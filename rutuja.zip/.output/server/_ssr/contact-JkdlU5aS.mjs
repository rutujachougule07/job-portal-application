import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n } from "./i18n-CEAlH7ip.mjs";
import { i as cn, n as Button } from "./button-DlK03b8v.mjs";
import { Ct as CircleCheck, F as Phone, H as Mail, V as MapPin, jt as Building2, x as Sparkles, z as MessageSquare } from "../_libs/lucide-react.mjs";
import { n as PublicHeader, t as PublicFooter } from "./PublicHeader-DazdRGin.mjs";
import { t as Input } from "./input-AgVN5mZH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-JkdlU5aS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-[60px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Textarea.displayName = "Textarea";
function ContactPage() {
	const { t } = useI18n();
	const [submitted, setSubmitted] = (0, import_react.useState)(false);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		email: "",
		phone: "",
		subject: "worker",
		message: ""
	});
	const handleSubmit = (e) => {
		e.preventDefault();
		setLoading(true);
		setTimeout(() => {
			setLoading(false);
			setSubmitted(true);
			setForm({
				name: "",
				email: "",
				phone: "",
				subject: "worker",
				message: ""
			});
		}, 1e3);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "bg-[#F5F8FC] min-h-screen py-10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-4 sm:px-6 lg:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-hero-overlay p-8 sm:p-12 rounded-2xl text-white mb-10 shadow-lg relative overflow-hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative z-10 max-w-3xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-bold uppercase tracking-wider text-[#FFC400] backdrop-blur mb-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5" }), t("contactSupportEyebrow")]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "text-3xl sm:text-5xl font-black text-white",
									children: t("contactTitle")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm sm:text-base font-medium text-white/90",
									children: t("contactSubtitle")
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-6 md:grid-cols-3 mb-10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "card-realjob p-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "size-12 rounded-xl bg-[#063B78]/10 text-[#063B78] flex items-center justify-center mb-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-6 text-[#063B78]" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-black text-lg text-[#10233F]",
										children: t("tollFreeTitle")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold text-[#5B6B7F] mt-1",
										children: t("tollFreeHours")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "tel:18002003040",
										className: "mt-3 block font-black text-[#063B78] text-lg hover:underline",
										children: "+91 1800 200 3040"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "mt-2 inline-flex items-center gap-1.5 text-xs font-bold text-emerald-600",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-emerald-500 animate-pulse" }),
											" ",
											t("liveSupportActive")
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "card-realjob p-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "size-12 rounded-xl bg-[#125BB5]/10 text-[#125BB5] flex items-center justify-center mb-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-6 text-[#125BB5]" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-black text-lg text-[#10233F]",
										children: t("emailSupportTitle")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold text-[#5B6B7F] mt-1",
										children: t("emailResponseTime")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "mailto:support@realjob.in",
										className: "mt-3 block font-black text-[#063B78] text-base hover:underline",
										children: "support@realjob.in"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-bold text-[#5B6B7F] mt-1",
										children: t("employerEmailNote")
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "card-realjob p-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "size-12 rounded-xl bg-[#063B78]/10 text-[#063B78] flex items-center justify-center mb-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-6 text-[#082F63]" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-black text-lg text-[#10233F]",
										children: t("hqTitle")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("address", {
										className: "mt-2 text-xs font-bold not-italic text-[#10233F] leading-relaxed",
										children: t("hqAddress")
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-10 lg:grid-cols-12 items-start",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-7 bg-white p-8 rounded-2xl border border-[#DCE5F0] shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 mb-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-10 rounded-xl bg-[#063B78] text-white flex items-center justify-center font-black",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: "size-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-2xl font-black text-[#10233F]",
									children: t("sendMessageTitle")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold text-[#5B6B7F]",
									children: t("sendMessageDesc")
								})] })]
							}), submitted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-8 rounded-xl bg-emerald-50 border border-emerald-200 text-center text-emerald-800 space-y-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mx-auto size-14 text-emerald-600 animate-bounce" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-xl font-black",
										children: t("messageSentSuccess")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold",
										children: t("messageSentDesc")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										onClick: () => setSubmitted(false),
										className: "btn-yellow text-xs font-bold mt-4",
										children: t("sendAnotherMessage")
									})
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: handleSubmit,
								className: "space-y-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid sm:grid-cols-2 gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "block text-xs font-extrabold text-[#10233F] mb-1",
											children: [t("yourName"), " *"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											required: true,
											placeholder: "Rahul Pawar",
											value: form.name,
											onChange: (e) => setForm({
												...form,
												name: e.target.value
											}),
											className: "h-11 border-[#DCE5F0] text-xs font-bold text-[#10233F]"
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "block text-xs font-extrabold text-[#10233F] mb-1",
											children: [t("emailAddress"), " *"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "email",
											required: true,
											placeholder: "name@example.com",
											value: form.email,
											onChange: (e) => setForm({
												...form,
												email: e.target.value
											}),
											className: "h-11 border-[#DCE5F0] text-xs font-bold text-[#10233F]"
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid sm:grid-cols-2 gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-xs font-extrabold text-[#10233F] mb-1",
											children: t("phoneNumber")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "tel",
											placeholder: "+91 98220 00000",
											value: form.phone,
											onChange: (e) => setForm({
												...form,
												phone: e.target.value
											}),
											className: "h-11 border-[#DCE5F0] text-xs font-bold text-[#10233F]"
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "block text-xs font-extrabold text-[#10233F] mb-1",
											children: [t("inquirySubject"), " *"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											value: form.subject,
											onChange: (e) => setForm({
												...form,
												subject: e.target.value
											}),
											className: "w-full h-11 rounded-lg border border-[#DCE5F0] bg-white px-3 text-xs font-bold text-[#10233F]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "worker",
													children: t("workerSupport")
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "employer",
													children: t("employerHiring")
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "tech",
													children: t("techSupport")
												})
											]
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block text-xs font-extrabold text-[#10233F] mb-1",
										children: [t("yourMessage"), " *"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										required: true,
										rows: 4,
										placeholder: t("messagePlaceholder"),
										value: form.message,
										onChange: (e) => setForm({
											...form,
											message: e.target.value
										}),
										className: "border-[#DCE5F0] text-xs font-bold text-[#10233F]"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										disabled: loading,
										type: "submit",
										className: "w-full btn-yellow font-black text-xs h-12",
										children: loading ? t("sending") : t("sendMessage")
									})
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "lg:col-span-5 space-y-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 rounded-2xl border border-[#DCE5F0] shadow-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-lg font-black text-[#10233F] mb-4 flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-5 text-[#063B78]" }),
										" ",
										t("regionalOffices")
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-4 text-xs font-bold text-[#10233F]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3 bg-[#F5F8FC] rounded-xl border border-[#DCE5F0]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-extrabold text-[#063B78] block",
												children: "Pune (Chakan Office)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[#5B6B7F]",
												children: "Industrial Hub, Chakan MIDC, Pune."
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3 bg-[#F5F8FC] rounded-xl border border-[#DCE5F0]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-extrabold text-[#063B78] block",
												children: "Mumbai (Thane / Navi Mumbai)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[#5B6B7F]",
												children: "Vashi Sector 17, Navi Mumbai."
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3 bg-[#F5F8FC] rounded-xl border border-[#DCE5F0]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-extrabold text-[#063B78] block",
												children: "Chhatrapati Sambhajinagar (Aurangabad)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[#5B6B7F]",
												children: "Waluj MIDC Area, Chhatrapati Sambhajinagar."
											})]
										})
									]
								})]
							})
						})]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
	] });
}
//#endregion
export { ContactPage as component };
