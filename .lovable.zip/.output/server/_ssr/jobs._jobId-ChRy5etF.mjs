import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n } from "./i18n-CEAlH7ip.mjs";
import { t as Button } from "./button--9UiOy7A.mjs";
import { g as Link, v as useParams } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as dataStore } from "./data-store-BCcScpg-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { Bt as Building2, D as Share2, Mt as CircleCheck, Ot as Clock3, Ut as Bookmark, Vt as Briefcase, W as MapPin, Wt as BookmarkCheck, Zt as ArrowLeft, a as Wallet, c as User, k as Send, r as X, zt as Building } from "../_libs/lucide-react.mjs";
import { t as PublicHeader } from "./PublicHeader-D-9eaxtQ.mjs";
import { t as PublicFooter } from "./PublicFooter-zsmeitx6.mjs";
import { t as Badge } from "./badge-DRaMiws1.mjs";
import { a as jobs, i as getFallbackConfig, t as DynamicApplicationForm } from "./JobCard-B_QpStMo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/jobs._jobId-ChRy5etF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function getJobDetails(jobId) {
	const storeJob = dataStore.getJobById(jobId);
	if (storeJob) return {
		id: storeJob.id,
		title: storeJob.title,
		company: storeJob.company,
		location: storeJob.location,
		salary: storeJob.salary,
		experience: storeJob.experience,
		type: storeJob.jobType,
		workMode: storeJob.workMode || "On-site",
		posted: storeJob.postedAgo || "Recently",
		initials: storeJob.initials || storeJob.company.slice(0, 2).toUpperCase(),
		category: storeJob.category,
		featured: storeJob.featured,
		openings: storeJob.vacancies,
		vacancies: storeJob.vacancies,
		description: storeJob.description,
		responsibilities: storeJob.responsibilities,
		requiredSkills: storeJob.requiredSkills,
		applicationConfig: storeJob.applicationConfig
	};
	return jobs.find((j) => j.id === jobId) ?? jobs[0];
}
function JobDetailPage() {
	const { t, n, lang } = useI18n();
	const { jobId } = useParams({ from: "/jobs/$jobId" });
	const job = getJobDetails(jobId);
	const [saved, setSaved] = (0, import_react.useState)(false);
	const [showApplyModal, setShowApplyModal] = (0, import_react.useState)(false);
	const [applied, setApplied] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!showApplyModal) return;
		const originalStyle = window.getComputedStyle(document.body).overflow;
		document.body.style.overflow = "hidden";
		return () => {
			document.body.style.overflow = originalStyle;
		};
	}, [showApplyModal]);
	const [applicantName, setApplicantName] = (0, import_react.useState)("");
	const [applicantPhone, setApplicantPhone] = (0, import_react.useState)("");
	const [applicantExp, setApplicantExp] = (0, import_react.useState)("3 Years");
	const [fieldValues, setFieldValues] = (0, import_react.useState)({});
	const [customAnswers, setCustomAnswers] = (0, import_react.useState)({});
	jobs.filter((j) => j.id !== job.id).slice(0, 3);
	const appConfig = job.applicationConfig || getFallbackConfig(job.category);
	const handleApplySubmit = (e) => {
		e.preventDefault();
		const currentUser = dataStore.getCurrentUser();
		const seekerId = currentUser ? currentUser.email || currentUser.id || "seeker-demo" : applicantName ? `seeker-${applicantName}` : "candidate@realjob.com";
		const name = applicantName || currentUser?.fullName || "Candidate";
		const userMobile = (seekerId ? dataStore.findRegisteredAccount(seekerId) : null)?.mobile || currentUser?.mobile || "";
		if (dataStore.hasAlreadyApplied(seekerId, job.id)) {
			toast.error(lang === "mr" ? "तुम्ही या नोकरीसाठी आधीच अर्ज भरला आहे!" : "You have already applied to this job!");
			setShowApplyModal(false);
			return;
		}
		const resolvedMobile = fieldValues["mobile"] || fieldValues["phone"] || fieldValues["candidateMobile"] || fieldValues["mobileNumber"] || fieldValues["contactNumber"] || fieldValues["phoneNo"] || fieldValues["mobileNo"] || applicantPhone || userMobile;
		try {
			dataStore.createApplication({
				jobId: job.id,
				employerId: job.company,
				jobSeekerId: seekerId,
				candidateName: fieldValues["fullName"] || name,
				candidateEmail: fieldValues["email"] || seekerId,
				candidateMobile: resolvedMobile,
				jobTitle: job.title,
				companyName: job.company,
				location: job.location,
				salary: job.salary,
				resume: fieldValues["resume"] || `${name.replaceAll(" ", "_")}_Resume.pdf`,
				fieldValues,
				customAnswers,
				category: job.category
			});
			setApplied(true);
			toast.success(`Application submitted for ${job.title}! ${job.company} will call you shortly.`);
			setTimeout(() => {
				setShowApplyModal(false);
				setApplied(false);
			}, 2e3);
		} catch (err) {
			toast.error(err.message || "Failed to submit application");
		}
	};
	const handleShare = () => {
		if (navigator.share) navigator.share({
			title: `${job.title} at ${job.company}`,
			text: `Check out this job opening on REAL JOB: ${job.title} (${job.salary})`,
			url: window.location.href
		});
		else {
			navigator.clipboard.writeText(window.location.href);
			toast.success("Job link copied to clipboard!");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "bg-[#F5F8FC] min-h-screen py-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-4 sm:px-6 lg:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-4 mb-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => window.history.back(),
							className: "px-3 py-2 text-[#5B6B7F] hover:text-[#10233F] hover:bg-white rounded-lg flex items-center gap-1.5 text-[13px] font-bold transition-colors shrink-0 shadow-sm border border-[#DCE5F0] bg-white",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }),
								" ",
								lang === "mr" ? "मागे जा" : "Back"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-xs font-bold text-[#5B6B7F]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/",
									className: "hover:text-[#063B78]",
									children: t("home")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "/" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/jobs",
									className: "hover:text-[#063B78]",
									children: t("jobs")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "/" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[#10233F]",
									children: job.title
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-white rounded-2xl p-6 sm:p-8 border border-[#DCE5F0] shadow-sm mb-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-16 shrink-0 place-items-center rounded-2xl bg-[#063B78] font-black text-2xl text-white shadow-md",
									children: job.initials
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 flex-wrap",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
											className: "bg-[#FFC400] text-[#082F63] font-black text-xs px-2.5 py-0.5",
											children: ["✓ ", t("verifiedCompany")]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: "outline",
											className: "border-[#063B78] text-[#063B78] font-bold text-xs",
											children: job.workMode
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "text-2xl sm:text-3xl font-black text-[#10233F] mt-1",
										children: job.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm font-extrabold text-[#125BB5] flex items-center gap-1.5 mt-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4" }),
											" ",
											job.company
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-3 flex flex-wrap gap-4 text-xs font-bold text-[#5B6B7F]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-1",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4 text-[#063B78]" }),
													" ",
													job.location
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-1 text-[#063B78]",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-4 text-[#FFC400]" }),
													" ",
													n(job.salary)
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-1",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { className: "size-4 text-[#5B6B7F]" }),
													" ",
													n(job.posted)
												]
											})
										]
									})
								] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex sm:flex-col gap-3 w-full sm:w-auto shrink-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: () => setShowApplyModal(true),
									className: "btn-yellow flex-1 sm:flex-none font-black text-xs px-8 py-3 h-11",
									children: t("applyNow")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: "outline",
										onClick: () => setSaved(!saved),
										className: `flex-1 border-[#063B78] font-bold text-xs h-11 ${saved ? "bg-[#EBF1F8] text-[#063B78]" : "text-[#063B78]"}`,
										children: [saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkCheck, { className: "size-4 mr-1 text-[#063B78]" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-4 mr-1" }), saved ? t("save") : t("save")]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "outline",
										onClick: handleShare,
										className: "border-[#063B78] text-[#063B78] font-bold text-xs h-11 px-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-4" })
									})]
								})]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid lg:grid-cols-3 gap-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "lg:col-span-2 space-y-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 sm:p-8 rounded-2xl border border-[#DCE5F0] shadow-xs space-y-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-lg font-black text-[#10233F] mb-3",
										children: t("jobDescription")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold text-[#5B6B7F] leading-relaxed",
										children: "Urgent requirement for skilled and experienced workforce in factory operations. The candidate should have relevant experience, willingness to work in shifts and maintain quality standards."
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-lg font-black text-[#10233F] mb-3",
										children: t("responsibilities")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
										className: "space-y-2 text-sm font-semibold text-[#5B6B7F] list-disc pl-5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Perform day-to-day operations and maintenance." }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Follow safety guidelines and complete production targets on time." }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Coordinate with team supervisor and plant management." })
										]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-lg font-black text-[#10233F] mb-3",
										children: t("requirements")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
										className: "space-y-2 text-sm font-semibold text-[#5B6B7F] list-disc pl-5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "10th / 12th Pass or ITI Trade Certificate." }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "1 to 5 years relevant trade experience." }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Punctuality and dedication to work." })
										]
									})] })
								]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white p-6 rounded-2xl border border-[#DCE5F0] shadow-xs sticky top-24 space-y-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-lg font-black text-[#10233F]",
									children: t("talkDirectlyToEmployer")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold text-[#5B6B7F] mt-1",
									children: t("directContactDesc")
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-3 pt-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 text-xs font-bold text-[#10233F]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-[#FFC400]" }),
												" ",
												t("freeApplication")
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 text-xs font-bold text-[#10233F]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-[#FFC400]" }),
												" ",
												t("response24h")
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 text-xs font-bold text-[#10233F]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-[#FFC400]" }),
												" ",
												t("verifiedCompany")
											]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: () => setShowApplyModal(true),
									className: "w-full btn-yellow font-black text-xs py-3 h-11",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4 mr-1.5" }),
										" ",
										t("applyNow")
									]
								})
							]
						}) })]
					})
				]
			}), showApplyModal && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-[100] flex flex-col bg-[#F5F8FC] overflow-y-auto animate-in fade-in duration-200",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white border-b border-[#DCE5F0] sticky top-0 z-10 px-4 sm:px-8 py-3 flex items-center justify-between shadow-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-8 rounded-xl bg-gradient-to-br from-[#125BB5] to-[#063B78] flex items-center justify-center text-white font-black shadow-md",
							children: "J"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-black text-[#082F63] text-xl tracking-tight hidden sm:block",
							children: "JobPortal"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setShowApplyModal(false),
						className: "flex items-center gap-2 px-4 py-2 rounded-xl bg-[#F5F8FC] text-[#5B6B7F] hover:text-[#10233F] hover:bg-[#EBF1F8] font-bold text-sm transition-colors",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }),
							" ",
							lang === "mr" ? "बंद करा" : "Close"
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1 w-full max-w-7xl mx-auto px-4 py-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col lg:flex-row gap-8 items-start",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 w-full bg-white rounded-3xl border border-[#DCE5F0] p-6 sm:p-10 shadow-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-3xl font-black text-[#082F63] mb-2",
									children: lang === "mr" ? "नोकरीसाठी अर्ज करा" : "Apply for Job"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[#5B6B7F] font-semibold text-sm mb-8",
									children: lang === "mr" ? "खालील माहिती काळजीपूर्वक भरा." : "Fill in the details below to apply for this job. Make sure all information is correct."
								}),
								applied ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-center py-12",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-20 text-[#063B78] mx-auto mb-4 animate-bounce" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-2xl font-black text-[#10233F]",
											children: lang === "mr" ? "अर्ज यशस्वीरीत्या पाठवला!" : "Application Submitted!"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-semibold text-[#5B6B7F] mt-2 max-w-md mx-auto",
											children: lang === "mr" ? "तुमचा अर्ज कंपनीला पाठवण्यात आला आहे. ते लवकरच तुमच्याशी संपर्क साधतील." : "Your application has been sent to the employer. They will contact you shortly."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											onClick: () => setShowApplyModal(false),
											className: "btn-yellow h-12 px-8 font-black text-sm mt-8 rounded-xl",
											children: lang === "mr" ? "मागे जा" : "Go Back"
										})
									]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: handleApplySubmit,
									className: "space-y-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DynamicApplicationForm, {
										appConfig,
										fieldValues,
										setFieldValues,
										customAnswers,
										setCustomAnswers,
										lang,
										category: job.category
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "pt-8 flex justify-end gap-4 mt-8",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											onClick: () => setShowApplyModal(false),
											variant: "outline",
											className: "h-12 px-8 font-bold text-sm rounded-xl border-[#DCE5F0] text-[#5B6B7F]",
											children: lang === "mr" ? "रद्द करा" : "Cancel"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											type: "submit",
											className: "btn-yellow h-12 px-8 font-black text-sm shadow-md rounded-xl",
											children: [
												lang === "mr" ? "अंतिम अर्ज सादर करा" : "Submit Application",
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "ml-2 size-4" })
											]
										})]
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "w-full lg:w-[400px] shrink-0 bg-white rounded-3xl border border-[#DCE5F0] p-6 shadow-sm sticky top-24 hidden lg:block",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between mb-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid size-14 place-items-center rounded-2xl bg-[#063B78] font-black text-white text-xl shadow-md",
										children: job.initials
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
										variant: "outline",
										className: "bg-emerald-50 text-emerald-700 border-emerald-200 font-bold px-3 py-1 flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5" }), "Active"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-2xl font-black text-[#10233F] mb-2",
									children: job.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2 mb-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm font-bold text-[#125BB5] flex items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building, { className: "size-4" }),
											" ",
											job.company
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm font-semibold text-[#5B6B7F] flex items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" }),
											" ",
											job.location
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "inline-block px-3 py-1 bg-[#EBF1F8] text-[#125BB5] text-xs font-bold rounded-lg mb-6",
									children: job.category || "General"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex gap-3 items-start",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "size-8 rounded-full bg-[#F5F8FC] flex items-center justify-center shrink-0",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4 text-[#5B6B7F]" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-bold text-[#5B6B7F]",
												children: "Experience Required"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-black text-[#10233F]",
												children: job.experience
											})] })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex gap-3 items-start",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "size-8 rounded-full bg-[#F5F8FC] flex items-center justify-center shrink-0",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-4 text-[#5B6B7F]" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-bold text-[#5B6B7F]",
												children: "Salary"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-black text-[#10233F]",
												children: job.salary
											})] })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex gap-3 items-start",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "size-8 rounded-full bg-[#F5F8FC] flex items-center justify-center shrink-0",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-4 text-[#5B6B7F]" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-bold text-[#5B6B7F]",
												children: "Vacancies"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-black text-[#10233F]",
												children: job.vacancies || job.openings || 1
											})] })]
										})
									]
								})
							]
						})]
					})
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
	] });
}
//#endregion
export { JobDetailPage as component };
