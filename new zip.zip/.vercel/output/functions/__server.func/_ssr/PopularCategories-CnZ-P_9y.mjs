import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n, n as getCategoryDesc, r as getCategoryTitle } from "./i18n-CEAlH7ip.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as dataStore } from "./data-store-BCcScpg-.mjs";
import { Vt as Briefcase, Xt as ArrowRight, _ as Stethoscope, et as Laptop, ft as GraduationCap, i as Wrench, m as TrendingUp, ot as Hotel, p as Truck, tt as Landmark, ut as HardHat, vt as Factory } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/PopularCategories-CnZ-P_9y.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PopularCategories({ limit = 8, hideHeader = false }) {
	const { t, n, lang } = useI18n();
	const allJobs = dataStore.getAllJobs();
	const dynamicCategories = (0, import_react.useMemo)(() => {
		const catData = /* @__PURE__ */ new Map();
		allJobs.forEach((job) => {
			if (!job.category) return;
			if (!catData.has(job.category)) catData.set(job.category, {
				id: job.category,
				subcategories: /* @__PURE__ */ new Set()
			});
			if (job.subcategory) catData.get(job.category).subcategories.add(job.subcategory);
		});
		return Array.from(catData.values()).map((data) => {
			let icon = Briefcase;
			const lc = data.id.toLowerCase();
			if (lc.includes("construction") || lc.includes("builder") || lc.includes("civil")) icon = HardHat;
			else if (lc.includes("software") || lc.includes("it") || lc.includes("develop")) icon = Laptop;
			else if (lc.includes("engineer") || lc.includes("tech")) icon = Wrench;
			else if (lc.includes("health") || lc.includes("medic") || lc.includes("doctor")) icon = Stethoscope;
			else if (lc.includes("financ") || lc.includes("account") || lc.includes("bank")) icon = Landmark;
			else if (lc.includes("sales") || lc.includes("market")) icon = TrendingUp;
			else if (lc.includes("educat") || lc.includes("teach")) icon = GraduationCap;
			else if (lc.includes("manufact") || lc.includes("factory") || lc.includes("production")) icon = Factory;
			else if (lc.includes("logistic") || lc.includes("transport") || lc.includes("delivery")) icon = Truck;
			else if (lc.includes("hotel") || lc.includes("hospitality") || lc.includes("restaurant")) icon = Hotel;
			return {
				id: data.id,
				icon,
				profilesCount: data.subcategories.size || 1
			};
		});
	}, [allJobs]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "categories",
		className: hideHeader ? "relative" : "relative bg-[#F5F8FC] py-16 sm:py-24 overflow-hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: hideHeader ? "" : "relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
			children: [!hideHeader && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col md:flex-row md:items-end justify-between gap-6 w-full mb-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-start text-left max-w-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-2 rounded-full border border-[#063B78]/20 bg-[#063B78]/10 px-4 py-1.5 text-xs font-bold uppercase tracking-wider text-[#063B78]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-[#FFC400]" }), t("popularCategoriesEyebrow")]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 text-3xl font-black text-[#10233F] sm:text-4xl",
							children: t("popularCategories")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-base font-semibold text-[#5B6B7F]",
							children: t("popularCategoriesSubtitle")
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/jobs",
					className: "inline-flex items-center gap-2 rounded-lg bg-[#063B78] px-6 py-3 text-sm font-bold text-white shadow-md transition-all duration-200 hover:bg-[#082F63] hover:shadow-lg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("viewAll") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 text-[#FFC400]" })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5",
				children: [dynamicCategories.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "col-span-full text-center py-12 text-[#5B6B7F] font-semibold",
					children: "सध्या कोणतीही श्रेणी उपलब्ध नाही. (No categories available at the moment.)"
				}), dynamicCategories.slice(0, limit).map((cat) => {
					const IconComponent = cat.icon;
					const categoryTitle = getCategoryTitle(cat.id, lang) || cat.id;
					const categoryDesc = getCategoryDesc(cat.id, lang);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/jobs",
						search: { category: cat.id },
						className: "group card-realjob p-6 flex flex-col justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-12 rounded-xl bg-[#063B78]/10 text-[#063B78] flex items-center justify-center group-hover:bg-[#FFC400] group-hover:text-[#082F63] transition-colors",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconComponent, { className: "size-6" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-black bg-[#EBF1F8] text-[#063B78] px-2.5 py-1 rounded-full group-hover:bg-[#063B78] group-hover:text-white transition-colors",
									children: [
										n(cat.profilesCount),
										" ",
										lang === "mr" ? "प्रोफाईल्स" : "Profiles"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg font-black text-[#10233F] group-hover:text-[#063B78] transition-colors",
								children: categoryTitle
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs font-semibold text-[#5B6B7F] line-clamp-2",
								children: categoryDesc
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 pt-3 border-t border-[#DCE5F0] flex items-center justify-between text-xs font-bold text-[#063B78] group-hover:text-[#125BB5]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("apply") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 transition-transform group-hover:translate-x-1" })]
						})]
					}, cat.id);
				})]
			})]
		})
	});
}
//#endregion
export { PopularCategories as t };
