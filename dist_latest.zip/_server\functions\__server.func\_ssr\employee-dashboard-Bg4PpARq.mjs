import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/employee-dashboard-Bg4PpARq.js
var $$splitComponentImporter = () => import("./employee-dashboard-RCs3vE1A.mjs");
var Route = createFileRoute("/employee-dashboard")({
	validateSearch: (search) => {
		return { tab: search["tab"] };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
