import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n, r as getCategoryTitle } from "./i18n-CEAlH7ip.mjs";
import { t as Button } from "./button--9UiOy7A.mjs";
import { t as dataStore } from "./data-store-BCcScpg-.mjs";
import { A as Search, B as PackageCheck, N as RotateCcw, S as SlidersHorizontal, T as ShieldCheck, Vt as Briefcase, W as MapPin, Z as LayoutGrid, Zt as ArrowLeft, _t as Factory, at as Hotel, ct as Headphones, d as UserCheck, i as Wrench, lt as HardHat, mt as Funnel, p as Truck, r as X, s as Users, t as Zap, zt as Building } from "../_libs/lucide-react.mjs";
import { t as PublicHeader } from "./PublicHeader-D-9eaxtQ.mjs";
import { t as PublicFooter } from "./PublicFooter-zsmeitx6.mjs";
import { t as Input } from "./input-CZUnWUIa.mjs";
import { n as JobCard } from "./JobCard-B_QpStMo.mjs";
import { t as PopularCategories } from "./PopularCategories-CnZ-P_9y.mjs";
import { t as Route } from "./jobs.index-BK1VOIrX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/jobs.index-FvR043gF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function JobsListingPage() {
	const { t, n, lang } = useI18n();
	const searchParams = Route.useSearch();
	const [searchTerm, setSearchTerm] = (0, import_react.useState)("");
	const [categoryFilter, setCategoryFilter] = (0, import_react.useState)(searchParams.category || "all");
	const [subCategoryFilter, setSubCategoryFilter] = (0, import_react.useState)("all");
	const [locationFilter, setLocationFilter] = (0, import_react.useState)("all");
	const [salaryFilter, setSalaryFilter] = (0, import_react.useState)("all");
	const [experienceFilter, setExperienceFilter] = (0, import_react.useState)("all");
	const [typeFilter, setTypeFilter] = (0, import_react.useState)("all");
	const [sortBy, setSortBy] = (0, import_react.useState)("newest");
	const [mobileFilterOpen, setMobileFilterOpen] = (0, import_react.useState)(false);
	const [workModeFilter, setWorkModeFilter] = (0, import_react.useState)("all");
	(0, import_react.useEffect)(() => {
		setCategoryFilter(searchParams.category || "all");
		setSubCategoryFilter("all");
	}, [searchParams.category]);
	const isInitialState = (!categoryFilter || categoryFilter === "all") && !searchTerm && (!locationFilter || locationFilter === "all") && (!typeFilter || typeFilter === "all") && (!workModeFilter || workModeFilter === "all") && (!experienceFilter || experienceFilter === "all") && (!salaryFilter || salaryFilter === "all");
	const dynamicSubCategories = (0, import_react.useMemo)(() => {
		if (!categoryFilter || categoryFilter === "all") return [];
		const jobsInCategory = dataStore.getActiveJobs().filter((j) => j.category.toLowerCase().replace(/ & /g, "-").replace(/ /g, "-") === categoryFilter.toLowerCase() || j.category.toLowerCase() === categoryFilter.toLowerCase());
		const subs = /* @__PURE__ */ new Set();
		jobsInCategory.forEach((j) => {
			if (j.subcategory) subs.add(j.subcategory);
		});
		return Array.from(subs).map((sub) => ({
			id: sub,
			label: sub
		}));
	}, [categoryFilter]);
	const resetFilters = () => {
		setSearchTerm("");
		setCategoryFilter("all");
		setLocationFilter("all");
		setSalaryFilter("all");
		setExperienceFilter("all");
		setTypeFilter("all");
		setWorkModeFilter("all");
		setSortBy("newest");
		setSubCategoryFilter("all");
	};
	const filteredJobs = (0, import_react.useMemo)(() => {
		return dataStore.getActiveJobs().map((dj) => ({
			id: dj.id,
			title: dj.title,
			company: dj.company,
			location: dj.location,
			salary: dj.salary,
			experience: dj.experience,
			type: dj.jobType,
			workMode: dj.workMode || "On-site",
			posted: dj.postedAgo || "Recently",
			initials: dj.initials || dj.company.slice(0, 2).toUpperCase(),
			category: dj.category,
			featured: dj.featured ?? false,
			openings: dj.vacancies ?? 1
		})).filter((job) => {
			const term = searchTerm.toLowerCase();
			const matchesSearch = !term || job.title.toLowerCase().includes(term) || job.company.toLowerCase().includes(term) || job.location.toLowerCase().includes(term) || job.category && job.category.toLowerCase().includes(term);
			let matchesCategory = false;
			if (categoryFilter === "all" || !categoryFilter) matchesCategory = true;
			else {
				const normalizedFilter = categoryFilter.toLowerCase().replace(/ & /g, "-").replace(/ /g, "-");
				const jobCatNorm = (job.category || "").toLowerCase().replace(/ & /g, "-").replace(/ /g, "-");
				matchesCategory = jobCatNorm === normalizedFilter || jobCatNorm.includes(normalizedFilter) || normalizedFilter.includes(jobCatNorm);
			}
			if (matchesCategory && subCategoryFilter !== "all" && subCategoryFilter) {
				const subClean = subCategoryFilter.toLowerCase();
				const titleClean = job.title.toLowerCase();
				const catClean = (job.category || "").toLowerCase();
				matchesCategory = titleClean.includes(subClean) || catClean.includes(subClean) || subClean.includes(titleClean);
			}
			const matchesLocation = locationFilter === "all" || job.location.toLowerCase().includes(locationFilter.toLowerCase());
			const matchesType = typeFilter === "all" || job.type.toLowerCase() === typeFilter.toLowerCase();
			const matchesWorkMode = workModeFilter === "all" || job.workMode.toLowerCase() === workModeFilter.toLowerCase();
			let matchesExp = true;
			if (experienceFilter !== "all") {
				const expStr = job.experience.toLowerCase();
				if (experienceFilter === "Fresher") matchesExp = expStr.includes("fresher") || expStr.includes("0-2");
				else if (experienceFilter === "1-3") matchesExp = expStr.includes("1-3") || expStr.includes("1+") || expStr.includes("0-2") || expStr.includes("2-5");
				else if (experienceFilter === "3-5") matchesExp = expStr.includes("3+") || expStr.includes("2-5") || expStr.includes("3-5") || expStr.includes("5+");
				else if (experienceFilter === "5+") matchesExp = expStr.includes("5+");
			}
			let matchesSalary = true;
			if (salaryFilter !== "all") {
				const minTarget = parseInt(salaryFilter);
				const match = job.salary.match(/\d+,\d+/);
				if (match) matchesSalary = parseInt(match[0].replace(",", "")) >= minTarget;
				else if (job.salary.includes("/day")) {
					const dayMatch = job.salary.match(/\d+/);
					if (dayMatch) matchesSalary = parseInt(dayMatch[0]) * 26 >= minTarget;
				}
			}
			return matchesSearch && matchesCategory && matchesLocation && matchesType && matchesWorkMode && matchesExp && matchesSalary;
		});
	}, [
		searchTerm,
		categoryFilter,
		locationFilter,
		typeFilter,
		workModeFilter,
		subCategoryFilter,
		experienceFilter,
		salaryFilter,
		lang
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "bg-[#F5F8FC] min-h-screen py-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
				children: [
					!categoryFilter || categoryFilter === "all" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-hero-overlay p-8 rounded-2xl text-white mb-8 shadow-lg relative overflow-hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative z-10 max-w-3xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-bold uppercase tracking-wider text-[#FFC400] backdrop-blur mb-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-3.5" }), t("jobs")]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
									className: "text-3xl sm:text-4xl font-black text-white",
									children: [
										t("jobsInRegion"),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[#FFC400]",
											children: t("directCompanyContact")
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-white/90 font-medium",
									children: t("jobsSubtext")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-6 grid sm:grid-cols-[1fr_0.8fr_auto] gap-3 bg-white p-2.5 rounded-xl shadow-md border border-[#DCE5F0]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative flex items-center",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 size-4 text-[#5B6B7F]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												placeholder: t("searchJobPlaceholder"),
												value: searchTerm,
												onChange: (e) => setSearchTerm(e.target.value),
												className: "pl-9 h-11 border-0 bg-transparent text-xs text-[#10233F] font-bold focus-visible:ring-0"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative flex items-center",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "absolute left-3 size-4 text-[#125BB5]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
												value: locationFilter,
												onChange: (e) => setLocationFilter(e.target.value),
												className: "w-full h-11 border-0 bg-transparent text-xs font-bold text-[#10233F] pl-9 pr-3 focus:outline-none",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "all",
														children: t("allLocations")
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "mumbai",
														children: "Mumbai"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "pune",
														children: "Pune"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "chakan",
														children: "Chakan"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "bengaluru",
														children: "Bengaluru"
													})
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											className: "btn-yellow h-11 font-black text-xs px-6",
											children: t("search")
										})
									]
								})
							]
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-8 flex flex-col md:flex-row gap-6 justify-between items-start md:items-center bg-white p-6 rounded-2xl border border-[#DCE5F0] shadow-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								setCategoryFilter("all");
								setSubCategoryFilter("all");
							},
							className: "text-xs font-bold text-[#125BB5] mb-3 flex items-center gap-1 hover:underline",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3" }),
								" ",
								lang === "mr" ? "सर्व नोकऱ्या पहा" : "All Jobs"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-14 rounded-2xl bg-gradient-to-br from-[#EBF1F8] to-[#DCE5F0] flex items-center justify-center text-[#063B78] shadow-inner",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-6" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-2xl sm:text-3xl font-black text-[#082F63] capitalize",
								children: getCategoryTitle(categoryFilter, lang)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm font-bold text-[#5B6B7F] mt-1",
								children: [
									filteredJobs.length,
									" ",
									lang === "mr" ? "नोकऱ्या उपलब्ध" : "Jobs Available"
								]
							})] })]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-full md:w-auto grid grid-cols-[1fr] gap-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative flex items-center w-full md:w-[280px]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 size-4 text-[#5B6B7F]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: lang === "mr" ? "नोकरी शोधा..." : "Search in category...",
									value: searchTerm,
									onChange: (e) => setSearchTerm(e.target.value),
									className: "pl-9 h-12 border border-[#DCE5F0] bg-[#F5F8FC] rounded-xl text-xs text-[#10233F] font-bold focus-visible:ring-1 focus-visible:ring-[#125BB5]"
								})]
							})
						})]
					}),
					(!categoryFilter || categoryFilter === "all") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-8 bg-white p-6 rounded-2xl border border-[#DCE5F0] shadow-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "text-xl font-black text-[#10233F] mb-6 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, { className: "size-5 text-[#063B78]" }), t("popularCategories")]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopularCategories, {
							limit: 20,
							hideHeader: true
						})]
					}),
					!isInitialState && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `grid grid-cols-1 ${categoryFilter !== "all" && categoryFilter ? "lg:grid-cols-[280px_1fr]" : ""} gap-8 items-start`,
						children: [categoryFilter !== "all" && categoryFilter && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
							className: "hidden lg:block bg-white p-6 rounded-2xl border border-[#DCE5F0] shadow-xs sticky top-24",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between pb-4 border-b border-[#DCE5F0] mb-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-black text-sm text-[#10233F] flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "size-4 text-[#063B78]" }), t("filters")]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: resetFilters,
										className: "text-xs font-bold text-[#125BB5] hover:underline flex items-center gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3" }),
											" ",
											t("reset")
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
										children: t("experience")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: experienceFilter,
										onChange: (e) => setExperienceFilter(e.target.value),
										className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "all",
												children: t("experience")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Fresher",
												children: "Fresher"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "1-3",
												children: "1-3 Years"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "3-5",
												children: "3-5 Years"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "5+",
												children: "5+ Years"
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
										children: t("expectedSalary")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: salaryFilter,
										onChange: (e) => setSalaryFilter(e.target.value),
										className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "all",
												children: t("expectedSalary")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "10000",
												children: "₹10,000+ / mo"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "15000",
												children: "₹15,000+ / mo"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "20000",
												children: "₹20,000+ / mo"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "25000",
												children: "₹25,000+ / mo"
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
										children: t("jobTypeLabel")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: typeFilter,
										onChange: (e) => setTypeFilter(e.target.value),
										className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "all",
												children: t("allTypes")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Full-time",
												children: t("fullTime")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Part-time",
												children: t("partTime")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Contract",
												children: t("contract")
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
										children: "Work Mode / मोड"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: workModeFilter,
										onChange: (e) => setWorkModeFilter(e.target.value),
										className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "all",
												children: "All Modes / सर्व मोड"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Remote",
												children: "🏠 Work From Home (WFH)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "On-site",
												children: "🏢 On-site (Office / Site)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Hybrid",
												children: "🔄 Hybrid"
											})
										]
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "w-full",
							children: [
								categoryFilter !== "all" && categoryFilter && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-[#DCE5F0] mb-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex items-center gap-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-sm font-black text-[#10233F]",
											children: [
												t("totalJobsCount"),
												": ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[#063B78]",
													children: n(filteredJobs.length)
												})
											]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											variant: "outline",
											size: "sm",
											className: "lg:hidden text-xs font-bold border-[#063B78] text-[#063B78]",
											onClick: () => setMobileFilterOpen(true),
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { className: "size-3.5 mr-1" }),
												" ",
												t("filters")
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-xs font-bold text-[#5B6B7F] shrink-0",
												children: [t("sortByLabel"), ":"]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
												value: sortBy,
												onChange: (e) => setSortBy(e.target.value),
												className: "h-9 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "newest",
													children: t("newestFirst")
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "title",
													children: t("byTitle")
												})]
											})]
										})]
									})]
								}),
								categoryFilter !== "all" && categoryFilter && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-8",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex border-b border-[#DCE5F0] mb-6 overflow-x-auto no-scrollbar items-end gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => {
												setCategoryFilter("all");
												setSubCategoryFilter("all");
											},
											className: "px-3 py-2 text-[#5B6B7F] hover:text-[#10233F] hover:bg-[#F5F8FC] rounded-lg mb-1 ml-1 flex items-center gap-1.5 text-[13px] font-bold transition-colors shrink-0",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }),
												" ",
												t("viewWebsite")
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative px-8 py-3 text-sm font-black text-[#10233F] bg-white border border-b-0 border-[#DCE5F0] rounded-t-[16px] shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)] z-10 flex items-center gap-2 shrink-0",
											children: [
												categoryFilter === "factory-workers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Factory, { className: "size-4" }) : categoryFilter === "construction-workers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HardHat, { className: "size-4" }) : categoryFilter === "technical-staff" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, { className: "size-4" }) : categoryFilter === "logistics-drivers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "size-4" }) : categoryFilter === "skilled-workers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-4" }) : categoryFilter === "unskilled-workers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4" }) : categoryFilter === "helpers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Headphones, { className: "size-4" }) : categoryFilter === "electricians" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-4" }) : categoryFilter === "maintenance" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building, { className: "size-4" }) : categoryFilter === "warehouse-workers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackageCheck, { className: "size-4" }) : categoryFilter === "hotel-restaurant" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hotel, { className: "size-4" }) : categoryFilter === "security" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4" }),
												getCategoryTitle(categoryFilter, lang) || categoryFilter,
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-3 bottom-0 w-3 h-full bg-white skew-x-[15deg] origin-bottom border-r border-[#DCE5F0]" })
											]
										})]
									}), dynamicSubCategories.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => setSubCategoryFilter("all"),
											className: `px-5 py-2.5 rounded-full text-[11px] font-black tracking-wide uppercase transition-all shadow-sm flex items-center gap-2 ${subCategoryFilter === "all" ? "bg-[#063B78] text-white shadow-md scale-105" : "bg-white border border-[#DCE5F0] text-[#5B6B7F] hover:bg-[#F5F8FC] hover:text-[#10233F] hover:scale-105"}`,
											children: t("allCategories")
										}), dynamicSubCategories.map((sub) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => setSubCategoryFilter(sub.id),
											className: `px-5 py-2.5 rounded-full text-[11px] font-black tracking-wide uppercase transition-all shadow-sm flex items-center gap-2 ${subCategoryFilter === sub.id ? "bg-[#063B78] text-white shadow-md scale-105" : "bg-white border border-[#DCE5F0] text-[#5B6B7F] hover:bg-[#F5F8FC] hover:text-[#10233F] hover:scale-105"}`,
											children: sub.label
										}, sub.id))]
									})]
								}),
								filteredJobs.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 lg:grid-cols-2 gap-5",
									children: filteredJobs.map((job) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JobCard, { job }, job.id))
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "card-realjob p-12 text-center bg-white rounded-2xl border border-[#DCE5F0]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "mx-auto size-14 text-[#5B6B7F] mb-4" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-xl font-black text-[#10233F]",
											children: "कोणतीही नोकरी उपलब्ध नाही (No Jobs Found)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold text-[#5B6B7F] mt-2",
											children: "अद्याप कोणतीही नवीन नोकरी पोस्ट केलेली नाही. मालक / कंपनी नवीन नोकरी पोस्ट करतील तेव्हा ती येथे थेट दिसेल."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											onClick: resetFilters,
											className: "mt-5 btn-yellow text-xs font-bold px-6",
											children: t("resetFilters")
										})
									]
								})
							]
						})]
					})
				]
			}), mobileFilterOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-[#082F63]/60 backdrop-blur-sm flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-xs bg-white h-full p-6 overflow-y-auto shadow-2xl flex flex-col justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between pb-4 border-b border-[#DCE5F0] mb-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-black text-base text-[#10233F]",
							children: t("filters")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setMobileFilterOpen(false),
							className: "p-1 text-[#5B6B7F]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-6" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
								children: lang === "mr" ? "अनुभव" : "Experience"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: experienceFilter,
								onChange: (e) => setExperienceFilter(e.target.value),
								className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "all",
										children: lang === "mr" ? "सर्व अनुभव" : "Any Experience"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Fresher",
										children: lang === "mr" ? "फ्रेसर" : "Fresher"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: "1-3",
										children: ["1-3 ", lang === "mr" ? "वर्षे" : "Years"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: "3-5",
										children: ["3-5 ", lang === "mr" ? "वर्षे" : "Years"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: "5+",
										children: ["5+ ", lang === "mr" ? "वर्षे" : "Years"]
									})
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
								children: lang === "mr" ? "किमान पगार" : "Minimum Salary"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: salaryFilter,
								onChange: (e) => setSalaryFilter(e.target.value),
								className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "all",
										children: lang === "mr" ? "कोणताही पगार" : "Any Salary"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: "10000",
										children: ["₹10,000+ / ", lang === "mr" ? "महिना" : "mo"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: "15000",
										children: ["₹15,000+ / ", lang === "mr" ? "महिना" : "mo"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: "20000",
										children: ["₹20,000+ / ", lang === "mr" ? "महिना" : "mo"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: "25000",
										children: ["₹25,000+ / ", lang === "mr" ? "महिना" : "mo"]
									})
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
								children: t("jobTypeLabel")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: typeFilter,
								onChange: (e) => setTypeFilter(e.target.value),
								className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "all",
										children: t("allTypes")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Full-time",
										children: t("fullTime")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Part-time",
										children: t("partTime")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Contract",
										children: t("contract")
									})
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
								children: "Work Mode / मोड"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: workModeFilter,
								onChange: (e) => setWorkModeFilter(e.target.value),
								className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "all",
										children: "All Modes / सर्व मोड"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Remote",
										children: "🏠 Work From Home (WFH)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "On-site",
										children: "🏢 On-site (Office / Site)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Hybrid",
										children: "🔄 Hybrid"
									})
								]
							})] })
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-6 border-t border-[#DCE5F0] grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: resetFilters,
							className: "text-xs font-bold",
							children: t("reset")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => setMobileFilterOpen(false),
							className: "btn-yellow text-xs font-extrabold",
							children: t("continue")
						})]
					})]
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
	] });
}
//#endregion
export { JobsListingPage as component };
