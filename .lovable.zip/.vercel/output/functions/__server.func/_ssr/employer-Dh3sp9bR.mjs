import { n as EmployerDashboard } from "./Dashboards-BuSAs1ES.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/employer-Dh3sp9bR.js
var SplitComponent = EmployerDashboard;
//#endregion
export { SplitComponent as component };
