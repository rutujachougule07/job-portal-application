import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n, n as getCategoryDesc, r as getCategoryTitle } from "./i18n-CEAlH7ip.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { $ as Laptop, A as Search, Bt as Building2, C as ShoppingBag, P as Radio, Xt as ArrowRight, _ as Stethoscope, _t as Factory, at as Hotel, b as Sprout, ct as Headphones, dt as GraduationCap, et as Landmark, ht as FlaskConical, i as Wrench, j as Scale, lt as HardHat, m as TrendingUp, p as Truck, u as UserPlus, wt as Compass, x as Sparkles, z as Palette } from "../_libs/lucide-react.mjs";
import { t as PublicHeader } from "./PublicHeader-D-9eaxtQ.mjs";
import { t as PublicFooter } from "./PublicFooter-zsmeitx6.mjs";
import { t as Input } from "./input-CZUnWUIa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/categories-CIi-5jKB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CategoriesPage() {
	const { t, n, lang } = useI18n();
	const [searchTerm, setSearchTerm] = (0, import_react.useState)("");
	const filtered = [
		{
			id: "construction",
			jobsCount: "1,950",
			icon: HardHat
		},
		{
			id: "it-software",
			jobsCount: "3,420",
			icon: Laptop
		},
		{
			id: "engineering",
			jobsCount: "2,840",
			icon: Wrench
		},
		{
			id: "healthcare-medical",
			jobsCount: "1,680",
			icon: Stethoscope
		},
		{
			id: "finance-accounting",
			jobsCount: "2,110",
			icon: Landmark
		},
		{
			id: "sales-marketing",
			jobsCount: "4,150",
			icon: TrendingUp
		},
		{
			id: "education",
			jobsCount: "1,450",
			icon: GraduationCap
		},
		{
			id: "manufacturing",
			jobsCount: "3,890",
			icon: Factory
		},
		{
			id: "hr-recruitment",
			jobsCount: "1,220",
			icon: UserPlus
		},
		{
			id: "hospitality-tourism",
			jobsCount: "1,530",
			icon: Hotel
		},
		{
			id: "logistics-transport",
			jobsCount: "2,760",
			icon: Truck
		},
		{
			id: "government-public",
			jobsCount: "980",
			icon: Building2
		},
		{
			id: "legal",
			jobsCount: "640",
			icon: Scale
		},
		{
			id: "architecture-design",
			jobsCount: "890",
			icon: Compass
		},
		{
			id: "retail-ecommerce",
			jobsCount: "2,350",
			icon: ShoppingBag
		},
		{
			id: "customer-service-bpo",
			jobsCount: "3,100",
			icon: Headphones
		},
		{
			id: "design-creative",
			jobsCount: "1,140",
			icon: Palette
		},
		{
			id: "media-communication",
			jobsCount: "780",
			icon: Radio
		},
		{
			id: "agriculture-farming",
			jobsCount: "1,050",
			icon: Sprout
		},
		{
			id: "science-research",
			jobsCount: "740",
			icon: FlaskConical
		}
	].filter((c) => {
		const title = getCategoryTitle(c.id, lang).toLowerCase();
		const desc = getCategoryDesc(c.id, lang).toLowerCase();
		const term = searchTerm.toLowerCase();
		return title.includes(term) || desc.includes(term);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "bg-[#F5F8FC] min-h-screen py-10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bg-hero-overlay p-8 sm:p-12 rounded-2xl text-white mb-10 shadow-lg relative overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 max-w-3xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-bold uppercase tracking-wider text-[#FFC400] backdrop-blur mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5" }), t("catHeroEyebrow")]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "text-3xl sm:text-5xl font-black text-white",
								children: [
									t("catHeroTitle"),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[#FFC400]",
										children: t("catHeroSub")
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm sm:text-base font-medium text-white/90",
								children: t("popularCategoriesSubtitle")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 relative max-w-xl",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-4 top-1/2 -translate-y-1/2 size-5 text-[#5B6B7F]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "text",
									placeholder: t("catSearchPlaceholder"),
									value: searchTerm,
									onChange: (e) => setSearchTerm(e.target.value),
									className: "h-12 pl-12 bg-white border-0 text-xs font-bold text-[#10233F] rounded-xl shadow-md focus-visible:ring-[#FFC400]"
								})]
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6",
					children: filtered.map((cat) => {
						const Icon = cat.icon;
						const title = getCategoryTitle(cat.id, lang);
						const desc = getCategoryDesc(cat.id, lang);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/jobs",
							search: { category: cat.id },
							className: "card-realjob p-6 flex flex-col justify-between group",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "size-12 rounded-xl bg-[#063B78]/10 text-[#063B78] flex items-center justify-center group-hover:bg-[#FFC400] group-hover:text-[#082F63] transition-colors",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-6" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs font-black bg-[#EBF1F8] text-[#063B78] px-2.5 py-1 rounded-full group-hover:bg-[#063B78] group-hover:text-white transition-colors",
										children: [
											n(cat.jobsCount),
											" ",
											t("jobsCountText")
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-lg font-black text-[#10233F] group-hover:text-[#063B78] transition-colors",
									children: title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-xs font-semibold text-[#5B6B7F] leading-relaxed",
									children: desc
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5 pt-3 border-t border-[#DCE5F0] flex items-center justify-between text-xs font-bold text-[#063B78] group-hover:text-[#125BB5]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("browseJobs") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 transition-transform group-hover:translate-x-1" })]
							})]
						}, cat.id);
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
	] });
}
//#endregion
export { CategoriesPage as component };
