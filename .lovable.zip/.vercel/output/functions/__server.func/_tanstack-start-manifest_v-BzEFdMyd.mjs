//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BzEFdMyd.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/job-portal-application-main/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/about",
			"/admin",
			"/auth",
			"/categories",
			"/contact",
			"/dashboard",
			"/faq",
			"/home",
			"/reset-password",
			"/select-language",
			"/superadmin",
			"/company/$companyId",
			"/jobs/$jobId",
			"/workers/$workerId",
			"/jobs/",
			"/workers/"
		],
		preloads: [
			"/assets/index-CVOJDR3A.js",
			"/assets/rolldown-runtime-hePW80VL.js",
			"/assets/useRouter-CmhgAzN5.js",
			"/assets/react-dom-DHRi64S4.js",
			"/assets/Match-BpKa3JvO.js",
			"/assets/lazyRouteComponent-BbGAYUkN.js",
			"/assets/link-hNFDYPQv.js",
			"/assets/useMatch-Bc8_-oHk.js",
			"/assets/root-DLTE-HSj.js",
			"/assets/useSelector-BdvyXqSB.js",
			"/assets/preload-helper-Czpn1I53.js",
			"/assets/types-DKSnJpxg.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CVOJDR3A.js"
		} }]
	},
	"/": {
		filePath: "C:/job-portal-application-main/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BzO6rX90.js",
			"/assets/useNavigate-BtH586Ug.js",
			"/assets/button-BNkNxccP.js",
			"/assets/createLucideIcon-Brgs3nTD.js",
			"/assets/arrow-right-uAPemfR5.js",
			"/assets/briefcase-e5GQkTn9.js",
			"/assets/building-2-CWEOzFke.js",
			"/assets/eye-CBwm70VB.js",
			"/assets/truck-Dql2JKFs.js",
			"/assets/hard-hat-Dd6xDfkE.js",
			"/assets/PublicFooter-Dsli6k48.js",
			"/assets/shield-check-Dweaf7ZR.js",
			"/assets/sparkles-CxhP7C1G.js",
			"/assets/star-D_V3pO2r.js",
			"/assets/target-DqcM_aBI.js",
			"/assets/user-check-DVfmk_u_.js",
			"/assets/users-7Ef-6M2B.js",
			"/assets/wrench-BcZ39l3P.js",
			"/assets/zap-DDpT0BMQ.js",
			"/assets/Brand-De_SMchX.js",
			"/assets/data-store-CzhBQGbm.js",
			"/assets/career-team-DHTUSRpW.js"
		]
	},
	"/_authenticated": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/applications",
			"/_authenticated/control",
			"/_authenticated/employer",
			"/_authenticated/messages",
			"/_authenticated/notifications",
			"/_authenticated/post-job",
			"/_authenticated/profile",
			"/_authenticated/salary"
		],
		preloads: ["/assets/route-8PSLvnjs.js"]
	},
	"/about": {
		filePath: "C:/job-portal-application-main/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-BsekNnPn.js",
			"/assets/useNavigate-BtH586Ug.js",
			"/assets/button-BNkNxccP.js",
			"/assets/building-2-CWEOzFke.js",
			"/assets/circle-check-D_8zmU9y.js",
			"/assets/globe-DiKjLfTe.js",
			"/assets/hard-hat-Dd6xDfkE.js",
			"/assets/heart-handshake-Dtx-8-Ja.js",
			"/assets/PublicFooter-Dsli6k48.js",
			"/assets/shield-check-Dweaf7ZR.js",
			"/assets/sparkles-CxhP7C1G.js",
			"/assets/target-DqcM_aBI.js",
			"/assets/zap-DDpT0BMQ.js",
			"/assets/data-store-CzhBQGbm.js",
			"/assets/PublicHeader-H7KAn3ea.js"
		]
	},
	"/admin": {
		filePath: "C:/job-portal-application-main/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-mF2R1gkD.js",
			"/assets/useNavigate-BtH586Ug.js",
			"/assets/button-BNkNxccP.js",
			"/assets/createLucideIcon-Brgs3nTD.js",
			"/assets/Stats-BBfUGpQj.js",
			"/assets/LanguageSwitcher-DvfCbxX7.js",
			"/assets/building-2-CWEOzFke.js",
			"/assets/check-JSUsLmOq.js",
			"/assets/circle-check-D_8zmU9y.js",
			"/assets/clock-PZo7zyHc.js",
			"/assets/file-text-CsDvkRZR.js",
			"/assets/log-out-BiZnsXah.js",
			"/assets/search-Bj6Qy5X8.js",
			"/assets/shield-check-Dweaf7ZR.js",
			"/assets/user-check-DVfmk_u_.js",
			"/assets/user-plus-GrvK9MMS.js",
			"/assets/users-7Ef-6M2B.js",
			"/assets/zap-DDpT0BMQ.js",
			"/assets/data-store-CzhBQGbm.js",
			"/assets/badge-RSaSxcBk.js",
			"/assets/input-CAssVG3s.js",
			"/assets/label-BIblf2us.js"
		]
	},
	"/auth": {
		filePath: "C:/job-portal-application-main/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-eeCUfS66.js",
			"/assets/useNavigate-BtH586Ug.js",
			"/assets/button-BNkNxccP.js",
			"/assets/createLucideIcon-Brgs3nTD.js",
			"/assets/arrow-left-Ddvb8HXX.js",
			"/assets/building-2-CWEOzFke.js",
			"/assets/check-JSUsLmOq.js",
			"/assets/eye-CBwm70VB.js",
			"/assets/mail-9nUxl_ZT.js",
			"/assets/phone-rYyVmMFj.js",
			"/assets/rotate-ccw-D_ys2TUj.js",
			"/assets/user-plus-GrvK9MMS.js",
			"/assets/user-DagIsUW9.js",
			"/assets/x-sJ3yILvj.js",
			"/assets/Brand-De_SMchX.js",
			"/assets/data-store-CzhBQGbm.js",
			"/assets/label-BIblf2us.js"
		]
	},
	"/categories": {
		filePath: "C:/job-portal-application-main/src/routes/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-BYR0QX9W.js",
			"/assets/createLucideIcon-Brgs3nTD.js",
			"/assets/arrow-left-Ddvb8HXX.js",
			"/assets/arrow-right-uAPemfR5.js",
			"/assets/building-2-CWEOzFke.js",
			"/assets/truck-Dql2JKFs.js",
			"/assets/graduation-cap-DD8JSVVD.js",
			"/assets/hard-hat-Dd6xDfkE.js",
			"/assets/stethoscope-B38NEPBB.js",
			"/assets/PublicFooter-Dsli6k48.js",
			"/assets/search-Bj6Qy5X8.js",
			"/assets/sparkles-CxhP7C1G.js",
			"/assets/sprout-KvFHPYkf.js",
			"/assets/trending-up-DqLtUAOe.js",
			"/assets/user-plus-GrvK9MMS.js",
			"/assets/wrench-BcZ39l3P.js",
			"/assets/input-CAssVG3s.js",
			"/assets/PublicHeader-H7KAn3ea.js"
		]
	},
	"/contact": {
		filePath: "C:/job-portal-application-main/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-BapHh_zj.js",
			"/assets/useNavigate-BtH586Ug.js",
			"/assets/button-BNkNxccP.js",
			"/assets/circle-check-D_8zmU9y.js",
			"/assets/PublicFooter-Dsli6k48.js",
			"/assets/mail-9nUxl_ZT.js",
			"/assets/map-pin-GJxW2fih.js",
			"/assets/message-square-MzaxXqv4.js",
			"/assets/phone-rYyVmMFj.js",
			"/assets/send-D3RbLbo5.js",
			"/assets/sparkles-CxhP7C1G.js",
			"/assets/data-store-CzhBQGbm.js",
			"/assets/input-CAssVG3s.js",
			"/assets/PublicHeader-H7KAn3ea.js"
		]
	},
	"/dashboard": {
		filePath: "C:/job-portal-application-main/src/routes/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-CEJxaPVO.js",
			"/assets/useNavigate-BtH586Ug.js",
			"/assets/button-BNkNxccP.js",
			"/assets/createLucideIcon-Brgs3nTD.js",
			"/assets/JobCard-BfcWMy0C.js",
			"/assets/bookmark-C4YiboN8.js",
			"/assets/briefcase-e5GQkTn9.js",
			"/assets/chevron-down-C8QmCefx.js",
			"/assets/chevron-right-VpsGz8l4.js",
			"/assets/circle-check-D_8zmU9y.js",
			"/assets/file-text-CsDvkRZR.js",
			"/assets/UserSidebarLayout-Dpb80gTB.js",
			"/assets/mail-9nUxl_ZT.js",
			"/assets/map-pin-GJxW2fih.js",
			"/assets/phone-rYyVmMFj.js",
			"/assets/save-NxwpO_YA.js",
			"/assets/search-Bj6Qy5X8.js",
			"/assets/settings-DEfUL0QO.js",
			"/assets/trending-up-DqLtUAOe.js",
			"/assets/user-DagIsUW9.js",
			"/assets/x-sJ3yILvj.js",
			"/assets/data-store-CzhBQGbm.js",
			"/assets/input-CAssVG3s.js"
		]
	},
	"/faq": {
		filePath: "C:/job-portal-application-main/src/routes/faq.tsx",
		children: void 0,
		preloads: [
			"/assets/faq-CtfmD6Ri.js",
			"/assets/button-BNkNxccP.js",
			"/assets/createLucideIcon-Brgs3nTD.js",
			"/assets/briefcase-e5GQkTn9.js",
			"/assets/building-2-CWEOzFke.js",
			"/assets/chevron-down-C8QmCefx.js",
			"/assets/hard-hat-Dd6xDfkE.js",
			"/assets/PublicFooter-Dsli6k48.js",
			"/assets/message-square-MzaxXqv4.js",
			"/assets/search-Bj6Qy5X8.js",
			"/assets/user-check-DVfmk_u_.js",
			"/assets/input-CAssVG3s.js",
			"/assets/PublicHeader-H7KAn3ea.js"
		]
	},
	"/home": {
		filePath: "C:/job-portal-application-main/src/routes/home.tsx",
		children: void 0,
		preloads: [
			"/assets/home-CCoHKGv4.js",
			"/assets/useNavigate-BtH586Ug.js",
			"/assets/button-BNkNxccP.js",
			"/assets/createLucideIcon-Brgs3nTD.js",
			"/assets/arrow-right-uAPemfR5.js",
			"/assets/bookmark-C4YiboN8.js",
			"/assets/briefcase-e5GQkTn9.js",
			"/assets/building-2-CWEOzFke.js",
			"/assets/circle-check-D_8zmU9y.js",
			"/assets/heart-pulse-BOoDkIGJ.js",
			"/assets/truck-Dql2JKFs.js",
			"/assets/globe-DiKjLfTe.js",
			"/assets/graduation-cap-DD8JSVVD.js",
			"/assets/hard-hat-Dd6xDfkE.js",
			"/assets/heart-handshake-Dtx-8-Ja.js",
			"/assets/stethoscope-B38NEPBB.js",
			"/assets/PublicFooter-Dsli6k48.js",
			"/assets/layout-grid-DyzMv5-_.js",
			"/assets/map-pin-GJxW2fih.js",
			"/assets/search-Bj6Qy5X8.js",
			"/assets/shield-check-Dweaf7ZR.js",
			"/assets/sparkles-CxhP7C1G.js",
			"/assets/trending-up-DqLtUAOe.js",
			"/assets/users-7Ef-6M2B.js",
			"/assets/wallet-CcMraxWe.js",
			"/assets/wrench-BcZ39l3P.js",
			"/assets/zap-DDpT0BMQ.js",
			"/assets/data-store-CzhBQGbm.js",
			"/assets/input-CAssVG3s.js",
			"/assets/PublicHeader-H7KAn3ea.js",
			"/assets/career-team-DHTUSRpW.js"
		]
	},
	"/reset-password": {
		filePath: "C:/job-portal-application-main/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-DYHK-Wz3.js",
			"/assets/button-BNkNxccP.js",
			"/assets/Brand-De_SMchX.js",
			"/assets/input-CAssVG3s.js",
			"/assets/label-BIblf2us.js"
		]
	},
	"/select-language": {
		filePath: "C:/job-portal-application-main/src/routes/select-language.tsx",
		children: void 0,
		preloads: [
			"/assets/select-language-DpSIFNMk.js",
			"/assets/useNavigate-BtH586Ug.js",
			"/assets/button-BNkNxccP.js",
			"/assets/check-JSUsLmOq.js",
			"/assets/Brand-De_SMchX.js"
		]
	},
	"/superadmin": {
		filePath: "C:/job-portal-application-main/src/routes/superadmin.tsx",
		children: void 0,
		preloads: [
			"/assets/superadmin-h23LZ_Yh.js",
			"/assets/useNavigate-BtH586Ug.js",
			"/assets/button-BNkNxccP.js",
			"/assets/createLucideIcon-Brgs3nTD.js",
			"/assets/LanguageSwitcher-DvfCbxX7.js",
			"/assets/briefcase-e5GQkTn9.js",
			"/assets/building-2-CWEOzFke.js",
			"/assets/check-JSUsLmOq.js",
			"/assets/chevron-down-C8QmCefx.js",
			"/assets/chevron-up-DGiHRlei.js",
			"/assets/circle-check-D_8zmU9y.js",
			"/assets/clock-PZo7zyHc.js",
			"/assets/eye-CBwm70VB.js",
			"/assets/file-text-CsDvkRZR.js",
			"/assets/globe-DiKjLfTe.js",
			"/assets/log-out-BiZnsXah.js",
			"/assets/mail-9nUxl_ZT.js",
			"/assets/map-pin-GJxW2fih.js",
			"/assets/phone-rYyVmMFj.js",
			"/assets/search-Bj6Qy5X8.js",
			"/assets/settings-DEfUL0QO.js",
			"/assets/user-check-DVfmk_u_.js",
			"/assets/users-7Ef-6M2B.js",
			"/assets/x-sJ3yILvj.js",
			"/assets/data-store-CzhBQGbm.js"
		]
	},
	"/_authenticated/applications": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/applications.tsx",
		children: void 0,
		preloads: ["/assets/applications-B1OWvpzi.js", "/assets/Dashboards-CSitGD1X.js"]
	},
	"/_authenticated/control": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.tsx",
		children: [
			"/_authenticated/control/employers",
			"/_authenticated/control/jobs",
			"/_authenticated/control/languages",
			"/_authenticated/control/reports",
			"/_authenticated/control/salary",
			"/_authenticated/control/settings",
			"/_authenticated/control/users"
		],
		preloads: ["/assets/control-Bpw9WdwJ.js", "/assets/Dashboards-CSitGD1X.js"]
	},
	"/_authenticated/employer": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.tsx",
		children: [
			"/_authenticated/employer/applicants",
			"/_authenticated/employer/employees",
			"/_authenticated/employer/jobs",
			"/_authenticated/employer/reports",
			"/_authenticated/employer/salary"
		],
		preloads: ["/assets/employer-e-Ql_kHA.js", "/assets/Dashboards-CSitGD1X.js"]
	},
	"/_authenticated/messages": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/messages.tsx",
		children: void 0,
		preloads: [
			"/assets/messages-Bpon2nng.js",
			"/assets/button-BNkNxccP.js",
			"/assets/badge-check-Ir6mc501.js",
			"/assets/PublicFooter-Dsli6k48.js",
			"/assets/phone-rYyVmMFj.js",
			"/assets/search-Bj6Qy5X8.js",
			"/assets/send-D3RbLbo5.js",
			"/assets/input-CAssVG3s.js",
			"/assets/PublicHeader-H7KAn3ea.js"
		]
	},
	"/_authenticated/notifications": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/notifications.tsx",
		children: void 0,
		preloads: ["/assets/notifications-DsGLY_2J.js", "/assets/Dashboards-CSitGD1X.js"]
	},
	"/_authenticated/post-job": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/post-job.tsx",
		children: void 0,
		preloads: [
			"/assets/post-job-B8x5gYnV.js",
			"/assets/useNavigate-BtH586Ug.js",
			"/assets/button-BNkNxccP.js",
			"/assets/briefcase-e5GQkTn9.js",
			"/assets/building-2-CWEOzFke.js",
			"/assets/eye-CBwm70VB.js",
			"/assets/file-text-CsDvkRZR.js",
			"/assets/PublicFooter-Dsli6k48.js",
			"/assets/save-NxwpO_YA.js",
			"/assets/send-D3RbLbo5.js",
			"/assets/wallet-CcMraxWe.js",
			"/assets/x-sJ3yILvj.js",
			"/assets/data-store-CzhBQGbm.js",
			"/assets/badge-RSaSxcBk.js",
			"/assets/input-CAssVG3s.js",
			"/assets/PublicHeader-H7KAn3ea.js"
		]
	},
	"/_authenticated/profile": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/profile.tsx",
		children: void 0,
		preloads: ["/assets/profile-BXCtrLcl.js", "/assets/Dashboards-CSitGD1X.js"]
	},
	"/_authenticated/salary": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/salary.tsx",
		children: void 0,
		preloads: ["/assets/salary-CAPWdMCW.js", "/assets/Dashboards-CSitGD1X.js"]
	},
	"/company/$companyId": {
		filePath: "C:/job-portal-application-main/src/routes/company.$companyId.tsx",
		children: void 0,
		preloads: [
			"/assets/company._companyId-C1bSBQQf.js",
			"/assets/useParams-3NdHqM2e.js",
			"/assets/button-BNkNxccP.js",
			"/assets/arrow-left-Ddvb8HXX.js",
			"/assets/JobCard-BfcWMy0C.js",
			"/assets/briefcase-e5GQkTn9.js",
			"/assets/building-2-CWEOzFke.js",
			"/assets/circle-check-D_8zmU9y.js",
			"/assets/PublicFooter-Dsli6k48.js",
			"/assets/map-pin-GJxW2fih.js",
			"/assets/share-2-Cm5D5QEz.js",
			"/assets/shield-check-Dweaf7ZR.js",
			"/assets/star-D_V3pO2r.js",
			"/assets/users-7Ef-6M2B.js",
			"/assets/PublicHeader-H7KAn3ea.js"
		]
	},
	"/jobs/$jobId": {
		filePath: "C:/job-portal-application-main/src/routes/jobs.$jobId.tsx",
		children: void 0,
		preloads: [
			"/assets/jobs._jobId-Bw_BomkI.js",
			"/assets/useParams-3NdHqM2e.js",
			"/assets/button-BNkNxccP.js",
			"/assets/createLucideIcon-Brgs3nTD.js",
			"/assets/arrow-left-Ddvb8HXX.js",
			"/assets/JobCard-BfcWMy0C.js",
			"/assets/bookmark-C4YiboN8.js",
			"/assets/briefcase-e5GQkTn9.js",
			"/assets/building-2-CWEOzFke.js",
			"/assets/circle-check-D_8zmU9y.js",
			"/assets/heart-pulse-BOoDkIGJ.js",
			"/assets/PublicFooter-Dsli6k48.js",
			"/assets/map-pin-GJxW2fih.js",
			"/assets/send-D3RbLbo5.js",
			"/assets/share-2-Cm5D5QEz.js",
			"/assets/user-DagIsUW9.js",
			"/assets/wallet-CcMraxWe.js",
			"/assets/x-sJ3yILvj.js",
			"/assets/data-store-CzhBQGbm.js",
			"/assets/badge-RSaSxcBk.js",
			"/assets/PublicHeader-H7KAn3ea.js"
		]
	},
	"/workers/$workerId": {
		filePath: "C:/job-portal-application-main/src/routes/workers.$workerId.tsx",
		children: void 0,
		preloads: [
			"/assets/workers._workerId-DKKXFNOY.js",
			"/assets/useParams-3NdHqM2e.js",
			"/assets/button-BNkNxccP.js",
			"/assets/badge-check-Ir6mc501.js",
			"/assets/circle-check-D_8zmU9y.js",
			"/assets/PublicFooter-Dsli6k48.js",
			"/assets/map-pin-GJxW2fih.js",
			"/assets/WorkerCard-DH6W7Y2y.js",
			"/assets/share-2-Cm5D5QEz.js",
			"/assets/user-DagIsUW9.js",
			"/assets/x-sJ3yILvj.js",
			"/assets/badge-RSaSxcBk.js",
			"/assets/PublicHeader-H7KAn3ea.js"
		]
	},
	"/jobs/": {
		filePath: "C:/job-portal-application-main/src/routes/jobs.index.tsx",
		children: void 0,
		preloads: [
			"/assets/jobs.index-CHGE_Rh6.js",
			"/assets/button-BNkNxccP.js",
			"/assets/createLucideIcon-Brgs3nTD.js",
			"/assets/arrow-left-Ddvb8HXX.js",
			"/assets/JobCard-BfcWMy0C.js",
			"/assets/briefcase-e5GQkTn9.js",
			"/assets/chevron-down-C8QmCefx.js",
			"/assets/truck-Dql2JKFs.js",
			"/assets/graduation-cap-DD8JSVVD.js",
			"/assets/hard-hat-Dd6xDfkE.js",
			"/assets/stethoscope-B38NEPBB.js",
			"/assets/UserSidebarLayout-Dpb80gTB.js",
			"/assets/PublicFooter-Dsli6k48.js",
			"/assets/layout-grid-DyzMv5-_.js",
			"/assets/map-pin-GJxW2fih.js",
			"/assets/rotate-ccw-D_ys2TUj.js",
			"/assets/search-Bj6Qy5X8.js",
			"/assets/shield-check-Dweaf7ZR.js",
			"/assets/sliders-horizontal-s3qp2fgD.js",
			"/assets/trending-up-DqLtUAOe.js",
			"/assets/wrench-BcZ39l3P.js",
			"/assets/x-sJ3yILvj.js",
			"/assets/data-store-CzhBQGbm.js",
			"/assets/input-CAssVG3s.js",
			"/assets/PublicHeader-H7KAn3ea.js"
		]
	},
	"/workers/": {
		filePath: "C:/job-portal-application-main/src/routes/workers.index.tsx",
		children: void 0,
		preloads: [
			"/assets/workers.index-CtJZPJPq.js",
			"/assets/button-BNkNxccP.js",
			"/assets/createLucideIcon-Brgs3nTD.js",
			"/assets/badge-check-Ir6mc501.js",
			"/assets/PublicFooter-Dsli6k48.js",
			"/assets/map-pin-GJxW2fih.js",
			"/assets/WorkerCard-DH6W7Y2y.js",
			"/assets/rotate-ccw-D_ys2TUj.js",
			"/assets/search-Bj6Qy5X8.js",
			"/assets/sliders-horizontal-s3qp2fgD.js",
			"/assets/users-7Ef-6M2B.js",
			"/assets/x-sJ3yILvj.js",
			"/assets/badge-RSaSxcBk.js",
			"/assets/input-CAssVG3s.js",
			"/assets/PublicHeader-H7KAn3ea.js"
		]
	},
	"/_authenticated/control/employers": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.employers.tsx",
		children: void 0,
		preloads: ["/assets/control.employers-DByduXV7.js"]
	},
	"/_authenticated/control/jobs": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.jobs.tsx",
		children: void 0,
		preloads: ["/assets/control.jobs-9KXUX8nL.js"]
	},
	"/_authenticated/control/languages": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.languages.tsx",
		children: void 0,
		preloads: ["/assets/control.languages-YDvx5avf.js"]
	},
	"/_authenticated/control/reports": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.reports.tsx",
		children: void 0,
		preloads: ["/assets/control.reports-DqIhC9iS.js"]
	},
	"/_authenticated/control/salary": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.salary.tsx",
		children: void 0,
		preloads: ["/assets/control.salary-B8mUfVWt.js"]
	},
	"/_authenticated/control/settings": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.settings.tsx",
		children: void 0,
		preloads: ["/assets/control.settings-CdFdpzNH.js"]
	},
	"/_authenticated/control/users": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.users.tsx",
		children: void 0,
		preloads: ["/assets/control.users-Bs9ybiUd.js"]
	},
	"/_authenticated/employer/applicants": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.applicants.tsx",
		children: void 0,
		preloads: ["/assets/employer.applicants-BocGdGRw.js"]
	},
	"/_authenticated/employer/employees": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.employees.tsx",
		children: void 0,
		preloads: ["/assets/employer.employees-DIiM1yc_.js"]
	},
	"/_authenticated/employer/jobs": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.jobs.tsx",
		children: void 0,
		preloads: ["/assets/employer.jobs-gYfNUVwe.js"]
	},
	"/_authenticated/employer/reports": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.reports.tsx",
		children: void 0,
		preloads: ["/assets/employer.reports-CFLNnc2S.js"]
	},
	"/_authenticated/employer/salary": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.salary.tsx",
		children: void 0,
		preloads: ["/assets/employer.salary-BgDEvCWZ.js"]
	}
} });
//#endregion
export { tsrStartManifest };
