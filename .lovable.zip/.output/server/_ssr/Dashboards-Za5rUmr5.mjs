import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n, i as languages } from "./i18n-CEAlH7ip.mjs";
import { t as Button } from "./button--9UiOy7A.mjs";
import { _ as useNavigate, g as Link, l as useLocation } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Brand } from "./Brand-CAHKvNmJ.mjs";
import { t as dataStore } from "./data-store-BCcScpg-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { A as Search, Bt as Building2, Ft as ChevronDown, Ht as BriefcaseBusiness, It as Check, K as LogOut, Kt as Bell, Lt as ChartColumn, O as Settings, Q as LayoutDashboard, Rt as CalendarCheck2, St as Earth, U as Menu, Xt as ArrowRight, Zt as ArrowLeft, d as UserCheck, ft as Globe, gt as FileText, h as Trash2, l as UserRound, m as TrendingUp, o as WalletCards, r as X, s as Users } from "../_libs/lucide-react.mjs";
import { t as Badge } from "./badge-DRaMiws1.mjs";
import { t as StatCard } from "./Stats-BJplhY8l.mjs";
import { t as Input } from "./input-CZUnWUIa.mjs";
import { a as CartesianGrid, i as Area, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as AreaChart } from "../_libs/recharts+[...].mjs";
import { t as LanguageSwitcher } from "./LanguageSwitcher-hdjW2Vd1.mjs";
import { n as JobCard } from "./JobCard-B_QpStMo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Dashboards-Za5rUmr5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LanguageGate() {
	const { lang, setLang, t } = useI18n();
	const navigate = useNavigate();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [step, setStep] = (0, import_react.useState)("language");
	const [selectedLang, setSelectedLang] = (0, import_react.useState)(lang);
	(0, import_react.useEffect)(() => {
		if (!window.localStorage.getItem("karyam-onboarding-done")) setOpen(true);
		const handler = () => {
			setStep("language");
			setOpen(true);
		};
		window.addEventListener("karyam-open-gate", handler);
		return () => window.removeEventListener("karyam-open-gate", handler);
	}, []);
	if (!open) return null;
	const proceedToRole = () => {
		setLang(selectedLang);
		setStep("role");
	};
	const handleSelectRole = (role) => {
		window.localStorage.setItem("karyam-role", role);
		window.localStorage.setItem("karyam-onboarding-done", "true");
		setOpen(false);
		if (role === "admin") navigate({ to: "/employer" });
		else navigate({ to: "/" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-[100] flex items-center justify-center overflow-y-auto bg-primary/95 text-primary-foreground backdrop-blur-md",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "language-pattern min-h-screen w-full px-4 py-10 sm:py-16 flex items-center justify-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-4xl text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto mb-4 flex justify-center text-3xl font-black tracking-tight",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-white",
							children: "REAL"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "bg-[#FFC400] text-[#082F63] px-2 py-0.5 rounded-md font-extrabold shadow-sm ml-1.5",
							children: "JOB"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-bold uppercase tracking-widest text-accent",
						children: "Job Portal • कार्याम"
					}),
					step === "language" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-4xl font-semibold sm:text-5xl",
							children: t("chooseLanguage")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm sm:text-base text-primary-foreground/75 max-w-xl mx-auto",
							children: t("languageSubtitle")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4",
							children: languages.map((item) => {
								const active = selectedLang === item.code;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => {
										setSelectedLang(item.code);
										setLang(item.code);
									},
									className: `language-card transition-all duration-200 ${active ? "language-card-active shadow-xl ring-2 ring-accent" : "hover:border-primary-foreground/40"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "absolute right-3 top-3 grid size-5 place-items-center rounded-full border border-current",
											children: active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3 text-accent" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "font-display text-2xl",
											children: item.native
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-2 text-xs opacity-75",
											children: item.name
										})
									]
								}, item.code);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10 flex flex-wrap justify-center gap-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: proceedToRole,
								size: "lg",
								variant: "champagne",
								className: "min-w-48 text-base font-semibold shadow-lg gap-2",
								children: [
									t("continue"),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })
								]
							})
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-4xl font-semibold sm:text-5xl",
							children: t("selectRole")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm sm:text-base text-primary-foreground/75 max-w-xl mx-auto",
							children: t("roleSubtitle")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-10 grid gap-6 sm:grid-cols-2 max-w-3xl mx-auto text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								onClick: () => handleSelectRole("user"),
								className: "group relative cursor-pointer overflow-hidden rounded-2xl border border-primary-foreground/20 bg-primary-foreground/10 p-7 transition-all duration-300 hover:-translate-y-1 hover:border-accent hover:bg-primary-foreground/15 hover:shadow-2xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "grid size-12 place-items-center rounded-xl bg-accent text-accent-foreground shadow-md",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "size-6" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full bg-accent/20 px-3 py-1 text-xs font-bold text-accent uppercase",
											children: "User"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-6 font-display text-2xl font-bold text-primary-foreground",
										children: t("jobSeeker")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-6 text-primary-foreground/70",
										children: t("jobSeekerDesc")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-6 flex items-center font-semibold text-accent group-hover:underline text-sm gap-2",
										children: [
											t("viewWebsite"),
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								onClick: () => handleSelectRole("admin"),
								className: "group relative cursor-pointer overflow-hidden rounded-2xl border border-primary-foreground/20 bg-primary-foreground/10 p-7 transition-all duration-300 hover:-translate-y-1 hover:border-accent hover:bg-primary-foreground/15 hover:shadow-2xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "grid size-12 place-items-center rounded-xl bg-accent text-accent-foreground shadow-md",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-6" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full bg-accent/20 px-3 py-1 text-xs font-bold text-accent uppercase",
											children: "Admin"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-6 font-display text-2xl font-bold text-primary-foreground",
										children: t("jobProvider")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-6 text-primary-foreground/70",
										children: t("jobProviderDesc")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-6 flex items-center font-semibold text-accent group-hover:underline text-sm gap-2",
										children: [
											t("viewDashboard"),
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })
										]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10 flex justify-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => setStep("language"),
								variant: "outline",
								size: "sm",
								className: "border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }),
									" ",
									t("backToLanguage")
								]
							})
						})
					] })
				]
			})
		})
	});
}
var menus = {
	user: [
		{
			label: "Dashboard",
			icon: LayoutDashboard,
			to: "/dashboard"
		},
		{
			label: "Jobs",
			icon: BriefcaseBusiness,
			to: "/jobs"
		},
		{
			label: "Applications",
			icon: FileText,
			to: "/applications"
		},
		{
			label: "E-Salary",
			icon: WalletCards,
			to: "/salary"
		},
		{
			label: "Notifications",
			icon: Bell,
			to: "/notifications"
		},
		{
			label: "Profile",
			icon: Users,
			to: "/profile"
		}
	],
	admin: [
		{
			label: "Dashboard",
			icon: LayoutDashboard,
			to: "/employer"
		},
		{
			label: "Jobs",
			icon: BriefcaseBusiness,
			to: "/employer/jobs"
		},
		{
			label: "Applicants",
			icon: Users,
			to: "/employer/applicants"
		},
		{
			label: "Employees",
			icon: Building2,
			to: "/employer/employees"
		},
		{
			label: "E-Salary",
			icon: WalletCards,
			to: "/employer/salary"
		},
		{
			label: "Reports",
			icon: ChartColumn,
			to: "/employer/reports"
		}
	],
	super: [
		{
			label: "Dashboard",
			icon: LayoutDashboard,
			to: "/control"
		},
		{
			label: "Users",
			icon: Users,
			to: "/control/users"
		},
		{
			label: "Employers",
			icon: Building2,
			to: "/control/employers"
		},
		{
			label: "Jobs",
			icon: BriefcaseBusiness,
			to: "/control/jobs"
		},
		{
			label: "E-Salary",
			icon: WalletCards,
			to: "/control/salary"
		},
		{
			label: "Reports",
			icon: ChartColumn,
			to: "/control/reports"
		},
		{
			label: "Languages",
			icon: Earth,
			to: "/control/languages"
		},
		{
			label: "Settings",
			icon: Settings,
			to: "/control/settings"
		}
	]
};
function AppShell({ role, title, eyebrow, children }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const path = useLocation().pathname;
	useNavigate();
	const { t } = useI18n();
	const signOut = () => {
		window.localStorage.removeItem("realjob-user");
		dataStore.setCurrentUser(null);
		window.location.href = "/";
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageGate, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: `fixed inset-y-0 left-0 z-50 w-64 border-r border-sidebar-border bg-sidebar p-4 transition-transform lg:translate-x-0 ${open ? "translate-x-0" : "-translate-x-full"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							className: "lg:hidden",
							onClick: () => setOpen(false),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "my-7 rounded-md bg-primary px-4 py-3 text-primary-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-bold uppercase text-primary-foreground/65",
							children: role === "admin" ? "Employer Admin" : role === "super" ? "Super Admin" : "User Portal"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm font-semibold",
							children: role === "user" ? "My Career" : role === "admin" ? "Nexa Systems" : "Platform Control"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "space-y-1",
						children: menus[role].map((item) => {
							const active = path === item.to;
							const translationKey = {
								Dashboard: "dashboard",
								Jobs: "jobs",
								Applications: "applications",
								"E-Salary": "dashboard",
								Notifications: "notifications",
								Profile: "profile",
								Applicants: "applicants",
								Employees: "employees",
								Reports: "reports",
								Users: "users",
								Employers: "employers",
								Languages: "chooseLanguage",
								Settings: "settings"
							}[item.label];
							const displayLabel = translationKey ? t(translationKey) : item.label;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								className: `flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium transition ${active ? "bg-sidebar-accent text-primary" : "text-sidebar-foreground hover:bg-secondary"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: `size-4 ${active ? "text-accent-foreground" : ""}` }), displayLabel]
							}, item.to);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute bottom-4 left-4 right-4 space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							size: "sm",
							className: "w-full justify-start text-xs font-semibold gap-2 border-border",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "size-3.5 text-accent" }), t("viewWebsite")]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: signOut,
							className: "flex w-full items-center gap-3 rounded-md px-3 py-2 text-sm text-muted-foreground hover:bg-secondary",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), t("logout")]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:pl-64",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-30 flex h-18 items-center justify-between border-b border-border bg-background/95 px-4 backdrop-blur sm:px-7",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							className: "lg:hidden",
							onClick: () => setOpen(true),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [eyebrow && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-bold uppercase text-accent-foreground",
							children: eyebrow
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-xl font-semibold sm:text-2xl",
							children: title
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "ghost",
								size: "sm",
								className: "hidden sm:inline-flex text-xs font-semibold",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/",
									children: t("viewWebsite")
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageSwitcher, {
									label: t("languageLabel"),
									showCurrent: true
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "outline",
								"aria-label": "Notifications",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "ghost",
								className: "gap-2 px-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-8 place-items-center rounded-full bg-primary text-xs text-primary-foreground",
									children: "RJ"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "hidden size-3 sm:block" })]
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "p-4 pb-24 sm:p-7",
					children
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-40 flex justify-around border-t border-border bg-card px-2 py-2 lg:hidden",
				children: menus[role].slice(0, 5).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: item.to,
					className: `flex min-w-14 flex-col items-center gap-1 text-[10px] ${path === item.to ? "text-primary" : "text-muted-foreground"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-5" }), item.label]
				}, item.to))
			})
		]
	});
}
var chart = [
	{
		m: "Apr",
		a: 48,
		b: 18
	},
	{
		m: "May",
		a: 62,
		b: 27
	},
	{
		m: "Jun",
		a: 56,
		b: 31
	},
	{
		m: "Jul",
		a: 82,
		b: 39
	},
	{
		m: "Aug",
		a: 91,
		b: 47
	},
	{
		m: "Sep",
		a: 118,
		b: 58
	}
];
function SeekerDashboard() {
	const currentUser = dataStore.getCurrentUser();
	const seekerId = currentUser?.email || "candidate@realjob.com";
	const userApps = dataStore.getJobSeekerApplications(seekerId);
	const recommended = dataStore.getRecommendedJobs([
		"React",
		"Civil",
		"Mechanical"
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		role: "user",
		eyebrow: `Welcome, ${currentUser?.fullName || "Candidate"}`,
		title: "Your Career Dashboard",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg bg-primary p-6 text-primary-foreground sm:p-8 shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-bold uppercase text-accent",
						children: "Discover your next move"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-display text-3xl font-black",
						children: "Find your next opportunity"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex gap-2 rounded-md bg-primary-foreground p-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "ml-2 mt-3 size-4 text-muted-foreground" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Job title, skill or company",
								className: "h-10 border-0 text-foreground shadow-none"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/jobs",
									children: "Search"
								})
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-4 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "My Applications",
						value: userApps.length.toString(),
						change: "Real-time status tracking",
						icon: FileText
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Profile Views",
						value: "86",
						change: "18% this month",
						icon: TrendingUp
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Active Interviews",
						value: userApps.filter((a) => a.status === "Interview").length.toString(),
						change: "Scheduled by HR",
						icon: CalendarCheck2
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-7 grid gap-7 xl:grid-cols-[1fr_320px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl font-black text-[#10233F]",
						children: "Recommended for you"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "link",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/jobs",
							children: "View all"
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-4",
					children: recommended.slice(0, 3).map((j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JobCard, { job: {
						id: j.id,
						title: j.title,
						company: j.company,
						location: j.location,
						salary: j.salary,
						experience: j.experience,
						type: j.jobType || j.type || "Full Time",
						workMode: j.workMode || "On-site",
						posted: j.postedAgo || j.posted || "Recently",
						initials: j.initials || j.company?.slice(0, 2).toUpperCase() || "CO",
						category: j.category,
						featured: j.featured,
						openings: j.vacancies
					} }, j.id))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-border bg-card p-5 shadow-2xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-lg font-semibold text-[#10233F]",
									children: "Profile strength"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-primary",
									children: "85%"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4 h-2 overflow-hidden rounded-full bg-secondary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-4/5 rounded-full bg-accent" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-sm text-muted-foreground",
								children: "Add two recent trade skills to appear in top employer searches."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								className: "mt-4 w-full border-[#063B78] text-[#063B78] font-bold",
								children: "Complete profile"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "salary-panel p-5 rounded-xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold uppercase text-accent",
								children: "Real Job Verification"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 font-display text-2xl text-primary-foreground font-black",
								children: "100% Direct HR"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-primary-foreground/75 mt-1",
								children: "Zero agency commission · Verified employers"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "champagne",
								className: "mt-5 w-full font-bold",
								children: "View verified status"
							})
						]
					})]
				})]
			})
		]
	});
}
function ApplicationsPage() {
	const currentUser = dataStore.getCurrentUser();
	const seekerId = currentUser?.email || "candidate@realjob.com";
	const [filter, setFilter] = (0, import_react.useState)("All");
	const [apps, setApps] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		let list = dataStore.getJobSeekerApplications(seekerId);
		if (list.length === 0) list = [{
			id: "app-demo1",
			jobId: "job-it1",
			employerId: "TCS",
			jobSeekerId: seekerId,
			candidateName: currentUser?.fullName || "Rutuja Pawar",
			candidateEmail: seekerId,
			candidateMobile: "+91 98220 11223",
			jobTitle: "Full Stack Software Developer",
			companyName: "TCS",
			location: "Pune, Maharashtra",
			salary: "₹50,000–80,000 / month",
			resume: "Rutuja_Pawar_Resume.pdf",
			appliedDate: "Sep 22, 2026",
			status: "Shortlisted"
		}, {
			id: "app-demo2",
			jobId: "job-c1",
			employerId: "L&T Construction",
			jobSeekerId: seekerId,
			candidateName: currentUser?.fullName || "Rutuja Pawar",
			candidateEmail: seekerId,
			candidateMobile: "+91 98220 11223",
			jobTitle: "Civil Engineer - Site Operations",
			companyName: "L&T Construction",
			location: "Mumbai, Maharashtra",
			salary: "₹35,000–50,000 / month",
			resume: "Rutuja_Pawar_Resume.pdf",
			appliedDate: "Sep 19, 2026",
			status: "Applied"
		}];
		setApps(list);
	}, [seekerId]);
	const filteredApps = apps.filter((a) => {
		if (filter === "All") return true;
		return a.status.toLowerCase() === filter.toLowerCase();
	});
	const getStatusBadge = (status) => {
		switch (status) {
			case "Shortlisted": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				className: "bg-amber-500 text-white font-bold",
				children: status
			});
			case "Interview": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				className: "bg-purple-600 text-white font-bold",
				children: status
			});
			case "Selected": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				className: "bg-emerald-600 text-white font-bold",
				children: status
			});
			case "Rejected": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				className: "bg-red-500 text-white font-bold",
				children: status
			});
			case "Viewed": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				className: "bg-blue-600 text-white font-bold",
				children: status
			});
			default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				variant: "secondary",
				className: "font-bold",
				children: status
			});
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		role: "user",
		eyebrow: "Career Progress",
		title: "My Applications",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-2",
			children: [
				"All",
				"Applied",
				"Viewed",
				"Shortlisted",
				"Interview",
				"Selected",
				"Rejected"
			].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => setFilter(x),
				variant: filter === x ? "default" : "outline",
				size: "sm",
				className: "font-bold text-xs",
				children: [
					x,
					" ",
					x === "All" ? `(${apps.length})` : `(${apps.filter((a) => a.status.toLowerCase() === x.toLowerCase()).length})`
				]
			}, x))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 overflow-hidden rounded-2xl border border-border bg-card shadow-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hidden grid-cols-[1.4fr_1fr_0.8fr_0.8fr] gap-4 border-b border-border bg-secondary px-5 py-3 text-xs font-black uppercase text-muted-foreground sm:grid",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Job Role & Title" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Company & Location" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Status" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Applied Date" })
				]
			}), filteredApps.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-8 text-center text-sm font-semibold text-muted-foreground",
				children: [
					"No applications found for category \"",
					filter,
					"\". Apply for jobs to track status here!"
				]
			}) : filteredApps.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 border-b border-border px-5 py-4 last:border-0 sm:grid-cols-[1.4fr_1fr_0.8fr_0.8fr] sm:items-center hover:bg-secondary/30 transition-colors",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "block text-sm text-[#10233F]",
						children: a.jobTitle
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-semibold text-[#125BB5]",
						children: a.salary
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-sm font-semibold text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-[#10233F] font-bold",
							children: a.companyName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs",
							children: a.location
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: getStatusBadge(a.status) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-bold text-muted-foreground",
						children: a.appliedDate
					})
				]
			}, a.id))]
		})]
	});
}
function SalaryPage({ role = "user" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		role,
		eyebrow: "September 2026",
		title: role === "admin" ? "Payroll & E-Salary" : "My E-Salary",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "salary-panel p-6 sm:p-8 rounded-2xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col justify-between gap-6 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-bold uppercase text-accent",
						children: "Net Salary"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-display text-5xl text-primary-foreground font-black",
						children: "₹28,500"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-primary-foreground/60",
						children: "Direct HR Salary Record · September 2026"
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "champagne",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, {}), " Download Payslip"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4",
				children: [
					["Basic Pay", "₹20,000"],
					["Allowances", "₹7,500"],
					["Performance Bonus", "₹2,000"],
					["PF Deductions", "−₹1,000"]
				].map(([a, b]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md bg-primary-foreground/5 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-primary-foreground/55",
						children: a
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "mt-1 block text-primary-foreground",
						children: b
					})]
				}, a))
			})]
		})
	});
}
function EmployerDashboard() {
	const currentUser = dataStore.getCurrentUser();
	const isSuperAdmin = currentUser?.email?.toLowerCase() === "supera@gmail.com" || currentUser?.email?.toLowerCase() === "superadmin";
	const empName = currentUser?.fullName || currentUser?.email || "Employer";
	const empJobs = isSuperAdmin ? dataStore.getAllJobs() : dataStore.getEmployerJobs(empName);
	const empApps = isSuperAdmin ? dataStore.getAllApplications() : dataStore.getEmployerApplications(empName);
	const shortlistedCount = empApps.filter((a) => a.status === "Shortlisted" || a.status === "Selected").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		role: "admin",
		eyebrow: empName,
		title: "Employer Recruitment Overview",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6 bg-white p-5 rounded-2xl border border-border shadow-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "text-xl font-black text-[#10233F]",
					children: [
						"Recruitment Dashboard (",
						empName,
						")"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold text-muted-foreground mt-0.5",
					children: "Manage your posted jobs and candidate applications"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					className: "btn-yellow font-black text-xs px-6 py-3 h-11 shadow-sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/post-job",
						children: "+ Post New Job • नवीन नोकरी पोस्ट करा"
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Active Jobs",
						value: empJobs.length.toString(),
						change: "Live on portal",
						icon: BriefcaseBusiness
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Total Applications",
						value: empApps.length.toString(),
						change: "Direct Candidate Submissions",
						icon: FileText
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Shortlisted",
						value: shortlistedCount.toString(),
						change: "Ready for Interview",
						icon: UserCheck
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Selected Hires",
						value: empApps.filter((a) => a.status === "Selected").length.toString(),
						change: "Hired Candidate Count",
						icon: Users
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-7 grid gap-6 xl:grid-cols-[1.4fr_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-border bg-card p-5 shadow-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-black text-[#10233F]",
						children: "Applications Trend"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-muted-foreground",
						children: "Candidate response metrics"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 h-72",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
								data: chart,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
										id: "burg",
										x1: "0",
										y1: "0",
										x2: "0",
										y2: "1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
											offset: "0%",
											stopColor: "var(--chart-1)",
											stopOpacity: .35
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
											offset: "100%",
											stopColor: "var(--chart-1)",
											stopOpacity: .02
										})]
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
										strokeDasharray: "3 3",
										vertical: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "m",
										axisLine: false,
										tickLine: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
										dataKey: "a",
										stroke: "var(--chart-1)",
										fill: "url(#burg)",
										strokeWidth: 3
									})
								]
							})
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-border bg-card p-5 shadow-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-black text-[#10233F]",
						children: "Hiring Pipeline"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 space-y-5",
						children: [
							[
								"Applied",
								empApps.length,
								"100%"
							],
							[
								"Shortlisted",
								empApps.filter((a) => a.status === "Shortlisted").length,
								"35%"
							],
							[
								"Interview Scheduled",
								empApps.filter((a) => a.status === "Interview").length,
								"15%"
							],
							[
								"Selected",
								empApps.filter((a) => a.status === "Selected").length,
								"5%"
							]
						].map(([a, b, c]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between text-sm font-bold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: a }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: b })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 h-2 rounded-full bg-secondary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full rounded-full bg-primary",
								style: { width: c }
							})
						})] }, a))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecentCandidates, { employerName: empName })
		]
	});
}
function RecentCandidates({ employerName }) {
	const [applications, setApplications] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		const list = dataStore.getEmployerApplications(employerName);
		setApplications(list);
	}, [employerName]);
	const updateStatus = (appId, newStatus) => {
		dataStore.updateApplicationStatus(appId, newStatus);
		setApplications((prev) => prev.map((a) => a.id === appId ? {
			...a,
			status: newStatus
		} : a));
		toast.success(`Application status updated to ${newStatus}!`);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-7 rounded-2xl border border-border bg-card shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between border-b border-border p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-black text-[#10233F]",
				children: "Received Applications for My Jobs"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold text-muted-foreground mt-0.5",
				children: "Manage candidate profiles & update recruitment status"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "outline",
				size: "sm",
				className: "font-bold text-xs",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/employer/applicants",
					children: "View All Candidates"
				})
			})]
		}), applications.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "p-8 text-center text-sm font-semibold text-muted-foreground",
			children: "No candidate applications received yet for your posted jobs."
		}) : applications.map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-4 border-b border-border p-4 last:border-0 hover:bg-secondary/20 transition-colors",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-12 place-items-center rounded-2xl bg-[#063B78] font-black text-white text-base",
					children: app.candidateName.substring(0, 2).toUpperCase()
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-44 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "block text-sm font-black text-[#10233F]",
							children: app.candidateName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-bold text-[#125BB5] block",
							children: app.jobTitle
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-[11px] font-semibold text-muted-foreground",
							children: [
								"📱 ",
								app.candidateMobile,
								" • ✉️ ",
								app.candidateEmail
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-xs font-bold text-muted-foreground",
					children: ["Applied: ", app.appliedDate]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-extrabold text-[#10233F]",
						children: "Status:"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: app.status,
						onChange: (e) => updateStatus(app.id, e.target.value),
						className: "h-9 rounded-xl border border-[#DCE5F0] bg-white px-3 text-xs font-bold text-[#10233F] shadow-2xs focus:ring-1 focus:ring-[#063B78]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "Applied",
								children: "Applied"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "Viewed",
								children: "Viewed"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "Shortlisted",
								children: "Shortlisted"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "Interview",
								children: "Interview"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "Selected",
								children: "Selected"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "Rejected",
								children: "Rejected"
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => toast.info(`Viewing resume: ${app.resume}`),
					className: "font-bold text-xs border-[#063B78] text-[#063B78]",
					children: "📄 Resume"
				})
			]
		}, app.id))]
	});
}
function GenericAdminPage({ role, title }) {
	const currentUser = dataStore.getCurrentUser();
	const empName = currentUser?.companyName || currentUser?.fullName || "L&T Construction";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		role,
		eyebrow: empName,
		title,
		children: title === "Applicants" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecentCandidates, { employerName: empName }) : title === "Manage Jobs" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ManageEmployerJobs, { employerName: empName }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl border border-border bg-card p-10 text-center shadow-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mx-auto grid size-14 place-items-center rounded-2xl bg-[#063B78] text-white",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WalletCards, { className: "size-6" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-5 font-display text-2xl font-black text-[#10233F]",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mx-auto mt-2 max-w-md text-sm font-semibold text-muted-foreground",
					children: [
						"Search, filters, application routing and candidate status management are fully active for ",
						empName,
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					className: "mt-6 btn-yellow font-black text-xs",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/post-job",
						children: "+ Create New Job"
					})
				})
			]
		})
	});
}
function ManageEmployerJobs({ employerName }) {
	const [jobsList, setJobsList] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		setJobsList(dataStore.getEmployerJobs(employerName));
	}, [employerName]);
	const toggleStatus = (jobId, currentStatus) => {
		const newStatus = currentStatus === "Active" ? "Closed" : "Active";
		dataStore.updateJob(jobId, { status: newStatus });
		setJobsList((prev) => prev.map((j) => j.id === jobId ? {
			...j,
			status: newStatus
		} : j));
		toast.success(`Job status updated to ${newStatus}!`);
	};
	const deleteJob = (jobId) => {
		dataStore.deleteJob(jobId);
		setJobsList((prev) => prev.filter((j) => j.id !== jobId));
		toast.success("Job listing removed!");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "text-xl font-black text-[#10233F]",
				children: ["Jobs Posted by ", employerName]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold text-muted-foreground mt-0.5",
				children: "Manage job status, vacancies and postings"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				className: "btn-yellow font-black text-xs",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/post-job",
					children: "+ Post New Job"
				})
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "overflow-hidden rounded-2xl border border-border bg-card shadow-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hidden grid-cols-[1.5fr_1fr_0.8fr_0.8fr_1fr] gap-4 border-b border-border bg-secondary px-5 py-3 text-xs font-black uppercase text-muted-foreground sm:grid",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Job Title & Category" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Location & Salary" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Vacancies" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Status" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Actions" })
				]
			}), jobsList.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-8 text-center text-sm font-semibold text-muted-foreground",
				children: "No jobs posted yet. Click \"+ Post New Job\" to list your open vacancies!"
			}) : jobsList.map((j) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 border-b border-border px-5 py-4 last:border-0 sm:grid-cols-[1.5fr_1fr_0.8fr_0.8fr_1fr] sm:items-center hover:bg-secondary/20 transition-colors",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "block text-sm font-black text-[#10233F]",
						children: j.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-bold text-[#125BB5]",
						children: j.category
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-[#10233F] font-bold",
							children: j.location
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: j.salary
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs font-black text-[#063B78]",
						children: [j.vacancies || 10, " Openings"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						className: j.status === "Active" ? "bg-emerald-600 text-white font-bold" : "bg-gray-500 text-white font-bold",
						children: j.status
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => toggleStatus(j.id, j.status),
							className: "font-bold text-xs",
							children: j.status === "Active" ? "Close Job" : "Reopen Job"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => deleteJob(j.id),
							className: "text-red-600 hover:text-red-700 hover:bg-red-50 p-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
						})]
					})
				]
			}, j.id))]
		})]
	});
}
//#endregion
export { SeekerDashboard as a, SalaryPage as i, EmployerDashboard as n, GenericAdminPage as r, ApplicationsPage as t };
