globalThis.__nitro_main__ = import.meta.url;
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.svg": {
		"type": "image/svg+xml",
		"etag": "\"4bb-8vf8YEvzPt29YAdvIjyYatbeApE\"",
		"mtime": "2026-09-30T05:47:14.491Z",
		"size": 1211,
		"path": "../public/favicon.svg"
	},
	"/assets/applications-CRUHJzqP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4c-TvLrRvH4l4AXdfo1yGw+P6rxqo8\"",
		"mtime": "2026-10-01T06:30:41.470Z",
		"size": 76,
		"path": "../public/assets/applications-CRUHJzqP.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-09-30T05:47:14.553Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/career-team-CL7SHC2o.jpg": {
		"type": "image/jpeg",
		"etag": "\"267a3-c8mLj67X5QLSyB70hI1wiKgmTTU\"",
		"mtime": "2026-10-01T06:30:41.500Z",
		"size": 157603,
		"path": "../public/assets/career-team-CL7SHC2o.jpg"
	},
	"/assets/about-BGSqbvds.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3182-lIWLNRniS6xOrIbHM9Olu0Hh36M\"",
		"mtime": "2026-10-01T06:30:41.469Z",
		"size": 12674,
		"path": "../public/assets/about-BGSqbvds.js"
	},
	"/assets/categories--uIG9WyT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1895-W7kNx6u4tc1QcTiGfH9xsHreTNM\"",
		"mtime": "2026-10-01T06:30:41.473Z",
		"size": 6293,
		"path": "../public/assets/categories--uIG9WyT.js"
	},
	"/assets/auth-Dgb2iI-d.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2908-60j/bDQjW6H1VyseQdMqcK3fge0\"",
		"mtime": "2026-10-01T06:30:41.471Z",
		"size": 10504,
		"path": "../public/assets/auth-Dgb2iI-d.js"
	},
	"/assets/control.employers-C2ONinmj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ad-yTkTYyyGdfnWdURl7w68Mx20k20\"",
		"mtime": "2026-10-01T06:30:41.475Z",
		"size": 173,
		"path": "../public/assets/control.employers-C2ONinmj.js"
	},
	"/assets/contact-CTy-ushq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"216f-DmOqcIgQgSbLFegI/azImBjtHLs\"",
		"mtime": "2026-10-01T06:30:41.473Z",
		"size": 8559,
		"path": "../public/assets/contact-CTy-ushq.js"
	},
	"/assets/control-o83KZ5F_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b4-gfsjeO3wacuRjAPjoIaKwFBSxbM\"",
		"mtime": "2026-10-01T06:30:41.474Z",
		"size": 180,
		"path": "../public/assets/control-o83KZ5F_.js"
	},
	"/assets/control.jobs-DwgritVh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a8-YsXhtu9yslf18M6NUdZRuhKtD4o\"",
		"mtime": "2026-10-01T06:30:41.475Z",
		"size": 168,
		"path": "../public/assets/control.jobs-DwgritVh.js"
	},
	"/assets/control.languages-q9H2EbsA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ad-xwnWxZ5Lr0vArTje7wpM6BOFTpA\"",
		"mtime": "2026-10-01T06:30:41.476Z",
		"size": 173,
		"path": "../public/assets/control.languages-q9H2EbsA.js"
	},
	"/assets/control.salary-gTot5h2Z.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ac-Jy8w0OapqFb2pfIAQw+eW46mpi4\"",
		"mtime": "2026-10-01T06:30:41.477Z",
		"size": 172,
		"path": "../public/assets/control.salary-gTot5h2Z.js"
	},
	"/assets/button-ChBG2UF1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a04a-O8sCoJerx1GR7auWr7XPf3T+3jk\"",
		"mtime": "2026-10-01T06:30:41.472Z",
		"size": 41034,
		"path": "../public/assets/button-ChBG2UF1.js"
	},
	"/assets/control.settings-DfwJl9dL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ac-TozQKz6X48/GqpPrGb6SuAip8EY\"",
		"mtime": "2026-10-01T06:30:41.477Z",
		"size": 172,
		"path": "../public/assets/control.settings-DfwJl9dL.js"
	},
	"/assets/control.users-BHQxsmR8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a9-JgL9u0NA7YWP3U3Q7N6UreaHKQQ\"",
		"mtime": "2026-10-01T06:30:41.479Z",
		"size": 169,
		"path": "../public/assets/control.users-BHQxsmR8.js"
	},
	"/assets/control.reports-CXmRLfgb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ab-6K1kXetgT30M+XYpwOqcysyXqfk\"",
		"mtime": "2026-10-01T06:30:41.476Z",
		"size": 171,
		"path": "../public/assets/control.reports-CXmRLfgb.js"
	},
	"/assets/createLucideIcon-CbXIaOsE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4a8-Huh7II/4jfsqbsvu6ieixUW5zlw\"",
		"mtime": "2026-10-01T06:30:41.480Z",
		"size": 1192,
		"path": "../public/assets/createLucideIcon-CbXIaOsE.js"
	},
	"/assets/dist-BV5KeWp_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"29d-o8uU3hjw/AQqRwTzo3WfNeZoQ7w\"",
		"mtime": "2026-10-01T06:30:41.481Z",
		"size": 669,
		"path": "../public/assets/dist-BV5KeWp_.js"
	},
	"/assets/dashboard-ePDZhWwG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4c-mdLakXzqy+3LHNnBaxpqXXCGuiM\"",
		"mtime": "2026-10-01T06:30:41.480Z",
		"size": 76,
		"path": "../public/assets/dashboard-ePDZhWwG.js"
	},
	"/logo.png": {
		"type": "image/png",
		"etag": "\"aaa85-ID2XIrvLtsa3ALzbSjAZObUHs70\"",
		"mtime": "2026-09-30T05:47:14.532Z",
		"size": 699013,
		"path": "../public/logo.png"
	},
	"/office_desk_bg.png": {
		"type": "image/png",
		"etag": "\"aa3e2-SIGji47l6fCbKCmT29kY8orfS24\"",
		"mtime": "2026-10-01T05:18:20.481Z",
		"size": 697314,
		"path": "../public/office_desk_bg.png"
	},
	"/assets/employer-BvY2n3-S.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4c-k3cyuSwpexVlr39vDuHafEMWAcY\"",
		"mtime": "2026-10-01T06:30:41.481Z",
		"size": 76,
		"path": "../public/assets/employer-BvY2n3-S.js"
	},
	"/assets/employer.applicants-BQyWEjRO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae-MwRTCvYoTwI9/umxjQ84yQWspSE\"",
		"mtime": "2026-10-01T06:30:41.482Z",
		"size": 174,
		"path": "../public/assets/employer.applicants-BQyWEjRO.js"
	},
	"/assets/Dashboards-Dw14TnK8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ddaf-D4NVaWzAOaNWTtpN7Zem1zddGSY\"",
		"mtime": "2026-10-01T06:30:41.467Z",
		"size": 122287,
		"path": "../public/assets/Dashboards-Dw14TnK8.js"
	},
	"/assets/employer.employees-CZVKCP7W.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ad-O469mzkYSO9M58blohDSe2uH9nE\"",
		"mtime": "2026-10-01T06:30:41.483Z",
		"size": 173,
		"path": "../public/assets/employer.employees-CZVKCP7W.js"
	},
	"/assets/employer.jobs-DMLQmyRo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"af-THQKyvDVRduOQVRl54bj49vURvg\"",
		"mtime": "2026-10-01T06:30:41.483Z",
		"size": 175,
		"path": "../public/assets/employer.jobs-DMLQmyRo.js"
	},
	"/assets/employer.reports-D_Gv_jyw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ab-xXVJyO7Vb+Uj4FvprqCT+lnijWQ\"",
		"mtime": "2026-10-01T06:30:41.484Z",
		"size": 171,
		"path": "../public/assets/employer.reports-D_Gv_jyw.js"
	},
	"/assets/employer.salary-Dzs6trGH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9b-uqnP3PJbtU8fvnq/nP1sg2LwaIQ\"",
		"mtime": "2026-10-01T06:30:41.485Z",
		"size": 155,
		"path": "../public/assets/employer.salary-Dzs6trGH.js"
	},
	"/assets/eye-BoSgHQ9W.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"100-+yc7wNht+YXfUIvIvTOpGjMdX+4\"",
		"mtime": "2026-10-01T06:30:41.486Z",
		"size": 256,
		"path": "../public/assets/eye-BoSgHQ9W.js"
	},
	"/assets/label-CRb_nHOk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2ab-sGtBKgX+aGzQqoHj/l3HBIWH7dA\"",
		"mtime": "2026-10-01T06:30:41.487Z",
		"size": 683,
		"path": "../public/assets/label-CRb_nHOk.js"
	},
	"/assets/matchContext-CwTwuMgb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8b-5uQkLd//TPYpA2IEIEcyb20Qzx8\"",
		"mtime": "2026-10-01T06:30:41.488Z",
		"size": 139,
		"path": "../public/assets/matchContext-CwTwuMgb.js"
	},
	"/assets/notifications-CY2ygTiN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b1-m+h7sl38fDLLI3Lltm1QGek2bn8\"",
		"mtime": "2026-10-01T06:30:41.489Z",
		"size": 177,
		"path": "../public/assets/notifications-CY2ygTiN.js"
	},
	"/assets/Match-CVRpd2l3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bddb-HU4mT98rw7oSOCtQZR6/RdXeEKQ\"",
		"mtime": "2026-10-01T06:30:41.468Z",
		"size": 48603,
		"path": "../public/assets/Match-CVRpd2l3.js"
	},
	"/assets/messages-BikKGSVh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b53-vOKtCguK+yoOXEF/eyTflQYqHjI\"",
		"mtime": "2026-10-01T06:30:41.488Z",
		"size": 6995,
		"path": "../public/assets/messages-BikKGSVh.js"
	},
	"/assets/phone-DbWY5LC3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"142-xZvGdrspFWnwUmkdfhCU+CrPbWo\"",
		"mtime": "2026-10-01T06:30:41.490Z",
		"size": 322,
		"path": "../public/assets/phone-DbWY5LC3.js"
	},
	"/assets/post-job-UO49aIw5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"66b3-fr83l4UJR0q4lmDhSsUvZo2Ye0M\"",
		"mtime": "2026-10-01T06:30:41.490Z",
		"size": 26291,
		"path": "../public/assets/post-job-UO49aIw5.js"
	},
	"/assets/redirect-1Dss4sOM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"216-AhfiXwQqYdLrM+uQAOtPHfIddmI\"",
		"mtime": "2026-10-01T06:30:41.492Z",
		"size": 534,
		"path": "../public/assets/redirect-1Dss4sOM.js"
	},
	"/assets/profile-B7W-LykZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ab-ZpOl/KomZbIEmBuJ2aUYtzPu0Fg\"",
		"mtime": "2026-10-01T06:30:41.491Z",
		"size": 171,
		"path": "../public/assets/profile-B7W-LykZ.js"
	},
	"/assets/salary-B6E0mpWm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8f-Y0xaMuy0E+9hRVYr69puO0k46rw\"",
		"mtime": "2026-10-01T06:30:41.495Z",
		"size": 143,
		"path": "../public/assets/salary-B6E0mpWm.js"
	},
	"/assets/reset-password-CV924Df_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5af-YmnNxv+sRb0KohXLWTPh7bYno24\"",
		"mtime": "2026-10-01T06:30:41.493Z",
		"size": 1455,
		"path": "../public/assets/reset-password-CV924Df_.js"
	},
	"/assets/select-language-Cx47M2US.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8ef-v2RHF2X+KT01POapvH/vhmGgeWg\"",
		"mtime": "2026-10-01T06:30:41.496Z",
		"size": 2287,
		"path": "../public/assets/select-language-Cx47M2US.js"
	},
	"/assets/route-BcD8ecfk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8a-ItMUJkUQ2TYMzLx2ed1z8hEW3Xk\"",
		"mtime": "2026-10-01T06:30:41.494Z",
		"size": 138,
		"path": "../public/assets/route-BcD8ecfk.js"
	},
	"/assets/user-plus-B6ITgSTl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"136-VUuJ84RgC18ge4T0ZiX6BZNS3rg\"",
		"mtime": "2026-10-01T06:30:41.498Z",
		"size": 310,
		"path": "../public/assets/user-plus-B6ITgSTl.js"
	},
	"/assets/useStore-BSq4-GUT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6d89-fAmtZQftFTPpU3KyKxUrpuzx+p0\"",
		"mtime": "2026-10-01T06:30:41.497Z",
		"size": 28041,
		"path": "../public/assets/useStore-BSq4-GUT.js"
	},
	"/assets/styles-C409cjex.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1d991-19oCZNE1Hdi/eVTM6lQLEAJDs+s\"",
		"mtime": "2026-10-01T06:30:41.500Z",
		"size": 121233,
		"path": "../public/assets/styles-C409cjex.css"
	},
	"/assets/index-BTDZWWHo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12af63-QWeCjO+J4Usue5BIgdzgw/Q+2Gw\"",
		"mtime": "2026-10-01T06:30:41.466Z",
		"size": 1224547,
		"path": "../public/assets/index-BTDZWWHo.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_9pO3Yx = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_9pO3Yx
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
