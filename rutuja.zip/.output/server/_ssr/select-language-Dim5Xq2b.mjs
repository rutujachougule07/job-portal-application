import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as stringType, t as objectType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/select-language-Dim5Xq2b.js
var $$splitComponentImporter = () => import("./select-language-B6KTAF5D.mjs");
var Route = createFileRoute("/select-language")({
	validateSearch: objectType({ redirectTo: stringType().optional().catch("/home") }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
