import { n as EmployerDashboard } from "./Dashboards-Bp9jvLIp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/employer-Dg94airc.js
var SplitComponent = EmployerDashboard;
//#endregion
export { SplitComponent as component };
