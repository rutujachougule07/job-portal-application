import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n, r as getCategoryTitle } from "./i18n-CEAlH7ip.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as QrCode, G as Mail, Nt as ChevronUp, Pt as ChevronRight, Z as Linkedin, f as Twitter, n as Youtube, rt as Instagram } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/PublicFooter-zsmeitx6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PublicFooter() {
	const { t, n, lang } = useI18n();
	const [email, setEmail] = (0, import_react.useState)("");
	const [subscribed, setSubscribed] = (0, import_react.useState)(false);
	const handleSubscribe = (e) => {
		e.preventDefault();
		if (email.trim()) {
			setSubscribed(true);
			setEmail("");
			setTimeout(() => setSubscribed(false), 4e3);
		}
	};
	const scrollToTop = () => {
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "relative bg-[#082F63] text-slate-200 overflow-hidden font-sans border-t border-[#125BB5]/40",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-transparent via-[#FFC400] to-transparent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto max-w-7xl px-4 pt-14 pb-10 sm:px-6 lg:px-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 gap-8 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-[1.3fr_0.8fr_0.8fr_0.8fr_0.8fr_1.5fr] items-start",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/",
									className: "inline-flex items-center gap-3 group",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "/logo.png",
										alt: "REAL JOB Logo",
										className: "h-20 object-contain bg-white/95 p-2 rounded-xl shadow-md transition-transform group-hover:scale-105"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs leading-relaxed text-slate-300 pr-2",
									children: "Right Person • Right Job • Right Opportunity — Connecting Workers and Employers"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center gap-2.5 pt-1",
									children: [
										{
											icon: Linkedin,
											label: "LinkedIn",
											href: "#"
										},
										{
											icon: Instagram,
											label: "Instagram",
											href: "#"
										},
										{
											icon: Youtube,
											label: "YouTube",
											href: "#"
										},
										{
											icon: Twitter,
											label: "X (Twitter)",
											href: "#"
										}
									].map(({ icon: Icon, label, href }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href,
										"aria-label": label,
										className: "grid size-8 place-items-center rounded-full border border-white/20 bg-white/10 text-white hover:border-[#FFC400] hover:bg-[#FFC400] hover:text-[#082F63] transition-all duration-200",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3.5" })
									}, label))
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-black text-white tracking-wide",
								children: "I Want a Job"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-1.5 h-[2px] w-8 bg-[#FFC400] rounded-full mb-4" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-2 text-xs font-semibold text-slate-300",
								children: [
									{
										label: "Find Jobs",
										to: "/jobs"
									},
									{
										label: "My Applications",
										to: "/auth"
									},
									{
										label: "My Profile",
										to: "/auth"
									},
									{
										label: "About Us",
										to: "/about"
									},
									{
										label: "FAQ",
										to: "/faq"
									}
								].map(({ label, to }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to,
									className: "inline-flex items-center gap-1 hover:text-[#FFC400] hover:translate-x-1 transition-all duration-150",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-3 text-[#FFC400] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
								}) }, label))
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-black text-white tracking-wide",
								children: "I Need Workers"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-1.5 h-[2px] w-8 bg-[#FFC400] rounded-full mb-4" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-2 text-xs font-semibold text-slate-300",
								children: [
									{
										label: "Hire Talent",
										to: "/auth"
									},
									{
										label: "Search Workers",
										to: "/workers"
									},
									{
										label: "View Profiles",
										to: "/workers"
									},
									{
										label: "Contact Us",
										to: "/contact"
									},
									{
										label: "Register",
										to: "/auth"
									}
								].map(({ label, to }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to,
									className: "inline-flex items-center gap-1 hover:text-[#FFC400] hover:translate-x-1 transition-all duration-150",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-3 text-[#FFC400] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
								}) }, label))
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-black text-white tracking-wide",
								children: "Categories"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-1.5 h-[2px] w-8 bg-[#FFC400] rounded-full mb-4" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-2 text-xs font-semibold text-slate-300",
								children: [
									{
										id: "factory-workers",
										to: "/jobs"
									},
									{
										id: "construction-workers",
										to: "/jobs"
									},
									{
										id: "technical-staff",
										to: "/jobs"
									},
									{
										id: "logistics-drivers",
										to: "/jobs"
									},
									{
										id: "electricians",
										to: "/jobs"
									},
									{
										id: "security",
										to: "/jobs"
									}
								].map(({ id, to }) => {
									const label = getCategoryTitle(id, "en");
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to,
										className: "inline-flex items-center gap-1 hover:text-[#FFC400] hover:translate-x-1 transition-all duration-150",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-3 text-[#FFC400] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
									}) }, id);
								})
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-black text-white tracking-wide",
								children: "REAL JOB"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-1.5 h-[2px] w-8 bg-[#FFC400] rounded-full mb-4" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-2 text-xs font-semibold text-slate-300",
								children: [
									{
										label: "About Us",
										to: "/about"
									},
									{
										label: "Contact Us",
										to: "/contact"
									},
									{
										label: "FAQ",
										to: "/faq"
									}
								].map(({ label, to }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to,
									className: "inline-flex items-center gap-1 hover:text-[#FFC400] hover:translate-x-1 transition-all duration-150",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-3 text-[#FFC400] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
								}) }, label))
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:border-l lg:border-white/10 lg:pl-6 space-y-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-lg font-black text-white tracking-wide",
									children: "Download the REAL JOB App"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1.5 text-xs font-medium text-slate-300",
									children: "Find jobs from your mobile and talk directly to employers."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: handleSubscribe,
									className: "mt-3.5 flex items-center rounded-xl border border-white/20 bg-white/10 p-1 focus-within:border-[#FFC400] transition-all",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative flex-1 flex items-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "ml-3 size-4 text-slate-300 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "email",
											required: true,
											placeholder: "Email or Mobile No.",
											value: email,
											onChange: (e) => setEmail(e.target.value),
											className: "w-full h-9 bg-transparent px-3 text-xs text-white placeholder-slate-300 focus:outline-none"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "submit",
										className: "h-9 px-4 rounded-lg bg-[#FFC400] text-[#082F63] font-black text-xs transition-colors shrink-0 shadow-sm hover:bg-[#FFD21F]",
										children: subscribed ? "..." : "Continue"
									})]
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3 rounded-xl border border-white/15 bg-white/5 flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, { className: "size-10 text-[#FFC400] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-black text-white block",
									children: "REAL JOB Mobile App"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-bold text-slate-300",
									children: "Google Play & App Store"
								})] })]
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-t border-white/10 bg-[#063B78] py-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-4 text-xs font-bold text-slate-300 sm:flex-row sm:px-6 lg:px-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-center sm:text-left",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "© 2026 REAL JOB. All rights reserved." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden text-slate-400 sm:inline",
								children: "|"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Find Workers | Get Jobs" })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1.5",
							children: [
								"Made with ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[#FFC400]",
									children: "💛"
								}),
								" in India."
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: scrollToTop,
							"aria-label": "Scroll to top",
							className: "grid size-8 place-items-center rounded-full bg-[#FFC400] text-[#082F63] transition-all shadow-md hover:scale-105 font-black",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-4 stroke-[3]" })
						})]
					})]
				})
			})
		]
	});
}
//#endregion
export { PublicFooter as t };
