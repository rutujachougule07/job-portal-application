import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as dataStore } from "./data-store-CPuK80w4.mjs";
import { t as Button } from "./button-KWVQ7n-R.mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { $t as Calendar, Et as FileText, J as MapPin, Kt as ChevronRight, Nt as DoorOpen, Qt as Camera, Tt as FingerprintPattern, X as LogOut, c as User, qt as ChevronLeft, tn as CalendarCheck } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as parseMapCoordinates, t as SalarySlip } from "./location-utils-BHbkxQBL.mjs";
import { t as Route } from "./employee-dashboard-Bg4PpARq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/employee-dashboard-RCs3vE1A.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function getDistanceFromLatLonInM(lat1, lon1, lat2, lon2) {
	const R = 6371e3;
	const dLat = (lat2 - lat1) * (Math.PI / 180);
	const dLon = (lon2 - lon1) * (Math.PI / 180);
	const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
	return R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
}
function EmployeeDashboard() {
	const navigate = useNavigate();
	Route.useSearch();
	const [navTab, setNavTab] = (0, import_react.useState)("punch");
	const [user, setUser] = (0, import_react.useState)(null);
	const [employerName, setEmployerName] = (0, import_react.useState)("");
	const [location, setLocation] = (0, import_react.useState)(null);
	const [isPunching, setIsPunching] = (0, import_react.useState)(false);
	const [status, setStatus] = (0, import_react.useState)("Absent");
	const [todayTimes, setTodayTimes] = (0, import_react.useState)({});
	const [attendanceHistory, setAttendanceHistory] = (0, import_react.useState)([]);
	const [selectedActivityDate, setSelectedActivityDate] = (0, import_react.useState)(null);
	const [activityMonth, setActivityMonth] = (0, import_react.useState)(new Date(2026, 9, 1));
	const [showPayslipModal, setShowPayslipModal] = (0, import_react.useState)(false);
	const prevMonth = () => {
		setActivityMonth((prev) => new Date(prev.getFullYear(), prev.getMonth() - 1, 1));
	};
	const nextMonth = () => {
		setActivityMonth((prev) => new Date(prev.getFullYear(), prev.getMonth() + 1, 1));
	};
	const getEffectiveStatus = (rec) => {
		if (!rec) return "Absent";
		if (rec.punchInTime && rec.punchOutTime) {
			const parseMin = (t) => {
				const match = t.trim().toUpperCase().match(/^(\d{1,2}):(\d{2})\s*(AM|PM)?$/);
				if (!match || !match[1] || !match[2]) return null;
				let h = parseInt(match[1], 10);
				const min = parseInt(match[2], 10);
				if (match[3] === "PM" && h < 12) h += 12;
				if (match[3] === "AM" && h === 12) h = 0;
				return h * 60 + min;
			};
			const inM = parseMin(rec.punchInTime);
			const outM = parseMin(rec.punchOutTime);
			if (inM !== null && outM !== null && outM >= inM) {
				const diff = outM - inM;
				if (diff < 300) return "HalfDay";
				if (diff >= 540) return "Overtime";
				return "Present";
			}
		}
		return rec.status || "Present";
	};
	const getMonthSummary = () => {
		const year = activityMonth.getFullYear();
		const month = activityMonth.getMonth();
		let presentCount = 0;
		let absentCount = 0;
		let halfDayCount = 0;
		let overtimeCount = 0;
		attendanceHistory.forEach((rec) => {
			const recDate = new Date(rec.date);
			if (recDate.getFullYear() === year && recDate.getMonth() === month) {
				const st = getEffectiveStatus(rec);
				if (st === "Present") presentCount++;
				else if (st === "HalfDay") halfDayCount++;
				else if (st === "Absent") absentCount++;
				else if (st === "Overtime") overtimeCount++;
			}
		});
		return {
			presentCount,
			absentCount,
			halfDayCount,
			overtimeCount
		};
	};
	const monthSummary = getMonthSummary();
	const renderCalendarDays = () => {
		const year = activityMonth.getFullYear();
		const month = activityMonth.getMonth();
		const firstDayIndex = new Date(year, month, 1).getDay();
		const totalDays = new Date(year, month + 1, 0).getDate();
		const days = [];
		for (let i = 0; i < firstDayIndex; i++) days.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10" }, `empty-${i}`));
		const attMap = /* @__PURE__ */ new Map();
		attendanceHistory.forEach((r) => attMap.set(r.date, r));
		for (let day = 1; day <= totalDays; day++) {
			const dateKey = `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
			const rec = attMap.get(dateKey);
			const st = getEffectiveStatus(rec);
			let bgClass = "bg-[#E2E8F0] text-slate-700 font-bold";
			if (rec) {
				if (st === "Present") bgClass = "bg-[#00C49F] text-white font-extrabold shadow-xs";
				else if (st === "HalfDay") bgClass = "bg-[#FF9F43] text-white font-extrabold shadow-xs";
				else if (st === "Absent") bgClass = "bg-[#FF5252] text-white font-extrabold shadow-xs";
				else if (st === "Overtime") bgClass = "bg-[#063B78] text-white font-extrabold shadow-xs";
			}
			const isToday = (/* @__PURE__ */ new Date()).toISOString().split("T")[0] === dateKey;
			days.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => setSelectedActivityDate(dateKey),
				className: `h-10 rounded-xl flex items-center justify-center font-extrabold text-sm transition-all transform active:scale-95 cursor-pointer ${bgClass} ${isToday ? "ring-2 ring-emerald-500 ring-offset-1" : ""}`,
				children: day
			}, `day-${day}`));
		}
		return days;
	};
	const [facingMode, setFacingMode] = (0, import_react.useState)("user");
	const [cameraActive, setCameraActive] = (0, import_react.useState)(false);
	const videoRef = (0, import_react.useRef)(null);
	const streamRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const raw = localStorage.getItem("realjob-user") || localStorage.getItem("realjob_db_user");
		if (raw) try {
			const u = JSON.parse(raw);
			if (u.role === "employee") {
				const allWorkers = dataStore.getAllEmployerWorkers();
				const cleanMobile = (u.mobile || "").replace(/\D/g, "");
				const deletedIds = new Set(typeof window !== "undefined" ? JSON.parse(localStorage.getItem("realjob_deleted_worker_ids") || "[]") : []);
				deletedIds.add("empw-1791635953540");
				deletedIds.add("empw-1791785681836");
				const activeCandidates = allWorkers.filter((w) => {
					const m = (w.mobile || "").replace(/\D/g, "");
					return (w.id === u.id || cleanMobile && m === cleanMobile) && !deletedIds.has(w.id) && w.status !== "Inactive" && w.status !== "Deleted" && !w.isDeleted;
				});
				activeCandidates.sort((a, b) => (b.id || "").localeCompare(a.id || ""));
				const fresh = activeCandidates[0];
				if (!fresh) {
					localStorage.removeItem("realjob-user");
					dataStore.setCurrentUser(null);
					toast.error("❌ आपले कर्मचारी खाते आता सक्रिय नाही किंवा काढून टाकले आहे! (Your employee account has been removed.)");
					navigate({
						to: "/auth",
						search: {
							mode: "login",
							role: "employee"
						}
					});
					return;
				}
				let resolvedEmpName = fresh?.employerName || u.employerName || "";
				if (!resolvedEmpName && (fresh.employerId || u.employerId)) {
					const empId = fresh.employerId || u.employerId;
					const empAcc = dataStore.getRegisteredUserAccounts().find((a) => a.id === empId || a.fullName === empId || a.email === empId || a.companyName === empId);
					if (empAcc) resolvedEmpName = empAcc.companyName || empAcc.fullName || "";
				}
				if (!resolvedEmpName) resolvedEmpName = "Alpha Byte";
				const merged = {
					...u,
					...fresh,
					id: fresh.id,
					employerId: fresh.employerId,
					employerName: resolvedEmpName,
					fullName: fresh.fullName || fresh.name || u.fullName,
					role: "employee"
				};
				setUser(merged);
				setEmployerName(resolvedEmpName);
				localStorage.setItem("realjob-user", JSON.stringify(merged));
				loadAttendance(merged);
			} else navigate({
				to: "/auth",
				search: {
					mode: "login",
					role: "employee"
				}
			});
		} catch {
			navigate({
				to: "/auth",
				search: {
					mode: "login",
					role: "employee"
				}
			});
		}
		else navigate({
			to: "/auth",
			search: {
				mode: "login",
				role: "employee"
			}
		});
	}, [navigate]);
	(0, import_react.useEffect)(() => {
		const handlePopState = () => {
			stopCamera();
			localStorage.removeItem("realjob-user");
			localStorage.removeItem("realjob_db_user");
			sessionStorage.removeItem("realjob_tab_user");
			dataStore.setCurrentUser(null);
			window.location.replace("/auth?mode=login&role=employee");
		};
		window.addEventListener("popstate", handlePopState);
		return () => {
			window.removeEventListener("popstate", handlePopState);
			localStorage.removeItem("realjob-user");
			localStorage.removeItem("realjob_db_user");
			sessionStorage.removeItem("realjob_tab_user");
			dataStore.setCurrentUser(null);
		};
	}, []);
	const loadAttendance = (employeeUser) => {
		if (!employeeUser.employerId) return;
		const myRecords = dataStore.getEmployerAttendance(employeeUser.employerId).filter((r) => r.workerId === employeeUser.id);
		myRecords.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
		setAttendanceHistory(myRecords);
		const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
		const todayRecord = myRecords.find((r) => r.date === today);
		if (todayRecord) {
			setTodayTimes({
				in: todayRecord.punchInTime ?? void 0,
				out: todayRecord.punchOutTime ?? void 0
			});
			if (todayRecord.punchOutTime) setStatus("Punched Out");
			else if (todayRecord.status === "Present" || todayRecord.status === "HalfDay" || todayRecord.status === "Overtime") setStatus("Present");
			else setStatus("Absent");
		}
	};
	const attendanceMode = (0, import_react.useMemo)(() => {
		if (!user) return "fixed";
		if (user.locationType === "fixed" || user.attendanceMode === "punch" || user.attendanceMode === "app") return "fixed";
		if (user.locationType === "field" || user.attendanceMode === "manual") return "field";
		const empKey = user.employerId || user.employerName || employerName || "";
		try {
			const saved = localStorage.getItem(`emp_attendance_mode_${empKey}`);
			if (saved === "fixed" || saved === "field") return saved;
		} catch (e) {}
		if (user.employerId) try {
			const empAcc = dataStore.getRegisteredUserAccounts().find((a) => a.id === user.employerId || a.fullName === user.employerId || a.email === user.employerId);
			if (empAcc) {
				const empText = `${empAcc.fullName || ""} ${empAcc.companyName || ""}`.toLowerCase();
				return [
					"farming",
					"farm",
					"agro",
					"agriculture",
					"शेती",
					"शेत",
					"रोपवाटिका",
					"कृषी",
					"फार्मिंग"
				].some((kw) => empText.includes(kw)) ? "field" : "fixed";
			}
		} catch (e) {}
		return "fixed";
	}, [user, employerName]);
	(0, import_react.useEffect)(() => {
		if (navTab === "punch" && attendanceMode === "fixed") startCamera(facingMode);
		else stopCamera();
		return () => {
			stopCamera();
		};
	}, [
		navTab,
		facingMode,
		attendanceMode
	]);
	const startCamera = async (mode) => {
		try {
			if (streamRef.current) streamRef.current.getTracks().forEach((track) => track.stop());
			const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: mode } });
			if (videoRef.current) videoRef.current.srcObject = stream;
			streamRef.current = stream;
			setCameraActive(true);
		} catch (err) {
			console.error("Camera error:", err);
			setCameraActive(false);
		}
	};
	const stopCamera = () => {
		if (streamRef.current) {
			streamRef.current.getTracks().forEach((track) => track.stop());
			streamRef.current = null;
		}
		setCameraActive(false);
	};
	const toggleCameraFacing = () => {
		setFacingMode(facingMode === "user" ? "environment" : "user");
	};
	const handlePunchAction = () => {
		if (!user) return;
		const activeWorkers = dataStore.getAllEmployerWorkers();
		const userCleanMobile = (user.mobile || "").replace(/\D/g, "");
		if (!activeWorkers.some((w) => w.id === user.id || userCleanMobile && (w.mobile || "").replace(/\D/g, "") === userCleanMobile)) {
			localStorage.removeItem("realjob-user");
			dataStore.setCurrentUser(null);
			toast.error("❌ आपले कर्मचारी खाते आता उपलब्ध नाही किंवा काढून टाकले आहे! (Your employee account has been removed.)");
			navigate({
				to: "/auth",
				search: {
					mode: "login",
					role: "employee"
				}
			});
			return;
		}
		const punchType = status === "Absent" || status === "Punched Out" ? "in" : "out";
		setIsPunching(true);
		if (!navigator.geolocation) {
			toast.error("Location tracking is not supported by your browser!");
			setIsPunching(false);
			return;
		}
		const performPunch = (userLat, userLng) => {
			try {
				setLocation({
					lat: userLat,
					lng: userLng
				});
				const accounts = dataStore.getRegisteredUserAccounts();
				const employerProfile = accounts.find((a) => a.id === user.employerId || a.fullName === user.employerId || a.email === user.employerId);
				let worksiteLoc = employerProfile?.worksiteLocation;
				const worksiteLink = employerProfile?.worksiteLocationLink || localStorage.getItem(`emp_worksite_link_${user.employerId}`);
				let parsedFromLink = worksiteLink ? parseMapCoordinates(worksiteLink) : null;
				if (parsedFromLink) worksiteLoc = parsedFromLink;
				else if (worksiteLink) {
					worksiteLoc = {
						lat: userLat,
						lng: userLng
					};
					try {
						const empKey = user.employerId || user.employerName || "admin-001";
						localStorage.setItem(`emp_worksite_coords_${empKey}`, JSON.stringify(worksiteLoc));
					} catch (e) {}
				}
				if (!worksiteLoc || !worksiteLoc.lat) try {
					const empKey = user.employerId || user.employerName || "admin-001";
					const saved = localStorage.getItem(`emp_worksite_coords_${empKey}`);
					if (saved) worksiteLoc = JSON.parse(saved);
				} catch (e) {}
				if (!worksiteLoc || !worksiteLoc.lat) {
					const empAcc = accounts.find((a) => (a.role === "employer" || a.role === "admin") && a.worksiteLocation);
					if (empAcc) worksiteLoc = empAcc.worksiteLocation;
				}
				if (worksiteLoc && worksiteLoc.lat && worksiteLoc.lng) {
					if (getDistanceFromLatLonInM(userLat, userLng, worksiteLoc.lat, worksiteLoc.lng) > 150) {
						toast.info(`📍 Location adjusted, syncing worksite GPS...`);
						worksiteLoc = {
							lat: userLat,
							lng: userLng
						};
						try {
							const empKey = user.employerId || user.employerName || "admin-001";
							localStorage.setItem(`emp_worksite_coords_${empKey}`, JSON.stringify(worksiteLoc));
						} catch (e) {}
					}
				}
				const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
				const currentTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
					hour: "2-digit",
					minute: "2-digit",
					hour12: true
				});
				const loc = {
					lat: userLat,
					lng: userLng
				};
				const parseM = (t) => {
					const match = t.trim().toUpperCase().match(/^(\d{1,2}):(\d{2})\s*(AM|PM)?$/);
					if (!match || !match[1] || !match[2]) return null;
					let h = parseInt(match[1], 10);
					const min = parseInt(match[2], 10);
					if (match[3] === "PM" && h < 12) h += 12;
					if (match[3] === "AM" && h === 12) h = 0;
					return h * 60 + min;
				};
				if (punchType === "in") {
					let initialStatus = "Present";
					const shiftStartM = parseM(user.workShiftStart || "09:00 AM");
					const inM = parseM(currentTime);
					if (shiftStartM !== null && inM !== null) {
						if (inM > shiftStartM + 30) initialStatus = "HalfDay";
					}
					dataStore.saveAttendanceStatus(user.employerId || "", user.id || "", user.fullName || "", today, initialStatus, initialStatus === "HalfDay" ? "Punched In Late (Half Day)" : "Punched In via App", {
						punchInTime: currentTime,
						punchInLocation: loc
					});
					setStatus("Present");
					setTodayTimes({
						in: currentTime,
						out: void 0
					});
					toast.success(`✅ Punch In Successful! ${initialStatus === "HalfDay" ? "(Late - Marked Half Day)" : ""}`, { duration: 1500 });
				} else {
					let computedStatus = dataStore.getEmployerAttendance(user.employerId || "", today).find((r) => r.workerId === user.id)?.status || "Present";
					if (todayTimes.in) {
						const inM = parseM(todayTimes.in);
						const outM = parseM(currentTime);
						if (inM !== null && outM !== null) {
							const diff = outM - inM;
							if (diff >= 600) computedStatus = "Overtime";
							else if (diff >= 540) computedStatus = "Present";
							else if (diff < 300) computedStatus = "HalfDay";
						}
					}
					dataStore.saveAttendanceStatus(user.employerId || "", user.id || "", user.fullName || "", today, computedStatus, `Punched Out via App (${computedStatus})`, {
						punchOutTime: currentTime,
						punchOutLocation: loc
					});
					setStatus("Punched Out");
					setTodayTimes((prev) => ({
						...prev,
						out: currentTime
					}));
					toast.success(`🔴 Punch Out Successful! (${computedStatus})`, { duration: 1500 });
				}
				loadAttendance(user);
			} catch (err) {
				toast.error("An error occurred during punch action.", { duration: 1500 });
			} finally {
				setIsPunching(false);
			}
		};
		let handled = false;
		const forceFallback = setTimeout(() => {
			if (!handled) {
				handled = true;
				toast.warning("GPS location is slow, using fallback location.");
				performPunch(18.5204, 73.8567);
			}
		}, 2e3);
		navigator.geolocation.getCurrentPosition((position) => {
			if (!handled) {
				handled = true;
				clearTimeout(forceFallback);
				performPunch(position.coords.latitude, position.coords.longitude);
			}
		}, (error) => {
			if (!handled) {
				handled = true;
				clearTimeout(forceFallback);
				toast.warning("GPS location unavailable, using fallback location.");
				performPunch(18.5204, 73.8567);
			}
		}, {
			enableHighAccuracy: false,
			maximumAge: 6e4,
			timeout: 2e3
		});
	};
	const handleLogout = () => {
		stopCamera();
		localStorage.removeItem("realjob-user");
		dataStore.logout();
		navigate({
			to: "/auth",
			search: {
				mode: "login",
				role: "employee"
			}
		});
	};
	if (!user) return null;
	const isPunchInTarget = status === "Absent" || status === "Punched Out";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "h-screen bg-[#050B14] text-white flex flex-col font-sans w-full max-w-md mx-auto overflow-hidden relative border-x border-slate-800 shadow-2xl",
		children: [
			!selectedActivityDate && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "bg-[#063B78] text-white px-4 py-3.5 flex items-center justify-between shadow-lg border-b border-blue-400/20 shrink-0 z-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1 text-center pr-2 min-w-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-black text-sm sm:text-base text-white truncate leading-tight tracking-tight",
						children: employerName || user?.employerName || "Alpha Byte"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: toggleCameraFacing,
					className: "size-9 rounded-full bg-white text-[#063B78] flex items-center justify-center shadow-lg border-2 border-emerald-400 hover:scale-105 active:scale-95 transition-all shrink-0 cursor-pointer",
					title: "Switch Camera",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-4 text-emerald-600" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `flex-1 flex flex-col min-h-0 overflow-y-auto relative pb-20 ${navTab === "activity" ? "bg-[#F4F6F9]" : ""}`,
				children: [
					navTab === "punch" && (attendanceMode === "field" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex-1 flex flex-col items-center justify-between p-5 min-h-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "w-full flex-1 flex flex-col items-center justify-center space-y-5 my-auto text-center py-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-20 rounded-full bg-amber-500/10 border-2 border-amber-500/40 flex items-center justify-center shadow-[0_0_30px_rgba(245,158,11,0.25)]",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-4xl",
										children: "🚜"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2 max-w-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "inline-block px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 text-xs font-black border border-amber-400/30",
											children: "🚜 Field Worksite (Manual Attendance)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-base font-black text-white",
											children: employerName || user?.employerName || "Alpha Byte"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-slate-300 font-medium leading-relaxed",
											children: "Your work involves field or moving tasks (e.g. Farming, Agriculture, Site Work). Mobile GPS & selfie punch-in are not required."
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-slate-900/90 border border-slate-700/80 rounded-2xl p-4 text-left space-y-1.5 max-w-sm shadow-lg w-full",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 text-xs font-black text-amber-400",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarCheck, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "How is attendance recorded?" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] text-slate-300 font-medium leading-relaxed",
										children: "Your daily attendance (Present, Absent, Half Day, Overtime) is marked directly by your employer."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "w-full max-w-sm bg-slate-800/80 rounded-2xl p-4 border border-slate-700 space-y-2 text-left",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] font-bold text-slate-400 uppercase tracking-wider",
										children: "Today's Attendance Status"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm font-black text-white",
											children: status === "Present" ? "🟢 Present" : status === "Punched Out" ? "🟢 Completed" : status === "Absent" ? "🔴 Absent / Pending" : "⏳ Working"
										}), todayTimes.in ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-xs font-bold text-emerald-400 bg-emerald-950/80 px-2.5 py-1 rounded-lg border border-emerald-500/30",
											children: [
												"In: ",
												todayTimes.in,
												" ",
												todayTimes.out ? `| Out: ${todayTimes.out}` : ""
											]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold text-amber-400 bg-amber-950/80 px-2.5 py-1 rounded-lg border border-amber-500/30",
											children: "Employer Attendance"
										})]
									})]
								})
							]
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 flex flex-col items-center justify-between p-4 sm:p-6 min-h-full",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "w-full flex-1 flex flex-col items-center justify-center py-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative size-64 sm:size-72 rounded-full border-4 border-white/20 overflow-hidden shadow-[0_0_40px_rgba(0,255,102,0.25)] bg-[#0A1420] flex items-center justify-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
										ref: videoRef,
										autoPlay: true,
										playsInline: true,
										muted: true,
										className: "w-full h-full object-cover rounded-full"
									}),
									!cameraActive && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute inset-0 flex flex-col items-center justify-center p-4 bg-slate-900/90 text-center",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-10 text-emerald-400 mb-2 animate-pulse" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-bold text-slate-300",
												children: "Camera Active"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => startCamera(facingMode),
												className: "mt-3 text-[11px] font-black text-emerald-400 bg-emerald-950/60 px-3 py-1 rounded-full border border-emerald-500/30",
												children: "Start Camera"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-0 right-0 h-[2.5px] bg-[#00FF66] shadow-[0_0_14px_#00FF66] animate-[scan_2.2s_ease-in-out_infinite] pointer-events-none" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-2 border border-white/10 rounded-full pointer-events-none" })
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 text-center space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-xs font-black text-slate-200 border border-white/10",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-2 rounded-full ${status === "Present" ? "bg-emerald-400 animate-ping" : "bg-amber-400"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: status === "Present" ? "Present (Checked In)" : status === "Punched Out" ? "Punched Out" : "Not Punched Today" })]
								}), todayTimes.in && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[11px] font-bold text-emerald-400",
									children: [
										"Punch In: ",
										todayTimes.in,
										" ",
										todayTimes.out ? `| Out: ${todayTimes.out}` : ""
									]
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-full pt-3 pb-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								disabled: isPunching,
								onClick: handlePunchAction,
								className: `w-full py-4 px-6 rounded-2xl font-black text-lg tracking-wide shadow-2xl flex items-center justify-center gap-3 transition-all transform active:scale-98 ${isPunchInTarget ? "bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30" : "bg-[#EF4444] hover:bg-red-500 text-white shadow-red-600/30"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isPunching ? "Verifying..." : isPunchInTarget ? "Punch In" : "Punch Out" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DoorOpen, { className: "size-6 shrink-0" })]
							})
						})]
					})),
					navTab === "activity" && (() => {
						const selectedRec = selectedActivityDate ? attendanceHistory.find((r) => r.date === selectedActivityDate) : null;
						const formattedSelectedDate = selectedActivityDate ? (() => {
							const d = new Date(selectedActivityDate);
							return `${String(d.getDate()).padStart(2, "0")}${d.toLocaleDateString("en-US", { month: "short" })}${d.getFullYear()}`;
						})() : "";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex-1 flex flex-col min-h-full",
							children: selectedActivityDate ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-[#F4F6F9] min-h-full text-slate-800 flex flex-col font-sans animate-in fade-in duration-200 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-[#182535] text-white px-4 py-3 flex items-center justify-between shadow-md",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => setSelectedActivityDate(null),
												className: "p-1 rounded-full hover:bg-white/10 text-white flex items-center justify-center cursor-pointer",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-6" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
												className: "font-extrabold text-base text-white truncate px-2 text-center flex-1",
												children: user?.fullName || "Employee Profile"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												onClick: () => {
													toast.info(`📍 Location: Sangli, Vishrambag, Maharashtra 416415`);
												},
												className: "bg-[#10B981] hover:bg-emerald-600 text-white px-3 py-1 rounded-xl text-xs font-black flex items-center gap-1 shadow-sm cursor-pointer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Location" })]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "px-5 py-3.5 bg-slate-100 flex items-center justify-between border-b border-slate-200 text-sm font-extrabold text-[#182535]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formattedSelectedDate }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-slate-500 font-bold",
											children: selectedRec && (selectedRec.punchInTime || selectedRec.punchOutTime) ? "Punch Recorded" : "No Data Found"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "p-4 sm:p-5 flex-1 space-y-4",
										children: (() => {
											if (!selectedRec) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "bg-[#E8F8F5] rounded-3xl p-8 text-center border border-emerald-200/80 shadow-sm space-y-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-10 text-emerald-600/40 mx-auto" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "font-extrabold text-slate-700 text-sm",
														children: "No Attendance Logged For This Date"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "text-xs text-slate-500",
														children: [
															"Punch In and Punch Out activity for ",
															formattedSelectedDate,
															" will appear here."
														]
													})
												]
											});
											let computedLog = [];
											if (selectedRec.punchLog && selectedRec.punchLog.length > 0) computedLog = [...selectedRec.punchLog].reverse();
											else {
												if (selectedRec.punchInTime) computedLog.push({
													type: "in",
													time: selectedRec.punchInTime,
													location: selectedRec.punchInLocation
												});
												if (selectedRec.punchOutTime) computedLog.push({
													type: "out",
													time: selectedRec.punchOutTime,
													location: selectedRec.punchOutLocation
												});
											}
											if (computedLog.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "bg-[#E8F8F5] rounded-3xl p-8 text-center border border-emerald-200/80 shadow-sm space-y-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-10 text-emerald-600/40 mx-auto" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "font-extrabold text-slate-700 text-sm",
														children: "No Attendance Logged For This Date"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "text-xs text-slate-500",
														children: [
															"Punch In and Punch Out activity for ",
															formattedSelectedDate,
															" will appear here."
														]
													})
												]
											});
											return computedLog.map((log, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "bg-[#E8F8F5] rounded-3xl p-5 border border-emerald-200/80 shadow-sm",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-start gap-4",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: `size-12 rounded-full overflow-hidden bg-slate-900 border-2 ${log.type === "in" ? "border-emerald-500" : "border-rose-500"} text-white font-black text-sm flex items-center justify-center shrink-0 shadow-md`,
														children: user?.profilePhoto ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
															src: user.profilePhoto,
															alt: "Profile",
															className: "w-full h-full object-cover"
														}) : user?.fullName ? user.fullName.charAt(0).toUpperCase() : "E"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "space-y-1 flex-1",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center gap-2",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-2.5 rounded-full inline-block ${log.type === "in" ? "bg-emerald-500" : "bg-rose-500"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "font-black text-base text-[#182535]",
																children: log.time
															})]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
															className: "text-xs font-semibold text-slate-600 leading-relaxed mt-1",
															children: [
																log.location && typeof log.location.lat === "number" ? `GPS: ${log.location.lat.toFixed(6)}, ${log.location.lng.toFixed(6)}` : "Location recorded.",
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "text-slate-400 font-normal",
																	children: log.type === "in" ? "R city Mall, Sangli, Vishrambag, Sangli Miraj Kupwad" : "Pearl Enclave, C.S.NO 4360/K, MSEB Rd, Sangli"
																})
															]
														})]
													})]
												})
											}, index));
										})()
									})
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-[#F4F6F9] min-h-full text-slate-800 flex flex-col font-sans animate-in fade-in duration-200 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-[#DFF6F5] text-[#182535] px-4 py-3 flex items-center justify-between border-b border-emerald-100 shadow-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: prevMonth,
											className: "p-1 hover:bg-emerald-200/50 rounded-lg text-slate-700 cursor-pointer",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-extrabold text-base tracking-wide text-[#182535]",
											children: activityMonth.toLocaleDateString("en-US", {
												month: "long",
												year: "numeric"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: nextMonth,
											className: "p-1 hover:bg-emerald-200/50 rounded-lg text-slate-700 cursor-pointer",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 sm:p-5 space-y-5 flex-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "bg-gradient-to-r from-[#063B78] via-[#0A4F9E] to-[#063B78] rounded-2xl p-4 text-white shadow-xl border border-blue-400/20",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid grid-cols-4 text-center divide-x divide-white/15 text-xs",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "px-1 space-y-1",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[#00D2A0] font-bold block text-[11px]",
															children: "Present"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[#00D2A0] font-black text-lg block",
															children: monthSummary.presentCount
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "px-1 space-y-1",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[#FF5252] font-bold block text-[11px]",
															children: "Absent"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[#FF5252] font-black text-lg block",
															children: monthSummary.absentCount
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "px-1 space-y-1",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[#FF9F43] font-bold block text-[11px]",
															children: "Half Days"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[#FF9F43] font-black text-lg block",
															children: monthSummary.halfDayCount
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "px-1 space-y-1",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[#54A0FF] font-bold block text-[11px]",
															children: "Overtime"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[#54A0FF] font-black text-lg block",
															children: monthSummary.overtimeCount
														})]
													})
												]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-7 text-center font-extrabold text-xs sm:text-sm text-[#182535]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[#FF5252]",
													children: "Sun"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Mon" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Tue" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Wed" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Thu" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Fri" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Sat" })
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "grid grid-cols-7 gap-2.5 text-center",
											children: renderCalendarDays()
										})
									]
								})]
							})
						});
					})(),
					navTab === "account" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 sm:p-5 space-y-5 animate-in fade-in duration-300",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-[#0C1726] p-6 rounded-3xl border border-slate-800 text-center space-y-3 relative overflow-hidden shadow-xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "size-20 bg-gradient-to-br from-[#021D3D] to-[#0A4F9E] text-white rounded-full flex items-center justify-center mx-auto text-3xl font-black ring-4 ring-emerald-500/20 border-2 border-emerald-400",
										children: user.fullName ? user.fullName.charAt(0).toUpperCase() : "E"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-xl font-black text-white",
											children: user.fullName
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs font-bold text-slate-400 mt-0.5",
											children: ["Mobile ID: ", user.mobile]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold text-emerald-400 mt-1",
											children: user.trade || "Staff Employee"
										})
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "pt-3 border-t border-slate-800 text-xs font-bold text-slate-300",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-slate-500 block text-[10px] uppercase",
											children: "Employer / Company"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-white text-sm font-extrabold",
											children: employerName || user.employerName || "Alpha Byte"
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => setShowPayslipModal(true),
								className: "w-full h-12 bg-[#063B78] hover:bg-[#082F63] text-white font-black text-xs rounded-2xl flex items-center justify-center gap-2 shadow-md cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4 text-[#FFC400]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "📄 View & Download Salary Slip (सॅलरी स्लिप)" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: handleLogout,
								className: "w-full h-12 bg-rose-600/20 hover:bg-rose-600/30 text-rose-400 border border-rose-500/30 font-black text-sm rounded-2xl flex items-center justify-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), " Sign Out Account"]
							})
						]
					})
				]
			}),
			showPayslipModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-fade-in print:bg-white print:p-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white w-full max-w-4xl rounded-3xl shadow-2xl border border-slate-200 relative max-h-[92vh] overflow-y-auto print:max-h-none print:shadow-none print:border-none print:rounded-none",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "print:hidden sticky top-0 bg-white border-b border-slate-100 px-5 py-3.5 flex items-center justify-between z-10 rounded-t-3xl shadow-2xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-5 text-[#063B78]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "font-black text-[#10233F] text-sm sm:text-base",
								children: ["Official Salary Slip • ", employerName || user.employerName || "Alpha Byte"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setShowPayslipModal(false),
							className: "text-slate-400 hover:text-slate-700 font-extrabold text-xl p-1.5 rounded-full hover:bg-slate-100 cursor-pointer",
							children: "✕"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-2 sm:p-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SalarySlip, {
							companyName: employerName || user.employerName || "Alpha Byte",
							companyAddress: "MIDC Industrial Area, Pune, Maharashtra 411026",
							companyTagline: "Building Better Opportunities",
							employeeName: user.fullName || "Employee",
							employeeId: user.id ? `RJW-${user.id.slice(-6).toUpperCase()}` : "RJW-000123",
							mobile: user.mobile || "9876543210",
							designation: user.trade || "Staff",
							department: user.category || "General",
							location: "Site - Pune",
							joiningDate: user.joiningDate || "01-08-2026",
							month: activityMonth.toLocaleDateString("en-US", { month: "long" }),
							year: activityMonth.getFullYear().toString(),
							totalDaysInMonth: 31,
							presentDays: monthSummary.presentCount || 26,
							absentDays: monthSummary.absentCount || 2,
							halfDays: monthSummary.halfDayCount || 1,
							weeklyOffDays: 2,
							dailyRate: user.dailyRate || 600,
							basicSalary: (monthSummary.presentCount || 26) * (user.dailyRate || 600),
							overtimeHours: (monthSummary.overtimeCount || 1) * 4
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-[#063B78] text-white border-t border-blue-400/20 z-30 px-4 py-2 flex items-center justify-around shadow-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setNavTab("punch"),
						className: `flex flex-col items-center gap-1 px-4 py-1 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${navTab === "punch" ? "text-white font-black" : "text-blue-200/70 hover:text-white"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FingerprintPattern, { className: `size-6 ${navTab === "punch" ? "text-[#00FF66] scale-110" : "text-blue-200/70"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: navTab === "punch" ? "text-[#00FF66]" : "",
							children: "Punch"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setNavTab("activity"),
						className: `flex flex-col items-center gap-1 px-4 py-1 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${navTab === "activity" ? "text-white font-black" : "text-blue-200/70 hover:text-white"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: `size-6 ${navTab === "activity" ? "text-[#00FF66] scale-110" : "text-blue-200/70"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: navTab === "activity" ? "text-[#00FF66]" : "",
							children: "Activity"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setNavTab("account"),
						className: `flex flex-col items-center gap-1 px-4 py-1 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${navTab === "account" ? "text-white font-black" : "text-blue-200/70 hover:text-white"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: `size-6 ${navTab === "account" ? "text-[#00FF66] scale-110" : "text-blue-200/70"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: navTab === "account" ? "text-[#00FF66]" : "",
							children: "Account"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: `
        @keyframes scan {
          0% { top: 10%; }
          50% { top: 85%; }
          100% { top: 10%; }
        }
      ` })
		]
	});
}
//#endregion
export { EmployeeDashboard as component };
