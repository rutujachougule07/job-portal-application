import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n, i as languages } from "./i18n-CEAlH7ip.mjs";
import { t as Button } from "./button--9UiOy7A.mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as LogoIcon } from "./Brand-CAHKvNmJ.mjs";
import { It as Check } from "../_libs/lucide-react.mjs";
import { t as Route } from "./select-language-CheD_KNP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/select-language-Atgt6oFS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SelectLanguagePage() {
	const { lang: currentLang, setLang, t } = useI18n();
	const navigate = useNavigate();
	const { redirectTo } = Route.useSearch();
	const [selectedLang, setSelectedLang] = (0, import_react.useState)(currentLang || "mr");
	const handleContinue = () => {
		setLang(selectedLang);
		navigate({ to: redirectTo || "/home" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-cover bg-center flex items-center justify-center p-4",
		style: { backgroundImage: `url('/office_desk_bg.png')` },
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-black/15 backdrop-blur-[2px] pointer-events-none" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative z-10 w-full max-w-3xl bg-white/80 backdrop-blur-xl rounded-2xl border border-white/80 shadow-2xl px-6 py-6 sm:py-8 sm:px-10 transition-all duration-300",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-center mb-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoIcon, { className: "h-12 sm:h-14 object-contain" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center space-y-1 mb-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-xl sm:text-2xl font-black text-[#0A3B7B] tracking-tight leading-tight",
						children: t("chooseLanguage")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-gray-600 px-2",
						children: t("languageSubtitle")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 sm:grid-cols-4 gap-2.5 mb-6",
					children: languages.map((lang) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setSelectedLang(lang.code),
						className: `relative flex items-center justify-between p-2.5 sm:p-3 rounded-xl border-2 transition-all duration-200 ${selectedLang === lang.code ? "border-[#0A3B7B] bg-[#EBF1F8] shadow-md" : "border-white/60 bg-white/50 hover:bg-white hover:border-[#DCE5F0]"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `text-base sm:text-lg font-bold ${selectedLang === lang.code ? "text-[#0A3B7B]" : "text-gray-900"}`,
								children: lang.native
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs sm:text-sm font-semibold text-gray-500",
								children: lang.name
							})]
						}), selectedLang === lang.code && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "bg-[#0A3B7B] rounded-full p-1 sm:p-1.5 text-white",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3 sm:size-4" })
						})]
					}, lang.code))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: handleContinue,
					className: "w-full bg-[#0A3B7B] hover:bg-[#082F63] text-white font-black text-sm sm:text-base h-12 rounded-xl shadow-lg transition-all active:scale-95",
					children: t("continue")
				})
			]
		})]
	});
}
//#endregion
export { SelectLanguagePage as component };
