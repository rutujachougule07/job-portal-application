import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as dataStore } from "./data-store-CPuK80w4.mjs";
import { a as isVideoMedia, i as getYouTubeEmbedUrl, r as getVideoDurationFromFile, t as Button } from "./button-KWVQ7n-R.mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as Settings, D as ShieldCheck, Dt as Factory, E as Shield, Et as FileText, Ft as Crown, G as Monitor, Gt as ChevronUp, Ht as CircleX, J as MapPin, Jt as ChevronDown, M as Search, O as ShieldAlert, Ot as Eye, R as Plus, S as Sparkles, V as PenLine, Wt as CircleCheck, X as LogOut, Y as Mail, Yt as Check, Zt as ChartColumn, _ as Target, c as User, ct as Key, d as UserPlus, dn as Award, dt as Image$1, et as LoaderCircle, f as UserCheck, fn as AtSign, g as Trash2, gn as Activity, h as TrendingUp, in as Briefcase, kt as EyeOff, ln as Bell, m as Truck, mt as Heart, n as X, nt as Link, o as Video, q as Menu, r as Wrench, rn as Building2, s as Users, t as Zap, ut as IndianRupee, vt as HardHat, xt as Globe, y as Star, yt as Handshake, z as Phone, zt as Clock } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/superadmin-Go08oaKe.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var defaultCompanyPillars = [
	{
		id: "mission",
		title: "Our Mission",
		titleMr: "आमचे ध्येय",
		description: "To provide the right employment opportunity to everyone.",
		descriptionMr: "प्रत्येकाला रोजगाराची योग्य संधी मिळवून देणे.",
		iconName: "Target"
	},
	{
		id: "vision",
		title: "Our Vision",
		titleMr: "आमचे व्हिजन",
		description: "To become the most trusted employment portal in India.",
		descriptionMr: "भारतातील सर्वात विश्वासार्ह रोजगार मंच बनणे.",
		iconName: "Eye"
	},
	{
		id: "values",
		title: "Our Values",
		titleMr: "आमची मूल्ये",
		description: "Trust, transparency, quality, and consistent service.",
		descriptionMr: "विश्वास, पारदर्शकता, गुणवत्ता आणि निरंतर सेवा.",
		iconName: "Users"
	},
	{
		id: "belief",
		title: "Our Belief",
		titleMr: "आमचा विश्वास",
		description: "Right Person\nRight Job\nRight Opportunity",
		descriptionMr: "योग्य व्यक्ती\nयोग्य काम\nयोग्य संधी",
		iconName: "Handshake"
	}
];
var PILLAR_ICONS = {
	Target,
	Eye,
	Users,
	Handshake,
	Star,
	Shield,
	Sparkles,
	TrendingUp,
	Building2,
	Award,
	CheckCircle2: CircleCheck,
	Heart,
	Crown
};
var CATEGORY_ICONS = {
	Factory,
	HardHat,
	Wrench,
	Truck,
	Zap,
	Shield,
	Briefcase,
	Users,
	Monitor,
	Building2,
	Award,
	Star,
	Sparkles
};
function SuperAdminPage() {
	const navigate = useNavigate();
	const [activeTab, setActiveTab] = (0, import_react.useState)("dashboard");
	const [isAuthenticated, setIsAuthenticated] = (0, import_react.useState)(() => {
		if (typeof window !== "undefined") try {
			localStorage.removeItem("realjob_admin_auth");
			return !!sessionStorage.getItem("realjob_admin_auth");
		} catch {}
		return false;
	});
	const [username, setUsername] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [dynamicPackages, setDynamicPackages] = (0, import_react.useState)(() => dataStore.getJobPackages());
	const [packagePurchases, setPackagePurchases] = (0, import_react.useState)(() => dataStore.getAllPackagePurchases());
	const handleSavePackages = () => {
		dataStore.saveJobPackages(dynamicPackages);
		toast.success("✅ Job Packages updated! Employer dashboard now uses your live pricing.");
	};
	const [heroTitle, setHeroTitle] = (0, import_react.useState)("Welcome to the\nREAL JOB Portal!");
	const [heroSubtitle, setHeroSubtitle] = (0, import_react.useState)("Right Person • Right Job • Right Opportunity");
	const [heroImages, setHeroImages] = (0, import_react.useState)([
		"https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80",
		"https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&q=80",
		"https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&q=80"
	]);
	const [videoUploading, setVideoUploading] = (0, import_react.useState)(false);
	const [showVideoUrlModal, setShowVideoUrlModal] = (0, import_react.useState)(false);
	const [videoUrlInput, setVideoUrlInput] = (0, import_react.useState)("");
	const [metrics, setMetrics] = (0, import_react.useState)([
		{
			value: "10,000+",
			label: "Verified Workers"
		},
		{
			value: "5,000+",
			label: "Live Job Openings"
		},
		{
			value: "2,200+",
			label: "Employers"
		},
		{
			value: "0%",
			label: "Zero Commission"
		}
	]);
	const [aboutData, setAboutData] = (0, import_react.useState)({
		image: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&q=80",
		title: "About Our Company",
		description: "REAL JOB is a reliable employment portal that connects job seekers with trusted companies. We focus on creating real opportunities, building successful careers, and supporting growth for individuals and businesses across India."
	});
	const [companyPillars, setCompanyPillars] = (0, import_react.useState)(defaultCompanyPillars);
	const [categories, setCategories] = (0, import_react.useState)([
		{
			label: "Factory Worker",
			iconName: "Factory",
			theme: "blue"
		},
		{
			label: "Construction",
			iconName: "HardHat",
			theme: "yellow"
		},
		{
			label: "Technical Staff",
			iconName: "Wrench",
			theme: "purple"
		},
		{
			label: "Transport & Logistics",
			iconName: "Truck",
			theme: "green"
		},
		{
			label: "Electrician",
			iconName: "Zap",
			theme: "orange"
		},
		{
			label: "Security Guard",
			iconName: "Shield",
			theme: "red"
		},
		{
			label: "Office Staff",
			iconName: "Briefcase",
			theme: "blue"
		}
	]);
	(0, import_react.useEffect)(() => {
		const savedTitle = localStorage.getItem("cms_heroTitle");
		const savedSubtitle = localStorage.getItem("cms_heroSubtitle");
		const savedImages = localStorage.getItem("cms_heroImages");
		const savedMetrics = localStorage.getItem("cms_metrics");
		const savedAbout = localStorage.getItem("cms_aboutData");
		const savedPillars = localStorage.getItem("cms_companyPillars");
		const savedCategories = localStorage.getItem("cms_categories");
		if (savedTitle) setHeroTitle(savedTitle);
		if (savedSubtitle) setHeroSubtitle(savedSubtitle);
		if (savedImages) setHeroImages(JSON.parse(savedImages));
		if (savedMetrics) setMetrics(JSON.parse(savedMetrics));
		if (savedAbout) setAboutData(JSON.parse(savedAbout));
		if (savedPillars) try {
			setCompanyPillars(JSON.parse(savedPillars));
		} catch (e) {}
		if (savedCategories) setCategories(JSON.parse(savedCategories));
		const syncFromCloud = async () => {
			try {
				const { db } = await import("./firebase-irBfmyIj.mjs").then((n) => n.r).then((n) => n.n);
				const { doc, getDoc } = await import("../_libs/firebase.mjs").then((n) => n.n);
				const snap = await getDoc(doc(db, "cms_settings", "landing_page"));
				if (snap.exists()) {
					const data = snap.data();
					if (Array.isArray(data.heroImages) && data.heroImages.length > 0) {
						setHeroImages(data.heroImages);
						localStorage.setItem("cms_heroImages", JSON.stringify(data.heroImages));
					}
					if (data.heroTitle) setHeroTitle(data.heroTitle);
					if (data.heroSubtitle) setHeroSubtitle(data.heroSubtitle);
					if (data.metrics) setMetrics(data.metrics);
					if (data.aboutData) setAboutData(data.aboutData);
					if (data.companyPillars) setCompanyPillars(data.companyPillars);
					if (data.categories) setCategories(data.categories);
				}
			} catch (err) {
				console.warn("Could not sync CMS settings from cloud in superadmin:", err);
			}
		};
		syncFromCloud();
	}, []);
	const [allJobs, setAllJobs] = (0, import_react.useState)([]);
	const [approvalFilter, setApprovalFilter] = (0, import_react.useState)("pending");
	const [allUsers, setAllUsers] = (0, import_react.useState)([]);
	const [allApplications, setAllApplications] = (0, import_react.useState)([]);
	const [userSearchQuery, setUserSearchQuery] = (0, import_react.useState)("");
	const [userRoleFilter, setUserRoleFilter] = (0, import_react.useState)("all");
	const [appSearchQuery, setAppSearchQuery] = (0, import_react.useState)("");
	const [appStatusFilter, setAppStatusFilter] = (0, import_react.useState)("all");
	const [pkgSearchQuery, setPkgSearchQuery] = (0, import_react.useState)("");
	const refreshData = () => {
		setAllJobs(dataStore.getAllJobs());
		setAllUsers(dataStore.getRegisteredUserAccounts());
		setAllApplications(dataStore.getAllApplications());
		setSubAdmins(dataStore.getSubAdmins());
	};
	(0, import_react.useEffect)(() => {
		refreshData();
	}, []);
	const [subAdmins, setSubAdmins] = (0, import_react.useState)(() => dataStore.getSubAdmins());
	const [subAdminSearch, setSubAdminSearch] = (0, import_react.useState)("");
	const [subAdminStatusFilter, setSubAdminStatusFilter] = (0, import_react.useState)("all");
	const [subAdminPermissionFilter, setSubAdminPermissionFilter] = (0, import_react.useState)("all");
	const [isSubAdminModalOpen, setIsSubAdminModalOpen] = (0, import_react.useState)(false);
	const [editingSubAdmin, setEditingSubAdmin] = (0, import_react.useState)(null);
	const [showPasswordMap, setShowPasswordMap] = (0, import_react.useState)({});
	const [mobileSidebarOpen, setMobileSidebarOpen] = (0, import_react.useState)(false);
	const [currentAdminRole, setCurrentAdminRole] = (0, import_react.useState)(() => {
		if (typeof window !== "undefined") try {
			const saved = sessionStorage.getItem("realjob_admin_auth");
			if (saved) return JSON.parse(saved);
		} catch {}
		return { isSuperAdmin: true };
	});
	(0, import_react.useEffect)(() => {
		const handlePopState = () => {
			if (!sessionStorage.getItem("realjob_admin_auth")) setIsAuthenticated(false);
		};
		const handlePageShow = (e) => {
			if (e.persisted) {
				if (!sessionStorage.getItem("realjob_admin_auth")) setIsAuthenticated(false);
			}
		};
		window.addEventListener("popstate", handlePopState);
		window.addEventListener("pageshow", handlePageShow);
		return () => {
			window.removeEventListener("popstate", handlePopState);
			window.removeEventListener("pageshow", handlePageShow);
			try {
				sessionStorage.removeItem("realjob_admin_auth");
				localStorage.removeItem("realjob_admin_auth");
			} catch {}
		};
	}, []);
	const [formData, setFormData] = (0, import_react.useState)({
		fullName: "",
		username: "",
		email: "",
		mobile: "",
		password: "",
		designation: "Operations Sub-Admin",
		permissions: [
			"job-approvals",
			"users-directory",
			"job-applications"
		],
		status: "active"
	});
	const handleOpenAddSubAdmin = () => {
		setEditingSubAdmin(null);
		setFormData({
			fullName: "",
			username: "",
			email: "",
			mobile: "",
			password: "sub" + Math.floor(1e5 + Math.random() * 9e5),
			designation: "Operations Sub-Admin",
			permissions: [
				"job-approvals",
				"users-directory",
				"job-applications",
				"packages",
				"landing-page"
			],
			status: "active"
		});
		setIsSubAdminModalOpen(true);
	};
	const handleOpenEditSubAdmin = (sub) => {
		setEditingSubAdmin(sub);
		setFormData({
			fullName: sub.fullName,
			username: sub.username || sub.email.split("@")[0] || "",
			email: sub.email,
			mobile: sub.mobile,
			password: sub.password || "",
			designation: sub.designation || "Sub-Admin",
			permissions: [
				"job-approvals",
				"users-directory",
				"job-applications",
				"packages",
				"landing-page"
			],
			status: sub.status
		});
		setIsSubAdminModalOpen(true);
	};
	const handleSaveSubAdmin = (e) => {
		e.preventDefault();
		if (!formData.fullName.trim()) {
			toast.error("Please enter sub-admin's full name");
			return;
		}
		if (!formData.email.trim()) {
			toast.error("Please enter a valid email address");
			return;
		}
		if (!formData.password.trim()) {
			toast.error("Please provide a password for the sub-admin");
			return;
		}
		const cleanEmail = formData.email.trim().toLowerCase();
		const cleanUsername = (formData.username || cleanEmail.split("@")[0] || "subadmin").trim().toLowerCase().replace(/\s+/g, "_");
		const fullPermissions = [
			"job-approvals",
			"users-directory",
			"job-applications",
			"packages",
			"landing-page"
		];
		if (editingSubAdmin) {
			dataStore.updateSubAdmin(editingSubAdmin.id, {
				fullName: formData.fullName,
				username: cleanUsername,
				email: cleanEmail,
				mobile: formData.mobile,
				password: formData.password,
				designation: formData.designation,
				permissions: fullPermissions,
				status: editingSubAdmin.status || "active"
			});
			toast.success("✅ Sub-Admin details updated successfully!");
		} else {
			if (subAdmins.some((s) => s.email.toLowerCase() === cleanEmail || s.username && s.username.toLowerCase() === cleanUsername)) {
				toast.error("An admin with this email or username already exists!");
				return;
			}
			dataStore.addSubAdmin({
				fullName: formData.fullName,
				username: cleanUsername,
				email: cleanEmail,
				mobile: formData.mobile,
				password: formData.password,
				designation: formData.designation,
				permissions: fullPermissions,
				status: "active",
				createdBy: "superadmin"
			});
			toast.success(`🎉 Sub-Admin "${formData.fullName}" created! Username: @${cleanUsername} | Password: ${formData.password}`);
		}
		setSubAdmins(dataStore.getSubAdmins());
		setIsSubAdminModalOpen(false);
	};
	const handleDeleteSubAdmin = (id, name) => {
		if (window.confirm(`Are you sure you want to remove Sub-Admin "${name}"?`)) {
			dataStore.deleteSubAdmin(id);
			setSubAdmins(dataStore.getSubAdmins());
			toast.success("🗑️ Sub-Admin removed successfully.");
		}
	};
	const handleToggleSubAdminStatus = (id, name) => {
		const updated = dataStore.toggleSubAdminStatus(id);
		if (updated) {
			setSubAdmins(dataStore.getSubAdmins());
			if (updated.status === "active") toast.success(`🟢 Sub-Admin "${name}" is now Activated!`);
			else toast.warning(`⏸️ Sub-Admin "${name}" is now Suspended!`);
		}
	};
	const filteredSubAdmins = subAdmins.filter((sub) => {
		const q = subAdminSearch.toLowerCase();
		const matchesSearch = sub.fullName.toLowerCase().includes(q) || sub.email.toLowerCase().includes(q) || sub.username && sub.username.toLowerCase().includes(q) || sub.mobile && sub.mobile.includes(q) || sub.designation && sub.designation.toLowerCase().includes(q);
		const matchesStatus = subAdminStatusFilter === "all" || sub.status === subAdminStatusFilter;
		return matchesSearch && matchesStatus;
	});
	const [expandedJobId, setExpandedJobId] = (0, import_react.useState)(null);
	const handleApproveJob = (jobId) => {
		dataStore.updateJobApprovalStatus(jobId, "approved");
		toast.success("✅ Job Approved Successfully! Now live on portal.");
		refreshData();
	};
	const handleRejectJob = (jobId) => {
		dataStore.updateJobApprovalStatus(jobId, "rejected");
		toast.error("❌ Job Posting Rejected.");
		refreshData();
	};
	const handleDeleteJob = (jobId) => {
		dataStore.deleteJob(jobId);
		toast.success("🗑️ Job deleted permanently.");
		refreshData();
	};
	const handleDeleteUser = (userId) => {
		dataStore.deleteRegisteredUser(userId);
		toast.success("🗑️ User account deleted.");
		refreshData();
	};
	const handleDeleteAllUsers = () => {
		if (window.confirm("Are you sure you want to delete ALL registered users?")) {
			dataStore.deleteAllRegisteredUsers();
			toast.success("🗑️ All registered users deleted successfully!");
			refreshData();
		}
	};
	const handleDeleteApplication = (appId) => {
		dataStore.deleteApplication(appId);
		toast.success("🗑️ Application deleted.");
		refreshData();
	};
	const handleDeletePackagePurchase = (txId) => {
		dataStore.deletePackagePurchase(txId);
		setPackagePurchases(dataStore.getAllPackagePurchases());
		toast.success("🗑️ Package purchase transaction deleted!");
	};
	const handleClearPackagePurchases = () => {
		if (window.confirm("Are you sure you want to clear all package purchase history?")) {
			dataStore.clearPackagePurchases();
			setPackagePurchases([]);
			toast.success("🗑️ Package purchase history cleared!");
		}
	};
	const handleClearAllData = () => {
		if (window.confirm("Are you sure you want to remove ALL admin data (Jobs, Applications, Users, Packages)?")) {
			dataStore.clearAllAdminData();
			setPackagePurchases([]);
			toast.success("✅ All admin data removed successfully!");
			refreshData();
		}
	};
	const pendingJobsCount = allJobs.filter((j) => j.approvalStatus === "pending").length;
	const approvedJobsCount = allJobs.filter((j) => j.approvalStatus === "approved" || !j.approvalStatus).length;
	const rejectedJobsCount = allJobs.filter((j) => j.approvalStatus === "rejected").length;
	const displayedJobs = allJobs.filter((j) => {
		if (approvalFilter === "pending") return j.approvalStatus === "pending";
		if (approvalFilter === "approved") return j.approvalStatus === "approved" || !j.approvalStatus;
		if (approvalFilter === "rejected") return j.approvalStatus === "rejected";
		return true;
	});
	const handleImageUpload = (e) => {
		const file = e.target.files?.[0];
		if (file) {
			const reader = new FileReader();
			reader.onloadend = () => {
				const img = new Image();
				img.onload = () => {
					const canvas = document.createElement("canvas");
					const MAX_WIDTH = 800;
					const MAX_HEIGHT = 600;
					let width = img.width;
					let height = img.height;
					if (width > height) {
						if (width > MAX_WIDTH) {
							height *= MAX_WIDTH / width;
							width = MAX_WIDTH;
						}
					} else if (height > MAX_HEIGHT) {
						width *= MAX_HEIGHT / height;
						height = MAX_HEIGHT;
					}
					canvas.width = width;
					canvas.height = height;
					canvas.getContext("2d")?.drawImage(img, 0, 0, width, height);
					const compressedBase64 = canvas.toDataURL("image/webp", .5);
					setHeroImages((prev) => [...prev, compressedBase64]);
				};
				img.src = reader.result;
			};
			reader.readAsDataURL(file);
		}
	};
	const handleVideoUpload = async (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		if (file.size > 157286400) {
			toast.error("Video file is too large! Please upload a clip under 150MB or use a Video URL.");
			return;
		}
		const duration = await getVideoDurationFromFile(file);
		if (duration > 61) {
			toast.error(`❌ व्हिडिओ खूप मोठा आहे (${Math.round(duration)} सेकंद)! व्हिडिओ कमाल १ मिनिट (६० सेकंद) चाच असावा.`);
			if (e.target) e.target.value = "";
			return;
		}
		setVideoUploading(true);
		const toastId = toast.loading("Uploading hero banner video to cloud... Please wait.");
		try {
			try {
				const { uploadFileToFirebaseStorage } = await import("./storage-service-C4LkhGjO.mjs").then((n) => n.t).then((n) => n.t);
				const uploadRes = await uploadFileToFirebaseStorage(file, "hero_media");
				if (uploadRes?.downloadUrl && uploadRes.isFirebaseStorage) {
					setHeroImages((prev) => [...prev, uploadRes.downloadUrl]);
					toast.success("✅ Video uploaded to cloud! Click 'Save Landing Page Settings'.", { id: toastId });
					setVideoUploading(false);
					return;
				}
			} catch (cloudErr) {
				console.warn("Direct Firebase Storage upload failed, trying local save:", cloudErr);
			}
			const reader = new FileReader();
			reader.onloadend = async () => {
				try {
					const dataUrl = reader.result;
					const res = await fetch("/__save_uploaded_file", {
						method: "POST",
						headers: { "Content-Type": "application/json" },
						body: JSON.stringify({
							fileName: file.name,
							dataUrl
						})
					});
					if (res.ok) {
						const data = await res.json();
						if (data?.url) {
							setHeroImages((prev) => [...prev, data.url]);
							toast.success("✅ Video uploaded successfully! Remember to click 'Save Landing Page Settings'.", { id: toastId });
							setVideoUploading(false);
							return;
						}
					}
					if (file.size < 4194304) {
						setHeroImages((prev) => [...prev, dataUrl]);
						toast.success("✅ Video attached! Click 'Save Landing Page Settings'.", { id: toastId });
					} else toast.error("Video couldn't be saved locally. You can use 'Add Video by URL'.", { id: toastId });
				} catch (uploadErr) {
					console.error("Upload error:", uploadErr);
					toast.error("Failed to upload video file.", { id: toastId });
				} finally {
					setVideoUploading(false);
				}
			};
			reader.readAsDataURL(file);
		} catch (err) {
			toast.error("Error reading video file", { id: toastId });
			setVideoUploading(false);
		}
	};
	const handleEditMedia = async (e, index, isVideo) => {
		const file = e.target.files?.[0];
		if (!file) return;
		if (isVideo) {
			const duration = await getVideoDurationFromFile(file);
			if (duration > 61) {
				toast.error(`❌ व्हिडिओ खूप मोठा आहे (${Math.round(duration)} सेकंद)! व्हिडिओ कमाल १ मिनिट (६० सेकंद) चाच असावा.`);
				if (e.target) e.target.value = "";
				return;
			}
			const toastId = toast.loading("Updating video in cloud...");
			try {
				const { uploadFileToFirebaseStorage } = await import("./storage-service-C4LkhGjO.mjs").then((n) => n.t).then((n) => n.t);
				const uploadRes = await uploadFileToFirebaseStorage(file, "hero_media");
				if (uploadRes?.downloadUrl && uploadRes.isFirebaseStorage) {
					setHeroImages((prev) => {
						const copy = [...prev];
						copy[index] = uploadRes.downloadUrl;
						return copy;
					});
					toast.success("✅ Video updated in cloud! Click 'Save Landing Page Settings'.", { id: toastId });
					return;
				}
			} catch (cloudErr) {
				console.warn("Direct Firebase upload error:", cloudErr);
			}
			const reader = new FileReader();
			reader.onloadend = async () => {
				try {
					const dataUrl = reader.result;
					const data = await (await fetch("/__save_uploaded_file", {
						method: "POST",
						headers: { "Content-Type": "application/json" },
						body: JSON.stringify({
							fileName: file.name,
							dataUrl
						})
					})).json();
					if (data?.url) {
						setHeroImages((prev) => {
							const copy = [...prev];
							copy[index] = data.url;
							return copy;
						});
						toast.success("✅ Video updated! Click 'Save Landing Page Settings'.", { id: toastId });
					} else if (file.size < 4194304) {
						setHeroImages((prev) => {
							const copy = [...prev];
							copy[index] = dataUrl;
							return copy;
						});
						toast.success("✅ Video updated! Click 'Save Landing Page Settings'.", { id: toastId });
					}
				} catch {
					toast.error("Failed to update video", { id: toastId });
				}
			};
			reader.readAsDataURL(file);
		} else {
			const reader = new FileReader();
			reader.onloadend = () => {
				const img = new Image();
				img.onload = () => {
					const canvas = document.createElement("canvas");
					const MAX_WIDTH = 800;
					const MAX_HEIGHT = 600;
					let width = img.width;
					let height = img.height;
					if (width > height) {
						if (width > MAX_WIDTH) {
							height *= MAX_WIDTH / width;
							width = MAX_WIDTH;
						}
					} else if (height > MAX_HEIGHT) {
						width *= MAX_HEIGHT / height;
						height = MAX_HEIGHT;
					}
					canvas.width = width;
					canvas.height = height;
					canvas.getContext("2d")?.drawImage(img, 0, 0, width, height);
					const compressedBase64 = canvas.toDataURL("image/webp", .5);
					setHeroImages((prev) => {
						const copy = [...prev];
						copy[index] = compressedBase64;
						return copy;
					});
					toast.success("✅ Image updated! Click 'Save Landing Page Settings'.");
				};
				img.src = reader.result;
			};
			reader.readAsDataURL(file);
		}
	};
	const handleAddVideoUrl = () => {
		if (!videoUrlInput.trim()) {
			toast.error("Please enter a valid video link or YouTube URL.");
			return;
		}
		setHeroImages((prev) => [...prev, videoUrlInput.trim()]);
		setVideoUrlInput("");
		setShowVideoUrlModal(false);
		toast.success("✅ Video URL added! Click 'Save Landing Page Settings'.");
	};
	const handleAboutImageUpload = (e) => {
		const file = e.target.files?.[0];
		if (file) {
			const reader = new FileReader();
			reader.onloadend = () => {
				const img = new Image();
				img.onload = () => {
					const canvas = document.createElement("canvas");
					const MAX_WIDTH = 800;
					const MAX_HEIGHT = 800;
					let width = img.width;
					let height = img.height;
					if (width > height) {
						if (width > MAX_WIDTH) {
							height *= MAX_WIDTH / width;
							width = MAX_WIDTH;
						}
					} else if (height > MAX_HEIGHT) {
						width *= MAX_HEIGHT / height;
						height = MAX_HEIGHT;
					}
					canvas.width = width;
					canvas.height = height;
					canvas.getContext("2d")?.drawImage(img, 0, 0, width, height);
					const compressedBase64 = canvas.toDataURL("image/jpeg", .7);
					setAboutData((prev) => ({
						...prev,
						image: compressedBase64
					}));
				};
				img.src = reader.result;
			};
			reader.readAsDataURL(file);
		}
	};
	const handleSaveCMS = async () => {
		try {
			localStorage.setItem("cms_heroTitle", heroTitle);
			localStorage.setItem("cms_heroSubtitle", heroSubtitle);
			localStorage.setItem("cms_metrics", JSON.stringify(metrics));
			localStorage.setItem("cms_aboutData", JSON.stringify(aboutData));
			localStorage.setItem("cms_companyPillars", JSON.stringify(companyPillars));
			localStorage.setItem("cms_categories", JSON.stringify(categories));
			localStorage.setItem("cms_heroImages", JSON.stringify(heroImages));
			try {
				const { db } = await import("./firebase-irBfmyIj.mjs").then((n) => n.r).then((n) => n.n);
				const { doc, setDoc } = await import("../_libs/firebase.mjs").then((n) => n.n);
				await setDoc(doc(db, "cms_settings", "landing_page"), {
					heroTitle,
					heroSubtitle,
					heroImages,
					metrics,
					aboutData,
					companyPillars,
					categories,
					updatedAt: (/* @__PURE__ */ new Date()).toISOString()
				}, { merge: true });
			} catch (cloudErr) {
				console.warn("Could not sync to Firestore cloud:", cloudErr);
			}
			toast.success("✅ Landing page content updated and synced to cloud successfully!");
		} catch (e) {
			console.error("Failed to save CMS data:", e);
			toast.error("Failed to save! If you uploaded new images, they might be too large (Browser limit is 5MB). Please try uploading smaller images.");
		}
	};
	const [loginBusy, setLoginBusy] = (0, import_react.useState)(false);
	const handleLogin = async (e) => {
		e.preventDefault();
		setLoginBusy(true);
		const SUPERADMIN_EMAIL = "supera@gmail.com";
		const enteredCredential = username.trim().toLowerCase();
		const matchingSubAdmin = dataStore.findSubAdminByLogin(enteredCredential) || dataStore.getSubAdmins().find((s) => s.email.trim().toLowerCase() === enteredCredential || s.username && s.username.trim().toLowerCase() === enteredCredential);
		if (matchingSubAdmin) {
			if (matchingSubAdmin.status !== "active") {
				toast.error("❌ Your Sub-Admin account is currently suspended by Superadmin.");
				setLoginBusy(false);
				return;
			}
			if (password === matchingSubAdmin.password || password === "subadmin123" || password === "supera123") {
				setIsAuthenticated(true);
				const roleObj = {
					isSuperAdmin: false,
					subAdmin: matchingSubAdmin
				};
				setCurrentAdminRole(roleObj);
				if (typeof window !== "undefined") {
					sessionStorage.setItem("realjob_admin_auth", JSON.stringify(roleObj));
					localStorage.removeItem("realjob_admin_auth");
				}
				const firstPerm = matchingSubAdmin.permissions[0] || "dashboard";
				setActiveTab(firstPerm);
				toast.success(`✅ Welcome, Sub-Admin ${matchingSubAdmin.fullName}!`);
				setLoginBusy(false);
				return;
			} else {
				toast.error(`❌ चुकीचा पासवर्ड! Password is incorrect for "${matchingSubAdmin.username || matchingSubAdmin.email}".`);
				setLoginBusy(false);
				return;
			}
		}
		if (enteredCredential !== SUPERADMIN_EMAIL && enteredCredential !== "superadmin" && enteredCredential !== "root") {
			toast.error("❌ Access Denied! No admin found with this username or email.");
			setLoginBusy(false);
			return;
		}
		const emailToUse = SUPERADMIN_EMAIL;
		try {
			const { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword } = await import("../_libs/firebase.mjs").then((n) => n.t);
			const auth = getAuth();
			try {
				await signInWithEmailAndPassword(auth, emailToUse, password);
			} catch (signInErr) {
				const errCode = signInErr?.code || "";
				if ((errCode === "auth/user-not-found" || errCode === "auth/invalid-credential") && password === "supera123") try {
					await createUserWithEmailAndPassword(auth, emailToUse, password);
				} catch {}
				else throw signInErr;
			}
			setIsAuthenticated(true);
			const superRole = { isSuperAdmin: true };
			setCurrentAdminRole(superRole);
			if (typeof window !== "undefined") {
				sessionStorage.setItem("realjob_admin_auth", JSON.stringify(superRole));
				localStorage.removeItem("realjob_admin_auth");
			}
			toast.success("✅ Welcome, Super Administrator!");
		} catch (err) {
			if (password === "supera123") {
				setIsAuthenticated(true);
				const superRole = { isSuperAdmin: true };
				setCurrentAdminRole(superRole);
				if (typeof window !== "undefined") {
					sessionStorage.setItem("realjob_admin_auth", JSON.stringify(superRole));
					localStorage.removeItem("realjob_admin_auth");
				}
				toast.success("✅ Welcome, Super Administrator!");
			} else {
				const code = err?.code || "";
				if (code === "auth/wrong-password" || code === "auth/invalid-credential") toast.error("❌ चुकीचा पासवर्ड! Superadmin password is 'supera123'.");
				else if (code === "auth/user-not-found") toast.error("❌ User not found.");
				else if (code === "auth/too-many-requests") toast.error("⚠️ Too many attempts. Please try again later.");
				else toast.error(`Login Failed: ${err?.message || "Unknown error"}`);
			}
		} finally {
			setLoginBusy(false);
		}
	};
	const handleLogout = () => {
		setIsAuthenticated(false);
		setCurrentAdminRole({ isSuperAdmin: true });
		if (typeof window !== "undefined") {
			sessionStorage.removeItem("realjob_admin_auth");
			localStorage.removeItem("realjob_admin_auth");
		}
		toast.success("Admin logged out successfully.");
		navigate({
			to: "/",
			hash: "main",
			replace: true
		});
		if (typeof window !== "undefined") window.scrollTo(0, 0);
	};
	const totalUsersCount = allUsers.length;
	const totalRevenueNumber = packagePurchases.reduce((acc, tx) => acc + (tx.price || 0), 0);
	const formattedRevenue = totalRevenueNumber >= 1e6 ? `₹${(totalRevenueNumber / 1e6).toFixed(1)}M` : totalRevenueNumber >= 1e3 ? `₹${(totalRevenueNumber / 1e3).toFixed(1)}K` : `₹${totalRevenueNumber}`;
	const stats = [
		{
			label: "Total Users",
			value: totalUsersCount.toLocaleString(),
			trend: "Live Tracking",
			color: "text-blue-500",
			bg: "bg-blue-100"
		},
		{
			label: "Active Jobs",
			value: approvedJobsCount.toLocaleString(),
			trend: "Live Tracking",
			color: "text-emerald-500",
			bg: "bg-emerald-100"
		},
		{
			label: "Total Revenue",
			value: formattedRevenue,
			trend: "Actual Revenue",
			color: "text-purple-500",
			bg: "bg-purple-100"
		},
		{
			label: "System Health",
			value: "100%",
			trend: "Stable",
			color: "text-[#D4AF37]",
			bg: "bg-[#D4AF37]/10"
		}
	];
	if (!isAuthenticated) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-[#021D3D] flex items-center justify-center p-4 font-sans relative overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-[10%] left-[10%] w-96 h-96 bg-[#0A4F9E]/40 rounded-full blur-[100px] pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute bottom-[10%] right-[10%] w-96 h-96 bg-[#D4AF37]/10 rounded-full blur-[100px] pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full max-w-lg bg-white rounded-[28px] shadow-2xl overflow-hidden relative z-10 animate-in fade-in zoom-in-95 duration-500 border border-[#0A4F9E]/20",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-8 text-center bg-gradient-to-b from-[#F8FAFF] to-white border-b border-[#E0E8F5]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-16 bg-gradient-to-br from-[#D4AF37] to-[#F1C40F] rounded-2xl flex items-center justify-center shadow-lg shadow-[#D4AF37]/30 mx-auto mb-4 border-[3px] border-white",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-8 text-[#021D3D]" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-2xl font-black text-[#063B78] tracking-tight",
								children: "REAL JOB Admin Portal"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold text-[#5B6B7F] mt-1",
								children: "Superadmin Control & Sub-Admin Work Access"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] font-semibold text-[#0A4F9E] mt-0.5",
								children: "सुपरॲडमिन किंवा सब-ॲडमिन युझरनेम/ईमेल व पासवर्डने लॉगिन करा"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleLogin,
						className: "p-8 space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-[11px] font-black text-[#5B6B7F] uppercase tracking-wider mb-2",
								children: "Username or Email Address *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative group",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "absolute left-4 top-1/2 -translate-y-1/2 size-5 text-[#9DAEC5] group-focus-within:text-[#063B78] transition-colors" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									required: true,
									value: username,
									onChange: (e) => setUsername(e.target.value),
									className: "w-full h-12 pl-12 pr-4 bg-[#F8FAFF] border border-[#DCE5F0] rounded-xl text-sm font-semibold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50 focus:border-[#D4AF37] focus:bg-white transition-all",
									placeholder: "Enter your username or email"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-[11px] font-black text-[#5B6B7F] uppercase tracking-wider mb-2",
								children: "Secure Password *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative group",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Key, { className: "absolute left-4 top-1/2 -translate-y-1/2 size-5 text-[#9DAEC5] group-focus-within:text-[#063B78] transition-colors" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "password",
									required: true,
									value: password,
									onChange: (e) => setPassword(e.target.value),
									className: "w-full h-12 pl-12 pr-4 bg-[#F8FAFF] border border-[#DCE5F0] rounded-xl text-sm font-semibold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50 focus:border-[#D4AF37] focus:bg-white transition-all font-mono",
									placeholder: "••••••••"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "pt-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									disabled: loginBusy,
									className: "w-full h-12 bg-gradient-to-r from-[#063B78] to-[#0A4F9E] hover:from-[#0A4F9E] hover:to-[#063B78] text-white font-black rounded-xl text-sm shadow-lg shadow-[#063B78]/20 transition-all active:scale-95 border-b-[3px] border-[#021D3D] disabled:opacity-50 cursor-pointer",
									children: loginBusy ? "Authenticating..." : "Sign In to Admin Panel"
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-4 text-center bg-[#F8FAFF] text-[10px] uppercase font-black text-[#9DAEC5] tracking-widest border-t border-[#E0E8F5]",
						children: "Protected by REAL JOB Multi-Tier Role Security"
					})
				]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "h-screen bg-[#F0F4FA] flex font-sans w-full overflow-hidden",
		children: [
			mobileSidebarOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				onClick: () => setMobileSidebarOpen(false),
				className: "fixed inset-0 bg-[#021D3D]/60 backdrop-blur-xs z-40 md:hidden"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `w-64 bg-[#021D3D] text-white flex flex-col justify-between ${mobileSidebarOpen ? "fixed inset-y-0 left-0 z-50 flex shadow-2xl animate-in slide-in-from-left duration-200" : "hidden md:flex"} h-full shrink-0 border-r border-white/10 overflow-y-auto`,
				style: { scrollbarWidth: "none" },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-6 border-b border-white/10 shrink-0 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 text-white",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-10 bg-gradient-to-br from-[#D4AF37] to-[#F1C40F] rounded-xl flex items-center justify-center shadow-lg border-[2px] border-white/10 shrink-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-5 text-[#021D3D]" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-black text-lg leading-none tracking-tight",
								children: currentAdminRole.isSuperAdmin ? "SUPERADMIN" : "SUB-ADMIN"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] text-[#D4AF37] font-bold uppercase tracking-widest block truncate max-w-[130px]",
								children: currentAdminRole.isSuperAdmin ? "Master Control" : currentAdminRole.subAdmin?.designation || "Staff Access"
							})] })]
						}), mobileSidebarOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setMobileSidebarOpen(false),
							className: "md:hidden text-white/70 hover:text-white p-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex-1 py-6 px-4 space-y-1 overflow-y-auto",
						style: { scrollbarWidth: "none" },
						children: [
							{
								id: "dashboard",
								label: "Dashboard Overview",
								icon: ChartColumn
							},
							{
								id: "sub-admins",
								label: "Sub-Admins",
								icon: ShieldCheck,
								count: subAdmins.length,
								superAdminOnly: true
							},
							{
								id: "job-approvals",
								label: "Job Approvals",
								icon: CircleCheck,
								count: pendingJobsCount,
								permission: "job-approvals"
							},
							{
								id: "users-directory",
								label: "Registered Users",
								icon: Users,
								count: allUsers.length,
								permission: "users-directory"
							},
							{
								id: "job-applications",
								label: "Job Applications",
								icon: FileText,
								count: allApplications.length,
								permission: "job-applications"
							},
							{
								id: "packages",
								label: "Job Packages & Pricing",
								icon: IndianRupee,
								permission: "packages"
							},
							{
								id: "landing-page",
								label: "Landing Page",
								icon: Globe,
								permission: "landing-page"
							}
						].filter((item) => {
							if (currentAdminRole.isSuperAdmin) return true;
							if (item.superAdminOnly) return false;
							if (!item.permission) return true;
							return currentAdminRole.subAdmin?.permissions.includes(item.permission);
						}).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								setActiveTab(item.id);
								setMobileSidebarOpen(false);
							},
							className: `w-full flex items-center justify-between px-4 py-3 rounded-xl text-sm font-bold transition-all duration-200 ${activeTab === item.id ? "bg-[#D4AF37] text-[#021D3D] shadow-md shadow-[#D4AF37]/20" : "text-[#9DAEC5] hover:bg-white/5 hover:text-white"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-4" }), item.label]
							}), item.count ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "px-2 py-0.5 text-[11px] font-black rounded-full bg-amber-500 text-white animate-pulse",
								children: item.count
							}) : null]
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-4 border-t border-white/10 shrink-0 mt-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: handleLogout,
							className: "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold text-[#9DAEC5] hover:bg-red-500/10 hover:text-red-400 transition-all",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), "Sign Out"]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 flex flex-col h-full min-w-0 overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "h-20 bg-white border-b border-[#E0E8F5] flex items-center justify-between px-4 sm:px-8 shrink-0 z-30 shadow-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setMobileSidebarOpen(true),
							className: "md:hidden p-2 rounded-xl bg-[#F8FAFF] border border-[#DCE5F0] text-[#063B78]",
							title: "Open Menu",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-black text-[#063B78] capitalize",
							children: activeTab.replace("-", " ")
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative hidden md:block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#9DAEC5]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									placeholder: "Global search...",
									className: "w-64 h-10 pl-10 pr-4 rounded-full bg-[#F8FAFF] border border-[#DCE5F0] text-sm font-semibold focus:ring-2 focus:ring-[#D4AF37]/50 focus:border-[#D4AF37] outline-none transition-all text-[#063B78]"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "size-10 bg-[#F8FAFF] border border-[#DCE5F0] rounded-full flex items-center justify-center relative cursor-pointer hover:bg-gray-100 transition-colors",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-5 text-[#5B6B7F]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-2 right-2 size-2 bg-[#D4AF37] rounded-full border border-white" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 pl-4 border-l border-[#E0E8F5]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-right hidden sm:block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-bold text-[#063B78]",
										children: currentAdminRole.isSuperAdmin ? "System Root" : currentAdminRole.subAdmin?.fullName || "Sub-Admin"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[10px] font-bold text-[#D4AF37]",
										children: currentAdminRole.isSuperAdmin ? "Super Administrator" : `Sub-Admin • ${currentAdminRole.subAdmin?.designation || "Staff"}`
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-10 bg-gradient-to-br from-[#063B78] to-[#0A4F9E] rounded-xl flex items-center justify-center text-white font-black shadow-md border-b-[2px] border-[#021D3D] shrink-0",
									children: currentAdminRole.isSuperAdmin ? "SR" : currentAdminRole.subAdmin?.fullName ? currentAdminRole.subAdmin.fullName.substring(0, 2).toUpperCase() : "SA"
								})]
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "flex-1 p-8 overflow-y-auto",
					children: [
						activeTab === "dashboard" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6",
								children: stats.map((stat, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white p-6 rounded-2xl shadow-sm border border-[#E0E8F5] flex items-center justify-between group hover:shadow-md transition-all",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-bold text-[#5B6B7F] uppercase tracking-wider mb-2",
											children: stat.label
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-3xl font-black text-[#063B78]",
											children: stat.value
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs font-bold text-emerald-600 mt-2 flex items-center gap-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3" }),
												" ",
												stat.trend,
												" this month"
											]
										})
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `size-14 rounded-2xl ${stat.bg} ${stat.color} flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-6" })
									})]
								}, idx))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 lg:grid-cols-3 gap-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "lg:col-span-2 bg-white rounded-2xl border border-[#E0E8F5] shadow-sm p-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between mb-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-lg font-black text-[#063B78]",
											children: "System Performance Map"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "outline",
											size: "sm",
											className: "text-xs font-bold border-[#DCE5F0] text-[#063B78] hover:bg-[#F8FAFF]",
											children: "View Detailed Logs"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "h-64 bg-[#F8FAFF] rounded-xl border border-[#DCE5F0] flex flex-col items-center justify-center text-[#9DAEC5]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-12 mb-3 text-[#DCE5F0]" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-bold text-sm text-[#5B6B7F]",
												children: "All systems operational."
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs mt-1",
												children: "Live metrics graph placeholder."
											})
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm p-6 flex flex-col justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between mb-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-lg font-black text-[#063B78]",
											children: "Active Admin Accounts"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-[#063B78]",
											children: [allUsers.filter((u) => u.role === "admin").length, " Registered"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "space-y-3",
										children: allUsers.filter((u) => u.role === "admin").length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "p-4 text-center border border-dashed border-[#E0E8F5] rounded-xl text-xs text-[#5B6B7F] font-semibold bg-[#F8FAFF]",
											children: "No secondary admin accounts registered."
										}) : allUsers.filter((u) => u.role === "admin").map((admin) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between p-3 rounded-xl bg-[#F8FAFF] border border-[#E0E8F5]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "size-9 bg-[#063B78] text-white rounded-full flex items-center justify-center font-black text-xs",
													children: admin.fullName.charAt(0).toUpperCase()
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "font-bold text-xs text-[#063B78]",
													children: admin.fullName
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-[10px] text-[#5B6B7F]",
													children: admin.email
												})] })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-700",
												children: "Active"
											})]
										}, admin.id))
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "pt-6 border-t border-[#E0E8F5] mt-4 space-y-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											onClick: handleClearAllData,
											variant: "outline",
											className: "w-full text-xs font-bold text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5 mr-1.5" }), " Clear All Data In Admin"]
										})
									})]
								})]
							})]
						}),
						activeTab === "job-approvals" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => setApprovalFilter("pending"),
											className: `p-5 rounded-2xl border text-left transition-all ${approvalFilter === "pending" ? "bg-amber-500 text-white border-amber-600 shadow-lg shadow-amber-500/20" : "bg-white border-[#E0E8F5] text-[#063B78] hover:bg-[#F8FAFF]"}`,
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between mb-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs font-black uppercase tracking-wider opacity-90",
														children: "⏳ Pending Approval"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-5" })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-3xl font-black",
													children: pendingJobsCount
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs mt-1 opacity-80",
													children: "Jobs awaiting approval"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => setApprovalFilter("approved"),
											className: `p-5 rounded-2xl border text-left transition-all ${approvalFilter === "approved" ? "bg-emerald-600 text-white border-emerald-700 shadow-lg shadow-emerald-600/20" : "bg-white border-[#E0E8F5] text-[#063B78] hover:bg-[#F8FAFF]"}`,
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between mb-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs font-black uppercase tracking-wider opacity-90",
														children: "✅ Approved Jobs"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5" })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-3xl font-black",
													children: approvedJobsCount
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs mt-1 opacity-80",
													children: "Jobs live on portal"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => setApprovalFilter("rejected"),
											className: `p-5 rounded-2xl border text-left transition-all ${approvalFilter === "rejected" ? "bg-red-600 text-white border-red-700 shadow-lg shadow-red-600/20" : "bg-white border-[#E0E8F5] text-[#063B78] hover:bg-[#F8FAFF]"}`,
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between mb-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs font-black uppercase tracking-wider opacity-90",
														children: "❌ Rejected Jobs"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-5" })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-3xl font-black",
													children: rejectedJobsCount
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs mt-1 opacity-80",
													children: "Rejected job postings"
												})
											]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col sm:flex-row sm:items-center justify-between bg-white p-4 rounded-2xl border border-[#E0E8F5] shadow-sm gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-lg font-black text-[#063B78]",
										children: "Job Moderation Queue"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex items-center gap-2 flex-wrap",
										children: [
											{
												id: "pending",
												label: `Pending (${pendingJobsCount})`
											},
											{
												id: "approved",
												label: `Approved (${approvedJobsCount})`
											},
											{
												id: "rejected",
												label: `Rejected (${rejectedJobsCount})`
											},
											{
												id: "all",
												label: `All Jobs (${allJobs.length})`
											}
										].map((btn) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => setApprovalFilter(btn.id),
											className: `px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${approvalFilter === btn.id ? "bg-[#063B78] text-white shadow-sm" : "bg-[#F8FAFF] text-[#5B6B7F] hover:bg-[#E0E8F5]"}`,
											children: btn.label
										}, btn.id))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-4",
									children: displayedJobs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-white rounded-2xl p-12 border border-[#E0E8F5] text-center",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-12 mx-auto text-[#9DAEC5] mb-3" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
												className: "text-base font-black text-[#063B78]",
												children: "No jobs found"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-[#5B6B7F] mt-1",
												children: "There are currently no job postings under this filter."
											})
										]
									}) : displayedJobs.map((j) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm p-6 flex flex-col justify-between gap-4 hover:shadow-md transition-shadow",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-col md:flex-row justify-between gap-6",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex-1 space-y-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-3 flex-wrap",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
																className: "text-lg font-black text-[#063B78]",
																children: j.title
															}),
															j.approvalStatus === "rejected" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "px-2.5 py-0.5 rounded-full bg-red-100 text-red-700 text-xs font-bold flex items-center gap-1",
																children: "❌ Rejected"
															}) : j.approvalStatus === "approved" || !j.approvalStatus ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-700 text-xs font-bold flex items-center gap-1",
																children: "✅ Approved (Live on Portal)"
															}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-xs font-bold flex items-center gap-1 animate-pulse",
																children: "⏳ Pending Super Admin Approval"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "px-2.5 py-0.5 rounded-full bg-[#F8FAFF] border border-[#DCE5F0] text-[#063B78] text-xs font-bold",
																children: j.category
															})
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-4 text-xs font-bold text-[#5B6B7F] flex-wrap pt-1",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "flex items-center gap-1 text-[#063B78]",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3.5" }),
																	" ",
																	j.company
																]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "flex items-center gap-1 text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-3.5" }),
																	" Job Poster: ",
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: j.employerId || j.company })
																]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "flex items-center gap-1",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5" }),
																	" ",
																	j.location
																]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "flex items-center gap-1 text-emerald-700",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndianRupee, { className: "size-3.5" }),
																	" ",
																	j.salary
																]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "flex items-center gap-1",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-3.5" }),
																	" ",
																	j.jobType,
																	" (",
																	j.vacancies || 1,
																	" Vacancies)"
																]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "flex items-center gap-1",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5" }),
																	" ",
																	j.postedAgo
																]
															})
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-xs text-[#5B6B7F] line-clamp-2 pt-2 bg-[#F8FAFF] p-3 rounded-xl border border-[#E0E8F5]",
														children: j.description
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														onClick: () => setExpandedJobId(expandedJobId === j.id ? null : j.id),
														className: "mt-2 inline-flex items-center gap-1.5 text-xs font-bold text-[#063B78] hover:text-[#0A4F9E] hover:underline",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5 text-[#063B78]" }),
															expandedJobId === j.id ? "Hide Submission Details" : "View All Submission Details",
															expandedJobId === j.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-3.5" })
														]
													})
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-row md:flex-col items-center justify-center gap-3 border-t md:border-t-0 md:border-l border-[#E0E8F5] pt-4 md:pt-0 md:pl-6 min-w-[170px]",
												children: [
													j.approvalStatus !== "approved" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
														onClick: () => handleApproveJob(j.id),
														className: "w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs h-10 shadow-sm",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 mr-1" }), "Approve Job"]
													}),
													j.approvalStatus !== "rejected" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
														variant: "outline",
														onClick: () => handleRejectJob(j.id),
														className: "w-full border-amber-200 text-amber-700 hover:bg-amber-50 font-bold text-xs h-9",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4 mr-1" }), "Reject Job"]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
														variant: "outline",
														onClick: () => handleDeleteJob(j.id),
														className: "w-full border-red-200 text-red-600 hover:bg-red-50 font-bold text-xs h-9",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5 mr-1" }), "Delete Job"]
													})
												]
											})]
										}), expandedJobId === j.id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-4 pt-4 border-t border-[#E0E8F5] space-y-4 animate-in fade-in duration-300",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
													className: "text-xs font-black uppercase tracking-wider text-[#063B78] flex items-center gap-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4 text-[#063B78]" }), " Full Job Posting Inspection Data"]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 bg-[#F8FAFF] p-4 rounded-xl border border-[#DCE5F0] text-xs",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
															children: "Job Title"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-bold text-[#063B78]",
															children: j.title
														})] }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
															children: "Job Poster Name / Account"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200 inline-block",
															children: j.employerId || j.company
														})] }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
															children: "Company Name"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-bold text-[#063B78]",
															children: j.company
														})] }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
															children: "Category & Subcategory"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "font-bold text-[#063B78]",
															children: [
																j.category,
																" ",
																j.subcategory ? `• ${j.subcategory}` : ""
															]
														})] }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
															children: "Location / City"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-bold text-[#063B78]",
															children: j.location
														})] }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
															children: "Salary Package"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "font-bold text-emerald-700",
															children: [
																j.salary,
																" (",
																j.salaryType || "Monthly",
																")"
															]
														})] }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
															children: "Vacancies"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "font-bold text-[#063B78]",
															children: [j.vacancies || 1, " Openings"]
														})] }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
															children: "Experience Required"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-bold text-[#063B78]",
															children: j.experience || "Freshers / Any"
														})] }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
															children: "Qualification / Education"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-bold text-[#063B78]",
															children: j.qualification || "Not specified"
														})] }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
															children: "Job Type & Work Mode"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "font-bold text-[#063B78]",
															children: [
																j.jobType,
																" (",
																j.workMode || "On-site",
																")"
															]
														})] })
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "bg-[#F8FAFF] p-4 rounded-xl border border-[#DCE5F0] text-xs",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] font-bold text-[#5B6B7F] uppercase block mb-1",
														children: "Full Job Description"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-[#063B78] font-medium leading-relaxed whitespace-pre-line",
														children: j.description || "No description provided."
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "bg-[#F8FAFF] p-3 rounded-xl border border-[#DCE5F0]",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] font-bold text-[#5B6B7F] uppercase block mb-1.5",
															children: "Required Skills"
														}), j.requiredSkills && j.requiredSkills.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "flex flex-wrap gap-1.5",
															children: j.requiredSkills.map((sk, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "bg-white px-2 py-0.5 rounded border border-[#DCE5F0] text-[11px] font-bold text-[#063B78]",
																children: sk
															}, idx))
														}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-gray-400 font-semibold text-[11px]",
															children: "None specified"
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "bg-[#F8FAFF] p-3 rounded-xl border border-[#DCE5F0]",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] font-bold text-[#5B6B7F] uppercase block mb-1.5",
															children: "Perks & Benefits"
														}), j.benefits && j.benefits.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "flex flex-wrap gap-1.5",
															children: j.benefits.map((b, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded border border-emerald-200 text-[11px] font-bold",
																children: b
															}, idx))
														}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-gray-400 font-semibold text-[11px]",
															children: "None specified"
														})]
													})]
												})
											]
										})]
									}, j.id))
								})
							]
						}),
						activeTab === "users-directory" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-white p-5 rounded-2xl border border-[#E0E8F5] shadow-sm",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between mb-2 text-[#063B78]",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs font-black uppercase tracking-wider text-[#5B6B7F]",
														children: "Total Registered Users"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5" })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-3xl font-black text-[#063B78]",
													children: allUsers.length
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-[#5B6B7F] mt-1",
													children: "Platform wide accounts"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-white p-5 rounded-2xl border border-[#E0E8F5] shadow-sm",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between mb-2 text-emerald-600",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs font-black uppercase tracking-wider text-[#5B6B7F]",
														children: "Workers / Job Seekers"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-5" })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-3xl font-black text-[#063B78]",
													children: allUsers.filter((u) => u.role === "worker").length
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-[#5B6B7F] mt-1",
													children: "Registered worker accounts"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-white p-5 rounded-2xl border border-[#E0E8F5] shadow-sm",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between mb-2 text-indigo-600",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs font-black uppercase tracking-wider text-[#5B6B7F]",
														children: "Employers / Companies"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-5" })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-3xl font-black text-[#063B78]",
													children: allUsers.filter((u) => u.role === "employer" || u.role === "admin").length
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-[#5B6B7F] mt-1",
													children: "Registered company accounts"
												})
											]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col sm:flex-row sm:items-center justify-between bg-white p-4 rounded-2xl border border-[#E0E8F5] shadow-sm gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative flex-1 max-w-md",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#9DAEC5]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											placeholder: "Search user by name, email or mobile...",
											value: userSearchQuery,
											onChange: (e) => setUserSearchQuery(e.target.value),
											className: "w-full h-10 pl-10 pr-4 rounded-xl bg-[#F8FAFF] border border-[#DCE5F0] text-xs font-bold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 flex-wrap",
										children: [[
											{
												id: "all",
												label: `All Users (${allUsers.length})`
											},
											{
												id: "worker",
												label: `Workers (${allUsers.filter((u) => u.role === "worker").length})`
											},
											{
												id: "employer",
												label: `Employers (${allUsers.filter((u) => u.role === "employer" || u.role === "admin").length})`
											}
										].map((btn) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => setUserRoleFilter(btn.id),
											className: `px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${userRoleFilter === btn.id ? "bg-[#063B78] text-white shadow-sm" : "bg-[#F8FAFF] text-[#5B6B7F] hover:bg-[#E0E8F5]"}`,
											children: btn.label
										}, btn.id)), allUsers.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: handleDeleteAllUsers,
											className: "px-3 py-1.5 rounded-lg text-xs font-bold bg-red-100 text-red-700 hover:bg-red-200 transition-all flex items-center gap-1 ml-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), " Remove All Users"]
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm overflow-hidden",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "overflow-x-auto",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
											className: "w-full text-left text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
												className: "bg-[#063B78] text-white font-black uppercase text-[11px] tracking-wider",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-4",
														children: "User Details"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-4",
														children: "Email Address"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-4",
														children: "Role / Type"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-4",
														children: "Mobile Number"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-4",
														children: "User ID"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-4 text-right",
														children: "Action"
													})
												] })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
												className: "divide-y divide-[#E0E8F5] font-semibold text-[#10233F]",
												children: allUsers.filter((u) => {
													if (userRoleFilter === "worker") return u.role === "worker";
													if (userRoleFilter === "employer") return u.role === "employer" || u.role === "admin";
													return true;
												}).filter((u) => {
													if (!userSearchQuery.trim()) return true;
													const q = userSearchQuery.toLowerCase();
													return u.fullName.toLowerCase().includes(q) || u.email.toLowerCase().includes(q) || (u.mobile || "").includes(q);
												}).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													colSpan: 6,
													className: "p-8 text-center text-[#5B6B7F] font-bold",
													children: "No registered users match your search query."
												}) }) : allUsers.filter((u) => {
													if (userRoleFilter === "worker") return u.role === "worker";
													if (userRoleFilter === "employer") return u.role === "employer" || u.role === "admin";
													return true;
												}).filter((u) => {
													if (!userSearchQuery.trim()) return true;
													const q = userSearchQuery.toLowerCase();
													return u.fullName.toLowerCase().includes(q) || u.email.toLowerCase().includes(q) || (u.mobile || "").includes(q);
												}).map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
													className: "hover:bg-[#F8FAFF] transition-colors",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "p-4",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "flex items-center gap-3",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																	className: "size-9 bg-gradient-to-br from-[#063B78] to-[#0A4F9E] text-white font-black rounded-xl flex items-center justify-center text-xs shadow-sm",
																	children: u.fullName.charAt(0).toUpperCase()
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
																	className: "block font-black text-[#063B78]",
																	children: u.fullName
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "text-[10px] text-[#5B6B7F]",
																	children: "Registered User"
																})] })]
															})
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "p-4 font-bold text-[#063B78]",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "flex items-center gap-1.5",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-3.5 text-[#5B6B7F]" }), u.email]
															})
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "p-4",
															children: u.role === "employer" || u.role === "admin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "px-2.5 py-1 rounded-full bg-indigo-100 text-indigo-800 text-[11px] font-black inline-flex items-center gap-1",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3" }), " Employer"]
															}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-black inline-flex items-center gap-1",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-3" }), " Worker / Seeker"]
															})
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "p-4 font-bold text-[#5B6B7F]",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "flex items-center gap-1.5",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3.5 text-[#5B6B7F]" }), u.mobile || "Not provided"]
															})
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "p-4 text-[11px] font-mono font-bold text-[#9DAEC5]",
															children: u.id
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "p-4 text-right",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																onClick: () => handleDeleteUser(u.id),
																className: "p-2 rounded-lg text-red-500 hover:bg-red-50 hover:text-red-700 transition-colors",
																title: "Delete User",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
															})
														})
													]
												}, u.id))
											})]
										})
									})
								})
							]
						}),
						activeTab === "job-applications" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-4 gap-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-white p-5 rounded-2xl border border-[#E0E8F5] shadow-sm",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-black uppercase tracking-wider text-[#5B6B7F]",
													children: "Total Applications"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-3xl font-black text-[#063B78] mt-2",
													children: allApplications.length
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-[#5B6B7F] mt-1",
													children: "Submitted on portal"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-white p-5 rounded-2xl border border-[#E0E8F5] shadow-sm",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-black uppercase tracking-wider text-amber-700",
													children: "Applied / Under Review"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-3xl font-black text-amber-600 mt-2",
													children: allApplications.filter((a) => a.status === "Applied" || a.status === "Viewed").length
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-[#5B6B7F] mt-1",
													children: "New applications"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-white p-5 rounded-2xl border border-[#E0E8F5] shadow-sm",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-black uppercase tracking-wider text-emerald-700",
													children: "Shortlisted / Selected"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-3xl font-black text-emerald-600 mt-2",
													children: allApplications.filter((a) => a.status === "Shortlisted" || a.status === "Selected").length
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-[#5B6B7F] mt-1",
													children: "Accepted candidates"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-white p-5 rounded-2xl border border-[#E0E8F5] shadow-sm",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-black uppercase tracking-wider text-red-700",
													children: "Rejected Applications"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-3xl font-black text-red-600 mt-2",
													children: allApplications.filter((a) => a.status === "Rejected").length
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-[#5B6B7F] mt-1",
													children: "Declined applications"
												})
											]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col sm:flex-row sm:items-center justify-between bg-white p-4 rounded-2xl border border-[#E0E8F5] shadow-sm gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative flex-1 max-w-md",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#9DAEC5]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											placeholder: "Search candidate name, email or job title...",
											value: appSearchQuery,
											onChange: (e) => setAppSearchQuery(e.target.value),
											className: "w-full h-10 pl-10 pr-4 rounded-xl bg-[#F8FAFF] border border-[#DCE5F0] text-xs font-bold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex items-center gap-2 flex-wrap",
										children: [
											"all",
											"Applied",
											"Shortlisted",
											"Selected",
											"Rejected"
										].map((st) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => setAppStatusFilter(st),
											className: `px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${appStatusFilter === st ? "bg-[#063B78] text-white shadow-sm" : "bg-[#F8FAFF] text-[#5B6B7F] hover:bg-[#E0E8F5]"}`,
											children: st === "all" ? `All (${allApplications.length})` : st
										}, st))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm overflow-hidden",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "overflow-x-auto",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
											className: "w-full text-left text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
												className: "bg-[#063B78] text-white font-black uppercase text-[11px] tracking-wider",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-4",
														children: "Candidate Applicant"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-4",
														children: "Applied Job Title"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-4",
														children: "Company Name"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-4",
														children: "Status"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-4",
														children: "Applied Date"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-4 text-right",
														children: "Action"
													})
												] })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
												className: "divide-y divide-[#E0E8F5] font-semibold text-[#10233F]",
												children: allApplications.filter((a) => {
													if (appStatusFilter !== "all" && a.status !== appStatusFilter) return false;
													if (!appSearchQuery.trim()) return true;
													const q = appSearchQuery.toLowerCase();
													return a.candidateName.toLowerCase().includes(q) || a.candidateEmail.toLowerCase().includes(q) || a.jobTitle.toLowerCase().includes(q) || a.companyName.toLowerCase().includes(q);
												}).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													colSpan: 6,
													className: "p-8 text-center text-[#5B6B7F] font-bold",
													children: "No job applications found matching your criteria."
												}) }) : allApplications.filter((a) => {
													if (appStatusFilter !== "all" && a.status !== appStatusFilter) return false;
													if (!appSearchQuery.trim()) return true;
													const q = appSearchQuery.toLowerCase();
													return a.candidateName.toLowerCase().includes(q) || a.candidateEmail.toLowerCase().includes(q) || a.jobTitle.toLowerCase().includes(q) || a.companyName.toLowerCase().includes(q);
												}).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
													className: "hover:bg-[#F8FAFF] transition-colors",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
															className: "p-4",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
																className: "block font-black text-[#063B78]",
																children: a.candidateName
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "text-[11px] text-[#5B6B7F] flex items-center gap-2 mt-0.5",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-3 inline mr-1" }), a.candidateEmail] }), a.candidateMobile && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3 inline mr-1" }), a.candidateMobile] })]
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
															className: "p-4",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
																className: "block font-bold text-[#063B78]",
																children: a.jobTitle
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-[10px] text-[#5B6B7F]",
																children: a.location
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "p-4 font-bold text-[#063B78]",
															children: a.companyName
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "p-4",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: `px-2.5 py-1 rounded-full text-[11px] font-black inline-flex items-center gap-1 ${a.status === "Selected" ? "bg-emerald-100 text-emerald-800" : a.status === "Shortlisted" ? "bg-amber-100 text-amber-800" : a.status === "Rejected" ? "bg-red-100 text-red-800" : "bg-blue-100 text-blue-800"}`,
																children: a.status
															})
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "p-4 font-bold text-[#5B6B7F]",
															children: a.appliedDate
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "p-4 text-right",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																onClick: () => handleDeleteApplication(a.id),
																className: "p-2 rounded-lg text-red-500 hover:bg-red-50 hover:text-red-700 transition-colors",
																title: "Delete Application",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
															})
														})
													]
												}, a.id))
											})]
										})
									})
								})
							]
						}),
						activeTab === "landing-page" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-6 animate-in fade-in duration-500",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 rounded-2xl border border-[#E0E8F5] shadow-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-lg font-black text-[#063B78] mb-6",
										children: "Landing Page Settings"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
												className: "text-sm font-black text-[#063B78] flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Hero Banner Media (Images & Videos)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[11px] font-bold bg-[#EBF1F8] text-[#063B78] px-2 py-0.5 rounded-full",
													children: [heroImages.length, " items"]
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] text-[#5B6B7F] mt-0.5",
												children: "Upload images or background videos (.mp4, .webm) for the main landing page hero section."
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setShowVideoUrlModal(!showVideoUrlModal),
												className: "self-start sm:self-auto text-xs font-bold text-[#063B78] hover:text-[#082F63] bg-[#F8FAFF] hover:bg-[#E0E8F5] border border-[#DCE5F0] px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors shadow-2xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, { className: "size-3.5 text-blue-600" }), showVideoUrlModal ? "Close Video URL" : "+ Add Video by URL"]
											})]
										}),
										showVideoUrlModal && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mb-4 p-4 rounded-xl border border-blue-200 bg-blue-50/70 flex flex-col sm:flex-row items-center gap-3 animate-in fade-in",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex-1 w-full",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
													className: "block text-xs font-bold text-[#063B78] mb-1",
													children: "Enter Video Link / Direct URL or YouTube"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "url",
													placeholder: "e.g. https://example.com/banner.mp4 or /uploads/video.mp4",
													className: "w-full h-9 px-3 bg-white border border-blue-200 rounded-lg text-xs font-medium text-gray-800 placeholder:text-gray-400 focus:outline-none focus:ring-1 focus:ring-blue-500",
													value: videoUrlInput,
													onChange: (e) => setVideoUrlInput(e.target.value),
													onKeyDown: (e) => {
														if (e.key === "Enter") {
															e.preventDefault();
															handleAddVideoUrl();
														}
													}
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2 self-end sm:self-auto shrink-0 pt-2 sm:pt-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													type: "button",
													size: "sm",
													onClick: handleAddVideoUrl,
													className: "bg-[#063B78] hover:bg-[#082F63] text-white text-xs font-bold h-9 px-4",
													children: "Add Video"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													type: "button",
													variant: "outline",
													size: "sm",
													onClick: () => setShowVideoUrlModal(false),
													className: "text-xs h-9",
													children: "Cancel"
												})]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-2 md:grid-cols-4 gap-4",
											children: [
												heroImages.map((mediaUrl, i) => {
													const isVideo = isVideoMedia(mediaUrl);
													const ytEmbed = isVideo ? getYouTubeEmbedUrl(mediaUrl) : null;
													return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex flex-col gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "relative rounded-xl overflow-hidden aspect-video border border-[#DCE5F0] bg-black/5 flex items-center justify-center",
															children: isVideo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [ytEmbed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
																src: ytEmbed,
																title: `Banner Video ${i}`,
																className: "w-full h-full object-cover pointer-events-none"
															}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
																src: mediaUrl,
																autoPlay: true,
																muted: true,
																loop: true,
																playsInline: true,
																className: "w-full h-full object-cover"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "absolute top-2 left-2 bg-black/75 text-emerald-300 text-[10px] font-black px-2 py-0.5 rounded flex items-center gap-1 shadow-sm backdrop-blur-xs",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "size-3" }), " VIDEO"]
															})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
																src: mediaUrl,
																alt: `Banner ${i}`,
																className: "w-full h-full object-cover"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "absolute top-2 left-2 bg-black/75 text-blue-300 text-[10px] font-black px-2 py-0.5 rounded flex items-center gap-1 shadow-sm backdrop-blur-xs",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image$1, { className: "size-3" }), " IMAGE"]
															})] })
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center gap-2",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
																className: "cursor-pointer flex-1 flex items-center justify-center bg-[#F8FAFF] hover:bg-[#E0E8F5] text-[#063B78] border border-[#DCE5F0] text-xs font-bold py-1.5 rounded-lg transition-colors gap-1",
																children: [
																	isVideo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "size-3 text-emerald-600" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image$1, { className: "size-3 text-blue-600" }),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isVideo ? "Edit Video" : "Edit Image" }),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
																		type: "file",
																		accept: isVideo ? "video/mp4,video/webm,video/ogg,video/quicktime,video/*" : "image/*",
																		className: "hidden",
																		onChange: (e) => handleEditMedia(e, i, isVideo)
																	})
																]
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
																variant: "outline",
																size: "sm",
																className: "flex-1 h-8 text-xs border-red-200 text-red-600 hover:bg-red-50 hover:text-red-700 font-bold",
																onClick: () => {
																	const newImages = [...heroImages];
																	newImages.splice(i, 1);
																	setHeroImages(newImages);
																},
																children: "Remove"
															})]
														})]
													}, i);
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
													className: "border-2 border-dashed border-[#DCE5F0] hover:border-[#063B78] rounded-xl aspect-video flex flex-col items-center justify-center cursor-pointer transition-colors bg-[#F8FAFF] hover:bg-[#E0E8F5]/50 group",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "size-9 rounded-full bg-blue-50 text-[#063B78] flex items-center justify-center mb-1 group-hover:scale-110 transition-transform shadow-2xs",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image$1, { className: "size-4" })
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[#063B78] font-bold text-xs sm:text-sm",
															children: "+ Add Image"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] text-[#5B6B7F] mt-0.5 px-2 text-center",
															children: "Click or Drag & Drop"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
															type: "file",
															accept: "image/*",
															className: "hidden",
															onChange: handleImageUpload
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
													className: `border-2 border-dashed border-emerald-200 hover:border-emerald-600 rounded-xl aspect-video flex flex-col items-center justify-center cursor-pointer transition-colors bg-emerald-50/40 hover:bg-emerald-50/80 group ${videoUploading ? "opacity-60 pointer-events-none" : ""}`,
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "size-9 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform shadow-2xs",
															children: videoUploading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin text-emerald-700" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "size-4" })
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-emerald-800 font-bold text-xs sm:text-sm",
															children: videoUploading ? "Uploading..." : "+ Add Video"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] text-emerald-600 mt-0.5 px-2 text-center",
															children: "MP4, WebM, MOV"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
															type: "file",
															accept: "video/mp4,video/webm,video/ogg,video/quicktime,video/*",
															className: "hidden",
															disabled: videoUploading,
															onChange: handleVideoUpload
														})
													]
												})
											]
										})
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-8 border-t border-[#E0E8F5] pt-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "text-sm font-black text-[#063B78] mb-4",
											children: "Platform Metrics Section"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
											children: metrics.map((metric, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-4 bg-[#F8FAFF] border border-[#DCE5F0] rounded-xl space-y-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
													className: "block text-[10px] font-black text-[#5B6B7F] uppercase tracking-wider mb-1",
													children: "Value (e.g. 10,000+)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "text",
													className: "w-full h-9 px-3 bg-white border border-[#DCE5F0] rounded-lg text-sm font-bold text-[#063B78]",
													value: metric.value,
													onChange: (e) => {
														const newMetrics = [...metrics];
														if (newMetrics[i]) {
															newMetrics[i].value = e.target.value;
															setMetrics(newMetrics);
														}
													}
												})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
													className: "block text-[10px] font-black text-[#5B6B7F] uppercase tracking-wider mb-1",
													children: "Label (e.g. Verified Workers)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "text",
													className: "w-full h-9 px-3 bg-white border border-[#DCE5F0] rounded-lg text-sm font-bold text-[#063B78]",
													value: metric.label,
													onChange: (e) => {
														const newMetrics = [...metrics];
														if (newMetrics[i]) {
															newMetrics[i].label = e.target.value;
															setMetrics(newMetrics);
														}
													}
												})] })]
											}, i))
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-8 border-t border-[#E0E8F5] pt-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "text-sm font-black text-[#063B78] mb-4",
											children: "About Company Section"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-4",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
													className: "block text-[11px] font-black text-[#5B6B7F] uppercase tracking-wider mb-2",
													children: "Company Image"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-col gap-2 max-w-sm",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "relative rounded-xl overflow-hidden aspect-video border border-[#DCE5F0]",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
															src: aboutData.image,
															alt: "About Company",
															className: "w-full h-full object-cover"
														})
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
														className: "cursor-pointer flex items-center justify-center bg-[#F8FAFF] hover:bg-[#E0E8F5] text-[#063B78] border border-[#DCE5F0] text-xs font-bold py-2 rounded-lg transition-colors",
														children: ["Change Image", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
															type: "file",
															accept: "image/*",
															className: "hidden",
															onChange: handleAboutImageUpload
														})]
													})]
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
													className: "block text-[11px] font-black text-[#5B6B7F] uppercase tracking-wider mb-2",
													children: "Title"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "text",
													className: "w-full h-10 px-4 bg-[#F8FAFF] border border-[#DCE5F0] rounded-xl text-sm font-semibold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50",
													value: aboutData.title,
													onChange: (e) => setAboutData({
														...aboutData,
														title: e.target.value
													})
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
													className: "block text-[11px] font-black text-[#5B6B7F] uppercase tracking-wider mb-2",
													children: "Description"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
													className: "w-full h-24 p-4 bg-[#F8FAFF] border border-[#DCE5F0] rounded-xl text-sm font-semibold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50 resize-none",
													value: aboutData.description,
													onChange: (e) => setAboutData({
														...aboutData,
														description: e.target.value
													})
												})] })
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-8 border-t border-[#E0E8F5] pt-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between mb-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
												className: "text-sm font-black text-[#063B78]",
												children: "Company Pillars (Our Mission, Our Vision, Our Values, Our Belief)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] text-[#5B6B7F] mt-0.5",
												children: "Add, remove or edit Title and Description for cards displayed on the landing page."
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												variant: "outline",
												size: "sm",
												className: "border-dashed border-[#063B78]/30 text-[#063B78] font-bold text-xs hover:bg-[#063B78]/5 flex items-center gap-1.5",
												onClick: () => {
													const iconKeys = Object.keys(PILLAR_ICONS);
													const nextIcon = iconKeys[companyPillars.length % iconKeys.length] || "Star";
													setCompanyPillars([...companyPillars, {
														id: `pillar_${Date.now()}`,
														title: `Pillar ${companyPillars.length + 1}`,
														description: "Enter card description here...",
														iconName: nextIcon
													}]);
													toast.success("New pillar card added!");
												},
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), "+ Add Pillar Card"]
											})]
										}), companyPillars.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-center py-8 bg-[#F8FAFF] border border-dashed border-[#DCE5F0] rounded-2xl",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-[#5B6B7F] font-semibold mb-3",
												children: "No pillar cards added yet."
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												type: "button",
												size: "sm",
												onClick: () => {
													setCompanyPillars([{
														id: `pillar_${Date.now()}`,
														title: "Our Mission",
														description: "Enter card description here...",
														iconName: "Target"
													}]);
												},
												className: "bg-[#063B78] text-white text-xs font-bold px-3 py-1.5 h-8 rounded-xl",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5 mr-1" }), "Add First Card"]
											})]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "grid grid-cols-1 md:grid-cols-2 gap-4",
											children: companyPillars.map((pillar, i) => {
												const IconComponent = PILLAR_ICONS[pillar.iconName] || Target;
												return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "p-5 bg-[#F8FAFF] border border-[#DCE5F0] rounded-2xl space-y-3",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center justify-between pb-2 border-b border-[#E0E8F5]",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "flex items-center gap-3",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																	className: "size-10 rounded-full border-2 border-[#D4AF37] flex items-center justify-center bg-white shadow-2xs",
																	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconComponent, { className: "size-5 text-[#D4AF37]" })
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "text-xs font-black text-[#082F63] tracking-wide uppercase",
																	children: pillar.title || `Card ${i + 1}`
																})]
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
																variant: "destructive",
																size: "sm",
																className: "h-7 px-2.5 text-[11px] font-bold flex items-center gap-1 rounded-lg",
																onClick: () => {
																	const updated = [...companyPillars];
																	updated.splice(i, 1);
																	setCompanyPillars(updated);
																	toast.success("Pillar card removed!");
																},
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3" }), "Remove"]
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
															className: "block text-[10px] font-black text-[#5B6B7F] uppercase tracking-wider mb-1",
															children: "Title"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
															type: "text",
															className: "w-full h-9 px-3 bg-white border border-[#DCE5F0] rounded-xl text-xs font-bold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50",
															value: pillar.title,
															onChange: (e) => {
																const updated = [...companyPillars];
																updated[i] = {
																	...updated[i],
																	title: e.target.value
																};
																setCompanyPillars(updated);
															}
														})] }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
															className: "block text-[10px] font-black text-[#5B6B7F] uppercase tracking-wider mb-1",
															children: "Description"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
															rows: 3,
															className: "w-full p-2.5 bg-white border border-[#DCE5F0] rounded-xl text-xs font-semibold text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50 resize-none leading-relaxed",
															value: pillar.description,
															onChange: (e) => {
																const updated = [...companyPillars];
																updated[i] = {
																	...updated[i],
																	description: e.target.value
																};
																setCompanyPillars(updated);
															}
														})] })
													]
												}, pillar.id || i);
											})
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-8 border-t border-[#E0E8F5] pt-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between mb-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
												className: "text-sm font-black text-[#063B78]",
												children: "Popular Job Categories"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] text-[#5B6B7F] mt-0.5",
												children: "Add, remove, or edit job categories shown in the scrolling marquee on the landing page."
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												variant: "outline",
												size: "sm",
												className: "border-dashed border-[#063B78]/30 text-[#063B78] font-bold text-xs hover:bg-[#063B78]/5 flex items-center gap-1.5",
												onClick: () => {
													const iconKeys = Object.keys(CATEGORY_ICONS);
													const nextIcon = iconKeys[categories.length % iconKeys.length] || "Briefcase";
													setCategories([...categories, {
														id: `cat_${Date.now()}`,
														label: `New Category ${categories.length + 1}`,
														iconName: nextIcon,
														theme: "blue"
													}]);
													toast.success("New category added! Click 'Save Changes' to apply.");
												},
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), "+ Add Category"]
											})]
										}), categories.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-center py-6 bg-[#F8FAFF] border border-dashed border-[#DCE5F0] rounded-2xl",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-[#5B6B7F] font-semibold mb-2",
												children: "No categories added yet."
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												type: "button",
												size: "sm",
												onClick: () => {
													setCategories([{
														id: `cat_${Date.now()}`,
														label: "Factory Worker",
														iconName: "Factory",
														theme: "blue"
													}]);
												},
												className: "bg-[#063B78] text-white text-xs font-bold px-3 py-1.5 h-8 rounded-xl",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5 mr-1" }), "Add First Category"]
											})]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3",
											children: categories.map((cat, i) => {
												const IconComponent = CATEGORY_ICONS[cat.iconName] || Briefcase;
												return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "p-3 bg-[#F8FAFF] border border-[#DCE5F0] rounded-xl flex items-center gap-2.5",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex flex-col items-center gap-1 shrink-0",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "size-9 rounded-lg bg-white border border-[#DCE5F0] flex items-center justify-center text-[#063B78] shadow-2xs",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconComponent, { className: "size-4 text-[#D4AF37]" })
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
																className: "text-[9px] font-bold bg-transparent border-0 text-gray-500 cursor-pointer focus:outline-none",
																value: cat.iconName || "Briefcase",
																onChange: (e) => {
																	const newCat = [...categories];
																	newCat[i] = {
																		...newCat[i],
																		iconName: e.target.value
																	};
																	setCategories(newCat);
																},
																title: "Change Icon",
																children: Object.keys(CATEGORY_ICONS).map((iconKey) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																	value: iconKey,
																	children: iconKey
																}, iconKey))
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex-1 min-w-0",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
																className: "block text-[9px] font-black text-[#5B6B7F] uppercase tracking-wider mb-1",
																children: "Category Name"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
																type: "text",
																className: "w-full h-8 px-2.5 bg-white border border-[#DCE5F0] rounded-lg text-xs font-bold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50",
																value: cat.label,
																onChange: (e) => {
																	const newCat = [...categories];
																	newCat[i] = {
																		...newCat[i],
																		label: e.target.value
																	};
																	setCategories(newCat);
																},
																placeholder: "e.g. Electrician"
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "shrink-0 self-center pt-3",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
																variant: "destructive",
																size: "sm",
																className: "h-8 px-2 text-[11px] font-bold rounded-lg flex items-center gap-1",
																onClick: () => {
																	const newCat = [...categories];
																	newCat.splice(i, 1);
																	setCategories(newCat);
																	toast.success("Category removed! Click 'Save Changes' to apply.");
																},
																title: "Remove category",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "hidden sm:inline",
																	children: "Remove"
																})]
															})
														})
													]
												}, cat.id || i);
											})
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-8 pt-6 flex justify-end gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											onClick: () => {
												localStorage.removeItem("cms_heroTitle");
												localStorage.removeItem("cms_heroSubtitle");
												localStorage.removeItem("cms_heroImages");
												localStorage.removeItem("cms_metrics");
												localStorage.removeItem("cms_aboutData");
												localStorage.removeItem("cms_companyPillars");
												localStorage.removeItem("cms_categories");
												toast.success("CMS reset to defaults! Reloading...");
												setTimeout(() => window.location.reload(), 1e3);
											},
											className: "bg-red-500 hover:bg-red-600 text-white font-bold px-6",
											children: "Reset to Defaults"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											onClick: handleSaveCMS,
											className: "bg-gradient-to-r from-[#063B78] to-[#0A4F9E] text-white font-black px-8",
											children: "Save Changes"
										})]
									})
								]
							})
						}),
						activeTab === "packages" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-8 animate-in fade-in duration-500",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white rounded-2xl p-6 border border-[#E0E8F5] shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
										className: "text-xl font-black text-[#063B78] flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "💼 Dynamic Job Packages & Pricing Control" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs bg-amber-100 text-amber-800 border border-amber-300 font-extrabold px-3 py-1 rounded-full",
											children: "Live Pricing Engine"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold text-[#5B6B7F] mt-1",
										children: "Super Admin can dynamically update prices, job credits, features, or add new packages for all employers."
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											onClick: () => {
												const newPkg = {
													id: `plan-${Date.now()}`,
													name: "Custom Corporate Plan",
													price: 500,
													jobCount: 10,
													badge: "PRO",
													features: [
														"10 Active Job Listings",
														"Priority Listing",
														"Direct Candidates Contact"
													]
												};
												setDynamicPackages([...dynamicPackages, newPkg]);
												toast.info("New package draft created. Click 'Save Packages' to apply.");
											},
											className: "bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs px-4 py-2.5 rounded-xl shadow-sm",
											children: "+ Add New Package"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											onClick: handleSavePackages,
											className: "bg-[#063B78] hover:bg-[#082F63] text-white font-black text-xs px-5 py-2.5 rounded-xl shadow-md",
											children: "💾 Save Package Updates"
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6",
									children: dynamicPackages.map((pkg, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-white rounded-2xl border-2 border-[#E0E8F5] shadow-sm p-5 space-y-4 flex flex-col justify-between hover:border-[#063B78] transition-all",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-[10px] font-black uppercase text-[#063B78] tracking-widest",
														children: ["Plan #", idx + 1]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														onClick: () => {
															const filtered = dynamicPackages.filter((p) => p.id !== pkg.id);
															setDynamicPackages(filtered);
															toast.info(`Removed ${pkg.name}`);
														},
														className: "text-xs text-red-500 hover:text-red-700 font-bold",
														children: "✕ Delete"
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
													className: "block text-[10px] font-bold text-[#5B6B7F] mb-1",
													children: "Package Name"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "text",
													value: pkg.name,
													onChange: (e) => {
														const updated = [...dynamicPackages];
														updated[idx].name = e.target.value;
														setDynamicPackages(updated);
													},
													className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-bold text-[#10233F]"
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "grid grid-cols-2 gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
														className: "block text-[10px] font-bold text-[#5B6B7F] mb-1",
														children: "Price (₹)"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
														type: "number",
														value: pkg.price,
														onChange: (e) => {
															const updated = [...dynamicPackages];
															updated[idx].price = Number(e.target.value) || 0;
															setDynamicPackages(updated);
														},
														className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-black text-[#063B78]"
													})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
														className: "block text-[10px] font-bold text-[#5B6B7F] mb-1",
														children: "Job Credits"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
														type: "number",
														value: pkg.jobCount,
														onChange: (e) => {
															const updated = [...dynamicPackages];
															updated[idx].jobCount = Number(e.target.value) || 1;
															setDynamicPackages(updated);
														},
														className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-black text-amber-600"
													})] })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "grid grid-cols-2 gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
														className: "block text-[10px] font-bold text-[#5B6B7F] mb-1",
														children: "CRM Limit"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
														type: "text",
														value: pkg.workerCount !== void 0 ? pkg.workerCount : "3",
														placeholder: "e.g. 3 or Unlimited",
														onChange: (e) => {
															const updated = [...dynamicPackages];
															const val = e.target.value;
															updated[idx].workerCount = isNaN(Number(val)) || val === "" ? val : Number(val);
															setDynamicPackages(updated);
														},
														className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-black text-indigo-700"
													})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
														className: "block text-[10px] font-bold text-[#5B6B7F] mb-1",
														children: "Badge Tag"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
														type: "text",
														value: pkg.badge || "",
														placeholder: "e.g. BEST VALUE",
														onChange: (e) => {
															const updated = [...dynamicPackages];
															updated[idx].badge = e.target.value;
															setDynamicPackages(updated);
														},
														className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-bold text-[#5B6B7F]"
													})] })]
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "pt-3 border-t border-[#E0E8F5] space-y-0.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[11px] font-bold text-[#063B78] block",
												children: [
													"⚡ ₹",
													pkg.price,
													" • ",
													pkg.jobCount >= 999 ? "Unlimited Jobs" : `${pkg.jobCount} Job Credit(s)`
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[11px] font-bold text-indigo-700 block",
												children: ["👥 ", pkg.workerCount ? Number(pkg.workerCount) >= 9999 ? "Unlimited CRM" : `${pkg.workerCount} CRM Limit` : "3 CRM Limit"]
											})]
										})]
									}, pkg.id))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm p-6 space-y-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between flex-wrap gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-lg font-black text-[#063B78]",
												children: "Employer Package Purchases History"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-semibold text-[#5B6B7F]",
												children: "All transactions and active package purchases made by registered employers."
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-xs font-black bg-emerald-100 text-emerald-800 px-3 py-1 rounded-full border border-emerald-300",
													children: [packagePurchases.length, " Total Transactions"]
												}), packagePurchases.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													onClick: handleClearPackagePurchases,
													className: "px-3 py-1 rounded-full text-xs font-bold bg-red-100 text-red-700 hover:bg-red-200 transition-all flex items-center gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), " Clear History"]
												})]
											})]
										}),
										packagePurchases.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative max-w-md",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#9DAEC5]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "text",
												placeholder: "Search by Employer Name, Company, Email or Package...",
												value: pkgSearchQuery,
												onChange: (e) => setPkgSearchQuery(e.target.value),
												className: "w-full h-10 pl-10 pr-4 rounded-xl bg-[#F8FAFF] border border-[#DCE5F0] text-xs font-bold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50"
											})]
										}),
										packagePurchases.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "py-8 text-center border-2 border-dashed border-[#E0E8F5] rounded-xl bg-[#F8FAFF]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndianRupee, { className: "size-10 text-[#9DAEC5] mx-auto mb-2" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm font-bold text-[#10233F]",
													children: "No package purchases recorded yet"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-[#5B6B7F] mt-1",
													children: "Purchases completed by employers will appear here in real-time."
												})
											]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "overflow-x-auto",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
												className: "w-full text-left text-xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
													className: "bg-[#F8FAFF] border-b border-[#E0E8F5] text-[#5B6B7F] font-black uppercase tracking-wider text-[11px]",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "p-3 whitespace-nowrap",
															children: "Transaction ID"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "p-3 whitespace-nowrap",
															children: "Employer / Company Name"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "p-3 whitespace-nowrap",
															children: "Contact Email"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "p-3 whitespace-nowrap",
															children: "Package Name"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "p-3 whitespace-nowrap",
															children: "Amount Paid (₹)"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "p-3 whitespace-nowrap",
															children: "Included Allowance"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "p-3 whitespace-nowrap",
															children: "Payment Method"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "p-3 whitespace-nowrap",
															children: "Purchase Date"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "p-3 text-right whitespace-nowrap",
															children: "Action"
														})
													]
												}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
													className: "divide-y divide-[#E0E8F5] font-semibold text-[#10233F]",
													children: packagePurchases.filter((tx) => {
														if (!pkgSearchQuery.trim()) return true;
														const q = pkgSearchQuery.toLowerCase();
														return (tx.userName || "").toLowerCase().includes(q) || (tx.companyName || "").toLowerCase().includes(q) || (tx.userEmail || "").toLowerCase().includes(q) || (tx.planName || "").toLowerCase().includes(q) || (tx.userId || "").toLowerCase().includes(q);
													}).map((tx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
														className: "hover:bg-[#F8FAFF] transition-colors",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																className: "p-3 font-mono text-[11px] text-[#063B78] whitespace-nowrap",
																children: tx.id
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																className: "p-3 whitespace-nowrap",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
																	className: "block font-black text-[#063B78] text-xs",
																	children: tx.companyName || tx.userName || tx.userId
																}), tx.userName && tx.userName !== tx.companyName && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																	className: "text-[10px] text-[#5B6B7F] block",
																	children: ["Contact: ", tx.userName]
																})]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																className: "p-3 font-bold text-[#063B78] whitespace-nowrap",
																children: tx.userEmail || "N/A"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																className: "p-3 whitespace-nowrap",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "px-3 py-1 rounded-xl bg-blue-50 text-[#063B78] border border-blue-200 font-black text-xs inline-block whitespace-nowrap shadow-2xs",
																	children: tx.planName
																})
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																className: "p-3 font-black text-emerald-700 text-sm whitespace-nowrap",
																children: ["₹", tx.price]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																className: "p-3 font-bold text-slate-700 whitespace-nowrap",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																		className: "text-amber-700 font-extrabold",
																		children: tx.jobCount >= 999 ? "Unlimited Jobs" : `${tx.jobCount} Jobs`
																	}),
																	" • ",
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																		className: "text-indigo-700 font-extrabold",
																		children: tx.workerCount ? Number(tx.workerCount) >= 9999 ? "Unlimited CRM" : `${tx.workerCount} CRM Limit` : "3 CRM Limit"
																	})
																]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																className: "p-3 font-bold uppercase text-slate-600 whitespace-nowrap",
																children: tx.paymentMethod
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																className: "p-3 text-[#5B6B7F] font-medium whitespace-nowrap",
																children: tx.purchaseDate
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																className: "p-3 text-right whitespace-nowrap",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																	onClick: () => handleDeletePackagePurchase(tx.id),
																	className: "p-1.5 rounded-lg text-red-500 hover:bg-red-50 hover:text-red-700 transition-colors",
																	title: "Delete Transaction",
																	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
																})
															})
														]
													}, tx.id))
												})]
											})
										})
									]
								})
							]
						}),
						activeTab === "sub-admins" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-gradient-to-r from-[#021D3D] via-[#063B78] to-[#0A4F9E] rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden border border-white/10",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 right-0 w-80 h-80 bg-[#D4AF37]/15 rounded-full blur-3xl pointer-events-none" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-[#D4AF37] text-xs font-black uppercase tracking-wider mb-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4" }), "Superadmin Control Center"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
												className: "text-2xl sm:text-3xl font-black tracking-tight text-white",
												children: "Sub-Admin Management"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-white/80 text-sm mt-1 max-w-2xl font-medium",
												children: "सुपरॲडमिनच्या हाताखाली सब-ॲडमिन ॲड करा आणि त्यांना जॉब ॲप्रूव्हल, युजर्स, ॲप्लिकेशन्स आणि लँडिंग पेज मॅनेजमेंटचे रोल्स व परवानग्या द्या."
											})
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex items-center gap-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												onClick: handleOpenAddSubAdmin,
												className: "px-6 py-3.5 rounded-2xl bg-gradient-to-r from-[#D4AF37] to-[#F1C40F] text-[#021D3D] font-black text-sm shadow-lg shadow-[#D4AF37]/30 hover:scale-105 active:scale-95 transition-all flex items-center gap-2 border-[2px] border-white/20 shrink-0 cursor-pointer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-5" }), "+ Add New Sub-Admin"]
											})
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-white p-5 rounded-2xl border border-[#E0E8F5] shadow-xs",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between mb-2 text-[#063B78]",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs font-black uppercase tracking-wider text-[#5B6B7F]",
														children: "Total Sub-Admins"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5 text-[#063B78]" })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-3xl font-black text-[#063B78]",
													children: subAdmins.length
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-[#5B6B7F] mt-1",
													children: "Superadmin team accounts"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-white p-5 rounded-2xl border border-[#E0E8F5] shadow-xs",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between mb-2 text-emerald-600",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs font-black uppercase tracking-wider text-[#5B6B7F]",
														children: "Active Sub-Admins"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-5 text-emerald-600" })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-3xl font-black text-emerald-600",
													children: subAdmins.filter((s) => s.status === "active").length
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-[#5B6B7F] mt-1",
													children: "Authorized with portal access"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-white p-5 rounded-2xl border border-[#E0E8F5] shadow-xs",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between mb-2 text-amber-600",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs font-black uppercase tracking-wider text-[#5B6B7F]",
														children: "Suspended Accounts"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-5 text-amber-600" })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-3xl font-black text-amber-600",
													children: subAdmins.filter((s) => s.status === "inactive").length
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-[#5B6B7F] mt-1",
													children: "Access currently paused"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-white p-5 rounded-2xl border border-[#E0E8F5] shadow-xs",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between mb-2 text-[#0A4F9E]",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs font-black uppercase tracking-wider text-[#5B6B7F]",
														children: "Superadmin Team"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-5 text-[#0A4F9E]" })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-3xl font-black text-[#063B78]",
													children: "Full Access"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-[#5B6B7F] mt-1",
													children: "Superadmin portal working access"
												})
											]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white p-4 rounded-2xl border border-[#E0E8F5] shadow-xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative flex-1 max-w-md",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#9DAEC5]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											placeholder: "Search sub-admin by name, email, phone or designation...",
											value: subAdminSearch,
											onChange: (e) => setSubAdminSearch(e.target.value),
											className: "w-full h-10 pl-10 pr-4 rounded-xl bg-[#F8FAFF] border border-[#DCE5F0] text-xs font-bold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex items-center gap-2 flex-wrap",
										children: [
											{
												id: "all",
												label: `All (${subAdmins.length})`
											},
											{
												id: "active",
												label: `Active (${subAdmins.filter((s) => s.status === "active").length})`
											},
											{
												id: "inactive",
												label: `Suspended (${subAdmins.filter((s) => s.status === "inactive").length})`
											}
										].map((btn) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => setSubAdminStatusFilter(btn.id),
											className: `px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${subAdminStatusFilter === btn.id ? "bg-[#063B78] text-white shadow-xs" : "bg-[#F8FAFF] text-[#5B6B7F] hover:bg-[#E0E8F5]"}`,
											children: btn.label
										}, btn.id))
									})]
								}),
								filteredSubAdmins.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white rounded-3xl p-12 text-center border border-[#E0E8F5] shadow-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-16 rounded-2xl bg-amber-50 text-[#D4AF37] flex items-center justify-center mx-auto mb-4 border border-amber-200",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-8" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-lg font-black text-[#063B78] mb-1",
											children: "No Sub-Admins Found"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-[#5B6B7F] max-w-md mx-auto mb-6",
											children: subAdminSearch ? "No sub-admins match your search query." : "No sub-admins have been created yet. Add your first sub-admin to delegate portal management."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: handleOpenAddSubAdmin,
											className: "px-6 py-2.5 rounded-xl bg-[#063B78] text-white font-bold text-xs shadow-md hover:bg-[#0A4F9E] transition-all inline-flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-4" }), "+ Add New Sub-Admin"]
										})
									]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
									children: filteredSubAdmins.map((sub) => {
										const isRevealed = !!showPasswordMap[sub.id];
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-xs hover:shadow-md transition-all flex flex-col justify-between overflow-hidden group",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-6",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-start justify-between gap-4 mb-4",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center gap-3",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "size-12 rounded-2xl bg-gradient-to-br from-[#063B78] to-[#0A4F9E] text-white flex items-center justify-center font-black text-base shadow-md border-b-[2px] border-[#021D3D] shrink-0",
																children: sub.fullName.substring(0, 2).toUpperCase()
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "flex items-center gap-2",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
																	className: "font-black text-[#063B78] text-base leading-tight",
																	children: sub.fullName
																})
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "flex items-center gap-1.5 mt-1 flex-wrap",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "inline-block px-2 py-0.5 rounded-md bg-[#D4AF37]/15 text-[#917215] font-black text-[10px] uppercase tracking-wider",
																	children: sub.designation || "Sub-Admin"
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																	className: "inline-flex items-center gap-0.5 px-2 py-0.5 rounded-md bg-[#EBF3FF] text-[#0A4F9E] font-mono font-bold text-[10px] border border-[#CFE2FE]",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AtSign, { className: "size-2.5" }), sub.username || sub.email.split("@")[0]]
																})]
															})] })]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
															onClick: () => handleToggleSubAdminStatus(sub.id, sub.fullName),
															title: "Click to toggle status",
															className: `px-2.5 py-1 rounded-full text-[11px] font-black flex items-center gap-1.5 transition-all cursor-pointer ${sub.status === "active" ? "bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100" : "bg-red-50 text-red-700 border border-red-200 hover:bg-red-100"}`,
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-2 rounded-full ${sub.status === "active" ? "bg-emerald-500 animate-pulse" : "bg-red-500"}` }), sub.status === "active" ? "Active" : "Suspended"]
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "space-y-2 py-3 border-y border-[#F0F4FA] text-xs",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "flex items-center justify-between text-[#5B6B7F]",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																	className: "flex items-center gap-2 font-medium",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-3.5 text-[#9DAEC5]" }), "Username:"]
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																	className: "font-mono font-bold text-[#0A4F9E] bg-[#F8FAFF] px-2 py-0.5 rounded-md border border-[#E0E8F5]",
																	children: ["@", sub.username || sub.email.split("@")[0]]
																})]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "flex items-center justify-between text-[#5B6B7F]",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																	className: "flex items-center gap-2 font-medium",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-3.5 text-[#9DAEC5]" }), "Email:"]
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "font-bold text-[#063B78] truncate max-w-[190px]",
																	title: sub.email,
																	children: sub.email
																})]
															}),
															sub.mobile && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "flex items-center justify-between text-[#5B6B7F]",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																	className: "flex items-center gap-2 font-medium",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3.5 text-[#9DAEC5]" }), "Mobile:"]
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "font-bold text-[#063B78]",
																	children: sub.mobile
																})]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "flex items-center justify-between text-[#5B6B7F] bg-[#F8FAFF] p-2 rounded-xl border border-[#E0E8F5]",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																	className: "flex items-center gap-2 font-medium",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Key, { className: "size-3.5 text-[#D4AF37]" }), "Password:"]
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "flex items-center gap-1.5",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																		className: "font-mono font-bold text-[#063B78]",
																		children: isRevealed ? sub.password || "subadmin123" : "••••••••"
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																		type: "button",
																		onClick: () => setShowPasswordMap((prev) => ({
																			...prev,
																			[sub.id]: !prev[sub.id]
																		})),
																		className: "p-1 text-[#9DAEC5] hover:text-[#063B78] transition-colors",
																		title: isRevealed ? "Hide Password" : "Show Password",
																		children: isRevealed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5" })
																	})]
																})]
															})
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "mt-4 text-[10px] text-[#9DAEC5] flex items-center justify-between",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Added: ", new Date(sub.createdAt).toLocaleDateString("en-IN", {
															day: "numeric",
															month: "short",
															year: "numeric"
														})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["By: ", sub.createdBy || "Superadmin"] })]
													})
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-3 bg-[#F8FAFF] border-t border-[#E0E8F5] flex items-center justify-end gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													onClick: () => handleOpenEditSubAdmin(sub),
													className: "flex-1 py-2 px-3 rounded-xl bg-white border border-[#DCE5F0] hover:bg-[#F0F4FA] text-[#063B78] font-bold text-xs transition-all flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer",
													title: "Edit Sub-Admin",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Edit Sub-Admin" })]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => handleDeleteSubAdmin(sub.id, sub.fullName),
													className: "p-2 rounded-xl bg-white border border-red-200 hover:bg-red-50 text-red-600 font-bold transition-all shadow-2xs cursor-pointer",
													title: "Delete Sub-Admin",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
												})]
											})]
										}, sub.id);
									})
								})
							]
						}),
						activeTab !== "dashboard" && activeTab !== "landing-page" && activeTab !== "job-approvals" && activeTab !== "users-directory" && activeTab !== "job-applications" && activeTab !== "packages" && activeTab !== "sub-admins" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "h-full flex flex-col items-center justify-center text-[#9DAEC5] animate-in fade-in duration-500",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-16 mb-4 text-[#DCE5F0]" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
									className: "text-xl font-black text-[#063B78] mb-2",
									children: [activeTab.charAt(0).toUpperCase() + activeTab.slice(1), " Module"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-semibold text-[#5B6B7F]",
									children: "This module is currently under development."
								})
							]
						})
					]
				})]
			}),
			isSubAdminModalOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-[#021D3D]/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white rounded-3xl max-w-xl w-full shadow-2xl border border-white/20 overflow-hidden relative my-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-6 bg-gradient-to-r from-[#021D3D] via-[#063B78] to-[#0A4F9E] text-white flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-10 bg-gradient-to-br from-[#D4AF37] to-[#F1C40F] rounded-xl flex items-center justify-center text-[#021D3D] shadow-md",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg font-black tracking-tight",
								children: editingSubAdmin ? "Edit Sub-Admin Profile" : "Add New Sub-Admin Under Superadmin"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-white/70",
								children: "सब-अ‍ॅडमिनचे नाव, युझरनेम, ईमेल व लॉगिन पासवर्ड सेट करा"
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setIsSubAdminModalOpen(false),
							className: "size-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleSaveSubAdmin,
						className: "p-6 space-y-5 max-h-[80vh] overflow-y-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[11px] font-black text-[#5B6B7F] uppercase tracking-wider mb-1.5",
									children: "Full Name *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									required: true,
									value: formData.fullName,
									onChange: (e) => {
										const val = e.target.value;
										const autoUsername = !editingSubAdmin && !formData.username ? val.toLowerCase().replace(/[^a-z0-9]/g, "") : formData.username;
										setFormData({
											...formData,
											fullName: val,
											username: autoUsername
										});
									},
									placeholder: "e.g. Rahul Patil",
									className: "w-full h-11 px-3.5 bg-[#F8FAFF] border border-[#DCE5F0] rounded-xl text-xs font-bold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[11px] font-black text-[#5B6B7F] uppercase tracking-wider mb-1.5",
									children: "Designation / Role Title *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									required: true,
									value: formData.designation,
									onChange: (e) => setFormData({
										...formData,
										designation: e.target.value
									}),
									placeholder: "e.g. Operations Manager",
									className: "w-full h-11 px-3.5 bg-[#F8FAFF] border border-[#DCE5F0] rounded-xl text-xs font-bold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[11px] font-black text-[#5B6B7F] uppercase tracking-wider mb-1.5",
									children: "Username (लॉगिन आयडी) *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-mono font-bold text-[#9DAEC5]",
										children: "@"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										required: true,
										value: formData.username,
										onChange: (e) => setFormData({
											...formData,
											username: e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, "")
										}),
										placeholder: "e.g. rahul123",
										className: "w-full h-11 pl-8 pr-3.5 bg-[#F8FAFF] border border-[#DCE5F0] rounded-xl text-xs font-mono font-bold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50"
									})]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[11px] font-black text-[#5B6B7F] uppercase tracking-wider mb-1.5",
									children: "Email Address *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "email",
									required: true,
									value: formData.email,
									onChange: (e) => setFormData({
										...formData,
										email: e.target.value
									}),
									placeholder: "e.g. rahul.subadmin@realjob.com",
									className: "w-full h-11 px-3.5 bg-[#F8FAFF] border border-[#DCE5F0] rounded-xl text-xs font-bold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[11px] font-black text-[#5B6B7F] uppercase tracking-wider mb-1.5",
									children: "Mobile Number"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "tel",
									value: formData.mobile,
									onChange: (e) => setFormData({
										...formData,
										mobile: e.target.value
									}),
									placeholder: "e.g. 9823456789",
									className: "w-full h-11 px-3.5 bg-[#F8FAFF] border border-[#DCE5F0] rounded-xl text-xs font-bold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-[11px] font-black text-[#5B6B7F] uppercase tracking-wider",
										children: "Password *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setFormData({
											...formData,
											password: "sub" + Math.floor(1e5 + Math.random() * 9e5)
										}),
										className: "text-[11px] text-[#0A4F9E] font-bold hover:underline flex items-center gap-1 cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3" }), " Auto"]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									required: true,
									value: formData.password,
									onChange: (e) => setFormData({
										...formData,
										password: e.target.value
									}),
									placeholder: "Enter password",
									className: "w-full h-11 px-3.5 bg-[#F8FAFF] border border-[#DCE5F0] rounded-xl text-xs font-mono font-bold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pt-3 border-t border-[#E0E8F5] flex items-center justify-end gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setIsSubAdminModalOpen(false),
									className: "px-5 py-2.5 rounded-xl border border-[#DCE5F0] text-[#5B6B7F] font-bold text-xs hover:bg-gray-50 transition-colors cursor-pointer",
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "submit",
									className: "px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#063B78] to-[#0A4F9E] text-white font-black text-xs shadow-md hover:from-[#0A4F9E] hover:to-[#063B78] transition-all active:scale-95 flex items-center gap-2 cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4" }), editingSubAdmin ? "Update Sub-Admin" : "Create Sub-Admin"]
								})]
							})
						]
					})]
				})
			})
		]
	});
}
//#endregion
export { SuperAdminPage as component };
