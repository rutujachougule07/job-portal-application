import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n, n as getCategoryDesc, r as getCategoryTitle, t as I18nProvider } from "./i18n-CEAlH7ip.mjs";
import { _ as useNavigate, c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, m as createFileRoute, p as lazyRouteComponent, s as Scripts, v as useParams, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Button, t as Brand } from "./button-DlK03b8v.mjs";
import { t as dataStore } from "./data-store-j7ecARph.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { At as Building, Ct as CircleCheck, D as Send, Et as ChevronDown, Ft as BookmarkCheck, Ht as ArrowLeft, I as PhoneCall, J as LayoutGrid, Mt as Briefcase, N as QrCode, Nt as BriefcaseBusiness, O as Search, Ot as ChartColumn, P as Plus, Pt as Bookmark, R as PackageCheck, Rt as BadgeCheck, S as SlidersHorizontal, St as CircleQuestionMark, T as Share2, V as MapPin, Vt as ArrowRight, X as Laptop, Z as Landmark, _ as Stethoscope, _t as Download, a as Wallet, at as GraduationCap, bt as Clock3, c as User, ct as Funnel, d as UserCheck, dt as Factory, et as Hotel, h as Trash2, ht as Ellipsis, i as Wrench, it as HardHat, j as RotateCcw, jt as Building2, m as TrendingUp, mt as ExternalLink, nt as HeartHandshake, ot as Globe, p as Truck, r as X, rt as Headphones, s as Users, st as Gift, t as Zap, tt as HeartPulse, ut as FileText, v as Star, w as ShieldCheck, x as Sparkles, y as SquarePen, yt as Code, z as MessageSquare, zt as Award } from "../_libs/lucide-react.mjs";
import { n as PublicHeader, t as PublicFooter } from "./PublicHeader-DazdRGin.mjs";
import { t as Input } from "./input-AgVN5mZH.mjs";
import { t as Badge } from "./badge-Sq1JKEhL.mjs";
import { i as jobs, n as StatCard, r as getCompanyMetadata, t as JobCard } from "./JobCard-C-fka3vt.mjs";
import { a as CartesianGrid, i as Area, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as AreaChart } from "../_libs/recharts+[...].mjs";
import { t as Route$36 } from "./auth-TmANPNaU.mjs";
import { t as Route$37 } from "./select-language-Dim5Xq2b.mjs";
import { t as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-Cc9TT-XN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-C409cjex.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$35 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Karyam" },
			{
				name: "description",
				content: "Jobs, hiring, workforce management and E-Salary."
			},
			{
				name: "author",
				content: "Karyam"
			},
			{
				property: "og:title",
				content: "Karyam"
			},
			{
				property: "og:description",
				content: "Jobs, hiring, workforce management and E-Salary."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:site",
				content: "@Lovable"
			}
		],
		links: [
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@600;700&family=Manrope:wght@400;500;600;700;800&display=swap"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.svg",
				type: "image/svg+xml"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$35.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(I18nProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {})] })
	});
}
var career_team_default = "/assets/career-team-CL7SHC2o.jpg";
var Route$34 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "REAL JOB — Portal Entrance | User Login & Admin Login" },
		{
			name: "description",
			content: "Select User Login to browse jobs & hire workers or Admin Login for platform administration."
		},
		{
			property: "og:title",
			content: "REAL JOB — Portal Entrance"
		},
		{
			property: "og:description",
			content: "योग्य माणूस • योग्य काम • योग्य संधी — Portal Entrance"
		},
		{
			property: "og:type",
			content: "website"
		}
	] }),
	component: LandingGatewayPage
});
function LandingGatewayPage() {
	const { t } = useI18n();
	const navigate = useNavigate();
	const [currentUser, setCurrentUser] = (0, import_react.useState)(() => dataStore.getCurrentUser());
	const handleLogout = () => {
		window.localStorage.removeItem("realjob-user");
		dataStore.setCurrentUser(null);
		setCurrentUser(null);
		toast.info("Logged out successfully!");
	};
	const handleQuickUserEntry = () => {
		const userObj = {
			id: "seeker-demo",
			email: "user@realjob.com",
			role: "worker",
			fullName: "Rutuja Pawar (Candidate)"
		};
		window.localStorage.setItem("realjob-user", JSON.stringify(userObj));
		dataStore.setCurrentUser(userObj);
		setCurrentUser(userObj);
		toast.success("User Portal Ready! Redirecting to main website...");
		navigate({ to: "/home" });
	};
	const handleQuickAdminEntry = () => {
		const adminObj = {
			id: "admin-super",
			email: "admin@realjob.com",
			role: "admin",
			fullName: "Platform Admin Manager"
		};
		window.localStorage.setItem("realjob-user", JSON.stringify(adminObj));
		dataStore.setCurrentUser(adminObj);
		setCurrentUser(adminObj);
		toast.success("Admin Portal Ready! Opening Admin Control Dashboard...");
		navigate({ to: "/admin" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-[#F5F8FC] flex flex-col justify-between",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-50 border-b border-[#DCE5F0] bg-white/95 backdrop-blur-md shadow-xs",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-18 max-w-7xl items-center justify-between px-4 sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, { className: "h-14 sm:h-16 scale-105 origin-left" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-2 sm:gap-3",
						children: currentUser ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#EBF1F8] border border-[#B8D3F2] text-xs font-black text-[#063B78]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["👤 ", currentUser.fullName || currentUser.email?.split("@")[0]] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: handleLogout,
								size: "sm",
								className: "bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs px-3 h-9.5 rounded-lg shadow-xs",
								children: "Logout (लॉग आउट)"
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							className: "border-[#063B78] text-[#063B78] font-extrabold hover:bg-[#063B78] hover:text-white text-xs px-3 sm:px-4 h-9.5 rounded-lg shadow-2xs",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/auth",
								search: {
									mode: "login",
									role: "worker"
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-4 mr-1.5" }), t("userLogin")]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							className: "bg-[#063B78] hover:bg-[#082F63] text-white font-extrabold text-xs px-3 sm:px-4 h-9.5 rounded-lg shadow-xs",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/auth",
								search: {
									mode: "login",
									role: "admin"
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 mr-1.5 text-[#FFC400]" }), t("adminLogin")]
							})
						})] })
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "relative isolate overflow-hidden bg-hero-overlay py-16 sm:py-24 text-white",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: career_team_default,
							alt: "REAL JOB India Portal",
							className: "absolute inset-0 h-full w-full object-cover object-center opacity-25"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative mx-auto max-w-7xl px-4 text-center sm:px-6 lg:px-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-4 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-1.5 text-xs font-black uppercase tracking-wider text-[#FFC400] backdrop-blur",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" }), "भारतातील #१ कामगार व जॉब डिजिटल पोर्टल (Portal Entrance)"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
									className: "font-display text-3xl font-black leading-tight sm:text-5xl lg:text-6xl text-white",
									children: [
										"REAL JOB पोर्टल मध्ये आपले स्वागत आहे! ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[#FFC400]",
											children: "योग्य माणूस • योग्य काम • योग्य संधी"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mx-auto mt-4 max-w-2xl text-base sm:text-lg font-semibold text-white/90",
									children: "पुढील पर्यायांमधून आपले पोर्टल निवडा — युजर लॉगिन द्वारे वेबसाईट वापरा किंवा ॲडमिन लॉगिन द्वारे डॅशबोर्ड नियंत्रित करा."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 flex flex-wrap items-center justify-center gap-4 bg-white/10 p-3 rounded-2xl border border-white/20 max-w-xl mx-auto backdrop-blur-md",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-black uppercase text-[#FFC400] w-full sm:w-auto",
											children: "⚡ झटपट चाचणी (Quick Access):"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											onClick: handleQuickUserEntry,
											className: "btn-yellow text-xs font-black h-9 px-4 shadow-sm",
											children: "👤 युजर पोर्टलवर जा (User Portal)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											onClick: handleQuickAdminEntry,
											className: "bg-white hover:bg-gray-100 text-[#063B78] text-xs font-black h-9 px-4 shadow-sm",
											children: "🛡️ ॲडमिन डॅशबोर्ड पहा (Admin Panel)"
										})
									]
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "relative z-20 mx-auto -mt-10 max-w-6xl px-4 sm:px-6 mb-16",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-8 md:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "group rounded-3xl border-2 border-[#DCE5F0] bg-white p-8 shadow-xl transition-all duration-300 hover:border-[#063B78] hover:shadow-2xl flex flex-col justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between mb-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "grid size-16 place-items-center rounded-2xl bg-[#EBF1F8] text-[#063B78] group-hover:bg-[#063B78] group-hover:text-white transition-colors",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-8" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full bg-[#EBF1F8] px-3 py-1 text-xs font-black uppercase text-[#063B78]",
											children: "कामगार & मालक दालन"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-2xl font-black text-[#10233F] group-hover:text-[#063B78] transition-colors",
										children: "युजर लॉगिन / User Portal"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm font-semibold text-[#5B6B7F]",
										children: "नोकरी शोधक कामगार, कारागीर आणि काम देणाऱ्या कंपन्यांसाठी युजर लॉगिन आणि मुख्य जॉब वेबसाईट."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-6 space-y-3 pt-4 border-t border-[#DCE5F0]",
										children: [
											"१०,०००+ सत्यापित कुशल कामगार व नोकऱ्या",
											"कोणतेही मध्यस्थ किंवा कमिशन नाही (0% Commission)",
											"थेट फोन अथवा व्हॉट्सॲपवर संपर्क करा",
											"नवीन प्रोफाईल तयार करा & जॉब्स ट्रॅक करा"
										].map((feat, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 text-xs font-bold text-[#10233F]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-[#063B78] shrink-0" }), feat]
										}, i))
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 grid gap-3 pt-6 border-t border-[#DCE5F0]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										size: "lg",
										className: "btn-navy h-12 w-full font-black text-sm shadow-md",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/auth",
											search: {
												mode: "login",
												role: "worker"
											},
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-4 mr-2" }),
												"युजर लॉगिन करा (User Login)",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "ml-auto size-4 text-[#FFC400]" })
											]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										variant: "outline",
										size: "lg",
										className: "h-11 w-full border-[#063B78] text-[#063B78] font-black text-xs hover:bg-[#EBF1F8]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/home",
											children: "🌐 मुख्य वेबसाईट पहा (Go to Main Website)"
										})
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "group rounded-3xl border-2 border-[#DCE5F0] bg-white p-8 shadow-xl transition-all duration-300 hover:border-[#FFC400] hover:shadow-2xl flex flex-col justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between mb-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "grid size-16 place-items-center rounded-2xl bg-[#FFF8E1] text-[#082F63] group-hover:bg-[#FFC400] group-hover:text-[#082F63] transition-colors",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-8" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full bg-[#FFF8E1] px-3 py-1 text-xs font-black uppercase text-[#082F63]",
											children: "प्रशासकीय दालन (Control)"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-2xl font-black text-[#10233F] group-hover:text-[#082F63] transition-colors",
										children: "ॲडमिन लॉगिन / Admin Portal"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm font-semibold text-[#5B6B7F]",
										children: "प्लॅटफॉर्म व्यवस्थापक आणि प्रशासकांसाठी स्वतंत्र ॲडमिन डॅशबोर्ड आणि नियंत्रण दालन."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-6 space-y-3 pt-4 border-t border-[#DCE5F0]",
										children: [
											"कामगार, कंपनी व युजर्सचे संपूर्ण नियंत्रण",
											"नोकरी पोस्टिंग्स मंजुरी & स्टेटस मॅनेजमेंट",
											"ई-पगार (E-Salary) & पेरोल पडताळणी",
											"प्लॅटफॉर्म रिपोर्ट, विश्लेषण & सेटिंग्ज"
										].map((feat, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 text-xs font-bold text-[#10233F]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-[#082F63] shrink-0" }), feat]
										}, i))
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 grid gap-3 pt-6 border-t border-[#DCE5F0]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										size: "lg",
										className: "btn-yellow h-12 w-full font-black text-sm shadow-md",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/auth",
											search: {
												mode: "login",
												role: "admin"
											},
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 mr-2" }),
												"ॲडमिन लॉगिन करा (Admin Login)",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "ml-auto size-4" })
											]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										variant: "outline",
										size: "lg",
										className: "h-11 w-full border-[#063B78] text-[#063B78] font-black text-xs hover:bg-[#EBF1F8]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/admin",
											children: "🛡️ ॲडमिन डॅशबोर्ड पहा (Go to Admin Dashboard)"
										})
									})]
								})]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "py-12 bg-white border-y border-[#DCE5F0]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 lg:grid-cols-4 gap-6 text-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "block text-3xl sm:text-4xl font-black text-[#063B78]",
											children: "१०,०००+"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold text-[#5B6B7F]",
											children: "सत्यापित कामगार (Verified Workers)"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "block text-3xl sm:text-4xl font-black text-[#063B78]",
											children: "५,०००+"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold text-[#5B6B7F]",
											children: "सक्रिय नोकऱ्या (Live Job Openings)"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "block text-3xl sm:text-4xl font-black text-[#063B78]",
											children: "१,२००+"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold text-[#5B6B7F]",
											children: "कारखाने व कंपन्या (Employers)"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "block text-3xl sm:text-4xl font-black text-[#063B78]",
											children: "०%"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold text-[#5B6B7F]",
											children: "कमिशन नियम (Zero Commission)"
										})]
									})
								]
							})
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
		]
	});
}
var $$splitComponentImporter$25 = () => import("./route-Di7iQBCH.mjs");
var Route$33 = createFileRoute("/_authenticated")({
	ssr: false,
	beforeLoad: async () => {
		if (typeof window !== "undefined") {
			const userStr = window.localStorage.getItem("realjob-user");
			if (userStr) try {
				return { user: JSON.parse(userStr) };
			} catch {}
			return { user: {
				id: "demo-user",
				email: "user@realjob.in"
			} };
		}
		return { user: {
			id: "demo-user",
			email: "user@realjob.in"
		} };
	},
	component: lazyRouteComponent($$splitComponentImporter$25, "component")
});
var $$splitComponentImporter$24 = () => import("./about-DxW-lfL6.mjs");
var Route$32 = createFileRoute("/about")({
	head: () => ({ meta: [{ title: "About Us — REAL JOB | Find Work | Find Workers" }, {
		name: "description",
		content: "Learn about REAL JOB — India's trusted digital workforce & recruitment platform connecting verified workers with top employers."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$24, "component")
});
var Route$31 = createFileRoute("/admin")({
	head: () => ({ meta: [{ title: "Admin Portal & Control Dashboard — REAL JOB" }, {
		name: "description",
		content: "Platform administration, user management, employer verification and job control panel."
	}] }),
	component: AdminDashboardPage
});
var monthlyAnalytics = [
	{
		month: "May",
		workers: 0,
		jobs: 0,
		hires: 0
	},
	{
		month: "Jun",
		workers: 0,
		jobs: 0,
		hires: 0
	},
	{
		month: "Jul",
		workers: 0,
		jobs: 0,
		hires: 0
	},
	{
		month: "Aug",
		workers: 0,
		jobs: 0,
		hires: 0
	},
	{
		month: "Sep",
		workers: 0,
		jobs: 0,
		hires: 0
	}
];
function AdminDashboardPage() {
	const navigate = useNavigate();
	const [activeTab, setActiveTab] = (0, import_react.useState)("overview");
	const [jobs, setJobs] = (0, import_react.useState)([]);
	const [applications, setApplications] = (0, import_react.useState)([]);
	const [userSearch, setUserSearch] = (0, import_react.useState)("");
	const [jobSearch, setJobSearch] = (0, import_react.useState)("");
	const [appSearch, setAppSearch] = (0, import_react.useState)("");
	const [filterJobId, setFilterJobId] = (0, import_react.useState)(null);
	const [registeredUsers, setRegisteredUsers] = (0, import_react.useState)([]);
	const loadAllData = () => {
		setJobs(dataStore.getAllJobs());
		setApplications(dataStore.getAllApplications());
		const reg = dataStore.getRegisteredUsers();
		setRegisteredUsers(reg.map((u) => ({
			id: u.id,
			name: u.fullName,
			role: u.role,
			mobile: u.mobile || "N/A",
			city: "Maharashtra",
			trade: u.role === "worker" ? "Worker" : u.role === "employer" ? "Employer" : "Admin",
			status: "Verified"
		})));
	};
	(0, import_react.useEffect)(() => {
		loadAllData();
	}, []);
	const handleUpdateAppStatus = (appId, status) => {
		dataStore.updateApplicationStatus(appId, status);
		setApplications(dataStore.getAllApplications());
		toast.success(`अर्जाची स्थिती '${status}' वर बदलली!`);
	};
	const [showJobForm, setShowJobForm] = (0, import_react.useState)(false);
	const [editingJobId, setEditingJobId] = (0, import_react.useState)(null);
	const [jobForm, setJobForm] = (0, import_react.useState)({
		title: "",
		company: "REAL JOB Platform",
		category: "",
		location: "",
		salaryMin: "",
		salaryMax: "",
		salaryType: "Monthly",
		jobType: "Full Time",
		workMode: "On-site",
		vacancies: "5",
		education: "",
		experience: "",
		skills: "",
		description: "",
		responsibilities: "",
		benefits: "",
		status: "Active"
	});
	const setJ = (k, v) => setJobForm((p) => ({
		...p,
		[k]: v
	}));
	const handleAddNewJobClick = () => {
		setEditingJobId(null);
		setJobForm({
			title: "",
			company: "REAL JOB Platform",
			category: "",
			location: "",
			salaryMin: "",
			salaryMax: "",
			salaryType: "Monthly",
			jobType: "Full Time",
			workMode: "On-site",
			vacancies: "5",
			education: "",
			experience: "",
			skills: "",
			description: "",
			responsibilities: "",
			benefits: "",
			status: "Active"
		});
		setShowJobForm(true);
	};
	const handleEditJobClick = (job) => {
		setEditingJobId(job.id);
		let sMin = job.salaryMin ? String(job.salaryMin) : "";
		let sMax = job.salaryMax ? String(job.salaryMax) : "";
		if (!sMin && !sMax && job.salary) {
			const numbers = job.salary.match(/\d[\d,]*/g);
			if (numbers && numbers.length >= 2 && numbers[0] && numbers[1]) {
				sMin = numbers[0].replace(/,/g, "");
				sMax = numbers[1].replace(/,/g, "");
			}
		}
		setJobForm({
			title: job.title || "",
			company: job.company || "",
			category: job.category || "",
			location: job.location || "",
			salaryMin: sMin,
			salaryMax: sMax,
			salaryType: job.salaryType || "Monthly",
			jobType: job.jobType || "Full Time",
			workMode: job.workMode || "On-site",
			vacancies: job.vacancies ? String(job.vacancies) : "5",
			education: job.qualification || "",
			experience: job.experience || "",
			skills: (job.requiredSkills || []).join(", "),
			description: job.description || "",
			responsibilities: (job.responsibilities || []).join("\n"),
			benefits: (job.benefits || []).join(", "),
			status: job.status || "Active"
		});
		setShowJobForm(true);
	};
	const handlePublishJob = (e) => {
		e.preventDefault();
		const salaryText = jobForm.salaryMin && jobForm.salaryMax ? `₹${Number(jobForm.salaryMin).toLocaleString("en-IN")} - ₹${Number(jobForm.salaryMax).toLocaleString("en-IN")} / ${jobForm.salaryType === "Monthly" ? "Month" : "Year"}` : "Salary on Interview";
		if (editingJobId) {
			dataStore.updateJob(editingJobId, {
				title: jobForm.title,
				company: jobForm.company,
				category: jobForm.category || "General",
				description: jobForm.description,
				qualification: jobForm.education,
				experience: jobForm.experience,
				salary: salaryText,
				salaryMin: Number(jobForm.salaryMin) || 0,
				salaryMax: Number(jobForm.salaryMax) || 0,
				salaryType: jobForm.salaryType,
				location: jobForm.location,
				jobType: jobForm.jobType,
				workMode: jobForm.workMode,
				vacancies: Number(jobForm.vacancies) || 1,
				status: jobForm.status
			});
			toast.success("✅ नोकरीची माहिती यशस्वीरित्या अद्ययावत (Updated) झाली!");
		} else {
			dataStore.createJob({
				employerId: "admin-001",
				title: jobForm.title,
				company: jobForm.company,
				category: jobForm.category || "General",
				subcategory: "",
				description: jobForm.description,
				responsibilities: [],
				requiredSkills: [],
				qualification: jobForm.education,
				experience: jobForm.experience,
				salary: salaryText,
				salaryMin: Number(jobForm.salaryMin) || 0,
				salaryMax: Number(jobForm.salaryMax) || 0,
				salaryType: jobForm.salaryType,
				location: jobForm.location,
				jobType: jobForm.jobType,
				workMode: jobForm.workMode,
				vacancies: Number(jobForm.vacancies) || 1,
				benefits: [],
				status: jobForm.status
			});
			toast.success("✅ नवीन नोकरी यशस्वीरित्या प्रकाशित झाली!");
		}
		setShowJobForm(false);
		setEditingJobId(null);
		setJobs(dataStore.getAllJobs());
	};
	const handleToggleJobStatus = (jobId, currentStatus) => {
		const nextStatus = currentStatus === "Active" ? "Closed" : "Active";
		dataStore.updateJob(jobId, { status: nextStatus });
		setJobs((prev) => prev.map((j) => j.id === jobId ? {
			...j,
			status: nextStatus
		} : j));
		toast.success(`Job status updated to ${nextStatus}!`);
	};
	const handleDeleteJob = (jobId) => {
		dataStore.deleteJob(jobId);
		setJobs((prev) => prev.filter((j) => j.id !== jobId));
		toast.success("Job posting removed by Admin!");
	};
	const filteredJobs = jobs.filter((j) => j.title.toLowerCase().includes(jobSearch.toLowerCase()) || j.company.toLowerCase().includes(jobSearch.toLowerCase()) || j.location.toLowerCase().includes(jobSearch.toLowerCase()));
	if (showJobForm) {
		const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "fixed inset-0 z-50 bg-[#F0F4FA] overflow-y-auto flex flex-col",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-[#021D3D] text-white px-6 py-4 flex items-center justify-between border-b border-[#0A4F9E] sticky top-0 z-10 shadow-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setShowJobForm(false),
						className: "px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-bold transition-all flex items-center gap-1",
						children: "← मागे जा (Back)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-base font-black text-white",
						children: editingJobId ? "✏️ नोकरीची माहिती संपादीत करा (Edit Job Posting)" : "💼 नवीन नोकरी पोस्ट करा (Post New Job)"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-bold text-[#FFC400] bg-white/10 px-3 py-1 rounded-full",
					children: "100% नि:शुल्क व थेट नोकरी (Zero Commission)"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-5xl w-full mx-auto p-4 sm:p-8 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bg-white rounded-2xl p-4 border border-[#E0E8F5] shadow-sm mb-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between text-xs font-black text-[#063B78]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-5 rounded-full bg-[#063B78] text-white flex items-center justify-center text-[10px]",
									children: "1"
								}), " Basic Details"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[#9DAEC5]",
								children: "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-5 rounded-full bg-[#063B78] text-white flex items-center justify-center text-[10px]",
									children: "2"
								}), " Requirements"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[#9DAEC5]",
								children: "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-5 rounded-full bg-[#063B78] text-white flex items-center justify-center text-[10px]",
									children: "3"
								}), " Salary & Work"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[#9DAEC5]",
								children: "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-5 rounded-full bg-[#063B78] text-white flex items-center justify-center text-[10px]",
									children: "4"
								}), " Preferences"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[#9DAEC5]",
								children: "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-5 rounded-full bg-[#063B78] text-white flex items-center justify-center text-[10px]",
									children: "5"
								}), " Application"]
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handlePublishJob,
					className: "space-y-6 pb-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm overflow-hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 px-5 py-3 bg-[#F8FAFF] border-b border-[#E0E8F5]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-7 rounded-xl bg-[#063B78] text-white flex items-center justify-center text-xs font-black",
									children: "1"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-black text-[#10233F]",
									children: "Basic Job Details"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-5 space-y-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Company Name *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											required: true,
											value: jobForm.company,
											onChange: (e) => setJ("company", e.target.value),
											placeholder: "e.g. Tata Motors / Real Job Platform",
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Job Title *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											required: true,
											value: jobForm.title,
											onChange: (e) => setJ("title", e.target.value),
											placeholder: "e.g. Senior CNC Machine Operator",
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Category *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											required: true,
											value: jobForm.category,
											onChange: (e) => setJ("category", e.target.value),
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "",
													children: "Select Category"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Manufacturing & Industrial" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Construction & Building" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Healthcare & Nursing" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Logistics & Transport" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Engineering & Technical" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Retail & Sales" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Hotel & Hospitality" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Security & Services" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "General Worker" })
											]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Location (City/District) *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											required: true,
											value: jobForm.location,
											onChange: (e) => setJ("location", e.target.value),
											placeholder: "e.g. Chakan, Pune / MIDC Kolhapur",
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
										children: "Job Description *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										required: true,
										rows: 3,
										value: jobForm.description,
										onChange: (e) => setJ("description", e.target.value),
										placeholder: "Describe main duties, responsibilities, work schedule, shift timings...",
										className: "w-full p-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
									})] })
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm overflow-hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 px-5 py-3 bg-[#F8FAFF] border-b border-[#E0E8F5]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-7 rounded-xl bg-[#063B78] text-white flex items-center justify-center text-xs font-black",
									children: "2"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-black text-[#10233F]",
									children: "Candidate Requirements"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "p-5 space-y-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
										children: "Education Required *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: jobForm.education,
										onChange: (e) => setJ("education", e.target.value),
										className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "",
												children: "Select Education"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "10th Pass" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "12th Pass" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "ITI Diploma" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Polytechnic Diploma" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Graduate / BE / B.Tech" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Post Graduate" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "No Formal Education Required" })
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
										children: "Experience Required *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: jobForm.experience,
										onChange: (e) => setJ("experience", e.target.value),
										className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "",
												children: "Select Experience"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Fresher (0 Years)" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "1 - 2 Years" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "3 - 5 Years" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "5 - 8 Years" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "8+ Years" })
										]
									})] })]
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm overflow-hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 px-5 py-3 bg-[#F8FAFF] border-b border-[#E0E8F5]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-7 rounded-xl bg-[#063B78] text-white flex items-center justify-center text-xs font-black",
									children: "3"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-black text-[#10233F]",
									children: "Salary & Work Details"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-5 space-y-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Min Salary (₹)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											value: jobForm.salaryMin,
											onChange: (e) => setJ("salaryMin", e.target.value),
											placeholder: "e.g. 18000",
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Max Salary (₹)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											value: jobForm.salaryMax,
											onChange: (e) => setJ("salaryMax", e.target.value),
											placeholder: "e.g. 25000",
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Salary Period"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											value: jobForm.salaryType,
											onChange: (e) => setJ("salaryType", e.target.value),
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "Monthly",
													children: "Per Month (दरमहा)"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "Daily",
													children: "Per Day (दररोज)"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "Yearly",
													children: "Per Year (वार्षिक)"
												})
											]
										})] })
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Job Type *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											value: jobForm.jobType,
											onChange: (e) => setJ("jobType", e.target.value),
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Full Time" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Part Time" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Contract" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Daily Wage" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Internship" })
											]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Work Mode *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											value: jobForm.workMode,
											onChange: (e) => setJ("workMode", e.target.value),
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "On-site" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Work From Home" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Hybrid" })
											]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "No. of Openings *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											required: true,
											type: "number",
											min: "1",
											value: jobForm.vacancies,
											onChange: (e) => setJ("vacancies", e.target.value),
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
										})] })
									]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm overflow-hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 px-5 py-3 bg-[#F8FAFF] border-b border-[#E0E8F5]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-7 rounded-xl bg-[#063B78] text-white flex items-center justify-center text-xs font-black",
									children: "4"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-black text-[#10233F]",
									children: "Preferences & Benefits"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "p-5 space-y-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Gender Preference"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											value: jobForm.genderPreference || "Any",
											onChange: (e) => setJ("genderPreference", e.target.value),
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "Any",
													children: "Any (पुरुष व महिला दोन्ही)"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "Male",
													children: "Male Only (केवळ पुरुष)"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "Female",
													children: "Female Only (केवळ महिला)"
												})
											]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Age Limit (Optional)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "number",
													value: jobForm.ageMin || "",
													onChange: (e) => setJ("ageMin", e.target.value),
													placeholder: "Min Age",
													className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold focus:outline-none focus:border-[#063B78]"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[#9DAEC5] font-bold shrink-0",
													children: "–"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "number",
													value: jobForm.ageMax || "",
													onChange: (e) => setJ("ageMax", e.target.value),
													placeholder: "Max Age",
													className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold focus:outline-none focus:border-[#063B78]"
												})
											]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Languages Required"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: jobForm.languages || "",
											onChange: (e) => setJ("languages", e.target.value),
											placeholder: "e.g. English, Hindi, Marathi",
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
										})] })
									]
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm overflow-hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 px-5 py-3 bg-[#F8FAFF] border-b border-[#E0E8F5]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-7 rounded-xl bg-[#063B78] text-white flex items-center justify-center text-xs font-black",
									children: "5"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-black text-[#10233F]",
									children: "Application Details"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "p-5 space-y-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-4 gap-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Application Deadline *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											required: true,
											type: "date",
											min: today,
											value: jobForm.deadline || "",
											onChange: (e) => setJ("deadline", e.target.value),
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Application Method *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											value: jobForm.applicationMethod || "",
											onChange: (e) => setJ("applicationMethod", e.target.value),
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "",
													children: "Select Method"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Apply via Portal" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Apply via WhatsApp" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Walk-in Interview" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Call to Apply" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Email CV" })
											]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Recruiter Email *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "email",
											value: jobForm.recruiterEmail || "",
											onChange: (e) => setJ("recruiterEmail", e.target.value),
											placeholder: "e.g. recruiter@company.com",
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Recruiter Phone (Optional)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "tel",
											value: jobForm.recruiterPhone || "",
											onChange: (e) => setJ("recruiterPhone", e.target.value),
											placeholder: "e.g. 98765 43210",
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
										})] })
									]
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white rounded-2xl border border-[#E0E8F5] px-6 py-4 flex items-center justify-between sticky bottom-0 shadow-lg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-[#9DAEC5] font-semibold",
								children: "* Required fields must be filled before submitting"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setShowJobForm(false),
									className: "px-5 py-2.5 rounded-xl border border-[#DCE5F0] text-xs font-bold text-[#5B6B7F] hover:bg-[#F5F8FC] transition-all",
									children: "रद्द करा (Cancel)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									className: "px-7 py-2.5 rounded-xl bg-gradient-to-r from-[#063B78] to-[#0A4F9E] text-white font-black text-xs hover:opacity-90 transition-all shadow-md shadow-[#063B78]/20 flex items-center gap-1.5",
									children: editingJobId ? "✦ माहिती अद्ययावत करा (Update Job)" : "✦ नोकरी प्रकाशित करा (Publish Job)"
								})]
							})]
						})
					]
				})]
			})]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-[#F0F4FA]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "sticky top-0 z-40 bg-gradient-to-r from-[#021D3D] via-[#063B78] to-[#0A4F9E] text-white shadow-xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-0.5 w-full bg-gradient-to-r from-[#FFC400] via-[#FFD84D] to-[#FFA500]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col items-center justify-center size-10 rounded-xl bg-white shadow-md shrink-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[9px] font-black text-[#063B78] leading-none",
								children: "REAL"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[9px] font-black text-[#FFC400] leading-none",
								children: "JOB"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hidden sm:block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-black text-white leading-tight",
								children: "REAL JOB"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5 text-[10px] font-bold text-[#FFC400]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3" }), "ॲडमिन कंट्रोल पोर्टल"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hidden md:block w-px h-8 bg-white/20 mx-2" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 border border-white/20 text-[10px] font-black text-white",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-emerald-400 animate-pulse" }), "Super Admin Control"]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 sm:gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "ghost",
						size: "sm",
						className: "hidden sm:flex border border-white/30 text-white hover:bg-white/15 font-bold text-xs h-8 px-3 rounded-lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/home",
							children: "🌐 मुख्य साईट"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => {
							window.localStorage.removeItem("realjob-user");
							toast.info("Logged out from Admin Dashboard");
							navigate({ to: "/" });
						},
						size: "sm",
						className: "bg-red-500 hover:bg-red-600 text-white font-extrabold text-xs h-8 px-3 rounded-lg shadow-md",
						children: "लॉग आउट"
					})]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-[#DCE5F0] shadow-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-2 rounded-full bg-[#063B78]/10 px-3 py-1 text-xs font-black text-[#063B78] mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-emerald-500 animate-pulse" }), "REAL JOB PLATFORM SYSTEM ONLINE"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-2xl sm:text-3xl font-black text-[#10233F]",
							children: "ॲडमिन कंट्रोल सेंटर (Admin Control Dashboard)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs sm:text-sm font-semibold text-[#5B6B7F] mt-1",
							children: "कामकूट, नवीन नोकऱ्या, कामगार पडताळणी आणि अर्ज व्यवस्थापन नियंत्रण करा."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: handleAddNewJobClick,
							className: "btn-yellow text-xs font-black px-4 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 mr-1" }), " नवीन जॉब जोडा (Add New Job)"]
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap items-center gap-2 mb-8 pb-3 border-b border-[#DCE5F0]",
					children: [
						{
							id: "overview",
							label: "सारांश (Overview)",
							icon: ChartColumn
						},
						{
							id: "jobs",
							label: "नोकरी पोस्टिंग्स (Jobs)",
							icon: BriefcaseBusiness
						},
						{
							id: "applications",
							label: `अर्ज आलेले कामगार (${applications.length})`,
							icon: FileText
						}
					].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setActiveTab(t.id),
						className: `flex items-center gap-2 px-4 py-2.5 rounded-xl font-extrabold text-xs transition-all ${activeTab === t.id ? "bg-[#063B78] text-white shadow-md shadow-[#063B78]/20" : "bg-white text-[#5B6B7F] border border-[#DCE5F0] hover:bg-[#EBF1F8] hover:text-[#063B78]"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(t.icon, { className: "size-4 shrink-0" }), t.label]
					}, t.id))
				}),
				activeTab === "overview" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
								label: "एकूण नोंदणीकृत कामगार (Total Registered Workers)",
								value: registeredUsers.filter((u) => u.role === "worker").length.toString(),
								change: "थेट नोंदणीकृत कामगार",
								icon: Users
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
								label: "सक्रिय नोकऱ्या (Active Jobs)",
								value: jobs.filter((j) => j.status === "Active").length.toString(),
								change: "थेट प्लॅटफॉर्मवर",
								icon: BriefcaseBusiness
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
								label: "एकूण आलेले अर्ज (Total Applications)",
								value: applications.length.toString(),
								change: "थेट कामगारांचे अर्ज",
								icon: FileText
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-6 lg:grid-cols-[1.4fr_1fr]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-[#DCE5F0] bg-white p-6 shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-lg font-black text-[#10233F]",
									children: "प्लॅटफॉर्म वाढ आणि नोकरी अर्ज (Platform Growth & Applications)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold text-[#5B6B7F]",
									children: "महिनानिहाय कामगार नोंदणी आणि भरती डेटा"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									className: "bg-[#063B78] text-white font-bold",
									children: "2026 Live"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-72",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
									width: "100%",
									height: "100%",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
										data: monthlyAnalytics,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("defs", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
												id: "colorWorkers",
												x1: "0",
												y1: "0",
												x2: "0",
												y2: "1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "5%",
													stopColor: "#063B78",
													stopOpacity: .8
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "95%",
													stopColor: "#063B78",
													stopOpacity: 0
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
												id: "colorJobs",
												x1: "0",
												y1: "0",
												x2: "0",
												y2: "1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "5%",
													stopColor: "#FFC400",
													stopOpacity: .8
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "95%",
													stopColor: "#FFC400",
													stopOpacity: 0
												})]
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
												strokeDasharray: "3 3",
												vertical: false
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, { dataKey: "month" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
												type: "monotone",
												dataKey: "workers",
												stroke: "#063B78",
												fillOpacity: 1,
												fill: "url(#colorWorkers)",
												name: "Workers"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
												type: "monotone",
												dataKey: "jobs",
												stroke: "#FFC400",
												fillOpacity: 1,
												fill: "url(#colorJobs)",
												name: "Jobs"
											})
										]
									})
								})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-[#DCE5F0] bg-white p-6 shadow-sm space-y-6 flex flex-col justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-lg font-black text-[#10233F]",
								children: "त्वरित कृती (Quick Controls)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold text-[#5B6B7F] mt-1",
								children: "जॉब लिस्ट व अर्जांचे नियंत्रण करण्यासाठी खालील बटन्स वापरा."
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										onClick: handleAddNewJobClick,
										className: "w-full btn-yellow text-xs font-black py-3",
										children: "+ नवीन जॉब पोस्ट करा (Post New Job)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										onClick: () => setActiveTab("jobs"),
										variant: "outline",
										className: "w-full border-[#063B78] text-[#063B78] font-bold text-xs py-3",
										children: "💼 सर्व जॉब पोस्टिंग्स नियंत्रण"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										onClick: () => setActiveTab("applications"),
										variant: "outline",
										className: "w-full border-[#063B78] text-[#063B78] font-bold text-xs py-3",
										children: [
											"📄 आलेले सर्व कामगार अर्ज पहा (",
											applications.length,
											")"
										]
									})
								]
							})]
						})]
					})]
				}),
				activeTab === "jobs" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white p-6 rounded-2xl border border-[#DCE5F0] shadow-sm space-y-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-black text-[#10233F]",
							children: "नोकरी पोस्टिंग्स नियंत्रण (All Platform Job Listings)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-semibold text-[#5B6B7F]",
							children: [
								"एकूण ",
								jobs.length,
								" नोकऱ्या उपलब्ध आहेत. माहिती अपडेट करा किंवा डिलीट करा."
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "w-full sm:w-72 relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-3 size-4 text-[#5B6B7F]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "नोकरी / कंपनी / शहर शोधा...",
								value: jobSearch,
								onChange: (e) => setJobSearch(e.target.value),
								className: "pl-9 text-xs font-bold"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto rounded-xl border border-[#DCE5F0]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-left text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "bg-[#063B78] text-white font-black uppercase",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5",
										children: "नोकरी शीर्षक (Title)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5",
										children: "कंपनी (Company)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5",
										children: "ठिकाण & पगार (Location & Salary)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5",
										children: "जागा (Vacancies)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5",
										children: "स्थिती (Status)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5 text-right",
										children: "कृती (Actions)"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
								className: "divide-y divide-[#DCE5F0] font-semibold text-[#10233F]",
								children: [filteredJobs.map((j) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "hover:bg-[#F5F8FC]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "p-3.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "block font-black text-[#063B78]",
												children: j.title
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[11px] text-[#5B6B7F]",
												children: j.category
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3.5 font-bold",
											children: j.company
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "p-3.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: j.location }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[#125BB5] font-bold",
												children: j.salary
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "p-3.5 font-black text-[#063B78]",
											children: [j.vacancies || 5, " Openings"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												className: j.status === "Active" ? "bg-emerald-600 text-white font-bold" : "bg-gray-500 text-white font-bold",
												children: j.status
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3.5 text-right",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-end gap-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
														size: "sm",
														onClick: () => {
															setFilterJobId(j.id);
															setActiveTab("applications");
														},
														className: "bg-[#063B78] text-white font-extrabold text-[11px] hover:bg-[#0A4F9E]",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-3.5 mr-1" }),
															"अर्ज पहा (",
															applications.filter((a) => a.jobId === j.id).length,
															")"
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
														size: "sm",
														variant: "outline",
														onClick: () => handleEditJobClick(j),
														className: "font-extrabold text-[11px] border-[#063B78] text-[#063B78] hover:bg-[#F0F5FF]",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquarePen, { className: "size-3.5 mr-1" }), " एडिट (Edit)"]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														size: "sm",
														variant: "outline",
														onClick: () => handleToggleJobStatus(j.id, j.status),
														className: "font-extrabold text-[11px] border-gray-400 text-gray-700",
														children: j.status === "Active" ? "बंद करा (Close)" : "सुरू करा (Activate)"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														size: "sm",
														variant: "ghost",
														onClick: () => handleDeleteJob(j.id),
														className: "text-red-600 hover:bg-red-50",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
													})
												]
											})
										})
									]
								}, j.id)), filteredJobs.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									colSpan: 6,
									className: "p-8 text-center text-xs font-bold text-[#5B6B7F] bg-[#F8FAFF]",
									children: "अद्याप एकही नोकरी पोस्ट केलेली नाही. (No jobs posted yet)"
								}) })]
							})]
						})
					})]
				}),
				activeTab === "applications" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white p-6 rounded-2xl border border-[#DCE5F0] shadow-sm space-y-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-black text-[#10233F]",
							children: "नोकरीसाठी आलेले अर्ज (Job Applications & Applicants)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-semibold text-[#5B6B7F]",
							children: [
								"एकूण ",
								applications.length,
								" कामगारांनी नोकरीसाठी अर्ज केले आहेत. थेट संपर्क करा किंवा स्थिती बदला."
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-3 w-full sm:w-auto",
							children: [filterJobId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => setFilterJobId(null),
								className: "text-xs font-bold border-[#063B78] text-[#063B78]",
								children: "✕ सर्व जॉब्जचे अर्ज दाखवा"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "w-full sm:w-64 relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-3 size-4 text-[#5B6B7F]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "उमेदवार नाव / नोकरी / संपर्क शोधा...",
									value: appSearch,
									onChange: (e) => setAppSearch(e.target.value),
									className: "pl-9 text-xs font-bold"
								})]
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto rounded-xl border border-[#DCE5F0]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-left text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "bg-[#063B78] text-white font-black uppercase",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5",
										children: "उमेदवार नाव (Applicant Name)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5",
										children: "अर्ज केलेली नोकरी (Applied Job)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5",
										children: "संपर्क पर्याय (Direct Contact)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5",
										children: "अर्जाची तारीख (Applied Date)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5",
										children: "सध्याची स्थिती (Status)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5 text-right",
										children: "संपर्क क्र. (Mobile)"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
								className: "divide-y divide-[#DCE5F0] font-semibold text-[#10233F]",
								children: [applications.filter((a) => !filterJobId || a.jobId === filterJobId).filter((a) => a.candidateName.toLowerCase().includes(appSearch.toLowerCase()) || a.jobTitle.toLowerCase().includes(appSearch.toLowerCase()) || a.candidateMobile.toLowerCase().includes(appSearch.toLowerCase())).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "hover:bg-[#F5F8FC]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "p-3.5 font-black text-[#063B78]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: a.candidateName }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[11px] text-[#5B6B7F] font-normal",
												children: a.candidateEmail
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "p-3.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "font-bold text-[#10233F]",
												children: a.jobTitle
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-[11px] text-[#125BB5]",
												children: [
													a.companyName || "Company",
													" • ",
													a.location
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: `tel:${a.candidateMobile}`,
													className: "px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold text-[10px] hover:bg-emerald-700 transition-all flex items-center gap-1",
													children: "📞 कॉल करा"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: `https://wa.me/${a.candidateMobile.replace(/\D/g, "")}`,
													target: "_blank",
													rel: "noreferrer",
													className: "px-2.5 py-1 rounded-lg bg-green-600 text-white font-bold text-[10px] hover:bg-green-700 transition-all flex items-center gap-1",
													children: "💬 WhatsApp"
												})]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3.5 text-[#5B6B7F] font-bold",
											children: a.appliedDate
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
												value: a.status,
												onChange: (e) => handleUpdateAppStatus(a.id, e.target.value),
												className: "h-8 px-2 rounded-lg border border-[#DCE5F0] text-xs font-black focus:outline-none focus:border-[#063B78]",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "Applied",
														children: "📝 Applied"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "Viewed",
														children: "👀 Viewed"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "Shortlisted",
														children: "⭐ Shortlisted"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "Interview",
														children: "📅 Interview Scheduled"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "Selected",
														children: "✅ Selected / Hired"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "Rejected",
														children: "❌ Rejected"
													})
												]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3.5 text-right font-bold text-[#063B78]",
											children: a.candidateMobile
										})
									]
								}, a.id)), applications.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									colSpan: 6,
									className: "p-8 text-center text-xs font-bold text-[#5B6B7F] bg-[#F8FAFF]",
									children: "अद्याप कोणत्याही कामगाराने अर्ज केलेला नाही (No job applications received yet)"
								}) })]
							})]
						})
					})]
				})
			]
		})]
	});
}
var $$splitComponentImporter$23 = () => import("./categories-B_DOguZ5.mjs");
var Route$30 = createFileRoute("/categories")({
	head: () => ({ meta: [{ title: "Job Categories — REAL JOB | Find Work | Find Workers" }, {
		name: "description",
		content: "Explore all 20 main job categories on REAL JOB — Construction, IT, Engineering, Medical, Finance, Sales, Education & more."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$23, "component")
});
var $$splitComponentImporter$22 = () => import("./contact-JkdlU5aS.mjs");
var Route$29 = createFileRoute("/contact")({
	head: () => ({ meta: [{ title: "Contact Us — REAL JOB | Find Work | Find Workers" }, {
		name: "description",
		content: "Contact REAL JOB support team for worker registration, employer hiring assistance, or job postings."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$22, "component")
});
var Route$28 = createFileRoute("/faq")({
	head: () => ({ meta: [{ title: "Frequently Asked Questions (FAQ) — REAL JOB" }, {
		name: "description",
		content: "Find answers to all questions about finding jobs, hiring workers, account setup, and verification on REAL JOB."
	}] }),
	component: FAQPage
});
var faqList = [
	{
		category: "worker",
		questions: {
			en: "How do I apply for jobs on REAL JOB?",
			mr: "REAL JOB वर काम किंवा नोकरीसाठी अर्ज कसा करावा?",
			hi: "REAL JOB पर नौकरी के लिए आवेदन कैसे करें?",
			gu: "REAL JOB પર કામ માટે અરજી કેવી રીતે કરવી?",
			kn: "REAL JOB ನಲ್ಲಿ ಕೆಲಸಕ್ಕೆ ಅರ್ಜಿ ಸಲ್ಲಿಸುವುದು ಹೇಗೆ?",
			te: "REAL JOB లో పనికి దరఖాస్తు చేసుకోవడం ఎలా?",
			ta: "REAL JOB-ல் வேலைக்கு விண்ணப்பிப்பது எப்படி?",
			bn: "REAL JOB-এ কাজের জন্য আবেদন কীভাবে করবেন?"
		},
		answers: {
			en: "Simply search for jobs according to your skill or location, click on 'Apply Now' or 'Direct Call', and contact the employer directly without any middleman fees.",
			mr: "तुमचे कौशल्य किंवा शहरानुसार नोकरी शोधा, 'Apply Now' किंवा 'कॉल करा' वर क्लिक करा आणि थेट मालकाशी विनामूल्य बोला.",
			hi: "अपने कौशल या शहर के अनुसार नौकरी खोजें, 'आवेदन करें' या 'सीधा कॉल करें' पर क्लिक करें और नियोक्ताओं से मुफ्त में बात करें।",
			gu: "તમારા કૌશલ્ય અથવા શહેર મુજબ કામ શોધો, 'અરજી કરો' પર ક્લિક કરો અને સીધા માલિક સાથે વાત કરો.",
			kn: "ನಿಮ್ಮ ಕೌಶಲ್ಯ ಅಥವಾ ನಗರಕ್ಕೆ ತಕ್ಕಂತೆ ಕೆಲಸ ಹುಡುಕಿ, 'ಅರ್ಜಿ ಸಲ್ಲಿಸಿ' ಕ್ಲಿಕ್ ಮಾಡಿ ಮತ್ತು ಮಾಲೀಕರೊಂದಿಗೆ ನೇರವಾಗಿ ಮಾತನಾಡಿ.",
			te: "మీ నైపుణ్యం లేదా నగరం ప్రకారం పనిని వెతికి, 'అప్లై చేయండి' పై క్లిక్ చేసి యజమానితో నేరుగా మాట్లాడండి.",
			ta: "உங்கள் திறமை அல்லது நகரத்திற்கு ஏற்ப வேலை தேடி, 'விண்ணப்பிக்கவும்' கிளிக் செய்து முதலாளியிடம் நேரடியாகப் பேசுங்கள்.",
			bn: "আপনার দক্ষতা বা শহর অনুযায়ী কাজ খুঁজুন, 'আবেদন করুন' বা 'সরাসরি কল' অপশনে ক্লিক করে কথা বলুন।"
		}
	},
	{
		category: "worker",
		questions: {
			en: "Is there any registration fee for job seekers?",
			mr: "कामगारांसाठी नोंदणी शुल्क आहे का?",
			hi: "क्या कामगारों के लिए कोई पंजीकरण शुल्क है?",
			gu: "શું કારીગરો માટે કોઈ રજિસ્ટ્રેશન ફી છે?",
			kn: "ಕಾರ್ಮಿಕರಿಗೆ ಯಾವುದೇ ನೋಂದಣಿ ಶುಲ್ಕವಿದೆಯೇ?",
			te: "కార్మికులకు ఏమైనా రిజిస్ట్రేషన్ ఫీజు ఉందా?",
			ta: "தொழிலாளர்களுக்கு ஏதேனும் பதிவுக் கட்டணம் உள்ளதா?",
			bn: "কর্মীদের জন্য কোনো রেজিস্ট্রেশন ফি আছে কি?"
		},
		answers: {
			en: "No! REAL JOB is 100% free for workers and job seekers. We never charge any commission or placement fees.",
			mr: "नाही! कामगारांसाठी REAL JOB संपूर्ण मोफत आहे. आम्ही कोणतेही कमिशन किंवा फी घेत नाही.",
			hi: "नहीं! कामगारों के लिए REAL JOB 100% मुफ्त है। हम कभी कोई कमीशन या फीस नहीं लेते।",
			gu: "ના! કારીગરો માટે REAL JOB ૧૦૦% મફત છે. અમે કોઈ કમિશન લેતા નથી.",
			kn: "ಇಲ್ಲ! ಕಾರ್ಮಿಕರಿಗೆ REAL JOB ಸಂಪೂರ್ಣ ಉಚಿತವಾಗಿದೆ. ನಾವು ಯಾವುದೇ ಕಮಿಷನ್ ಪಡೆಯುವುದಿಲ್ಲ.",
			te: "లేదు! కార్మికులకు REAL JOB 100% ఉచితం. మేము ఎలాంటి కమిషన్ తీసుకోము.",
			ta: "இல்லை! தொழிலாளர்களுக்கு REAL JOB 100% இலவசம். நாங்கள் எந்த கமிஷனும் வாங்குவதில்லை.",
			bn: "না! কর্মীদের জন্য REAL JOB ১০০% বিনামূল্যে। আমরা কোনো কমিশন নেই না।"
		}
	},
	{
		category: "worker",
		questions: {
			en: "What types of jobs are available on REAL JOB?",
			mr: "कोणत्या प्रकारच्या नोकऱ्या उपलब्ध आहेत?",
			hi: "REAL JOB पर किस प्रकार की नौकरियां उपलब्ध हैं?",
			gu: "REAL JOB પર કેવા પ્રકારના કામ ઉપલબ્ધ છે?",
			kn: "REAL JOB ನಲ್ಲಿ ಯಾವ ರೀತಿಯ ಕೆಲಸಗಳು ಲಭ್ಯವಿವೆ?",
			te: "REAL JOB లో ఎలాంటి పనులు అందుబాటులో ఉన్నాయి?",
			ta: "REAL JOB-ல் என்னென்ன வகையான வேலைகள் உள்ளன?",
			bn: "REAL JOB-এ কী ধরনের কাজ পাওয়া যায়?"
		},
		answers: {
			en: "We list factory operators, construction workers, electricians, turners, CNC machine operators, drivers, welders, masons, warehouse staff, security guards, and hotel/restaurant staff.",
			mr: "कारखाना कामगार, बांधकाम कामगार, इलेक्ट्रीशियन, वेल्डर, फॅक्टरी ऑपरेटर, ड्रायव्हर, वेअरहाउस स्टाफ, सुरक्षा रक्षक व हॉटेल स्टाफच्या नोकऱ्या उपलब्ध आहेत.",
			hi: "फैक्टरी ऑपरेटर, निर्माण मजदूर, इलेक्ट्रीशियन, वेल्डर, सीएनसी ऑपरेटर, ड्राइवर, सुरक्षा गार्ड और होटल स्टाफ की नौकरियां उपलब्ध हैं।",
			gu: "ફેક્ટરી કારીગર, બાંધકામ મજૂર, ઇલેક્ટ્રિશિયન, ડ્રાઇવર અને સિક્યુરિટી ગાર્ડના કામ ઉપલબ્ધ છે.",
			kn: "ಫ್ಯಾಕ್ಟರಿ ಕಾರ್ಮಿಕರು, ನಿರ್ಮಾಣ ಕಾರ್ಮಿಕರು, ಎಲೆಕ್ಟ್ರಿಷಿಯನ್, ಚಾಲಕರು ಮತ್ತು ಸೆಕ್ಯುರಿಟಿ ಗಾರ್ಡ್ ಕೆಲಸಗಳು ಲಭ್ಯವಿವೆ.",
			te: "ఫ్యాక్టరీ కార్మికులు, బిల్డింగ్ వర్కర్లు, ఎలక్ట్రీషియన్లు, డ్రైవర్లు మరియు సెక్యూరిటీ గార్డుల పనులు అందుబాటులో ఉన్నాయి.",
			ta: "ஃபேக்டரி ஊழியர்கள், கட்டுமானத் தொழிலாளர்கள், எலக்ட்ரீஷியன்கள், டிரைவர்கள் மற்றும் செக்யூரிட்டி கார்டு வேலைகள் உள்ளன.",
			bn: "ফ্যাক্টরি শ্রমিক, নির্মাণ শ্রমিক, ইলেকট্রিশিয়ান, ড্রাইভার ও সিকিউরিটি গার্ডের কাজ পাওয়া যায়।"
		}
	},
	{
		category: "employer",
		questions: {
			en: "How can employers post a job on REAL JOB?",
			mr: "मालक किंवा कंपन्या नोकरी कशी पोस्ट करू शकतात?",
			hi: "नियोक्ता या कंपनियां नौकरी कैसे पोस्ट कर सकती हैं?",
			gu: "માલિકો કામ કેવી રીતે પોસ્ટ કરી શકે છે?",
			kn: "ಮಾಲೀಕರು ಕೆಲಸವನ್ನು ಪ್ರಕಟಿಸುವುದು ಹೇಗೆ?",
			te: "యజమానులు పనిని ఎలా పోస్ట్ చేయవచ్చు?",
			ta: "முதலாளிகள் வேலையை எவ்வாறு பதிவிடலாம்?",
			bn: "নিয়োগকর্তারা কীভাবে কাজ পোস্ট করতে পারেন?"
		},
		answers: {
			en: "Register as an Employer, go to your dashboard, click 'Post Job', fill in the job details, requirements, and salary, and publish it instantly.",
			mr: "मालक म्हणून नोंदणी करा, डॅशबोर्डवर 'Post Job' वर क्लिक करा, नोकरीची माहिती व पगार भरा आणि त्वरित पोस्ट करा.",
			hi: "नियोक्ता के रूप में पंजीकरण करें, डैशबोर्ड पर जाएं, 'नौकरी पोस्ट करें' पर क्लिक करें और विवरण भरकर प्रकाशित करें।",
			gu: "માલિક તરીકે રજિસ્ટર કરો, ડેશબોર્ડ પર 'કામ પોસ્ટ કરો' પર ક્લિક કરો અને વિગતો ભરો.",
			kn: "ಮಾಲೀಕರಾಗಿ ನೋಂದಾಯಿಸಿ, ಡ್ಯಾಶ್‌ಬೋರ್ಡ್‌ನಲ್ಲಿ 'ಕೆಲಸ ಪ್ರಕಟಿಸಿ' ಕ್ಲಿಕ್ ಮಾಡಿ ವಿವರಗಳನ್ನು ಭರ್ತಿ ಮಾಡಿ.",
			te: "యజమానిగా రిజిస్టర్ అవ్వండి, డాష్‌బోర్డ్‌లో 'పని పోస్ట్ చేయండి' పై క్లిక్ చేసి వివరాలు నింపండి.",
			ta: "முதலாளியாக பதிவு செய்து, டாஷ்போர்டில் 'வேலையைப் பதிவிடு' கிளிக் செய்து వివరங்களை நிரப்பவும்.",
			bn: "নিয়োগকারী হিসেবে রেজিস্টার করুন, ড্যাশবোর্ডে 'কাজ পোস্ট করুন' এ ক্লিক করে বিবরণ প্রদান করুন।"
		}
	},
	{
		category: "employer",
		questions: {
			en: "How do I search for verified workers directly?",
			mr: "मी थेट सत्यापित कामगार कसे शोधू शकतो?",
			hi: "मैं सीधे सत्यापित कामगार कैसे खोज सकता हूं?",
			gu: "હું સીધા ચકાસાયેલ કારીગરો કેવી રીતે શોધી શકું?",
			kn: "ಪರಿಶೀಲಿಸಿದ ಕಾರ್ಮಿಕರನ್ನು ನೇರವಾಗಿ ಹುಡುಕುವುದು ಹೇಗೆ?",
			te: "ధృవీకరించబడిన కార్మికులను ನೇరుగా ఎలా వెతకవచ్చు?",
			ta: "சரிபார்க்கப்பட்ட தொழிலாளர்களை நேரடியாக ఎలా தேடுவது?",
			bn: "যাচাইকৃত কর্মী কীভাবে সরাসরি খুঁজবেন?"
		},
		answers: {
			en: "Navigate to the 'Find Workers' tab, filter by skill, experience, location, and expected salary, and view verified worker profile cards to request hire.",
			mr: "'Find Workers' विभागामध्ये जाऊन कौशल्य, अनुभव आणि शहरानुसार कामगार फिल्टर करा आणि थेट फोनवर संपर्क साधा.",
			hi: "'कामगार खोजें' सेक्शन में जाएं, कौशल और शहर के अनुसार फिल्टर करें और प्रोफाइल देखकर सीधा संपर्क करें।",
			gu: "'કારીગર શોધો' વિભાગમાં જઈને કૌશલ્ય અને શહેર મુજબ ફિલ્ટર કરો અને સીધો સંપર્ક કરો.",
			kn: "'ಕಾರ್ಮಿಕರನ್ನು ಹುಡುಕಿ' ವಿಭಾಗಕ್ಕೆ ಹೋಗಿ ಕೌಶಲ್ಯ ಮತ್ತು ನಗರಕ್ಕೆ ತಕ್ಕಂತೆ ಫಿಲ್ಟರ್ ಮಾಡಿ ನೇರವಾಗಿ ಮಾತನಾಡಿ.",
			te: "'కార్మికులను వెతకండి' విభాగానికి వెళ్లి నైపుణ్యం మరియు నగరం ప్రకారం ఫిల్టర్ చేసి మాట్లాడండి.",
			ta: "'தொழிலாளர்களை தேடுங்கள்' பகுதிக்குச் சென்று திறன் மற்றும் நகரம் வாரியாகத் தேடிப் பேசுங்கள்.",
			bn: "'কর্মী খুঁজুন' বিভাগে গিয়ে দক্ষতা ও শহর অনুসারে ফিল্টার করে সরাসরি কথা বলুন।"
		}
	},
	{
		category: "account",
		questions: {
			en: "How do I change my language preferences?",
			mr: "मी भाषा बदलू शकतो का?",
			hi: "मैं भाषा कैसे बदल सकता हूं?",
			gu: "હું ભાષા કેવી રીતે બદલી શકું?",
			kn: "ನಾನು ಭಾಷೆಯನ್ನು ಬದಲಾಯಿಸುವುದು ಹೇಗೆ?",
			te: "నేను భాషను ఎలా మార్చగలను?",
			ta: "நான் மொழியை எவ்வாறு மாற்றுவது?",
			bn: "আমি কীভাবে ভাষা পরিবর্তন করব?"
		},
		answers: {
			en: "Use the language switcher dropdown in the top header menu to switch anytime between Marathi, Hindi, English, Gujarati, Kannada, Telugu, Tamil, and Bengali.",
			mr: "हेडरमधील 'Language' मेनू वापरून तुम्ही कधीही मराठी, हिंदी किंवा इंग्रजी भाषा निवडू शकता.",
			hi: "ऊपरी हेडर मेनू में 'Language' ड्रॉपडाउन का उपयोग करके आप कभी भी हिंदी, मराठी या अंग्रेजी भाषा चुन सकते हैं।",
			gu: "હેડરમાં 'Language' મેનૂનો ઉપયોગ કરીને તમે ગમે ત્યારે ભાષા બદલી શકો છો.",
			kn: "ಹೆಡರ್‌ನಲ್ಲಿರುವ 'Language' ಮೆನುವನ್ನು ಬಳಸಿ ನೀವು ಯಾವಾಗ ಬೇಕಾದರೂ ಭಾಷೆಯನ್ನು ಬದಲಾಯಿಸಬಹುದು.",
			te: "హెడర్‌లోని 'Language' మెనూని ఉపయోగించి మీరు ఎప్పుడైనా భాషను మార్చవచ్చు.",
			ta: "மேலே உள்ள 'Language' மெனுவைப் பயன்படுத்தி எப்போது வேண்டுமானாலும் மொழியை மாற்றலாம்.",
			bn: "উপরের 'Language' মেনু ব্যবহার করে আপনি যেকোনো সময় ভাষা পরিবর্তন করতে পারেন।"
		}
	}
];
function FAQPage() {
	const { t, lang } = useI18n();
	const [selectedCategory, setSelectedCategory] = (0, import_react.useState)("all");
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [openIndex, setOpenIndex] = (0, import_react.useState)(0);
	const getQuestion = (faq) => faq.questions[lang] || faq.questions["mr"] || faq.questions["en"] || "";
	const getAnswer = (faq) => faq.answers[lang] || faq.answers["mr"] || faq.answers["en"] || "";
	const filteredFaqs = faqList.filter((item) => {
		const matchesCategory = selectedCategory === "all" || item.category === selectedCategory;
		const q = getQuestion(item).toLowerCase();
		const a = getAnswer(item).toLowerCase();
		const matchesSearch = !searchQuery || q.includes(searchQuery.toLowerCase()) || a.includes(searchQuery.toLowerCase());
		return matchesCategory && matchesSearch;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "bg-[#F5F8FC] min-h-screen py-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-5xl px-4 sm:px-6 lg:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center max-w-2xl mx-auto mb-10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-flex items-center gap-2 rounded-full bg-[#063B78]/10 px-4 py-1.5 text-xs font-bold uppercase tracking-wider text-[#063B78] mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleQuestionMark, { className: "size-4 text-[#FFC400]" }), t("faqEyebrow")]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-3xl font-black text-[#10233F] sm:text-4xl",
								children: t("faqHeading")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm font-semibold text-[#5B6B7F]",
								children: t("faqSubheading")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 relative max-w-xl mx-auto",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-4 top-1/2 -translate-y-1/2 size-5 text-[#5B6B7F]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "text",
									placeholder: t("searchFaqPlaceholder"),
									value: searchQuery,
									onChange: (e) => setSearchQuery(e.target.value),
									className: "h-12 pl-12 bg-white border-[#DCE5F0] rounded-xl shadow-xs text-sm font-semibold focus-visible:ring-[#FFC400]"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap justify-center gap-2 mb-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setSelectedCategory("all"),
								className: `px-4 py-2 rounded-xl font-bold text-xs transition-all ${selectedCategory === "all" ? "bg-[#063B78] text-white shadow-md" : "bg-white text-[#10233F] border border-[#DCE5F0] hover:bg-[#EBF1F8]"}`,
								children: t("allFaqs")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setSelectedCategory("worker"),
								className: `px-4 py-2 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all ${selectedCategory === "worker" ? "bg-[#063B78] text-white shadow-md" : "bg-white text-[#10233F] border border-[#DCE5F0] hover:bg-[#EBF1F8]"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HardHat, { className: "size-4 text-[#FFC400]" }), t("workerFaqs")]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setSelectedCategory("employer"),
								className: `px-4 py-2 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all ${selectedCategory === "employer" ? "bg-[#063B78] text-white shadow-md" : "bg-white text-[#10233F] border border-[#DCE5F0] hover:bg-[#EBF1F8]"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4 text-[#125BB5]" }), t("employerFaqs")]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setSelectedCategory("job"),
								className: `px-4 py-2 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all ${selectedCategory === "job" ? "bg-[#063B78] text-white shadow-md" : "bg-white text-[#10233F] border border-[#DCE5F0] hover:bg-[#EBF1F8]"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4 text-[#063B78]" }), t("jobFaqs")]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setSelectedCategory("account"),
								className: `px-4 py-2 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all ${selectedCategory === "account" ? "bg-[#063B78] text-white shadow-md" : "bg-white text-[#10233F] border border-[#DCE5F0] hover:bg-[#EBF1F8]"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-4 text-[#FFC400]" }), t("accountFaqs")]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-3",
						children: filteredFaqs.length > 0 ? filteredFaqs.map((faq, index) => {
							const isOpen = openIndex === index;
							const questionText = getQuestion(faq);
							const answerText = getAnswer(faq);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "card-realjob overflow-hidden transition-all duration-200",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setOpenIndex(isOpen ? null : index),
									className: "w-full p-5 text-left flex items-center justify-between gap-4 font-black text-[#10233F] hover:text-[#063B78]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-base font-black block",
										children: questionText
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `size-5 text-[#063B78] shrink-0 transition-transform duration-300 ${isOpen ? "rotate-180" : ""}` })]
								}), isOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "px-5 pb-5 pt-1 border-t border-[#DCE5F0] bg-[#F5F8FC]",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-bold text-[#082F63] leading-relaxed",
										children: answerText
									})
								})]
							}, index);
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "card-realjob p-12 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleQuestionMark, { className: "mx-auto size-12 text-[#5B6B7F] mb-3" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-lg font-black text-[#10233F]",
									children: t("noFaqFound")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold text-[#5B6B7F] mt-1",
									children: t("noFaqFoundSub")
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-12 card-realjob p-8 bg-hero-overlay text-white rounded-2xl flex flex-col md:flex-row items-center justify-between gap-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-[#FFC400] font-black text-xs uppercase tracking-wider mb-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: "size-4" }),
									" ",
									t("needSupportEyebrow")
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-2xl font-black text-white",
								children: t("stillHaveQuestions")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-white/90 font-medium mt-1",
								children: t("supportTeamReady")
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							className: "btn-yellow font-extrabold text-sm px-6 py-3 shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/contact",
								children: t("contactUsBtn")
							})
						})]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
	] });
}
function PopularCategories({ limit = 8, hideHeader = false }) {
	const { t, n, lang } = useI18n();
	const allJobs = dataStore.getAllJobs();
	const getCategoryJobCount = (catId) => {
		return allJobs.filter((j) => {
			const cat = (j.category || "").toLowerCase();
			const title = (j.title || "").toLowerCase();
			const query = catId.toLowerCase();
			if (cat.includes(query)) return true;
			if (catId === "construction") return cat.includes("construction") || cat.includes("building") || title.includes("construction") || title.includes("civil");
			if (catId === "it-software") return cat.includes("it") || cat.includes("software") || title.includes("developer") || title.includes("software");
			if (catId === "engineering") return cat.includes("engineering") || cat.includes("technical") || title.includes("engineer");
			if (catId === "healthcare-medical") return cat.includes("health") || cat.includes("medical") || cat.includes("nursing");
			if (catId === "finance-accounting") return cat.includes("finance") || cat.includes("accounting") || cat.includes("account");
			if (catId === "sales-marketing") return cat.includes("sales") || cat.includes("marketing");
			if (catId === "education") return cat.includes("education") || cat.includes("teaching");
			if (catId === "manufacturing") return cat.includes("manufacturing") || cat.includes("industrial") || cat.includes("factory") || title.includes("operator") || title.includes("mfg");
			return false;
		}).length;
	};
	const realJobCategories = [
		{
			id: "construction",
			icon: HardHat
		},
		{
			id: "it-software",
			icon: Laptop
		},
		{
			id: "engineering",
			icon: Wrench
		},
		{
			id: "healthcare-medical",
			icon: Stethoscope
		},
		{
			id: "finance-accounting",
			icon: Landmark
		},
		{
			id: "sales-marketing",
			icon: TrendingUp
		},
		{
			id: "education",
			icon: GraduationCap
		},
		{
			id: "manufacturing",
			icon: Factory
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "categories",
		className: hideHeader ? "relative" : "relative bg-[#F5F8FC] py-16 sm:py-24 overflow-hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: hideHeader ? "" : "relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
			children: [!hideHeader && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col md:flex-row md:items-end justify-between gap-6 w-full mb-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-start text-left max-w-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-2 rounded-full border border-[#063B78]/20 bg-[#063B78]/10 px-4 py-1.5 text-xs font-bold uppercase tracking-wider text-[#063B78]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-[#FFC400]" }), t("popularCategoriesEyebrow")]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 text-3xl font-black text-[#10233F] sm:text-4xl",
							children: t("popularCategories")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-base font-semibold text-[#5B6B7F]",
							children: t("popularCategoriesSubtitle")
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/jobs",
					className: "inline-flex items-center gap-2 rounded-lg bg-[#063B78] px-6 py-3 text-sm font-bold text-white shadow-md transition-all duration-200 hover:bg-[#082F63] hover:shadow-lg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						t("viewAll"),
						" (",
						n(allJobs.length),
						")"
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 text-[#FFC400]" })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5",
				children: realJobCategories.slice(0, limit).map((cat) => {
					const IconComponent = cat.icon;
					const categoryTitle = getCategoryTitle(cat.id, lang);
					const categoryDesc = getCategoryDesc(cat.id, lang);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/jobs",
						search: { category: cat.id },
						className: "group card-realjob p-6 flex flex-col justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-12 rounded-xl bg-[#063B78]/10 text-[#063B78] flex items-center justify-center group-hover:bg-[#FFC400] group-hover:text-[#082F63] transition-colors",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconComponent, { className: "size-6" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-black bg-[#EBF1F8] text-[#063B78] px-2.5 py-1 rounded-full group-hover:bg-[#063B78] group-hover:text-white transition-colors",
									children: [
										n(getCategoryJobCount(cat.id)),
										" ",
										t("jobsCountText")
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg font-black text-[#10233F] group-hover:text-[#063B78] transition-colors",
								children: categoryTitle
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs font-semibold text-[#5B6B7F] line-clamp-2",
								children: categoryDesc
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 pt-3 border-t border-[#DCE5F0] flex items-center justify-between text-xs font-bold text-[#063B78] group-hover:text-[#125BB5]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("apply") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 transition-transform group-hover:translate-x-1" })]
						})]
					}, cat.id);
				})
			})]
		})
	});
}
function PopularJobs() {
	const { t } = useI18n();
	const [activeTab, setActiveTab] = (0, import_react.useState)("all");
	const [savedJobs, setSavedJobs] = (0, import_react.useState)({});
	const toggleSave = (id) => {
		setSavedJobs((prev) => ({
			...prev,
			[id]: !prev[id]
		}));
	};
	const filterTabs = [
		{
			id: "all",
			labelKey: "allJobsTab",
			icon: LayoutGrid
		},
		{
			id: "tech",
			labelKey: "itSoftwareTab",
			icon: Code
		},
		{
			id: "health",
			labelKey: "healthcareTab",
			icon: HeartPulse
		},
		{
			id: "banking",
			labelKey: "bankingTab",
			icon: Landmark
		},
		{
			id: "edu",
			labelKey: "educationTab",
			icon: GraduationCap
		},
		{
			id: "mkt",
			labelKey: "marketingTab",
			icon: Briefcase
		}
	];
	const jobsList = dataStore.getAllJobs().map((j) => ({
		id: j.id,
		title: j.title,
		company: j.company,
		location: j.location,
		salary: j.salary,
		posted: j.postedAgo || "Just now",
		type: j.jobType || "Full Time",
		exp: j.experience || "Any",
		mode: j.workMode || "On-site",
		featured: true,
		badgeColor: "bg-[#063B78]",
		btnColor: "bg-[#063B78] hover:bg-[#082F63] text-white",
		waveGlow: "from-[#063B78]/15 via-[#063B78]/5",
		logoSvg: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid size-12 shrink-0 place-items-center rounded-2xl bg-[#063B78] text-white shadow-md font-black text-[#FFC400] text-sm",
			children: j.initials || (j.company ? j.company.substring(0, 2).toUpperCase() : "RJ")
		})
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative bg-[#F8F7F4] py-20 sm:py-28 overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -left-20 top-1/2 h-96 w-96 -translate-y-1/2 rounded-full bg-[#D4AF37]/10 blur-3xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -right-20 top-1/2 h-96 w-96 -translate-y-1/2 rounded-full bg-[#1F2937]/5 blur-3xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col items-start text-left max-w-2xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "inline-flex items-center gap-2 rounded-full border border-[#D4AF37]/40 bg-[#FFFDF5] px-4 py-1 text-[11px] font-bold uppercase tracking-widest text-[#1F2937] shadow-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full bg-[#D4AF37]" }), t("popularJobsEyebrow")]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-4 font-display text-4xl font-bold text-[#111827] sm:text-5xl",
									children: t("popularJobs")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 max-w-xl text-sm leading-6 text-[#374151] sm:text-base",
									children: t("popularJobsSubtitle")
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative shrink-0 sm:ml-auto sm:self-end pb-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								className: "absolute -right-3 -top-5 size-7 text-[#D4AF37] opacity-90",
								viewBox: "0 0 24 24",
								fill: "none",
								stroke: "currentColor",
								strokeWidth: "2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/jobs",
								className: "inline-flex items-center gap-2 rounded-full bg-[#1F2937] px-7 py-3 text-sm font-semibold text-white shadow-lg transition-all duration-200 hover:bg-[#D4AF37] hover:text-[#1F2937] hover:shadow-xl hover:-translate-y-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("browseJobs") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap items-center gap-2.5 overflow-x-auto pb-2 scrollbar-none",
						children: [filterTabs.map((tab) => {
							const Icon = tab.icon;
							const isActive = activeTab === tab.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setActiveTab(tab.id),
								className: `inline-flex items-center gap-2 rounded-full px-4 py-2 text-xs font-semibold transition-all duration-200 shadow-sm ${isActive ? "bg-[#1F2937] text-white shadow-md ring-2 ring-[#D4AF37]/50" : "bg-white border border-[#E5E2DA] text-[#374151] hover:bg-[#F2EFEC] hover:border-[#1F2937]/30"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: `size-3.5 ${isActive ? "text-[#D4AF37]" : "text-[#374151]"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(tab.labelKey) })]
							}, tab.id);
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "inline-flex items-center justify-center size-8 rounded-full bg-white border border-[#E5E2DA] text-[#374151] hover:bg-[#F2EFEC]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-4" })
						})]
					}),
					jobsList.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 p-12 text-center bg-white rounded-3xl border border-[#E5E2DA] shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-12 mx-auto text-[#063B78] mb-3 opacity-60" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg font-black text-[#10233F]",
								children: "अद्याप कोणतीही नोकरी जोडलेली नाही (No Jobs Posted Yet)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold text-[#5B6B7F] mt-1",
								children: "ॲडमिन कंट्रोल पॅनेलवरून नवीन नोकऱ्या जोडल्यावर त्या येथे थेट दिसतील."
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 grid gap-6 lg:grid-cols-2",
						children: jobsList.map((job) => {
							const isSaved = !!savedJobs[job.id];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "group relative flex flex-col justify-between overflow-hidden rounded-3xl border border-[#E5E2DA] bg-white p-6 shadow-sm transition-all duration-300 hover:-translate-y-1.5 hover:border-[#D4AF37]/50 hover:shadow-xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `pointer-events-none absolute -right-12 -top-12 size-44 rounded-full bg-gradient-to-br ${job.waveGlow} to-transparent blur-xl` }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative z-10 flex items-start gap-4",
										children: [job.logoSvg, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0 flex-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-start justify-between gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-wrap items-center gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
														to: "/jobs/$jobId",
														params: { jobId: job.id },
														className: "font-display text-xl font-bold text-[#111827] transition-colors hover:text-[#D4AF37]",
														children: job.title
													}), job.featured && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "rounded-full border border-[#D4AF37]/40 bg-[#FFFDF5] px-2.5 py-0.5 text-[10px] font-extrabold uppercase tracking-wide text-[#B59124]",
														children: t("featured")
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "mt-1 flex items-center gap-1.5 text-xs font-semibold text-[#374151]",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3.5 text-muted-foreground" }), job.company]
												})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => toggleSave(job.id),
													className: `grid size-9 shrink-0 place-items-center rounded-full border transition-all shadow-sm ${isSaved ? "border-[#D4AF37] bg-[#FFFDF5] text-[#D4AF37]" : "border-[#E5E2DA] bg-white text-[#374151] hover:bg-[#F2EFEC]"}`,
													"aria-label": "Save job",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: `size-4 ${isSaved ? "fill-current" : ""}` })
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-[#374151]",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "inline-flex items-center gap-1.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5 text-muted-foreground" }), job.location]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "inline-flex items-center gap-1.5 font-semibold text-[#111827]",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-3.5 text-muted-foreground" }), job.salary]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "inline-flex items-center gap-1.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { className: "size-3.5 text-muted-foreground" }), job.posted]
													})
												]
											})]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative z-10 mt-6 flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-[#F2EFEC]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `rounded-full ${job.badgeColor} px-3.5 py-1 text-xs font-bold text-white shadow-sm`,
													children: job.type === "Full Time" || job.type === "Full-time" ? t("fullTime") : job.type
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "rounded-full bg-[#F2EFEC] border border-[#E5E2DA] px-3.5 py-1 text-xs font-bold text-[#374151]",
													children: job.exp
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "rounded-full bg-[#F2EFEC] border border-[#E5E2DA] px-3.5 py-1 text-xs font-bold text-[#374151]",
													children: job.mode === "On-site" ? t("onSite") : job.mode === "Hybrid" ? t("hybrid") : t("remote")
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/jobs/$jobId",
											params: { jobId: job.id },
											className: `inline-flex items-center gap-1.5 rounded-full ${job.btnColor} px-6 py-2.5 text-xs font-bold text-white shadow-md transition-all duration-200 hover:shadow-lg hover:-translate-y-0.5`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("apply") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5" })]
										})]
									})
								]
							}, job.id);
						})
					})
				]
			})
		]
	});
}
var workersList = [
	{
		id: "worker-1",
		name: "Ramesh Pawar",
		profession: "Senior Electrician",
		marathiProfession: "वरिष्ठ इलेक्ट्रीशियन",
		hindiProfession: "वरिष्ठ इलेक्ट्रीशियन",
		location: "Pune, Maharashtra",
		experience: "7 Years",
		expectedSalary: "₹25,000 / month",
		availability: "Available Now",
		rating: 4.9,
		reviewsCount: 38,
		verified: true,
		skills: [
			"Industrial Wiring",
			"Panel Maintenance",
			"PLC Basics",
			"Solar Installation"
		],
		photoUrl: "https://images.unsplash.com/photo-1540569014015-19a7be504e3a?auto=format&fit=crop&w=300&q=80",
		phone: "+91 98230 11223",
		age: 32,
		languages: [
			"Marathi",
			"Hindi",
			"English"
		],
		about: "Certified ITI electrician with 7 years of industrial & commercial building wiring experience."
	},
	{
		id: "worker-2",
		name: "Ganesh Patil",
		profession: "CNC Machine Operator",
		marathiProfession: "CNC मशीन ऑपरेटर",
		hindiProfession: "सीएनसी मशीन ऑपरेटर",
		location: "Chakan, Pune",
		experience: "5 Years",
		expectedSalary: "₹28,000 / month",
		availability: "Available Now",
		rating: 4.8,
		reviewsCount: 24,
		verified: true,
		skills: [
			"Fanuc Control",
			"VMC Operating",
			"Quality Inspection",
			"Micrometer"
		],
		photoUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80",
		phone: "+91 97654 44321",
		age: 28,
		languages: ["Marathi", "Hindi"],
		about: "Specialized in auto-component machining, Fanuc CNC turning and VMC setting."
	},
	{
		id: "worker-3",
		name: "Sunil Shinde",
		profession: "Heavy Commercial Driver",
		marathiProfession: "अवजड वाहन चालक (ड्रायव्हर)",
		hindiProfession: "भारी वाहन चालक (ड्राइवर)",
		location: "Thane, Mumbai",
		experience: "9 Years",
		expectedSalary: "₹30,000 / month",
		availability: "Immediate",
		rating: 4.9,
		reviewsCount: 52,
		verified: true,
		skills: [
			"Heavy Badge License",
			"Container Truck",
			"Interstate Driving",
			"GPS Navigation"
		],
		photoUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80",
		phone: "+91 98901 22334",
		age: 36,
		languages: ["Marathi", "Hindi"],
		about: "Clean driving record, experienced in long-haul multi-axle trucks and container transport."
	},
	{
		id: "worker-4",
		name: "Prakash Jadhav",
		profession: "ARC & TIG Welder",
		marathiProfession: "वेल्डर (ARC / TIG)",
		hindiProfession: "वेल्डर (ARC / TIG)",
		location: "Aurangabad / Chhatrapati Sambhajinagar",
		experience: "6 Years",
		expectedSalary: "₹24,000 / month",
		availability: "Available Now",
		rating: 4.7,
		reviewsCount: 19,
		verified: true,
		skills: [
			"6G Welding",
			"Structure Welding",
			"SS Pipe Welding",
			"Safety Norms"
		],
		photoUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=300&q=80",
		phone: "+91 94221 88776",
		age: 30,
		languages: ["Marathi", "Hindi"],
		about: "Certified structural and pressure vessel welder with 6G certification."
	},
	{
		id: "worker-5",
		name: "Santosh More",
		profession: "Head Mason & Construction Supervisor",
		marathiProfession: "मुख्य गवंडी (Mason)",
		hindiProfession: "मुख्य राजमिस्त्री (Mason)",
		location: "Nagpur, Maharashtra",
		experience: "12 Years",
		expectedSalary: "₹35,000 / month",
		availability: "1 Week Notice",
		rating: 5,
		reviewsCount: 61,
		verified: true,
		skills: [
			"Brickwork",
			"Plastering",
			"Tile Laying",
			"Site Supervision"
		],
		photoUrl: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=300&q=80",
		phone: "+91 98220 99887",
		age: 42,
		languages: ["Marathi", "Hindi"],
		about: "Experienced building contractor mason leading site teams of up to 25 workers."
	},
	{
		id: "worker-6",
		name: "Sachin Kadam",
		profession: "Plumbing & Maintenance Specialist",
		marathiProfession: "प्लंबर व मेंटेनन्स",
		hindiProfession: "प्लंबर व मेंटेनेंस",
		location: "Navi Mumbai, Maharashtra",
		experience: "4 Years",
		expectedSalary: "₹22,000 / month",
		availability: "Available Now",
		rating: 4.8,
		reviewsCount: 31,
		verified: true,
		skills: [
			"CPVC Fitting",
			"Drainage Systems",
			"Water Pump Repair",
			"Leak Detection"
		],
		photoUrl: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=300&q=80",
		phone: "+91 97300 55443",
		age: 26,
		languages: [
			"Marathi",
			"Hindi",
			"English"
		],
		about: "Residential and commercial plumbing specialist skilled in pump automation."
	}
];
function WorkerCard({ worker }) {
	const { t, n, lang } = useI18n();
	const [requested, setRequested] = (0, import_react.useState)(false);
	const handleHireRequest = () => {
		setRequested(true);
		toast.success(`Hire request sent to ${worker.name}! They will contact you shortly.`);
	};
	const displayProfession = lang === "mr" ? worker.marathiProfession : lang === "hi" ? worker.hindiProfession || worker.profession : worker.profession;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card-realjob p-5 flex flex-col justify-between h-full group",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: worker.photoUrl,
						alt: worker.name,
						className: "size-16 rounded-full object-cover border-2 border-[#063B78] shadow-sm"
					}), worker.verified && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { className: "size-5 text-[#FFC400] fill-[#063B78] absolute -bottom-1 -right-1" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-base font-black text-[#10233F] truncate group-hover:text-[#063B78] transition-colors",
								children: worker.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1 text-xs font-extrabold text-[#082F63] bg-[#FFC400] px-2 py-0.5 rounded-full",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-3 fill-[#082F63]" }), n(worker.rating)]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-extrabold text-[#063B78] truncate",
							children: displayProfession
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 flex items-center gap-2 text-xs font-semibold text-[#5B6B7F]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5 text-[#125BB5]" }), worker.location]
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-2 gap-2 bg-[#F5F8FC] p-2.5 rounded-lg border border-[#DCE5F0]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[10px] font-bold uppercase text-[#5B6B7F] block",
					children: t("experience")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-extrabold text-[#10233F]",
					children: n(worker.experience)
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[10px] font-bold uppercase text-[#5B6B7F] block",
					children: t("expectedSalary")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-black text-[#063B78]",
					children: n(worker.expectedSalary)
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[10px] font-bold uppercase text-[#5B6B7F] block mb-1.5",
					children: t("keySkills")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1.5",
					children: worker.skills.map((skill, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "secondary",
						className: "text-[10.5px] font-bold bg-[#EBF1F8] text-[#063B78] border-0",
						children: skill
					}, idx))
				})]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 pt-3 border-t border-[#DCE5F0] flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/workers/$workerId",
				params: { workerId: worker.id },
				className: "flex-1 text-center py-2 px-3 rounded-lg border border-[#063B78] text-[#063B78] font-extrabold text-xs hover:bg-[#063B78] hover:text-white transition-colors",
				children: t("viewProfile")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: handleHireRequest,
				disabled: requested,
				size: "sm",
				className: "btn-yellow text-xs font-black px-4 py-2",
				children: requested ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5 text-[#082F63]" }), t("contactSent")]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneCall, { className: "size-3.5 text-[#082F63]" }), t("hireWorker")]
				})
			})]
		})]
	});
}
var Route$27 = createFileRoute("/home")({
	head: () => ({ meta: [
		{ title: "REAL JOB — Main Portal | Find Work | Find Workers | सर्व काही ऑनलाइन!" },
		{
			name: "description",
			content: "India's premier digital workforce platform connecting verified workers with top factory, construction & technical employers."
		},
		{
			property: "og:title",
			content: "REAL JOB — Find Work | Find Workers"
		},
		{
			property: "og:description",
			content: "योग्य माणूस • योग्य काम • योग्य संधी — सर्व काही ऑनलाइन!"
		},
		{
			property: "og:type",
			content: "website"
		}
	] }),
	component: HomePage
});
function HomePage() {
	const { t, lang } = useI18n();
	const [searchTab, setSearchTab] = (0, import_react.useState)("job");
	const [keyword, setKeyword] = (0, import_react.useState)("");
	const [location, setLocation] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("all");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "bg-[#F5F8FC]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "relative isolate min-h-[640px] overflow-hidden",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: career_team_default,
							alt: "REAL JOB India Workforce & Construction Workers",
							width: 1600,
							height: 1e3,
							className: "absolute inset-0 h-full w-full object-cover object-center"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-hero-overlay" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative mx-auto flex min-h-[640px] max-w-7xl flex-col justify-center px-4 py-20 sm:px-6 lg:px-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "max-w-3xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mb-4 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-1.5 text-xs font-bold uppercase tracking-wider text-[#FFC400] backdrop-blur",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" }), t("heroBadge")]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
										className: "font-display text-4xl font-black leading-[1.1] text-white sm:text-6xl lg:text-7xl",
										children: [
											t("heroTitleLine1"),
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[#FFC400]",
												children: t("heroTitleLine2")
											}),
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
											t("heroTitleLine3")
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-lg sm:text-xl font-bold text-white/90",
										children: t("heroSubtitle")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-8 flex flex-wrap gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											asChild: true,
											size: "lg",
											className: "btn-yellow h-13 px-8 text-sm font-black shadow-md",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/jobs",
												children: [t("findJob"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "ml-1 size-4" })]
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											asChild: true,
											size: "lg",
											className: "btn-navy h-13 px-8 text-sm font-bold border border-white/30",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/workers",
												children: [t("hireTalent"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "ml-1.5 size-4" })]
											})
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-10 flex flex-wrap gap-6 text-xs sm:text-sm font-bold text-white/90",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-[#FFC400]" }), t("trustPhone")]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-[#FFC400]" }), t("trustCommission")]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-[#FFC400]" }), t("trustVerified")]
											})
										]
									})
								]
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "relative z-20 mx-auto -mt-12 max-w-6xl px-4 sm:px-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-[#DCE5F0] bg-white p-5 shadow-xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 mb-4 border-b border-[#DCE5F0] pb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setSearchTab("job"),
								className: `px-5 py-2 rounded-lg font-black text-xs transition-all ${searchTab === "job" ? "bg-[#063B78] text-white shadow-xs" : "text-[#5B6B7F] hover:bg-[#F5F8FC]"}`,
								children: t("searchJobTab")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setSearchTab("worker"),
								className: `px-5 py-2 rounded-lg font-black text-xs transition-all ${searchTab === "worker" ? "bg-[#063B78] text-white shadow-xs" : "text-[#5B6B7F] hover:bg-[#F5F8FC]"}`,
								children: t("searchWorkerTab")
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 md:grid-cols-[1fr_0.8fr_0.8fr_auto]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative flex items-center bg-[#F5F8FC] rounded-xl px-3 border border-[#DCE5F0]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-[#063B78] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: t("searchPlaceholder"),
										value: keyword,
										onChange: (e) => setKeyword(e.target.value),
										className: "h-11 border-0 bg-transparent text-xs font-bold text-[#10233F] focus-visible:ring-0"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative flex items-center bg-[#F5F8FC] rounded-xl px-3 border border-[#DCE5F0]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4 text-[#125BB5] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: t("location"),
										value: location,
										onChange: (e) => setLocation(e.target.value),
										className: "h-11 border-0 bg-transparent text-xs font-bold text-[#10233F] focus-visible:ring-0"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative flex items-center bg-[#F5F8FC] rounded-xl px-3 border border-[#DCE5F0]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4 text-[#063B78] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: category,
										onChange: (e) => setCategory(e.target.value),
										className: "w-full h-11 border-0 bg-transparent text-xs font-bold text-[#10233F] focus:outline-none",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "all",
												children: t("allCategories")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "construction",
												children: "Construction"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "it-software",
												children: "IT & Software"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "engineering",
												children: "Engineering"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "healthcare-medical",
												children: "Healthcare & Medical"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "finance-accounting",
												children: "Finance & Accounting"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "sales-marketing",
												children: "Sales & Marketing"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "education",
												children: "Education"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "manufacturing",
												children: "Manufacturing"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "hr-recruitment",
												children: "HR & Recruitment"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "hospitality-tourism",
												children: "Hospitality & Tourism"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "logistics-transport",
												children: "Logistics & Transport"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "government-public",
												children: "Government & Public Sector"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "legal",
												children: "Legal"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "architecture-design",
												children: "Architecture & Interior Design"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "retail-ecommerce",
												children: "Retail & E-commerce"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "customer-service-bpo",
												children: "Customer Service & BPO"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "design-creative",
												children: "Design & Creative"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "media-communication",
												children: "Media & Communication"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "agriculture-farming",
												children: "Agriculture & Farming"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "science-research",
												children: "Science & Research"
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									size: "lg",
									className: "btn-yellow h-11 px-8 font-black text-xs",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: searchTab === "job" ? "/jobs" : "/workers",
										search: { ...category !== "all" ? { category } : {} },
										children: searchTab === "job" ? t("jobs") : t("workers")
									})
								})
							]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopularCategories, { limit: 4 }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopularJobs, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-16 sm:py-24 bg-white border-y border-[#DCE5F0]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "inline-flex items-center gap-2 rounded-full border border-[#063B78]/20 bg-[#063B78]/10 px-4 py-1.5 text-xs font-bold uppercase tracking-wider text-[#063B78]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-[#FFC400]" }), t("topWorkersTitle")]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 text-3xl font-black text-[#10233F] sm:text-4xl",
									children: t("topWorkersTitle")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm font-semibold text-[#5B6B7F]",
									children: t("topWorkersSubtitle")
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								className: "btn-navy font-bold text-xs px-6 py-3 h-auto shrink-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/workers",
									children: [
										t("viewAll"),
										" (",
										workersList.length,
										") ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "ml-1.5 size-4 text-[#FFC400]" })
									]
								})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
							children: workersList.slice(0, 3).map((worker) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkerCard, { worker }, worker.id))
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-16 sm:py-24",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center max-w-2xl mx-auto mb-14",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-black uppercase tracking-wider text-[#125BB5] bg-[#EBF1F8] px-3 py-1 rounded-full",
									children: t("whyUs")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 text-3xl font-black text-[#10233F] sm:text-4xl",
									children: t("whyUs")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm font-semibold text-[#5B6B7F]",
									children: t("whyUsSubtitle")
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid sm:grid-cols-2 lg:grid-cols-4 gap-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "card-realjob p-6 text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-14 rounded-2xl bg-[#063B78]/10 text-[#063B78] mx-auto flex items-center justify-center mb-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-7" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-black text-lg text-[#10233F]",
											children: t("step1Title")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold text-[#5B6B7F] mt-2",
											children: t("step1Desc")
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "card-realjob p-6 text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-14 rounded-2xl bg-[#FFC400]/20 text-[#082F63] mx-auto flex items-center justify-center mb-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeartHandshake, { className: "size-7" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-black text-lg text-[#10233F]",
											children: t("trustCommission")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold text-[#5B6B7F] mt-2",
											children: t("step3Desc")
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "card-realjob p-6 text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-14 rounded-2xl bg-[#125BB5]/10 text-[#125BB5] mx-auto flex items-center justify-center mb-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "size-7" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-black text-lg text-[#10233F]",
											children: t("chooseLanguage")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold text-[#5B6B7F] mt-2",
											children: t("languageSubtitle")
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "card-realjob p-6 text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-14 rounded-2xl bg-[#063B78]/10 text-[#063B78] mx-auto flex items-center justify-center mb-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-7" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-black text-lg text-[#10233F]",
											children: t("step3Title")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold text-[#5B6B7F] mt-2",
											children: t("step3Desc")
										})
									]
								})
							]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "bg-hero-overlay text-white py-16 relative overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid md:grid-cols-2 gap-10 items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-black uppercase tracking-wider text-[#FFC400] bg-white/10 px-3 py-1 rounded-full border border-white/20",
									children: t("downloadTitle")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
									className: "mt-4 text-3xl font-black text-white sm:text-4xl leading-tight",
									children: [
										t("downloadTitle"),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[#FFC400]",
											children: t("downloadSubtitle")
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-sm font-semibold text-white/90 leading-relaxed",
									children: t("downloadSubtitle")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 flex flex-wrap items-center gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										className: "btn-yellow font-black text-xs px-6 py-3 h-12",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4 mr-2" }),
											" ",
											t("playStore")
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "outline",
										className: "border-white text-white font-bold text-xs px-6 py-3 h-12 hover:bg-white hover:text-[#063B78]",
										children: t("appStore")
									})]
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex justify-center md:justify-end",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white text-[#10233F] p-6 rounded-2xl shadow-2xl border-4 border-[#FFC400] text-center max-w-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, { className: "size-36 mx-auto text-[#063B78]" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-xs font-black text-[#063B78] mt-3",
											children: t("downloadTitle")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-[10px] font-bold text-[#5B6B7F]",
											children: "Scan QR to download REAL JOB App"
										})
									]
								})
							})]
						})
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
	] });
}
var $$splitComponentImporter$21 = () => import("./reset-password-DkGKqFDk.mjs");
var Route$26 = createFileRoute("/reset-password")({
	head: () => ({ meta: [
		{ title: "Reset password — REAL JOB" },
		{
			name: "description",
			content: "Securely choose a new REAL JOB password."
		},
		{
			property: "og:title",
			content: "Reset password — REAL JOB"
		},
		{
			property: "og:description",
			content: "Secure account recovery."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$21, "component")
});
var $$splitComponentImporter$20 = () => import("./applications-Bwy9Rb0r.mjs");
var Route$25 = createFileRoute("/_authenticated/applications")({
	head: () => ({ meta: [
		{ title: "My Applications — Karyam" },
		{
			name: "description",
			content: "Track every job application and interview milestone."
		},
		{
			property: "og:title",
			content: "My Applications — Karyam"
		},
		{
			property: "og:description",
			content: "Track your application progress."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$20, "component")
});
var $$splitComponentImporter$19 = () => import("./control-D6s-FSMT.mjs");
var Route$24 = createFileRoute("/_authenticated/control")({
	head: () => ({ meta: [
		{ title: "Platform Control — Karyam" },
		{
			name: "description",
			content: "Manage Karyam users, employers, jobs, payroll and system health."
		},
		{
			property: "og:title",
			content: "Platform Control — Karyam"
		},
		{
			property: "og:description",
			content: "Karyam platform administration."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$19, "component")
});
var $$splitComponentImporter$18 = () => import("./dashboard-BXWCChc5.mjs");
var Route$23 = createFileRoute("/_authenticated/dashboard")({
	head: () => ({ meta: [
		{ title: "Career Dashboard — Karyam" },
		{
			name: "description",
			content: "Track jobs, applications, interviews and profile progress."
		},
		{
			property: "og:title",
			content: "Career Dashboard — Karyam"
		},
		{
			property: "og:description",
			content: "Your career activity in one place."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$18, "component")
});
var $$splitComponentImporter$17 = () => import("./employer-D86mfG_Z.mjs");
var Route$22 = createFileRoute("/_authenticated/employer")({
	head: () => ({ meta: [
		{ title: "Employer Dashboard — Karyam" },
		{
			name: "description",
			content: "Manage recruitment, candidates, employees and payroll."
		},
		{
			property: "og:title",
			content: "Employer Dashboard — Karyam"
		},
		{
			property: "og:description",
			content: "Recruitment and workforce management."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$17, "component")
});
var $$splitComponentImporter$16 = () => import("./messages-CFn04Z43.mjs");
var Route$21 = createFileRoute("/_authenticated/messages")({
	head: () => ({ meta: [{ title: "Messages & Employer Chat — REAL JOB" }, {
		name: "description",
		content: "Directly chat with employers and workers on REAL JOB."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./notifications-BTZJaoA3.mjs");
var Route$20 = createFileRoute("/_authenticated/notifications")({
	head: () => ({ meta: [
		{ title: "Notifications — Karyam" },
		{
			name: "description",
			content: "Manage your Notifications on Karyam."
		},
		{
			property: "og:title",
			content: "Notifications — Karyam"
		},
		{
			property: "og:description",
			content: "Your secure Karyam Notifications."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./post-job-BtYJZtnn.mjs");
var Route$19 = createFileRoute("/_authenticated/post-job")({
	head: () => ({ meta: [{ title: "Post a New Job — REAL JOB Employer Portal" }, {
		name: "description",
		content: "Post jobs for factory workers, technicians, drivers, welders & general labor on REAL JOB."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./profile-BslUmtR3.mjs");
var Route$18 = createFileRoute("/_authenticated/profile")({
	head: () => ({ meta: [
		{ title: "Profile — Karyam" },
		{
			name: "description",
			content: "Manage your Profile on Karyam."
		},
		{
			property: "og:title",
			content: "Profile — Karyam"
		},
		{
			property: "og:description",
			content: "Your secure Karyam Profile."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./salary-B5TVqkAN.mjs");
var Route$17 = createFileRoute("/_authenticated/salary")({
	head: () => ({ meta: [
		{ title: "My E-Salary — Karyam" },
		{
			name: "description",
			content: "View salary, attendance, bonuses, deductions and payslips."
		},
		{
			property: "og:title",
			content: "My E-Salary — Karyam"
		},
		{
			property: "og:description",
			content: "Your secure salary dashboard."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var Route$16 = createFileRoute("/company/$companyId")({
	head: ({ params }) => ({ meta: [{ title: `${params.companyId.replaceAll("-", " ").toUpperCase()} — Verified Company Hub | REAL JOB` }, {
		name: "description",
		content: "Explore company background, active job openings, ratings, and employee benefits on REAL JOB."
	}] }),
	component: CompanyPage
});
function CompanyPage() {
	const { t, n, lang } = useI18n();
	const { companyId } = useParams({ from: "/company/$companyId" });
	const matchingJob = jobs.find((j) => {
		const slug = j.company.toLowerCase().replace(/[^a-z0-9]+/g, "-");
		return slug === companyId || companyId.includes(slug) || slug.includes(companyId);
	}) ?? jobs[0] ?? {
		id: "c-1",
		title: "Civil Engineer - Site Operations",
		company: "L&T Construction",
		location: "Mumbai, Maharashtra",
		salary: "₹35,000–50,000/mo",
		experience: "2–5 years",
		type: "Full-time",
		workMode: "On-site",
		posted: "1h ago",
		initials: "LT",
		category: "Construction"
	};
	const companyMeta = getCompanyMetadata(matchingJob);
	const companyJobs = jobs.filter((j) => j.company === matchingJob.company);
	const [activeTab, setActiveTab] = (0, import_react.useState)("overview");
	const [following, setFollowing] = (0, import_react.useState)(false);
	const handleShare = () => {
		if (typeof navigator !== "undefined" && navigator.clipboard) {
			navigator.clipboard.writeText(window.location.href);
			toast.success(lang === "mr" ? "कंपनी प्रोफाइल लिंक कॉपी झाली!" : "Company page link copied!");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "bg-[#F5F8FC] min-h-screen py-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4 mb-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => window.history.back(),
							className: "px-3.5 py-2 text-[#5B6B7F] hover:text-[#10233F] hover:bg-white rounded-xl flex items-center gap-1.5 text-xs font-black transition-all shadow-2xs border border-[#DCE5F0] bg-white",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }),
								" ",
								lang === "mr" ? "मागे जा" : "Back"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-xs font-bold text-[#5B6B7F]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/",
									className: "hover:text-[#063B78]",
									children: t("home")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "/" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/jobs",
									className: "hover:text-[#063B78]",
									children: t("jobs")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "/" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[#10233F]",
									children: companyMeta.name
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white rounded-3xl border border-[#DCE5F0] shadow-md overflow-hidden mb-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "h-44 sm:h-52 bg-gradient-to-r from-[#063B78] via-[#082F63] to-[#125BB5] p-6 text-white relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute right-6 top-6 flex items-center gap-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: handleShare,
									className: "bg-white/10 hover:bg-white/20 border-white/20 text-white font-bold text-xs h-9 px-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-4 mr-1.5" }),
										" ",
										lang === "mr" ? "शेअर करा" : "Share"
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute bottom-4 left-6 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-black uppercase tracking-wider bg-[#FFC400] text-[#082F63] px-3 py-1 rounded-full shadow-sm",
									children: companyMeta.industry
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-black text-emerald-300 flex items-center gap-1 bg-white/10 backdrop-blur px-3 py-1 rounded-full",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-emerald-400" }), " REAL JOB Verified Corporate Hub"]
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-6 sm:p-8 pt-0 relative",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col sm:flex-row items-start sm:items-end justify-between gap-6 -mt-12 sm:-mt-16 mb-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-end gap-5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "grid size-24 sm:size-28 shrink-0 place-items-center rounded-3xl bg-white font-black text-[#063B78] text-4xl shadow-xl border-4 border-white ring-2 ring-[#063B78]/20",
											children: matchingJob.initials
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
											className: "text-2xl sm:text-3xl font-black text-[#10233F]",
											children: companyMeta.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 text-xs font-bold text-[#5B6B7F] mt-1.5 flex-wrap",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-1",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4 text-[#063B78]" }),
														" ",
														companyMeta.headquarters
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-1 text-[#082F63] bg-[#FFC400]/20 px-2.5 py-0.5 rounded-full border border-[#FFC400]/30 font-black",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-3.5 fill-[#FFC400] text-[#082F63]" }),
														" ",
														companyMeta.rating,
														" / 5.0 (",
														companyMeta.reviewsCount,
														")"
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Est. ", companyMeta.founded] })
											]
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3 w-full sm:w-auto",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											onClick: () => {
												setFollowing(!following);
												toast.success(following ? `Unfollowed ${matchingJob.company}` : `Now following ${matchingJob.company}`);
											},
											className: `h-11 px-6 font-black text-xs rounded-2xl shadow-sm ${following ? "bg-[#EBF1F8] text-[#063B78] hover:bg-[#DCE5F0]" : "bg-[#063B78] text-white hover:bg-[#082F63]"}`,
											children: following ? "✓ Following Company" : "+ Follow Company"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: companyMeta.website,
											target: "_blank",
											rel: "noreferrer",
											className: "h-11 px-5 rounded-2xl border border-[#DCE5F0] bg-white text-[#063B78] font-black text-xs inline-flex items-center justify-center hover:bg-[#F5F8FC] shadow-2xs gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Website" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" })]
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-2xl bg-[#F5F8FC] border border-[#DCE5F0]/70",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "grid size-10 place-items-center rounded-xl bg-[#063B78]/10 text-[#063B78]",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
												children: "कर्मचारी संख्या"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs sm:text-sm font-black text-[#10233F]",
												children: companyMeta.size
											})] })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 border-l sm:border-l border-[#DCE5F0] pl-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "grid size-10 place-items-center rounded-xl bg-[#FFC400]/20 text-[#082F63]",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-5" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
												children: "उपलब्ध नोकऱ्या"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-xs sm:text-sm font-black text-[#063B78]",
												children: [companyJobs.length, " Live Openings"]
											})] })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 border-l border-[#DCE5F0] pl-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "grid size-10 place-items-center rounded-xl bg-emerald-100 text-emerald-800",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-5" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
												children: "कंपनी स्टेटस"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs sm:text-sm font-black text-emerald-700",
												children: "Govt & GST Verified"
											})] })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 border-l border-[#DCE5F0] pl-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "grid size-10 place-items-center rounded-xl bg-[#063B78]/10 text-[#063B78]",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building, { className: "size-5" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
												children: "मुख्यालय"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs sm:text-sm font-black text-[#10233F] truncate",
												children: companyMeta.headquarters
											})] })]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 mt-6 border-b border-[#DCE5F0]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => setActiveTab("overview"),
											className: `pb-3 px-4 text-xs sm:text-sm font-black transition-all border-b-2 ${activeTab === "overview" ? "border-[#063B78] text-[#063B78]" : "border-transparent text-[#5B6B7F] hover:text-[#10233F]"}`,
											children: ["🏢 ", lang === "mr" ? "कंपनी परिचय व माहिती" : "Company Overview"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => setActiveTab("jobs"),
											className: `pb-3 px-4 text-xs sm:text-sm font-black transition-all border-b-2 ${activeTab === "jobs" ? "border-[#063B78] text-[#063B78]" : "border-transparent text-[#5B6B7F] hover:text-[#10233F]"}`,
											children: [
												"💼 ",
												lang === "mr" ? "सर्व नोकऱ्या" : "Active Openings",
												" (",
												companyJobs.length,
												")"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => setActiveTab("culture"),
											className: `pb-3 px-4 text-xs sm:text-sm font-black transition-all border-b-2 ${activeTab === "culture" ? "border-[#063B78] text-[#063B78]" : "border-transparent text-[#5B6B7F] hover:text-[#10233F]"}`,
											children: ["🌟 ", lang === "mr" ? "सुविधा आणि संस्कृती" : "Culture & Benefits"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => setActiveTab("locations"),
											className: `pb-3 px-4 text-xs sm:text-sm font-black transition-all border-b-2 ${activeTab === "locations" ? "border-[#063B78] text-[#063B78]" : "border-transparent text-[#5B6B7F] hover:text-[#10233F]"}`,
											children: ["📍 ", lang === "mr" ? "कार्यालये" : "Office Locations"]
										})
									]
								})
							]
						})]
					}),
					activeTab === "overview" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid lg:grid-cols-3 gap-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-2 space-y-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 sm:p-8 rounded-3xl border border-[#DCE5F0] shadow-xs space-y-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
										className: "text-lg font-black text-[#10233F] flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-5 text-[#063B78]" }), lang === "mr" ? "कंपनीबद्दल सविस्तर माहिती (About Corporate)" : "About Company"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold text-[#5B6B7F] leading-relaxed bg-[#F5F8FC] p-5 rounded-2xl border border-[#DCE5F0]/70",
										children: lang === "mr" ? companyMeta.aboutMr : companyMeta.aboutEn
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "pt-4 border-t border-[#DCE5F0]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "text-xs font-black uppercase text-[#5B6B7F] tracking-wider mb-3",
											children: lang === "mr" ? "कंपनीची अधिकृत प्रमाणपत्रे व बॅजेस" : "Verification Badges"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex flex-wrap items-center gap-2.5",
											children: companyMeta.trustBadges.map((badge, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center gap-2 rounded-2xl bg-emerald-50 border border-emerald-200 px-4 py-2 text-xs font-black text-emerald-800 shadow-2xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-emerald-600" }), badge]
											}, idx))
										})]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 sm:p-8 rounded-3xl border border-[#DCE5F0] shadow-xs space-y-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-lg font-black text-[#10233F] flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "size-5 text-[#FFC400]" }), lang === "mr" ? "कामगारांना मिळणाऱ्या सुविधा (Perks & Benefits)" : "Employee Benefits"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid sm:grid-cols-2 gap-3",
									children: (lang === "mr" ? companyMeta.perksMr : companyMeta.perksEn).map((perk, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3 p-3.5 rounded-2xl bg-[#EBF1F8] border border-[#063B78]/10 text-xs font-bold text-[#063B78]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "size-5 text-[#063B78] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: perk })]
									}, idx))
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "bg-[#082F63] text-white p-6 rounded-3xl shadow-lg relative overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative z-10 space-y-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-black uppercase tracking-wider bg-[#FFC400] text-[#082F63] px-2.5 py-1 rounded-full",
											children: "Direct Hiring Partner"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
											className: "text-xl font-black text-white",
											children: [
												companyMeta.name,
												" ",
												lang === "mr" ? "मध्ये काम करायचे आहे?" : "Want to work here?"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-slate-200 leading-relaxed font-semibold",
											children: lang === "mr" ? "कंपनीच्या थेट HR विभागाशी संपर्क साधा आणि सत्यापित नोकऱ्यांसाठी आजच अर्ज करा." : "Connect directly with HR and apply for verified job openings today."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											onClick: () => setActiveTab("jobs"),
											className: "w-full btn-yellow h-11 font-black text-xs rounded-2xl shadow-md",
											children: lang === "mr" ? "सर्व नोकऱ्या पाहा आणि अर्ज करा" : "Browse & Apply for Jobs"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 rounded-3xl border border-[#DCE5F0] shadow-xs space-y-3 text-xs font-semibold text-[#5B6B7F]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
										className: "font-black text-[#10233F] text-sm flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-emerald-600" }), lang === "mr" ? "कायदेशीर माहिती व सुरक्षा" : "Compliance & Safety"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "✓ 100% Verified GSTIN & Corporate Affairs Record." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "✓ Zero-fee application for all candidates." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "✓ Direct interview call from HR within 48 hours." })
								]
							})]
						})]
					}),
					activeTab === "jobs" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "text-xl font-black text-[#10233F]",
								children: [
									companyMeta.name,
									" — ",
									lang === "mr" ? "उपलब्ध नोकऱ्यांची यादी" : "Current Openings"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs font-extrabold text-[#063B78] bg-[#063B78]/10 px-3 py-1 rounded-full",
								children: [
									companyJobs.length,
									" ",
									lang === "mr" ? "नोकऱ्या उपलब्ध" : "Jobs Available"
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
							children: companyJobs.map((job) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JobCard, { job }, job.id))
						})]
					}),
					activeTab === "culture" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white p-6 sm:p-8 rounded-3xl border border-[#DCE5F0] shadow-xs space-y-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "text-xl font-black text-[#10233F]",
							children: [
								companyMeta.name,
								" ",
								lang === "mr" ? "कामगार पुनरावलोकने व कार्यसंस्कृती" : "Work Culture & Employee Ratings"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid sm:grid-cols-2 md:grid-cols-4 gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-[#F5F8FC] border border-[#DCE5F0] text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-3xl font-black text-[#063B78]",
										children: "4.6 ★"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-bold text-[#5B6B7F] block mt-1",
										children: "Work-Life Balance"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-[#F5F8FC] border border-[#DCE5F0] text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-3xl font-black text-[#063B78]",
										children: "4.8 ★"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-bold text-[#5B6B7F] block mt-1",
										children: "Salary & Benefits"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-[#F5F8FC] border border-[#DCE5F0] text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-3xl font-black text-[#063B78]",
										children: "4.7 ★"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-bold text-[#5B6B7F] block mt-1",
										children: "Job Security"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-[#F5F8FC] border border-[#DCE5F0] text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-3xl font-black text-[#063B78]",
										children: "4.5 ★"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-bold text-[#5B6B7F] block mt-1",
										children: "Skill Growth"
									})]
								})
							]
						})]
					}),
					activeTab === "locations" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white p-6 sm:p-8 rounded-3xl border border-[#DCE5F0] shadow-xs space-y-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "text-xl font-black text-[#10233F]",
							children: [
								companyMeta.name,
								" ",
								lang === "mr" ? "मुख्य आणि प्रादेशिक कार्यालये" : "Offices & Site Branches"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid sm:grid-cols-2 gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-2xl bg-[#F5F8FC] border border-[#DCE5F0]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
									className: "font-black text-sm text-[#063B78] flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" }), " Head Office (मुख्यालय)"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold text-[#5B6B7F] mt-1",
									children: companyMeta.headquarters
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-2xl bg-[#F5F8FC] border border-[#DCE5F0]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
									className: "font-black text-sm text-[#063B78] flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" }), " Maharashtra Regional Hub"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold text-[#5B6B7F] mt-1",
									children: "MIDC Industrial Complex, Pune & Navi Mumbai"
								})]
							})]
						})]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
	] });
}
var Route$15 = createFileRoute("/jobs/")({
	validateSearch: (search) => {
		return { category: typeof search["category"] === "string" ? search["category"] : void 0 };
	},
	head: () => ({ meta: [{ title: "Find Jobs — REAL JOB | Find Work | Find Workers" }, {
		name: "description",
		content: "Browse verified factory, construction, driver, ITI and technical jobs across Maharashtra and India."
	}] }),
	component: JobsListingPage
});
function JobsListingPage() {
	const { t, n, lang } = useI18n();
	const searchParams = Route$15.useSearch();
	const [searchTerm, setSearchTerm] = (0, import_react.useState)("");
	const [categoryFilter, setCategoryFilter] = (0, import_react.useState)(searchParams.category || "all");
	const [subCategoryFilter, setSubCategoryFilter] = (0, import_react.useState)("all");
	const [locationFilter, setLocationFilter] = (0, import_react.useState)("all");
	const [salaryFilter, setSalaryFilter] = (0, import_react.useState)("all");
	const [experienceFilter, setExperienceFilter] = (0, import_react.useState)("all");
	const [typeFilter, setTypeFilter] = (0, import_react.useState)("all");
	const [sortBy, setSortBy] = (0, import_react.useState)("newest");
	const [mobileFilterOpen, setMobileFilterOpen] = (0, import_react.useState)(false);
	const [workModeFilter, setWorkModeFilter] = (0, import_react.useState)("all");
	(0, import_react.useEffect)(() => {
		setCategoryFilter(searchParams.category || "all");
		setSubCategoryFilter("all");
	}, [searchParams.category]);
	const isInitialState = (!categoryFilter || categoryFilter === "all") && !searchTerm && (!locationFilter || locationFilter === "all") && (!typeFilter || typeFilter === "all") && (!workModeFilter || workModeFilter === "all") && (!experienceFilter || experienceFilter === "all") && (!salaryFilter || salaryFilter === "all");
	const subCategoryMap = {
		"construction": [
			{
				id: "Civil Engineer",
				label: "Civil Engineer"
			},
			{
				id: "Site Engineer",
				label: "Site Engineer"
			},
			{
				id: "Architect",
				label: "Architect"
			},
			{
				id: "Site Supervisor",
				label: "Site Supervisor"
			},
			{
				id: "Quantity Surveyor",
				label: "Quantity Surveyor"
			},
			{
				id: "Project Manager",
				label: "Project Manager"
			},
			{
				id: "Safety Officer",
				label: "Safety Officer"
			}
		],
		"it-software": [
			{
				id: "Software Developer",
				label: "Software Developer"
			},
			{
				id: "Web Developer",
				label: "Web Developer"
			},
			{
				id: "Full Stack Developer",
				label: "Full Stack Developer"
			},
			{
				id: "Frontend Developer",
				label: "Frontend Developer"
			},
			{
				id: "Backend Developer",
				label: "Backend Developer"
			},
			{
				id: "UI/UX Designer",
				label: "UI/UX Designer"
			},
			{
				id: "DevOps Engineer",
				label: "DevOps Engineer"
			},
			{
				id: "Data Analyst",
				label: "Data Analyst"
			},
			{
				id: "Cyber Security",
				label: "Cyber Security"
			}
		],
		"engineering": [
			{
				id: "Mechanical Engineer",
				label: "Mechanical Engineer"
			},
			{
				id: "Electrical Engineer",
				label: "Electrical Engineer"
			},
			{
				id: "Civil Engineer",
				label: "Civil Engineer"
			},
			{
				id: "Electronics Engineer",
				label: "Electronics Engineer"
			},
			{
				id: "Production Engineer",
				label: "Production Engineer"
			},
			{
				id: "Automobile Engineer",
				label: "Automobile Engineer"
			},
			{
				id: "Quality Engineer",
				label: "Quality Engineer"
			}
		],
		"healthcare-medical": [
			{
				id: "Doctor",
				label: "Doctor"
			},
			{
				id: "Nurse",
				label: "Nurse"
			},
			{
				id: "Pharmacist",
				label: "Pharmacist"
			},
			{
				id: "Lab Technician",
				label: "Lab Technician"
			},
			{
				id: "Medical Assistant",
				label: "Medical Assistant"
			},
			{
				id: "Hospital Administration",
				label: "Hospital Administration"
			}
		],
		"finance-accounting": [
			{
				id: "Accountant",
				label: "Accountant"
			},
			{
				id: "Finance Executive",
				label: "Finance Executive"
			},
			{
				id: "Banking",
				label: "Banking"
			},
			{
				id: "Auditor",
				label: "Auditor"
			},
			{
				id: "Tax Consultant",
				label: "Tax Consultant"
			},
			{
				id: "Financial Analyst",
				label: "Financial Analyst"
			}
		],
		"sales-marketing": [
			{
				id: "Sales Executive",
				label: "Sales Executive"
			},
			{
				id: "Business Development",
				label: "Business Development"
			},
			{
				id: "Digital Marketing",
				label: "Digital Marketing"
			},
			{
				id: "Marketing Executive",
				label: "Marketing Executive"
			},
			{
				id: "Sales Manager",
				label: "Sales Manager"
			},
			{
				id: "Telecaller",
				label: "Telecaller"
			}
		],
		"education": [
			{
				id: "Teacher",
				label: "Teacher"
			},
			{
				id: "Professor",
				label: "Professor"
			},
			{
				id: "Lecturer",
				label: "Lecturer"
			},
			{
				id: "Tutor",
				label: "Tutor"
			},
			{
				id: "Academic Coordinator",
				label: "Academic Coordinator"
			},
			{
				id: "School Administrator",
				label: "School Administrator"
			}
		],
		"manufacturing": [
			{
				id: "Production",
				label: "Production"
			},
			{
				id: "Quality Control",
				label: "Quality Control"
			},
			{
				id: "Machine Operator",
				label: "Machine Operator"
			},
			{
				id: "Maintenance Engineer",
				label: "Maintenance Engineer"
			},
			{
				id: "Production Manager",
				label: "Production Manager"
			}
		],
		"hr-recruitment": [
			{
				id: "HR Executive",
				label: "HR Executive"
			},
			{
				id: "HR Manager",
				label: "HR Manager"
			},
			{
				id: "Recruiter",
				label: "Recruiter"
			},
			{
				id: "Talent Acquisition",
				label: "Talent Acquisition"
			},
			{
				id: "Payroll Executive",
				label: "Payroll Executive"
			}
		],
		"hospitality-tourism": [
			{
				id: "Hotel Management",
				label: "Hotel Management"
			},
			{
				id: "Chef",
				label: "Chef"
			},
			{
				id: "Front Office",
				label: "Front Office"
			},
			{
				id: "Housekeeping",
				label: "Housekeeping"
			},
			{
				id: "Travel Executive",
				label: "Travel Executive"
			}
		],
		"logistics-transport": [
			{
				id: "Logistics Executive",
				label: "Logistics Executive"
			},
			{
				id: "Warehouse Manager",
				label: "Warehouse Manager"
			},
			{
				id: "Delivery Executive",
				label: "Delivery Executive"
			},
			{
				id: "Supply Chain",
				label: "Supply Chain"
			},
			{
				id: "Transport Manager",
				label: "Transport Manager"
			}
		],
		"government-public": [
			{
				id: "Government Jobs",
				label: "Government Jobs"
			},
			{
				id: "PSU Jobs",
				label: "PSU Jobs"
			},
			{
				id: "Administrative Jobs",
				label: "Administrative Jobs"
			},
			{
				id: "Public Services",
				label: "Public Services"
			}
		],
		"legal": [
			{
				id: "Lawyer",
				label: "Lawyer"
			},
			{
				id: "Legal Advisor",
				label: "Legal Advisor"
			},
			{
				id: "Legal Executive",
				label: "Legal Executive"
			},
			{
				id: "Compliance Officer",
				label: "Compliance Officer"
			}
		],
		"architecture-design": [
			{
				id: "Architect",
				label: "Architect"
			},
			{
				id: "Interior Designer",
				label: "Interior Designer"
			},
			{
				id: "3D Visualizer",
				label: "3D Visualizer"
			},
			{
				id: "CAD Designer",
				label: "CAD Designer"
			}
		],
		"retail-ecommerce": [
			{
				id: "Store Manager",
				label: "Store Manager"
			},
			{
				id: "Retail Executive",
				label: "Retail Executive"
			},
			{
				id: "E-commerce Executive",
				label: "E-commerce Executive"
			},
			{
				id: "Customer Service",
				label: "Customer Service"
			}
		],
		"customer-service-bpo": [
			{
				id: "Customer Support",
				label: "Customer Support"
			},
			{
				id: "Call Center",
				label: "Call Center"
			},
			{
				id: "BPO Executive",
				label: "BPO Executive"
			},
			{
				id: "Technical Support",
				label: "Technical Support"
			}
		],
		"design-creative": [
			{
				id: "Graphic Designer",
				label: "Graphic Designer"
			},
			{
				id: "UI/UX Designer",
				label: "UI/UX Designer"
			},
			{
				id: "Video Editor",
				label: "Video Editor"
			},
			{
				id: "Content Creator",
				label: "Content Creator"
			},
			{
				id: "Photographer",
				label: "Photographer"
			}
		],
		"media-communication": [
			{
				id: "Content Writer",
				label: "Content Writer"
			},
			{
				id: "Journalist",
				label: "Journalist"
			},
			{
				id: "Social Media Manager",
				label: "Social Media Manager"
			},
			{
				id: "PR Executive",
				label: "PR Executive"
			}
		],
		"agriculture-farming": [
			{
				id: "Agricultural Engineer",
				label: "Agricultural Engineer"
			},
			{
				id: "Farm Manager",
				label: "Farm Manager"
			},
			{
				id: "Agronomist",
				label: "Agronomist"
			},
			{
				id: "Agriculture Officer",
				label: "Agriculture Officer"
			}
		],
		"science-research": [
			{
				id: "Research Scientist",
				label: "Research Scientist"
			},
			{
				id: "Laboratory Researcher",
				label: "Laboratory Researcher"
			},
			{
				id: "Biotechnologist",
				label: "Biotechnologist"
			},
			{
				id: "Research Assistant",
				label: "Research Assistant"
			}
		]
	};
	const resetFilters = () => {
		setSearchTerm("");
		setCategoryFilter("all");
		setLocationFilter("all");
		setSalaryFilter("all");
		setExperienceFilter("all");
		setTypeFilter("all");
		setWorkModeFilter("all");
		setSortBy("newest");
		setSubCategoryFilter("all");
	};
	const filteredJobs = (0, import_react.useMemo)(() => {
		return dataStore.getActiveJobs().map((dj) => ({
			id: dj.id,
			title: dj.title,
			company: dj.company,
			location: dj.location,
			salary: dj.salary,
			experience: dj.experience,
			type: dj.jobType,
			workMode: dj.workMode || "On-site",
			posted: dj.postedAgo || "Recently",
			initials: dj.initials || dj.company.slice(0, 2).toUpperCase(),
			category: dj.category,
			featured: dj.featured ?? false,
			openings: dj.vacancies ?? 1
		})).filter((job) => {
			const term = searchTerm.toLowerCase();
			const matchesSearch = !term || job.title.toLowerCase().includes(term) || job.company.toLowerCase().includes(term) || job.location.toLowerCase().includes(term) || job.category && job.category.toLowerCase().includes(term);
			let matchesCategory = false;
			if (categoryFilter === "all" || !categoryFilter) matchesCategory = true;
			else {
				const normalizedFilter = categoryFilter.toLowerCase().replace(/ & /g, "-").replace(/ /g, "-");
				const jobCatNorm = (job.category || "").toLowerCase().replace(/ & /g, "-").replace(/ /g, "-");
				const subCats = subCategoryMap[normalizedFilter] || [];
				const isMainCategoryMatch = jobCatNorm.includes(normalizedFilter) || normalizedFilter.includes(jobCatNorm);
				const isSubCategoryMatch = subCats.some((sub) => job.title.toLowerCase().includes(sub.id.toLowerCase()) || job.category.toLowerCase().includes(sub.id.toLowerCase()));
				matchesCategory = isMainCategoryMatch || isSubCategoryMatch;
			}
			if (matchesCategory && subCategoryFilter !== "all" && subCategoryFilter) {
				const subClean = subCategoryFilter.toLowerCase();
				const titleClean = job.title.toLowerCase();
				const catClean = (job.category || "").toLowerCase();
				matchesCategory = titleClean.includes(subClean) || catClean.includes(subClean) || subClean.includes(titleClean);
			}
			const matchesLocation = locationFilter === "all" || job.location.toLowerCase().includes(locationFilter.toLowerCase());
			const matchesType = typeFilter === "all" || job.type.toLowerCase() === typeFilter.toLowerCase();
			const matchesWorkMode = workModeFilter === "all" || job.workMode.toLowerCase() === workModeFilter.toLowerCase();
			let matchesExp = true;
			if (experienceFilter !== "all") {
				const expStr = job.experience.toLowerCase();
				if (experienceFilter === "Fresher") matchesExp = expStr.includes("fresher") || expStr.includes("0-2");
				else if (experienceFilter === "1-3") matchesExp = expStr.includes("1-3") || expStr.includes("1+") || expStr.includes("0-2") || expStr.includes("2-5");
				else if (experienceFilter === "3-5") matchesExp = expStr.includes("3+") || expStr.includes("2-5") || expStr.includes("3-5") || expStr.includes("5+");
				else if (experienceFilter === "5+") matchesExp = expStr.includes("5+");
			}
			let matchesSalary = true;
			if (salaryFilter !== "all") {
				const minTarget = parseInt(salaryFilter);
				const match = job.salary.match(/\d+,\d+/);
				if (match) matchesSalary = parseInt(match[0].replace(",", "")) >= minTarget;
				else if (job.salary.includes("/day")) {
					const dayMatch = job.salary.match(/\d+/);
					if (dayMatch) matchesSalary = parseInt(dayMatch[0]) * 26 >= minTarget;
				}
			}
			return matchesSearch && matchesCategory && matchesLocation && matchesType && matchesWorkMode && matchesExp && matchesSalary;
		});
	}, [
		searchTerm,
		categoryFilter,
		locationFilter,
		typeFilter,
		workModeFilter,
		subCategoryFilter,
		experienceFilter,
		salaryFilter,
		lang
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "bg-[#F5F8FC] min-h-screen py-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-hero-overlay p-8 rounded-2xl text-white mb-8 shadow-lg relative overflow-hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative z-10 max-w-3xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-bold uppercase tracking-wider text-[#FFC400] backdrop-blur mb-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-3.5" }), t("jobs")]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
									className: "text-3xl sm:text-4xl font-black text-white",
									children: [
										t("jobsInRegion"),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[#FFC400]",
											children: t("directCompanyContact")
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-white/90 font-medium",
									children: t("jobsSubtext")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-6 grid sm:grid-cols-[1fr_0.8fr_auto] gap-3 bg-white p-2.5 rounded-xl shadow-md border border-[#DCE5F0]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative flex items-center",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 size-4 text-[#5B6B7F]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												placeholder: t("searchJobPlaceholder"),
												value: searchTerm,
												onChange: (e) => setSearchTerm(e.target.value),
												className: "pl-9 h-11 border-0 bg-transparent text-xs text-[#10233F] font-bold focus-visible:ring-0"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative flex items-center",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "absolute left-3 size-4 text-[#125BB5]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
												value: locationFilter,
												onChange: (e) => setLocationFilter(e.target.value),
												className: "w-full h-11 border-0 bg-transparent text-xs font-bold text-[#10233F] pl-9 pr-3 focus:outline-none",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "all",
														children: t("allLocations")
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "mumbai",
														children: "Mumbai"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "pune",
														children: "Pune"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "chakan",
														children: "Chakan"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "bengaluru",
														children: "Bengaluru"
													})
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											className: "btn-yellow h-11 font-black text-xs px-6",
											children: t("search")
										})
									]
								})
							]
						})
					}),
					(!categoryFilter || categoryFilter === "all") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-8 bg-white p-6 rounded-2xl border border-[#DCE5F0] shadow-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "text-xl font-black text-[#10233F] mb-6 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, { className: "size-5 text-[#063B78]" }), t("popularCategories")]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopularCategories, {
							limit: 20,
							hideHeader: true
						})]
					}),
					!isInitialState && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `grid grid-cols-1 ${categoryFilter !== "all" && categoryFilter ? "lg:grid-cols-[280px_1fr]" : ""} gap-8 items-start`,
						children: [categoryFilter !== "all" && categoryFilter && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
							className: "hidden lg:block bg-white p-6 rounded-2xl border border-[#DCE5F0] shadow-xs sticky top-24",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between pb-4 border-b border-[#DCE5F0] mb-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-black text-sm text-[#10233F] flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "size-4 text-[#063B78]" }), t("filters")]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: resetFilters,
										className: "text-xs font-bold text-[#125BB5] hover:underline flex items-center gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3" }),
											" ",
											t("reset")
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
										children: t("experience")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: experienceFilter,
										onChange: (e) => setExperienceFilter(e.target.value),
										className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "all",
												children: t("experience")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Fresher",
												children: "Fresher"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "1-3",
												children: "1-3 Years"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "3-5",
												children: "3-5 Years"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "5+",
												children: "5+ Years"
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
										children: t("expectedSalary")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: salaryFilter,
										onChange: (e) => setSalaryFilter(e.target.value),
										className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "all",
												children: t("expectedSalary")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "10000",
												children: "₹10,000+ / mo"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "15000",
												children: "₹15,000+ / mo"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "20000",
												children: "₹20,000+ / mo"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "25000",
												children: "₹25,000+ / mo"
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
										children: t("jobTypeLabel")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: typeFilter,
										onChange: (e) => setTypeFilter(e.target.value),
										className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "all",
												children: t("allTypes")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Full-time",
												children: t("fullTime")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Part-time",
												children: t("partTime")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Contract",
												children: t("contract")
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
										children: "Work Mode / मोड"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: workModeFilter,
										onChange: (e) => setWorkModeFilter(e.target.value),
										className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "all",
												children: "All Modes / सर्व मोड"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Remote",
												children: "🏠 Work From Home (WFH)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "On-site",
												children: "🏢 On-site (Office / Site)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Hybrid",
												children: "🔄 Hybrid"
											})
										]
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "w-full",
							children: [
								categoryFilter !== "all" && categoryFilter && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-[#DCE5F0] mb-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex items-center gap-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-sm font-black text-[#10233F]",
											children: [
												t("totalJobsCount"),
												": ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[#063B78]",
													children: n(filteredJobs.length)
												})
											]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											variant: "outline",
											size: "sm",
											className: "lg:hidden text-xs font-bold border-[#063B78] text-[#063B78]",
											onClick: () => setMobileFilterOpen(true),
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { className: "size-3.5 mr-1" }),
												" ",
												t("filters")
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-xs font-bold text-[#5B6B7F] shrink-0",
												children: [t("sortByLabel"), ":"]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
												value: sortBy,
												onChange: (e) => setSortBy(e.target.value),
												className: "h-9 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "newest",
													children: t("newestFirst")
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "title",
													children: t("byTitle")
												})]
											})]
										})]
									})]
								}),
								categoryFilter !== "all" && categoryFilter && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-8",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex border-b border-[#DCE5F0] mb-6 overflow-x-auto no-scrollbar items-end gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => {
												setCategoryFilter("all");
												setSubCategoryFilter("all");
											},
											className: "px-3 py-2 text-[#5B6B7F] hover:text-[#10233F] hover:bg-[#F5F8FC] rounded-lg mb-1 ml-1 flex items-center gap-1.5 text-[13px] font-bold transition-colors shrink-0",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }),
												" ",
												t("viewWebsite")
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative px-8 py-3 text-sm font-black text-[#10233F] bg-white border border-b-0 border-[#DCE5F0] rounded-t-[16px] shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)] z-10 flex items-center gap-2 shrink-0",
											children: [
												categoryFilter === "factory-workers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Factory, { className: "size-4" }) : categoryFilter === "construction-workers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HardHat, { className: "size-4" }) : categoryFilter === "technical-staff" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, { className: "size-4" }) : categoryFilter === "logistics-drivers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "size-4" }) : categoryFilter === "skilled-workers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-4" }) : categoryFilter === "unskilled-workers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4" }) : categoryFilter === "helpers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Headphones, { className: "size-4" }) : categoryFilter === "electricians" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-4" }) : categoryFilter === "maintenance" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building, { className: "size-4" }) : categoryFilter === "warehouse-workers" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackageCheck, { className: "size-4" }) : categoryFilter === "hotel-restaurant" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hotel, { className: "size-4" }) : categoryFilter === "security" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4" }),
												getCategoryTitle(categoryFilter, lang) || categoryFilter,
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-3 bottom-0 w-3 h-full bg-white skew-x-[15deg] origin-bottom border-r border-[#DCE5F0]" })
											]
										})]
									}), subCategoryMap[categoryFilter] && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => setSubCategoryFilter("all"),
											className: `px-5 py-2.5 rounded-full text-[11px] font-black tracking-wide uppercase transition-all shadow-sm flex items-center gap-2 ${subCategoryFilter === "all" ? "bg-[#063B78] text-white shadow-md scale-105" : "bg-white border border-[#DCE5F0] text-[#5B6B7F] hover:bg-[#F5F8FC] hover:text-[#10233F] hover:scale-105"}`,
											children: t("allCategories")
										}), subCategoryMap[categoryFilter].map((sub) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => setSubCategoryFilter(sub.id),
											className: `px-5 py-2.5 rounded-full text-[11px] font-black tracking-wide uppercase transition-all shadow-sm flex items-center gap-2 ${subCategoryFilter === sub.id ? "bg-[#063B78] text-white shadow-md scale-105" : "bg-white border border-[#DCE5F0] text-[#5B6B7F] hover:bg-[#F5F8FC] hover:text-[#10233F] hover:scale-105"}`,
											children: sub.label
										}, sub.id))]
									})]
								}),
								filteredJobs.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 lg:grid-cols-2 gap-5",
									children: filteredJobs.map((job) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JobCard, { job }, job.id))
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "card-realjob p-12 text-center bg-white rounded-2xl border border-[#DCE5F0]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "mx-auto size-14 text-[#5B6B7F] mb-4" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-xl font-black text-[#10233F]",
											children: "कोणतीही नोकरी उपलब्ध नाही (No Jobs Found)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold text-[#5B6B7F] mt-2",
											children: "अद्याप कोणतीही नवीन नोकरी पोस्ट केलेली नाही. मालक / कंपनी नवीन नोकरी पोस्ट करतील तेव्हा ती येथे थेट दिसेल."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											onClick: resetFilters,
											className: "mt-5 btn-yellow text-xs font-bold px-6",
											children: t("resetFilters")
										})
									]
								})
							]
						})]
					})
				]
			}), mobileFilterOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-[#082F63]/60 backdrop-blur-sm flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-xs bg-white h-full p-6 overflow-y-auto shadow-2xl flex flex-col justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between pb-4 border-b border-[#DCE5F0] mb-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-black text-base text-[#10233F]",
							children: t("filters")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setMobileFilterOpen(false),
							className: "p-1 text-[#5B6B7F]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-6" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
								children: lang === "mr" ? "अनुभव" : "Experience"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: experienceFilter,
								onChange: (e) => setExperienceFilter(e.target.value),
								className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "all",
										children: lang === "mr" ? "सर्व अनुभव" : "Any Experience"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Fresher",
										children: lang === "mr" ? "फ्रेसर" : "Fresher"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: "1-3",
										children: ["1-3 ", lang === "mr" ? "वर्षे" : "Years"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: "3-5",
										children: ["3-5 ", lang === "mr" ? "वर्षे" : "Years"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: "5+",
										children: ["5+ ", lang === "mr" ? "वर्षे" : "Years"]
									})
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
								children: lang === "mr" ? "किमान पगार" : "Minimum Salary"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: salaryFilter,
								onChange: (e) => setSalaryFilter(e.target.value),
								className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "all",
										children: lang === "mr" ? "कोणताही पगार" : "Any Salary"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: "10000",
										children: ["₹10,000+ / ", lang === "mr" ? "महिना" : "mo"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: "15000",
										children: ["₹15,000+ / ", lang === "mr" ? "महिना" : "mo"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: "20000",
										children: ["₹20,000+ / ", lang === "mr" ? "महिना" : "mo"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: "25000",
										children: ["₹25,000+ / ", lang === "mr" ? "महिना" : "mo"]
									})
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
								children: t("jobTypeLabel")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: typeFilter,
								onChange: (e) => setTypeFilter(e.target.value),
								className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "all",
										children: t("allTypes")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Full-time",
										children: t("fullTime")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Part-time",
										children: t("partTime")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Contract",
										children: t("contract")
									})
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
								children: "Work Mode / मोड"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: workModeFilter,
								onChange: (e) => setWorkModeFilter(e.target.value),
								className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "all",
										children: "All Modes / सर्व मोड"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Remote",
										children: "🏠 Work From Home (WFH)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "On-site",
										children: "🏢 On-site (Office / Site)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Hybrid",
										children: "🔄 Hybrid"
									})
								]
							})] })
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-6 border-t border-[#DCE5F0] grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: resetFilters,
							className: "text-xs font-bold",
							children: t("reset")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => setMobileFilterOpen(false),
							className: "btn-yellow text-xs font-extrabold",
							children: t("continue")
						})]
					})]
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
	] });
}
var Route$14 = createFileRoute("/jobs/$jobId")({
	head: ({ params }) => ({ meta: [{ title: `${params.jobId.replaceAll("-", " ")} — REAL JOB` }, {
		name: "description",
		content: "Apply directly for verified factory, construction, driver and technical jobs on REAL JOB."
	}] }),
	component: JobDetailPage
});
function getJobDetails(jobId) {
	const storeJob = dataStore.getJobById(jobId);
	if (storeJob) return {
		id: storeJob.id,
		title: storeJob.title,
		company: storeJob.company,
		location: storeJob.location,
		salary: storeJob.salary,
		experience: storeJob.experience,
		type: storeJob.jobType,
		workMode: storeJob.workMode || "On-site",
		posted: storeJob.postedAgo || "Recently",
		initials: storeJob.initials || storeJob.company.slice(0, 2).toUpperCase(),
		category: storeJob.category,
		featured: storeJob.featured,
		openings: storeJob.vacancies,
		description: storeJob.description,
		responsibilities: storeJob.responsibilities,
		requiredSkills: storeJob.requiredSkills,
		applicationConfig: storeJob.applicationConfig
	};
	return jobs.find((j) => j.id === jobId) ?? jobs[0];
}
function JobDetailPage() {
	const { t, n, lang } = useI18n();
	const { jobId } = useParams({ from: "/jobs/$jobId" });
	const job = getJobDetails(jobId);
	const [saved, setSaved] = (0, import_react.useState)(false);
	const [showApplyModal, setShowApplyModal] = (0, import_react.useState)(false);
	const [applied, setApplied] = (0, import_react.useState)(false);
	const [applicantName, setApplicantName] = (0, import_react.useState)("");
	const [applicantPhone, setApplicantPhone] = (0, import_react.useState)("");
	const [applicantExp, setApplicantExp] = (0, import_react.useState)("3 Years");
	const [fieldValues, setFieldValues] = (0, import_react.useState)({});
	const [customAnswers, setCustomAnswers] = (0, import_react.useState)({});
	jobs.filter((j) => j.id !== job.id).slice(0, 3);
	const appConfig = job.applicationConfig || {
		fields: {
			fullName: "required",
			mobile: "required",
			experience: "optional"
		},
		customQuestions: []
	};
	const handleFieldChange = (key, val) => setFieldValues((p) => ({
		...p,
		[key]: val
	}));
	const handleCustomChange = (id, val) => setCustomAnswers((p) => ({
		...p,
		[id]: val
	}));
	const handleApplySubmit = (e) => {
		e.preventDefault();
		const currentUser = dataStore.getCurrentUser();
		const seekerId = currentUser ? currentUser.email || currentUser.id || "seeker-demo" : applicantName ? `seeker-${applicantName}` : "candidate@realjob.com";
		const name = applicantName || currentUser?.fullName || "Candidate";
		if (dataStore.hasAlreadyApplied(seekerId, job.id)) {
			toast.error(lang === "mr" ? "तुम्ही या नोकरीसाठी आधीच अर्ज भरला आहे!" : "You have already applied to this job!");
			setShowApplyModal(false);
			return;
		}
		try {
			dataStore.createApplication({
				jobId: job.id,
				employerId: job.company,
				jobSeekerId: seekerId,
				candidateName: name,
				candidateEmail: seekerId,
				candidateMobile: fieldValues.mobile || applicantPhone || "+91 98220 11223",
				jobTitle: job.title,
				companyName: job.company,
				location: job.location,
				salary: job.salary,
				resume: fieldValues.resume || `${name.replaceAll(" ", "_")}_Resume.pdf`,
				fieldValues,
				customAnswers,
				category: job.category
			});
			setApplied(true);
			toast.success(`Application submitted for ${job.title}! ${job.company} will call you shortly.`);
			setTimeout(() => {
				setShowApplyModal(false);
				setApplied(false);
			}, 2e3);
		} catch (err) {
			toast.error(err.message || "Failed to submit application");
		}
	};
	const handleShare = () => {
		if (navigator.share) navigator.share({
			title: `${job.title} at ${job.company}`,
			text: `Check out this job opening on REAL JOB: ${job.title} (${job.salary})`,
			url: window.location.href
		});
		else {
			navigator.clipboard.writeText(window.location.href);
			toast.success("Job link copied to clipboard!");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "bg-[#F5F8FC] min-h-screen py-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-4 sm:px-6 lg:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-4 mb-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => window.history.back(),
							className: "px-3 py-2 text-[#5B6B7F] hover:text-[#10233F] hover:bg-white rounded-lg flex items-center gap-1.5 text-[13px] font-bold transition-colors shrink-0 shadow-sm border border-[#DCE5F0] bg-white",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }),
								" ",
								lang === "mr" ? "मागे जा" : "Back"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-xs font-bold text-[#5B6B7F]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/",
									className: "hover:text-[#063B78]",
									children: t("home")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "/" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/jobs",
									className: "hover:text-[#063B78]",
									children: t("jobs")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "/" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[#10233F]",
									children: job.title
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-white rounded-2xl p-6 sm:p-8 border border-[#DCE5F0] shadow-sm mb-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-16 shrink-0 place-items-center rounded-2xl bg-[#063B78] font-black text-2xl text-white shadow-md",
									children: job.initials
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 flex-wrap",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
											className: "bg-[#FFC400] text-[#082F63] font-black text-xs px-2.5 py-0.5",
											children: ["✓ ", t("verifiedCompany")]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: "outline",
											className: "border-[#063B78] text-[#063B78] font-bold text-xs",
											children: job.workMode
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "text-2xl sm:text-3xl font-black text-[#10233F] mt-1",
										children: job.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm font-extrabold text-[#125BB5] flex items-center gap-1.5 mt-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4" }),
											" ",
											job.company
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-3 flex flex-wrap gap-4 text-xs font-bold text-[#5B6B7F]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-1",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4 text-[#063B78]" }),
													" ",
													job.location
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-1 text-[#063B78]",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-4 text-[#FFC400]" }),
													" ",
													n(job.salary)
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-1",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { className: "size-4 text-[#5B6B7F]" }),
													" ",
													n(job.posted)
												]
											})
										]
									})
								] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex sm:flex-col gap-3 w-full sm:w-auto shrink-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: () => setShowApplyModal(true),
									className: "btn-yellow flex-1 sm:flex-none font-black text-xs px-8 py-3 h-11",
									children: t("applyNow")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: "outline",
										onClick: () => setSaved(!saved),
										className: `flex-1 border-[#063B78] font-bold text-xs h-11 ${saved ? "bg-[#EBF1F8] text-[#063B78]" : "text-[#063B78]"}`,
										children: [saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkCheck, { className: "size-4 mr-1 text-[#063B78]" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-4 mr-1" }), saved ? t("save") : t("save")]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "outline",
										onClick: handleShare,
										className: "border-[#063B78] text-[#063B78] font-bold text-xs h-11 px-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-4" })
									})]
								})]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid lg:grid-cols-3 gap-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "lg:col-span-2 space-y-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 sm:p-8 rounded-2xl border border-[#DCE5F0] shadow-xs space-y-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-lg font-black text-[#10233F] mb-3",
										children: t("jobDescription")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold text-[#5B6B7F] leading-relaxed",
										children: "Urgent requirement for skilled and experienced workforce in factory operations. The candidate should have relevant experience, willingness to work in shifts and maintain quality standards."
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-lg font-black text-[#10233F] mb-3",
										children: t("responsibilities")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
										className: "space-y-2 text-sm font-semibold text-[#5B6B7F] list-disc pl-5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Perform day-to-day operations and maintenance." }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Follow safety guidelines and complete production targets on time." }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Coordinate with team supervisor and plant management." })
										]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-lg font-black text-[#10233F] mb-3",
										children: t("requirements")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
										className: "space-y-2 text-sm font-semibold text-[#5B6B7F] list-disc pl-5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "10th / 12th Pass or ITI Trade Certificate." }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "1 to 5 years relevant trade experience." }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Punctuality and dedication to work." })
										]
									})] })
								]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white p-6 rounded-2xl border border-[#DCE5F0] shadow-xs sticky top-24 space-y-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-lg font-black text-[#10233F]",
									children: t("talkDirectlyToEmployer")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold text-[#5B6B7F] mt-1",
									children: t("directContactDesc")
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-3 pt-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 text-xs font-bold text-[#10233F]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-[#FFC400]" }),
												" ",
												t("freeApplication")
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 text-xs font-bold text-[#10233F]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-[#FFC400]" }),
												" ",
												t("response24h")
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 text-xs font-bold text-[#10233F]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-[#FFC400]" }),
												" ",
												t("verifiedCompany")
											]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: () => setShowApplyModal(true),
									className: "w-full btn-yellow font-black text-xs py-3 h-11",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4 mr-1.5" }),
										" ",
										t("applyNow")
									]
								})
							]
						}) })]
					})
				]
			}), showApplyModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-[#082F63]/60 backdrop-blur-sm flex items-center justify-center p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white w-full max-w-md rounded-2xl p-6 shadow-2xl relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setShowApplyModal(false),
						className: "absolute right-4 top-4 text-[#5B6B7F]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					}), applied ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center py-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-16 text-[#063B78] mx-auto mb-3 animate-bounce" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xl font-black text-[#10233F]",
								children: t("applicationSubmitted")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold text-[#5B6B7F] mt-2",
								children: t("applicationSubmittedDesc")
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleApplySubmit,
						className: "space-y-4 max-h-[70vh] overflow-y-auto px-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg font-black text-[#10233F] sticky top-0 bg-white z-10 pb-2",
								children: job.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs font-semibold text-[#5B6B7F]",
								children: [
									job.company,
									" • ",
									job.location
								]
							}),
							Object.keys(appConfig.fields).map((fieldKey) => {
								const req = appConfig.fields[fieldKey];
								if (req === "hidden") return null;
								const isReq = req === "required";
								const label = fieldKey.replace(/([A-Z])/g, " $1").trim().replace(/^./, (str) => str.toUpperCase());
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-1",
									children: [
										label,
										" ",
										isReq && "*"
									]
								}), fieldKey === "resume" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									required: isReq,
									onChange: (e) => handleFieldChange(fieldKey, e.target.files?.[0]?.name),
									className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 py-2 text-xs font-bold text-[#10233F]"
								}) : fieldKey === "experience" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									required: isReq,
									value: fieldValues[fieldKey] || "",
									onChange: (e) => handleFieldChange(fieldKey, e.target.value),
									className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											children: "Select Experience"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Fresher",
											children: "Fresher"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "1-3 Years",
											children: "1 - 3 Years"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "3-5 Years",
											children: "3 - 5 Years"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "5+ Years",
											children: "5+ Years"
										})
									]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: fieldKey.includes("Email") ? "email" : fieldKey.includes("mobile") ? "tel" : "text",
									required: isReq,
									value: fieldValues[fieldKey] || "",
									onChange: (e) => handleFieldChange(fieldKey, e.target.value),
									className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]"
								})] }, fieldKey);
							}),
							appConfig.customQuestions && appConfig.customQuestions.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: [
									q.question,
									" ",
									q.required && "*"
								]
							}), q.type === "long" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								required: q.required,
								value: customAnswers[q.id] || "",
								onChange: (e) => handleCustomChange(q.id, e.target.value),
								className: "w-full rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] p-3 text-xs font-bold text-[#10233F]"
							}) : q.type === "yesno" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								required: q.required,
								value: customAnswers[q.id] || "",
								onChange: (e) => handleCustomChange(q.id, e.target.value),
								className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Select option"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Yes",
										children: "Yes"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "No",
										children: "No"
									})
								]
							}) : q.type === "number" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								required: q.required,
								value: customAnswers[q.id] || "",
								onChange: (e) => handleCustomChange(q.id, e.target.value),
								className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								required: q.required,
								value: customAnswers[q.id] || "",
								onChange: (e) => handleCustomChange(q.id, e.target.value),
								className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]"
							})] }, q.id)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								className: "w-full btn-yellow font-black text-xs py-3 h-11 sticky bottom-0",
								children: t("submitApplication")
							})
						]
					})]
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
	] });
}
var Route$13 = createFileRoute("/workers/")({
	head: () => ({ meta: [{ title: "Find Verified Workers & Skilled Labor — REAL JOB" }, {
		name: "description",
		content: "Hire skilled & semi-skilled workers, electricians, technicians, welders, CNC operators & drivers across Maharashtra and India."
	}] }),
	component: WorkersListingPage
});
function WorkersListingPage() {
	const { t, n, lang } = useI18n();
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [locationFilter, setLocationFilter] = (0, import_react.useState)("");
	const [professionFilter, setProfessionFilter] = (0, import_react.useState)("all");
	const [availabilityFilter, setAvailabilityFilter] = (0, import_react.useState)("all");
	const [minExp, setMinExp] = (0, import_react.useState)(0);
	const [sortBy, setSortBy] = (0, import_react.useState)("rating");
	const [mobileFilterOpen, setMobileFilterOpen] = (0, import_react.useState)(false);
	const filteredWorkers = (0, import_react.useMemo)(() => {
		return workersList.filter((worker) => {
			const matchesSearch = worker.name.toLowerCase().includes(searchQuery.toLowerCase()) || worker.profession.toLowerCase().includes(searchQuery.toLowerCase()) || worker.marathiProfession.includes(searchQuery) || worker.skills.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase()));
			const matchesLocation = !locationFilter || worker.location.toLowerCase().includes(locationFilter.toLowerCase());
			const matchesProfession = professionFilter === "all" || worker.profession.toLowerCase().includes(professionFilter.toLowerCase());
			const matchesAvailability = availabilityFilter === "all" || worker.availability === availabilityFilter;
			const matchesExp = (parseInt(worker.experience) || 0) >= minExp;
			return matchesSearch && matchesLocation && matchesProfession && matchesAvailability && matchesExp;
		}).sort((a, b) => {
			if (sortBy === "rating") return b.rating - a.rating;
			if (sortBy === "exp") return (parseInt(b.experience) || 0) - (parseInt(a.experience) || 0);
			return 0;
		});
	}, [
		searchQuery,
		locationFilter,
		professionFilter,
		availabilityFilter,
		minExp,
		sortBy
	]);
	const clearFilters = () => {
		setSearchQuery("");
		setLocationFilter("");
		setProfessionFilter("all");
		setAvailabilityFilter("all");
		setMinExp(0);
		setSortBy("rating");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "bg-[#F5F8FC] min-h-screen py-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bg-hero-overlay p-8 rounded-2xl text-white mb-8 shadow-lg relative overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 max-w-3xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-bold uppercase tracking-wider text-[#FFC400] backdrop-blur mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-3.5" }), t("workers")]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "text-3xl sm:text-4xl font-black text-white",
								children: [
									t("verifiedWorkersHeading"),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[#FFC400]",
										children: t("skilledUnskilledSub")
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-white/90 font-medium",
								children: t("workersHeroSub")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 grid sm:grid-cols-[1fr_0.8fr_auto] gap-3 bg-white p-2.5 rounded-xl shadow-md border border-[#DCE5F0]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative flex items-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 size-4 text-[#5B6B7F]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											placeholder: t("skillPlaceholder"),
											value: searchQuery,
											onChange: (e) => setSearchQuery(e.target.value),
											className: "pl-9 h-11 border-0 bg-transparent text-xs text-[#10233F] font-bold focus-visible:ring-0"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative flex items-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "absolute left-3 size-4 text-[#125BB5]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											placeholder: t("cityPlaceholder"),
											value: locationFilter,
											onChange: (e) => setLocationFilter(e.target.value),
											className: "pl-9 h-11 border-0 bg-transparent text-xs text-[#10233F] font-bold focus-visible:ring-0"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										className: "btn-yellow h-11 font-black text-xs px-6",
										children: t("search")
									})
								]
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-8 items-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "hidden lg:block bg-white p-6 rounded-2xl border border-[#DCE5F0] shadow-xs sticky top-24",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between pb-4 border-b border-[#DCE5F0] mb-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-black text-sm text-[#10233F] flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "size-4 text-[#063B78]" }), t("filters")]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: clearFilters,
									className: "text-xs font-bold text-[#125BB5] hover:underline flex items-center gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3" }),
										" ",
										t("reset")
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase tracking-wider",
									children: t("professionLabel")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: professionFilter,
									onChange: (e) => setProfessionFilter(e.target.value),
									className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "all",
											children: t("allProfessions")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "electrician",
											children: "Electrician"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "cnc",
											children: "CNC Operator"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "driver",
											children: "Driver"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "welder",
											children: "Welder"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "mason",
											children: "Mason"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "plumber",
											children: "Plumber"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase tracking-wider",
									children: t("availabilityLabel")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: availabilityFilter,
									onChange: (e) => setAvailabilityFilter(e.target.value),
									className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "all",
											children: t("allStatus")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Available Now",
											children: "Available Now"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Immediate",
											children: "Immediate"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "1 Week Notice",
											children: "1 Week Notice"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase tracking-wider",
										children: [
											t("minExpLabel"),
											": ",
											n(minExp),
											" Years"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "range",
										min: 0,
										max: 10,
										step: 1,
										value: minExp,
										onChange: (e) => setMinExp(Number(e.target.value)),
										className: "w-full accent-[#063B78]"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between text-[10px] font-bold text-[#5B6B7F] mt-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "0 Yr" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "5 Yrs" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "10+ Yrs" })
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3.5 bg-[#EBF1F8] rounded-xl border border-[#063B78]/20 flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { className: "size-5 text-[#FFC400] fill-[#063B78] shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-bold text-[#063B78] leading-tight",
									children: t("verificationNotice")
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-[#DCE5F0] mb-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm font-black text-[#10233F]",
								children: [
									t("totalWorkersCount"),
									": ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[#063B78]",
										children: n(filteredWorkers.length)
									})
								]
							}), searchQuery && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								variant: "secondary",
								className: "text-xs font-bold bg-[#EBF1F8] text-[#063B78]",
								children: [
									"\"",
									searchQuery,
									"\""
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								className: "lg:hidden text-xs font-bold border-[#063B78] text-[#063B78]",
								onClick: () => setMobileFilterOpen(true),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { className: "size-3.5 mr-1" }),
									" ",
									t("filters")
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-bold text-[#5B6B7F] shrink-0",
									children: [t("sortByLabel"), ":"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: sortBy,
									onChange: (e) => setSortBy(e.target.value),
									className: "h-9 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "rating",
										children: t("highestRated")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "exp",
										children: t("mostExp")
									})]
								})]
							})]
						})]
					}), filteredWorkers.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-6",
						children: filteredWorkers.map((worker) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkerCard, { worker }, worker.id))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "card-realjob p-12 text-center bg-white",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "mx-auto size-14 text-[#5B6B7F] mb-4" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xl font-black text-[#10233F]",
								children: t("noWorkersFound")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold text-[#5B6B7F] mt-2",
								children: t("noWorkersFoundSub")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: clearFilters,
								className: "mt-5 btn-yellow text-xs font-bold px-6",
								children: t("resetFilters")
							})
						]
					})] })]
				})]
			}), mobileFilterOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-[#082F63]/60 backdrop-blur-sm flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-xs bg-white h-full p-6 overflow-y-auto shadow-2xl flex flex-col justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between pb-4 border-b border-[#DCE5F0] mb-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-black text-base text-[#10233F]",
							children: t("filters")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setMobileFilterOpen(false),
							className: "p-1 text-[#5B6B7F]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-6" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
							children: t("professionLabel")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: professionFilter,
							onChange: (e) => setProfessionFilter(e.target.value),
							className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "all",
									children: t("allProfessions")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "electrician",
									children: "Electrician"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "cnc",
									children: "CNC Operator"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "driver",
									children: "Driver"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "welder",
									children: "Welder"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "mason",
									children: "Mason"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "plumber",
									children: "Plumber"
								})
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
							children: t("availabilityLabel")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: availabilityFilter,
							onChange: (e) => setAvailabilityFilter(e.target.value),
							className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "all",
									children: t("allStatus")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Available Now",
									children: "Available Now"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Immediate",
									children: "Immediate"
								})
							]
						})] })]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-6 border-t border-[#DCE5F0] grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: clearFilters,
							className: "text-xs font-bold",
							children: t("reset")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => setMobileFilterOpen(false),
							className: "btn-yellow text-xs font-extrabold",
							children: t("continue")
						})]
					})]
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
	] });
}
var Route$12 = createFileRoute("/workers/$workerId")({
	head: () => ({ meta: [{ title: "Worker Profile — REAL JOB" }, {
		name: "description",
		content: "View verified worker details, trade experience, expected salary, and direct contact options on REAL JOB."
	}] }),
	component: WorkerProfilePage
});
function WorkerProfilePage() {
	const { t, n, lang } = useI18n();
	const { workerId } = useParams({ from: "/workers/$workerId" });
	const worker = workersList.find((w) => w.id === workerId) ?? workersList[0];
	const [showContactModal, setShowContactModal] = (0, import_react.useState)(false);
	const [requestSubmitted, setRequestSubmitted] = (0, import_react.useState)(false);
	const [employerName, setEmployerName] = (0, import_react.useState)("");
	const [employerPhone, setEmployerPhone] = (0, import_react.useState)("");
	const [jobDescription, setJobDescription] = (0, import_react.useState)("");
	const displayProfession = lang === "mr" ? worker.marathiProfession : lang === "hi" ? worker.hindiProfession || worker.profession : worker.profession;
	const handleHireSubmit = (e) => {
		e.preventDefault();
		setRequestSubmitted(true);
		toast.success(`Hire request sent to ${worker.name}! They will contact you shortly.`);
		setTimeout(() => {
			setShowContactModal(false);
			setRequestSubmitted(false);
		}, 2500);
	};
	const handleShare = () => {
		if (navigator.share) navigator.share({
			title: `${worker.name} — ${worker.profession}`,
			text: `Check out ${worker.name} on REAL JOB: ${worker.profession} with ${worker.experience} experience.`,
			url: window.location.href
		});
		else {
			navigator.clipboard.writeText(window.location.href);
			toast.success("Profile link copied to clipboard!");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "bg-[#F5F8FC] min-h-screen py-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-5xl px-4 sm:px-6 lg:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-xs font-bold text-[#5B6B7F] mb-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								className: "hover:text-[#063B78]",
								children: t("home")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "/" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/workers",
								className: "hover:text-[#063B78]",
								children: t("workers")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "/" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[#10233F]",
								children: worker.name
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white rounded-2xl p-6 sm:p-8 border border-[#DCE5F0] shadow-sm mb-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start sm:items-center gap-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative shrink-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: worker.photoUrl,
										alt: worker.name,
										className: "size-24 rounded-2xl object-cover border-4 border-[#063B78] shadow-md"
									}), worker.verified && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { className: "size-7 text-[#FFC400] fill-[#063B78] absolute -bottom-2 -right-2" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 flex-wrap",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
											className: "text-2xl sm:text-3xl font-black text-[#10233F]",
											children: worker.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
											className: "bg-[#FFC400] text-[#082F63] font-black text-xs px-2.5 py-0.5",
											children: [
												"★ ",
												n(worker.rating),
												" (",
												n(worker.reviewsCount),
												" Reviews)"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-base font-extrabold text-[#063B78] mt-1",
										children: displayProfession
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 flex flex-wrap gap-4 text-xs font-semibold text-[#5B6B7F]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4 text-[#125BB5]" }),
												" ",
												worker.location
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-4 text-[#063B78]" }),
												" ",
												t("ageLabel"),
												": ",
												n(worker.age),
												" ",
												t("yearsOld")
											]
										})]
									})
								] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex sm:flex-col gap-3 w-full sm:w-auto shrink-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: () => setShowContactModal(true),
									className: "btn-yellow flex-1 sm:flex-none font-black text-xs px-6 py-3 h-11",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneCall, { className: "size-4 mr-1.5" }),
										" ",
										t("hireWorker")
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: handleShare,
									className: "flex-1 sm:flex-none border-[#063B78] text-[#063B78] font-bold text-xs px-4 h-11",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-4 mr-1.5" }), " Share"]
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 grid grid-cols-2 sm:grid-cols-4 gap-4 bg-[#F5F8FC] p-4 rounded-xl border border-[#DCE5F0]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-bold uppercase text-[#5B6B7F] block",
									children: t("experience")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-black text-[#10233F]",
									children: n(worker.experience)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-bold uppercase text-[#5B6B7F] block",
									children: t("expectedSalary")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-black text-[#063B78]",
									children: n(worker.expectedSalary)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-bold uppercase text-[#5B6B7F] block",
									children: t("availabilityLabel")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-black text-[#125BB5]",
									children: worker.availability
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-bold uppercase text-[#5B6B7F] block",
									children: "Languages"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-bold text-[#10233F]",
									children: worker.languages.join(", ")
								})] })
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid md:grid-cols-3 gap-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "md:col-span-2 space-y-8",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 sm:p-8 rounded-2xl border border-[#DCE5F0] shadow-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
										className: "text-lg font-black text-[#10233F] mb-3 flex items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-5 text-[#063B78]" }),
											" ",
											t("aboutAndExp")
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold text-[#5B6B7F] leading-relaxed",
										children: worker.about
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-6 pt-6 border-t border-[#DCE5F0]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "text-xs font-extrabold text-[#10233F] uppercase tracking-wider mb-3",
											children: t("skillsAndExpertise")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex flex-wrap gap-2",
											children: worker.skills.map((skill, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
												className: "bg-[#EBF1F8] text-[#063B78] font-bold text-xs px-3 py-1 border-0",
												children: ["✓ ", skill]
											}, i))
										})]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 sm:p-8 rounded-2xl border border-[#DCE5F0] shadow-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-lg font-black text-[#10233F] mb-4 flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { className: "size-5 text-[#FFC400]" }),
										" ",
										t("verifiedStatus")
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start gap-3 p-3.5 bg-[#F5F8FC] rounded-xl border border-[#DCE5F0]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5 text-[#063B78] shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-extrabold text-[#10233F] block",
											children: t("aadhaarVerifiedPhone")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[11px] font-semibold text-[#5B6B7F]",
											children: worker.phone.replace(/(\d{3})\d{4}(\d{2})/, "$1****$2")
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start gap-3 p-3.5 bg-[#F5F8FC] rounded-xl border border-[#DCE5F0]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5 text-[#063B78] shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-extrabold text-[#10233F] block",
											children: t("tradeCertVerified")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[11px] font-semibold text-[#5B6B7F]",
											children: "Verified by REAL JOB Field Inspection Team"
										})] })]
									})]
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 rounded-2xl border border-[#DCE5F0] shadow-xs sticky top-24",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-base font-black text-[#10233F] mb-3",
										children: t("directHire")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold text-[#5B6B7F] mb-4",
										children: t("directHireDesc")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										onClick: () => setShowContactModal(true),
										className: "w-full btn-yellow font-black text-xs py-3 h-11 mb-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneCall, { className: "size-4 mr-1.5" }),
											" ",
											t("callWorker")
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] font-bold text-[#5B6B7F] text-center",
										children: t("freeDirectContact")
									})
								]
							})
						})]
					})
				]
			}), showContactModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-[#082F63]/60 backdrop-blur-sm flex items-center justify-center p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white w-full max-w-md rounded-2xl p-6 shadow-2xl relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setShowContactModal(false),
						className: "absolute right-4 top-4 text-[#5B6B7F] hover:text-[#10233F]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					}), requestSubmitted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center py-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-16 text-[#063B78] mx-auto mb-3 animate-bounce" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xl font-black text-[#10233F]",
								children: t("contactSent")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold text-[#5B6B7F] mt-2",
								children: t("contactSentDesc")
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleHireSubmit,
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg font-black text-[#10233F]",
								children: t("contactWorkerTitle")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold text-[#5B6B7F]",
								children: t("enterDetails")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: t("yourName")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								required: true,
								placeholder: "Rajesh Patil",
								value: employerName,
								onChange: (e) => setEmployerName(e.target.value),
								className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: t("phoneNumber")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "tel",
								required: true,
								placeholder: "+91 98220 00000",
								value: employerPhone,
								onChange: (e) => setEmployerPhone(e.target.value),
								className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: t("jobDescription")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								rows: 3,
								placeholder: t("jobDetailsPlaceholder"),
								value: jobDescription,
								onChange: (e) => setJobDescription(e.target.value),
								className: "w-full rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] p-3 text-xs font-bold text-[#10233F]"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								className: "w-full btn-yellow font-black text-xs py-3 h-11",
								children: t("sendRequest")
							})
						]
					})]
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
	] });
}
var $$splitComponentImporter$11 = () => import("./control.employers-URIQ9xHP.mjs");
var Route$11 = createFileRoute("/_authenticated/control/employers")({
	head: () => ({ meta: [
		{ title: "Employers — Karyam Control" },
		{
			name: "description",
			content: "Platform-wide Employers administration on Karyam."
		},
		{
			property: "og:title",
			content: "Employers — Karyam Control"
		},
		{
			property: "og:description",
			content: "Secure platform administration."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./control.jobs-4uXBslMj.mjs");
var Route$10 = createFileRoute("/_authenticated/control/jobs")({
	head: () => ({ meta: [
		{ title: "Jobs — Karyam Control" },
		{
			name: "description",
			content: "Platform-wide Jobs administration on Karyam."
		},
		{
			property: "og:title",
			content: "Jobs — Karyam Control"
		},
		{
			property: "og:description",
			content: "Secure platform administration."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./control.languages-qVq4zQ5u.mjs");
var Route$9 = createFileRoute("/_authenticated/control/languages")({
	head: () => ({ meta: [
		{ title: "Languages — Karyam Control" },
		{
			name: "description",
			content: "Platform-wide Languages administration on Karyam."
		},
		{
			property: "og:title",
			content: "Languages — Karyam Control"
		},
		{
			property: "og:description",
			content: "Secure platform administration."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./control.reports-DKBOm2HQ.mjs");
var Route$8 = createFileRoute("/_authenticated/control/reports")({
	head: () => ({ meta: [
		{ title: "Reports — Karyam Control" },
		{
			name: "description",
			content: "Platform-wide Reports administration on Karyam."
		},
		{
			property: "og:title",
			content: "Reports — Karyam Control"
		},
		{
			property: "og:description",
			content: "Secure platform administration."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./control.salary-CMbPXWTa.mjs");
var Route$7 = createFileRoute("/_authenticated/control/salary")({
	head: () => ({ meta: [
		{ title: "E-Salary — Karyam Control" },
		{
			name: "description",
			content: "Platform-wide E-Salary administration on Karyam."
		},
		{
			property: "og:title",
			content: "E-Salary — Karyam Control"
		},
		{
			property: "og:description",
			content: "Secure platform administration."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./control.settings-CsVsPzB6.mjs");
var Route$6 = createFileRoute("/_authenticated/control/settings")({
	head: () => ({ meta: [
		{ title: "Settings — Karyam Control" },
		{
			name: "description",
			content: "Platform-wide Settings administration on Karyam."
		},
		{
			property: "og:title",
			content: "Settings — Karyam Control"
		},
		{
			property: "og:description",
			content: "Secure platform administration."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./control.users-CvYeoSg2.mjs");
var Route$5 = createFileRoute("/_authenticated/control/users")({
	head: () => ({ meta: [
		{ title: "Users — Karyam Control" },
		{
			name: "description",
			content: "Platform-wide Users administration on Karyam."
		},
		{
			property: "og:title",
			content: "Users — Karyam Control"
		},
		{
			property: "og:description",
			content: "Secure platform administration."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./employer.applicants-DuncK5i1.mjs");
var Route$4 = createFileRoute("/_authenticated/employer/applicants")({
	head: () => ({ meta: [
		{ title: "Applicants — Karyam Employer" },
		{
			name: "description",
			content: "Employer Applicants management on Karyam."
		},
		{
			property: "og:title",
			content: "Applicants — Karyam Employer"
		},
		{
			property: "og:description",
			content: "Professional employer management."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./employer.employees-DlVMkJCt.mjs");
var Route$3 = createFileRoute("/_authenticated/employer/employees")({
	head: () => ({ meta: [
		{ title: "Employees — Karyam Employer" },
		{
			name: "description",
			content: "Employer Employees management on Karyam."
		},
		{
			property: "og:title",
			content: "Employees — Karyam Employer"
		},
		{
			property: "og:description",
			content: "Professional employer management."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./employer.jobs-Da-cKDuc.mjs");
var Route$2 = createFileRoute("/_authenticated/employer/jobs")({
	head: () => ({ meta: [
		{ title: "Manage Jobs — Karyam Employer" },
		{
			name: "description",
			content: "Employer Manage Jobs management on Karyam."
		},
		{
			property: "og:title",
			content: "Manage Jobs — Karyam Employer"
		},
		{
			property: "og:description",
			content: "Professional employer management."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./employer.reports-Cs6OIp1r.mjs");
var Route$1 = createFileRoute("/_authenticated/employer/reports")({
	head: () => ({ meta: [
		{ title: "Reports — Karyam Employer" },
		{
			name: "description",
			content: "Employer Reports management on Karyam."
		},
		{
			property: "og:title",
			content: "Reports — Karyam Employer"
		},
		{
			property: "og:description",
			content: "Professional employer management."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./employer.salary-OF3V-DFj.mjs");
var Route = createFileRoute("/_authenticated/employer/salary")({
	head: () => ({ meta: [
		{ title: "Payroll & E-Salary — Karyam" },
		{
			name: "description",
			content: "Generate salaries, bonuses, deductions and payslips."
		},
		{
			property: "og:title",
			content: "Payroll & E-Salary — Karyam"
		},
		{
			property: "og:description",
			content: "Secure employer payroll management."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$34.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$35
});
var AuthenticatedRouteRoute = Route$33.update({
	id: "/_authenticated",
	getParentRoute: () => Route$35
});
var AboutRoute = Route$32.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$35
});
var AdminRoute = Route$31.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => Route$35
});
var AuthRoute = Route$36.update({
	id: "/auth",
	path: "/auth",
	getParentRoute: () => Route$35
});
var CategoriesRoute = Route$30.update({
	id: "/categories",
	path: "/categories",
	getParentRoute: () => Route$35
});
var ContactRoute = Route$29.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => Route$35
});
var FaqRoute = Route$28.update({
	id: "/faq",
	path: "/faq",
	getParentRoute: () => Route$35
});
var HomeRoute = Route$27.update({
	id: "/home",
	path: "/home",
	getParentRoute: () => Route$35
});
var ResetPasswordRoute = Route$26.update({
	id: "/reset-password",
	path: "/reset-password",
	getParentRoute: () => Route$35
});
var SelectLanguageRoute = Route$37.update({
	id: "/select-language",
	path: "/select-language",
	getParentRoute: () => Route$35
});
var AuthenticatedApplicationsRoute = Route$25.update({
	id: "/applications",
	path: "/applications",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedControlRoute = Route$24.update({
	id: "/control",
	path: "/control",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedDashboardRoute = Route$23.update({
	id: "/dashboard",
	path: "/dashboard",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedEmployerRoute = Route$22.update({
	id: "/employer",
	path: "/employer",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedMessagesRoute = Route$21.update({
	id: "/messages",
	path: "/messages",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedNotificationsRoute = Route$20.update({
	id: "/notifications",
	path: "/notifications",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedPostJobRoute = Route$19.update({
	id: "/post-job",
	path: "/post-job",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedProfileRoute = Route$18.update({
	id: "/profile",
	path: "/profile",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedSalaryRoute = Route$17.update({
	id: "/salary",
	path: "/salary",
	getParentRoute: () => AuthenticatedRouteRoute
});
var CompanyCompanyIdRoute = Route$16.update({
	id: "/company/$companyId",
	path: "/company/$companyId",
	getParentRoute: () => Route$35
});
var JobsIndexRoute = Route$15.update({
	id: "/jobs/",
	path: "/jobs/",
	getParentRoute: () => Route$35
});
var JobsJobIdRoute = Route$14.update({
	id: "/jobs/$jobId",
	path: "/jobs/$jobId",
	getParentRoute: () => Route$35
});
var WorkersIndexRoute = Route$13.update({
	id: "/workers/",
	path: "/workers/",
	getParentRoute: () => Route$35
});
var WorkersWorkerIdRoute = Route$12.update({
	id: "/workers/$workerId",
	path: "/workers/$workerId",
	getParentRoute: () => Route$35
});
var AuthenticatedControlEmployersRoute = Route$11.update({
	id: "/employers",
	path: "/employers",
	getParentRoute: () => AuthenticatedControlRoute
});
var AuthenticatedControlJobsRoute = Route$10.update({
	id: "/jobs",
	path: "/jobs",
	getParentRoute: () => AuthenticatedControlRoute
});
var AuthenticatedControlLanguagesRoute = Route$9.update({
	id: "/languages",
	path: "/languages",
	getParentRoute: () => AuthenticatedControlRoute
});
var AuthenticatedControlReportsRoute = Route$8.update({
	id: "/reports",
	path: "/reports",
	getParentRoute: () => AuthenticatedControlRoute
});
var AuthenticatedControlSalaryRoute = Route$7.update({
	id: "/salary",
	path: "/salary",
	getParentRoute: () => AuthenticatedControlRoute
});
var AuthenticatedControlSettingsRoute = Route$6.update({
	id: "/settings",
	path: "/settings",
	getParentRoute: () => AuthenticatedControlRoute
});
var AuthenticatedControlUsersRoute = Route$5.update({
	id: "/users",
	path: "/users",
	getParentRoute: () => AuthenticatedControlRoute
});
var AuthenticatedEmployerApplicantsRoute = Route$4.update({
	id: "/applicants",
	path: "/applicants",
	getParentRoute: () => AuthenticatedEmployerRoute
});
var AuthenticatedEmployerEmployeesRoute = Route$3.update({
	id: "/employees",
	path: "/employees",
	getParentRoute: () => AuthenticatedEmployerRoute
});
var AuthenticatedEmployerJobsRoute = Route$2.update({
	id: "/jobs",
	path: "/jobs",
	getParentRoute: () => AuthenticatedEmployerRoute
});
var AuthenticatedEmployerReportsRoute = Route$1.update({
	id: "/reports",
	path: "/reports",
	getParentRoute: () => AuthenticatedEmployerRoute
});
var AuthenticatedEmployerSalaryRoute = Route.update({
	id: "/salary",
	path: "/salary",
	getParentRoute: () => AuthenticatedEmployerRoute
});
var AuthenticatedControlRouteChildren = {
	AuthenticatedControlEmployersRoute,
	AuthenticatedControlJobsRoute,
	AuthenticatedControlLanguagesRoute,
	AuthenticatedControlReportsRoute,
	AuthenticatedControlSalaryRoute,
	AuthenticatedControlSettingsRoute,
	AuthenticatedControlUsersRoute
};
var AuthenticatedControlRouteWithChildren = AuthenticatedControlRoute._addFileChildren(AuthenticatedControlRouteChildren);
var AuthenticatedEmployerRouteChildren = {
	AuthenticatedEmployerApplicantsRoute,
	AuthenticatedEmployerEmployeesRoute,
	AuthenticatedEmployerJobsRoute,
	AuthenticatedEmployerReportsRoute,
	AuthenticatedEmployerSalaryRoute
};
var AuthenticatedRouteRouteChildren = {
	AuthenticatedApplicationsRoute,
	AuthenticatedControlRoute: AuthenticatedControlRouteWithChildren,
	AuthenticatedDashboardRoute,
	AuthenticatedEmployerRoute: AuthenticatedEmployerRoute._addFileChildren(AuthenticatedEmployerRouteChildren),
	AuthenticatedMessagesRoute,
	AuthenticatedNotificationsRoute,
	AuthenticatedPostJobRoute,
	AuthenticatedProfileRoute,
	AuthenticatedSalaryRoute
};
var rootRouteChildren = {
	IndexRoute,
	AuthenticatedRouteRoute: AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren),
	AboutRoute,
	AdminRoute,
	AuthRoute,
	CategoriesRoute,
	ContactRoute,
	FaqRoute,
	HomeRoute,
	ResetPasswordRoute,
	SelectLanguageRoute,
	CompanyCompanyIdRoute,
	JobsJobIdRoute,
	WorkersWorkerIdRoute,
	JobsIndexRoute,
	WorkersIndexRoute
};
var routeTree = Route$35._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
