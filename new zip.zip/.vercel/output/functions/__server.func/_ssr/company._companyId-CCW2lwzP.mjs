import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n } from "./i18n-CEAlH7ip.mjs";
import { t as Button } from "./button--9UiOy7A.mjs";
import { g as Link, v as useParams } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { Bt as Building2, D as Share2, Jt as Award, Mt as CircleCheck, T as ShieldCheck, Vt as Briefcase, W as MapPin, Zt as ArrowLeft, mt as Gift, s as Users, v as Star, xt as ExternalLink, zt as Building } from "../_libs/lucide-react.mjs";
import { t as PublicHeader } from "./PublicHeader-D1uPireo.mjs";
import { t as PublicFooter } from "./PublicFooter-zsmeitx6.mjs";
import { a as jobs, n as JobCard, r as getCompanyMetadata } from "./JobCard-B_QpStMo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/company._companyId-CCW2lwzP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CompanyPage() {
	const { t, n, lang } = useI18n();
	const { companyId } = useParams({ from: "/company/$companyId" });
	const matchingJob = jobs.find((j) => {
		const slug = j.company.toLowerCase().replace(/[^a-z0-9]+/g, "-");
		return slug === companyId || companyId.includes(slug) || slug.includes(companyId);
	}) ?? jobs[0] ?? {
		id: "c-1",
		title: "Civil Engineer - Site Operations",
		company: "L&T Construction",
		location: "Mumbai, Maharashtra",
		salary: "₹35,000–50,000/mo",
		experience: "2–5 years",
		type: "Full-time",
		workMode: "On-site",
		posted: "1h ago",
		initials: "LT",
		category: "Construction"
	};
	const companyMeta = getCompanyMetadata(matchingJob);
	const companyJobs = jobs.filter((j) => j.company === matchingJob.company);
	const [activeTab, setActiveTab] = (0, import_react.useState)("overview");
	const [following, setFollowing] = (0, import_react.useState)(false);
	const handleShare = () => {
		if (typeof navigator !== "undefined" && navigator.clipboard) {
			navigator.clipboard.writeText(window.location.href);
			toast.success(lang === "mr" ? "कंपनी प्रोफाइल लिंक कॉपी झाली!" : "Company page link copied!");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "bg-[#F5F8FC] min-h-screen py-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4 mb-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => window.history.back(),
							className: "px-3.5 py-2 text-[#5B6B7F] hover:text-[#10233F] hover:bg-white rounded-xl flex items-center gap-1.5 text-xs font-black transition-all shadow-2xs border border-[#DCE5F0] bg-white",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }),
								" ",
								lang === "mr" ? "मागे जा" : "Back"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-xs font-bold text-[#5B6B7F]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/",
									className: "hover:text-[#063B78]",
									children: t("home")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "/" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/jobs",
									className: "hover:text-[#063B78]",
									children: t("jobs")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "/" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[#10233F]",
									children: companyMeta.name
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white rounded-3xl border border-[#DCE5F0] shadow-md overflow-hidden mb-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "h-44 sm:h-52 bg-gradient-to-r from-[#063B78] via-[#082F63] to-[#125BB5] p-6 text-white relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute right-6 top-6 flex items-center gap-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: handleShare,
									className: "bg-white/10 hover:bg-white/20 border-white/20 text-white font-bold text-xs h-9 px-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-4 mr-1.5" }),
										" ",
										lang === "mr" ? "शेअर करा" : "Share"
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute bottom-4 left-6 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-black uppercase tracking-wider bg-[#FFC400] text-[#082F63] px-3 py-1 rounded-full shadow-sm",
									children: companyMeta.industry
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-black text-emerald-300 flex items-center gap-1 bg-white/10 backdrop-blur px-3 py-1 rounded-full",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-emerald-400" }), " REAL JOB Verified Corporate Hub"]
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-6 sm:p-8 pt-0 relative",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col sm:flex-row items-start sm:items-end justify-between gap-6 -mt-12 sm:-mt-16 mb-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-end gap-5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "grid size-24 sm:size-28 shrink-0 place-items-center rounded-3xl bg-white font-black text-[#063B78] text-4xl shadow-xl border-4 border-white ring-2 ring-[#063B78]/20",
											children: matchingJob.initials
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
											className: "text-2xl sm:text-3xl font-black text-[#10233F]",
											children: companyMeta.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 text-xs font-bold text-[#5B6B7F] mt-1.5 flex-wrap",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-1",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4 text-[#063B78]" }),
														" ",
														companyMeta.headquarters
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-1 text-[#082F63] bg-[#FFC400]/20 px-2.5 py-0.5 rounded-full border border-[#FFC400]/30 font-black",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-3.5 fill-[#FFC400] text-[#082F63]" }),
														" ",
														companyMeta.rating,
														" / 5.0 (",
														companyMeta.reviewsCount,
														")"
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Est. ", companyMeta.founded] })
											]
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3 w-full sm:w-auto",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											onClick: () => {
												setFollowing(!following);
												toast.success(following ? `Unfollowed ${matchingJob.company}` : `Now following ${matchingJob.company}`);
											},
											className: `h-11 px-6 font-black text-xs rounded-2xl shadow-sm ${following ? "bg-[#EBF1F8] text-[#063B78] hover:bg-[#DCE5F0]" : "bg-[#063B78] text-white hover:bg-[#082F63]"}`,
											children: following ? "✓ Following Company" : "+ Follow Company"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: companyMeta.website,
											target: "_blank",
											rel: "noreferrer",
											className: "h-11 px-5 rounded-2xl border border-[#DCE5F0] bg-white text-[#063B78] font-black text-xs inline-flex items-center justify-center hover:bg-[#F5F8FC] shadow-2xs gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Website" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" })]
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-2xl bg-[#F5F8FC] border border-[#DCE5F0]/70",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "grid size-10 place-items-center rounded-xl bg-[#063B78]/10 text-[#063B78]",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
												children: "कर्मचारी संख्या"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs sm:text-sm font-black text-[#10233F]",
												children: companyMeta.size
											})] })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 border-l sm:border-l border-[#DCE5F0] pl-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "grid size-10 place-items-center rounded-xl bg-[#FFC400]/20 text-[#082F63]",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-5" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
												children: "उपलब्ध नोकऱ्या"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-xs sm:text-sm font-black text-[#063B78]",
												children: [companyJobs.length, " Live Openings"]
											})] })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 border-l border-[#DCE5F0] pl-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "grid size-10 place-items-center rounded-xl bg-emerald-100 text-emerald-800",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-5" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
												children: "कंपनी स्टेटस"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs sm:text-sm font-black text-emerald-700",
												children: "Govt & GST Verified"
											})] })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 border-l border-[#DCE5F0] pl-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "grid size-10 place-items-center rounded-xl bg-[#063B78]/10 text-[#063B78]",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building, { className: "size-5" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
												children: "मुख्यालय"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs sm:text-sm font-black text-[#10233F] truncate",
												children: companyMeta.headquarters
											})] })]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 mt-6 border-b border-[#DCE5F0]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => setActiveTab("overview"),
											className: `pb-3 px-4 text-xs sm:text-sm font-black transition-all border-b-2 ${activeTab === "overview" ? "border-[#063B78] text-[#063B78]" : "border-transparent text-[#5B6B7F] hover:text-[#10233F]"}`,
											children: ["🏢 ", lang === "mr" ? "कंपनी परिचय व माहिती" : "Company Overview"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => setActiveTab("jobs"),
											className: `pb-3 px-4 text-xs sm:text-sm font-black transition-all border-b-2 ${activeTab === "jobs" ? "border-[#063B78] text-[#063B78]" : "border-transparent text-[#5B6B7F] hover:text-[#10233F]"}`,
											children: [
												"💼 ",
												lang === "mr" ? "सर्व नोकऱ्या" : "Active Openings",
												" (",
												companyJobs.length,
												")"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => setActiveTab("culture"),
											className: `pb-3 px-4 text-xs sm:text-sm font-black transition-all border-b-2 ${activeTab === "culture" ? "border-[#063B78] text-[#063B78]" : "border-transparent text-[#5B6B7F] hover:text-[#10233F]"}`,
											children: ["🌟 ", lang === "mr" ? "सुविधा आणि संस्कृती" : "Culture & Benefits"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => setActiveTab("locations"),
											className: `pb-3 px-4 text-xs sm:text-sm font-black transition-all border-b-2 ${activeTab === "locations" ? "border-[#063B78] text-[#063B78]" : "border-transparent text-[#5B6B7F] hover:text-[#10233F]"}`,
											children: ["📍 ", lang === "mr" ? "कार्यालये" : "Office Locations"]
										})
									]
								})
							]
						})]
					}),
					activeTab === "overview" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid lg:grid-cols-3 gap-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-2 space-y-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 sm:p-8 rounded-3xl border border-[#DCE5F0] shadow-xs space-y-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
										className: "text-lg font-black text-[#10233F] flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-5 text-[#063B78]" }), lang === "mr" ? "कंपनीबद्दल सविस्तर माहिती (About Corporate)" : "About Company"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold text-[#5B6B7F] leading-relaxed bg-[#F5F8FC] p-5 rounded-2xl border border-[#DCE5F0]/70",
										children: lang === "mr" ? companyMeta.aboutMr : companyMeta.aboutEn
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "pt-4 border-t border-[#DCE5F0]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "text-xs font-black uppercase text-[#5B6B7F] tracking-wider mb-3",
											children: lang === "mr" ? "कंपनीची अधिकृत प्रमाणपत्रे व बॅजेस" : "Verification Badges"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex flex-wrap items-center gap-2.5",
											children: companyMeta.trustBadges.map((badge, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center gap-2 rounded-2xl bg-emerald-50 border border-emerald-200 px-4 py-2 text-xs font-black text-emerald-800 shadow-2xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-emerald-600" }), badge]
											}, idx))
										})]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 sm:p-8 rounded-3xl border border-[#DCE5F0] shadow-xs space-y-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-lg font-black text-[#10233F] flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "size-5 text-[#FFC400]" }), lang === "mr" ? "कामगारांना मिळणाऱ्या सुविधा (Perks & Benefits)" : "Employee Benefits"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid sm:grid-cols-2 gap-3",
									children: (lang === "mr" ? companyMeta.perksMr : companyMeta.perksEn).map((perk, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3 p-3.5 rounded-2xl bg-[#EBF1F8] border border-[#063B78]/10 text-xs font-bold text-[#063B78]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "size-5 text-[#063B78] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: perk })]
									}, idx))
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "bg-[#082F63] text-white p-6 rounded-3xl shadow-lg relative overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative z-10 space-y-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-black uppercase tracking-wider bg-[#FFC400] text-[#082F63] px-2.5 py-1 rounded-full",
											children: "Direct Hiring Partner"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
											className: "text-xl font-black text-white",
											children: [
												companyMeta.name,
												" ",
												lang === "mr" ? "मध्ये काम करायचे आहे?" : "Want to work here?"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-slate-200 leading-relaxed font-semibold",
											children: lang === "mr" ? "कंपनीच्या थेट HR विभागाशी संपर्क साधा आणि सत्यापित नोकऱ्यांसाठी आजच अर्ज करा." : "Connect directly with HR and apply for verified job openings today."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											onClick: () => setActiveTab("jobs"),
											className: "w-full btn-yellow h-11 font-black text-xs rounded-2xl shadow-md",
											children: lang === "mr" ? "सर्व नोकऱ्या पाहा आणि अर्ज करा" : "Browse & Apply for Jobs"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 rounded-3xl border border-[#DCE5F0] shadow-xs space-y-3 text-xs font-semibold text-[#5B6B7F]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
										className: "font-black text-[#10233F] text-sm flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-emerald-600" }), lang === "mr" ? "कायदेशीर माहिती व सुरक्षा" : "Compliance & Safety"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "✓ 100% Verified GSTIN & Corporate Affairs Record." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "✓ Zero-fee application for all candidates." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "✓ Direct interview call from HR within 48 hours." })
								]
							})]
						})]
					}),
					activeTab === "jobs" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "text-xl font-black text-[#10233F]",
								children: [
									companyMeta.name,
									" — ",
									lang === "mr" ? "उपलब्ध नोकऱ्यांची यादी" : "Current Openings"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs font-extrabold text-[#063B78] bg-[#063B78]/10 px-3 py-1 rounded-full",
								children: [
									companyJobs.length,
									" ",
									lang === "mr" ? "नोकऱ्या उपलब्ध" : "Jobs Available"
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
							children: companyJobs.map((job) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JobCard, { job }, job.id))
						})]
					}),
					activeTab === "culture" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white p-6 sm:p-8 rounded-3xl border border-[#DCE5F0] shadow-xs space-y-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "text-xl font-black text-[#10233F]",
							children: [
								companyMeta.name,
								" ",
								lang === "mr" ? "कामगार पुनरावलोकने व कार्यसंस्कृती" : "Work Culture & Employee Ratings"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid sm:grid-cols-2 md:grid-cols-4 gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-[#F5F8FC] border border-[#DCE5F0] text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-3xl font-black text-[#063B78]",
										children: "4.6 ★"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-bold text-[#5B6B7F] block mt-1",
										children: "Work-Life Balance"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-[#F5F8FC] border border-[#DCE5F0] text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-3xl font-black text-[#063B78]",
										children: "4.8 ★"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-bold text-[#5B6B7F] block mt-1",
										children: "Salary & Benefits"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-[#F5F8FC] border border-[#DCE5F0] text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-3xl font-black text-[#063B78]",
										children: "4.7 ★"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-bold text-[#5B6B7F] block mt-1",
										children: "Job Security"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl bg-[#F5F8FC] border border-[#DCE5F0] text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-3xl font-black text-[#063B78]",
										children: "4.5 ★"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-bold text-[#5B6B7F] block mt-1",
										children: "Skill Growth"
									})]
								})
							]
						})]
					}),
					activeTab === "locations" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white p-6 sm:p-8 rounded-3xl border border-[#DCE5F0] shadow-xs space-y-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "text-xl font-black text-[#10233F]",
							children: [
								companyMeta.name,
								" ",
								lang === "mr" ? "मुख्य आणि प्रादेशिक कार्यालये" : "Offices & Site Branches"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid sm:grid-cols-2 gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-2xl bg-[#F5F8FC] border border-[#DCE5F0]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
									className: "font-black text-sm text-[#063B78] flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" }), " Head Office (मुख्यालय)"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold text-[#5B6B7F] mt-1",
									children: companyMeta.headquarters
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-2xl bg-[#F5F8FC] border border-[#DCE5F0]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
									className: "font-black text-sm text-[#063B78] flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" }), " Maharashtra Regional Hub"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold text-[#5B6B7F] mt-1",
									children: "MIDC Industrial Complex, Pune & Navi Mumbai"
								})]
							})]
						})]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
	] });
}
//#endregion
export { CompanyPage as component };
