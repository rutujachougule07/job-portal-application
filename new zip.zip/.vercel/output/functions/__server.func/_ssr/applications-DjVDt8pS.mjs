import { t as ApplicationsPage } from "./Dashboards-CYTAs71H.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/applications-DjVDt8pS.js
var SplitComponent = ApplicationsPage;
//#endregion
export { SplitComponent as component };
