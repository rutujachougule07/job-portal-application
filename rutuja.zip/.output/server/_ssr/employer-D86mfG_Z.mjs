import { n as EmployerDashboard } from "./Dashboards-DS6IH2fS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/employer-D86mfG_Z.js
var SplitComponent = EmployerDashboard;
//#endregion
export { SplitComponent as component };
