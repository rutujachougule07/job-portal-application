//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-YcPJeyUk.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/job-portal-application-main/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/about",
			"/admin",
			"/auth",
			"/categories",
			"/contact",
			"/faq",
			"/home",
			"/reset-password",
			"/select-language",
			"/company/$companyId",
			"/jobs/$jobId",
			"/workers/$workerId",
			"/jobs/",
			"/workers/"
		],
		preloads: [
			"/assets/index-BTDZWWHo.js",
			"/assets/useStore-BSq4-GUT.js",
			"/assets/button-ChBG2UF1.js",
			"/assets/Match-CVRpd2l3.js",
			"/assets/redirect-1Dss4sOM.js",
			"/assets/matchContext-CwTwuMgb.js",
			"/assets/createLucideIcon-CbXIaOsE.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BTDZWWHo.js"
		} }]
	},
	"/_authenticated": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/applications",
			"/_authenticated/control",
			"/_authenticated/dashboard",
			"/_authenticated/employer",
			"/_authenticated/messages",
			"/_authenticated/notifications",
			"/_authenticated/post-job",
			"/_authenticated/profile",
			"/_authenticated/salary"
		],
		preloads: ["/assets/route-BcD8ecfk.js"]
	},
	"/about": {
		filePath: "C:/job-portal-application-main/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-BGSqbvds.js"]
	},
	"/auth": {
		filePath: "C:/job-portal-application-main/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-Dgb2iI-d.js",
			"/assets/eye-BoSgHQ9W.js",
			"/assets/phone-DbWY5LC3.js",
			"/assets/user-plus-B6ITgSTl.js",
			"/assets/label-CRb_nHOk.js"
		]
	},
	"/categories": {
		filePath: "C:/job-portal-application-main/src/routes/categories.tsx",
		children: void 0,
		preloads: ["/assets/categories--uIG9WyT.js", "/assets/user-plus-B6ITgSTl.js"]
	},
	"/contact": {
		filePath: "C:/job-portal-application-main/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-CTy-ushq.js", "/assets/phone-DbWY5LC3.js"]
	},
	"/reset-password": {
		filePath: "C:/job-portal-application-main/src/routes/reset-password.tsx",
		children: void 0,
		preloads: ["/assets/reset-password-CV924Df_.js", "/assets/label-CRb_nHOk.js"]
	},
	"/select-language": {
		filePath: "C:/job-portal-application-main/src/routes/select-language.tsx",
		children: void 0,
		preloads: ["/assets/select-language-Cx47M2US.js"]
	},
	"/_authenticated/applications": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/applications.tsx",
		children: void 0,
		preloads: ["/assets/applications-CRUHJzqP.js", "/assets/Dashboards-Dw14TnK8.js"]
	},
	"/_authenticated/control": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.tsx",
		children: [
			"/_authenticated/control/employers",
			"/_authenticated/control/jobs",
			"/_authenticated/control/languages",
			"/_authenticated/control/reports",
			"/_authenticated/control/salary",
			"/_authenticated/control/settings",
			"/_authenticated/control/users"
		],
		preloads: ["/assets/control-o83KZ5F_.js", "/assets/Dashboards-Dw14TnK8.js"]
	},
	"/_authenticated/dashboard": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/dashboard.tsx",
		children: void 0,
		preloads: ["/assets/dashboard-ePDZhWwG.js", "/assets/Dashboards-Dw14TnK8.js"]
	},
	"/_authenticated/employer": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.tsx",
		children: [
			"/_authenticated/employer/applicants",
			"/_authenticated/employer/employees",
			"/_authenticated/employer/jobs",
			"/_authenticated/employer/reports",
			"/_authenticated/employer/salary"
		],
		preloads: ["/assets/employer-BvY2n3-S.js", "/assets/Dashboards-Dw14TnK8.js"]
	},
	"/_authenticated/messages": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/messages.tsx",
		children: void 0,
		preloads: ["/assets/messages-BikKGSVh.js", "/assets/phone-DbWY5LC3.js"]
	},
	"/_authenticated/notifications": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/notifications.tsx",
		children: void 0,
		preloads: ["/assets/notifications-CY2ygTiN.js", "/assets/Dashboards-Dw14TnK8.js"]
	},
	"/_authenticated/post-job": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/post-job.tsx",
		children: void 0,
		preloads: ["/assets/post-job-UO49aIw5.js", "/assets/eye-BoSgHQ9W.js"]
	},
	"/_authenticated/profile": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/profile.tsx",
		children: void 0,
		preloads: ["/assets/profile-B7W-LykZ.js", "/assets/Dashboards-Dw14TnK8.js"]
	},
	"/_authenticated/salary": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/salary.tsx",
		children: void 0,
		preloads: ["/assets/salary-B6E0mpWm.js", "/assets/Dashboards-Dw14TnK8.js"]
	},
	"/_authenticated/control/employers": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.employers.tsx",
		children: void 0,
		preloads: ["/assets/control.employers-C2ONinmj.js"]
	},
	"/_authenticated/control/jobs": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.jobs.tsx",
		children: void 0,
		preloads: ["/assets/control.jobs-DwgritVh.js"]
	},
	"/_authenticated/control/languages": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.languages.tsx",
		children: void 0,
		preloads: ["/assets/control.languages-q9H2EbsA.js"]
	},
	"/_authenticated/control/reports": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.reports.tsx",
		children: void 0,
		preloads: ["/assets/control.reports-CXmRLfgb.js"]
	},
	"/_authenticated/control/salary": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.salary.tsx",
		children: void 0,
		preloads: ["/assets/control.salary-gTot5h2Z.js"]
	},
	"/_authenticated/control/settings": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.settings.tsx",
		children: void 0,
		preloads: ["/assets/control.settings-DfwJl9dL.js"]
	},
	"/_authenticated/control/users": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.users.tsx",
		children: void 0,
		preloads: ["/assets/control.users-BHQxsmR8.js"]
	},
	"/_authenticated/employer/applicants": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.applicants.tsx",
		children: void 0,
		preloads: ["/assets/employer.applicants-BQyWEjRO.js"]
	},
	"/_authenticated/employer/employees": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.employees.tsx",
		children: void 0,
		preloads: ["/assets/employer.employees-CZVKCP7W.js"]
	},
	"/_authenticated/employer/jobs": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.jobs.tsx",
		children: void 0,
		preloads: ["/assets/employer.jobs-DMLQmyRo.js"]
	},
	"/_authenticated/employer/reports": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.reports.tsx",
		children: void 0,
		preloads: ["/assets/employer.reports-D_Gv_jyw.js"]
	},
	"/_authenticated/employer/salary": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.salary.tsx",
		children: void 0,
		preloads: ["/assets/employer.salary-Dzs6trGH.js"]
	}
} });
//#endregion
export { tsrStartManifest };
