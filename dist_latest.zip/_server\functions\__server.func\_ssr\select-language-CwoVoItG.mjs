import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as stringType, t as objectType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/select-language-CwoVoItG.js
var $$splitComponentImporter = () => import("./select-language-DME3B1C9.mjs");
var Route = createFileRoute("/select-language")({
	validateSearch: objectType({ redirectTo: stringType().optional().catch("/") }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
