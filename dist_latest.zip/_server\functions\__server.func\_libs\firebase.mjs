import { r as __exportAll } from "../_runtime.mjs";
import { l as registerVersion } from "./@firebase/analytics+[...].mjs";
import { S as getFirestore, _ as Timestamp, a as deleteDoc, b as doc, c as getDocs, d as AutoId, f as DocumentReference, g as Query, h as FirestoreError, i as SnapshotMetadata, l as setDoc, m as Firestore, n as QueryDocumentSnapshot, o as executeWrite, p as FieldPath, r as QuerySnapshot, s as getDoc, t as DocumentSnapshot, u as updateDoc, v as cast, x as ensureFirestoreConfigured, y as collection } from "./@firebase/firestore+[...].mjs";
import { i as signInWithEmailAndPassword, n as getAuth, r as sendPasswordResetEmail, t as createUserWithEmailAndPassword } from "./firebase__auth.mjs";
import "./firebase__storage.mjs";
//#region node_modules/firebase/app/dist/index.mjs
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
registerVersion("firebase", "12.19.0", "app");
//#endregion
//#region node_modules/firebase/firestore/dist/index.mjs
var dist_exports$1 = /* @__PURE__ */ __exportAll({
	CACHE_SIZE_UNLIMITED: () => -1,
	DocumentReference: () => DocumentReference,
	DocumentSnapshot: () => DocumentSnapshot,
	FieldPath: () => FieldPath,
	Firestore: () => Firestore,
	FirestoreError: () => FirestoreError,
	Query: () => Query,
	QueryDocumentSnapshot: () => QueryDocumentSnapshot,
	QuerySnapshot: () => QuerySnapshot,
	SnapshotMetadata: () => SnapshotMetadata,
	Timestamp: () => Timestamp,
	_AutoId: () => AutoId,
	_cast: () => cast,
	collection: () => collection,
	deleteDoc: () => deleteDoc,
	doc: () => doc,
	ensureFirestoreConfigured: () => ensureFirestoreConfigured,
	executeWrite: () => executeWrite,
	getDoc: () => getDoc,
	getDocs: () => getDocs,
	getFirestore: () => getFirestore,
	setDoc: () => setDoc,
	updateDoc: () => updateDoc
});
//#endregion
//#region node_modules/firebase/auth/dist/index.mjs
var dist_exports = /* @__PURE__ */ __exportAll({
	createUserWithEmailAndPassword: () => createUserWithEmailAndPassword,
	getAuth: () => getAuth,
	sendPasswordResetEmail: () => sendPasswordResetEmail,
	signInWithEmailAndPassword: () => signInWithEmailAndPassword
});
//#endregion
export { dist_exports$1 as n, dist_exports as t };
