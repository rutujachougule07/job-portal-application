import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n } from "./i18n-BcT9wMyM.mjs";
import { t as Button } from "./button--9UiOy7A.mjs";
import { t as dataStore } from "./data-store-CvMaHmbm.mjs";
import { b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as LogoIcon } from "./Brand-CAHKvNmJ.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { $ as Lock, Dt as EyeOff, Et as Eye, I as RotateCcw, Kt as Check, Q as LogIn, V as Phone, X as Mail, Yt as Camera, c as User, d as UserPlus, dn as ArrowLeft, en as Building2, et as LoaderCircle, p as Upload, r as X } from "../_libs/lucide-react.mjs";
import { t as Label } from "./label-Ckx2BWD4.mjs";
import { t as Route } from "./auth-C1nSM6C6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-BovHYvxG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AuthPage() {
	const search = Route.useSearch();
	const navigate = useNavigate();
	const { lang } = useI18n();
	const [mode, setMode] = (0, import_react.useState)(search.mode || "login");
	const [role, setRole] = (0, import_react.useState)(search.role || "worker");
	const [showPassword, setShowPassword] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [rememberMe, setRememberMe] = (0, import_react.useState)(true);
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [profilePhoto, setProfilePhoto] = (0, import_react.useState)("");
	const [cameraOpen, setCameraOpen] = (0, import_react.useState)(false);
	const videoRef = (0, import_react.useRef)(null);
	const [mediaStream, setMediaStream] = (0, import_react.useState)(null);
	const [tempCaptured, setTempCaptured] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setEmail("");
		setPassword("");
		setProfilePhoto("");
	}, [mode, role]);
	(0, import_react.useEffect)(() => {
		if (cameraOpen && videoRef.current && mediaStream) videoRef.current.srcObject = mediaStream;
	}, [cameraOpen, mediaStream]);
	const startCamera = async () => {
		try {
			setTempCaptured(null);
			setCameraOpen(true);
			const stream = await navigator.mediaDevices.getUserMedia({
				video: {
					facingMode: "user",
					width: { ideal: 640 },
					height: { ideal: 640 }
				},
				audio: false
			});
			setMediaStream(stream);
		} catch (err) {
			toast.error(lang === "mr" ? "कॅमेरा उघडता आला नाही! कृपया कॅमेरा परवानगी तपासा." : "Could not open camera. Please check camera permissions.");
			setCameraOpen(false);
		}
	};
	const stopCamera = () => {
		if (mediaStream) {
			mediaStream.getTracks().forEach((track) => track.stop());
			setMediaStream(null);
		}
		setCameraOpen(false);
		setTempCaptured(null);
	};
	const capturePhoto = () => {
		if (videoRef.current) {
			const video = videoRef.current;
			const canvas = document.createElement("canvas");
			canvas.width = video.videoWidth || 640;
			canvas.height = video.videoHeight || 480;
			const ctx = canvas.getContext("2d");
			if (ctx) {
				ctx.translate(canvas.width, 0);
				ctx.scale(-1, 1);
				ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
				const dataUrl = canvas.toDataURL("image/jpeg", .9);
				setTempCaptured(dataUrl);
			}
		}
	};
	const confirmCapturedPhoto = () => {
		if (tempCaptured) {
			setProfilePhoto(tempCaptured);
			toast.success(lang === "mr" ? "फोटो कॅमेऱ्यातून यशस्वीरीत्या घेतला!" : "Photo captured successfully!");
		}
		stopCamera();
	};
	const [workerName, setWorkerName] = (0, import_react.useState)("");
	const [workerPhone, setWorkerPhone] = (0, import_react.useState)("");
	const [companyName, setCompanyName] = (0, import_react.useState)("");
	const [employerPhone, setEmployerPhone] = (0, import_react.useState)("");
	const handlePhotoUpload = (e) => {
		const file = e.target.files?.[0];
		if (file) {
			if (file.size > 5242880) {
				toast.error("Photo size should be less than 5MB");
				return;
			}
			const reader = new FileReader();
			reader.onloadend = () => {
				setProfilePhoto(reader.result);
			};
			reader.readAsDataURL(file);
		}
	};
	const handleSubmit = async (e) => {
		e.preventDefault();
		setBusy(true);
		try {
			if (mode === "forgot") {
				const { getAuth, sendPasswordResetEmail } = await import("../_libs/firebase.mjs").then((n) => n.t);
				await sendPasswordResetEmail(getAuth(), email);
				toast.success("Password reset email sent! Check your inbox.");
				setMode("login");
				setBusy(false);
				return;
			}
			if (mode === "register") {
				const rawName = role === "employer" || role === "admin" ? companyName : workerName;
				const userMobile = role === "employer" || role === "admin" ? employerPhone : workerPhone;
				let finalEmail = email.trim().toLowerCase();
				if (!finalEmail && userMobile) finalEmail = `${userMobile.replace(/\D/g, "")}@realjob.com`;
				const nameString = rawName && rawName.trim() ? rawName.trim() : finalEmail ? finalEmail.split("@")[0] || "User" : "User";
				const registeredAccount = dataStore.registerAccount({
					email: finalEmail,
					password,
					role: role === "admin" ? "employer" : role,
					fullName: nameString,
					mobile: userMobile || "",
					profilePhoto: profilePhoto || ""
				});
				const userObj = {
					id: registeredAccount.id,
					email: registeredAccount.email,
					role: registeredAccount.role,
					fullName: registeredAccount.fullName || "User",
					mobile: registeredAccount.mobile || userMobile || "",
					profilePhoto: registeredAccount.profilePhoto || profilePhoto || ""
				};
				window.localStorage.setItem("realjob-user", JSON.stringify(userObj));
				dataStore.setCurrentUser(userObj);
				toast.success("✅ खाते यशस्वीरित्या तयार झाले! Welcome to REAL JOB.");
				if (role === "admin" || role === "employer") navigate({ to: "/admin" });
				else navigate({ to: "/home" });
				setBusy(false);
				return;
			}
			const enteredEmail = email.trim().toLowerCase();
			if (enteredEmail === "supera@gmail.com" || enteredEmail === "superadmin") {
				const { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword } = await import("../_libs/firebase.mjs").then((n) => n.t);
				const auth = getAuth();
				let uid = "superadmin-uid";
				try {
					uid = (await signInWithEmailAndPassword(auth, "supera@gmail.com", password)).user.uid;
				} catch (signInErr) {
					const errCode = signInErr?.code || "";
					if ((errCode === "auth/user-not-found" || errCode === "auth/invalid-credential") && password === "supera123") try {
						uid = (await createUserWithEmailAndPassword(auth, "supera@gmail.com", password)).user.uid;
					} catch {}
					else if (password !== "supera123") {
						toast.error("❌ चुकीचा पासवर्ड! Super Admin password is 'supera123'.");
						setBusy(false);
						return;
					}
				}
				const userObj = {
					id: uid,
					email: "supera@gmail.com",
					role: "admin",
					fullName: "Super Admin"
				};
				window.localStorage.setItem("realjob-user", JSON.stringify(userObj));
				dataStore.setCurrentUser(userObj);
				toast.success("✅ Super Admin Login Successful!");
				navigate({ to: "/superadmin" });
				setBusy(false);
				return;
			}
			const existingAccount = dataStore.findRegisteredAccount(enteredEmail);
			if (existingAccount) {
				if (existingAccount.password && existingAccount.password !== password) {
					toast.error("❌ चुकीचा पासवर्ड! (Wrong password. Please enter correct password.)");
					setBusy(false);
					return;
				}
				const userObj = {
					id: existingAccount.id,
					email: existingAccount.email,
					role: role === "admin" ? "employer" : role,
					fullName: existingAccount.fullName || "User",
					mobile: existingAccount.mobile || ""
				};
				window.localStorage.setItem("realjob-user", JSON.stringify(userObj));
				dataStore.setCurrentUser(userObj);
				toast.success(`✅ स्वागत आहे, ${existingAccount.fullName}! Welcome back.`);
				if (userObj.role === "employer" || userObj.role === "admin" || role === "admin" || role === "employer") navigate({ to: "/admin" });
				else navigate({ to: "/home" });
			} else {
				const newAcc = dataStore.registerAccount({
					email: enteredEmail,
					password,
					role: role === "admin" ? "employer" : role,
					fullName: enteredEmail.split("@")[0] || "Company Admin"
				});
				const userObj = {
					id: newAcc.id,
					email: newAcc.email,
					role: newAcc.role,
					fullName: newAcc.fullName || "Company Admin",
					mobile: newAcc.mobile || ""
				};
				window.localStorage.setItem("realjob-user", JSON.stringify(userObj));
				dataStore.setCurrentUser(userObj);
				toast.success("✅ लॉगिन यशस्वी झाले! Welcome to REAL JOB!");
				if (userObj.role === "employer" || userObj.role === "admin" || role === "admin" || role === "employer") navigate({ to: "/admin" });
				else navigate({ to: "/home" });
			}
		} catch (err) {
			const code = err?.code || "";
			if (code === "auth/wrong-password" || code === "auth/invalid-credential") toast.error("❌ चुकीचा पासवर्ड! Superadmin password is 'supera123'.");
			else if (code === "auth/user-not-found") toast.error("❌ हा यूझर सापडला नाही. User not found.");
			else if (code === "auth/too-many-requests") toast.error("⚠️ जास्त प्रयत्न झाले. Too many attempts. Try later.");
			else toast.error(`Login Failed: ${err?.message || "Unknown error"}`);
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "h-screen w-full overflow-hidden relative flex items-center justify-center bg-cover bg-center bg-no-repeat p-3 sm:p-4",
		style: { backgroundImage: `url('/office_desk_bg.png')` },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-black/15 backdrop-blur-[2px] pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute left-4 top-3.5 z-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "ghost",
					size: "sm",
					className: "bg-white/85 hover:bg-white text-[#0A3B7B] font-bold text-xs rounded-full shadow-md backdrop-blur-md px-3.5 py-1.5 h-8 border border-white/70",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "mr-1 size-3.5" }), " Home"]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 w-full max-w-md sm:max-w-[420px] max-h-[92vh] overflow-y-auto bg-white/85 backdrop-blur-xl rounded-2xl border border-white/80 shadow-2xl px-5 py-4 sm:px-6 sm:py-5 transition-all duration-300",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex justify-center mb-1.5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoIcon, { className: "h-9 sm:h-10 object-contain" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center space-y-0.5 mb-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-lg sm:text-xl font-black text-[#0A3B7B] tracking-tight leading-tight",
							children: role === "admin" ? mode === "register" ? "Employer / Admin Registration" : mode === "forgot" ? "Reset Password" : "Employer / Admin Login" : mode === "register" ? "Worker / User Registration" : mode === "forgot" ? "Reset Password" : "Worker / User Login"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] sm:text-[11px] font-semibold text-gray-600 px-1 leading-tight",
							children: role === "admin" ? mode === "register" ? "For employers & companies: Register an account to find workers." : "For employers & admins: Login to post jobs and search candidates." : mode === "register" ? "For job seekers: Create a new profile and start finding jobs." : "Please enter your email and password to log in and find jobs."
						})]
					}),
					mode !== "forgot" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-gray-200/80 backdrop-blur-md p-1 rounded-full border border-white/70 flex items-center shadow-inner mb-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setMode("login"),
							className: `flex-1 py-1 rounded-full text-[11px] font-black transition-all duration-200 flex items-center justify-center gap-1.5 ${mode === "login" ? "bg-[#0A3B7B] text-white shadow-md shadow-[#0A3B7B]/30" : "text-gray-700 hover:text-black font-bold"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-3.5" }), " Login"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setMode("register"),
							className: `flex-1 py-1 rounded-full text-[11px] font-black transition-all duration-200 flex items-center justify-center gap-1.5 ${mode === "register" ? "bg-[#0A3B7B] text-white shadow-md shadow-[#0A3B7B]/30" : "text-gray-700 hover:text-black font-bold"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-3.5" }), " Register"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleSubmit,
						autoComplete: "off",
						className: "space-y-2.5",
						children: [
							mode === "register" && role === "worker" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[10px] sm:text-[11px] font-extrabold text-gray-800 mb-0.5 block",
									children: "Full Name *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-gray-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										type: "text",
										autoComplete: "off",
										placeholder: "e.g. Rahul Sharma",
										value: workerName,
										onChange: (e) => setWorkerName(e.target.value),
										className: "w-full h-8.5 pl-9 pr-3 bg-white rounded-lg border border-gray-200 text-xs font-bold text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#0A3B7B]"
									})]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[10px] sm:text-[11px] font-extrabold text-gray-800 mb-0.5 block",
									children: "Mobile Number *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-gray-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										type: "tel",
										autoComplete: "off",
										placeholder: "+91 98220 00000",
										value: workerPhone,
										onChange: (e) => setWorkerPhone(e.target.value),
										className: "w-full h-8.5 pl-9 pr-3 bg-white rounded-lg border border-gray-200 text-xs font-bold text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#0A3B7B]"
									})]
								})] })]
							}),
							mode === "register" && (role === "employer" || role === "admin") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[10px] sm:text-[11px] font-extrabold text-gray-800 mb-0.5 block",
									children: "Company Name *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-gray-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										type: "text",
										autoComplete: "off",
										placeholder: "e.g. Tata Motors / L&T",
										value: companyName,
										onChange: (e) => setCompanyName(e.target.value),
										className: "w-full h-8.5 pl-9 pr-3 bg-white rounded-lg border border-gray-200 text-xs font-bold text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#0A3B7B]"
									})]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[10px] sm:text-[11px] font-extrabold text-gray-800 mb-0.5 block",
									children: "Mobile Number *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-gray-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										type: "tel",
										autoComplete: "off",
										placeholder: "+91 98220 00000",
										value: employerPhone,
										onChange: (e) => setEmployerPhone(e.target.value),
										className: "w-full h-8.5 pl-9 pr-3 bg-white rounded-lg border border-gray-200 text-xs font-bold text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#0A3B7B]"
									})]
								})] })]
							}),
							mode === "register" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-blue-50/80 p-2 sm:p-2.5 rounded-xl border border-blue-100 space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [profilePhoto ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: profilePhoto,
										alt: "Profile Preview",
										className: "size-9 rounded-full object-cover ring-2 ring-[#0A3B7B] shadow-xs"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "size-9 rounded-full bg-[#0A3B7B]/10 text-[#0A3B7B] flex items-center justify-center shrink-0 border border-[#0A3B7B]/20",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] font-extrabold text-[#0A3B7B]",
										children: role === "employer" || role === "admin" ? "Company Logo / Photo" : "Profile Photo (प्रोफाईल फोटो)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] text-gray-500 font-bold",
										children: profilePhoto ? "✓ Photo Attached" : "Choose file or take live camera photo"
									})] })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 pt-0.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex-1 py-1 px-2 rounded-lg bg-[#0A3B7B] text-white text-[10px] sm:text-[11px] font-black cursor-pointer hover:bg-[#072B5B] transition-colors shadow-xs flex items-center justify-center gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-3" }),
											" ",
											profilePhoto ? "Change" : "Upload File",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "file",
												accept: "image/*",
												onChange: handlePhotoUpload,
												className: "hidden"
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: startCamera,
										className: "flex-1 py-1 px-2 rounded-lg bg-emerald-700 text-white text-[10px] sm:text-[11px] font-black hover:bg-emerald-800 transition-colors shadow-xs flex items-center justify-center gap-1 cursor-pointer",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-3" }),
											" ",
											lang === "mr" ? "कॅमेरा उघडा" : "Take Photo"
										]
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "email",
								className: "text-[10px] sm:text-[11px] font-extrabold text-gray-800 mb-0.5 block",
								children: mode === "login" ? "Email Address or Mobile Number *" : "Email Address (Optional / ऐच्छिक)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [mode === "login" && /^\d+$/.test(email.replace(/\D/g, "")) && email.length >= 5 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-[#0A3B7B]" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-gray-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "email",
									type: mode === "login" ? "text" : "email",
									required: mode === "login",
									autoComplete: "off",
									placeholder: mode === "login" ? "Email or Mobile (e.g. 98220 00000 / user@gmail.com)" : "name@example.com (Optional)",
									value: email,
									onChange: (e) => setEmail(e.target.value),
									className: "w-full h-8.5 pl-9 pr-3 bg-white rounded-lg border border-gray-200 text-xs font-bold text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-[#0A3B7B] shadow-xs"
								})]
							})] }),
							mode !== "forgot" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between items-center mb-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "password",
									className: "text-[11px] font-extrabold text-gray-800",
									children: "Password *"
								}), mode === "login" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setMode("forgot"),
									className: "text-[11px] font-bold text-[#0A3B7B] hover:underline",
									children: "Forgot Password?"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-gray-400" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "password",
										type: showPassword ? "text" : "password",
										required: true,
										autoComplete: "new-password",
										placeholder: "••••••••",
										minLength: 6,
										value: password,
										onChange: (e) => setPassword(e.target.value),
										className: "w-full h-9.5 pl-9 pr-9 bg-white rounded-lg border border-gray-200 text-xs font-bold text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-[#0A3B7B] shadow-xs"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setShowPassword(!showPassword),
										className: "absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600",
										children: showPassword ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5" })
									})
								]
							})] }),
							mode === "login" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 pt-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									id: "remember",
									checked: rememberMe,
									onChange: (e) => setRememberMe(e.target.checked),
									className: "size-3.5 rounded border-gray-300 text-[#0A3B7B] focus:ring-[#0A3B7B] accent-[#0A3B7B] cursor-pointer"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "remember",
									className: "text-[11px] font-bold text-gray-700 cursor-pointer select-none",
									children: "Remember me"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								disabled: busy,
								type: "submit",
								className: "w-full h-10 bg-[#0A3B7B] hover:bg-[#072B5B] text-white font-black text-xs rounded-lg shadow-md shadow-[#0A3B7B]/20 hover:shadow-lg transition-all duration-200 flex items-center justify-center gap-2 mt-1",
								children: busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin size-4" }) : mode === "register" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-3.5" }), " Register Account"] }) : mode === "forgot" ? "Send Reset Link" : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogIn, { className: "size-3.5" }), " Sign In"] })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 text-center text-[11px] font-bold text-gray-600",
						children: [
							mode === "register" ? "Already have an account?" : "Don't have an account?",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setMode(mode === "register" ? "login" : "register"),
								className: "text-[#0A3B7B] font-black hover:underline ml-1",
								children: mode === "register" ? "Sign In" : "Register"
							})
						]
					})
				]
			}),
			cameraOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-[#051B38]/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-white/40 flex flex-col items-center animate-in zoom-in-95 duration-200",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "w-full flex items-center justify-between pb-3 border-b border-gray-100 mb-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-8 rounded-full bg-[#0A3B7B]/10 text-[#0A3B7B] flex items-center justify-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-black text-sm text-[#0A3B7B]",
									children: lang === "mr" ? "थेट फोटो काढा (Take Photo)" : "Live Camera Capture"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: stopCamera,
								className: "size-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-gray-500 hover:text-gray-700 transition-colors",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative size-64 sm:size-72 rounded-2xl overflow-hidden bg-black flex items-center justify-center shadow-inner border-2 border-[#0A3B7B]",
							children: tempCaptured ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: tempCaptured,
								alt: "Captured",
								className: "w-full h-full object-cover"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
								ref: videoRef,
								autoPlay: true,
								playsInline: true,
								muted: true,
								className: "w-full h-full object-cover transform -scale-x-100"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-full flex items-center justify-center gap-3 mt-5",
							children: tempCaptured ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setTempCaptured(null),
								className: "px-4 py-2.5 rounded-xl border border-gray-300 text-xs font-bold text-gray-700 hover:bg-gray-50 flex items-center gap-1.5 transition-colors cursor-pointer",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }),
									" ",
									lang === "mr" ? "पुन्हा काढा (Retake)" : "Retake"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: confirmCapturedPhoto,
								className: "px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black shadow-md flex items-center gap-1.5 transition-colors cursor-pointer",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }),
									" ",
									lang === "mr" ? "फोटो वापरा (Use Photo)" : "Use Photo"
								]
							})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: capturePhoto,
								className: "px-6 py-3 rounded-full bg-[#0A3B7B] hover:bg-[#072B5B] text-white text-xs font-black shadow-lg shadow-[#0A3B7B]/30 flex items-center gap-2 transition-all transform active:scale-95 cursor-pointer",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-4" }),
									" 📷 ",
									lang === "mr" ? "फोटो काढा (Snap Photo)" : "Snap Photo"
								]
							})
						})
					]
				})
			})
		]
	});
}
//#endregion
export { AuthPage as component };
