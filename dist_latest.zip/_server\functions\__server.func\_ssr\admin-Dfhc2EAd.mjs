import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n } from "./i18n-BlIP7F54.mjs";
import { t as dataStore } from "./data-store-CPuK80w4.mjs";
import { t as Button } from "./button-KWVQ7n-R.mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { $ as LocateFixed, $t as Calendar, At as ExternalLink, C as Smartphone, D as ShieldCheck, Et as FileText, It as CreditCard, J as MapPin, Jt as ChevronDown, Kt as ChevronRight, L as Printer, M as Search, Pt as DollarSign, R as Plus, S as Sparkles, U as Package, V as PenLine, W as Navigation, Wt as CircleCheck, X as LogOut, Xt as ChartPie, Yt as Check, Zt as ChartColumn, an as BriefcaseBusiness, at as Layers, b as SquarePen, c as User, d as UserPlus, en as CalendarDays, et as LoaderCircle, f as UserCheck, g as Trash2, l as UserX, n as X, q as Menu, qt as ChevronLeft, rn as Building2, s as Users, t as Zap, tn as CalendarCheck, ut as IndianRupee, z as Phone, zt as Clock } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Badge } from "./badge-7W_V4vX2.mjs";
import { t as Input } from "./input-C3Ab97hR.mjs";
import { n as parseMapCoordinates, t as SalarySlip } from "./location-utils-BHbkxQBL.mjs";
import { t as Label } from "./label-BGvJ-OWw.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-Dfhc2EAd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function parseTimeStringToMinutes(timeStr) {
	if (!timeStr) return null;
	const match = timeStr.trim().toUpperCase().match(/^(\d{1,2}):(\d{2})\s*(AM|PM)?$/);
	if (!match || !match[1] || !match[2]) return null;
	let hours = parseInt(match[1], 10);
	const minutes = parseInt(match[2], 10);
	const meridiem = match[3];
	if (meridiem) {
		if (meridiem === "PM" && hours < 12) hours += 12;
		if (meridiem === "AM" && hours === 12) hours = 0;
	}
	return hours * 60 + minutes;
}
function formatTime12Hr(timeStr) {
	if (!timeStr) return "";
	const clean = timeStr.trim();
	if (!clean) return "";
	if (/AM|PM/i.test(clean)) return clean;
	const parts = clean.split(":");
	if (parts.length < 2) return clean;
	let hours = parseInt(parts[0], 10);
	const minutes = parts[1].padStart(2, "0");
	if (isNaN(hours)) return clean;
	const ampm = hours >= 12 ? "PM" : "AM";
	hours = hours % 12;
	if (hours === 0) hours = 12;
	return `${hours.toString().padStart(2, "0")}:${minutes} ${ampm}`;
}
function computeHoursFromTimes(startStr, endStr) {
	if (!startStr || !endStr) return 9;
	const start = parseTimeStringToMinutes(startStr);
	const end = parseTimeStringToMinutes(endStr);
	if (start !== null && end !== null && end > start) {
		const diff = end - start;
		return Math.round(diff / 60 * 10) / 10;
	}
	return 9;
}
function calculateWorkAndOvertime(punchInTime, punchOutTime, standardShiftMinutes = 540) {
	if (!punchInTime) return {
		statusText: "Not Punched In",
		workedText: "--",
		overtimeText: null,
		totalMinutes: 0,
		overtimeMinutes: 0,
		isCurrentlyWorking: false
	};
	const inMins = parseTimeStringToMinutes(punchInTime);
	if (inMins === null) return {
		statusText: "Invalid Punch In",
		workedText: "--",
		overtimeText: null,
		totalMinutes: 0,
		overtimeMinutes: 0,
		isCurrentlyWorking: false
	};
	let outMins = null;
	let isCurrentlyWorking = false;
	if (punchOutTime) outMins = parseTimeStringToMinutes(punchOutTime);
	if (outMins !== null && outMins < inMins) outMins = null;
	if (outMins === null) {
		const now = /* @__PURE__ */ new Date();
		outMins = now.getHours() * 60 + now.getMinutes();
		isCurrentlyWorking = true;
	} else isCurrentlyWorking = false;
	const diffMins = Math.max(0, outMins - inMins);
	const workHrs = Math.floor(diffMins / 60);
	const workMins = diffMins % 60;
	let workedText = "";
	if (workHrs > 0 && workMins > 0) workedText = `${workHrs} hr${workHrs > 1 ? "s" : ""} ${workMins} min${workMins > 1 ? "s" : ""}`;
	else if (workHrs > 0) workedText = `${workHrs} hr${workHrs > 1 ? "s" : ""}`;
	else workedText = `${workMins} min${workMins > 1 ? "s" : ""}`;
	const otDiff = diffMins - standardShiftMinutes;
	let overtimeText = null;
	let overtimeMinutes = 0;
	if (otDiff > 0) {
		overtimeMinutes = otDiff;
		const otHrs = Math.floor(otDiff / 60);
		const otMins = otDiff % 60;
		if (otHrs > 0 && otMins > 0) overtimeText = `${otHrs} hr${otHrs > 1 ? "s" : ""} ${otMins} min${otMins > 1 ? "s" : ""}`;
		else if (otHrs > 0) overtimeText = `${otHrs} hr${otHrs > 1 ? "s" : ""}`;
		else overtimeText = `${otMins} min${otMins > 1 ? "s" : ""}`;
	}
	return {
		statusText: isCurrentlyWorking ? "Working Now (Active)" : "Shift Completed",
		workedText,
		overtimeText,
		totalMinutes: diffMins,
		overtimeMinutes,
		isCurrentlyWorking
	};
}
function formatWaNumber(phone) {
	const digits = (phone || "").trim().replace(/\D/g, "");
	if (!digits) return "919822011223";
	if (digits.length === 10) return `91${digits}`;
	if (digits.length === 12 && digits.startsWith("91")) return digits;
	if (digits.length === 11 && digits.startsWith("0")) return `91${digits.slice(1)}`;
	return digits.length >= 10 ? digits : `91${digits}`;
}
function formatCallNumber(phone) {
	const raw = (phone || "").trim();
	const digits = raw.replace(/\D/g, "");
	if (!digits) return "+919822011223";
	if (digits.length === 10) return `+91${digits}`;
	if (digits.length === 12 && digits.startsWith("91")) return `+${digits}`;
	if (digits.length === 11 && digits.startsWith("0")) return `+91${digits.slice(1)}`;
	return raw.startsWith("+") ? raw : `+${digits}`;
}
function AdminDashboardPage() {
	const navigate = useNavigate();
	const { t, n } = useI18n();
	const [activeTabState, setActiveTabState] = (0, import_react.useState)("overview");
	const [isPendingTab, startTransitionTab] = (0, import_react.useTransition)();
	const activeTab = activeTabState;
	const setActiveTab = (tab) => {
		startTransitionTab(() => {
			setActiveTabState(tab);
		});
	};
	const [jobs, setJobs] = (0, import_react.useState)([]);
	const [applications, setApplications] = (0, import_react.useState)([]);
	const [userSearch, setUserSearch] = (0, import_react.useState)("");
	const [jobSearch, setJobSearch] = (0, import_react.useState)("");
	const [jobsPage, setJobsPage] = (0, import_react.useState)(1);
	const JOBS_PER_PAGE = 5;
	const [appSearch, setAppSearch] = (0, import_react.useState)("");
	const [filterJobId, setFilterJobId] = (0, import_react.useState)(null);
	const [expandedApp, setExpandedApp] = (0, import_react.useState)(null);
	const [viewSlipWorker, setViewSlipWorker] = (0, import_react.useState)(null);
	const [viewSlipPeriod, setViewSlipPeriod] = (0, import_react.useState)("month");
	const [workers, setWorkers] = (0, import_react.useState)([]);
	const [selectedAttendanceDate, setSelectedAttendanceDate] = (0, import_react.useState)((/* @__PURE__ */ new Date()).toISOString().split("T")[0]);
	const [dailyAttendanceRecords, setDailyAttendanceRecords] = (0, import_react.useState)([]);
	const [workerSearch, setWorkerSearch] = (0, import_react.useState)("");
	const [showWorkerModal, setShowWorkerModal] = (0, import_react.useState)(false);
	const [showLocationModal, setShowLocationModal] = (0, import_react.useState)(false);
	const [locationLinkInput, setLocationLinkInput] = (0, import_react.useState)("");
	const [isDetectingLocation, setIsDetectingLocation] = (0, import_react.useState)(false);
	const [editingWorkerId, setEditingWorkerId] = (0, import_react.useState)(null);
	const [calendarWorker, setCalendarWorker] = (0, import_react.useState)(null);
	const [calendarMonth, setCalendarMonth] = (0, import_react.useState)(() => (/* @__PURE__ */ new Date()).getMonth());
	const [calendarYear, setCalendarYear] = (0, import_react.useState)(() => (/* @__PURE__ */ new Date()).getFullYear());
	const [activeCalendarDate, setActiveCalendarDate] = (0, import_react.useState)(null);
	const [customOtHoursInput, setCustomOtHoursInput] = (0, import_react.useState)(2);
	const [overtimeModalDate, setOvertimeModalDate] = (0, import_react.useState)(null);
	const [overtimeModalHours, setOvertimeModalHours] = (0, import_react.useState)(3);
	const [showBulkFillSection, setShowBulkFillSection] = (0, import_react.useState)(false);
	const [bulkFillStatus, setBulkFillStatus] = (0, import_react.useState)("Present");
	const [bulkFillOtHours, setBulkFillOtHours] = (0, import_react.useState)(2);
	const [bulkFillFromDate, setBulkFillFromDate] = (0, import_react.useState)(() => {
		const d = /* @__PURE__ */ new Date();
		d.setDate(d.getDate() - 14);
		return d.toISOString().split("T")[0];
	});
	const [bulkFillToDate, setBulkFillToDate] = (0, import_react.useState)(() => (/* @__PURE__ */ new Date()).toISOString().split("T")[0]);
	const [bulkSkipSundays, setBulkSkipSundays] = (0, import_react.useState)(true);
	const [attendanceSubView, setAttendanceSubView] = (0, import_react.useState)("daily");
	const [selectedCategoryFilter, setSelectedCategoryFilter] = (0, import_react.useState)("ALL");
	const [reportTimeframe, setReportTimeframe] = (0, import_react.useState)("month");
	const [reportStartDate, setReportStartDate] = (0, import_react.useState)(() => {
		const d = /* @__PURE__ */ new Date();
		d.setDate(1);
		return d.toISOString().split("T")[0];
	});
	const [reportEndDate, setReportEndDate] = (0, import_react.useState)((/* @__PURE__ */ new Date()).toISOString().split("T")[0]);
	const [reportAttendanceRecords, setReportAttendanceRecords] = (0, import_react.useState)([]);
	const [selectedWorkerReport, setSelectedWorkerReport] = (0, import_react.useState)(null);
	const [workerReportPeriod, setWorkerReportPeriod] = (0, import_react.useState)("month");
	const [selectedSalaryWorkerId, setSelectedSalaryWorkerId] = (0, import_react.useState)(null);
	const [selectedSalaryMonth, setSelectedSalaryMonth] = (0, import_react.useState)(() => {
		return (/* @__PURE__ */ new Date()).toLocaleDateString("en-US", { month: "long" });
	});
	const [selectedSalaryYear, setSelectedSalaryYear] = (0, import_react.useState)(() => {
		return (/* @__PURE__ */ new Date()).getFullYear().toString();
	});
	const [slipRangeStartDay, setSlipRangeStartDay] = (0, import_react.useState)(10);
	const [slipRangeEndDay, setSlipRangeEndDay] = (0, import_react.useState)(20);
	const [workerForm, setWorkerForm] = (0, import_react.useState)({
		name: "",
		mobile: "",
		trade: "General Worker",
		category: "Plant Nursery & Care",
		education: "",
		dailyRate: "500",
		joiningDate: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
		workShiftStart: "09:00",
		workShiftEnd: "18:00",
		dailyWorkingHours: "9",
		overtimeRate: "56",
		overtimeRateMode: "auto",
		notes: "",
		pin: "1234",
		locationType: "fixed",
		attendanceMode: "punch"
	});
	const [persistentCustomFields, setPersistentCustomFields] = (0, import_react.useState)(() => {
		try {
			const saved = localStorage.getItem(`emp_custom_fields_tpl_${empIdentifier}`);
			return saved ? JSON.parse(saved) : [];
		} catch {
			return [];
		}
	});
	const [customFields, setCustomFields] = (0, import_react.useState)([]);
	const [showAddFieldPrompt, setShowAddFieldPrompt] = (0, import_react.useState)(false);
	const [newFieldNameInput, setNewFieldNameInput] = (0, import_react.useState)("");
	const [removedStandardFields, setRemovedStandardFields] = (0, import_react.useState)([]);
	const getStoredCustomCats = () => {
		try {
			const s1 = localStorage.getItem(`emp_custom_cats_${empIdentifier}`);
			const s2 = localStorage.getItem("emp_custom_cats_global");
			const set = /* @__PURE__ */ new Set();
			if (s1) JSON.parse(s1).forEach((c) => set.add(c));
			if (s2) JSON.parse(s2).forEach((c) => set.add(c));
			return Array.from(set);
		} catch {
			return [];
		}
	};
	const [customCategories, setCustomCategories] = (0, import_react.useState)(getStoredCustomCats);
	const getStoredRemovedCats = () => {
		try {
			const s1 = localStorage.getItem(`emp_removed_cats_${empIdentifier}`);
			const s2 = localStorage.getItem("emp_removed_cats_global");
			const set = /* @__PURE__ */ new Set();
			if (s1) JSON.parse(s1).forEach((c) => set.add(c));
			if (s2) JSON.parse(s2).forEach((c) => set.add(c));
			return Array.from(set);
		} catch {
			return [];
		}
	};
	const [removedCategories, setRemovedCategories] = (0, import_react.useState)(getStoredRemovedCats);
	const [showOtherCategoryInput, setShowOtherCategoryInput] = (0, import_react.useState)(false);
	const [isCategoryDropdownOpen, setIsCategoryDropdownOpen] = (0, import_react.useState)(false);
	const [newCustomCategoryInput, setNewCustomCategoryInput] = (0, import_react.useState)("");
	const handleAddCustomCategory = () => {
		const trimmed = newCustomCategoryInput.trim();
		if (!trimmed) {
			toast.error("Please enter department / category name");
			return;
		}
		const catName = trimmed.startsWith("✨") || trimmed.startsWith("🌱") || trimmed.startsWith("🚜") || trimmed.startsWith("⚙️") ? trimmed : `✨ ${trimmed}`;
		const updated = Array.from(/* @__PURE__ */ new Set([...customCategories, catName]));
		setCustomCategories(updated);
		setRemovedCategories((prev) => prev.filter((c) => c !== catName));
		try {
			localStorage.setItem(`emp_custom_cats_${empIdentifier}`, JSON.stringify(updated));
			localStorage.setItem("emp_custom_cats_global", JSON.stringify(updated));
		} catch (e) {
			console.error(e);
		}
		setWorkerForm((p) => ({
			...p,
			category: catName
		}));
		toast.success(`Category "${catName}" added & selected!`);
		setNewCustomCategoryInput("");
		setShowOtherCategoryInput(false);
	};
	const handleRemoveCategory = (catToRemove) => {
		if (customCategories.includes(catToRemove)) {
			const updatedCustom = customCategories.filter((c) => c !== catToRemove);
			setCustomCategories(updatedCustom);
			try {
				localStorage.setItem(`emp_custom_cats_${empIdentifier}`, JSON.stringify(updatedCustom));
				localStorage.setItem("emp_custom_cats_global", JSON.stringify(updatedCustom));
			} catch (e) {
				console.error(e);
			}
		} else {
			const updatedRemoved = Array.from(/* @__PURE__ */ new Set([...removedCategories, catToRemove]));
			setRemovedCategories(updatedRemoved);
			try {
				localStorage.setItem(`emp_removed_cats_${empIdentifier}`, JSON.stringify(updatedRemoved));
				localStorage.setItem("emp_removed_cats_global", JSON.stringify(updatedRemoved));
			} catch (e) {
				console.error(e);
			}
		}
		if (workerForm.category === catToRemove) {
			const remaining = [
				...getIndustryDefaultCategories(),
				...customCategories,
				"⚙️ Other / Custom"
			].filter((c) => c !== catToRemove && !removedCategories.includes(c));
			setWorkerForm((p) => ({
				...p,
				category: remaining[0] || getIndustryDefaultCategories()[0] || "General Work"
			}));
		}
		toast.info(`Category "${catToRemove}" removed`);
	};
	const savePersistentCustomFields = (fields) => {
		setPersistentCustomFields(fields);
		try {
			localStorage.setItem(`emp_custom_fields_tpl_${empIdentifier}`, JSON.stringify(fields.map((f) => ({
				label: f.label,
				value: ""
			}))));
		} catch (e) {
			console.error(e);
		}
	};
	const handleRemoveStandardField = (fieldKey) => {
		setRemovedStandardFields((prev) => [...prev, fieldKey]);
		toast.info("Field removed from form");
	};
	const handleRestoreStandardField = (fieldKey) => {
		setRemovedStandardFields((prev) => prev.filter((k) => k !== fieldKey));
		toast.success("Field restored to form");
	};
	const handleOpenAddFieldPrompt = () => {
		setNewFieldNameInput("");
		setShowAddFieldPrompt(true);
	};
	const handleConfirmAddCustomField = (presetName) => {
		const fieldName = (presetName || newFieldNameInput).trim();
		if (!fieldName) {
			toast.error("Please enter a field title (e.g. Aadhaar Card ID)");
			return;
		}
		const updated = [...customFields, {
			label: fieldName,
			value: ""
		}];
		setCustomFields(updated);
		savePersistentCustomFields(updated);
		toast.success(`"${fieldName}" added to form!`);
		setNewFieldNameInput("");
		setShowAddFieldPrompt(false);
	};
	const handleRemoveCustomField = (index) => {
		const updated = customFields.filter((_, i) => i !== index);
		setCustomFields(updated);
		savePersistentCustomFields(updated);
		toast.info("Custom field removed");
	};
	const handleCustomFieldChange = (index, key, val) => {
		setCustomFields((prev) => {
			const copy = [...prev];
			const existing = copy[index];
			if (existing) copy[index] = {
				...existing,
				[key]: val
			};
			return copy;
		});
	};
	const detectEmployerIndustry = () => {
		const text = `${currentUser?.fullName || ""} ${currentUser?.email || ""} ${empIdentifier || ""} ${profileForm?.industry || ""}`.toLowerCase();
		if (text.includes("itpl") || text.includes("software") || text.includes("technology") || text.includes("tech") || text.includes("it ") || text.includes(" bpo") || text.includes("computer") || text.includes("digital") || text.includes("infosys") || text.includes("tcs")) return "it_software";
		if (text.includes("construction") || text.includes("builder") || text.includes("developer") || text.includes("infrastructure") || text.includes("कंत्राटदार") || text.includes("कंत्राटदार") || text.includes("vaje")) return "construction";
		if (text.includes("factory") || text.includes("manufacturing") || text.includes("auto") || text.includes("steel") || text.includes("pipes") || text.includes("engineering")) return "factory";
		if (text.includes("hotel") || text.includes("restaurant") || text.includes("caterer") || text.includes("resort") || text.includes("food")) return "hospitality";
		if (text.includes("hospital") || text.includes("clinic") || text.includes("medical") || text.includes("pharma") || text.includes("health")) return "healthcare";
		if (text.includes("nursery") || text.includes("ropvatika") || text.includes("farm") || text.includes("krushi") || text.includes("agri") || text.includes("plant") || text.includes("कंत्राटदार")) return "agriculture";
		return "general";
	};
	const getIndustryDefaultCategories = () => {
		const indType = detectEmployerIndustry();
		const categoriesMap = {
			construction: [
				"🧱 Masonry & Brickwork",
				"⚡ Electrical & Wiring",
				"🔧 Plumbing & Piping",
				"🪵 Carpentry & Woodwork",
				"🎨 Painting & Finishing",
				"👷 General Labour & Helper"
			],
			factory: [
				"⚙️ Machine Operator",
				"🔧 Quality & Assembly",
				"📦 Packing & Warehouse",
				"👷 Helper & Maintenance",
				"🚛 Loading & Unloading"
			],
			hospitality: [
				"👨‍🍳 Chef & Kitchen Staff",
				"🍽️ Waiter & Food Service",
				"🧹 Housekeeping & Cleaning",
				"🛎️ Reception & Billing",
				"🛡️ Security & Support"
			],
			healthcare: [
				"🩺 Nursing & Patient Care",
				"💊 Pharmacy & Medical Support",
				"🔬 Lab Technician",
				"🧹 Sanitation & Cleaning",
				"🛡️ Security & Maintenance"
			],
			it_software: [
				"💻 Software Developer / Engineer",
				"🎨 UI/UX Designer",
				"📊 Data Analyst",
				"📞 BPO / Call Center Executive",
				"📈 Sales & Marketing",
				"👥 HR & Administration",
				"🖥️ System Admin / IT Support",
				"💼 Project Manager"
			],
			agriculture: [
				"🌱 Plant Nursery & Care",
				"🚜 Tractor & Machinery",
				"✂️ Grafting & Propagation",
				"📦 Packing & Loading",
				"💧 Irrigation & Spraying",
				"🌿 Soil & Fertilizer",
				"👷 General Labour"
			]
		};
		const generalCategories = [
			"💼 Office Staff & Admin",
			"🚛 Logistics & Transport",
			"🧹 Cleaning & Housekeeping",
			"🛡️ Security Guard"
		];
		let combinedResults = [];
		if (indType !== "general" && categoriesMap[indType]) combinedResults.push(...categoriesMap[indType]);
		combinedResults.push(...generalCategories);
		Object.keys(categoriesMap).forEach((key) => {
			if (key !== indType) combinedResults.push(...categoriesMap[key] || []);
		});
		return Array.from(new Set(combinedResults));
	};
	const formatCategoryName = (cat) => {
		if (!cat) return getIndustryDefaultCategories()[0] || "General Work";
		return cat.replace(/[\u1000-\uFFFF]/g, "").replace(/• /g, "").trim() || cat;
	};
	const getWorkerReportMetrics = (worker, period, targetMonthName, targetYearStr, customStartDate, customEndDate) => {
		let startDate = "";
		let endDate = "";
		const now = /* @__PURE__ */ new Date();
		const activeEmpId = currentUser?.id || currentUser?.fullName || currentUser?.email || empIdentifier;
		const monthMap = {
			January: 0,
			February: 1,
			March: 2,
			April: 3,
			May: 4,
			June: 5,
			July: 6,
			August: 7,
			September: 8,
			October: 9,
			November: 10,
			December: 11
		};
		const effectiveMonthName = targetMonthName || selectedSalaryMonth || now.toLocaleDateString("en-US", { month: "long" });
		const effectiveYearStr = targetYearStr || selectedSalaryYear || String(now.getFullYear());
		const mIdx = monthMap[effectiveMonthName] !== void 0 ? monthMap[effectiveMonthName] : now.getMonth();
		const yVal = parseInt(effectiveYearStr, 10) || now.getFullYear();
		const daysInTargetMonth = new Date(yVal, mIdx + 1, 0).getDate();
		if (customStartDate && customEndDate) {
			startDate = customStartDate;
			endDate = customEndDate;
		} else if (period === "week") {
			const d = /* @__PURE__ */ new Date();
			d.setDate(d.getDate() - 6);
			startDate = d.toISOString().split("T")[0];
			endDate = now.toISOString().split("T")[0];
		} else if (period === "month") {
			startDate = `${yVal}-${String(mIdx + 1).padStart(2, "0")}-01`;
			endDate = `${yVal}-${String(mIdx + 1).padStart(2, "0")}-${String(daysInTargetMonth).padStart(2, "0")}`;
		} else {
			startDate = worker.joiningDate || "2020-01-01";
			endDate = `${yVal}-${String(mIdx + 1).padStart(2, "0")}-${String(daysInTargetMonth).padStart(2, "0")}`;
		}
		if (worker.joiningDate && period === "all" && worker.joiningDate > startDate) startDate = worker.joiningDate;
		const workerRecords = dataStore.getEmployerAttendanceRange(activeEmpId, startDate, endDate).filter((r) => r.workerId === worker.id);
		let present = 0;
		let halfDay = 0;
		let absent = 0;
		let overtime = 0;
		let totalOvertimeHours = 0;
		let netPay = 0;
		const overtimeEntries = [];
		workerRecords.forEach((r) => {
			if (r.status === "Present") {
				present++;
				netPay += worker.dailyRate;
			} else if (r.status === "HalfDay") {
				halfDay++;
				netPay += Math.round(worker.dailyRate / 2);
			} else if (r.status === "Absent") absent++;
			else if (r.status === "Overtime") {
				present++;
				overtime++;
				const otH = r.overtimeHours !== void 0 ? Number(r.overtimeHours) : 2;
				totalOvertimeHours += otH;
				const dayNum = parseInt(r.date.split("-")[2] || "1", 10);
				overtimeEntries.push({
					date: r.date,
					day: dayNum,
					overtimeHours: otH
				});
				const shiftH = computeHoursFromTimes(worker.workShiftStart, worker.workShiftEnd) || 9;
				const otHourlyRate = worker.overtimeRate !== void 0 && worker.overtimeRate !== null && Number(worker.overtimeRate) > 0 ? Number(worker.overtimeRate) : Math.round(worker.dailyRate / shiftH);
				netPay += Math.round(worker.dailyRate + otH * otHourlyRate);
			}
		});
		overtimeEntries.sort((a, b) => a.day - b.day);
		return {
			startDate,
			endDate,
			records: workerRecords,
			present,
			halfDay,
			absent,
			overtime,
			overtimeEntries,
			totalOvertimeHours,
			totalDays: workerRecords.length,
			daysInMonth: daysInTargetMonth,
			netPay
		};
	};
	const [showPackageModal, setShowPackageModal] = (0, import_react.useState)(false);
	const [selectedPlanId, setSelectedPlanId] = (0, import_react.useState)("plan-100");
	const [paymentMethod, setPaymentMethod] = (0, import_react.useState)("upi");
	const [upiId, setUpiId] = (0, import_react.useState)("");
	const [isProcessingPackage, setIsProcessingPackage] = (0, import_react.useState)(false);
	const [userCredits, setUserCredits] = (0, import_react.useState)(0);
	const [isMobileMenuOpen, setIsMobileMenuOpen] = (0, import_react.useState)(false);
	const [registeredUsers, setRegisteredUsers] = (0, import_react.useState)([]);
	const [currentUser, setCurrentUser] = (0, import_react.useState)(() => {
		if (typeof window !== "undefined") {
			const fromStore = dataStore.getCurrentUser("employer") || dataStore.getCurrentUser("admin");
			if (fromStore) return fromStore;
			try {
				const backup = localStorage.getItem("realjob-employer-profile");
				if (backup) return JSON.parse(backup);
			} catch {}
		}
		return null;
	});
	(0, import_react.useEffect)(() => {
		if (currentUser) setProfileForm((prev) => ({
			...prev,
			fullName: currentUser.fullName || prev.fullName,
			contactPerson: currentUser.contactPerson || currentUser.fullName || prev.fullName,
			email: currentUser.email || prev.email,
			mobile: currentUser.mobile || prev.mobile,
			profilePhoto: currentUser.profilePhoto || prev.profilePhoto,
			location: currentUser.location || prev.location,
			industry: currentUser.industry || prev.industry
		}));
	}, [currentUser]);
	(0, import_react.useEffect)(() => {
		if (!currentUser || currentUser.role !== "employer" && currentUser.role !== "admin") navigate({
			to: "/auth",
			search: {
				mode: "login",
				role: "admin"
			},
			replace: true
		});
	}, [currentUser, navigate]);
	(0, import_react.useEffect)(() => {
		const handlePopState = () => {
			dataStore.logout("employer");
			localStorage.removeItem("realjob-employer-profile");
			localStorage.removeItem("realjob-user-admin");
			localStorage.removeItem("realjob-user-employer");
			localStorage.removeItem("realjob-user");
			localStorage.removeItem("realjob-role");
			sessionStorage.removeItem("realjob_tab_user");
			window.location.replace("/auth?mode=login&role=admin");
		};
		window.addEventListener("popstate", handlePopState);
		return () => {
			window.removeEventListener("popstate", handlePopState);
			dataStore.logout("employer");
			localStorage.removeItem("realjob-employer-profile");
			localStorage.removeItem("realjob-user-admin");
			localStorage.removeItem("realjob-user-employer");
			localStorage.removeItem("realjob-user");
			localStorage.removeItem("realjob-role");
			sessionStorage.removeItem("realjob_tab_user");
		};
	}, []);
	const isSuperAdmin = currentUser?.email?.toLowerCase() === "supera@gmail.com" || currentUser?.email?.toLowerCase() === "superadmin";
	const empIdentifier = currentUser?.fullName || currentUser?.email || "admin-001";
	const [savedLocationLink, setSavedLocationLink] = (0, import_react.useState)(() => {
		try {
			const direct = localStorage.getItem(`emp_worksite_link_${empIdentifier}`);
			if (direct) return direct;
			return currentUser?.worksiteLocationLink || "";
		} catch {
			return currentUser?.worksiteLocationLink || "";
		}
	});
	const [savedLocationCoords, setSavedLocationCoords] = (0, import_react.useState)(() => {
		try {
			const direct = localStorage.getItem(`emp_worksite_coords_${empIdentifier}`);
			if (direct) return JSON.parse(direct);
			return currentUser?.worksiteLocation || null;
		} catch {
			return currentUser?.worksiteLocation || null;
		}
	});
	(0, import_react.useEffect)(() => {
		if (currentUser) {
			const storedLink = localStorage.getItem(`emp_worksite_link_${empIdentifier}`) || currentUser?.worksiteLocationLink;
			if (storedLink && storedLink !== savedLocationLink) setSavedLocationLink(storedLink);
			const storedCoords = localStorage.getItem(`emp_worksite_coords_${empIdentifier}`);
			const coords = storedCoords ? JSON.parse(storedCoords) : currentUser?.worksiteLocation;
			if (coords && (!savedLocationCoords || coords.lat !== savedLocationCoords.lat)) setSavedLocationCoords(coords);
		}
	}, [currentUser, empIdentifier]);
	const attendanceMode = (0, import_react.useMemo)(() => {
		try {
			const text = `${currentUser?.fullName || ""} ${empIdentifier || ""}`.toLowerCase();
			return [
				"farming",
				"farm",
				"agro",
				"agriculture",
				"nursery",
				"शेती",
				"शेत",
				"रोपवाटिका",
				"कृषी",
				"फार्मिंग",
				"construction",
				"site",
				"baukam",
				"बांधकाम",
				"साइट",
				"मजूर",
				"लेबर",
				"labour",
				"labor",
				"field",
				"driver",
				"moving",
				"delivery",
				"security",
				"guard",
				"हमाल"
			].some((kw) => text.includes(kw)) ? "field" : "fixed";
		} catch {
			return "fixed";
		}
	}, [currentUser?.fullName, empIdentifier]);
	const [profileForm, setProfileForm] = (0, import_react.useState)({
		fullName: "",
		contactPerson: "",
		email: "",
		mobile: "",
		profilePhoto: "",
		location: "Maharashtra",
		industry: "Plant Nursery & Workforce Services"
	});
	const handleSaveProfile = (e) => {
		e.preventDefault();
		if (!profileForm.fullName.trim()) {
			toast.error("Please enter company or full name");
			return;
		}
		const updatedUser = {
			...currentUser || {},
			id: currentUser?.id || `usr-${Date.now()}`,
			email: profileForm.email.trim() || currentUser?.email || "",
			role: currentUser?.role || "employer",
			fullName: profileForm.fullName.trim(),
			contactPerson: profileForm.contactPerson?.trim() || "",
			mobile: profileForm.mobile.trim(),
			profilePhoto: profileForm.profilePhoto.trim(),
			location: profileForm.location.trim(),
			industry: profileForm.industry.trim(),
			worksiteLocation: currentUser?.worksiteLocation || savedLocationCoords || null,
			worksiteLocationLink: currentUser?.worksiteLocationLink || savedLocationLink || ""
		};
		setCurrentUser(updatedUser);
		dataStore.setCurrentUser(updatedUser);
		dataStore.updateRegisteredAccount(updatedUser.id, updatedUser);
		try {
			localStorage.setItem("realjob-employer-profile", JSON.stringify(updatedUser));
			localStorage.setItem(`emp_profile_${updatedUser.id}`, JSON.stringify(updatedUser));
			if (updatedUser.email) localStorage.setItem(`emp_profile_${updatedUser.email.toLowerCase()}`, JSON.stringify(updatedUser));
		} catch {}
		toast.success("🎉 Profile updated successfully!");
	};
	const refreshCredits = () => {
		if (currentUser?.id) setUserCredits(dataStore.getUserJobCredits(currentUser.id));
	};
	const loadAttendanceData = () => {
		const activeEmpId = currentUser?.id || currentUser?.fullName || currentUser?.email || empIdentifier;
		const empWorkers = dataStore.getEmployerWorkers(activeEmpId);
		setWorkers(empWorkers);
		const attRecords = dataStore.getEmployerAttendance(activeEmpId, selectedAttendanceDate);
		setDailyAttendanceRecords(attRecords);
		let start = reportStartDate;
		let end = reportEndDate;
		if (reportTimeframe === "week") {
			const now = /* @__PURE__ */ new Date();
			const first = now.getDate() - now.getDay();
			start = new Date(now.setDate(first)).toISOString().split("T")[0];
			end = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
		} else if (reportTimeframe === "month") {
			const now = /* @__PURE__ */ new Date();
			start = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split("T")[0];
			end = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
		}
		const rangeRecords = dataStore.getEmployerAttendanceRange(activeEmpId, start, end);
		setReportAttendanceRecords(rangeRecords);
	};
	(0, import_react.useEffect)(() => {
		loadAttendanceData();
	}, [
		currentUser?.id,
		currentUser?.fullName,
		empIdentifier,
		selectedAttendanceDate,
		reportTimeframe,
		reportStartDate,
		reportEndDate
	]);
	const handleMarkAttendance = (worker, status, targetDate, overtimeHours) => {
		const activeEmpId = currentUser?.id || currentUser?.fullName || currentUser?.email || empIdentifier;
		const dateToUse = targetDate || selectedAttendanceDate;
		if (dateToUse > (/* @__PURE__ */ new Date()).toISOString().split("T")[0]) {
			toast.error("⚠️ आजनंतरच्या (भविष्यातील) तारखेची हजेरी नोंदवता येत नाही! (Cannot mark attendance for future dates)");
			return;
		}
		dataStore.saveAttendanceStatus(activeEmpId, worker.id, worker.name, dateToUse, status, void 0, void 0, overtimeHours);
		loadAttendanceData();
		const otText = status === "Overtime" ? ` (${overtimeHours || 2} तास OT)` : "";
		toast.success(`हजेरी नोंदवली: ${worker.name} - ${status}${otText} [${dateToUse}]`);
	};
	const handleOpenAddWorker = () => {
		const userId = currentUser?.id || currentUser?.email || empIdentifier;
		const allowedLimit = dataStore.getUserWorkerCredits(userId);
		if (allowedLimit === 0) {
			toast.error("⚠️ Active package required to add employees! Please purchase a package to continue.", { duration: 6e3 });
			setShowPackageModal(true);
			return;
		}
		if (workers.length >= allowedLimit) {
			toast.error(`⚠️ Employee limit reached for your active package! (Current Limit: ${allowedLimit} employees). Please upgrade package to add more employees!`, { duration: 6e3 });
			setShowPackageModal(true);
			return;
		}
		const defStart = "09:00";
		const defEnd = "18:00";
		const defHours = computeHoursFromTimes(defStart, defEnd);
		const defOtRate = Math.round(500 / defHours);
		setEditingWorkerId(null);
		setWorkerForm({
			name: "",
			mobile: "",
			trade: "General Worker",
			category: getIndustryDefaultCategories()[0] || "General Work",
			education: "",
			dailyRate: "500",
			joiningDate: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
			workShiftStart: defStart,
			workShiftEnd: defEnd,
			dailyWorkingHours: defHours.toString(),
			overtimeRate: defOtRate.toString(),
			overtimeRateMode: "auto",
			notes: "",
			pin: "1234",
			locationType: attendanceMode === "field" ? "field" : "fixed",
			attendanceMode: attendanceMode === "field" ? "manual" : "punch"
		});
		setCustomCategories(getStoredCustomCats());
		setCustomFields(persistentCustomFields.map((f) => ({
			label: f.label,
			value: ""
		})));
		setShowWorkerModal(true);
	};
	const handleOpenEditWorker = (w) => {
		setEditingWorkerId(w.id);
		setCustomCategories(getStoredCustomCats());
		const locType = w.locationType || (w.attendanceMode === "manual" ? "field" : "fixed");
		const attMode = w.attendanceMode || (locType === "field" ? "manual" : "punch");
		const start = w.workShiftStart || "09:00";
		const end = w.workShiftEnd || "18:00";
		const calcHours = computeHoursFromTimes(start, end);
		const workerHours = w.dailyWorkingHours ?? calcHours;
		const mode = w.overtimeRateMode || (w.overtimeRate ? "manual" : "auto");
		const autoRate = calcHours > 0 ? Math.round(w.dailyRate / calcHours) : 56;
		const finalOtRate = w.overtimeRate !== void 0 ? w.overtimeRate.toString() : autoRate.toString();
		setWorkerForm({
			name: w.name,
			mobile: w.mobile,
			trade: w.trade,
			category: w.category || w.trade || getIndustryDefaultCategories()[0] || "General Work",
			education: w.education || "",
			dailyRate: w.dailyRate.toString(),
			joiningDate: w.joiningDate || (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
			workShiftStart: start,
			workShiftEnd: end,
			dailyWorkingHours: workerHours.toString(),
			overtimeRate: finalOtRate,
			overtimeRateMode: mode,
			notes: w.notes || "",
			pin: w.pin || "1234",
			locationType: locType,
			attendanceMode: attMode
		});
		const merged = [...w.customFields || []];
		persistentCustomFields.forEach((tpl) => {
			if (!merged.some((m) => m.label.toLowerCase() === tpl.label.toLowerCase())) merged.push({
				label: tpl.label,
				value: ""
			});
		});
		setCustomFields(merged);
		setShowWorkerModal(true);
	};
	const handleSaveWorker = (e) => {
		e.preventDefault();
		if (!workerForm.name.trim()) {
			toast.error("Please enter employee name");
			return;
		}
		const baseHrsNum = computeHoursFromTimes(workerForm.workShiftStart, workerForm.workShiftEnd);
		const dailyWageNum = Number(workerForm.dailyRate) || 500;
		const workingHrsNum = Number(workerForm.dailyWorkingHours) || baseHrsNum;
		const autoOtRate = baseHrsNum > 0 ? Math.round(dailyWageNum / baseHrsNum) : 50;
		const otRateNum = Number(workerForm.overtimeRate) || autoOtRate;
		const activeEmpId = currentUser?.id || currentUser?.fullName || currentUser?.email || empIdentifier;
		const empCompanyName = currentUser?.companyName || currentUser?.fullName || currentUser?.name || empIdentifier || "Alpha Byte";
		dataStore.saveEmployerWorker({
			...editingWorkerId ? { id: editingWorkerId } : {},
			employerId: activeEmpId,
			employerName: empCompanyName,
			name: workerForm.name.trim(),
			mobile: workerForm.mobile.trim(),
			trade: workerForm.trade.trim() || "General Worker",
			category: workerForm.category.trim() || "Plant Nursery & Care",
			education: workerForm.education.trim(),
			dailyRate: dailyWageNum,
			joiningDate: workerForm.joiningDate || (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
			status: "Active",
			workShiftStart: workerForm.workShiftStart,
			workShiftEnd: workerForm.workShiftEnd,
			dailyWorkingHours: workingHrsNum,
			overtimeRate: otRateNum,
			overtimeRateMode: workerForm.overtimeRateMode,
			notes: workerForm.notes.trim(),
			pin: workerForm.pin || "1234",
			locationType: workerForm.locationType,
			attendanceMode: workerForm.attendanceMode,
			customFields: customFields.filter((f) => f.label.trim() !== "")
		});
		setShowWorkerModal(false);
		setEditingWorkerId(null);
		loadAttendanceData();
		toast.success(editingWorkerId ? "Employee details updated successfully!" : "Employee registered successfully!");
	};
	const handleDeleteWorker = (workerId, name) => {
		if (confirm(`Are you sure you want to delete employee '${name}'?`)) {
			dataStore.deleteEmployerWorker(workerId);
			loadAttendanceData();
			toast.success("Employee removed successfully!");
		}
	};
	const loadAllData = () => {
		if (isSuperAdmin) {
			setJobs(dataStore.getAllJobs());
			setApplications(dataStore.getAllApplications());
		} else {
			setJobs(dataStore.getEmployerJobs(empIdentifier));
			setApplications(dataStore.getEmployerApplications(empIdentifier));
		}
		const reg = dataStore.getRegisteredUsers();
		setRegisteredUsers(reg.map((u) => ({
			id: u.id,
			name: u.fullName,
			role: u.role,
			mobile: u.mobile || "N/A",
			city: "Maharashtra",
			trade: u.role === "worker" ? "Worker" : u.role === "employer" ? "Employer" : "Admin",
			status: "Verified",
			createdAt: u.createdAt || void 0
		})));
		refreshCredits();
	};
	(0, import_react.useEffect)(() => {
		loadAllData();
	}, [empIdentifier]);
	const [replyInputs, setReplyInputs] = (0, import_react.useState)({});
	const handleUpdateAppStatus = (appId, status) => {
		dataStore.updateApplicationStatus(appId, status);
		loadAllData();
		toast.success(`Application status updated to '${status}'! Candidate can view this on their dashboard.`);
	};
	const handleSaveReply = (appId, replyText) => {
		if (!replyText || !replyText.trim()) {
			toast.error("Please enter a reply or note for the candidate");
			return;
		}
		dataStore.updateApplicationReply(appId, replyText.trim());
		loadAllData();
		toast.success("Reply saved & sent to candidate! They can now view it on their dashboard.");
	};
	const [showJobForm, setShowJobForm] = (0, import_react.useState)(false);
	const [editingJobId, setEditingJobId] = (0, import_react.useState)(null);
	const [jobForm, setJobForm] = (0, import_react.useState)({
		title: "",
		company: "REAL JOB Platform",
		category: "",
		subcategory: "",
		location: "",
		salary: "",
		salaryMin: "",
		salaryMax: "",
		salaryType: "Monthly",
		showSalary: true,
		jobType: "Full Time",
		workMode: "On-site",
		vacancies: "5",
		education: "",
		experience: "",
		skills: "",
		description: "",
		responsibilities: "",
		benefits: "",
		status: "Active"
	});
	const setJ = (k, v) => setJobForm((p) => ({
		...p,
		[k]: v
	}));
	const handleAddNewJobClick = () => {
		const credits = currentUser?.id ? dataStore.getUserJobCredits(currentUser.id) : 0;
		if (!isSuperAdmin && credits <= 0) {
			toast.info("Please select a Job Package to post new jobs.");
			setShowPackageModal(true);
			return;
		}
		setEditingJobId(null);
		setJobForm({
			title: "",
			company: currentUser?.fullName || "REAL JOB Platform",
			category: "",
			subcategory: "",
			location: "",
			salary: "",
			salaryMin: "",
			salaryMax: "",
			salaryType: "Monthly",
			showSalary: true,
			jobType: "Full Time",
			workMode: "On-site",
			vacancies: "5",
			education: "",
			experience: "",
			skills: "",
			description: "",
			responsibilities: "",
			benefits: "",
			status: "Active"
		});
		setShowJobForm(true);
	};
	const activeJobPackages = dataStore.getJobPackages();
	const handleActivatePackage = () => {
		if (!currentUser) {
			toast.error("User session expired. Please login again.");
			return;
		}
		const selectedPlan = activeJobPackages.find((p) => p.id === selectedPlanId) || activeJobPackages[0];
		const userId = currentUser.id || currentUser.email || "admin-001";
		setIsProcessingPackage(true);
		setTimeout(() => {
			dataStore.addPackagePurchase({
				userId,
				userEmail: currentUser.email || "",
				userName: currentUser.fullName || currentUser.email || "Employer",
				companyName: currentUser.companyName || currentUser.fullName || "Employer",
				planId: selectedPlan.id,
				planName: selectedPlan.name,
				price: selectedPlan.price,
				jobCount: selectedPlan.jobCount,
				workerCount: selectedPlan.workerCount || 3,
				paymentMethod: paymentMethod.toUpperCase()
			});
			setIsProcessingPackage(false);
			setShowPackageModal(false);
			refreshCredits();
			toast.success(`🎉 ${selectedPlan.name} activated! You now have ${selectedPlan.jobCount} Job Credits.`);
			setEditingJobId(null);
			setJobForm({
				title: "",
				company: currentUser?.fullName || "REAL JOB Platform",
				category: "",
				subcategory: "",
				location: "",
				salary: "",
				salaryMin: "",
				salaryMax: "",
				salaryType: "Monthly",
				showSalary: true,
				jobType: "Full Time",
				workMode: "On-site",
				vacancies: "5",
				education: "",
				experience: "",
				skills: "",
				description: "",
				responsibilities: "",
				benefits: "",
				status: "Active"
			});
			setShowJobForm(true);
		}, 1e3);
	};
	const handleEditJobClick = (job) => {
		setEditingJobId(job.id);
		let sMin = job.salaryMin ? String(job.salaryMin) : "";
		let sMax = job.salaryMax ? String(job.salaryMax) : "";
		if (!sMin && !sMax && job.salary) {
			const numbers = job.salary.match(/\d[\d,]*/g);
			if (numbers && numbers.length >= 2 && numbers[0] && numbers[1]) {
				sMin = numbers[0].replace(/,/g, "");
				sMax = numbers[1].replace(/,/g, "");
			}
		}
		setJobForm({
			title: job.title || "",
			company: job.company || "",
			category: job.category || "",
			subcategory: job.subcategory || "",
			location: job.location || "",
			salary: job.salary || (sMin && sMax ? `₹${sMin} - ₹${sMax}` : sMin ? `₹${sMin}` : ""),
			salaryMin: sMin,
			salaryMax: sMax,
			salaryType: job.salaryType || "Monthly",
			showSalary: job.showSalary !== false && !job.hideSalary,
			jobType: job.jobType || "Full Time",
			workMode: job.workMode || "On-site",
			vacancies: job.vacancies ? String(job.vacancies) : "5",
			education: job.qualification || "",
			experience: job.experience || "",
			skills: (job.requiredSkills || []).join(", "),
			description: job.description || "",
			responsibilities: (job.responsibilities || []).join("\n"),
			benefits: (job.benefits || []).join(", "),
			status: job.status || "Active"
		});
		setShowJobForm(true);
	};
	const handlePublishJob = (e) => {
		e.preventDefault();
		const salaryText = jobForm.salaryMin && jobForm.salaryMax ? `₹${Number(jobForm.salaryMin).toLocaleString("en-IN")} - ₹${Number(jobForm.salaryMax).toLocaleString("en-IN")}` : jobForm.salaryMin ? `₹${Number(jobForm.salaryMin).toLocaleString("en-IN")}` : "Salary on Interview";
		const parsedMin = Number(jobForm.salaryMin) || 0;
		const parsedMax = Number(jobForm.salaryMax) || parsedMin;
		const isShowSalary = jobForm.showSalary !== false;
		if (editingJobId) {
			dataStore.updateJob(editingJobId, {
				title: jobForm.title,
				company: jobForm.company || currentUser?.fullName || "Company",
				category: jobForm.category || "General",
				subcategory: jobForm.subcategory || "",
				description: jobForm.description,
				qualification: jobForm.education,
				experience: jobForm.experience,
				salary: salaryText,
				salaryMin: parsedMin,
				salaryMax: parsedMax,
				salaryType: "Monthly",
				showSalary: isShowSalary,
				hideSalary: !isShowSalary,
				location: jobForm.location,
				jobType: jobForm.jobType,
				workMode: jobForm.workMode,
				vacancies: Number(jobForm.vacancies) || 1,
				status: jobForm.status
			});
			toast.success("✅ Job posting updated successfully!");
		} else {
			const empId = currentUser?.email || currentUser?.fullName || currentUser?.id || "admin-001";
			const compName = jobForm.company || currentUser?.fullName || "Company";
			dataStore.createJob({
				employerId: empId,
				title: jobForm.title,
				company: compName,
				category: jobForm.category || "General",
				subcategory: jobForm.subcategory || "",
				description: jobForm.description,
				responsibilities: [],
				requiredSkills: [],
				qualification: jobForm.education,
				experience: jobForm.experience,
				salary: salaryText,
				salaryMin: parsedMin,
				salaryMax: parsedMax,
				salaryType: "Monthly",
				showSalary: isShowSalary,
				hideSalary: !isShowSalary,
				location: jobForm.location,
				jobType: jobForm.jobType,
				workMode: jobForm.workMode,
				vacancies: Number(jobForm.vacancies) || 1,
				benefits: [],
				status: jobForm.status,
				approvalStatus: "pending"
			});
			if (!isSuperAdmin && currentUser?.id) {
				dataStore.consumeJobCredit(currentUser.id);
				refreshCredits();
			}
			toast.success("🎉 New job posted successfully!");
		}
		setShowJobForm(false);
		setEditingJobId(null);
		loadAllData();
	};
	const handleToggleJobStatus = (jobId, currentStatus) => {
		const nextStatus = currentStatus === "Active" ? "Closed" : "Active";
		dataStore.updateJob(jobId, { status: nextStatus });
		loadAllData();
		toast.success(`Job status updated to ${nextStatus}!`);
	};
	const handleDeleteJob = (jobId) => {
		dataStore.deleteJob(jobId);
		loadAllData();
		toast.success("Job posting removed!");
	};
	const filteredJobs = jobs.filter((j) => j.title.toLowerCase().includes(jobSearch.toLowerCase()) || j.company.toLowerCase().includes(jobSearch.toLowerCase()) || j.location.toLowerCase().includes(jobSearch.toLowerCase()));
	const totalJobPages = Math.max(1, Math.ceil(filteredJobs.length / JOBS_PER_PAGE));
	const pagedJobs = filteredJobs.slice((jobsPage - 1) * JOBS_PER_PAGE, jobsPage * JOBS_PER_PAGE);
	const activeSelectedPlan = activeJobPackages.find((p) => p.id === selectedPlanId) || activeJobPackages[0];
	if (!currentUser || currentUser.role !== "employer" && currentUser.role !== "admin") return null;
	if (showJobForm) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 bg-[#F0F4FA] overflow-y-auto flex flex-col font-sans",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bg-[#021D3D] text-white px-6 py-4 flex items-center justify-between border-b border-[#0A4F9E] sticky top-0 z-10 shadow-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setShowJobForm(false),
					className: "px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-bold transition-all flex items-center gap-1",
					children: " Back to Dashboard"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-base font-black text-white",
					children: editingJobId ? "फार्मिंग" : "💼 Post New Job"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-bold text-[#FFC400] bg-white/10 px-3 py-1 rounded-full",
				children: "Direct Hiring (Zero Commission)"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "max-w-5xl w-full mx-auto p-4 sm:p-8 flex-1",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handlePublishJob,
				className: "space-y-6 pb-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm overflow-hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 px-5 py-3 bg-[#F8FAFF] border-b border-[#E0E8F5]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "size-7 rounded-xl bg-[#063B78] text-white flex items-center justify-center text-xs font-black",
								children: "1"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-black text-[#10233F]",
								children: t("basicJobDetails")
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-5 grid grid-cols-1 md:grid-cols-2 gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-[#5B6B7F] mb-1",
									children: t("jobTitleRequired")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									required: true,
									value: jobForm.title,
									onChange: (e) => setJ("title", e.target.value),
									placeholder: t("jobTitlePlaceholder"),
									className: "text-xs font-semibold"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-[#5B6B7F] mb-1",
									children: t("companyNameRequired")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									required: true,
									value: jobForm.company,
									onChange: (e) => setJ("company", e.target.value),
									placeholder: t("companyNamePlaceholder"),
									className: "text-xs font-semibold"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between mb-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-xs font-bold text-[#5B6B7F]",
											children: t("categoryRequired")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-[#125BB5] font-bold",
											children: t("pickExistingOrTypeNew")
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										list: "admin-category-suggestions",
										required: true,
										value: jobForm.category,
										onChange: (e) => setJ("category", e.target.value),
										placeholder: t("categoryPlaceholder"),
										className: "text-xs font-semibold"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
										id: "admin-category-suggestions",
										children: dataStore.getExistingJobCategories().map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: cat }, cat))
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-[#5B6B7F] mb-1",
									children: t("locationRequired")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									required: true,
									value: jobForm.location,
									onChange: (e) => setJ("location", e.target.value),
									placeholder: t("locationPlaceholder"),
									className: "text-xs font-semibold"
								})] })
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm overflow-hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 px-5 py-3 bg-[#F8FAFF] border-b border-[#E0E8F5]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "size-7 rounded-xl bg-[#063B78] text-white flex items-center justify-center text-xs font-black",
								children: "2"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-black text-[#10233F]",
								children: t("salaryAndWorkMode")
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-5 grid grid-cols-1 md:grid-cols-2 gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-[#5B6B7F] mb-1",
									children: t("minSalaryLabel")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "text",
									inputMode: "numeric",
									required: true,
									value: jobForm.salaryMin,
									onChange: (e) => setJ("salaryMin", e.target.value.replace(/\D/g, "")),
									placeholder: "e.g. 25000",
									className: "text-xs font-semibold"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-[#5B6B7F] mb-1",
									children: t("maxSalaryLabel")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "text",
									inputMode: "numeric",
									required: true,
									value: jobForm.salaryMax,
									onChange: (e) => setJ("salaryMax", e.target.value.replace(/\D/g, "")),
									placeholder: "e.g. 45000",
									className: "text-xs font-semibold"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "md:col-span-2 bg-[#F8FAFF] p-4 rounded-xl border border-[#DCE5F0] transition-all",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-xs font-black text-[#10233F]",
											children: "Show Salary to Job Seekers? *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] font-semibold text-[#5B6B7F] mt-0.5",
											children: jobForm.showSalary ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-emerald-700 font-bold",
												children: ["✅ 'Yes' selected — Salary will be visible to job seekers ", jobForm.salaryMin ? `(e.g. ₹${Number(jobForm.salaryMin).toLocaleString("en-IN")}${jobForm.salaryMax ? ` - ₹${Number(jobForm.salaryMax).toLocaleString("en-IN")}` : ""})` : ""]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-rose-700 font-bold",
												children: "🔒 'No' selected — Salary will be hidden from job seekers ('Not Disclosed' will be shown)."
											})
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 shrink-0 bg-white p-1 rounded-xl border border-[#DCE5F0] shadow-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setJ("showSalary", true),
												className: `px-4 py-2 rounded-lg text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${jobForm.showSalary ? "bg-emerald-600 text-white shadow-sm" : "text-[#5B6B7F] hover:bg-gray-100"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-sm",
													children: "✓"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("yesShowSalary") })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setJ("showSalary", false),
												className: `px-4 py-2 rounded-lg text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${!jobForm.showSalary ? "bg-rose-600 text-white shadow-sm" : "text-[#5B6B7F] hover:bg-gray-100"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-sm",
													children: "✕"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("noHideSalary") })]
											})]
										})]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-[#5B6B7F] mb-1",
									children: t("jobType")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: jobForm.jobType,
									onChange: (e) => setJ("jobType", e.target.value),
									className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Full Time",
											children: t("fullTimeJob")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Part Time",
											children: t("partTimeJob")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Contract",
											children: t("contractJob")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Internship",
											children: t("internshipJob")
										})
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-[#5B6B7F] mb-1",
									children: t("workMode")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: jobForm.workMode,
									onChange: (e) => setJ("workMode", e.target.value),
									className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "On-site",
											children: t("onSiteMode")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Work From Home",
											children: t("workFromHomeMode")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Hybrid",
											children: t("hybridMode")
										})
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-[#5B6B7F] mb-1",
									children: t("vacancies")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "text",
									inputMode: "numeric",
									value: jobForm.vacancies,
									onChange: (e) => setJ("vacancies", e.target.value.replace(/\D/g, "")),
									placeholder: "5",
									className: "text-xs font-semibold"
								})] })
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm overflow-hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 px-5 py-3 bg-[#F8FAFF] border-b border-[#E0E8F5]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "size-7 rounded-xl bg-[#063B78] text-white flex items-center justify-center text-xs font-black",
								children: "3"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-black text-[#10233F]",
								children: t("jobDescriptionAndRequirements")
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-5 space-y-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-bold text-[#5B6B7F] mb-1",
								children: t("jobDescriptionRequired")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								required: true,
								rows: 4,
								value: jobForm.description,
								onChange: (e) => setJ("description", e.target.value),
								placeholder: t("jobDescriptionPlaceholder"),
								className: "w-full p-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-[#5B6B7F] mb-1",
									children: t("requiredQualificationLabel")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: jobForm.education,
									onChange: (e) => setJ("education", e.target.value),
									placeholder: t("qualificationPlaceholder"),
									className: "text-xs font-semibold"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-[#5B6B7F] mb-1",
									children: t("requiredExperienceLabel")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: jobForm.experience,
									onChange: (e) => setJ("experience", e.target.value),
									placeholder: t("experiencePlaceholder"),
									className: "text-xs font-semibold"
								})] })]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white rounded-2xl border border-[#E0E8F5] px-6 py-4 flex items-center justify-between sticky bottom-0 shadow-lg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[10px] text-[#9DAEC5] font-semibold",
							children: ["*", t("requiredFieldsNote")]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setShowJobForm(false),
								className: "px-5 py-2.5 rounded-xl border border-[#DCE5F0] text-xs font-bold text-[#5B6B7F] hover:bg-[#F5F8FC] transition-all",
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: "px-7 py-2.5 rounded-xl bg-gradient-to-r from-[#063B78] to-[#0A4F9E] text-white font-black text-xs hover:opacity-90 transition-all shadow-md shadow-[#063B78]/20 flex items-center gap-1.5",
								children: editingJobId ? "✨ Update Job Posting" : "✨ Publish Job"
							})]
						})]
					})
				]
			})
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "h-screen bg-[#F0F4FA] flex flex-col md:flex-row font-sans w-full overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "md:hidden bg-[#021D3D] text-white px-4 py-3 sticky top-0 z-40 flex items-center justify-between shadow-md border-b border-white/10 shrink-0 w-full",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 min-w-0 pr-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-9 bg-gradient-to-br from-[#FFC400] to-[#FFA500] rounded-xl flex items-center justify-center shadow-md border border-white/10 shrink-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-5 text-[#021D3D]" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							suppressHydrationWarning: true,
							className: "font-black text-xs text-white truncate leading-tight",
							children: currentUser?.fullName || t("employerPortal")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] text-[#FFC400] font-black uppercase block tracking-wider leading-tight mt-0.5",
							children: t("employerPortal")
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setIsMobileMenuOpen(!isMobileMenuOpen),
					className: "p-2 rounded-xl bg-white/10 text-white hover:bg-white/20 transition-all cursor-pointer shrink-0 ml-1",
					"aria-label": "Toggle menu",
					children: isMobileMenuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
				})]
			}),
			isMobileMenuOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-50 md:hidden flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity",
					onClick: () => setIsMobileMenuOpen(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "relative w-4/5 max-w-xs bg-[#021D3D] text-white flex flex-col justify-between h-full p-5 shadow-2xl z-10 overflow-y-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between pb-4 border-b border-white/10 mb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-10 bg-gradient-to-br from-[#FFC400] to-[#FFA500] rounded-xl flex items-center justify-center font-black text-[#021D3D] shrink-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									suppressHydrationWarning: true,
									className: "font-black text-sm text-white truncate",
									children: currentUser?.fullName || "Employer"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-[#FFC400] font-bold",
									children: t("verifiedEmployer")
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setIsMobileMenuOpen(false),
							className: "p-1.5 rounded-lg text-white/60 hover:text-white hover:bg-white/10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "space-y-1.5",
						children: [
							{
								id: "overview",
								label: t("dashboardOverview"),
								icon: ChartColumn
							},
							{
								id: "jobs",
								label: t("jobListings"),
								icon: BriefcaseBusiness,
								count: jobs.length
							},
							{
								id: "applications",
								label: t("jobApplications"),
								icon: FileText,
								count: applications.length
							},
							{
								id: "attendance",
								label: t("attendancePayroll"),
								icon: CalendarCheck,
								count: workers.length
							},
							{
								id: "salary",
								label: t("eSalarySlips"),
								icon: FileText
							},
							{
								id: "packages",
								label: t("myPackagesBilling"),
								icon: IndianRupee
							},
							{
								id: "profile",
								label: t("myProfile"),
								icon: User
							}
						].map((item) => {
							const isActive = activeTab === item.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => {
									setActiveTab(item.id);
									setIsMobileMenuOpen(false);
								},
								className: `w-full flex items-center justify-between px-4 py-3 rounded-xl text-xs font-bold transition-all ${isActive ? "bg-[#FFC400] text-[#021D3D] font-extrabold shadow-md" : "text-white/70 hover:bg-white/5 hover:text-white"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3 min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: `size-4 ${isActive ? "text-[#021D3D]" : "text-white/60"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate",
										children: item.label
									})]
								}), item.count !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `px-2 py-0.5 text-[10px] font-black rounded-full ${isActive ? "bg-[#021D3D] text-[#FFC400]" : "bg-amber-500/20 text-amber-300 border border-amber-400/30"}`,
									children: item.count
								})]
							}, item.id);
						})
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pt-4 border-t border-white/10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								setIsMobileMenuOpen(false);
								dataStore.logout("employer");
								localStorage.removeItem("realjob-employer-profile");
								localStorage.removeItem("realjob-user-admin");
								localStorage.removeItem("realjob-user-employer");
								localStorage.removeItem("realjob-user");
								localStorage.removeItem("realjob-role");
								sessionStorage.removeItem("realjob_tab_user");
								toast.info("Logged out successfully");
								navigate({
									to: "/auth",
									search: {
										mode: "login",
										role: "admin"
									},
									replace: true
								});
								if (typeof window !== "undefined") window.scrollTo(0, 0);
							},
							className: "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold text-rose-400 hover:bg-rose-500/10 transition-colors",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("signOut") })]
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "w-64 bg-[#021D3D] text-white flex flex-col justify-between hidden md:flex h-full shrink-0 border-r border-white/10 overflow-y-auto",
				style: { scrollbarWidth: "none" },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-5 border-b border-white/10 shrink-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 text-white",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-10 bg-gradient-to-br from-[#FFC400] to-[#FFA500] rounded-xl flex items-center justify-center shadow-lg border-[2px] border-white/10 shrink-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-5 text-[#021D3D]" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									suppressHydrationWarning: true,
									className: "font-black text-sm leading-tight tracking-tight uppercase truncate text-white",
									title: currentUser?.fullName || t("employerPortal"),
									children: currentUser?.fullName || t("employerPortal")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] text-[#FFC400] font-black uppercase tracking-widest block",
									children: t("employerPortal")
								})]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 py-4 px-3 space-y-1 overflow-y-auto",
						style: { scrollbarWidth: "none" },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[10px] font-black uppercase text-[#9DAEC5] tracking-widest px-3 mb-2",
							children: t("mainNavigation")
						}), [
							{
								id: "overview",
								label: t("dashboardOverview"),
								icon: ChartColumn
							},
							{
								id: "jobs",
								label: t("jobListings"),
								icon: BriefcaseBusiness,
								count: jobs.length
							},
							{
								id: "applications",
								label: t("jobApplications"),
								icon: FileText,
								count: applications.length
							},
							{
								id: "attendance",
								label: t("attendancePayroll"),
								icon: CalendarCheck,
								count: workers.length
							},
							{
								id: "salary",
								label: t("eSalarySlips"),
								icon: FileText
							},
							{
								id: "packages",
								label: t("myPackagesBilling"),
								icon: IndianRupee
							},
							{
								id: "profile",
								label: t("myProfile"),
								icon: User
							}
						].map((item) => {
							const isActive = activeTab === item.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setActiveTab(item.id),
								className: `w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all duration-200 ${isActive ? "bg-[#FFC400] text-[#021D3D] shadow-md shadow-[#FFC400]/20 font-extrabold" : "text-[#9DAEC5] hover:bg-white/5 hover:text-white"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2.5 min-w-0 flex-1 pr-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: `size-4 shrink-0 ${isActive ? "text-[#021D3D]" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate text-left",
										children: item.label
									})]
								}), item.count !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `px-2 py-0.5 text-[10px] font-black rounded-full shrink-0 ${isActive ? "bg-[#021D3D] text-[#FFC400]" : "bg-amber-500/20 text-amber-300 border border-amber-400/30"}`,
									children: item.count
								}) : null]
							}, item.id);
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-4 border-t border-white/10 shrink-0 mt-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								dataStore.logout("employer");
								localStorage.removeItem("realjob-employer-profile");
								localStorage.removeItem("realjob-user-admin");
								localStorage.removeItem("realjob-user-employer");
								localStorage.removeItem("realjob-user");
								localStorage.removeItem("realjob-role");
								sessionStorage.removeItem("realjob_tab_user");
								toast.info("Logged out successfully");
								navigate({
									to: "/auth",
									search: {
										mode: "login",
										role: "admin"
									},
									replace: true
								});
								if (typeof window !== "undefined") window.scrollTo(0, 0);
							},
							className: "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold text-rose-400 hover:bg-rose-500/10 transition-all",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("signOut") })]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 flex flex-col h-full min-w-0 overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "h-16 sm:h-20 bg-white border-b border-[#E0E8F5] flex items-center justify-between px-3 sm:px-8 shrink-0 z-30 shadow-2xs min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-2 sm:gap-4 min-w-0 flex-1 mr-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "text-sm sm:text-xl font-black text-[#063B78] truncate leading-tight",
							children: [
								activeTab === "overview" && t("dashboardOverview"),
								activeTab === "jobs" && t("jobListings"),
								activeTab === "applications" && t("jobApplications"),
								activeTab === "attendance" && t("attendancePayroll"),
								activeTab === "packages" && t("myPackagesBilling"),
								activeTab === "profile" && t("myProfile"),
								activeTab === "salary" && t("employeeSalarySlipsTitle")
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 sm:gap-4 shrink-0",
						children: [!isSuperAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hidden sm:flex items-center gap-2 bg-amber-50 border border-amber-200 px-3 py-1.5 rounded-xl text-xs font-black text-amber-800 shrink-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-4 fill-amber-400 text-amber-500" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									t("creditsLabel"),
									" ",
									userCredits >= 999 ? t("unlimitedLabel") : userCredits
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setShowPackageModal(true),
									className: "ml-1 bg-amber-400 hover:bg-amber-500 text-[#063B78] px-2 py-0.5 rounded text-[10px] font-black transition-all cursor-pointer",
									children: t("addCreditsBtn")
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 sm:gap-3 pl-2 sm:pl-4 border-l border-[#E0E8F5] shrink-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right hidden sm:block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									suppressHydrationWarning: true,
									className: "text-sm font-bold text-[#063B78]",
									children: currentUser?.fullName || t("employerAccount")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[10px] font-bold text-amber-600 flex items-center justify-end gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3" }),
										" ",
										t("verifiedEmployer")
									]
								})]
							}), currentUser?.profilePhoto ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: currentUser.profilePhoto,
								alt: currentUser.fullName || "Employer",
								className: "size-8 sm:size-10 rounded-xl object-cover shadow-sm border-b-[2px] border-[#021D3D]"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-8 sm:size-10 bg-gradient-to-br from-[#063B78] to-[#0A4F9E] rounded-xl flex items-center justify-center text-white font-black text-xs sm:text-base shadow-sm border-b-[2px] border-[#021D3D]",
								children: (currentUser?.fullName || "E").charAt(0).toUpperCase()
							})]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto overflow-x-hidden min-w-0 max-w-full pb-20 md:pb-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: activeTab === "overview" ? "block" : "hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-6",
								children: [
									(() => {
										const userId = currentUser?.id || currentUser?.email || empIdentifier;
										const userPkgs = dataStore.getUserPackages(userId);
										const workerLimit = dataStore.getUserWorkerCredits(userId);
										const jobCredits = dataStore.getUserJobCredits(userId);
										const latestPkg = userPkgs.length > 0 ? userPkgs[0] : null;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-gradient-to-r from-[#021D3D] via-[#063B78] to-[#0A4F9E] rounded-2xl sm:rounded-3xl p-4 sm:p-6 text-white shadow-xl border border-amber-400/20 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 sm:gap-6 relative overflow-hidden",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute right-0 top-0 translate-x-8 -translate-y-8 size-48 bg-amber-400/10 rounded-full blur-2xl pointer-events-none" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "space-y-2.5 z-10 w-full md:w-auto",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center gap-2 flex-wrap",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-[11px] sm:text-xs font-black bg-gradient-to-r from-amber-400 to-yellow-300 text-[#021D3D] px-2.5 sm:px-3 py-1 rounded-full uppercase tracking-wider shadow-md",
																children: latestPkg ? `${t("activePlan")}: ${latestPkg.planName}` : t("noActivePackage")
															}), latestPkg && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "text-[10px] sm:text-xs font-bold text-amber-200 bg-white/10 px-2.5 py-0.5 rounded-full border border-white/15",
																children: [
																	"Purchased for ₹",
																	n(latestPkg.price),
																	" on ",
																	latestPkg.purchaseDate
																]
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
															className: "text-lg sm:text-xl font-black tracking-tight text-white leading-snug",
															children: latestPkg ? `${t("yourPackageIsActive").replace("Package", latestPkg.planName)}` : t("purchasePackageToStart")
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex flex-col sm:flex-row items-stretch sm:items-center gap-2 sm:gap-4 text-xs text-slate-200 font-semibold pt-1",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "flex items-center justify-between sm:justify-start gap-1.5 bg-white/10 px-3 py-2 rounded-xl border border-white/15",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
																	"💼 ",
																	t("jobPostCredits"),
																	":"
																] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
																	className: "text-amber-300 text-xs sm:text-sm",
																	children: [
																		n(jobCredits),
																		" ",
																		t("availableLabel")
																	]
																})]
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "flex items-center justify-between sm:justify-start gap-1.5 bg-white/10 px-3 py-2 rounded-xl border border-white/15",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
																	"👥 ",
																	t("employeeAdditionLimit"),
																	":"
																] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
																	className: "text-emerald-300 text-xs sm:text-sm",
																	children: workerLimit === 0 ? "0" : workerLimit >= 9999 ? t("unlimitedLabel") : `${n(workers.length)} / ${n(workerLimit)} ${t("addedLabel")}`
																})]
															})]
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "z-10 flex flex-col sm:flex-row items-center gap-2.5 sm:gap-3 shrink-0 w-full md:w-auto pt-2 sm:pt-0",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														onClick: () => setShowPackageModal(true),
														className: "w-full md:w-auto bg-gradient-to-r from-[#FFC400] to-[#FFA500] hover:from-[#FFA500] hover:to-[#FFC400] text-[#021D3D] font-black text-xs px-5 py-3 rounded-xl sm:rounded-2xl shadow-lg border-b-[3px] border-amber-600 transition-all active:scale-95 justify-center",
														children: userPkgs.length > 0 ? t("upgradePackageBtn") : t("buyPackageNowBtn")
													}), userPkgs.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														variant: "outline",
														onClick: () => setActiveTab("packages"),
														className: "w-full md:w-auto bg-white/10 hover:bg-white/20 text-white font-bold text-xs px-4 py-3 rounded-xl sm:rounded-2xl border-white/20 justify-center",
														children: t("viewBillingHistory")
													})]
												})
											]
										});
									})(),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												onClick: () => setActiveTab("jobs"),
												className: "bg-white p-5 rounded-2xl border border-[#DCE5F0] shadow-sm hover:shadow-md hover:border-[#063B78] transition-all cursor-pointer group flex flex-col justify-between",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center justify-between mb-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-xs font-black text-[#5B6B7F] uppercase tracking-wider",
															children: t("totalPostedJobs")
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "size-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-black group-hover:bg-[#063B78] group-hover:text-white transition-colors shrink-0",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BriefcaseBusiness, { className: "size-5" })
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-3xl font-black text-[#063B78] mb-2",
														children: n(jobs.length)
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "pt-2 border-t border-[#F0F4FA] text-xs",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "inline-block font-extrabold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md",
															children: [
																n(jobs.filter((j) => j.status === "Active").length),
																" ",
																t("activeJobsLabel")
															]
														})
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												onClick: () => setActiveTab("applications"),
												className: "bg-white p-5 rounded-2xl border border-[#DCE5F0] shadow-sm hover:shadow-md hover:border-[#063B78] transition-all cursor-pointer group flex flex-col justify-between",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center justify-between mb-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-xs font-black text-[#5B6B7F] uppercase tracking-wider",
															children: t("totalApplications")
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "size-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-black group-hover:bg-[#063B78] group-hover:text-white transition-colors shrink-0",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-5" })
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-3xl font-black text-[#063B78] mb-2",
														children: n(applications.length)
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "pt-2 border-t border-[#F0F4FA] text-xs",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "inline-block font-extrabold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-md",
															children: [
																n(new Set(applications.map((a) => a.jobSeekerId || a.candidateEmail)).size),
																" ",
																t("applicantsLabel")
															]
														})
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												onClick: () => setActiveTab("attendance"),
												className: "bg-white p-5 rounded-2xl border border-[#DCE5F0] shadow-sm hover:shadow-md hover:border-[#063B78] transition-all cursor-pointer group flex flex-col justify-between",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center justify-between mb-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-xs font-black text-[#5B6B7F] uppercase tracking-wider",
															children: t("totalEmployeesLabel")
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "size-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-black group-hover:bg-[#063B78] group-hover:text-white transition-colors shrink-0",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5" })
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-3xl font-black text-[#063B78] mb-2",
														children: n(workers.length)
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "pt-2 border-t border-[#F0F4FA] text-xs",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "inline-block font-extrabold text-purple-700 bg-purple-50 px-2.5 py-1 rounded-md",
															children: t("registeredStaff")
														})
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												onClick: () => setActiveTab("attendance"),
												className: "bg-white p-5 rounded-2xl border border-[#DCE5F0] shadow-sm hover:shadow-md hover:border-[#063B78] transition-all cursor-pointer group flex flex-col justify-between",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center justify-between mb-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-xs font-black text-[#5B6B7F] uppercase tracking-wider",
															children: t("presentToday")
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "size-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center font-black group-hover:bg-[#063B78] group-hover:text-white transition-colors shrink-0",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarCheck, { className: "size-5" })
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "text-3xl font-black text-[#063B78] mb-2",
														children: [
															n(dailyAttendanceRecords.filter((r) => r.status === "Present" || r.status === "Overtime" || r.status === "HalfDay").length),
															" / ",
															n(workers.length)
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "pt-2 border-t border-[#F0F4FA] text-xs",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "inline-block font-extrabold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-md",
															children: t("attendanceShift")
														})
													})
												]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-2xl border border-[#DCE5F0] bg-white p-6 shadow-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between mb-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
												className: "text-lg font-black text-[#10233F]",
												children: ["📥 ", t("recentCandidatesTitle")]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-semibold text-[#5B6B7F] mt-0.5",
												children: t("recentCandidatesDesc")
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												onClick: () => setActiveTab("applications"),
												className: "bg-[#063B78] text-white font-black text-xs hover:bg-[#0A4F9E]",
												children: [t("viewAllBtn"), " →"]
											})]
										}), applications.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "py-8 text-center border-2 border-dashed border-[#E0E8F5] rounded-xl bg-[#F8FAFF]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-8 text-[#A0AEC0] mx-auto mb-2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-bold text-[#10233F]",
												children: t("noApplicationsFound")
											})]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "space-y-2.5 max-h-[320px] overflow-y-auto pr-1",
											children: applications.slice(0, 5).map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												onClick: () => setActiveTab("applications"),
												className: "p-3.5 rounded-xl border border-[#E2E8F0] bg-[#F8FAFF] hover:bg-[#F0F4FA] transition-all cursor-pointer flex items-center justify-between gap-3",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "size-10 rounded-full bg-[#063B78] text-white font-black text-sm flex items-center justify-center shrink-0",
														children: (app.candidateName || "C").charAt(0).toUpperCase()
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
														className: "text-xs font-black text-[#10233F]",
														children: app.candidateName
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "text-[11px] font-semibold text-[#5B6B7F]",
														children: [
															"💼 Applied for: ",
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "font-bold text-[#063B78]",
																children: app.jobTitle
															}),
															" | 📞 ",
															app.candidateMobile || "N/A"
														]
													})] })]
												})
											}, app.id))
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-2xl border border-[#DCE5F0] bg-white p-6 shadow-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between mb-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
												className: "text-lg font-black text-[#10233F]",
												children: ["👥 ", t("registeredStaffRegister")]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-semibold text-[#5B6B7F] mt-0.5",
												children: t("registeredStaffRegisterSub")
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												onClick: () => setActiveTab("attendance"),
												className: "bg-[#063B78] text-white font-black text-xs hover:bg-[#0A4F9E]",
												children: t("viewAllArrow")
											})]
										}), workers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "py-8 text-center border-2 border-dashed border-[#E0E8F5] rounded-xl bg-[#F8FAFF]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-8 text-[#A0AEC0] mx-auto mb-2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-bold text-[#10233F]",
												children: t("noEmployeesRegistered")
											})]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
											children: workers.slice(0, 3).map((worker) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												onClick: () => setActiveTab("attendance"),
												className: "p-4 rounded-xl border border-[#E2E8F0] bg-[#F8FAFF] hover:bg-[#F0F4FA] transition-all cursor-pointer flex flex-col justify-between",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center justify-between mb-1.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-xs font-black text-[#063B78]",
															children: worker.name
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full",
															children: [
																"₹",
																worker.dailyRate,
																t("dailyRateUnit")
															]
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "text-xs font-semibold text-[#5B6B7F]",
														children: [
															t("departmentLabel"),
															": ",
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "font-bold text-[#10233F]",
																children: formatCategoryName(worker.category || worker.trade)
															})
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "text-[11px] font-semibold text-[#5B6B7F]",
														children: [
															t("mobileLabel"),
															": ",
															worker.mobile || "N/A"
														]
													})
												] })
											}, worker.id))
										})]
									})
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: activeTab === "jobs" ? "block" : "hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 rounded-2xl border border-[#DCE5F0] shadow-sm space-y-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-xl font-black text-[#10233F]",
											children: t("allPlatformJobListings")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold text-[#5B6B7F]",
											children: t("manageJobListingsSub")
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												onClick: handleAddNewJobClick,
												className: "bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-md hover:shadow-lg transition-all w-full sm:w-auto shrink-0 cursor-pointer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("postNewJob") })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "w-full sm:w-72 relative",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-3 size-4 text-[#5B6B7F]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													placeholder: t("searchJobPlaceholder"),
													value: jobSearch,
													onChange: (e) => {
														setJobSearch(e.target.value);
														setJobsPage(1);
													},
													className: "pl-9 text-xs font-bold"
												})]
											})]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "overflow-x-auto rounded-xl border border-[#DCE5F0]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
											className: "w-full text-left text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
												className: "bg-[#063B78] text-white font-black uppercase",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-3.5",
														children: t("jobTitleTh")
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-3.5",
														children: t("companyTh")
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-3.5",
														children: t("locationSalaryTh")
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-3.5",
														children: t("vacanciesTh")
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-3.5",
														children: t("approvalTh")
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-3.5",
														children: t("statusTh")
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-3.5 text-right",
														children: t("actionsTh")
													})
												] })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
												className: "divide-y divide-[#DCE5F0] font-semibold text-[#10233F]",
												children: [pagedJobs.map((j) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
													className: "hover:bg-[#F5F8FC]",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
															className: "p-3.5",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
																className: "block font-black text-[#063B78]",
																children: j.title
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-[11px] text-[#5B6B7F]",
																children: j.category
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
															className: "p-3.5",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
																className: "block font-bold text-[#063B78]",
																children: j.company
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "text-[10px] text-indigo-700 font-bold block mt-0.5",
																children: ["👤 Posted by: ", j.employerId || j.company]
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
															className: "p-3.5",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: j.location }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "text-[#125BB5] font-bold flex items-center gap-1.5 flex-wrap",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: j.salary }), j.showSalary === false || j.hideSalary ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																	className: "text-[10px] bg-rose-50 text-rose-700 border border-rose-200 px-1.5 py-0.5 rounded font-black",
																	children: ["🔒 ", t("hiddenFromSeekers")]
																}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																	className: "text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200 px-1.5 py-0.5 rounded font-black",
																	children: ["👁️ ", t("visibleToSeekers")]
																})]
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
															className: "p-3.5 font-black text-[#063B78]",
															children: [
																j.vacancies || 5,
																" ",
																t("openingsLabel")
															]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "p-3.5",
															children: j.approvalStatus === "rejected" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
																className: "bg-red-600 text-white font-bold",
																children: t("rejectedStatusTh")
															}) : j.approvalStatus === "approved" || !j.approvalStatus ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
																className: "bg-emerald-600 text-white font-bold",
																children: ["✅ ", t("approvedStatus")]
															}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
																className: "bg-amber-500 text-white font-bold",
																children: ["⏳ ", t("pendingApprovalStatus")]
															})
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "p-3.5",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
																className: j.status === "Active" ? "bg-emerald-600 text-white font-bold" : "bg-gray-500 text-white font-bold",
																children: j.status === "Active" ? t("activeStatus") : t("inactiveStatus")
															})
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "p-3.5 text-right",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "flex items-center justify-end gap-2",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
																		size: "sm",
																		onClick: () => {
																			setFilterJobId(j.id);
																			setActiveTab("applications");
																		},
																		className: "bg-[#063B78] text-white font-extrabold text-[11px] hover:bg-[#0A4F9E]",
																		children: [
																			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-3.5 mr-1" }),
																			t("viewApplicationsCount"),
																			" (",
																			applications.filter((a) => a.jobId === j.id).length,
																			")"
																		]
																	}),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
																		size: "sm",
																		variant: "outline",
																		onClick: () => handleEditJobClick(j),
																		className: "font-extrabold text-[11px] border-[#063B78] text-[#063B78] hover:bg-[#F0F5FF]",
																		children: [
																			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquarePen, { className: "size-3.5 mr-1" }),
																			" ",
																			t("editBtn")
																		]
																	}),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
																		size: "sm",
																		variant: "outline",
																		onClick: () => handleToggleJobStatus(j.id, j.status),
																		className: "font-extrabold text-[11px] border-gray-400 text-gray-700",
																		children: j.status === "Active" ? "Close Job" : "Activate Job"
																	}),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
																		size: "sm",
																		variant: "ghost",
																		onClick: () => handleDeleteJob(j.id),
																		className: "text-red-600 hover:bg-red-50",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
																	})
																]
															})
														})
													]
												}, j.id)), filteredJobs.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													colSpan: 7,
													className: "p-8 text-center text-xs font-bold text-[#5B6B7F] bg-[#F8FAFF]",
													children: "No job listings posted yet."
												}) })]
											})]
										})
									}),
									totalJobPages > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between mt-4 pt-4 border-t border-[#DCE5F0]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs font-bold text-[#5B6B7F]",
											children: [
												"Showing ",
												(jobsPage - 1) * JOBS_PER_PAGE + 1,
												"—œ",
												Math.min(jobsPage * JOBS_PER_PAGE, filteredJobs.length),
												" of ",
												filteredJobs.length,
												" jobs"
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-1.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													disabled: jobsPage === 1,
													onClick: () => setJobsPage((p) => p - 1),
													className: "px-3 py-1.5 rounded-lg text-xs font-black border border-[#DCE5F0] bg-white text-[#063B78] hover:bg-[#EBF3FF] disabled:opacity-40 disabled:cursor-not-allowed transition-all",
													children: " Prev"
												}),
												Array.from({ length: totalJobPages }, (_, i) => i + 1).map((pg) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => setJobsPage(pg),
													className: `w-8 h-8 rounded-lg text-xs font-black transition-all ${pg === jobsPage ? "bg-[#063B78] text-white shadow-md" : "border border-[#DCE5F0] bg-white text-[#063B78] hover:bg-[#EBF3FF]"}`,
													children: pg
												}, pg)),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													disabled: jobsPage === totalJobPages,
													onClick: () => setJobsPage((p) => p + 1),
													className: "px-3 py-1.5 rounded-lg text-xs font-black border border-[#DCE5F0] bg-white text-[#063B78] hover:bg-[#EBF3FF] disabled:opacity-40 disabled:cursor-not-allowed transition-all",
													children: "Next →"
												})
											]
										})]
									})
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: activeTab === "applications" ? "block" : "hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 rounded-2xl border border-[#DCE5F0] shadow-sm space-y-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-xl font-black text-[#10233F]",
										children: t("jobApplicationsTitle")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold text-[#5B6B7F]",
										children: t("jobApplicationsSubtitle").replace("{count}", String(applications.length))
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-3 w-full sm:w-auto",
										children: [filterJobId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "outline",
											onClick: () => setFilterJobId(null),
											className: "text-xs font-bold border-[#063B78] text-[#063B78]",
											children: "✕ Show All Applications"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "w-full sm:w-64 relative",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-3 size-4 text-[#5B6B7F]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												placeholder: t("searchCandidatePlaceholder"),
												value: appSearch,
												onChange: (e) => setAppSearch(e.target.value),
												className: "pl-9 text-xs font-bold"
											})]
										})]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "overflow-x-auto rounded-xl border border-[#DCE5F0]",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
										className: "w-full text-left text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
											className: "bg-[#063B78] text-white font-black uppercase",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-3.5",
													children: t("candidateNameTh")
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-3.5",
													children: t("appliedForLabel")
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-3.5",
													children: t("contactLabel")
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-3.5",
													children: t("appliedDateCol")
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-3.5",
													children: t("statusTh")
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-3.5 text-right",
													children: t("actionsTh")
												})
											] })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
											className: "divide-y divide-[#DCE5F0] font-semibold text-[#10233F]",
											children: [applications.filter((a) => !filterJobId || a.jobId === filterJobId).filter((a) => a.candidateName.toLowerCase().includes(appSearch.toLowerCase()) || a.jobTitle.toLowerCase().includes(appSearch.toLowerCase()) || a.candidateMobile.toLowerCase().includes(appSearch.toLowerCase())).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
												className: "hover:bg-[#F5F8FC]",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
														className: "p-3.5 font-black text-[#063B78]",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: a.candidateName }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "text-[11px] text-[#5B6B7F] font-normal",
															children: a.candidateEmail
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
														className: "p-3.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "font-bold text-[#10233F]",
															children: a.jobTitle
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "text-[11px] text-[#125BB5]",
															children: [
																a.companyName || "Company",
																" • ",
																a.location
															]
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-3.5",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center gap-2",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
																href: `tel:${formatCallNumber(a.candidateMobile)}`,
																className: "px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold text-[10px] hover:bg-emerald-700 transition-all flex items-center gap-1",
																children: "📞 Call Candidate"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
																href: `https://wa.me/${formatWaNumber(a.candidateMobile)}?text=${encodeURIComponent(`Hello ${a.candidateName}, regarding your application for ${a.jobTitle}.`)}`,
																target: "_blank",
																rel: "noreferrer",
																className: "px-2.5 py-1 rounded-lg bg-green-600 text-white font-bold text-[10px] hover:bg-green-700 transition-all flex items-center gap-1",
																children: "💬 WhatsApp"
															})]
														})
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-3.5 text-[#5B6B7F] font-bold",
														children: a.appliedDate
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-3.5",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
															value: a.status,
															onChange: (e) => handleUpdateAppStatus(a.id, e.target.value),
															className: "h-8 px-2 rounded-lg border border-[#DCE5F0] text-xs font-black focus:outline-none focus:border-[#063B78]",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
																	value: "Applied",
																	children: [" ", t("applied")]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
																	value: "Viewed",
																	children: [" ", t("applicationViewed")]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
																	value: "Shortlisted",
																	children: ["⭐ ", t("statusShortlisted")]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
																	value: "Interview",
																	children: ["📅 ", t("interviewScheduled")]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
																	value: "Selected",
																	children: ["✅ ", t("selectedHired")]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
																	value: "Rejected",
																	children: [" ", t("rejected")]
																})
															]
														})
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-3.5 text-right",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
															variant: "outline",
															size: "sm",
															onClick: () => setExpandedApp(expandedApp === a.id ? null : a.id),
															className: "text-[10px] h-7 px-3 border-[#063B78] text-[#063B78] hover:bg-[#063B78] hover:text-white",
															children: expandedApp === a.id ? "Hide Details" : "View Details"
														})
													})
												]
											}), expandedApp === a.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
												className: "bg-[#F8FAFC]",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													colSpan: 6,
													className: "p-0 border-t border-[#DCE5F0]",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "p-3 md:p-4",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "sticky left-0 md:static w-[88vw] sm:w-[90vw] md:w-full bg-white p-4 md:p-5 rounded-xl border border-[#E2E8F0] shadow-sm",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
																	className: "font-bold text-[#10233F] mb-4 border-b pb-2 flex items-center gap-2",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4 text-[#063B78]" }), t("candidateApplicationDetails")]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4",
																	children: [
																		a.fieldValues && Object.entries(a.fieldValues).filter(([key, value]) => key.trim() !== "" && value !== null && value !== void 0 && value.toString().trim() !== "").map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																			className: "text-xs bg-[#F5F8FC] p-3 rounded-lg border border-[#DCE5F0]",
																			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																				className: "font-bold text-[#5B6B7F] capitalize mb-1",
																				children: key.replace(/([A-Z])/g, " $1").trim()
																			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																				className: "font-black text-[#10233F]",
																				children: value
																			})]
																		}, key)),
																		a.customAnswers && Object.entries(a.customAnswers).filter(([key, value]) => key.trim() !== "" && value !== null && value !== void 0 && value.toString().trim() !== "").map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																			className: "text-xs bg-[#F5F8FC] p-3 rounded-lg border border-[#DCE5F0]",
																			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																				className: "font-bold text-[#5B6B7F] capitalize mb-1",
																				children: key
																			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																				className: "font-black text-[#10233F]",
																				children: value
																			})]
																		}, key)),
																		!a.fieldValues && !a.customAnswers && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																			className: "text-sm font-semibold text-[#5B6B7F]",
																			children: t("noAdditionalDetails")
																		})
																	]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "mt-5 pt-4 border-t border-[#DCE5F0]",
																	children: [
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
																			className: "block text-xs font-black text-[#063B78] mb-2",
																			children: "💬 Candidate Reply / Employer Response (या उमेदवाराला संदेश / रिप्लाय पाठवा):"
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																			className: "flex flex-col sm:flex-row gap-2",
																			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
																				type: "text",
																				placeholder: t("replyPlaceholder"),
																				value: replyInputs[a.id] !== void 0 ? replyInputs[a.id] : a.replyMessage || "",
																				onChange: (e) => setReplyInputs((prev) => ({
																					...prev,
																					[a.id]: e.target.value
																				})),
																				className: "flex-1 h-10 px-3.5 rounded-xl border border-[#DCE5F0] bg-[#F8FAFC] text-xs font-bold text-[#10233F] focus:outline-none focus:border-[#063B78]"
																			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
																				onClick: () => handleSaveReply(a.id, replyInputs[a.id] !== void 0 ? replyInputs[a.id] : a.replyMessage || ""),
																				className: "bg-[#063B78] hover:bg-[#082F63] text-white font-black text-xs px-5 h-10 rounded-xl shadow-xs shrink-0 cursor-pointer",
																				children: "Save & Send Reply"
																			})]
																		}),
																		a.replyMessage && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																			className: "mt-2.5 text-xs font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-3.5 py-2 rounded-xl flex items-center justify-between",
																			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
																				"✓ Sent Reply: \"",
																				a.replyMessage,
																				"\""
																			] }), a.replyDate && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																				className: "text-[10px] text-emerald-600 font-semibold",
																				children: a.replyDate
																			})]
																		})
																	]
																})
															]
														})
													})
												})
											})] }, a.id)), applications.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												colSpan: 6,
												className: "p-8 text-center text-xs font-bold text-[#5B6B7F] bg-[#F8FAFF]",
												children: "No job applications received yet."
											}) })]
										})]
									})
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: activeTab === "attendance" ? "block" : "hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-6 sm:space-y-8 animate-fade-in min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl border border-[#DCE5F0] bg-white p-4 sm:p-6 shadow-xs flex flex-col xl:flex-row xl:items-center justify-between gap-6 min-w-0 overflow-hidden flex-wrap",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1.5 min-w-[280px] flex-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "inline-flex items-center gap-2 rounded-full bg-[#063B78]/10 px-3 py-1 text-[11px] sm:text-xs font-black text-[#063B78] max-w-full truncate",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarCheck, { className: "size-3.5 text-[#063B78] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "truncate",
													children: t("employeeAttendancePayrollMgmt")
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
												className: "text-xl sm:text-2xl font-black text-[#10233F] tracking-tight leading-snug break-words",
												children: t("employeeAttendancePayrollRegister")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs sm:text-sm font-semibold text-[#5B6B7F] max-w-2xl leading-relaxed",
												children: t("manageEmployeeDetailsDesc")
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col sm:flex-row sm:flex-wrap xl:flex-nowrap sm:items-center gap-2.5 shrink-0 w-full xl:w-auto min-w-0 max-w-full",
										children: [
											attendanceMode === "field" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "min-h-10 py-2 px-3.5 flex items-center gap-2 bg-gradient-to-r from-amber-500/15 to-amber-600/10 border border-amber-500/40 rounded-xl text-[11px] sm:text-xs font-black text-amber-950 shadow-2xs w-full sm:w-auto min-w-0 max-w-full",
												title: t("autoDetectedFieldWorksite"),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-amber-500 animate-pulse shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "leading-snug flex-1 min-w-0 break-words",
													children: t("fieldMovingWorksite")
												})]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "min-h-10 py-2 px-3.5 flex items-center gap-2 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200/90 rounded-xl text-[11px] sm:text-xs font-black text-[#063B78] shadow-2xs w-full sm:w-auto min-w-0 max-w-full",
												title: t("autoDetectedFixedWorksite"),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-blue-600 animate-pulse shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "leading-snug flex-1 min-w-0 break-words",
													children: t("fixedWorksite")
												})]
											}),
											attendanceMode === "fixed" && (savedLocationLink || savedLocationCoords || currentUser?.worksiteLocationLink || currentUser?.worksiteLocation ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "h-10 flex items-center gap-1.5 bg-emerald-50/90 border border-emerald-300 p-1 pl-3 rounded-xl shadow-2xs w-full sm:w-auto min-w-0 max-w-full",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
													href: savedLocationLink || currentUser?.worksiteLocationLink ? (savedLocationLink || currentUser?.worksiteLocationLink || "").startsWith("http") ? savedLocationLink || currentUser?.worksiteLocationLink || "" : `https://${savedLocationLink || currentUser?.worksiteLocationLink}` : savedLocationCoords || currentUser?.worksiteLocation ? `https://maps.google.com/?q=${(savedLocationCoords || currentUser?.worksiteLocation)?.lat},${(savedLocationCoords || currentUser?.worksiteLocation)?.lng}` : "#",
													target: "_blank",
													rel: "noreferrer",
													className: "text-emerald-900 hover:text-emerald-950 font-black text-xs flex items-center gap-1.5 max-w-[200px] sm:max-w-[280px] truncate group",
													title: savedLocationLink || currentUser?.worksiteLocationLink || "View Worksite Location on Map",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4 text-emerald-600 shrink-0 group-hover:scale-110 transition-transform" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "truncate underline underline-offset-2",
															children: savedLocationLink || currentUser?.worksiteLocationLink || `GPS: ${savedLocationCoords?.lat.toFixed(4)}, ${savedLocationCoords?.lng.toFixed(4)}`
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5 text-emerald-600 shrink-0" })
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
													onClick: () => {
														setLocationLinkInput(savedLocationLink || currentUser?.worksiteLocationLink || "");
														setShowLocationModal(true);
													},
													variant: "ghost",
													size: "sm",
													className: "h-8 px-2.5 text-xs font-extrabold text-emerald-700 hover:bg-emerald-100 hover:text-emerald-900 rounded-lg ml-1 shrink-0",
													title: t("editWorksiteLocationLink"),
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquarePen, { className: "size-3.5 mr-1" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("editWorksiteLocation") })]
												})]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												onClick: () => {
													setLocationLinkInput(savedLocationLink || currentUser?.worksiteLocationLink || "");
													setShowLocationModal(true);
												},
												variant: "outline",
												className: "h-10 border-[#DCE5F0] text-[#5B6B7F] hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-200 font-extrabold text-xs px-4 rounded-xl shadow-2xs flex items-center justify-center gap-2 whitespace-nowrap cursor-pointer w-full sm:w-auto",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4 text-emerald-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("setWorksiteLocation") })]
											})),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												onClick: handleOpenAddWorker,
												className: "h-10 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs px-5 rounded-xl shadow-sm flex items-center justify-center gap-2 w-full sm:w-auto cursor-pointer shrink-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("addEmployeeBtn") })]
											})
										]
									})]
								}), (() => {
									const categoryCounts = /* @__PURE__ */ new Map();
									workers.forEach((w) => {
										const cat = w.category || w.trade || "Plant Nursery & Care";
										categoryCounts.set(cat, (categoryCounts.get(cat) || 0) + 1);
									});
									const allCategories = Array.from(categoryCounts.keys());
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 bg-white p-2 sm:p-3 rounded-2xl border border-[#DCE5F0] shadow-sm min-w-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "grid grid-cols-3 gap-1.5 w-full sm:w-auto sm:flex sm:items-center min-w-0",
													children: [
														{
															id: "daily",
															fullLabel: t("dailyAttendanceSubTab"),
															shortLabel: t("dailyShortSubTab"),
															icon: CalendarCheck
														},
														{
															id: "reports",
															fullLabel: t("reportsSubTab"),
															shortLabel: t("reportsSubTab"),
															icon: ChartPie
														},
														{
															id: "directory",
															fullLabel: `${t("employeesSubTab")} (${workers.length})`,
															shortLabel: `${t("employeesSubTab")} (${workers.length})`,
															icon: Users
														}
													].map((tab) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														onClick: () => setAttendanceSubView(tab.id),
														className: `flex items-center justify-center gap-1 sm:gap-1.5 px-1.5 sm:px-3 py-2 rounded-xl font-extrabold text-[11px] sm:text-xs transition-all w-full sm:w-auto ${attendanceSubView === tab.id ? "bg-[#063B78] text-white shadow-md shadow-[#063B78]/20" : "bg-[#F8FAFF] text-[#5B6B7F] border border-[#DCE5F0] hover:bg-[#EBF1F8] hover:text-[#063B78]"}`,
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(tab.icon, { className: "size-3.5 sm:size-4 shrink-0" }),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "hidden sm:inline",
																children: tab.fullLabel
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "sm:hidden",
																children: tab.shortLabel
															})
														]
													}, tab.id))
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2 w-full sm:w-auto shrink-0 min-w-0",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-1.5 bg-[#F8FAFF] px-3 py-2 rounded-xl border border-[#DCE5F0] w-full sm:w-auto min-w-0",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "size-4 text-[#063B78] shrink-0" }),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-xs font-black text-[#063B78] whitespace-nowrap",
																children: t("departmentFilterLabel")
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
																value: selectedCategoryFilter,
																onChange: (e) => setSelectedCategoryFilter(e.target.value),
																className: "bg-transparent font-bold text-xs text-[#10233F] focus:outline-none cursor-pointer outline-none w-full sm:max-w-[200px] truncate min-w-0",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
																	value: "ALL",
																	children: [
																		t("allCategoriesOption"),
																		" (",
																		workers.length,
																		")"
																	]
																}), allCategories.map((cat) => {
																	const count = categoryCounts.get(cat) || 0;
																	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
																		value: cat,
																		children: [
																			formatCategoryName(cat),
																			" (",
																			count,
																			")"
																		]
																	}, cat);
																})]
															})
														]
													}), attendanceSubView === "reports" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
														variant: "outline",
														size: "sm",
														onClick: () => window.print(),
														className: "text-xs font-black border-[#063B78] text-[#063B78] hover:bg-blue-50 flex items-center gap-1.5 h-9 shrink-0 cursor-pointer",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("printBtn") })]
													})]
												})]
											}),
											attendanceSubView === "daily" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-6",
												children: [
													(() => {
														const attMap = /* @__PURE__ */ new Map();
														dailyAttendanceRecords.forEach((r) => attMap.set(r.workerId, r));
														let pCount = 0;
														let hCount = 0;
														let aCount = 0;
														let otCount = 0;
														let todayWageSum = 0;
														const filteredByCat = workers.filter((w) => {
															if (selectedCategoryFilter === "ALL") return true;
															return (w.category || w.trade || "Plant Nursery / रोपवाटिका") === selectedCategoryFilter;
														});
														filteredByCat.forEach((w) => {
															const rec = attMap.get(w.id);
															const isFixed = w.locationType !== "field" && w.attendanceMode !== "manual";
															let st = "Absent";
															if (isFixed) if (rec?.punchInTime) st = rec.status || "Present";
															else st = "Absent";
															else st = rec?.status || "Present";
															if (st === "Present") {
																pCount++;
																todayWageSum += w.dailyRate;
															} else if (st === "HalfDay") {
																hCount++;
																todayWageSum += Math.round(w.dailyRate / 2);
															} else if (st === "Absent") aCount++;
															else if (st === "Overtime") {
																otCount++;
																todayWageSum += Math.round(w.dailyRate * 1.5);
															}
														});
														return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "grid gap-3 grid-cols-2 sm:grid-cols-2 lg:grid-cols-5",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "p-3.5 sm:p-4 rounded-2xl border border-[#DCE5F0] bg-white shadow-sm flex items-center justify-between gap-2",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																		className: "min-w-0 flex-1",
																		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																			className: "text-[11px] sm:text-xs font-bold text-[#5B6B7F] truncate",
																			title: t("totalEmployeesLabel"),
																			children: t("totalEmployeesLabel")
																		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
																			className: "text-xl sm:text-2xl font-black text-[#10233F] mt-0.5",
																			children: filteredByCat.length
																		})]
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																		className: "p-2.5 bg-blue-50 text-[#063B78] rounded-xl shrink-0",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5" })
																	})]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "p-3.5 sm:p-4 rounded-2xl border border-[#DCE5F0] bg-white shadow-sm flex items-center justify-between gap-2",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																		className: "min-w-0 flex-1",
																		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																			className: "text-[11px] sm:text-xs font-bold text-emerald-700 truncate",
																			title: t("presentToday"),
																			children: t("presentToday")
																		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
																			className: "text-xl sm:text-2xl font-black text-emerald-600 mt-0.5",
																			children: pCount
																		})]
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																		className: "p-2.5 bg-emerald-50 text-emerald-600 rounded-xl shrink-0",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-5" })
																	})]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "p-3.5 sm:p-4 rounded-2xl border border-[#DCE5F0] bg-white shadow-sm flex items-center justify-between gap-2",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																		className: "min-w-0 flex-1",
																		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																			className: "text-[11px] sm:text-xs font-bold text-amber-700 truncate",
																			title: t("halfDayToday"),
																			children: t("halfDayToday")
																		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
																			className: "text-xl sm:text-2xl font-black text-amber-600 mt-0.5",
																			children: hCount
																		})]
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																		className: "p-2.5 bg-amber-50 text-amber-600 rounded-xl shrink-0",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-5" })
																	})]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "p-3.5 sm:p-4 rounded-2xl border border-[#DCE5F0] bg-white shadow-sm flex items-center justify-between gap-2",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																		className: "min-w-0 flex-1",
																		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																			className: "text-[11px] sm:text-xs font-bold text-rose-700 truncate",
																			title: t("absentToday"),
																			children: t("absentToday")
																		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
																			className: "text-xl sm:text-2xl font-black text-rose-600 mt-0.5",
																			children: aCount
																		})]
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																		className: "p-2.5 bg-rose-50 text-rose-600 rounded-xl shrink-0",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserX, { className: "size-5" })
																	})]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "p-3.5 sm:p-4 rounded-2xl border border-[#DCE5F0] bg-white shadow-sm flex items-center justify-between gap-2",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																		className: "min-w-0 flex-1",
																		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																			className: "text-[11px] sm:text-xs font-bold text-[#063B78] truncate",
																			title: t("payableWages"),
																			children: t("payableWages")
																		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
																			className: "text-lg sm:text-xl font-black text-[#063B78] mt-0.5",
																			children: ["₹", todayWageSum.toLocaleString("en-IN")]
																		})]
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																		className: "p-2.5 bg-indigo-50 text-[#063B78] rounded-xl shrink-0",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DollarSign, { className: "size-5" })
																	})]
																})
															]
														});
													})(),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "rounded-2xl border border-[#DCE5F0] bg-white p-4 sm:p-5 shadow-sm flex flex-wrap items-center justify-between gap-3",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex flex-wrap items-center gap-2 sm:gap-3",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "flex items-center gap-2 bg-[#F8FAFF] px-3 py-1.5 rounded-xl border border-[#DCE5F0]",
																	children: [
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-4 text-[#063B78] shrink-0" }),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																			className: "text-xs font-extrabold text-[#10233F] whitespace-nowrap",
																			children: [t("selectDateLabel"), ":"]
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
																			type: "date",
																			max: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
																			value: selectedAttendanceDate,
																			onChange: (e) => {
																				const val = e.target.value;
																				if (val > (/* @__PURE__ */ new Date()).toISOString().split("T")[0]) {
																					toast.error("⚠️ आजनंतरच्या (भविष्यातील) तारखेची हजेरी निवडता येत नाही! (Cannot select future date)");
																					return;
																				}
																				setSelectedAttendanceDate(val);
																			},
																			className: "bg-transparent font-bold text-xs text-[#063B78] focus:outline-none cursor-pointer"
																		})
																	]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
																	variant: "outline",
																	size: "sm",
																	onClick: () => setSelectedAttendanceDate((/* @__PURE__ */ new Date()).toISOString().split("T")[0]),
																	className: `h-9 text-xs font-extrabold rounded-xl border-[#DCE5F0] shrink-0 ${selectedAttendanceDate === (/* @__PURE__ */ new Date()).toISOString().split("T")[0] ? "bg-[#063B78] text-white hover:bg-[#063B78]" : "bg-white text-[#5B6B7F]"}`,
																	children: t("todayBtn")
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
																	variant: "outline",
																	size: "sm",
																	onClick: () => {
																		const d = /* @__PURE__ */ new Date();
																		d.setDate(d.getDate() - 1);
																		setSelectedAttendanceDate(d.toISOString().split("T")[0]);
																	},
																	className: `h-9 text-xs font-extrabold rounded-xl border-[#DCE5F0] shrink-0 ${selectedAttendanceDate === (/* @__PURE__ */ new Date(Date.now() - 864e5)).toISOString().split("T")[0] ? "bg-[#063B78] text-white hover:bg-[#063B78]" : "bg-white text-[#5B6B7F]"}`,
																	children: t("yesterdayBtn")
																})
															]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "relative w-full sm:w-72 shrink-0",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-4 text-[#A0AEC0]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
																placeholder: t("searchEmployeePlaceholder"),
																value: workerSearch,
																onChange: (e) => setWorkerSearch(e.target.value),
																className: "pl-9 h-9 text-xs font-semibold rounded-xl border-[#DCE5F0]"
															})]
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "rounded-2xl border border-[#DCE5F0] bg-white p-6 shadow-sm",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "flex items-center justify-between mb-5",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
																className: "text-lg font-black text-[#10233F] flex items-center gap-2",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("dailyAttendanceSheetTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
																	className: "bg-[#063B78] text-white font-bold text-xs",
																	children: selectedAttendanceDate
																})]
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																className: "text-xs font-semibold text-[#5B6B7F] mt-1",
																children: selectedCategoryFilter === "ALL" ? t("showingAttendanceAllDept") : `${t("showingAttendanceForDept")} '${selectedCategoryFilter}'`
															})] })
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "overflow-x-auto",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
																className: "w-full text-left border-collapse",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
																	className: "border-b border-[#EBF1F8] bg-[#F8FAFF] text-[11px] uppercase tracking-wider text-[#5B6B7F] font-black",
																	children: [
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4 rounded-l-xl",
																			children: t("fullNameLabel")
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4",
																			children: t("departmentLabel")
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4",
																			children: t("jobTitleTh")
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4",
																			children: t("dailyWageRateLabel")
																		}),
																		attendanceMode === "fixed" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4 text-center",
																			children: t("punchTimesTh")
																		}),
																		attendanceMode === "fixed" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4 text-center min-w-[200px]",
																			children: t("workDurationOvertimeTh")
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4 text-right rounded-r-xl",
																			children: t("netSalaryLabel")
																		})
																	]
																}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
																	className: "divide-y divide-[#EBF1F8] text-xs font-semibold",
																	children: (() => {
																		const attMap = /* @__PURE__ */ new Map();
																		dailyAttendanceRecords.forEach((r) => attMap.set(r.workerId, r));
																		const list = workers.filter((w) => {
																			if (selectedCategoryFilter !== "ALL") {
																				if ((w.category || w.trade || "Plant Nursery & Care") !== selectedCategoryFilter) return false;
																			}
																			const q = workerSearch.toLowerCase().trim();
																			if (!q) return true;
																			return w.name.toLowerCase().includes(q) || w.mobile.includes(q) || w.trade.toLowerCase().includes(q) || w.category && w.category.toLowerCase().includes(q);
																		});
																		if (list.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																			colSpan: attendanceMode === "fixed" ? 7 : 5,
																			className: "py-12 text-center text-xs font-bold text-[#5B6B7F]",
																			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																				className: "max-w-md mx-auto",
																				children: [
																					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-10 text-[#A0AEC0] mx-auto mb-3" }),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																						className: "text-sm font-extrabold text-[#10233F]",
																						children: selectedCategoryFilter === "ALL" ? t("noEmployeesRegistered") : `${t("noEmployeesRegistered")} (${selectedCategoryFilter})`
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																						className: "text-xs font-medium text-[#5B6B7F] mt-1 mb-4",
																						children: t("clickAddEmployeePrompt")
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
																						onClick: handleOpenAddWorker,
																						className: "bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs px-4 py-2 rounded-xl",
																						children: [
																							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-4 mr-1.5" }),
																							" ",
																							t("addEmployeeBtn")
																						]
																					})
																				]
																			})
																		}) });
																		return list.map((worker) => {
																			const record = attMap.get(worker.id);
																			const isFixed = worker.locationType !== "field" && worker.attendanceMode !== "manual";
																			const workInfo = calculateWorkAndOvertime(record?.punchInTime, record?.punchOutTime, 540);
																			let currentStatus = "Absent";
																			if (isFixed) if (record?.punchInTime) if (workInfo.overtimeMinutes > 0) currentStatus = "Overtime";
																			else currentStatus = record.status || "Present";
																			else currentStatus = "Absent";
																			else currentStatus = record?.status || "Present";
																			let earnedAmount = worker.dailyRate;
																			if (currentStatus === "HalfDay") earnedAmount = Math.round(worker.dailyRate / 2);
																			if (currentStatus === "Absent") earnedAmount = 0;
																			if (currentStatus === "Overtime" || workInfo.overtimeMinutes > 0) {
																				const baseRate = worker.dailyRate;
																				if (workInfo.overtimeMinutes > 0) {
																					const hourlyRate = baseRate / 9;
																					earnedAmount = baseRate + Math.round(workInfo.overtimeMinutes / 60 * hourlyRate * 1.5);
																				} else earnedAmount = Math.round(baseRate * 1.5);
																			}
																			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
																				className: "hover:bg-[#F8FAFF] transition-colors",
																				children: [
																					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																						className: "p-4 font-black text-[#10233F] min-w-[200px] whitespace-nowrap",
																						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																							className: "flex items-center gap-3",
																							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																								className: "size-9 rounded-full bg-[#063B78]/10 text-[#063B78] font-black flex items-center justify-center text-sm shrink-0",
																								children: worker.name.slice(0, 1).toUpperCase()
																							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																								className: "min-w-0",
																								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																									className: "flex items-center gap-2",
																									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																										className: "text-sm font-black text-[#10233F] whitespace-nowrap",
																										children: worker.name
																									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																										type: "button",
																										onClick: () => {
																											setCalendarWorker(worker);
																											setCalendarMonth((/* @__PURE__ */ new Date()).getMonth());
																											setCalendarYear((/* @__PURE__ */ new Date()).getFullYear());
																											setActiveCalendarDate(null);
																										},
																										title: t("openAttendanceCalendar"),
																										className: "size-7 rounded-lg bg-blue-50 hover:bg-[#063B78] text-[#063B78] hover:text-white border border-blue-200 flex items-center justify-center transition-all shadow-2xs hover:scale-110 cursor-pointer shrink-0",
																										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-3.5 text-[#063B78] hover:text-white" })
																									})]
																								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																									className: "flex items-center gap-1.5 text-xs text-[#5B6B7F] font-bold whitespace-nowrap mt-0.5",
																									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3 text-slate-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: worker.mobile || "N/A" })]
																								})]
																							})]
																						})
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																						className: "p-4",
																						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
																							className: "bg-emerald-50 text-emerald-800 border border-emerald-200 font-extrabold text-[11px]",
																							children: formatCategoryName(worker.category || worker.trade)
																						})
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																						className: "p-4 font-bold text-[#063B78]",
																						children: worker.trade || "General Worker"
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																						className: "p-4 font-black text-[#10233F]",
																						children: [
																							"₹",
																							worker.dailyRate,
																							" ",
																							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																								className: "text-[10px] font-semibold text-[#5B6B7F]",
																								children: "/ day"
																							})
																						]
																					}),
																					attendanceMode === "fixed" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																						className: "p-4 text-center",
																						children: isFixed && record?.punchInTime ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																							className: "flex flex-col gap-1 items-center justify-center text-[10px] font-black",
																							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																								className: "text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 w-full text-center whitespace-nowrap",
																								children: ["IN: ", record.punchInTime]
																							}), !workInfo.isCurrentlyWorking && record.punchOutTime ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																								className: "text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200 w-full text-center whitespace-nowrap",
																								children: ["OUT: ", record.punchOutTime]
																							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																								className: "text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 w-full text-center whitespace-nowrap",
																								children: "Active (Working)"
																							})]
																						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																							className: "text-xs text-slate-400 font-extrabold",
																							children: "--"
																						})
																					}),
																					attendanceMode === "fixed" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																						className: "p-4 text-center min-w-[200px]",
																						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																							className: "flex flex-col items-center justify-center gap-1.5",
																							children: record?.punchInTime ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																								className: "flex flex-col items-center gap-1",
																								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																									className: "inline-flex items-center gap-1.5 bg-emerald-50 border border-emerald-300 text-emerald-900 px-3 py-1 rounded-xl shadow-xs font-black text-xs",
																									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5 text-emerald-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [workInfo.isCurrentlyWorking ? `⏳ ${t("liveWorkLabel")} ` : `⏱️ ${t("workedLabel")} `, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
																										className: "text-emerald-950 font-black",
																										children: workInfo.workedText
																									})] })]
																								}), workInfo.overtimeText && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																									className: "inline-flex items-center gap-1.5 bg-amber-100 border border-amber-400 text-amber-950 px-3 py-1 rounded-xl shadow-xs font-black text-xs animate-pulse",
																									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-3.5 text-amber-600 fill-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
																										t("overtimeLabel"),
																										" ",
																										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
																											className: "text-amber-950 font-black",
																											children: workInfo.overtimeText
																										})
																									] })]
																								})]
																							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																								className: "inline-flex items-center gap-2 bg-slate-100 border border-slate-300 text-slate-600 px-3.5 py-1.5 rounded-2xl",
																								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4 text-slate-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																									className: "font-extrabold text-xs",
																									children: t("autoAbsentNotPunched")
																								})]
																							})
																						})
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																						className: "p-4 text-right font-black text-emerald-700 text-sm",
																						children: ["₹", earnedAmount.toLocaleString("en-IN")]
																					})
																				]
																			}, worker.id);
																		});
																	})()
																})]
															})
														})]
													})
												]
											}),
											attendanceSubView === "reports" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-6",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "rounded-2xl border border-[#DCE5F0] bg-white p-5 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex flex-wrap items-center gap-2",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																	className: "text-xs font-black text-[#10233F] mr-1 flex items-center gap-1",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "size-4 text-[#063B78]" }), t("reportPeriodLabel")]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																	onClick: () => setReportTimeframe("week"),
																	className: `px-3.5 py-2 rounded-xl text-xs font-black transition-all ${reportTimeframe === "week" ? "bg-[#063B78] text-white shadow-md" : "bg-[#F5F8FC] text-[#5B6B7F] border border-[#DCE5F0] hover:bg-[#EBF1F8]"}`,
																	children: "This Week"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																	onClick: () => setReportTimeframe("month"),
																	className: `px-3.5 py-2 rounded-xl text-xs font-black transition-all ${reportTimeframe === "month" ? "bg-[#063B78] text-white shadow-md" : "bg-[#F5F8FC] text-[#5B6B7F] border border-[#DCE5F0] hover:bg-[#EBF1F8]"}`,
																	children: "This Month"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																	onClick: () => setReportTimeframe("custom"),
																	className: `px-3.5 py-2 rounded-xl text-xs font-black transition-all ${reportTimeframe === "custom" ? "bg-[#063B78] text-white shadow-md" : "bg-[#F5F8FC] text-[#5B6B7F] border border-[#DCE5F0] hover:bg-[#EBF1F8]"}`,
																	children: "Custom Date Range"
																})
															]
														}), reportTimeframe === "custom" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center gap-2",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
																	type: "date",
																	value: reportStartDate,
																	onChange: (e) => setReportStartDate(e.target.value),
																	className: "bg-[#F8FAFF] border border-[#DCE5F0] rounded-xl px-3 py-1.5 text-xs font-bold text-[#063B78]"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "text-xs font-bold text-[#5B6B7F]",
																	children: t("toWord")
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
																	type: "date",
																	value: reportEndDate,
																	onChange: (e) => setReportEndDate(e.target.value),
																	className: "bg-[#F8FAFF] border border-[#DCE5F0] rounded-xl px-3 py-1.5 text-xs font-bold text-[#063B78]"
																})
															]
														})]
													}),
													(() => {
														const filteredWorkers = workers.filter((w) => {
															if (selectedCategoryFilter === "ALL") return true;
															return (w.category || w.trade) === selectedCategoryFilter;
														});
														let totalPresentDays = 0;
														let totalHalfDays = 0;
														let totalAbsentDays = 0;
														let totalOvertimeDays = 0;
														let totalPeriodPayroll = 0;
														filteredWorkers.forEach((w) => {
															reportAttendanceRecords.filter((r) => r.workerId === w.id).forEach((r) => {
																if (r.status === "Present") {
																	totalPresentDays++;
																	totalPeriodPayroll += w.dailyRate;
																} else if (r.status === "HalfDay") {
																	totalHalfDays++;
																	totalPeriodPayroll += Math.round(w.dailyRate / 2);
																} else if (r.status === "Absent") totalAbsentDays++;
																else if (r.status === "Overtime") {
																	totalOvertimeDays++;
																	totalPeriodPayroll += Math.round(w.dailyRate * 1.5);
																}
															});
														});
														return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-5",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "p-4 rounded-2xl border border-[#DCE5F0] bg-white shadow-sm flex items-center justify-between",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-xs font-extrabold text-[#5B6B7F]",
																		children: t("totalRecordedDays")
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
																		className: "text-2xl font-black text-[#10233F] mt-1",
																		children: reportAttendanceRecords.length
																	})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																		className: "p-3 bg-blue-50 text-[#063B78] rounded-xl",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "size-5" })
																	})]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "p-4 rounded-2xl border border-[#DCE5F0] bg-white shadow-sm flex items-center justify-between",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-xs font-extrabold text-emerald-700",
																		children: t("totalPresentDays")
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
																		className: "text-2xl font-black text-emerald-600 mt-1",
																		children: totalPresentDays
																	})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																		className: "p-3 bg-emerald-50 text-emerald-600 rounded-xl",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-5" })
																	})]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "p-4 rounded-2xl border border-[#DCE5F0] bg-white shadow-sm flex items-center justify-between",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-xs font-extrabold text-amber-700",
																		children: t("totalHalfDays")
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
																		className: "text-2xl font-black text-amber-600 mt-1",
																		children: totalHalfDays
																	})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																		className: "p-3 bg-amber-50 text-amber-600 rounded-xl",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-5" })
																	})]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "p-4 rounded-2xl border border-[#DCE5F0] bg-white shadow-sm flex items-center justify-between",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-xs font-extrabold text-rose-700",
																		children: t("totalAbsentDays")
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
																		className: "text-2xl font-black text-rose-600 mt-1",
																		children: totalAbsentDays
																	})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																		className: "p-3 bg-rose-50 text-rose-600 rounded-xl",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserX, { className: "size-5" })
																	})]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "p-4 rounded-2xl border border-[#DCE5F0] bg-white shadow-sm flex items-center justify-between",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-xs font-extrabold text-[#063B78]",
																		children: t("netTotalPayroll")
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
																		className: "text-xl font-black text-[#063B78] mt-1",
																		children: ["₹", totalPeriodPayroll.toLocaleString("en-IN")]
																	})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																		className: "p-3 bg-indigo-50 text-[#063B78] rounded-xl",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DollarSign, { className: "size-5" })
																	})]
																})
															]
														});
													})(),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "rounded-2xl border border-[#DCE5F0] bg-white p-6 shadow-sm",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "flex items-center justify-between mb-5",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
																className: "text-lg font-black text-[#10233F] flex items-center gap-2",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["📊 ", t("payrollSummaryTitle")] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
																	className: "bg-[#063B78] text-white font-bold text-xs uppercase",
																	children: reportTimeframe === "week" ? t("weeklyReportBadge") : reportTimeframe === "month" ? t("monthlyReportBadge") : t("customRangeBadge")
																})]
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																className: "text-xs font-semibold text-[#5B6B7F] mt-1",
																children: t("payrollSummaryDesc")
															})] })
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "overflow-x-auto",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
																className: "w-full text-left border-collapse",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
																	className: "border-b border-[#EBF1F8] bg-[#F8FAFF] text-[11px] uppercase tracking-wider text-[#5B6B7F] font-black",
																	children: [
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4 rounded-l-xl",
																			children: t("employeeName")
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4",
																			children: t("department")
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4",
																			children: t("dailyWageRate")
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4 text-center text-emerald-700",
																			children: t("presentDaysTh")
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4 text-center text-amber-700",
																			children: t("halfDaysTh")
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4 text-center text-rose-700",
																			children: t("absentDaysTh")
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4 text-center text-blue-700",
																			children: t("overtimeDaysTh")
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4 text-right rounded-r-xl",
																			children: t("netPayableWagesTh")
																		})
																	]
																}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
																	className: "divide-y divide-[#EBF1F8] text-xs font-semibold",
																	children: (() => {
																		const filtered = workers.filter((w) => {
																			if (selectedCategoryFilter === "ALL") return true;
																			return (w.category || w.trade) === selectedCategoryFilter;
																		});
																		if (filtered.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																			colSpan: 8,
																			className: "p-8 text-center text-xs font-bold text-[#5B6B7F]",
																			children: t("noEmployeeAttendanceRecords")
																		}) });
																		return filtered.map((worker) => {
																			const recs = reportAttendanceRecords.filter((r) => r.workerId === worker.id);
																			let presentCount = 0;
																			let halfCount = 0;
																			let absentCount = 0;
																			let otCount = 0;
																			let totalWage = 0;
																			recs.forEach((r) => {
																				if (r.status === "Present") {
																					presentCount++;
																					totalWage += worker.dailyRate;
																				} else if (r.status === "HalfDay") {
																					halfCount++;
																					totalWage += Math.round(worker.dailyRate / 2);
																				} else if (r.status === "Absent") absentCount++;
																				else if (r.status === "Overtime") {
																					otCount++;
																					totalWage += Math.round(worker.dailyRate * 1.5);
																				}
																			});
																			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
																				className: "hover:bg-[#F8FAFF]",
																				children: [
																					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																						className: "p-4 font-black text-[#10233F]",
																						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																							className: "text-sm font-black",
																							children: worker.name
																						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																							className: "text-[10px] text-[#5B6B7F]",
																							children: ["📞 ", worker.mobile || "N/A"]
																						})]
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																						className: "p-4",
																						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
																							className: "bg-blue-50 text-[#063B78] border border-blue-200 font-extrabold text-[11px]",
																							children: formatCategoryName(worker.category || worker.trade)
																						})
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																						className: "p-4 font-black text-[#10233F]",
																						children: [
																							"₹",
																							worker.dailyRate,
																							" / day"
																						]
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																						className: "p-4 text-center font-black text-emerald-600 text-sm",
																						children: presentCount
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																						className: "p-4 text-center font-black text-amber-600 text-sm",
																						children: halfCount
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																						className: "p-4 text-center font-black text-rose-600 text-sm",
																						children: absentCount
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																						className: "p-4 text-center font-black text-blue-600 text-sm",
																						children: otCount
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																						className: "p-4 text-right font-black text-emerald-700 text-base",
																						children: ["₹", totalWage.toLocaleString("en-IN")]
																					})
																				]
																			}, worker.id);
																		});
																	})()
																})]
															})
														})]
													})
												]
											}),
											attendanceSubView === "directory" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "rounded-2xl border border-[#DCE5F0] bg-white p-6 shadow-sm space-y-5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "flex items-center justify-between",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
														className: "text-lg font-black text-[#10233F] flex items-center gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["👥 ", t("registeredEmployeeDirectory")] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
															className: "bg-emerald-100 text-emerald-800 font-bold text-xs border border-emerald-300",
															children: [
																workers.length,
																" ",
																t("employeesTotalBadge")
															]
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-xs font-semibold text-[#5B6B7F] mt-1",
														children: t("manageEmployeesDesc")
													})] })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "overflow-x-auto",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
														className: "w-full text-left border-collapse",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
															className: "border-b border-[#EBF1F8] bg-[#F8FAFF] text-[11px] uppercase tracking-wider text-[#5B6B7F] font-black",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																	className: "p-4 rounded-l-xl",
																	children: t("employeeName")
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																	className: "p-4",
																	children: t("department")
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																	className: "p-4",
																	children: t("roleDesignationTh")
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																	className: "p-4",
																	children: t("mobileNumberTh")
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																	className: "p-4",
																	children: t("dailyWageRate")
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																	className: "p-4",
																	children: t("joiningDateTh")
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																	className: "p-4 text-center rounded-r-xl",
																	children: t("actionsThDirectory")
																})
															]
														}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
															className: "divide-y divide-[#EBF1F8] text-xs font-semibold",
															children: workers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																colSpan: 7,
																className: "p-8 text-center text-xs font-bold text-[#5B6B7F]",
																children: t("noEmployeesRegistered")
															}) }) : workers.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
																className: "hover:bg-[#F8FAFF]",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																		className: "p-4",
																		children: [
																			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																				className: "flex items-center gap-2",
																				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																					className: "font-black text-[#10233F]",
																					children: w.name
																				})
																			}),
																			(w.workShiftStart || w.workShiftEnd) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																				className: "text-[10px] text-[#063B78] font-bold mt-0.5 flex items-center gap-1",
																				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3 text-[#063B78]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
																					t("shiftLabel"),
																					" ",
																					formatTime12Hr(w.workShiftStart || "09:00"),
																					" - ",
																					formatTime12Hr(w.workShiftEnd || "18:00")
																				] })]
																			}),
																			w.customFields && w.customFields.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																				className: "flex flex-wrap gap-1 mt-1",
																				children: w.customFields.map((cf, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																					className: "text-[9px] font-black bg-blue-50 text-[#063B78] border border-blue-200 px-1.5 py-0.5 rounded",
																					children: [
																						cf.label,
																						": ",
																						cf.value
																					]
																				}, i))
																			})
																		]
																	}),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																		className: "p-4",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
																			className: "bg-emerald-50 text-emerald-800 border border-emerald-200 font-extrabold text-[11px]",
																			children: formatCategoryName(w.category || w.trade)
																		})
																	}),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																		className: "p-4 font-bold text-[#063B78]",
																		children: w.trade
																	}),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																		className: "p-4 text-[#5B6B7F]",
																		children: w.mobile || "N/A"
																	}),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																		className: "p-4 font-black text-emerald-700",
																		children: [
																			"₹",
																			w.dailyRate,
																			" / day"
																		]
																	}),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																		className: "p-4 text-[#5B6B7F]",
																		children: w.joiningDate || "N/A"
																	}),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																		className: "p-4 text-center",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																			className: "flex items-center justify-center gap-2",
																			children: [
																				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
																					variant: "outline",
																					size: "sm",
																					onClick: () => setSelectedWorkerReport(w),
																					className: "h-8 px-2.5 rounded-lg border-blue-200 bg-blue-50/50 hover:bg-blue-100 text-xs font-bold text-[#063B78]",
																					title: t("viewReportAndPrintSlip"),
																					children: [
																						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-3.5 mr-1 text-[#063B78]" }),
																						" ",
																						t("slipBtn")
																					]
																				}),
																				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
																					variant: "outline",
																					size: "sm",
																					onClick: () => handleOpenEditWorker(w),
																					className: "h-8 px-2.5 rounded-lg border-[#DCE5F0] text-xs font-bold text-[#063B78]",
																					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquarePen, { className: "size-3.5 mr-1" }), " Edit"]
																				}),
																				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
																					variant: "outline",
																					size: "sm",
																					onClick: () => handleDeleteWorker(w.id, w.name),
																					className: "h-8 px-2.5 rounded-lg border-rose-200 text-xs font-bold text-rose-600 hover:bg-rose-50",
																					children: [
																						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5 mr-1" }),
																						" ",
																						t("deleteBtn")
																					]
																				})
																			]
																		})
																	})
																]
															}, w.id))
														})]
													})
												})]
											})
										]
									});
								})()]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: activeTab === "profile" ? "block" : "hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "max-w-4xl mx-auto space-y-6",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white rounded-2xl border border-[#DCE5F0] p-6 sm:p-8 shadow-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between pb-5 border-b border-[#EBF1F8] mb-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "p-3 bg-[#F0F4FA] rounded-xl text-[#063B78]",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-6 text-[#063B78]" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
												className: "text-xl font-black text-[#10233F]",
												children: t("employerProfileSettings")
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-semibold text-[#5B6B7F]",
												children: t("updateOrgDetailsDesc")
											})] })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
											className: "bg-emerald-600 text-white font-bold text-xs px-3 py-1",
											children: ["✓ ", t("verifiedEmployer")]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
										onSubmit: handleSaveProfile,
										className: "space-y-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-col sm:flex-row items-center gap-6 p-5 rounded-2xl bg-[#F8FAFF] border border-[#E0E8F5]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "relative shrink-0",
													children: profileForm.profilePhoto ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
														src: profileForm.profilePhoto,
														alt: "Profile Avatar",
														className: "size-24 rounded-full object-cover shadow-md ring-4 ring-white border-2 border-[#063B78]"
													}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "size-24 rounded-full bg-gradient-to-br from-[#063B78] to-[#125BB5] text-white font-black text-3xl flex items-center justify-center shadow-md ring-4 ring-white border-2 border-white",
														children: (profileForm.fullName || "E").charAt(0).toUpperCase()
													})
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex-1 space-y-2 w-full text-center sm:text-left",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
															className: "text-sm font-black text-[#10233F]",
															children: t("profilePictureLogoUrl")
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-xs text-[#5B6B7F]",
															children: t("providePhotoUrlDesc")
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
															type: "url",
															placeholder: "https://example.com/logo.jpg",
															value: profileForm.profilePhoto,
															onChange: (e) => setProfileForm({
																...profileForm,
																profilePhoto: e.target.value
															}),
															className: "text-xs font-semibold"
														})
													]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid grid-cols-1 sm:grid-cols-2 gap-5",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
														className: "block text-xs font-bold text-[#5B6B7F] mb-1.5",
														children: t("companyOrgName")
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														required: true,
														value: profileForm.fullName,
														onChange: (e) => setProfileForm({
															...profileForm,
															fullName: e.target.value
														}),
														placeholder: "e.g. Vikas Ropvatika & Nursery",
														className: "text-xs font-semibold"
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
														className: "block text-xs font-bold text-[#5B6B7F] mb-1.5",
														children: t("contactPersonName")
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														value: profileForm.contactPerson,
														onChange: (e) => setProfileForm({
															...profileForm,
															contactPerson: e.target.value
														}),
														placeholder: "e.g. Vikas Patil",
														className: "text-xs font-semibold"
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
														className: "block text-xs font-bold text-[#5B6B7F] mb-1.5",
														children: t("emailAddress")
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														required: true,
														type: "email",
														value: profileForm.email,
														onChange: (e) => setProfileForm({
															...profileForm,
															email: e.target.value
														}),
														placeholder: "e.g. ropvatika@gmail.com",
														className: "text-xs font-semibold"
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
														className: "block text-xs font-bold text-[#5B6B7F] mb-1.5",
														children: t("mobilePhoneNumber")
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														required: true,
														value: profileForm.mobile,
														onChange: (e) => setProfileForm({
															...profileForm,
															mobile: e.target.value
														}),
														placeholder: "e.g. 9822011223",
														className: "text-xs font-semibold"
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
														className: "block text-xs font-bold text-[#5B6B7F] mb-1.5",
														children: t("locationAddress")
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														value: profileForm.location,
														onChange: (e) => setProfileForm({
															...profileForm,
															location: e.target.value
														}),
														placeholder: "e.g. Pune, Maharashtra",
														className: "text-xs font-semibold"
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
														className: "block text-xs font-bold text-[#5B6B7F] mb-1.5",
														children: t("businessIndustrySector")
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														value: profileForm.industry,
														onChange: (e) => setProfileForm({
															...profileForm,
															industry: e.target.value
														}),
														placeholder: "e.g. Plant Nursery & Agricultural Services",
														className: "text-xs font-semibold"
													})] })
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex items-center justify-end gap-3 pt-4 border-t border-[#EBF1F8]",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
													type: "submit",
													className: "px-6 py-2.5 rounded-xl bg-[#063B78] hover:bg-[#0A4F9E] text-white font-black text-xs shadow-md flex items-center gap-2",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4" }),
														" ",
														t("saveProfileDetails")
													]
												})
											})
										]
									})]
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: activeTab === "packages" ? "block" : "hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "max-w-5xl mx-auto space-y-6 animate-in fade-in duration-300",
								children: (() => {
									const userId = currentUser?.id || currentUser?.email || empIdentifier;
									const userPkgs = dataStore.getUserPackages(userId);
									const workerLimit = dataStore.getUserWorkerCredits(userId);
									const jobCredits = dataStore.getUserJobCredits(userId);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-white rounded-2xl border border-[#DCE5F0] p-6 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
												className: "text-xl font-black text-[#10233F] flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["💳 ", t("activePackageStatus")] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-xs bg-emerald-100 text-emerald-800 border border-emerald-300 font-extrabold px-3 py-0.5 rounded-full",
													children: [
														userPkgs.length,
														" ",
														t("activePurchases")
													]
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-semibold text-[#5B6B7F] mt-1",
												children: t("manageActiveCreditsDesc")
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												onClick: () => setShowPackageModal(true),
												className: "bg-[#063B78] hover:bg-[#0A4F9E] text-white font-black text-xs px-5 py-2.5 rounded-xl shadow-md shrink-0",
												children: t("buyUpgradePackage")
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "bg-white p-5 rounded-2xl border border-[#DCE5F0] shadow-sm space-y-1",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[11px] font-black uppercase text-[#5B6B7F] tracking-wider",
															children: t("currentJobCredits")
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "text-3xl font-black text-amber-600",
															children: [jobCredits, " Available"]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-xs text-slate-500 font-medium",
															children: t("jobPostingsRemaining")
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "bg-white p-5 rounded-2xl border border-[#DCE5F0] shadow-sm space-y-1",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[11px] font-black uppercase text-[#5B6B7F] tracking-wider",
															children: t("employeeAdditionLimit")
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "text-3xl font-black text-indigo-700",
															children: workerLimit === 0 ? "0 Allowed" : workerLimit >= 9999 ? "Unlimited" : `${workerLimit} Employees`
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
															className: "text-xs text-slate-500 font-medium",
															children: [workers.length, " Employees Currently Added"]
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "bg-white p-5 rounded-2xl border border-[#DCE5F0] shadow-sm space-y-1",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[11px] font-black uppercase text-[#5B6B7F] tracking-wider",
															children: t("totalAmountSpent")
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "text-3xl font-black text-emerald-600",
															children: ["₹", userPkgs.reduce((sum, p) => sum + (p.price || 0), 0)]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
															className: "text-xs text-slate-500 font-medium",
															children: [
																"Across ",
																userPkgs.length,
																" transaction(s)"
															]
														})
													]
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-white rounded-2xl border border-[#DCE5F0] p-6 shadow-sm space-y-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-base font-black text-[#10233F]",
												children: t("packagePurchaseHistory")
											}), userPkgs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "py-12 text-center border-2 border-dashed border-[#E0E8F5] rounded-xl bg-[#F8FAFF]",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndianRupee, { className: "size-10 text-slate-300 mx-auto mb-2" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-sm font-bold text-[#10233F]",
														children: t("noPackagePurchasesFound")
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-xs text-slate-500 mt-1 mb-4",
														children: t("clickToChoosePackageDesc")
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														onClick: () => setShowPackageModal(true),
														className: "bg-[#063B78] text-white font-black text-xs px-6 py-2.5 rounded-xl shadow-md",
														children: "Choose Package Plan"
													})
												]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "overflow-x-auto",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
													className: "w-full text-left text-xs",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
														className: "bg-[#F8FAFF] border-b border-[#E0E8F5] text-[#5B6B7F] font-black uppercase tracking-wider text-[11px]",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																className: "p-3 whitespace-nowrap",
																children: t("transactionIdCol")
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																className: "p-3 whitespace-nowrap",
																children: t("packageNameCol")
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																className: "p-3 whitespace-nowrap",
																children: t("pricePaidCol")
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																className: "p-3 whitespace-nowrap",
																children: t("jobCredits")
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																className: "p-3 whitespace-nowrap",
																children: t("employeeLimitCol")
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																className: "p-3 whitespace-nowrap",
																children: t("paymentMethodCol")
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																className: "p-3 whitespace-nowrap",
																children: t("purchaseDateCol")
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																className: "p-3 whitespace-nowrap",
																children: t("status")
															})
														]
													}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
														className: "divide-y divide-[#E0E8F5] font-semibold text-[#10233F]",
														children: userPkgs.map((tx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
															className: "hover:bg-[#F8FAFF] transition-colors",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																	className: "p-3 font-mono text-[11px] text-[#063B78] whitespace-nowrap",
																	children: tx.id
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																	className: "p-3 whitespace-nowrap",
																	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																		className: "px-3 py-1 rounded-xl bg-blue-50 text-[#063B78] border border-blue-200 font-black text-xs inline-block whitespace-nowrap shadow-2xs",
																		children: tx.planName
																	})
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																	className: "p-3 font-black text-emerald-700 text-sm whitespace-nowrap",
																	children: ["₹", tx.price]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																	className: "p-3 font-extrabold text-amber-700 whitespace-nowrap",
																	children: tx.jobCount >= 999 ? t("unlimitedLabel") : tx.jobCount
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																	className: "p-3 font-extrabold text-indigo-700 whitespace-nowrap",
																	children: tx.workerCount ? Number(tx.workerCount) >= 9999 ? t("unlimitedLabel") : `${tx.workerCount} ${t("employeesSubTab")}` : `3 ${t("employeesSubTab")}`
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																	className: "p-3 font-bold uppercase text-slate-600 whitespace-nowrap",
																	children: tx.paymentMethod
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																	className: "p-3 text-[#5B6B7F] font-medium whitespace-nowrap",
																	children: tx.purchaseDate
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																	className: "p-3 whitespace-nowrap",
																	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																		className: "px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black inline-block whitespace-nowrap",
																		children: t("activeCompletedStatus")
																	})
																})
															]
														}, tx.id))
													})]
												})
											})]
										})
									] });
								})()
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: activeTab === "salary" ? "block" : "hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-6 sm:space-y-8 animate-fade-in min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl border border-[#DCE5F0] bg-white p-4 sm:p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 min-w-0 overflow-hidden flex-wrap",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1.5 min-w-[280px] flex-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "inline-flex items-center gap-2 rounded-full bg-[#063B78]/10 px-3 py-1 text-[11px] sm:text-xs font-black text-[#063B78] max-w-full truncate",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-3.5 text-[#063B78] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "truncate",
													children: t("eSalaryPayslipsManagement")
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
												className: "text-xl sm:text-2xl font-black text-[#10233F] tracking-tight leading-snug break-words",
												children: t("employeeSalarySlipsTitle")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs sm:text-sm font-semibold text-[#5B6B7F] max-w-2xl leading-relaxed",
												children: t("employeeSalarySlipsDesc")
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex items-center gap-2 shrink-0",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
											value: selectedSalaryMonth,
											onChange: (e) => setSelectedSalaryMonth(e.target.value),
											className: "h-10 px-3 bg-[#F8FAFF] rounded-xl border border-[#DCE5F0] text-xs font-black text-[#063B78] focus:outline-none cursor-pointer",
											children: [
												"January",
												"February",
												"March",
												"April",
												"May",
												"June",
												"July",
												"August",
												"September",
												"October",
												"November",
												"December"
											].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: m,
												children: [
													m,
													" ",
													selectedSalaryYear
												]
											}, m))
										})
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "bg-white p-4 sm:p-6 rounded-2xl border border-[#DCE5F0] shadow-sm space-y-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "overflow-x-auto rounded-xl border border-[#DCE5F0]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
											className: "w-full text-left text-xs whitespace-nowrap",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
												className: "bg-[#063B78] text-white font-black uppercase tracking-wider text-[11px]",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-4",
														children: t("employeeName")
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-4",
														children: t("positionCol")
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-4 text-center",
														children: t("wageRateCol")
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-4 text-center",
														children: t("present")
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-4 text-center",
														children: t("absent")
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-4 text-right",
														children: t("netEarnedCol")
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-4 text-center",
														children: t("actionCol")
													})
												] })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
												className: "divide-y divide-[#DCE5F0] font-semibold text-[#10233F]",
												children: [workers.map((emp) => {
													const metrics = getWorkerReportMetrics(emp, "month", selectedSalaryMonth, selectedSalaryYear);
													return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
														className: "hover:bg-[#F5F8FC] transition-colors",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																className: "p-4",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
																	className: "block font-black text-[#063B78]",
																	children: emp.name
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																	className: "text-[10px] text-slate-400 font-medium",
																	children: ["ID: RJW-", emp.id.slice(-6).toUpperCase()]
																})]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																className: "p-4 text-[#5B6B7F] font-bold",
																children: emp.trade || "Worker"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																className: "p-4 text-slate-600 font-bold text-center",
																children: [
																	"₹",
																	emp.dailyRate,
																	" / day"
																]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																className: "p-4 text-emerald-600 font-black text-center",
																children: [metrics.present + metrics.halfDay * .5, " Days"]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																className: "p-4 text-rose-600 font-black text-center",
																children: [metrics.absent, " Days"]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																className: "p-4 text-right font-black text-emerald-700 text-sm",
																children: ["₹", metrics.netPay.toLocaleString("en-IN")]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																className: "p-4 text-center",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
																	onClick: () => {
																		setViewSlipPeriod("month");
																		setViewSlipWorker(emp);
																	},
																	size: "sm",
																	className: "bg-[#063B78] hover:bg-[#082F63] text-white text-xs font-black px-4 shadow-sm cursor-pointer",
																	children: "View Slip"
																})
															})
														]
													}, emp.id);
												}), workers.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
													colSpan: 7,
													className: "p-8 text-center text-xs font-bold text-[#5B6B7F] bg-[#F8FAFF]",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "mb-2",
														children: t("noRegisteredEmployeesFound")
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														onClick: handleOpenAddWorker,
														size: "sm",
														className: "bg-[#063B78] hover:bg-[#082F63] text-white font-black text-xs h-8",
														children: "+ Add Employee"
													})]
												}) })]
											})]
										})
									})
								})]
							})
						})
					]
				})]
			}),
			showLocationModal && (() => {
				const handleUseCurrentLocation = () => {
					if (!navigator.geolocation) {
						toast.error("Geolocation is not supported by your browser / device.");
						return;
					}
					setIsDetectingLocation(true);
					toast.info("📍 Fetching your exact GPS location...");
					navigator.geolocation.getCurrentPosition((position) => {
						setIsDetectingLocation(false);
						const lat = position.coords.latitude;
						const lng = position.coords.longitude;
						const accuracy = position.coords.accuracy ? Math.round(position.coords.accuracy) : null;
						const mapsLink = `https://maps.google.com/?q=${lat},${lng}`;
						const coordsObj = {
							lat,
							lng
						};
						setLocationLinkInput(mapsLink);
						setSavedLocationLink(mapsLink);
						setSavedLocationCoords(coordsObj);
						try {
							localStorage.setItem(`emp_worksite_link_${empIdentifier}`, mapsLink);
							localStorage.setItem(`emp_worksite_coords_${empIdentifier}`, JSON.stringify(coordsObj));
						} catch (e) {}
						if (currentUser) {
							const updated = (currentUser.id ? dataStore.updateRegisteredAccount(currentUser.id, {
								worksiteLocation: coordsObj,
								worksiteLocationLink: mapsLink
							}) : null) || {
								...currentUser,
								worksiteLocation: coordsObj,
								worksiteLocationLink: mapsLink
							};
							dataStore.setCurrentUser(updated);
							try {
								sessionStorage.setItem("realjob_tab_user", JSON.stringify(updated));
								localStorage.setItem("realjob-user", JSON.stringify(updated));
								if (currentUser.role === "employer") localStorage.setItem("realjob-user-employer", JSON.stringify(updated));
								if (currentUser.role === "admin") localStorage.setItem("realjob-user-admin", JSON.stringify(updated));
							} catch (e) {}
						}
						toast.success(`📍 Worksite Location set to Current GPS! (${lat.toFixed(5)}, ${lng.toFixed(5)}${accuracy ? `, ~${accuracy}m` : ""})`);
						setShowLocationModal(false);
					}, (error) => {
						setIsDetectingLocation(false);
						console.error("GPS error:", error);
						if (error.code === error.PERMISSION_DENIED) toast.error("Location permission denied. Please allow location access in your browser settings.");
						else if (error.code === error.POSITION_UNAVAILABLE) toast.error("Location information is currently unavailable.");
						else if (error.code === error.TIMEOUT) toast.error("Location request timed out. Please try again or paste a map link.");
						else toast.error("Unable to get current location. Please paste a map link below.");
					}, {
						enableHighAccuracy: true,
						timeout: 12e3,
						maximumAge: 0
					});
				};
				const handleSaveMapLink = () => {
					const rawInput = locationLinkInput.trim();
					if (!rawInput) {
						toast.error("Please enter or paste a map location link.");
						return;
					}
					setSavedLocationLink(rawInput);
					try {
						localStorage.setItem(`emp_worksite_link_${empIdentifier}`, rawInput);
					} catch (e) {}
					const parsed = parseMapCoordinates(rawInput);
					let coordsObj = parsed || {
						lat: 18.5204,
						lng: 73.8567
					};
					if (parsed) toast.info(` Recognized Location: ${parsed.lat.toFixed(6)}, ${parsed.lng.toFixed(6)}`);
					else toast.warning("Saved link for reference.");
					setSavedLocationCoords(coordsObj);
					try {
						localStorage.setItem(`emp_worksite_coords_${empIdentifier}`, JSON.stringify(coordsObj));
					} catch (e) {}
					if (currentUser) {
						const updated = (currentUser.id ? dataStore.updateRegisteredAccount(currentUser.id, {
							worksiteLocation: coordsObj,
							worksiteLocationLink: rawInput
						}) : null) || {
							...currentUser,
							worksiteLocation: coordsObj,
							worksiteLocationLink: rawInput
						};
						dataStore.setCurrentUser(updated);
						try {
							sessionStorage.setItem("realjob_tab_user", JSON.stringify(updated));
							localStorage.setItem("realjob-user", JSON.stringify(updated));
							if (currentUser.role === "employer") localStorage.setItem("realjob-user-employer", JSON.stringify(updated));
							if (currentUser.role === "admin") localStorage.setItem("realjob-user-admin", JSON.stringify(updated));
						} catch (e) {}
					}
					toast.success("✅ Worksite Location Link Saved Successfully!");
					setShowLocationModal(false);
				};
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white w-full max-w-md rounded-3xl p-6 sm:p-7 shadow-2xl border border-slate-100 relative",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setShowLocationModal(false),
								className: "absolute top-5 right-5 text-slate-400 hover:text-slate-700 font-extrabold text-xl p-2 rounded-full hover:bg-slate-100",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 mb-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "p-3 rounded-2xl bg-emerald-50 text-emerald-700 shrink-0",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-6 text-emerald-600" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-xl font-black text-[#10233F]",
									children: t("setWorksiteTitle")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-slate-500 font-semibold mt-0.5",
									children: t("setWorksiteDesc")
								})] })]
							}),
							(savedLocationLink || savedLocationCoords) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-4 p-3.5 bg-emerald-50/90 border border-emerald-200 rounded-2xl",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-black text-emerald-900 uppercase tracking-wide",
									children: "Current Saved Location:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2 mt-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-bold text-emerald-800 truncate",
										children: savedLocationLink || `GPS: ${savedLocationCoords?.lat.toFixed(4)}, ${savedLocationCoords?.lng.toFixed(4)}`
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: savedLocationLink ? savedLocationLink.startsWith("http") ? savedLocationLink : `https://${savedLocationLink}` : `https://maps.google.com/?q=${savedLocationCoords?.lat},${savedLocationCoords?.lng}`,
										target: "_blank",
										rel: "noreferrer",
										className: "text-xs font-black text-emerald-700 hover:underline shrink-0 flex items-center gap-1",
										children: ["Open Map ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3" })]
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4 bg-gradient-to-br from-emerald-50 via-teal-50/40 to-emerald-50 border border-emerald-200 rounded-2xl shadow-2xs space-y-2.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-start gap-2.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "p-2 rounded-xl bg-emerald-600 text-white shrink-0 mt-0.5 shadow-sm",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocateFixed, { className: "size-4" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
												className: "text-xs font-black text-emerald-950 flex items-center gap-1.5",
												children: "Option 1: Device GPS (चालू स्थान)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] text-emerald-800/80 font-medium leading-relaxed mt-0.5",
												children: "सध्या ऑफिस/साइटवर असाल तर 1-क्लिकमध्ये तुमचे चालू GPS लोकेशन सेव्ह करा."
											})] })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											onClick: handleUseCurrentLocation,
											disabled: isDetectingLocation,
											className: "w-full h-11 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-98",
											children: isDetectingLocation ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("detectingGps") })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigation, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("useCurrentLocationBtn") })] })
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative flex py-1 items-center",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flex-grow border-t border-slate-200" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "flex-shrink mx-3 text-[10px] font-black uppercase tracking-wider text-slate-400 bg-white px-2",
												children: "OR Paste Map Link"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flex-grow border-t border-slate-200" })
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "block text-xs font-bold text-[#10233F] mb-1",
												children: "Option 2: Paste Google Maps / Bing Maps Link"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] text-slate-500 font-semibold mb-2",
												children: "गुगल मॅप्स किंवा बिंग मॅप्सची लोकेशन लिंक खाली पेस्ट करा."
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "relative",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: locationLinkInput,
													onChange: (e) => setLocationLinkInput(e.target.value),
													placeholder: t("pasteMapsPlaceholder"),
													className: "text-xs font-semibold pr-8"
												}), locationLinkInput && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => setLocationLinkInput(""),
													className: "absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
												})]
											})
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											onClick: handleSaveMapLink,
											className: "w-full h-10 bg-[#063B78] hover:bg-[#082F63] text-white font-extrabold text-xs rounded-xl shadow-sm cursor-pointer",
											children: "Save Map Link"
										})]
									})
								]
							})
						]
					})
				});
			})(),
			showWorkerModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white w-full max-w-xl rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-100 relative max-h-[92vh] overflow-y-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setShowWorkerModal(false),
							className: "absolute top-5 right-5 text-slate-400 hover:text-slate-700 font-extrabold text-xl p-2 rounded-full hover:bg-slate-100",
							children: "✕"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 pb-4 border-b border-slate-100 pr-8",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "p-3 rounded-2xl bg-emerald-50 text-emerald-700 shrink-0",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-6 text-emerald-600" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-xl font-black text-[#10233F]",
									children: editingWorkerId ? t("editEmployeeTitle") : t("addNewEmployeeTitle")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-slate-500 font-semibold mt-0.5",
									children: t("employeeFormSubtitle")
								})] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: handleOpenAddFieldPrompt,
								className: "px-3.5 py-2.5 rounded-xl bg-[#063B78] hover:bg-[#0A4F9E] text-white font-extrabold text-xs transition-all flex items-center gap-1.5 shadow-md shrink-0 self-start sm:self-auto",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Add Custom Field"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: handleSaveWorker,
							className: "space-y-4",
							children: [
								removedStandardFields.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5 flex-wrap p-2.5 bg-amber-50/80 rounded-2xl border border-amber-200/80 mb-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[11px] font-extrabold text-amber-800 uppercase tracking-wide mr-1",
											children: "Restore Hidden Fields:"
										}),
										removedStandardFields.includes("trade") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => handleRestoreStandardField("trade"),
											className: "px-2.5 py-1 bg-white hover:bg-emerald-50 hover:text-emerald-700 text-slate-700 font-bold text-xs rounded-lg border border-slate-200 shadow-2xs transition-all",
											children: "+ Role / Designation"
										}),
										removedStandardFields.includes("mobile") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => handleRestoreStandardField("mobile"),
											className: "px-2.5 py-1 bg-white hover:bg-emerald-50 hover:text-emerald-700 text-slate-700 font-bold text-xs rounded-lg border border-slate-200 shadow-2xs transition-all",
											children: "+ Mobile Number"
										}),
										removedStandardFields.includes("joiningDate") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => handleRestoreStandardField("joiningDate"),
											className: "px-2.5 py-1 bg-white hover:bg-emerald-50 hover:text-emerald-700 text-slate-700 font-bold text-xs rounded-lg border border-slate-200 shadow-2xs transition-all",
											children: "+ Joining Date"
										}),
										removedStandardFields.includes("shiftTimes") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => handleRestoreStandardField("shiftTimes"),
											className: "px-2.5 py-1 bg-white hover:bg-emerald-50 hover:text-emerald-700 text-slate-700 font-bold text-xs rounded-lg border border-slate-200 shadow-2xs transition-all",
											children: "+ Work Shift Times"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs font-extrabold text-slate-700 uppercase mb-1 block",
									children: "Employee Name *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									required: true,
									placeholder: t("workerNamePlaceholder"),
									value: workerForm.name,
									onChange: (e) => setWorkerForm((p) => ({
										...p,
										name: e.target.value
									})),
									className: "h-11 rounded-xl text-xs font-bold border-slate-300"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-xs font-extrabold text-slate-700 uppercase block",
										children: "Department / Category *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											setIsCategoryDropdownOpen(true);
											setShowOtherCategoryInput(true);
										},
										className: "text-[#063B78] hover:underline text-[11px] font-bold flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3" }), " Add Custom Category"]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setIsCategoryDropdownOpen((prev) => !prev),
										className: "w-full h-11 px-3 rounded-xl text-xs font-bold border border-slate-300 bg-white text-[#10233F] flex items-center justify-between focus:outline-none focus:ring-2 focus:ring-[#063B78] shadow-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate",
											children: workerForm.category || "Select Category"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `size-4 text-slate-400 transition-transform duration-200 ${isCategoryDropdownOpen ? "rotate-180" : ""}` })]
									}), isCategoryDropdownOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute left-0 right-0 top-12 z-50 bg-white border border-slate-200 rounded-2xl shadow-xl max-h-72 overflow-y-auto p-1.5 space-y-0.5 animate-fade-in",
										children: [[
											...getIndustryDefaultCategories(),
											...customCategories,
											"⚙️ Other / Custom"
										].filter((catName) => !removedCategories.includes(catName)).map((catName) => {
											const isSelected = workerForm.category === catName;
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												onClick: () => {
													setWorkerForm((p) => ({
														...p,
														category: catName
													}));
													setIsCategoryDropdownOpen(false);
													setShowOtherCategoryInput(false);
												},
												className: `w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold cursor-pointer transition-colors ${isSelected ? "bg-[#063B78] text-white" : "hover:bg-slate-100 text-[#10233F]"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "truncate",
													children: catName
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: (e) => {
														e.stopPropagation();
														handleRemoveCategory(catName);
													},
													className: `p-1 rounded-lg hover:bg-red-500 hover:text-white transition-colors ml-2 shrink-0 ${isSelected ? "text-white/80 hover:text-white" : "text-slate-400 hover:text-red-600"}`,
													title: `Remove category "${catName}"`,
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
												})]
											}, catName);
										}), showOtherCategoryInput ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											onClick: (e) => e.stopPropagation(),
											className: "p-2 bg-blue-50/90 rounded-xl border border-blue-200 mt-1 flex items-center gap-1.5 animate-fade-in",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													autoFocus: true,
													placeholder: t("typeNewCategoryPlaceholder"),
													value: newCustomCategoryInput,
													onChange: (e) => setNewCustomCategoryInput(e.target.value),
													onKeyDown: (e) => {
														if (e.key === "Enter") {
															e.preventDefault();
															handleAddCustomCategory();
														}
													},
													className: "h-9 text-xs font-bold bg-white border-blue-300 focus:border-[#063B78]"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: handleAddCustomCategory,
													className: "px-3 py-2 rounded-lg bg-[#063B78] hover:bg-[#0A4F9E] text-white font-extrabold text-xs shrink-0 shadow-xs",
													children: "+ Add"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => setShowOtherCategoryInput(false),
													className: "p-1 text-slate-400 hover:text-slate-700 text-xs font-bold shrink-0",
													children: "✕"
												})
											]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: (e) => {
												e.stopPropagation();
												setShowOtherCategoryInput(true);
											},
											className: "w-full flex items-center gap-2 px-3 py-2.5 rounded-xl text-xs font-black text-[#063B78] hover:bg-blue-50 transition-colors border-t border-slate-100 mt-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("addNewCategoryPrompt") })]
										})]
									})]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
									children: [!removedStandardFields.includes("trade") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between mb-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-xs font-extrabold text-slate-700 uppercase block",
											children: "Role / Designation"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => handleRemoveStandardField("trade"),
											className: "text-rose-500 hover:text-rose-700 text-[11px] font-bold flex items-center gap-1 hover:bg-rose-50 px-1.5 py-0.5 rounded transition-colors",
											title: t("removeField"),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), " Remove"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: t("designationPlaceholder"),
										value: workerForm.trade,
										onChange: (e) => setWorkerForm((p) => ({
											...p,
											trade: e.target.value
										})),
										className: "h-11 rounded-xl text-xs font-bold border-slate-300"
									})] }) : null, !removedStandardFields.includes("mobile") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between mb-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-xs font-extrabold text-slate-700 uppercase block",
											children: "Mobile Number"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => handleRemoveStandardField("mobile"),
											className: "text-rose-500 hover:text-rose-700 text-[11px] font-bold flex items-center gap-1 hover:bg-rose-50 px-1.5 py-0.5 rounded transition-colors",
											title: t("removeField"),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), " Remove"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: "e.g. 9822112233",
										value: workerForm.mobile,
										onChange: (e) => setWorkerForm((p) => ({
											...p,
											mobile: e.target.value
										})),
										className: "h-11 rounded-xl text-xs font-bold border-slate-300"
									})] }) : null]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-3 p-4 bg-slate-50/90 rounded-2xl border border-slate-200",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-xs font-extrabold text-slate-800 uppercase block tracking-wider",
										children: "Work Location & Attendance Type (Auto-Detected)"
									}), attendanceMode === "field" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3.5 bg-amber-50 rounded-xl border border-amber-200/90 space-y-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 text-xs font-black text-amber-950",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-amber-500 animate-pulse shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("fieldWorksiteOption") })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] text-amber-900/90 font-medium leading-relaxed",
											children: "Auto-detected from company name. Mobile GPS & selfie punch-in are not required. Daily attendance will be marked directly by employer."
										})]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3.5 bg-blue-50/90 rounded-xl border border-blue-200/90 space-y-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2 text-xs font-black text-[#063B78]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-blue-600 animate-pulse shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("fixedWorksiteOption") })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] text-blue-900/90 font-medium leading-relaxed",
												children: "Auto-detected from company name. Employee punches in/out via mobile app (GPS + Camera)."
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "pt-3 border-t border-blue-200/70",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
														className: "text-xs font-extrabold text-slate-700 uppercase mb-1 block",
														children: "Employee Login 4-Digit PIN *"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														required: true,
														placeholder: "1234",
														maxLength: 4,
														minLength: 4,
														value: workerForm.pin,
														onChange: (e) => setWorkerForm((p) => ({
															...p,
															pin: e.target.value.replace(/\D/g, "")
														})),
														className: "h-10 w-44 rounded-xl text-xs font-black border-slate-300 tracking-widest text-[#063B78]"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-[10px] text-slate-500 mt-1 font-semibold",
														children: "Employee uses Mobile Number and this 4-digit PIN to login to the app."
													})
												]
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-xs font-extrabold text-slate-700 uppercase mb-1 block",
										children: "Custom Daily Wage Rate (₹) *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "text",
										inputMode: "numeric",
										required: true,
										placeholder: "500",
										value: workerForm.dailyRate,
										onChange: (e) => {
											const val = e.target.value.replace(/\D/g, "");
											setWorkerForm((p) => {
												const next = {
													...p,
													dailyRate: val
												};
												if (p.overtimeRateMode === "auto") {
													const baseHrs = computeHoursFromTimes(p.workShiftStart, p.workShiftEnd);
													const rateNum = Number(val) || 0;
													next.overtimeRate = baseHrs > 0 ? Math.round(rateNum / baseHrs).toString() : "0";
												}
												return next;
											});
										},
										className: "h-11 rounded-xl text-xs font-bold border-slate-300 text-emerald-700 font-black"
									})] }), !removedStandardFields.includes("joiningDate") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between mb-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-xs font-extrabold text-slate-700 uppercase block",
											children: "Joining Date"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => handleRemoveStandardField("joiningDate"),
											className: "text-rose-500 hover:text-rose-700 text-[11px] font-bold flex items-center gap-1 hover:bg-rose-50 px-1.5 py-0.5 rounded transition-colors",
											title: t("removeField"),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), " Remove"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: workerForm.joiningDate,
										onChange: (e) => setWorkerForm((p) => ({
											...p,
											joiningDate: e.target.value
										})),
										className: "h-11 rounded-xl text-xs font-bold border-slate-300"
									})] }) : null]
								}),
								!removedStandardFields.includes("shiftTimes") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
										className: "text-xs font-extrabold text-slate-700 uppercase mb-1 flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5 text-[#063B78]" }), " Work Start Time (shift)"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "time",
										value: workerForm.workShiftStart,
										onChange: (e) => {
											const startVal = e.target.value;
											setWorkerForm((p) => {
												const next = {
													...p,
													workShiftStart: startVal
												};
												const newBaseHrs = computeHoursFromTimes(startVal, p.workShiftEnd);
												const oldBaseHrs = computeHoursFromTimes(p.workShiftStart, p.workShiftEnd);
												const prevTotal = Number(p.dailyWorkingHours) || oldBaseHrs;
												next.dailyWorkingHours = (newBaseHrs + Math.max(0, Math.min(4, Math.round((prevTotal - oldBaseHrs) * 10) / 10))).toString();
												if (p.overtimeRateMode === "auto") {
													const rateNum = Number(p.dailyRate) || 500;
													next.overtimeRate = newBaseHrs > 0 ? Math.round(rateNum / newBaseHrs).toString() : "50";
												}
												return next;
											});
										},
										className: "h-11 rounded-xl text-xs font-bold border-slate-300"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between mb-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
											className: "text-xs font-extrabold text-slate-700 uppercase flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5 text-[#063B78]" }), " Work End Time (shift)"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => handleRemoveStandardField("shiftTimes"),
											className: "text-rose-500 hover:text-rose-700 text-[11px] font-bold flex items-center gap-1 hover:bg-rose-50 px-1.5 py-0.5 rounded transition-colors",
											title: t("removeField"),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), " Remove"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "time",
										value: workerForm.workShiftEnd,
										onChange: (e) => {
											const endVal = e.target.value;
											setWorkerForm((p) => {
												const next = {
													...p,
													workShiftEnd: endVal
												};
												const newBaseHrs = computeHoursFromTimes(p.workShiftStart, endVal);
												const oldBaseHrs = computeHoursFromTimes(p.workShiftStart, p.workShiftEnd);
												const prevTotal = Number(p.dailyWorkingHours) || oldBaseHrs;
												next.dailyWorkingHours = (newBaseHrs + Math.max(0, Math.min(4, Math.round((prevTotal - oldBaseHrs) * 10) / 10))).toString();
												if (p.overtimeRateMode === "auto") {
													const rateNum = Number(p.dailyRate) || 500;
													next.overtimeRate = newBaseHrs > 0 ? Math.round(rateNum / newBaseHrs).toString() : "50";
												}
												return next;
											});
										},
										className: "h-11 rounded-xl text-xs font-bold border-slate-300"
									})] })]
								}) : null,
								(() => {
									const baseShiftHrs = computeHoursFromTimes(workerForm.workShiftStart, workerForm.workShiftEnd);
									const dailyWageNum = Number(workerForm.dailyRate) || 500;
									const autoHourlyRate = baseShiftHrs > 0 ? Math.round(dailyWageNum / baseShiftHrs) : 56;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4 rounded-2xl bg-gradient-to-br from-amber-50/80 via-blue-50/40 to-slate-50 border-2 border-amber-200 shadow-xs space-y-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-center justify-between gap-2 border-b border-amber-200/80 pb-2.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "size-7 rounded-lg bg-amber-500 text-white flex items-center justify-center font-black text-xs shadow-xs",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-4 fill-white" })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
													className: "text-xs font-black text-[#10233F] uppercase tracking-wide flex items-center gap-1.5",
													children: ["Overtime Hourly Rate (₹ / hr)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
														className: "bg-amber-100 text-amber-900 border-amber-300 font-extrabold text-[10px] px-1.5 py-0",
														children: workerForm.overtimeRateMode === "auto" ? `⚡ Auto (${dailyWageNum} ÷ ${baseShiftHrs}h = ₹${autoHourlyRate}/hr)` : "✏️ Custom Manual Rate"
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-[10px] font-bold text-slate-500",
													children: [
														"Daily Wage (₹",
														dailyWageNum,
														") ÷ Shift (",
														baseShiftHrs,
														"h) = ₹",
														autoHourlyRate,
														"/hr default rate."
													]
												})] })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center bg-white p-0.5 rounded-xl border border-amber-300 shadow-2xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: () => {
														setWorkerForm((p) => ({
															...p,
															overtimeRateMode: "auto",
															overtimeRate: autoHourlyRate.toString()
														}));
													},
													className: `px-2.5 py-1 rounded-lg text-[11px] font-black transition-all flex items-center gap-1 cursor-pointer ${workerForm.overtimeRateMode === "auto" ? "bg-amber-500 text-white shadow-xs" : "text-slate-600 hover:text-slate-900"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-3 fill-current" }), " Auto Calculate"]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: () => {
														setWorkerForm((p) => ({
															...p,
															overtimeRateMode: "manual"
														}));
													},
													className: `px-2.5 py-1 rounded-lg text-[11px] font-black transition-all flex items-center gap-1 cursor-pointer ${workerForm.overtimeRateMode === "manual" ? "bg-[#063B78] text-white shadow-xs" : "text-slate-600 hover:text-slate-900"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "size-3" }), " Manual Rate"]
												})]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
													className: "text-[11px] font-extrabold text-slate-700 uppercase flex items-center justify-between",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("overtimeRateLabel") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-[10px] text-slate-500 font-bold lowercase",
														children: [
															"(daily wage remains ₹",
															dailyWageNum,
															"/day)"
														]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "relative max-w-sm",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "absolute left-3 top-1/2 -translate-y-1/2 text-sm font-black text-slate-400",
															children: "₹"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
															type: "number",
															placeholder: autoHourlyRate.toString(),
															value: workerForm.overtimeRate,
															onChange: (e) => {
																const val = e.target.value;
																setWorkerForm((p) => ({
																	...p,
																	overtimeRate: val,
																	overtimeRateMode: "manual"
																}));
															},
															className: `h-11 pl-8 pr-16 rounded-xl text-sm font-black border-slate-300 ${workerForm.overtimeRateMode === "auto" ? "bg-amber-50/60 text-amber-950 border-amber-300 font-extrabold" : "bg-white text-emerald-800 border-emerald-400 ring-2 ring-emerald-400/20"}`
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "absolute right-3 top-1/2 -translate-y-1/2 text-xs font-extrabold text-slate-400",
															children: "/ Hour"
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-[10px] font-bold text-slate-500 mt-1",
													children: [
														"💡 Note: Overtime hours (1h, 2h, etc.) are recorded per day in the Attendance Calendar. In Salary Slip, overtime will be calculated as: ",
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
															"Total Overtime Hours × ₹",
															workerForm.overtimeRate || autoHourlyRate,
															"/hr"
														] }),
														"."
													]
												})
											]
										})]
									});
								})(),
								customFields.map((field, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "animate-fade-in pt-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between mb-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
											className: "text-xs font-extrabold text-slate-700 uppercase block flex items-center gap-1.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5 text-[#063B78]" }),
												" ",
												field.label || "CUSTOM FIELD"
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => handleRemoveCustomField(idx),
											className: "text-rose-500 hover:text-rose-700 text-[11px] font-bold flex items-center gap-1 hover:bg-rose-50 px-2 py-0.5 rounded transition-colors",
											title: t("removeField"),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), " Remove Field"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: `e.g. Enter ${field.label || "detail"}...`,
										value: field.value,
										onChange: (e) => handleCustomFieldChange(idx, "value", e.target.value),
										className: "h-11 rounded-xl text-xs font-bold border-slate-300"
									})]
								}, idx)),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-3 pt-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: "outline",
										onClick: () => setShowWorkerModal(false),
										className: "flex-1 py-5 rounded-xl font-bold border-slate-300 text-xs",
										children: "Cancel"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "submit",
										className: "flex-1 py-5 rounded-xl font-black bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg text-xs",
										children: editingWorkerId ? "Update Employee" : "Save Employee"
									})]
								})
							]
						})
					]
				})
			}),
			showAddFieldPrompt && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-60 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white w-full max-w-md rounded-3xl p-6 shadow-2xl border border-slate-100 relative space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setShowAddFieldPrompt(false),
							className: "absolute top-5 right-5 text-slate-400 hover:text-slate-700 font-extrabold text-lg p-1.5 rounded-full hover:bg-slate-100",
							children: "✕"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
							className: "text-lg font-black text-[#10233F] flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-5 text-[#063B78]" }), " Add New Custom Field"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-500 font-semibold mt-0.5",
							children: "Type the field name (e.g. Aadhaar Card ID, Education, PF Number)."
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs font-extrabold text-slate-700 uppercase mb-1 block",
							children: "Field Name / Title *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							autoFocus: true,
							placeholder: t("customFieldPlaceholder"),
							value: newFieldNameInput,
							onChange: (e) => setNewFieldNameInput(e.target.value),
							onKeyDown: (e) => {
								if (e.key === "Enter") {
									e.preventDefault();
									handleConfirmAddCustomField();
								}
							},
							className: "h-11 rounded-xl text-xs font-bold border-slate-300 focus:border-[#063B78]"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] font-bold text-slate-500 uppercase",
								children: t("quickSuggestionsLabel")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-1.5 flex-wrap",
								children: [
									"Aadhaar Card ID",
									"Education",
									"Alternate Mobile",
									"Bank Details",
									"PF Number"
								].map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => handleConfirmAddCustomField(preset),
									className: "px-2.5 py-1 bg-slate-100 hover:bg-[#063B78] hover:text-white text-slate-700 font-bold text-xs rounded-lg transition-colors",
									children: ["+ ", preset]
								}, preset))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-3 pt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								onClick: () => setShowAddFieldPrompt(false),
								className: "flex-1 py-4 rounded-xl font-bold text-xs border-slate-300",
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								onClick: () => handleConfirmAddCustomField(),
								className: "flex-1 py-4 rounded-xl font-black bg-[#063B78] hover:bg-[#0A4F9E] text-white text-xs shadow-md",
								children: "+ Add to Form"
							})]
						})
					]
				})
			}),
			showPackageModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white w-full max-w-xl rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-100 relative max-h-[90vh] overflow-y-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setShowPackageModal(false),
							className: "absolute top-5 right-5 text-slate-400 hover:text-slate-700 font-extrabold text-xl p-2 rounded-full hover:bg-slate-100",
							children: "✕"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 mb-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "p-3 rounded-2xl bg-amber-50 text-[#063B78]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "size-6 text-amber-600" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xl font-black text-[#063B78]",
								children: t("activatePackageTitle")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-slate-500 font-semibold",
								children: t("activatePackageDesc")
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3 my-5",
							children: activeJobPackages.map((pkg) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								onClick: () => setSelectedPlanId(pkg.id),
								className: `p-4 rounded-2xl border-2 transition-all cursor-pointer flex items-center justify-between ${selectedPlanId === pkg.id ? "border-[#063B78] bg-blue-50/60 ring-2 ring-[#063B78]/20" : "border-slate-200 hover:border-slate-300 bg-white"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `size-5 rounded-full border-2 flex items-center justify-center ${selectedPlanId === pkg.id ? "border-[#063B78] bg-[#063B78] text-white" : "border-slate-300"}`,
										children: selectedPlanId === pkg.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3 stroke-[3]" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-extrabold text-sm text-[#063B78]",
											children: pkg.name
										}), pkg.badge && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `text-[10px] font-black px-2 py-0.5 rounded-full uppercase ${pkg.popular ? "bg-[#063B78] text-amber-300" : "bg-amber-100 text-amber-800"}`,
											children: pkg.badge
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-slate-600 font-semibold mt-0.5",
										children: pkg.description || `${pkg.jobCount >= 999 ? "Unlimited Jobs" : `${pkg.jobCount} Job Posting`} + ${pkg.workerCount ? Number(pkg.workerCount) >= 9999 ? "Unlimited CRM" : `${pkg.workerCount} CRM` : "3 CRM"}`
									})] })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-right",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xl font-black text-[#063B78]",
										children: ["₹", pkg.price]
									})
								})]
							}, pkg.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-[#F4F7FB] p-4 rounded-2xl border border-[#DCE5F0] my-4 flex justify-between items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold text-slate-500",
								children: t("selectedPlanLabel")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-extrabold text-[#063B78]",
								children: activeSelectedPlan.name
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-bold text-slate-500",
									children: t("totalAmountLabel")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-2xl font-black text-emerald-700",
									children: ["₹", activeSelectedPlan.price]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 my-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs font-extrabold text-slate-700 uppercase tracking-wider",
									children: "Select Payment Method"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-3 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setPaymentMethod("upi"),
											className: `p-3 rounded-2xl border text-xs font-bold flex flex-col items-center gap-1.5 transition-all ${paymentMethod === "upi" ? "border-[#063B78] bg-blue-50/70 text-[#063B78] ring-2 ring-[#063B78]/20" : "border-slate-200 text-slate-600 hover:bg-slate-50"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("paymentUpi") })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setPaymentMethod("card"),
											className: `p-3 rounded-2xl border text-xs font-bold flex flex-col items-center gap-1.5 transition-all ${paymentMethod === "card" ? "border-[#063B78] bg-blue-50/70 text-[#063B78] ring-2 ring-[#063B78]/20" : "border-slate-200 text-slate-600 hover:bg-slate-50"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("paymentCard") })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setPaymentMethod("netbanking"),
											className: `p-3 rounded-2xl border text-xs font-bold flex flex-col items-center gap-1.5 transition-all ${paymentMethod === "netbanking" ? "border-[#063B78] bg-blue-50/70 text-[#063B78] ring-2 ring-[#063B78]/20" : "border-slate-200 text-slate-600 hover:bg-slate-50"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("paymentNetbanking") })]
										})
									]
								}),
								paymentMethod === "upi" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-xs font-bold text-slate-600 mb-1 block",
										children: "Enter UPI ID (or pay via PhonePe / GPay)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: t("upiPlaceholder"),
										value: upiId,
										onChange: (e) => setUpiId(e.target.value),
										className: "h-11 rounded-xl text-sm font-semibold border-slate-300"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-3 pt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setShowPackageModal(false),
								className: "flex-1 py-6 rounded-2xl font-bold border-slate-300",
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								disabled: isProcessingPackage,
								onClick: handleActivatePackage,
								className: "flex-1 py-6 rounded-2xl font-black bg-[#063B78] hover:bg-[#082F63] text-white shadow-lg",
								children: isProcessingPackage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("activatingStatus") }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"Pay ₹",
									activeSelectedPlan.price,
									" & Post Job"
								] })
							})]
						})
					]
				})
			}),
			selectedWorkerReport && (() => {
				const w = selectedWorkerReport;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white w-full max-w-2xl rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-100 relative max-h-[90vh] overflow-y-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setSelectedWorkerReport(null),
								className: "absolute top-5 right-5 text-slate-400 hover:text-slate-700 font-extrabold text-xl p-2 rounded-full hover:bg-slate-100",
								children: "✕"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-start justify-between border-b border-slate-100 pb-5 mb-5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "size-12 rounded-2xl bg-[#063B78] text-white font-black flex items-center justify-center text-xl shadow-md",
										children: w.name.slice(0, 1).toUpperCase()
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-xl font-black text-[#10233F]",
											children: w.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											className: "bg-emerald-50 text-emerald-800 border border-emerald-200 font-extrabold text-[10px]",
											children: formatCategoryName(w.category || w.trade)
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-[#5B6B7F] font-semibold mt-0.5",
										children: [
											"📞 ",
											w.mobile || "N/A",
											" • Role: ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-bold text-[#063B78]",
												children: w.trade || "General Worker"
											}),
											" • Rate: ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-extrabold text-emerald-700",
												children: [
													"₹",
													w.dailyRate,
													" / day"
												]
											})
										]
									})] })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between bg-[#F8FAFF] p-3 rounded-2xl border border-[#DCE5F0] mb-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-black text-[#10233F] flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "size-4 text-[#063B78]" }), " Select Report Period:"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setWorkerReportPeriod("week"),
											className: `px-3 py-1.5 rounded-xl text-xs font-black transition-all ${workerReportPeriod === "week" ? "bg-[#063B78] text-white shadow-md" : "bg-white text-[#5B6B7F] border border-[#DCE5F0] hover:bg-slate-50"}`,
											children: "This Week"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setWorkerReportPeriod("month"),
											className: `px-3 py-1.5 rounded-xl text-xs font-black transition-all ${workerReportPeriod === "month" ? "bg-[#063B78] text-white shadow-md" : "bg-white text-[#5B6B7F] border border-[#DCE5F0] hover:bg-slate-50"}`,
											children: "This Month"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setWorkerReportPeriod("all"),
											className: `px-3 py-1.5 rounded-xl text-xs font-black transition-all ${workerReportPeriod === "all" ? "bg-[#063B78] text-white shadow-md" : "bg-white text-[#5B6B7F] border border-[#DCE5F0] hover:bg-slate-50"}`,
											children: "All Time"
										})
									]
								})]
							}),
							(() => {
								const metrics = getWorkerReportMetrics(w, workerReportPeriod);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-2 sm:grid-cols-5 gap-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "p-3.5 rounded-2xl border border-emerald-200 bg-emerald-50/60 text-center",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-[10px] font-black uppercase text-emerald-800",
														children: t("present")
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
														className: "text-xl font-black text-emerald-700 mt-1",
														children: [metrics.present, " Days"]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "p-3.5 rounded-2xl border border-amber-200 bg-amber-50/60 text-center",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-[10px] font-black uppercase text-amber-800",
														children: t("halfDay")
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
														className: "text-xl font-black text-amber-700 mt-1",
														children: [metrics.halfDay, " Days"]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "p-3.5 rounded-2xl border border-rose-200 bg-rose-50/60 text-center",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-[10px] font-black uppercase text-rose-800",
														children: t("absent")
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
														className: "text-xl font-black text-rose-700 mt-1",
														children: [metrics.absent, " Days"]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "p-3.5 rounded-2xl border border-blue-200 bg-blue-50/60 text-center",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-[10px] font-black uppercase text-blue-800",
														children: t("overtime")
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
														className: "text-xl font-black text-blue-700 mt-1",
														children: [metrics.overtime, " Days"]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "p-3.5 rounded-2xl border border-emerald-300 bg-emerald-100/70 text-center col-span-2 sm:col-span-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-[10px] font-black uppercase text-emerald-900",
														children: t("totalWageLabel")
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
														className: "text-lg font-black text-emerald-800 mt-1",
														children: ["₹", metrics.netPay.toLocaleString("en-IN")]
													})]
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "border border-[#DCE5F0] rounded-2xl overflow-hidden",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "bg-[#F8FAFF] p-3 border-b border-[#DCE5F0] flex items-center justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-xs font-black text-[#10233F]",
													children: [
														"📅 Attendance Log History (",
														metrics.records.length,
														" records)"
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[11px] font-bold text-[#5B6B7F]",
													children: [
														metrics.startDate,
														" to ",
														metrics.endDate
													]
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "max-h-48 overflow-y-auto",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
													className: "w-full text-left border-collapse text-xs",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
														className: "border-b border-[#EBF1F8] bg-slate-50 text-[10px] uppercase font-black text-[#5B6B7F]",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																className: "p-2.5",
																children: "Date"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																className: "p-2.5",
																children: t("status")
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																className: "p-2.5",
																children: "Rate"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																className: "p-2.5 text-right",
																children: t("earnedWageLabel")
															})
														]
													}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
														className: "divide-y divide-[#EBF1F8] font-semibold",
														children: metrics.records.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															colSpan: 4,
															className: "p-4 text-center text-slate-400 font-bold",
															children: "No attendance records found for this timeframe."
														}) }) : metrics.records.map((r) => {
															let pay = w.dailyRate;
															if (r.status === "HalfDay") pay = Math.round(w.dailyRate / 2);
															if (r.status === "Absent") pay = 0;
															if (r.status === "Overtime") pay = Math.round(w.dailyRate * 1.5);
															return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
																className: "hover:bg-slate-50",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																		className: "p-2.5 font-bold text-[#10233F]",
																		children: r.date
																	}),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																		className: "p-2.5",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																			className: `text-[10px] font-extrabold px-2 py-0.5 rounded-full ${r.status === "Present" ? "bg-emerald-100 text-emerald-800" : r.status === "HalfDay" ? "bg-amber-100 text-amber-800" : r.status === "Absent" ? "bg-rose-100 text-rose-800" : "bg-blue-100 text-blue-800"}`,
																			children: r.status
																		})
																	}),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																		className: "p-2.5 text-slate-500",
																		children: ["₹", w.dailyRate]
																	}),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																		className: "p-2.5 text-right font-black text-emerald-700",
																		children: ["₹", pay]
																	})
																]
															}, r.id);
														})
													})]
												})
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "pt-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												onClick: () => {
													setViewSlipWorker(w);
													setViewSlipPeriod(workerReportPeriod === "all" ? "month" : workerReportPeriod);
												},
												className: "w-full bg-[#063B78] hover:bg-[#082F63] text-white font-extrabold text-xs py-5 rounded-xl shadow-md flex items-center justify-center gap-2 cursor-pointer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4" }), " View & Download Payslip"]
											})
										})
									]
								});
							})()
						]
					})
				});
			})(),
			viewSlipWorker && (() => {
				const v = viewSlipWorker;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in print:bg-white print:p-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white w-full max-w-3xl rounded-3xl shadow-2xl border border-slate-100 relative max-h-[90vh] overflow-y-auto print:max-h-none print:shadow-none print:border-none print:rounded-none",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "print:hidden sticky top-0 bg-white border-b border-slate-100 px-6 py-4 flex items-center justify-between z-10 rounded-t-3xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-black text-[#10233F] text-lg",
										children: t("employeeSalarySlipsTitle")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex bg-slate-100 rounded-lg p-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => setViewSlipPeriod("week"),
											className: `text-xs px-3 py-1 font-bold rounded-md ${viewSlipPeriod === "week" ? "bg-white shadow-sm text-[#063B78]" : "text-slate-500"}`,
											children: t("salarySlipPeriodWeek")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => setViewSlipPeriod("month"),
											className: `text-xs px-3 py-1 font-bold rounded-md ${viewSlipPeriod === "month" ? "bg-white shadow-sm text-[#063B78]" : "text-slate-500"}`,
											children: t("salarySlipPeriodMonth")
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										value: selectedSalaryMonth,
										onChange: (e) => setSelectedSalaryMonth(e.target.value),
										className: "h-8 px-2.5 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-200 text-xs font-black text-[#063B78] focus:outline-none cursor-pointer",
										children: [
											"January",
											"February",
											"March",
											"April",
											"May",
											"June",
											"July",
											"August",
											"September",
											"October",
											"November",
											"December"
										].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: m,
											children: m
										}, m))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										value: selectedSalaryYear,
										onChange: (e) => setSelectedSalaryYear(e.target.value),
										className: "h-8 px-2.5 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-200 text-xs font-black text-[#063B78] focus:outline-none cursor-pointer",
										children: [
											"2023",
											"2024",
											"2025",
											"2026",
											"2027",
											"2028"
										].map((y) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: y,
											children: y
										}, y))
									}),
									viewSlipPeriod === "week" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5 bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-200 text-xs",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-black text-slate-600 text-[11px]",
												children: t("datesLabel")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
												value: slipRangeStartDay,
												onChange: (e) => {
													const v = Number(e.target.value);
													setSlipRangeStartDay(v);
													if (v > slipRangeEndDay) setSlipRangeEndDay(v);
												},
												className: "h-7 px-1.5 bg-white rounded border border-slate-200 text-xs font-black text-[#063B78] cursor-pointer",
												children: Array.from({ length: 31 }, (_, i) => i + 1).map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
													value: d,
													children: ["Day ", d]
												}, d))
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-bold text-slate-400",
												children: t("toWord")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
												value: slipRangeEndDay,
												onChange: (e) => {
													const v = Number(e.target.value);
													setSlipRangeEndDay(v);
													if (v < slipRangeStartDay) setSlipRangeStartDay(v);
												},
												className: "h-7 px-1.5 bg-white rounded border border-slate-200 text-xs font-black text-[#063B78] cursor-pointer",
												children: Array.from({ length: 31 }, (_, i) => i + 1).map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
													value: d,
													children: ["Day ", d]
												}, d))
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => {
													setSlipRangeStartDay(10);
													setSlipRangeEndDay(20);
												},
												className: `ml-1 px-2 py-0.5 rounded text-[10px] font-black cursor-pointer border ${slipRangeStartDay === 10 && slipRangeEndDay === 20 ? "bg-[#063B78] text-white border-[#063B78]" : "bg-white text-slate-600 border-slate-200 hover:bg-slate-100"}`,
												title: "Set 10 to 20",
												children: "10-20"
											})
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setViewSlipWorker(null),
									className: "text-slate-400 hover:text-slate-700 font-extrabold text-xl p-1 rounded-full hover:bg-slate-100 cursor-pointer",
									title: t("closeBtn"),
									children: "✕"
								})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "bg-white overflow-hidden relative",
							children: (() => {
								const effectiveMonthName = selectedSalaryMonth || (/* @__PURE__ */ new Date()).toLocaleDateString("en-US", { month: "long" });
								const effectiveYearStr = selectedSalaryYear || String((/* @__PURE__ */ new Date()).getFullYear());
								const monthMap = {
									January: 0,
									February: 1,
									March: 2,
									April: 3,
									May: 4,
									June: 5,
									July: 6,
									August: 7,
									September: 8,
									October: 9,
									November: 10,
									December: 11
								};
								const mIdx = monthMap[effectiveMonthName] !== void 0 ? monthMap[effectiveMonthName] : (/* @__PURE__ */ new Date()).getMonth();
								const yVal = parseInt(effectiveYearStr, 10) || (/* @__PURE__ */ new Date()).getFullYear();
								const daysInTargetMonth = new Date(yVal, mIdx + 1, 0).getDate();
								const isCustomRange = viewSlipPeriod === "week";
								const startDay = isCustomRange ? Math.min(slipRangeStartDay, slipRangeEndDay, daysInTargetMonth) : 1;
								const endDay = isCustomRange ? Math.min(Math.max(slipRangeStartDay, slipRangeEndDay), daysInTargetMonth) : daysInTargetMonth;
								const customStartDate = `${yVal}-${String(mIdx + 1).padStart(2, "0")}-${String(startDay).padStart(2, "0")}`;
								const customEndDate = `${yVal}-${String(mIdx + 1).padStart(2, "0")}-${String(endDay).padStart(2, "0")}`;
								const customPayPeriod = `${String(startDay).padStart(2, "0")}-${String(mIdx + 1).padStart(2, "0")}-${yVal} to ${String(endDay).padStart(2, "0")}-${String(mIdx + 1).padStart(2, "0")}-${yVal}`;
								const metrics = getWorkerReportMetrics(v, viewSlipPeriod, effectiveMonthName, effectiveYearStr, isCustomRange ? customStartDate : void 0, isCustomRange ? customEndDate : void 0);
								const empCompanyName = currentUser?.fullName || currentUser?.companyName || "REAL JOB Construction Pvt. Ltd.";
								const empCompanyAddress = currentUser?.location || "MIDC Industrial Area, Pune, Maharashtra 411026";
								const empIndustry = currentUser?.industry || "Building Better Opportunities";
								const rate = v.dailyRate || 600;
								const pDays = metrics.present;
								const hdDays = metrics.halfDay;
								const aDays = metrics.absent;
								const otDays = metrics.overtime;
								const otHours = metrics.totalOvertimeHours;
								const shiftH = computeHoursFromTimes(v.workShiftStart, v.workShiftEnd) || 9;
								const effectiveOtRate = v.overtimeRate !== void 0 && v.overtimeRate !== null && Number(v.overtimeRate) > 0 ? Number(v.overtimeRate) : Math.round(rate / shiftH);
								const basic = pDays * rate + Math.round(hdDays * (rate / 2));
								const daAmt = Math.round(basic * .2);
								const hraAmt = Math.round(basic * .1667);
								const otAmt = Math.round(otHours * effectiveOtRate);
								const pfAmt = Math.round((basic + daAmt) * .12);
								const esiAmt = Math.round((basic + daAmt + hraAmt + otAmt) * .0075);
								const recordsMap = /* @__PURE__ */ new Map();
								metrics.records.forEach((r) => recordsMap.set(r.date, r));
								const weekdays = [
									"Sun",
									"Mon",
									"Tue",
									"Wed",
									"Thu",
									"Fri",
									"Sat"
								];
								const attendanceGrid = [];
								let weeklyOffCount = 0;
								for (let d = startDay; d <= endDay; d++) {
									const dateStr = `${yVal}-${String(mIdx + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
									const dateObj = new Date(yVal, mIdx, d);
									const wd = weekdays[dateObj.getDay()] || "Mon";
									const isSun = dateObj.getDay() === 0;
									const rec = recordsMap.get(dateStr);
									let status = "-";
									if (rec) {
										if (rec.status === "Present") status = "P";
										else if (rec.status === "Absent") status = "A";
										else if (rec.status === "HalfDay") status = "HD";
										else if (rec.status === "Overtime") status = "OT";
									} else if (isSun) {
										status = "WO";
										weeklyOffCount++;
									}
									attendanceGrid.push({
										day: d,
										weekday: wd,
										status
									});
								}
								const totalDaysInSelection = endDay - startDay + 1;
								const totalWorkHours = pDays * 8 + hdDays * 4 + otHours;
								const totalEarningsDays = pDays + weeklyOffCount + hdDays * .5;
								const otDatesText = otDays > 0 && metrics.overtimeEntries && metrics.overtimeEntries.length > 0 ? metrics.overtimeEntries.map((e) => `${String(e.day).padStart(2, "0")} ${effectiveMonthName.slice(0, 3)} (${e.overtimeHours}h OT)`).join(", ") : void 0;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SalarySlip, {
									companyName: empCompanyName,
									companyAddress: empCompanyAddress,
									companyTagline: empIndustry,
									employeeName: v.name,
									mobile: v.mobile || "9876543210",
									designation: v.trade || "Worker",
									department: v.category || "Construction",
									location: currentUser?.location || "Site - Pune",
									joiningDate: v.joiningDate || "01-08-2026",
									month: effectiveMonthName,
									year: effectiveYearStr,
									payPeriod: isCustomRange ? customPayPeriod : void 0,
									totalDaysInMonth: totalDaysInSelection,
									presentDays: pDays,
									absentDays: aDays,
									halfDays: hdDays,
									weeklyOffDays: weeklyOffCount,
									publicHolidays: 0,
									dailyRate: rate,
									basicSalary: basic,
									da: daAmt,
									hra: hraAmt,
									overtimeHours: otHours,
									overtimeRate: effectiveOtRate,
									overtimePay: otAmt,
									providentFund: pfAmt,
									esi: esiAmt,
									professionalTax: 200,
									attendanceGrid,
									absentDatesText: aDays > 0 ? `(${aDays} days absent)` : "No absent days recorded",
									halfDayDatesText: hdDays > 0 ? `(${hdDays} half days)` : "No half days recorded",
									overtimeDatesText: otDatesText,
									overtimeEntries: metrics.overtimeEntries,
									totalWorkHours,
									totalEarningsDays
								});
							})()
						})]
					})
				});
			})(),
			calendarWorker && (() => {
				const activeEmpId = currentUser?.id || currentUser?.fullName || currentUser?.email || empIdentifier;
				const monthNames = [
					"January",
					"February",
					"March",
					"April",
					"May",
					"June",
					"July",
					"August",
					"September",
					"October",
					"November",
					"December"
				];
				const daysInMonth = new Date(calendarYear, calendarMonth + 1, 0).getDate();
				const firstDayOfWeek = new Date(calendarYear, calendarMonth, 1).getDay();
				const monthStartStr = `${calendarYear}-${String(calendarMonth + 1).padStart(2, "0")}-01`;
				const monthEndStr = `${calendarYear}-${String(calendarMonth + 1).padStart(2, "0")}-${String(daysInMonth).padStart(2, "0")}`;
				const activeWorker = workers.find((w) => w.id === calendarWorker.id) || calendarWorker;
				const shiftH = computeHoursFromTimes(activeWorker.workShiftStart, activeWorker.workShiftEnd) || 9;
				const effectiveOtRate = activeWorker.overtimeRate !== void 0 && activeWorker.overtimeRate !== null && Number(activeWorker.overtimeRate) > 0 ? Number(activeWorker.overtimeRate) : Math.round(activeWorker.dailyRate / shiftH);
				const monthRangeRecords = dataStore.getEmployerAttendanceRange(activeEmpId, monthStartStr, monthEndStr).filter((r) => r.workerId === activeWorker.id);
				const recordsMap = /* @__PURE__ */ new Map();
				monthRangeRecords.forEach((r) => recordsMap.set(r.date, r));
				let presentCount = 0;
				let halfDayCount = 0;
				let absentCount = 0;
				let overtimeCount = 0;
				let totalOvertimeHours = 0;
				let totalEarned = 0;
				const overtimeDetails = [];
				for (let d = 1; d <= daysInMonth; d++) {
					const dateStr = `${calendarYear}-${String(calendarMonth + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
					const rec = recordsMap.get(dateStr);
					if (rec) {
						if (rec.status === "Present") {
							presentCount++;
							totalEarned += activeWorker.dailyRate;
						} else if (rec.status === "HalfDay") {
							halfDayCount++;
							totalEarned += activeWorker.dailyRate / 2;
						} else if (rec.status === "Absent") absentCount++;
						else if (rec.status === "Overtime") {
							presentCount++;
							overtimeCount++;
							const otH = rec.overtimeHours !== void 0 ? Number(rec.overtimeHours) : 1;
							totalOvertimeHours += otH;
							totalEarned += activeWorker.dailyRate + otH * effectiveOtRate;
							overtimeDetails.push({
								date: dateStr,
								hours: otH
							});
						}
					}
				}
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto animate-in fade-in duration-200",
					onClick: () => setActiveCalendarDate(null),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[94vh] flex flex-col overflow-hidden my-auto",
						onClick: (e) => e.stopPropagation(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-[#021D3D] text-white p-4 sm:p-5 flex items-center justify-between shadow-md",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-11 sm:size-12 rounded-2xl bg-[#063B78] border border-white/20 flex items-center justify-center text-lg sm:text-xl font-black text-amber-300 shadow-inner",
									children: activeWorker.name.charAt(0).toUpperCase()
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-base sm:text-lg font-black tracking-tight",
									children: activeWorker.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2 text-xs text-white/80 mt-0.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1",
											children: ["✂️ ", activeWorker.category || activeWorker.trade || "कर्मचारी"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: activeWorker.trade || "General Worker" }),
										activeWorker.mobile && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1 text-emerald-400 font-bold",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3" }),
												" ",
												activeWorker.mobile
											]
										})] })
									]
								})] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => {
										setCalendarWorker(null);
										setActiveCalendarDate(null);
										setOvertimeModalDate(null);
									},
									className: "size-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center font-bold text-lg transition-all cursor-pointer",
									title: t("closeBtn"),
									children: "✕"
								})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 sm:p-6 overflow-y-auto space-y-4 flex-1 bg-white",
							onClick: () => setActiveCalendarDate(null),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center justify-between pb-2 border-b border-slate-100",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => {
													if (calendarMonth === 0) {
														setCalendarMonth(11);
														setCalendarYear(calendarYear - 1);
													} else setCalendarMonth(calendarMonth - 1);
													setActiveCalendarDate(null);
												},
												className: "p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-700 font-bold transition-all cursor-pointer",
												title: t("previousMonthTitle"),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1.5 px-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
													value: calendarMonth,
													onChange: (e) => {
														setCalendarMonth(Number(e.target.value));
														setActiveCalendarDate(null);
													},
													className: "text-xs sm:text-sm font-black text-slate-900 bg-slate-50 border border-slate-200 rounded-lg py-1 px-2 cursor-pointer focus:outline-none",
													children: monthNames.map((m, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
														value: idx,
														children: ["📅 ", m]
													}, m))
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
													value: calendarYear,
													onChange: (e) => {
														setCalendarYear(Number(e.target.value));
														setActiveCalendarDate(null);
													},
													className: "text-xs sm:text-sm font-black text-slate-900 bg-slate-50 border border-slate-200 rounded-lg py-1 px-2 cursor-pointer focus:outline-none",
													children: [
														2023,
														2024,
														2025,
														2026,
														2027,
														2028
													].map((y) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: y,
														children: y
													}, y))
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => {
													if (calendarMonth === 11) {
														setCalendarMonth(0);
														setCalendarYear(calendarYear + 1);
													} else setCalendarMonth(calendarMonth + 1);
													setActiveCalendarDate(null);
												},
												className: "p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-700 font-bold transition-all cursor-pointer",
												title: t("nextMonthTitle"),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
											})
										]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-7 gap-1.5 sm:gap-2.5",
									children: [
										[
											"Sun",
											"Mon",
											"Tue",
											"Wed",
											"Thu",
											"Fri",
											"Sat"
										].map((dayName, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `text-center text-xs py-1.5 ${idx === 0 ? "text-rose-500 font-extrabold" : "text-slate-600 font-extrabold"}`,
											children: dayName
										}, dayName)),
										Array.from({ length: firstDayOfWeek }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "min-h-[72px] sm:min-h-[82px] rounded-2xl bg-slate-50/40 border border-slate-100/60" }, `empty-${i}`)),
										Array.from({ length: daysInMonth }).map((_, i) => {
											const dayNum = i + 1;
											const dateStr = `${calendarYear}-${String(calendarMonth + 1).padStart(2, "0")}-${String(dayNum).padStart(2, "0")}`;
											const rec = recordsMap.get(dateStr);
											const isSelected = activeCalendarDate === dateStr;
											const colIdx = (firstDayOfWeek + i) % 7;
											const isSunday = colIdx === 0;
											const isFuture = dateStr > (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: `relative min-h-[72px] sm:min-h-[82px] p-1.5 sm:p-2 rounded-2xl border flex flex-col justify-between transition-all ${isFuture ? "bg-slate-50/70 border-slate-100 opacity-40 cursor-not-allowed select-none" : isSunday ? "border-slate-100 bg-white hover:border-slate-300" : "border-slate-200 bg-white hover:border-slate-300"} ${isSelected && !isFuture ? "ring-2 ring-[#7C3AED] shadow-lg z-30" : "shadow-2xs"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "flex items-center justify-between",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: `text-xs font-black ${isFuture ? "text-slate-400 font-semibold" : isSunday ? "text-rose-500 font-black" : "text-slate-800 font-extrabold"}`,
														children: dayNum
													})
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "mt-auto relative",
													children: [isFuture ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "w-full flex items-center justify-center py-1 text-[11px] font-bold text-slate-300 select-none cursor-not-allowed",
														title: t("futureDateTitle"),
														children: "--"
													}) : rec?.status === "Present" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														onClick: (e) => {
															e.stopPropagation();
															setActiveCalendarDate(isSelected ? null : dateStr);
														},
														className: "w-full flex items-center justify-center py-1 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 transition-all cursor-pointer",
														title: t("clickToEditPresent"),
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "size-6 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-xs",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5 stroke-[3]" })
														})
													}) : rec?.status === "Absent" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														onClick: (e) => {
															e.stopPropagation();
															setActiveCalendarDate(isSelected ? null : dateStr);
														},
														className: "w-full flex items-center justify-center py-1 rounded-xl bg-rose-50 hover:bg-rose-100 border border-rose-200 transition-all cursor-pointer",
														title: t("clickToEditAbsent"),
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "size-6 rounded-full bg-rose-500 text-white flex items-center justify-center shadow-xs",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5 stroke-[3]" })
														})
													}) : rec?.status === "HalfDay" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														onClick: (e) => {
															e.stopPropagation();
															setActiveCalendarDate(isSelected ? null : dateStr);
														},
														className: "w-full flex items-center justify-center py-1 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200 transition-all cursor-pointer",
														title: t("clickToEditHalfDay"),
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "size-6 rounded-full bg-amber-500 text-white flex items-center justify-center shadow-xs font-black text-[10px]",
															children: "½"
														})
													}) : rec?.status === "Overtime" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														onClick: (e) => {
															e.stopPropagation();
															setActiveCalendarDate(isSelected ? null : dateStr);
														},
														className: "w-full flex flex-col items-center justify-center py-1 px-0.5 sm:px-1 rounded-xl bg-purple-50 hover:bg-purple-100 border border-purple-200 transition-all cursor-pointer gap-0.5 overflow-hidden",
														title: `Present + Overtime: ${rec.overtimeHours || 2} hours - Click to edit`,
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "size-5 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-xs shrink-0 font-black text-[10px]",
															children: "P"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-[9px] sm:text-[10px] font-black text-[#7C3AED] bg-purple-100/90 px-1 py-0.2 rounded truncate max-w-full",
															children: [
																"+",
																rec.overtimeHours || 2,
																"h OT"
															]
														})]
													}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														onClick: (e) => {
															e.stopPropagation();
															setActiveCalendarDate(isSelected ? null : dateStr);
														},
														className: "text-[11px] font-bold text-slate-500 hover:text-blue-700 bg-slate-50 hover:bg-blue-50 border border-slate-200 hover:border-blue-200 rounded-xl py-1 px-2 transition-all w-full text-center cursor-pointer shadow-2xs",
														children: "+ Mark"
													}), isSelected && !isFuture && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: `absolute bottom-full mb-2 w-44 bg-white rounded-2xl p-1.5 shadow-2xl border border-slate-200 z-50 animate-in fade-in zoom-in-95 ${colIdx === 0 ? "left-0" : colIdx === 6 ? "right-0" : "left-1/2 -translate-x-1/2"}`,
														onClick: (e) => e.stopPropagation(),
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
																type: "button",
																onClick: () => {
																	handleMarkAttendance(activeWorker, "Present", dateStr);
																	setActiveCalendarDate(null);
																},
																className: "w-full flex items-center gap-2.5 px-3 py-2 rounded-xl hover:bg-emerald-50 text-slate-800 hover:text-emerald-700 text-xs font-bold transition-all text-left cursor-pointer",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																	className: "size-5 rounded-full bg-emerald-500 text-white flex items-center justify-center shrink-0 shadow-2xs",
																	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3 stroke-[3]" })
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("present") })]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
																type: "button",
																onClick: () => {
																	handleMarkAttendance(activeWorker, "Absent", dateStr);
																	setActiveCalendarDate(null);
																},
																className: "w-full flex items-center gap-2.5 px-3 py-2 rounded-xl hover:bg-rose-50 text-slate-800 hover:text-rose-700 text-xs font-bold transition-all text-left cursor-pointer",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																	className: "size-5 rounded-full bg-rose-500 text-white flex items-center justify-center shrink-0 shadow-2xs",
																	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3 stroke-[3]" })
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("absent") })]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
																type: "button",
																onClick: () => {
																	handleMarkAttendance(activeWorker, "HalfDay", dateStr);
																	setActiveCalendarDate(null);
																},
																className: "w-full flex items-center gap-2.5 px-3 py-2 rounded-xl hover:bg-amber-50 text-slate-800 hover:text-amber-700 text-xs font-bold transition-all text-left cursor-pointer",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																	className: "size-5 rounded-full bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-2xs font-black text-[10px]",
																	children: "½"
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("halfDay") })]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
																type: "button",
																onClick: () => {
																	setActiveCalendarDate(null);
																	setOvertimeModalDate(dateStr);
																	setOvertimeModalHours(rec?.overtimeHours || 1);
																},
																className: "w-full flex items-center gap-2.5 px-3 py-2 rounded-xl bg-purple-50/70 hover:bg-purple-100 text-[#7C3AED] text-xs font-bold transition-all text-left cursor-pointer",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																	className: "size-5 rounded-full bg-[#7C3AED] text-white flex items-center justify-center shrink-0 shadow-2xs",
																	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3" })
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [t("overtime"), " (हजर + OT)"] })]
															}),
															rec && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
																type: "button",
																onClick: () => {
																	dataStore.deleteAttendanceRecord(activeWorker.id, dateStr);
																	loadAttendanceData();
																	setActiveCalendarDate(null);
																	toast.success(`Cleared for ${dateStr}`);
																},
																className: "w-full flex items-center gap-2 px-3 py-1.5 mt-1 border-t border-slate-100 text-slate-400 hover:text-rose-600 text-[11px] font-bold transition-all cursor-pointer",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("clearAttendanceBtn") })]
															})
														]
													})]
												})]
											}, dateStr);
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-[#FAF8FF] border border-purple-100 rounded-2xl p-3 sm:p-3.5 grid grid-cols-2 sm:flex sm:flex-wrap items-center justify-around gap-2.5 text-xs font-bold text-slate-700 mt-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "size-6 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-2xs",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5 stroke-[3]" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-extrabold text-slate-800",
												children: t("present")
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "size-6 rounded-full bg-rose-500 text-white flex items-center justify-center shadow-2xs",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5 stroke-[3]" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-extrabold text-slate-800",
												children: t("absent")
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "size-6 rounded-full bg-amber-500 text-white flex items-center justify-center shadow-2xs font-black text-[10px]",
												children: "½"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-extrabold text-slate-800",
												children: t("halfDay")
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1 bg-emerald-50 border border-emerald-300 rounded-xl px-1.5 py-0.5 shadow-2xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "size-4 rounded-full bg-emerald-500 text-white flex items-center justify-center font-black text-[9px]",
													children: "P"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] font-black text-[#7C3AED] bg-purple-100 px-1 rounded",
													children: "+OT"
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-extrabold text-slate-800",
												children: [t("overtime"), " (हजर + OT)"]
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-gradient-to-br from-slate-900 to-[#063B78] text-white rounded-2xl p-4 sm:p-5 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-xs font-bold text-amber-400",
												children: [
													monthNames[calendarMonth],
													" ",
													calendarYear,
													" — Monthly Attendance Summary"
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-wrap items-center gap-3 text-xs font-extrabold mt-1",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-emerald-400",
														children: [
															"🟢 Present: ",
															presentCount,
															" days"
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-amber-400",
														children: [
															"🟠 Half Day: ",
															halfDayCount,
															" days"
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-rose-400",
														children: [
															"🔴 Absent: ",
															absentCount,
															" days"
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-purple-300",
														children: [
															"🟣 Overtime: ",
															overtimeCount,
															" days (",
															totalOvertimeHours,
															" hrs)"
														]
													})
												]
											}),
											overtimeDetails.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-2.5 pt-2 border-t border-white/15 text-xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-purple-300 font-extrabold block mb-1",
													children: "📅 Overtime Work Log (Date & Hours):"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "flex flex-wrap gap-1.5 max-h-24 overflow-y-auto",
													children: overtimeDetails.map((ot) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "px-2 py-0.5 rounded-md bg-purple-500/25 border border-purple-400/40 text-purple-200 text-[11px] font-bold",
														children: [
															ot.date,
															": ",
															ot.hours,
															"h OT"
														]
													}, ot.date))
												})]
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-4 border-t sm:border-t-0 sm:border-l border-white/20 pt-3 sm:pt-0 sm:pl-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[10px] text-white/70 font-bold uppercase tracking-wider",
											children: t("estTotalSalaryLabel")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-xl sm:text-2xl font-black text-amber-300",
											children: ["₹", Math.round(totalEarned).toLocaleString("en-IN")]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											onClick: () => {
												const mName = monthNames[calendarMonth];
												const yStr = String(calendarYear);
												if (mName) setSelectedSalaryMonth(mName);
												setSelectedSalaryYear(yStr);
												setViewSlipPeriod("month");
												setViewSlipWorker(activeWorker);
												setCalendarWorker(null);
											},
											className: "bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs px-3.5 py-2 rounded-xl shadow-md cursor-pointer",
											children: "🧾 View Salary Slip"
										})]
									})]
								})
							]
						})]
					}), overtimeModalDate && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "fixed inset-0 z-[60] bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in",
						onClick: () => setOvertimeModalDate(null),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 w-full max-w-sm space-y-4 animate-in zoom-in-95",
							onClick: (e) => e.stopPropagation(),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-8 rounded-full bg-[#7C3AED] text-white flex items-center justify-center shadow-sm",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "text-base font-black text-slate-900",
											children: t("overtimeHoursTitle")
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setOvertimeModalDate(null),
										className: "size-7 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center transition-all cursor-pointer font-bold",
										children: "✕"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-black text-slate-700 block mb-2",
									children: "Enter Hours"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center border border-slate-200 rounded-2xl p-2.5 bg-slate-50/50 focus-within:border-[#7C3AED] focus-within:ring-2 focus-within:ring-[#7C3AED]/20 transition-all",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-5 text-slate-400 shrink-0 ml-1 mr-3" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											min: 1,
											max: 16,
											step: .5,
											value: overtimeModalHours,
											onChange: (e) => setOvertimeModalHours(Math.max(1, Math.min(16, Number(e.target.value) || 1))),
											className: "w-full font-black text-base bg-transparent outline-hidden text-slate-900",
											autoFocus: true
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold text-slate-400 mr-2",
											children: t("hoursWord")
										})
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3 pt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setOvertimeModalDate(null),
										className: "flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-700 font-bold text-xs hover:bg-slate-50 transition-all cursor-pointer",
										children: "Cancel"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => {
											handleMarkAttendance(activeWorker, "Overtime", overtimeModalDate, overtimeModalHours);
											setOvertimeModalDate(null);
											toast.success(`Overtime (${overtimeModalHours} hrs) saved for ${overtimeModalDate}`);
										},
										className: "flex-1 py-2.5 rounded-xl bg-[#7C3AED] hover:bg-[#6D28D9] text-white font-black text-xs shadow-md transition-all cursor-pointer",
										children: "Save"
									})]
								})
							]
						})
					})]
				});
			})(),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "md:hidden fixed bottom-0 left-0 right-0 bg-[#021D3D] text-white border-t border-white/10 z-40 px-2 py-1.5 flex items-center justify-around shadow-2xl",
				children: [
					{
						id: "overview",
						label: "Dashboard",
						icon: ChartColumn
					},
					{
						id: "jobs",
						label: "Jobs",
						icon: BriefcaseBusiness,
						count: jobs.length
					},
					{
						id: "applications",
						label: "Applications",
						icon: FileText,
						count: applications.length
					},
					{
						id: "salary",
						label: "E-Salary",
						icon: FileText
					},
					{
						id: "attendance",
						label: "Attendance",
						icon: CalendarCheck
					},
					{
						id: "profile",
						label: "Profile",
						icon: User
					}
				].map((item) => {
					const isActive = activeTab === item.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setActiveTab(item.id),
						className: `flex flex-col items-center gap-0.5 px-2.5 py-1 rounded-xl text-[10px] font-bold transition-all relative ${isActive ? "text-[#FFC400] bg-white/10" : "text-white/60 hover:text-white"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: `size-4.5 ${isActive ? "text-[#FFC400]" : "text-white/60"}` }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate max-w-[68px]",
								children: item.label
							}),
							isActive && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -top-1 size-1 bg-[#FFC400] rounded-full" })
						]
					}, item.id);
				})
			})
		]
	});
}
//#endregion
export { AdminDashboardPage as component };
