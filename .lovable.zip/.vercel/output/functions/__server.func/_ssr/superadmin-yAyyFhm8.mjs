import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button--9UiOy7A.mjs";
import { t as dataStore } from "./data-store-CvMaHmbm.mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { Bt as CircleX, Et as Eye, Gt as ChevronDown, Ht as CircleCheck, Jt as ChartColumn, Kt as Check, Lt as Clock, N as Search, Ut as ChevronUp, V as Phone, X as Mail, Y as MapPin, Z as LogOut, _ as Trash2, bt as Globe, ct as Key, dt as IndianRupee, en as Building2, f as UserCheck, fn as Activity, j as Settings, k as ShieldAlert, on as Bell, r as X, s as Users, tn as Briefcase, wt as FileText } from "../_libs/lucide-react.mjs";
import { t as LanguageSwitcher } from "./LanguageSwitcher-BQTToBxr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/superadmin-yAyyFhm8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SuperAdminPage() {
	const navigate = useNavigate();
	const [activeTab, setActiveTab] = (0, import_react.useState)("dashboard");
	const [isAuthenticated, setIsAuthenticated] = (0, import_react.useState)(false);
	const [username, setUsername] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [dynamicPackages, setDynamicPackages] = (0, import_react.useState)(() => dataStore.getJobPackages());
	const [packagePurchases, setPackagePurchases] = (0, import_react.useState)(() => dataStore.getAllPackagePurchases());
	const handleSavePackages = () => {
		dataStore.saveJobPackages(dynamicPackages);
		toast.success("✅ Job Packages updated! Employer dashboard now uses your live pricing.");
	};
	const [heroTitle, setHeroTitle] = (0, import_react.useState)("Welcome to the\nREAL JOB Portal!");
	const [heroSubtitle, setHeroSubtitle] = (0, import_react.useState)("Right Person • Right Job • Right Opportunity");
	const [heroImages, setHeroImages] = (0, import_react.useState)([
		"https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80",
		"https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&q=80",
		"https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&q=80"
	]);
	const [metrics, setMetrics] = (0, import_react.useState)([
		{
			value: "10,000+",
			label: "Verified Workers"
		},
		{
			value: "5,000+",
			label: "Live Job Openings"
		},
		{
			value: "2,200+",
			label: "Employers"
		},
		{
			value: "0%",
			label: "Zero Commission"
		}
	]);
	const [aboutData, setAboutData] = (0, import_react.useState)({
		image: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&q=80",
		title: "About Our Company",
		description: "REAL JOB is a reliable employment portal that connects job seekers with trusted companies. We focus on creating real opportunities, building successful careers, and supporting growth for individuals and businesses across India."
	});
	const [categories, setCategories] = (0, import_react.useState)([
		{
			label: "Factory Worker",
			iconName: "Factory",
			theme: "blue"
		},
		{
			label: "Construction",
			iconName: "HardHat",
			theme: "yellow"
		},
		{
			label: "Technical Staff",
			iconName: "Wrench",
			theme: "purple"
		},
		{
			label: "Transport & Logistics",
			iconName: "Truck",
			theme: "green"
		},
		{
			label: "Electrician",
			iconName: "Zap",
			theme: "orange"
		},
		{
			label: "Security Guard",
			iconName: "Shield",
			theme: "red"
		},
		{
			label: "Office Staff",
			iconName: "Briefcase",
			theme: "blue"
		}
	]);
	(0, import_react.useEffect)(() => {
		const savedTitle = localStorage.getItem("cms_heroTitle");
		const savedSubtitle = localStorage.getItem("cms_heroSubtitle");
		const savedImages = localStorage.getItem("cms_heroImages");
		const savedMetrics = localStorage.getItem("cms_metrics");
		const savedAbout = localStorage.getItem("cms_aboutData");
		const savedCategories = localStorage.getItem("cms_categories");
		if (savedTitle) setHeroTitle(savedTitle);
		if (savedSubtitle) setHeroSubtitle(savedSubtitle);
		if (savedImages) setHeroImages(JSON.parse(savedImages));
		if (savedMetrics) setMetrics(JSON.parse(savedMetrics));
		if (savedAbout) setAboutData(JSON.parse(savedAbout));
		if (savedCategories) setCategories(JSON.parse(savedCategories));
	}, []);
	const [allJobs, setAllJobs] = (0, import_react.useState)([]);
	const [approvalFilter, setApprovalFilter] = (0, import_react.useState)("pending");
	const [allUsers, setAllUsers] = (0, import_react.useState)([]);
	const [allApplications, setAllApplications] = (0, import_react.useState)([]);
	const [userSearchQuery, setUserSearchQuery] = (0, import_react.useState)("");
	const [userRoleFilter, setUserRoleFilter] = (0, import_react.useState)("all");
	const [appSearchQuery, setAppSearchQuery] = (0, import_react.useState)("");
	const [appStatusFilter, setAppStatusFilter] = (0, import_react.useState)("all");
	const refreshData = () => {
		setAllJobs(dataStore.getAllJobs());
		setAllUsers(dataStore.getRegisteredUserAccounts());
		setAllApplications(dataStore.getAllApplications());
	};
	(0, import_react.useEffect)(() => {
		refreshData();
	}, []);
	const [expandedJobId, setExpandedJobId] = (0, import_react.useState)(null);
	const handleApproveJob = (jobId) => {
		dataStore.updateJobApprovalStatus(jobId, "approved");
		toast.success("✅ Job Approved Successfully! Now live on portal.");
		refreshData();
	};
	const handleRejectJob = (jobId) => {
		dataStore.updateJobApprovalStatus(jobId, "rejected");
		toast.error("❌ Job Posting Rejected.");
		refreshData();
	};
	const handleDeleteJob = (jobId) => {
		dataStore.deleteJob(jobId);
		toast.success("🗑️ Job deleted permanently.");
		refreshData();
	};
	const handleDeleteUser = (userId) => {
		dataStore.deleteRegisteredUser(userId);
		toast.success("🗑️ User account deleted.");
		refreshData();
	};
	const handleDeleteAllUsers = () => {
		if (window.confirm("Are you sure you want to delete ALL registered users?")) {
			dataStore.deleteAllRegisteredUsers();
			toast.success("🗑️ All registered users deleted successfully!");
			refreshData();
		}
	};
	const handleDeleteApplication = (appId) => {
		dataStore.deleteApplication(appId);
		toast.success("🗑️ Application deleted.");
		refreshData();
	};
	const handleDeletePackagePurchase = (txId) => {
		dataStore.deletePackagePurchase(txId);
		setPackagePurchases(dataStore.getAllPackagePurchases());
		toast.success("🗑️ Package purchase transaction deleted!");
	};
	const handleClearPackagePurchases = () => {
		if (window.confirm("Are you sure you want to clear all package purchase history?")) {
			dataStore.clearPackagePurchases();
			setPackagePurchases([]);
			toast.success("🗑️ Package purchase history cleared!");
		}
	};
	const handleClearAllData = () => {
		if (window.confirm("Are you sure you want to remove ALL admin data (Jobs, Applications, Users, Packages)?")) {
			dataStore.clearAllAdminData();
			setPackagePurchases([]);
			toast.success("✅ All admin data removed successfully!");
			refreshData();
		}
	};
	const pendingJobsCount = allJobs.filter((j) => j.approvalStatus === "pending").length;
	const approvedJobsCount = allJobs.filter((j) => j.approvalStatus === "approved" || !j.approvalStatus).length;
	const rejectedJobsCount = allJobs.filter((j) => j.approvalStatus === "rejected").length;
	const displayedJobs = allJobs.filter((j) => {
		if (approvalFilter === "pending") return j.approvalStatus === "pending";
		if (approvalFilter === "approved") return j.approvalStatus === "approved" || !j.approvalStatus;
		if (approvalFilter === "rejected") return j.approvalStatus === "rejected";
		return true;
	});
	const handleImageUpload = (e) => {
		const file = e.target.files?.[0];
		if (file) {
			const reader = new FileReader();
			reader.onloadend = () => {
				const img = new Image();
				img.onload = () => {
					const canvas = document.createElement("canvas");
					const MAX_WIDTH = 800;
					const MAX_HEIGHT = 600;
					let width = img.width;
					let height = img.height;
					if (width > height) {
						if (width > MAX_WIDTH) {
							height *= MAX_WIDTH / width;
							width = MAX_WIDTH;
						}
					} else if (height > MAX_HEIGHT) {
						width *= MAX_HEIGHT / height;
						height = MAX_HEIGHT;
					}
					canvas.width = width;
					canvas.height = height;
					canvas.getContext("2d")?.drawImage(img, 0, 0, width, height);
					const compressedBase64 = canvas.toDataURL("image/webp", .5);
					setHeroImages((prev) => [...prev, compressedBase64]);
				};
				img.src = reader.result;
			};
			reader.readAsDataURL(file);
		}
	};
	const handleAboutImageUpload = (e) => {
		const file = e.target.files?.[0];
		if (file) {
			const reader = new FileReader();
			reader.onloadend = () => {
				const img = new Image();
				img.onload = () => {
					const canvas = document.createElement("canvas");
					const MAX_WIDTH = 800;
					const MAX_HEIGHT = 800;
					let width = img.width;
					let height = img.height;
					if (width > height) {
						if (width > MAX_WIDTH) {
							height *= MAX_WIDTH / width;
							width = MAX_WIDTH;
						}
					} else if (height > MAX_HEIGHT) {
						width *= MAX_HEIGHT / height;
						height = MAX_HEIGHT;
					}
					canvas.width = width;
					canvas.height = height;
					canvas.getContext("2d")?.drawImage(img, 0, 0, width, height);
					const compressedBase64 = canvas.toDataURL("image/jpeg", .7);
					setAboutData((prev) => ({
						...prev,
						image: compressedBase64
					}));
				};
				img.src = reader.result;
			};
			reader.readAsDataURL(file);
		}
	};
	const handleSaveCMS = () => {
		try {
			localStorage.setItem("cms_heroTitle", heroTitle);
			localStorage.setItem("cms_heroSubtitle", heroSubtitle);
			localStorage.setItem("cms_metrics", JSON.stringify(metrics));
			localStorage.setItem("cms_aboutData", JSON.stringify(aboutData));
			localStorage.setItem("cms_categories", JSON.stringify(categories));
			localStorage.setItem("cms_heroImages", JSON.stringify(heroImages));
			toast.success("Landing page content updated successfully!");
		} catch (e) {
			console.error("Failed to save CMS data:", e);
			toast.error("Failed to save! If you uploaded new images, they might be too large (Browser limit is 5MB). Please try uploading smaller images.");
		}
	};
	const [loginBusy, setLoginBusy] = (0, import_react.useState)(false);
	const handleLogin = async (e) => {
		e.preventDefault();
		setLoginBusy(true);
		const SUPERADMIN_EMAIL = "supera@gmail.com";
		const enteredEmail = username.trim().toLowerCase();
		if (enteredEmail !== SUPERADMIN_EMAIL && enteredEmail !== "superadmin") {
			toast.error("❌ Access Denied! Only the Super Admin can access this panel.");
			setLoginBusy(false);
			return;
		}
		const emailToUse = SUPERADMIN_EMAIL;
		try {
			const { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword } = await import("../_libs/firebase.mjs").then((n) => n.t);
			const auth = getAuth();
			try {
				await signInWithEmailAndPassword(auth, emailToUse, password);
			} catch (signInErr) {
				const errCode = signInErr?.code || "";
				if ((errCode === "auth/user-not-found" || errCode === "auth/invalid-credential") && password === "supera123") try {
					await createUserWithEmailAndPassword(auth, emailToUse, password);
				} catch {}
				else throw signInErr;
			}
			setIsAuthenticated(true);
			toast.success("✅ Welcome, Super Administrator!");
		} catch (err) {
			if (password === "supera123") {
				setIsAuthenticated(true);
				toast.success("✅ Welcome, Super Administrator!");
			} else {
				const code = err?.code || "";
				if (code === "auth/wrong-password" || code === "auth/invalid-credential") toast.error("❌ चुकीचा पासवर्ड! Superadmin password is 'supera123'.");
				else if (code === "auth/user-not-found") toast.error("❌ User not found.");
				else if (code === "auth/too-many-requests") toast.error("⚠️ Too many attempts. Please try again later.");
				else toast.error(`Login Failed: ${err?.message || "Unknown error"}`);
			}
		} finally {
			setLoginBusy(false);
		}
	};
	const handleLogout = () => {
		setIsAuthenticated(false);
		toast.success("Superadmin logged out.");
		navigate({ to: "/" });
	};
	const stats = [
		{
			label: "Total Users",
			value: "24,592",
			trend: "+12%",
			color: "text-blue-500",
			bg: "bg-blue-100"
		},
		{
			label: "Active Jobs",
			value: "8,143",
			trend: "+5%",
			color: "text-emerald-500",
			bg: "bg-emerald-100"
		},
		{
			label: "Total Revenue",
			value: "₹4.2M",
			trend: "+18%",
			color: "text-purple-500",
			bg: "bg-purple-100"
		},
		{
			label: "System Health",
			value: "99.9%",
			trend: "Stable",
			color: "text-[#D4AF37]",
			bg: "bg-[#D4AF37]/10"
		}
	];
	if (!isAuthenticated) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-[#021D3D] flex items-center justify-center p-4 font-sans relative overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-[10%] left-[10%] w-96 h-96 bg-[#0A4F9E]/40 rounded-full blur-[100px] pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute bottom-[10%] right-[10%] w-96 h-96 bg-[#D4AF37]/10 rounded-full blur-[100px] pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full max-w-md bg-white rounded-[24px] shadow-2xl overflow-hidden relative z-10 animate-in fade-in zoom-in-95 duration-500 border border-[#0A4F9E]/20",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-8 text-center bg-gradient-to-b from-[#F8FAFF] to-white border-b border-[#E0E8F5]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-16 bg-gradient-to-br from-[#D4AF37] to-[#F1C40F] rounded-2xl flex items-center justify-center shadow-lg shadow-[#D4AF37]/30 mx-auto mb-5 border-[3px] border-white",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-8 text-[#021D3D]" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-2xl font-black text-[#063B78] tracking-tight",
								children: "System Root Login"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-semibold text-[#5B6B7F] mt-1",
								children: "Superadmin Access Only"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleLogin,
						className: "p-8 space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-[11px] font-black text-[#5B6B7F] uppercase tracking-wider mb-2",
								children: "Admin Username"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative group",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "absolute left-4 top-1/2 -translate-y-1/2 size-5 text-[#9DAEC5] group-focus-within:text-[#063B78] transition-colors" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									required: true,
									value: username,
									onChange: (e) => setUsername(e.target.value),
									className: "w-full h-12 pl-12 pr-4 bg-[#F8FAFF] border border-[#DCE5F0] rounded-xl text-sm font-semibold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50 focus:border-[#D4AF37] focus:bg-white transition-all",
									placeholder: "supera@gmail.com"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-[11px] font-black text-[#5B6B7F] uppercase tracking-wider mb-2",
								children: "Secure Password"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative group",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Key, { className: "absolute left-4 top-1/2 -translate-y-1/2 size-5 text-[#9DAEC5] group-focus-within:text-[#063B78] transition-colors" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "password",
									required: true,
									value: password,
									onChange: (e) => setPassword(e.target.value),
									className: "w-full h-12 pl-12 pr-4 bg-[#F8FAFF] border border-[#DCE5F0] rounded-xl text-sm font-semibold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50 focus:border-[#D4AF37] focus:bg-white transition-all",
									placeholder: "••••••••"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "pt-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									disabled: loginBusy,
									className: "w-full h-12 bg-gradient-to-r from-[#063B78] to-[#0A4F9E] hover:from-[#0A4F9E] hover:to-[#063B78] text-white font-black rounded-xl text-sm shadow-lg shadow-[#063B78]/20 transition-all active:scale-95 border-b-[3px] border-[#021D3D] disabled:opacity-50",
									children: loginBusy ? "Authenticating..." : "Authenticate & Access"
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-4 text-center bg-[#F8FAFF] text-[10px] uppercase font-black text-[#9DAEC5] tracking-widest border-t border-[#E0E8F5]",
						children: "Protected by REAL JOB Security"
					})
				]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-[#F0F4FA] flex font-sans",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-64 bg-[#021D3D] text-white flex flex-col hidden md:flex h-screen sticky top-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "p-6 border-b border-white/10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 text-white",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-10 bg-gradient-to-br from-[#D4AF37] to-[#F1C40F] rounded-xl flex items-center justify-center shadow-lg border-[2px] border-white/10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-5 text-[#021D3D]" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-black text-lg leading-none tracking-tight",
							children: "SUPERADMIN"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] text-[#D4AF37] font-bold uppercase tracking-widest",
							children: "Master Control"
						})] })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1 py-6 px-4 space-y-1 overflow-y-auto",
					children: [
						{
							id: "dashboard",
							label: "Dashboard Overview",
							icon: ChartColumn
						},
						{
							id: "job-approvals",
							label: "Job Approvals",
							icon: CircleCheck,
							count: pendingJobsCount
						},
						{
							id: "users-directory",
							label: "Registered Users",
							icon: Users,
							count: allUsers.length
						},
						{
							id: "job-applications",
							label: "Job Applications",
							icon: FileText,
							count: allApplications.length
						},
						{
							id: "packages",
							label: "Job Packages & Pricing",
							icon: IndianRupee
						},
						{
							id: "landing-page",
							label: "Landing Page",
							icon: Globe
						}
					].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setActiveTab(item.id),
						className: `w-full flex items-center justify-between px-4 py-3 rounded-xl text-sm font-bold transition-all duration-200 ${activeTab === item.id ? "bg-[#D4AF37] text-[#021D3D] shadow-md shadow-[#D4AF37]/20" : "text-[#9DAEC5] hover:bg-white/5 hover:text-white"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-4" }), item.label]
						}), item.count ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "px-2 py-0.5 text-[11px] font-black rounded-full bg-amber-500 text-white animate-pulse",
							children: item.count
						}) : null]
					}, item.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "p-4 border-t border-white/10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: handleLogout,
						className: "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold text-[#9DAEC5] hover:bg-red-500/10 hover:text-red-400 transition-all",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), "Sign Out"]
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex-1 flex flex-col min-h-screen overflow-hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "h-20 bg-white border-b border-[#E0E8F5] flex items-center justify-between px-8 sticky top-0 z-30 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-black text-[#063B78] capitalize",
						children: activeTab.replace("-", " ")
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#9DAEC5]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								placeholder: "Global search...",
								className: "w-64 h-10 pl-10 pr-4 rounded-full bg-[#F8FAFF] border border-[#DCE5F0] text-sm font-semibold focus:ring-2 focus:ring-[#D4AF37]/50 focus:border-[#D4AF37] outline-none transition-all text-[#063B78]"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "size-10 bg-[#F8FAFF] border border-[#DCE5F0] rounded-full flex items-center justify-center relative cursor-pointer hover:bg-gray-100 transition-colors",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-5 text-[#5B6B7F]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-2 right-2 size-2 bg-[#D4AF37] rounded-full border border-white" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageSwitcher, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 pl-4 border-l border-[#E0E8F5] cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right hidden sm:block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-bold text-[#063B78]",
									children: "System Root"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] font-bold text-[#D4AF37]",
									children: "Super Administrator"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-10 bg-gradient-to-br from-[#063B78] to-[#0A4F9E] rounded-xl flex items-center justify-center text-white font-black shadow-md border-b-[2px] border-[#021D3D]",
								children: "SR"
							})]
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "flex-1 p-8 overflow-y-auto",
				children: [
					activeTab === "dashboard" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6",
							children: stats.map((stat, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 rounded-2xl shadow-sm border border-[#E0E8F5] flex items-center justify-between group hover:shadow-md transition-all",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-bold text-[#5B6B7F] uppercase tracking-wider mb-2",
										children: stat.label
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-3xl font-black text-[#063B78]",
										children: stat.value
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs font-bold text-emerald-600 mt-2 flex items-center gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3" }),
											" ",
											stat.trend,
											" this month"
										]
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `size-14 rounded-2xl ${stat.bg} ${stat.color} flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-6" })
								})]
							}, idx))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 lg:grid-cols-3 gap-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "lg:col-span-2 bg-white rounded-2xl border border-[#E0E8F5] shadow-sm p-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-lg font-black text-[#063B78]",
										children: "System Performance Map"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "outline",
										size: "sm",
										className: "text-xs font-bold border-[#DCE5F0] text-[#063B78] hover:bg-[#F8FAFF]",
										children: "View Detailed Logs"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "h-64 bg-[#F8FAFF] rounded-xl border border-[#DCE5F0] flex flex-col items-center justify-center text-[#9DAEC5]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-12 mb-3 text-[#DCE5F0]" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-bold text-sm text-[#5B6B7F]",
											children: "All systems operational."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs mt-1",
											children: "Live metrics graph placeholder."
										})
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm p-6 flex flex-col justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-lg font-black text-[#063B78]",
										children: "Active Admin Accounts"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-[#063B78]",
										children: [allUsers.filter((u) => u.role === "admin").length, " Registered"]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-3",
									children: allUsers.filter((u) => u.role === "admin").length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "p-4 text-center border border-dashed border-[#E0E8F5] rounded-xl text-xs text-[#5B6B7F] font-semibold bg-[#F8FAFF]",
										children: "No secondary admin accounts registered."
									}) : allUsers.filter((u) => u.role === "admin").map((admin) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between p-3 rounded-xl bg-[#F8FAFF] border border-[#E0E8F5]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "size-9 bg-[#063B78] text-white rounded-full flex items-center justify-center font-black text-xs",
												children: admin.fullName.charAt(0).toUpperCase()
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-bold text-xs text-[#063B78]",
												children: admin.fullName
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] text-[#5B6B7F]",
												children: admin.email
											})] })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-700",
											children: "Active"
										})]
									}, admin.id))
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "pt-6 border-t border-[#E0E8F5] mt-4 space-y-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										onClick: handleClearAllData,
										variant: "outline",
										className: "w-full text-xs font-bold text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5 mr-1.5" }), " Clear All Data In Admin"]
									})
								})]
							})]
						})]
					}),
					activeTab === "job-approvals" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setApprovalFilter("pending"),
										className: `p-5 rounded-2xl border text-left transition-all ${approvalFilter === "pending" ? "bg-amber-500 text-white border-amber-600 shadow-lg shadow-amber-500/20" : "bg-white border-[#E0E8F5] text-[#063B78] hover:bg-[#F8FAFF]"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between mb-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-black uppercase tracking-wider opacity-90",
													children: "⏳ Pending Approval"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-5" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-3xl font-black",
												children: pendingJobsCount
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs mt-1 opacity-80",
												children: "Jobs awaiting approval"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setApprovalFilter("approved"),
										className: `p-5 rounded-2xl border text-left transition-all ${approvalFilter === "approved" ? "bg-emerald-600 text-white border-emerald-700 shadow-lg shadow-emerald-600/20" : "bg-white border-[#E0E8F5] text-[#063B78] hover:bg-[#F8FAFF]"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between mb-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-black uppercase tracking-wider opacity-90",
													children: "✅ Approved Jobs"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-3xl font-black",
												children: approvedJobsCount
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs mt-1 opacity-80",
												children: "Jobs live on portal"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setApprovalFilter("rejected"),
										className: `p-5 rounded-2xl border text-left transition-all ${approvalFilter === "rejected" ? "bg-red-600 text-white border-red-700 shadow-lg shadow-red-600/20" : "bg-white border-[#E0E8F5] text-[#063B78] hover:bg-[#F8FAFF]"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between mb-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-black uppercase tracking-wider opacity-90",
													children: "❌ Rejected Jobs"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-5" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-3xl font-black",
												children: rejectedJobsCount
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs mt-1 opacity-80",
												children: "Rejected job postings"
											})
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col sm:flex-row sm:items-center justify-between bg-white p-4 rounded-2xl border border-[#E0E8F5] shadow-sm gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-lg font-black text-[#063B78]",
									children: "Job Moderation Queue"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center gap-2 flex-wrap",
									children: [
										{
											id: "pending",
											label: `Pending (${pendingJobsCount})`
										},
										{
											id: "approved",
											label: `Approved (${approvedJobsCount})`
										},
										{
											id: "rejected",
											label: `Rejected (${rejectedJobsCount})`
										},
										{
											id: "all",
											label: `All Jobs (${allJobs.length})`
										}
									].map((btn) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setApprovalFilter(btn.id),
										className: `px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${approvalFilter === btn.id ? "bg-[#063B78] text-white shadow-sm" : "bg-[#F8FAFF] text-[#5B6B7F] hover:bg-[#E0E8F5]"}`,
										children: btn.label
									}, btn.id))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-4",
								children: displayedJobs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white rounded-2xl p-12 border border-[#E0E8F5] text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-12 mx-auto text-[#9DAEC5] mb-3" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "text-base font-black text-[#063B78]",
											children: "No jobs found"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-[#5B6B7F] mt-1",
											children: "There are currently no job postings under this filter."
										})
									]
								}) : displayedJobs.map((j) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm p-6 flex flex-col justify-between gap-4 hover:shadow-md transition-shadow",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col md:flex-row justify-between gap-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex-1 space-y-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-3 flex-wrap",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
															className: "text-lg font-black text-[#063B78]",
															children: j.title
														}),
														j.approvalStatus === "rejected" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "px-2.5 py-0.5 rounded-full bg-red-100 text-red-700 text-xs font-bold flex items-center gap-1",
															children: "❌ Rejected"
														}) : j.approvalStatus === "approved" || !j.approvalStatus ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-700 text-xs font-bold flex items-center gap-1",
															children: "✅ Approved (Live on Portal)"
														}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-xs font-bold flex items-center gap-1 animate-pulse",
															children: "⏳ Pending Super Admin Approval"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "px-2.5 py-0.5 rounded-full bg-[#F8FAFF] border border-[#DCE5F0] text-[#063B78] text-xs font-bold",
															children: j.category
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-4 text-xs font-bold text-[#5B6B7F] flex-wrap pt-1",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "flex items-center gap-1 text-[#063B78]",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3.5" }),
																" ",
																j.company
															]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "flex items-center gap-1 text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-3.5" }),
																" Job Poster: ",
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: j.employerId || j.company })
															]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "flex items-center gap-1",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5" }),
																" ",
																j.location
															]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "flex items-center gap-1 text-emerald-700",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndianRupee, { className: "size-3.5" }),
																" ",
																j.salary
															]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "flex items-center gap-1",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-3.5" }),
																" ",
																j.jobType,
																" (",
																j.vacancies || 1,
																" Vacancies)"
															]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "flex items-center gap-1",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5" }),
																" ",
																j.postedAgo
															]
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-[#5B6B7F] line-clamp-2 pt-2 bg-[#F8FAFF] p-3 rounded-xl border border-[#E0E8F5]",
													children: j.description
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													onClick: () => setExpandedJobId(expandedJobId === j.id ? null : j.id),
													className: "mt-2 inline-flex items-center gap-1.5 text-xs font-bold text-[#063B78] hover:text-[#0A4F9E] hover:underline",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5 text-[#063B78]" }),
														expandedJobId === j.id ? "Hide Submission Details" : "View All Submission Details",
														expandedJobId === j.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-3.5" })
													]
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-row md:flex-col items-center justify-center gap-3 border-t md:border-t-0 md:border-l border-[#E0E8F5] pt-4 md:pt-0 md:pl-6 min-w-[170px]",
											children: [
												j.approvalStatus !== "approved" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
													onClick: () => handleApproveJob(j.id),
													className: "w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs h-10 shadow-sm",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 mr-1" }), "Approve Job"]
												}),
												j.approvalStatus !== "rejected" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
													variant: "outline",
													onClick: () => handleRejectJob(j.id),
													className: "w-full border-amber-200 text-amber-700 hover:bg-amber-50 font-bold text-xs h-9",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4 mr-1" }), "Reject Job"]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
													variant: "outline",
													onClick: () => handleDeleteJob(j.id),
													className: "w-full border-red-200 text-red-600 hover:bg-red-50 font-bold text-xs h-9",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5 mr-1" }), "Delete Job"]
												})
											]
										})]
									}), expandedJobId === j.id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-4 pt-4 border-t border-[#E0E8F5] space-y-4 animate-in fade-in duration-300",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
												className: "text-xs font-black uppercase tracking-wider text-[#063B78] flex items-center gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4 text-[#063B78]" }), " Full Job Posting Inspection Data"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 bg-[#F8FAFF] p-4 rounded-xl border border-[#DCE5F0] text-xs",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
														children: "Job Title"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-bold text-[#063B78]",
														children: j.title
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
														children: "Job Poster Name / Account"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200 inline-block",
														children: j.employerId || j.company
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
														children: "Company Name"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-bold text-[#063B78]",
														children: j.company
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
														children: "Category & Subcategory"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "font-bold text-[#063B78]",
														children: [
															j.category,
															" ",
															j.subcategory ? `• ${j.subcategory}` : ""
														]
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
														children: "Location / City"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-bold text-[#063B78]",
														children: j.location
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
														children: "Salary Package"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "font-bold text-emerald-700",
														children: [
															j.salary,
															" (",
															j.salaryType || "Monthly",
															")"
														]
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
														children: "Vacancies"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "font-bold text-[#063B78]",
														children: [j.vacancies || 1, " Openings"]
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
														children: "Experience Required"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-bold text-[#063B78]",
														children: j.experience || "Freshers / Any"
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
														children: "Qualification / Education"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-bold text-[#063B78]",
														children: j.qualification || "Not specified"
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
														children: "Job Type & Work Mode"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "font-bold text-[#063B78]",
														children: [
															j.jobType,
															" (",
															j.workMode || "On-site",
															")"
														]
													})] })
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "bg-[#F8FAFF] p-4 rounded-xl border border-[#DCE5F0] text-xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] font-bold text-[#5B6B7F] uppercase block mb-1",
													children: "Full Job Description"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-[#063B78] font-medium leading-relaxed whitespace-pre-line",
													children: j.description || "No description provided."
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "bg-[#F8FAFF] p-3 rounded-xl border border-[#DCE5F0]",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] font-bold text-[#5B6B7F] uppercase block mb-1.5",
														children: "Required Skills"
													}), j.requiredSkills && j.requiredSkills.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "flex flex-wrap gap-1.5",
														children: j.requiredSkills.map((sk, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "bg-white px-2 py-0.5 rounded border border-[#DCE5F0] text-[11px] font-bold text-[#063B78]",
															children: sk
														}, idx))
													}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-gray-400 font-semibold text-[11px]",
														children: "None specified"
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "bg-[#F8FAFF] p-3 rounded-xl border border-[#DCE5F0]",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] font-bold text-[#5B6B7F] uppercase block mb-1.5",
														children: "Perks & Benefits"
													}), j.benefits && j.benefits.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "flex flex-wrap gap-1.5",
														children: j.benefits.map((b, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded border border-emerald-200 text-[11px] font-bold",
															children: b
														}, idx))
													}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-gray-400 font-semibold text-[11px]",
														children: "None specified"
													})]
												})]
											})
										]
									})]
								}, j.id))
							})
						]
					}),
					activeTab === "users-directory" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-white p-5 rounded-2xl border border-[#E0E8F5] shadow-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between mb-2 text-[#063B78]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-black uppercase tracking-wider text-[#5B6B7F]",
													children: "Total Registered Users"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-3xl font-black text-[#063B78]",
												children: allUsers.length
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-[#5B6B7F] mt-1",
												children: "Platform wide accounts"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-white p-5 rounded-2xl border border-[#E0E8F5] shadow-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between mb-2 text-emerald-600",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-black uppercase tracking-wider text-[#5B6B7F]",
													children: "Workers / Job Seekers"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-5" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-3xl font-black text-[#063B78]",
												children: allUsers.filter((u) => u.role === "worker").length
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-[#5B6B7F] mt-1",
												children: "Registered worker accounts"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-white p-5 rounded-2xl border border-[#E0E8F5] shadow-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between mb-2 text-indigo-600",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-black uppercase tracking-wider text-[#5B6B7F]",
													children: "Employers / Companies"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-5" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-3xl font-black text-[#063B78]",
												children: allUsers.filter((u) => u.role === "employer" || u.role === "admin").length
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-[#5B6B7F] mt-1",
												children: "Registered company accounts"
											})
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col sm:flex-row sm:items-center justify-between bg-white p-4 rounded-2xl border border-[#E0E8F5] shadow-sm gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative flex-1 max-w-md",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#9DAEC5]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										placeholder: "Search user by name, email or mobile...",
										value: userSearchQuery,
										onChange: (e) => setUserSearchQuery(e.target.value),
										className: "w-full h-10 pl-10 pr-4 rounded-xl bg-[#F8FAFF] border border-[#DCE5F0] text-xs font-bold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 flex-wrap",
									children: [[
										{
											id: "all",
											label: `All Users (${allUsers.length})`
										},
										{
											id: "worker",
											label: `Workers (${allUsers.filter((u) => u.role === "worker").length})`
										},
										{
											id: "employer",
											label: `Employers (${allUsers.filter((u) => u.role === "employer" || u.role === "admin").length})`
										}
									].map((btn) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setUserRoleFilter(btn.id),
										className: `px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${userRoleFilter === btn.id ? "bg-[#063B78] text-white shadow-sm" : "bg-[#F8FAFF] text-[#5B6B7F] hover:bg-[#E0E8F5]"}`,
										children: btn.label
									}, btn.id)), allUsers.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: handleDeleteAllUsers,
										className: "px-3 py-1.5 rounded-lg text-xs font-bold bg-red-100 text-red-700 hover:bg-red-200 transition-all flex items-center gap-1 ml-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), " Remove All Users"]
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "overflow-x-auto",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
										className: "w-full text-left text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
											className: "bg-[#063B78] text-white font-black uppercase text-[11px] tracking-wider",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-4",
													children: "User Details"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-4",
													children: "Email Address"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-4",
													children: "Role / Type"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-4",
													children: "Mobile Number"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-4",
													children: "User ID"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-4 text-right",
													children: "Action"
												})
											] })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
											className: "divide-y divide-[#E0E8F5] font-semibold text-[#10233F]",
											children: allUsers.filter((u) => {
												if (userRoleFilter === "worker") return u.role === "worker";
												if (userRoleFilter === "employer") return u.role === "employer" || u.role === "admin";
												return true;
											}).filter((u) => {
												if (!userSearchQuery.trim()) return true;
												const q = userSearchQuery.toLowerCase();
												return u.fullName.toLowerCase().includes(q) || u.email.toLowerCase().includes(q) || (u.mobile || "").includes(q);
											}).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												colSpan: 6,
												className: "p-8 text-center text-[#5B6B7F] font-bold",
												children: "No registered users match your search query."
											}) }) : allUsers.filter((u) => {
												if (userRoleFilter === "worker") return u.role === "worker";
												if (userRoleFilter === "employer") return u.role === "employer" || u.role === "admin";
												return true;
											}).filter((u) => {
												if (!userSearchQuery.trim()) return true;
												const q = userSearchQuery.toLowerCase();
												return u.fullName.toLowerCase().includes(q) || u.email.toLowerCase().includes(q) || (u.mobile || "").includes(q);
											}).map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
												className: "hover:bg-[#F8FAFF] transition-colors",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-4",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center gap-3",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "size-9 bg-gradient-to-br from-[#063B78] to-[#0A4F9E] text-white font-black rounded-xl flex items-center justify-center text-xs shadow-sm",
																children: u.fullName.charAt(0).toUpperCase()
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
																className: "block font-black text-[#063B78]",
																children: u.fullName
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-[10px] text-[#5B6B7F]",
																children: "Registered User"
															})] })]
														})
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-4 font-bold text-[#063B78]",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center gap-1.5",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-3.5 text-[#5B6B7F]" }), u.email]
														})
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-4",
														children: u.role === "employer" || u.role === "admin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "px-2.5 py-1 rounded-full bg-indigo-100 text-indigo-800 text-[11px] font-black inline-flex items-center gap-1",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3" }), " Employer"]
														}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-black inline-flex items-center gap-1",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-3" }), " Worker / Seeker"]
														})
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-4 font-bold text-[#5B6B7F]",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center gap-1.5",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3.5 text-[#5B6B7F]" }), u.mobile || "Not provided"]
														})
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-4 text-[11px] font-mono font-bold text-[#9DAEC5]",
														children: u.id
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-4 text-right",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															onClick: () => handleDeleteUser(u.id),
															className: "p-2 rounded-lg text-red-500 hover:bg-red-50 hover:text-red-700 transition-colors",
															title: "Delete User",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
														})
													})
												]
											}, u.id))
										})]
									})
								})
							})
						]
					}),
					activeTab === "job-applications" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-4 gap-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-white p-5 rounded-2xl border border-[#E0E8F5] shadow-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-black uppercase tracking-wider text-[#5B6B7F]",
												children: "Total Applications"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-3xl font-black text-[#063B78] mt-2",
												children: allApplications.length
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-[#5B6B7F] mt-1",
												children: "Submitted on portal"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-white p-5 rounded-2xl border border-[#E0E8F5] shadow-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-black uppercase tracking-wider text-amber-700",
												children: "Applied / Under Review"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-3xl font-black text-amber-600 mt-2",
												children: allApplications.filter((a) => a.status === "Applied" || a.status === "Viewed").length
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-[#5B6B7F] mt-1",
												children: "New applications"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-white p-5 rounded-2xl border border-[#E0E8F5] shadow-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-black uppercase tracking-wider text-emerald-700",
												children: "Shortlisted / Selected"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-3xl font-black text-emerald-600 mt-2",
												children: allApplications.filter((a) => a.status === "Shortlisted" || a.status === "Selected").length
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-[#5B6B7F] mt-1",
												children: "Accepted candidates"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-white p-5 rounded-2xl border border-[#E0E8F5] shadow-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-black uppercase tracking-wider text-red-700",
												children: "Rejected Applications"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-3xl font-black text-red-600 mt-2",
												children: allApplications.filter((a) => a.status === "Rejected").length
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-[#5B6B7F] mt-1",
												children: "Declined applications"
											})
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col sm:flex-row sm:items-center justify-between bg-white p-4 rounded-2xl border border-[#E0E8F5] shadow-sm gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative flex-1 max-w-md",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#9DAEC5]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										placeholder: "Search candidate name, email or job title...",
										value: appSearchQuery,
										onChange: (e) => setAppSearchQuery(e.target.value),
										className: "w-full h-10 pl-10 pr-4 rounded-xl bg-[#F8FAFF] border border-[#DCE5F0] text-xs font-bold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center gap-2 flex-wrap",
									children: [
										"all",
										"Applied",
										"Shortlisted",
										"Selected",
										"Rejected"
									].map((st) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setAppStatusFilter(st),
										className: `px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${appStatusFilter === st ? "bg-[#063B78] text-white shadow-sm" : "bg-[#F8FAFF] text-[#5B6B7F] hover:bg-[#E0E8F5]"}`,
										children: st === "all" ? `All (${allApplications.length})` : st
									}, st))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "overflow-x-auto",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
										className: "w-full text-left text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
											className: "bg-[#063B78] text-white font-black uppercase text-[11px] tracking-wider",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-4",
													children: "Candidate Applicant"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-4",
													children: "Applied Job Title"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-4",
													children: "Company Name"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-4",
													children: "Status"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-4",
													children: "Applied Date"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-4 text-right",
													children: "Action"
												})
											] })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
											className: "divide-y divide-[#E0E8F5] font-semibold text-[#10233F]",
											children: allApplications.filter((a) => {
												if (appStatusFilter !== "all" && a.status !== appStatusFilter) return false;
												if (!appSearchQuery.trim()) return true;
												const q = appSearchQuery.toLowerCase();
												return a.candidateName.toLowerCase().includes(q) || a.candidateEmail.toLowerCase().includes(q) || a.jobTitle.toLowerCase().includes(q) || a.companyName.toLowerCase().includes(q);
											}).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												colSpan: 6,
												className: "p-8 text-center text-[#5B6B7F] font-bold",
												children: "No job applications found matching your criteria."
											}) }) : allApplications.filter((a) => {
												if (appStatusFilter !== "all" && a.status !== appStatusFilter) return false;
												if (!appSearchQuery.trim()) return true;
												const q = appSearchQuery.toLowerCase();
												return a.candidateName.toLowerCase().includes(q) || a.candidateEmail.toLowerCase().includes(q) || a.jobTitle.toLowerCase().includes(q) || a.companyName.toLowerCase().includes(q);
											}).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
												className: "hover:bg-[#F8FAFF] transition-colors",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
														className: "p-4",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
															className: "block font-black text-[#063B78]",
															children: a.candidateName
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "text-[11px] text-[#5B6B7F] flex items-center gap-2 mt-0.5",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-3 inline mr-1" }), a.candidateEmail] }), a.candidateMobile && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3 inline mr-1" }), a.candidateMobile] })]
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
														className: "p-4",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
															className: "block font-bold text-[#063B78]",
															children: a.jobTitle
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] text-[#5B6B7F]",
															children: a.location
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-4 font-bold text-[#063B78]",
														children: a.companyName
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-4",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: `px-2.5 py-1 rounded-full text-[11px] font-black inline-flex items-center gap-1 ${a.status === "Selected" ? "bg-emerald-100 text-emerald-800" : a.status === "Shortlisted" ? "bg-amber-100 text-amber-800" : a.status === "Rejected" ? "bg-red-100 text-red-800" : "bg-blue-100 text-blue-800"}`,
															children: a.status
														})
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-4 font-bold text-[#5B6B7F]",
														children: a.appliedDate
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-4 text-right",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															onClick: () => handleDeleteApplication(a.id),
															className: "p-2 rounded-lg text-red-500 hover:bg-red-50 hover:text-red-700 transition-colors",
															title: "Delete Application",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
														})
													})
												]
											}, a.id))
										})]
									})
								})
							})
						]
					}),
					activeTab === "landing-page" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-6 animate-in fade-in duration-500",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white p-6 rounded-2xl border border-[#E0E8F5] shadow-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-lg font-black text-[#063B78] mb-6",
									children: "Landing Page Settings"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "text-sm font-black text-[#063B78] mb-4",
									children: "Hero Banner Images"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 md:grid-cols-4 gap-4",
									children: [heroImages.map((img, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "relative rounded-xl overflow-hidden aspect-video border border-[#DCE5F0]",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: img,
												alt: `Banner ${i}`,
												className: "w-full h-full object-cover"
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
												className: "cursor-pointer flex-1 flex items-center justify-center bg-[#F8FAFF] hover:bg-[#E0E8F5] text-[#063B78] border border-[#DCE5F0] text-xs font-bold py-1.5 rounded-lg transition-colors",
												children: ["Edit Image", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "file",
													accept: "image/*",
													className: "hidden",
													onChange: (e) => {
														const file = e.target.files?.[0];
														if (file) {
															const reader = new FileReader();
															reader.onloadend = () => {
																const newImages = [...heroImages];
																newImages[i] = reader.result;
																setHeroImages(newImages);
															};
															reader.readAsDataURL(file);
														}
													}
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												variant: "outline",
												size: "sm",
												className: "flex-1 h-8 text-xs border-red-200 text-red-600 hover:bg-red-50 hover:text-red-700",
												onClick: () => {
													const newImages = [...heroImages];
													newImages.splice(i, 1);
													setHeroImages(newImages);
												},
												children: "Remove"
											})]
										})]
									}, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "border-2 border-dashed border-[#DCE5F0] hover:border-[#063B78] rounded-xl aspect-video flex flex-col items-center justify-center cursor-pointer transition-colors bg-[#F8FAFF] hover:bg-[#E0E8F5]/50",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[#063B78] font-bold text-sm",
												children: "+ Add Image"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] sm:text-xs text-[#5B6B7F] mt-1 px-2 text-center",
												children: "Click or Drag & Drop"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "file",
												accept: "image/*",
												className: "hidden",
												onChange: handleImageUpload
											})
										]
									})]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 border-t border-[#E0E8F5] pt-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "text-sm font-black text-[#063B78] mb-4",
										children: "Platform Metrics Section"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
										children: metrics.map((metric, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-4 bg-[#F8FAFF] border border-[#DCE5F0] rounded-xl space-y-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "block text-[10px] font-black text-[#5B6B7F] uppercase tracking-wider mb-1",
												children: "Value (e.g. 10,000+)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "text",
												className: "w-full h-9 px-3 bg-white border border-[#DCE5F0] rounded-lg text-sm font-bold text-[#063B78]",
												value: metric.value,
												onChange: (e) => {
													const newMetrics = [...metrics];
													if (newMetrics[i]) {
														newMetrics[i].value = e.target.value;
														setMetrics(newMetrics);
													}
												}
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "block text-[10px] font-black text-[#5B6B7F] uppercase tracking-wider mb-1",
												children: "Label (e.g. Verified Workers)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "text",
												className: "w-full h-9 px-3 bg-white border border-[#DCE5F0] rounded-lg text-sm font-bold text-[#063B78]",
												value: metric.label,
												onChange: (e) => {
													const newMetrics = [...metrics];
													if (newMetrics[i]) {
														newMetrics[i].label = e.target.value;
														setMetrics(newMetrics);
													}
												}
											})] })]
										}, i))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 border-t border-[#E0E8F5] pt-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "text-sm font-black text-[#063B78] mb-4",
										children: "About Company Section"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "block text-[11px] font-black text-[#5B6B7F] uppercase tracking-wider mb-2",
												children: "Company Image"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-col gap-2 max-w-sm",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "relative rounded-xl overflow-hidden aspect-video border border-[#DCE5F0]",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
														src: aboutData.image,
														alt: "About Company",
														className: "w-full h-full object-cover"
													})
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
													className: "cursor-pointer flex items-center justify-center bg-[#F8FAFF] hover:bg-[#E0E8F5] text-[#063B78] border border-[#DCE5F0] text-xs font-bold py-2 rounded-lg transition-colors",
													children: ["Change Image", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
														type: "file",
														accept: "image/*",
														className: "hidden",
														onChange: handleAboutImageUpload
													})]
												})]
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "block text-[11px] font-black text-[#5B6B7F] uppercase tracking-wider mb-2",
												children: "Title"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "text",
												className: "w-full h-10 px-4 bg-[#F8FAFF] border border-[#DCE5F0] rounded-xl text-sm font-semibold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50",
												value: aboutData.title,
												onChange: (e) => setAboutData({
													...aboutData,
													title: e.target.value
												})
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "block text-[11px] font-black text-[#5B6B7F] uppercase tracking-wider mb-2",
												children: "Description"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
												className: "w-full h-24 p-4 bg-[#F8FAFF] border border-[#DCE5F0] rounded-xl text-sm font-semibold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50 resize-none",
												value: aboutData.description,
												onChange: (e) => setAboutData({
													...aboutData,
													description: e.target.value
												})
											})] })
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 border-t border-[#E0E8F5] pt-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between mb-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "text-sm font-black text-[#063B78]",
											children: "Popular Job Categories"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "outline",
											size: "sm",
											className: "border-dashed border-[#063B78]/30 text-[#063B78] font-bold text-xs hover:bg-[#063B78]/5",
											onClick: () => setCategories([...categories, {
												label: "New Category",
												iconName: "Briefcase",
												theme: "blue"
											}]),
											children: "+ Add Category"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3",
										children: categories.map((cat, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3 bg-[#F8FAFF] border border-[#DCE5F0] rounded-xl flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex-1 min-w-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
													className: "block text-[9px] font-black text-[#5B6B7F] uppercase tracking-wider mb-1",
													children: "Label"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "text",
													className: "w-full h-8 px-2.5 bg-white border border-[#DCE5F0] rounded-lg text-xs font-bold text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]/50",
													value: cat.label,
													onChange: (e) => {
														const newCat = [...categories];
														newCat[i].label = e.target.value;
														setCategories(newCat);
													}
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex items-end pt-3",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													variant: "destructive",
													size: "sm",
													className: "h-8 px-2.5 text-[11px] font-bold",
													onClick: () => {
														const newCat = [...categories];
														newCat.splice(i, 1);
														setCategories(newCat);
													},
													children: "Remove"
												})
											})]
										}, i))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 pt-6 flex justify-end gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										onClick: () => {
											localStorage.removeItem("cms_heroTitle");
											localStorage.removeItem("cms_heroSubtitle");
											localStorage.removeItem("cms_heroImages");
											localStorage.removeItem("cms_metrics");
											localStorage.removeItem("cms_aboutData");
											localStorage.removeItem("cms_categories");
											toast.success("CMS reset to defaults! Reloading...");
											setTimeout(() => window.location.reload(), 1e3);
										},
										className: "bg-red-500 hover:bg-red-600 text-white font-bold px-6",
										children: "Reset to Defaults"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										onClick: handleSaveCMS,
										className: "bg-gradient-to-r from-[#063B78] to-[#0A4F9E] text-white font-black px-8",
										children: "Save Changes"
									})]
								})
							]
						})
					}),
					activeTab === "packages" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-8 animate-in fade-in duration-500",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white rounded-2xl p-6 border border-[#E0E8F5] shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
									className: "text-xl font-black text-[#063B78] flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "💼 Dynamic Job Packages & Pricing Control" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs bg-amber-100 text-amber-800 border border-amber-300 font-extrabold px-3 py-1 rounded-full",
										children: "Live Pricing Engine"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold text-[#5B6B7F] mt-1",
									children: "Super Admin can dynamically update prices, job credits, features, or add new packages for all employers."
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										onClick: () => {
											const newPkg = {
												id: `plan-${Date.now()}`,
												name: "Custom Corporate Plan",
												price: 500,
												jobCount: 10,
												badge: "PRO",
												features: [
													"10 Active Job Listings",
													"Priority Listing",
													"Direct Candidates Contact"
												]
											};
											setDynamicPackages([...dynamicPackages, newPkg]);
											toast.info("New package draft created. Click 'Save Packages' to apply.");
										},
										className: "bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs px-4 py-2.5 rounded-xl shadow-sm",
										children: "+ Add New Package"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										onClick: handleSavePackages,
										className: "bg-[#063B78] hover:bg-[#082F63] text-white font-black text-xs px-5 py-2.5 rounded-xl shadow-md",
										children: "💾 Save Package Updates"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6",
								children: dynamicPackages.map((pkg, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white rounded-2xl border-2 border-[#E0E8F5] shadow-sm p-5 space-y-4 flex flex-col justify-between hover:border-[#063B78] transition-all",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[10px] font-black uppercase text-[#063B78] tracking-widest",
													children: ["Plan #", idx + 1]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => {
														const filtered = dynamicPackages.filter((p) => p.id !== pkg.id);
														setDynamicPackages(filtered);
														toast.info(`Removed ${pkg.name}`);
													},
													className: "text-xs text-red-500 hover:text-red-700 font-bold",
													children: "✕ Delete"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "block text-[10px] font-bold text-[#5B6B7F] mb-1",
												children: "Package Name"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "text",
												value: pkg.name,
												onChange: (e) => {
													const updated = [...dynamicPackages];
													updated[idx].name = e.target.value;
													setDynamicPackages(updated);
												},
												className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-bold text-[#10233F]"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid grid-cols-2 gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
													className: "block text-[10px] font-bold text-[#5B6B7F] mb-1",
													children: "Price (₹)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "number",
													value: pkg.price,
													onChange: (e) => {
														const updated = [...dynamicPackages];
														updated[idx].price = Number(e.target.value) || 0;
														setDynamicPackages(updated);
													},
													className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-black text-[#063B78]"
												})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
													className: "block text-[10px] font-bold text-[#5B6B7F] mb-1",
													children: "Job Credits"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "number",
													value: pkg.jobCount,
													onChange: (e) => {
														const updated = [...dynamicPackages];
														updated[idx].jobCount = Number(e.target.value) || 1;
														setDynamicPackages(updated);
													},
													className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-black text-amber-600"
												})] })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "block text-[10px] font-bold text-[#5B6B7F] mb-1",
												children: "Badge Tag"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "text",
												value: pkg.badge || "",
												placeholder: "e.g. BEST VALUE / UNLIMITED",
												onChange: (e) => {
													const updated = [...dynamicPackages];
													updated[idx].badge = e.target.value;
													setDynamicPackages(updated);
												},
												className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-bold text-[#5B6B7F]"
											})] })
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "pt-3 border-t border-[#E0E8F5]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[11px] font-bold text-[#063B78]",
											children: [
												"⚡ ₹",
												pkg.price,
												" for ",
												pkg.jobCount >= 999 ? "Unlimited" : `${pkg.jobCount} Job Credits`
											]
										})
									})]
								}, pkg.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm p-6 space-y-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between flex-wrap gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-lg font-black text-[#063B78]",
										children: "Employer Package Purchases History"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold text-[#5B6B7F]",
										children: "All transactions and active package purchases made by registered employers."
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-xs font-black bg-emerald-100 text-emerald-800 px-3 py-1 rounded-full border border-emerald-300",
											children: [packagePurchases.length, " Total Transactions"]
										}), packagePurchases.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: handleClearPackagePurchases,
											className: "px-3 py-1 rounded-full text-xs font-bold bg-red-100 text-red-700 hover:bg-red-200 transition-all flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), " Clear History"]
										})]
									})]
								}), packagePurchases.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "py-8 text-center border-2 border-dashed border-[#E0E8F5] rounded-xl bg-[#F8FAFF]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndianRupee, { className: "size-10 text-[#9DAEC5] mx-auto mb-2" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-bold text-[#10233F]",
											children: "No package purchases recorded yet"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-[#5B6B7F] mt-1",
											children: "Purchases completed by employers will appear here in real-time."
										})
									]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "overflow-x-auto",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
										className: "w-full text-left text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: "bg-[#F8FAFF] border-b border-[#E0E8F5] text-[#5B6B7F] font-black uppercase tracking-wider",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-3",
													children: "Transaction ID"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-3",
													children: "Employer / User"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-3",
													children: "Package Name"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-3",
													children: "Amount (₹)"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-3",
													children: "Credits Granted"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-3",
													children: "Payment Method"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-3",
													children: "Date"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "p-3 text-right",
													children: "Action"
												})
											]
										}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
											className: "divide-y divide-[#E0E8F5] font-semibold text-[#10233F]",
											children: packagePurchases.map((tx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
												className: "hover:bg-[#F8FAFF] transition-colors",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-3 font-mono text-[11px] text-[#063B78]",
														children: tx.id
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-3 font-bold",
														children: tx.userId
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-3",
														children: tx.planName
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
														className: "p-3 font-black text-emerald-600",
														children: ["₹", tx.price]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-3 font-extrabold text-amber-600",
														children: tx.jobCount >= 999 ? "Unlimited" : tx.jobCount
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-3 font-bold uppercase",
														children: tx.paymentMethod
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-3 text-[#5B6B7F]",
														children: tx.purchaseDate
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "p-3 text-right",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															onClick: () => handleDeletePackagePurchase(tx.id),
															className: "p-1.5 rounded-lg text-red-500 hover:bg-red-50 hover:text-red-700 transition-colors",
															title: "Delete Transaction",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
														})
													})
												]
											}, tx.id))
										})]
									})
								})]
							})
						]
					}),
					activeTab !== "dashboard" && activeTab !== "landing-page" && activeTab !== "job-approvals" && activeTab !== "users-directory" && activeTab !== "job-applications" && activeTab !== "packages" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "h-full flex flex-col items-center justify-center text-[#9DAEC5] animate-in fade-in duration-500",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-16 mb-4 text-[#DCE5F0]" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "text-xl font-black text-[#063B78] mb-2",
								children: [activeTab.charAt(0).toUpperCase() + activeTab.slice(1), " Module"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-semibold text-[#5B6B7F]",
								children: "This module is currently under development."
							})
						]
					})
				]
			})]
		})]
	});
}
//#endregion
export { SuperAdminPage as component };
