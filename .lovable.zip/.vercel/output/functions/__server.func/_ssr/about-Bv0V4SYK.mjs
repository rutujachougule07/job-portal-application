import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n } from "./i18n-BcT9wMyM.mjs";
import { t as Button } from "./button--9UiOy7A.mjs";
import { t as dataStore } from "./data-store-CvMaHmbm.mjs";
import { b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as Sparkles, Ht as CircleCheck, O as ShieldCheck, _t as HardHat, bt as Globe, en as Building2, ht as HeartHandshake, t as Zap, v as Target } from "../_libs/lucide-react.mjs";
import { t as PublicHeader } from "./PublicHeader-CBfbRu9r.mjs";
import { t as PublicFooter } from "./PublicFooter-Ce7-btPc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-Bv0V4SYK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	const { t, n } = useI18n();
	const navigate = useNavigate();
	const user = dataStore.getCurrentUser();
	(0, import_react.useEffect)(() => {
		if (user) if (user.role === "admin" || user.role === "employer") navigate({ to: "/admin" });
		else navigate({ to: "/dashboard" });
	}, [user, navigate]);
	if (user) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "bg-[#F5F8FC] min-h-screen",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "bg-[#063B78] text-white py-20 sm:py-32 relative overflow-hidden",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 left-1/4 w-96 h-96 bg-[#125BB5] rounded-full mix-blend-multiply filter blur-3xl opacity-50 animate-pulse" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute top-0 right-1/4 w-96 h-96 bg-[#FFC400] rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse",
							style: { animationDelay: "2s" }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "max-w-4xl mx-auto text-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-5 py-2 text-xs font-bold uppercase tracking-wider text-[#FFC400] backdrop-blur-md mb-6 shadow-lg",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" }), t("aboutHeroEyebrow")]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
										className: "text-4xl font-black tracking-tight sm:text-6xl lg:text-7xl text-transparent bg-clip-text bg-gradient-to-r from-white via-blue-100 to-white pb-2",
										children: [
											t("heroTitleLine1"),
											" ",
											t("heroTitleLine2"),
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-transparent bg-clip-text bg-gradient-to-r from-[#FFC400] to-yellow-200",
												children: t("heroTitleLine3")
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-8 text-lg sm:text-2xl font-medium text-white/90 leading-relaxed max-w-3xl mx-auto",
										children: t("aboutHeroSub")
									})
								]
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 -mt-12 relative z-20",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 md:grid-cols-4 gap-0 bg-white rounded-3xl shadow-2xl border border-[#DCE5F0] overflow-hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center p-8 border-b md:border-b-0 border-r border-[#DCE5F0] hover:bg-blue-50 transition-colors duration-300",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-4xl sm:text-5xl font-black text-[#063B78]",
									children: n("50,000+")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm font-bold text-[#5B6B7F] mt-2 uppercase tracking-wide",
									children: t("statWorkers")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center p-8 border-b md:border-b-0 md:border-r border-[#DCE5F0] hover:bg-blue-50 transition-colors duration-300",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-4xl sm:text-5xl font-black text-[#125BB5]",
									children: n("10,000+")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm font-bold text-[#5B6B7F] mt-2 uppercase tracking-wide",
									children: t("statEmployers")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center p-8 border-r border-[#DCE5F0] hover:bg-blue-50 transition-colors duration-300",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-4xl sm:text-5xl font-black text-[#063B78]",
									children: n("1,50,000+")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm font-bold text-[#5B6B7F] mt-2 uppercase tracking-wide",
									children: t("statJobs")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center p-8 hover:bg-yellow-50 transition-colors duration-300",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-4xl sm:text-5xl font-black text-[#082F63] px-3 py-1 rounded-lg bg-[#FFC400] inline-block shadow-md",
									children: n("100%")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm font-bold text-[#5B6B7F] mt-2 uppercase tracking-wide",
									children: t("statContact")
								})]
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-20 sm:py-32",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid md:grid-cols-2 gap-10 items-stretch",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "group bg-white rounded-3xl p-10 shadow-lg border border-[#DCE5F0] hover:shadow-2xl hover:border-[#125BB5]/30 hover:-translate-y-2 transition-all duration-300 flex flex-col justify-between overflow-hidden relative",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 right-0 w-32 h-32 bg-blue-50 rounded-bl-full -z-10 group-hover:scale-150 transition-transform duration-500" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "z-10",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "size-16 rounded-2xl bg-gradient-to-br from-[#063B78] to-[#125BB5] text-white flex items-center justify-center mb-8 shadow-lg group-hover:scale-110 transition-transform duration-300",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "size-8" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
												className: "text-3xl font-black text-[#10233F] tracking-tight",
												children: t("ourMission")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-5 text-base font-medium text-[#5B6B7F] leading-relaxed",
												children: t("ourMissionDesc")
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-8 pt-6 border-t border-[#DCE5F0] flex items-center gap-3 text-sm font-bold text-[#063B78] z-10",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "bg-[#FFC400]/20 p-1 rounded-full",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5 text-[#FFC400]" })
											}),
											t("trustCommission"),
											" • ",
											t("trustPhone")
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "group bg-white rounded-3xl p-10 shadow-lg border border-[#DCE5F0] hover:shadow-2xl hover:border-[#FFC400]/50 hover:-translate-y-2 transition-all duration-300 flex flex-col justify-between overflow-hidden relative",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 right-0 w-32 h-32 bg-yellow-50 rounded-bl-full -z-10 group-hover:scale-150 transition-transform duration-500" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "z-10",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "size-16 rounded-2xl bg-gradient-to-br from-[#FFC400] to-yellow-500 text-[#082F63] flex items-center justify-center mb-8 shadow-lg group-hover:scale-110 transition-transform duration-300",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "size-8" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
												className: "text-3xl font-black text-[#10233F] tracking-tight",
												children: t("ourVision")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-5 text-base font-medium text-[#5B6B7F] leading-relaxed",
												children: t("ourVisionDesc")
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-8 pt-6 border-t border-[#DCE5F0] flex items-center gap-3 text-sm font-bold text-[#125BB5] z-10",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "bg-[#FFC400]/20 p-1 rounded-full",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5 text-[#FFC400]" })
										}), t("trustVerified")]
									})
								]
							})]
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "py-20 sm:py-32 bg-white relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5 pointer-events-none" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center max-w-3xl mx-auto mb-20",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-black uppercase tracking-widest text-[#125BB5] bg-[#EBF1F8] px-4 py-1.5 rounded-full shadow-sm",
									children: t("howWorksSimple")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-6 text-4xl font-black text-[#10233F] sm:text-5xl tracking-tight",
									children: t("howWorks")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-lg font-medium text-[#5B6B7F]",
									children: t("howWorksSubtitle")
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid md:grid-cols-2 gap-16",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-gradient-to-b from-[#F5F8FC] to-white p-10 rounded-[2rem] border border-[#DCE5F0] shadow-xl hover:shadow-2xl transition-shadow duration-300",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-5 mb-10",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-14 rounded-2xl bg-[#FFC400] text-[#082F63] flex items-center justify-center font-black shadow-md",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HardHat, { className: "size-7" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-2xl font-black text-[#10233F]",
											children: t("forWorkersTitle")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm font-bold text-[#125BB5]",
											children: t("seekerDesc")
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-8",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "group flex gap-5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "size-12 rounded-2xl bg-white border-2 border-[#063B78] text-[#063B78] font-black text-lg flex items-center justify-center shrink-0 shadow-sm group-hover:bg-[#063B78] group-hover:text-white transition-colors duration-300",
													children: n(1)
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
													className: "font-extrabold text-[#10233F] text-lg",
													children: t("forWorkersStep1Title")
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm text-[#5B6B7F] mt-2 font-medium",
													children: t("forWorkersStep1Desc")
												})] })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "group flex gap-5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "size-12 rounded-2xl bg-white border-2 border-[#063B78] text-[#063B78] font-black text-lg flex items-center justify-center shrink-0 shadow-sm group-hover:bg-[#063B78] group-hover:text-white transition-colors duration-300",
													children: n(2)
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
													className: "font-extrabold text-[#10233F] text-lg",
													children: t("forWorkersStep2Title")
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm text-[#5B6B7F] mt-2 font-medium",
													children: t("forWorkersStep2Desc")
												})] })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "group flex gap-5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "size-12 rounded-2xl bg-white border-2 border-[#063B78] text-[#063B78] font-black text-lg flex items-center justify-center shrink-0 shadow-sm group-hover:bg-[#063B78] group-hover:text-white transition-colors duration-300",
													children: n(3)
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
													className: "font-extrabold text-[#10233F] text-lg",
													children: t("forWorkersStep3Title")
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm text-[#5B6B7F] mt-2 font-medium",
													children: t("forWorkersStep3Desc")
												})] })]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										className: "w-full mt-12 bg-[#FFC400] hover:bg-[#e6b000] text-[#10233F] font-extrabold text-base py-6 rounded-xl shadow-lg hover:shadow-xl transition-all hover:-translate-y-1",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/jobs",
											children: t("jobs")
										})
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-gradient-to-b from-[#F5F8FC] to-white p-10 rounded-[2rem] border border-[#DCE5F0] shadow-xl hover:shadow-2xl transition-shadow duration-300",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-5 mb-10",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-14 rounded-2xl bg-[#063B78] text-white flex items-center justify-center font-black shadow-md",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-7" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-2xl font-black text-[#10233F]",
											children: t("forEmployersTitle")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm font-bold text-[#125BB5]",
											children: t("employerDesc")
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-8",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "group flex gap-5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "size-12 rounded-2xl bg-white border-2 border-[#125BB5] text-[#125BB5] font-black text-lg flex items-center justify-center shrink-0 shadow-sm group-hover:bg-[#125BB5] group-hover:text-white transition-colors duration-300",
													children: n(1)
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
													className: "font-extrabold text-[#10233F] text-lg",
													children: t("forEmployersStep1Title")
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm text-[#5B6B7F] mt-2 font-medium",
													children: t("forEmployersStep1Desc")
												})] })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "group flex gap-5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "size-12 rounded-2xl bg-white border-2 border-[#125BB5] text-[#125BB5] font-black text-lg flex items-center justify-center shrink-0 shadow-sm group-hover:bg-[#125BB5] group-hover:text-white transition-colors duration-300",
													children: n(2)
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
													className: "font-extrabold text-[#10233F] text-lg",
													children: t("forEmployersStep2Title")
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm text-[#5B6B7F] mt-2 font-medium",
													children: t("forEmployersStep2Desc")
												})] })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "group flex gap-5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "size-12 rounded-2xl bg-white border-2 border-[#125BB5] text-[#125BB5] font-black text-lg flex items-center justify-center shrink-0 shadow-sm group-hover:bg-[#125BB5] group-hover:text-white transition-colors duration-300",
													children: n(3)
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
													className: "font-extrabold text-[#10233F] text-lg",
													children: t("forEmployersStep3Title")
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm text-[#5B6B7F] mt-2 font-medium",
													children: t("forEmployersStep3Desc")
												})] })]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										className: "w-full mt-12 bg-[#063B78] hover:bg-[#10233F] text-white font-extrabold text-base py-6 rounded-xl shadow-lg hover:shadow-xl transition-all hover:-translate-y-1",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/workers",
											children: t("workers")
										})
									})
								]
							})]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-20 sm:py-32 bg-[#F5F8FC]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center max-w-2xl mx-auto mb-16",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-4xl font-black text-[#10233F] sm:text-5xl tracking-tight",
								children: t("whyChooseTitle")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-lg font-medium text-[#5B6B7F]",
								children: t("whyUsSubtitle")
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid sm:grid-cols-2 lg:grid-cols-4 gap-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "group bg-white rounded-3xl p-8 text-center border border-[#DCE5F0] shadow-sm hover:shadow-2xl hover:-translate-y-3 transition-all duration-300 cursor-pointer",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-16 rounded-2xl bg-[#063B78]/10 text-[#063B78] mx-auto flex items-center justify-center mb-6 group-hover:bg-[#063B78] group-hover:text-white transition-colors duration-300",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-8" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-black text-xl text-[#10233F] mb-3",
											children: t("verifiedUsersTitle")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-medium text-[#5B6B7F] leading-relaxed",
											children: t("verifiedUsersDesc")
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "group bg-white rounded-3xl p-8 text-center border border-[#DCE5F0] shadow-sm hover:shadow-2xl hover:-translate-y-3 transition-all duration-300 cursor-pointer",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-16 rounded-2xl bg-[#FFC400]/20 text-[#082F63] mx-auto flex items-center justify-center mb-6 group-hover:bg-[#FFC400] group-hover:text-[#082F63] transition-colors duration-300",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeartHandshake, { className: "size-8" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-black text-xl text-[#10233F] mb-3",
											children: t("zeroFeesTitle")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-medium text-[#5B6B7F] leading-relaxed",
											children: t("zeroFeesDesc")
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "group bg-white rounded-3xl p-8 text-center border border-[#DCE5F0] shadow-sm hover:shadow-2xl hover:-translate-y-3 transition-all duration-300 cursor-pointer",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-16 rounded-2xl bg-[#125BB5]/10 text-[#125BB5] mx-auto flex items-center justify-center mb-6 group-hover:bg-[#125BB5] group-hover:text-white transition-colors duration-300",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "size-8" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-black text-xl text-[#10233F] mb-3",
											children: t("regionalLangTitle")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-medium text-[#5B6B7F] leading-relaxed",
											children: t("regionalLangDesc")
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "group bg-white rounded-3xl p-8 text-center border border-[#DCE5F0] shadow-sm hover:shadow-2xl hover:-translate-y-3 transition-all duration-300 cursor-pointer",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-16 rounded-2xl bg-[#063B78]/10 text-[#063B78] mx-auto flex items-center justify-center mb-6 group-hover:bg-[#063B78] group-hover:text-white transition-colors duration-300",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-8" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-black text-xl text-[#10233F] mb-3",
											children: t("instantHiringTitle")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-medium text-[#5B6B7F] leading-relaxed",
											children: t("instantHiringDesc")
										})
									]
								})
							]
						})]
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
	] });
}
//#endregion
export { AboutPage as component };
