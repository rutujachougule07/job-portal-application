import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as I18nProvider } from "./i18n-CEAlH7ip.mjs";
import { c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, m as createFileRoute, p as lazyRouteComponent, s as Scripts, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { t as Route$35 } from "./auth-BwXfDosP.mjs";
import { t as Route$36 } from "./dashboard-B4qN4F-O.mjs";
import { t as Route$37 } from "./jobs.index-m4h0_coV.mjs";
import { t as Route$38 } from "./select-language-CheD_KNP.mjs";
import { t as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-AaqlTIDS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-vPBPVIpR.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$34 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Karyam" },
			{
				name: "description",
				content: "Jobs, hiring, workforce management and E-Salary."
			},
			{
				name: "author",
				content: "Karyam"
			},
			{
				property: "og:title",
				content: "Karyam"
			},
			{
				property: "og:description",
				content: "Jobs, hiring, workforce management and E-Salary."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:site",
				content: "@Lovable"
			}
		],
		links: [
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@600;700&family=Manrope:wght@400;500;600;700;800&display=swap"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.svg",
				type: "image/svg+xml"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$34.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(I18nProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {})] })
	});
}
var $$splitComponentImporter$33 = () => import("./routes-BaxQC8Qw.mjs");
var Route$33 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "REAL JOB — Portal Entrance | User Login & Admin Login" },
		{
			name: "description",
			content: "Select User Login to browse jobs & hire workers or Admin Login for platform administration."
		},
		{
			property: "og:title",
			content: "REAL JOB — Portal Entrance"
		},
		{
			property: "og:description",
			content: "योग्य माणूस • योग्य काम • योग्य संधी — Portal Entrance"
		},
		{
			property: "og:type",
			content: "website"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$33, "component")
});
var $$splitComponentImporter$32 = () => import("./route-Di7iQBCH.mjs");
var Route$32 = createFileRoute("/_authenticated")({
	ssr: false,
	beforeLoad: async () => {
		if (typeof window !== "undefined") {
			const userStr = window.localStorage.getItem("realjob-user");
			if (userStr) try {
				return { user: JSON.parse(userStr) };
			} catch {}
			return { user: {
				id: "demo-user",
				email: "user@realjob.in"
			} };
		}
		return { user: {
			id: "demo-user",
			email: "user@realjob.in"
		} };
	},
	component: lazyRouteComponent($$splitComponentImporter$32, "component")
});
var $$splitComponentImporter$31 = () => import("./about-DvPE8yDK.mjs");
var Route$31 = createFileRoute("/about")({
	head: () => ({ meta: [{ title: "About Us — REAL JOB | Find Work | Find Workers" }, {
		name: "description",
		content: "Learn about REAL JOB — India's trusted digital workforce & recruitment platform connecting verified workers with top employers."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$31, "component")
});
var $$splitComponentImporter$30 = () => import("./admin-B2zMQwjo.mjs");
var Route$30 = createFileRoute("/admin")({
	head: () => ({ meta: [{ title: "Admin Portal & Control Dashboard — REAL JOB" }, {
		name: "description",
		content: "Platform administration, user management, employer verification and job control panel."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$30, "component")
});
var $$splitComponentImporter$29 = () => import("./categories-BBNSKfIO.mjs");
var Route$29 = createFileRoute("/categories")({
	head: () => ({ meta: [{ title: "Job Categories — REAL JOB | Find Work | Find Workers" }, {
		name: "description",
		content: "Explore all 20 main job categories on REAL JOB — Construction, IT, Engineering, Medical, Finance, Sales, Education & more."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$29, "component")
});
var $$splitComponentImporter$28 = () => import("./contact-DwQ1u8Cp.mjs");
var Route$28 = createFileRoute("/contact")({
	head: () => ({ meta: [{ title: "Contact Us — REAL JOB | Find Work | Find Workers" }, {
		name: "description",
		content: "Contact REAL JOB support team for worker registration, employer hiring assistance, or job postings."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$28, "component")
});
var $$splitComponentImporter$27 = () => import("./faq-hZjDYcME.mjs");
var Route$27 = createFileRoute("/faq")({
	head: () => ({ meta: [{ title: "Frequently Asked Questions (FAQ) — REAL JOB" }, {
		name: "description",
		content: "Find answers to all questions about finding jobs, hiring workers, account setup, and verification on REAL JOB."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$27, "component")
});
var $$splitComponentImporter$26 = () => import("./home-BIymfOFy.mjs");
var Route$26 = createFileRoute("/home")({
	head: () => ({ meta: [
		{ title: "REAL JOB — Main Portal | Find Work | Find Workers | सर्व काही ऑनलाइन!" },
		{
			name: "description",
			content: "India's premier digital workforce platform connecting verified workers with top factory, construction & technical employers."
		},
		{
			property: "og:title",
			content: "REAL JOB — Find Work | Find Workers"
		},
		{
			property: "og:description",
			content: "योग्य माणूस • योग्य काम • योग्य संधी — सर्व काही ऑनलाइन!"
		},
		{
			property: "og:type",
			content: "website"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$26, "component")
});
var $$splitComponentImporter$25 = () => import("./reset-password-Dtkf7qYt.mjs");
var Route$25 = createFileRoute("/reset-password")({
	head: () => ({ meta: [
		{ title: "Reset password — REAL JOB" },
		{
			name: "description",
			content: "Securely choose a new REAL JOB password."
		},
		{
			property: "og:title",
			content: "Reset password — REAL JOB"
		},
		{
			property: "og:description",
			content: "Secure account recovery."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$25, "component")
});
var $$splitComponentImporter$24 = () => import("./superadmin-Bh5hX6f3.mjs");
var Route$24 = createFileRoute("/superadmin")({
	head: () => ({ meta: [{ title: "Super Admin Control — REAL JOB" }, {
		name: "description",
		content: "Super Administrator Control Panel"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$24, "component")
});
var $$splitComponentImporter$23 = () => import("./applications-DjVDt8pS.mjs");
var Route$23 = createFileRoute("/_authenticated/applications")({
	head: () => ({ meta: [
		{ title: "My Applications — Karyam" },
		{
			name: "description",
			content: "Track every job application and interview milestone."
		},
		{
			property: "og:title",
			content: "My Applications — Karyam"
		},
		{
			property: "og:description",
			content: "Track your application progress."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$23, "component")
});
var $$splitComponentImporter$22 = () => import("./control-B26rJy63.mjs");
var Route$22 = createFileRoute("/_authenticated/control")({
	head: () => ({ meta: [
		{ title: "Platform Control — Karyam" },
		{
			name: "description",
			content: "Manage Karyam users, employers, jobs, payroll and system health."
		},
		{
			property: "og:title",
			content: "Platform Control — Karyam"
		},
		{
			property: "og:description",
			content: "Karyam platform administration."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$22, "component")
});
var $$splitComponentImporter$21 = () => import("./employer-C-pjt69R.mjs");
var Route$21 = createFileRoute("/_authenticated/employer")({
	head: () => ({ meta: [
		{ title: "Employer Dashboard — Karyam" },
		{
			name: "description",
			content: "Manage recruitment, candidates, employees and payroll."
		},
		{
			property: "og:title",
			content: "Employer Dashboard — Karyam"
		},
		{
			property: "og:description",
			content: "Recruitment and workforce management."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$21, "component")
});
var $$splitComponentImporter$20 = () => import("./messages-BFp6bKeM.mjs");
var Route$20 = createFileRoute("/_authenticated/messages")({
	head: () => ({ meta: [{ title: "Messages & Employer Chat — REAL JOB" }, {
		name: "description",
		content: "Directly chat with employers and workers on REAL JOB."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$20, "component")
});
var $$splitComponentImporter$19 = () => import("./notifications-DCOdQuC5.mjs");
var Route$19 = createFileRoute("/_authenticated/notifications")({
	head: () => ({ meta: [
		{ title: "Notifications — Karyam" },
		{
			name: "description",
			content: "Manage your Notifications on Karyam."
		},
		{
			property: "og:title",
			content: "Notifications — Karyam"
		},
		{
			property: "og:description",
			content: "Your secure Karyam Notifications."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$19, "component")
});
var $$splitComponentImporter$18 = () => import("./post-job-eX136hqK.mjs");
var Route$18 = createFileRoute("/_authenticated/post-job")({
	head: () => ({ meta: [{ title: "Post a New Job — REAL JOB Employer Portal" }, {
		name: "description",
		content: "Post jobs for factory workers, technicians, drivers, welders & general labor on REAL JOB."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$18, "component")
});
var $$splitComponentImporter$17 = () => import("./profile-BJO2-Q0j.mjs");
var Route$17 = createFileRoute("/_authenticated/profile")({
	head: () => ({ meta: [
		{ title: "Profile — Karyam" },
		{
			name: "description",
			content: "Manage your Profile on Karyam."
		},
		{
			property: "og:title",
			content: "Profile — Karyam"
		},
		{
			property: "og:description",
			content: "Your secure Karyam Profile."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$17, "component")
});
var $$splitComponentImporter$16 = () => import("./salary-DMAgXW2E.mjs");
var Route$16 = createFileRoute("/_authenticated/salary")({
	head: () => ({ meta: [
		{ title: "My E-Salary — Karyam" },
		{
			name: "description",
			content: "View salary, attendance, bonuses, deductions and payslips."
		},
		{
			property: "og:title",
			content: "My E-Salary — Karyam"
		},
		{
			property: "og:description",
			content: "Your secure salary dashboard."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./company._companyId-CCW2lwzP.mjs");
var Route$15 = createFileRoute("/company/$companyId")({
	head: ({ params }) => ({ meta: [{ title: `${params.companyId.replaceAll("-", " ").toUpperCase()} — Verified Company Hub | REAL JOB` }, {
		name: "description",
		content: "Explore company background, active job openings, ratings, and employee benefits on REAL JOB."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./jobs._jobId-NAKa2Otd.mjs");
var Route$14 = createFileRoute("/jobs/$jobId")({
	head: ({ params }) => ({ meta: [{ title: `${params.jobId.replaceAll("-", " ")} — REAL JOB` }, {
		name: "description",
		content: "Apply directly for verified factory, construction, driver and technical jobs on REAL JOB."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./workers.index-dk3uKLEZ.mjs");
var Route$13 = createFileRoute("/workers/")({
	head: () => ({ meta: [{ title: "Find Verified Workers & Skilled Labor — REAL JOB" }, {
		name: "description",
		content: "Hire skilled & semi-skilled workers, electricians, technicians, welders, CNC operators & drivers across Maharashtra and India."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./workers._workerId-BOAfaREK.mjs");
var Route$12 = createFileRoute("/workers/$workerId")({
	head: () => ({ meta: [{ title: "Worker Profile — REAL JOB" }, {
		name: "description",
		content: "View verified worker details, trade experience, expected salary, and direct contact options on REAL JOB."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./control.employers-D16ZdAoR.mjs");
var Route$11 = createFileRoute("/_authenticated/control/employers")({
	head: () => ({ meta: [
		{ title: "Employers — Karyam Control" },
		{
			name: "description",
			content: "Platform-wide Employers administration on Karyam."
		},
		{
			property: "og:title",
			content: "Employers — Karyam Control"
		},
		{
			property: "og:description",
			content: "Secure platform administration."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./control.jobs-CNijVs1k.mjs");
var Route$10 = createFileRoute("/_authenticated/control/jobs")({
	head: () => ({ meta: [
		{ title: "Jobs — Karyam Control" },
		{
			name: "description",
			content: "Platform-wide Jobs administration on Karyam."
		},
		{
			property: "og:title",
			content: "Jobs — Karyam Control"
		},
		{
			property: "og:description",
			content: "Secure platform administration."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./control.languages-eI_NVefZ.mjs");
var Route$9 = createFileRoute("/_authenticated/control/languages")({
	head: () => ({ meta: [
		{ title: "Languages — Karyam Control" },
		{
			name: "description",
			content: "Platform-wide Languages administration on Karyam."
		},
		{
			property: "og:title",
			content: "Languages — Karyam Control"
		},
		{
			property: "og:description",
			content: "Secure platform administration."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./control.reports-0Dc-UH1Q.mjs");
var Route$8 = createFileRoute("/_authenticated/control/reports")({
	head: () => ({ meta: [
		{ title: "Reports — Karyam Control" },
		{
			name: "description",
			content: "Platform-wide Reports administration on Karyam."
		},
		{
			property: "og:title",
			content: "Reports — Karyam Control"
		},
		{
			property: "og:description",
			content: "Secure platform administration."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./control.salary-D8kHbmsI.mjs");
var Route$7 = createFileRoute("/_authenticated/control/salary")({
	head: () => ({ meta: [
		{ title: "E-Salary — Karyam Control" },
		{
			name: "description",
			content: "Platform-wide E-Salary administration on Karyam."
		},
		{
			property: "og:title",
			content: "E-Salary — Karyam Control"
		},
		{
			property: "og:description",
			content: "Secure platform administration."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./control.settings-t5wpga4C.mjs");
var Route$6 = createFileRoute("/_authenticated/control/settings")({
	head: () => ({ meta: [
		{ title: "Settings — Karyam Control" },
		{
			name: "description",
			content: "Platform-wide Settings administration on Karyam."
		},
		{
			property: "og:title",
			content: "Settings — Karyam Control"
		},
		{
			property: "og:description",
			content: "Secure platform administration."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./control.users-DFEBjArp.mjs");
var Route$5 = createFileRoute("/_authenticated/control/users")({
	head: () => ({ meta: [
		{ title: "Users — Karyam Control" },
		{
			name: "description",
			content: "Platform-wide Users administration on Karyam."
		},
		{
			property: "og:title",
			content: "Users — Karyam Control"
		},
		{
			property: "og:description",
			content: "Secure platform administration."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./employer.applicants-CdBayabg.mjs");
var Route$4 = createFileRoute("/_authenticated/employer/applicants")({
	head: () => ({ meta: [
		{ title: "Applicants — Karyam Employer" },
		{
			name: "description",
			content: "Employer Applicants management on Karyam."
		},
		{
			property: "og:title",
			content: "Applicants — Karyam Employer"
		},
		{
			property: "og:description",
			content: "Professional employer management."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./employer.employees-BR7aJREW.mjs");
var Route$3 = createFileRoute("/_authenticated/employer/employees")({
	head: () => ({ meta: [
		{ title: "Employees — Karyam Employer" },
		{
			name: "description",
			content: "Employer Employees management on Karyam."
		},
		{
			property: "og:title",
			content: "Employees — Karyam Employer"
		},
		{
			property: "og:description",
			content: "Professional employer management."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./employer.jobs-BWsb7aKi.mjs");
var Route$2 = createFileRoute("/_authenticated/employer/jobs")({
	head: () => ({ meta: [
		{ title: "Manage Jobs — Karyam Employer" },
		{
			name: "description",
			content: "Employer Manage Jobs management on Karyam."
		},
		{
			property: "og:title",
			content: "Manage Jobs — Karyam Employer"
		},
		{
			property: "og:description",
			content: "Professional employer management."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./employer.reports-DvKINDfs.mjs");
var Route$1 = createFileRoute("/_authenticated/employer/reports")({
	head: () => ({ meta: [
		{ title: "Reports — Karyam Employer" },
		{
			name: "description",
			content: "Employer Reports management on Karyam."
		},
		{
			property: "og:title",
			content: "Reports — Karyam Employer"
		},
		{
			property: "og:description",
			content: "Professional employer management."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./employer.salary-CrtS-FZh.mjs");
var Route = createFileRoute("/_authenticated/employer/salary")({
	head: () => ({ meta: [
		{ title: "Payroll & E-Salary — Karyam" },
		{
			name: "description",
			content: "Generate salaries, bonuses, deductions and payslips."
		},
		{
			property: "og:title",
			content: "Payroll & E-Salary — Karyam"
		},
		{
			property: "og:description",
			content: "Secure employer payroll management."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$33.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$34
});
var AuthenticatedRouteRoute = Route$32.update({
	id: "/_authenticated",
	getParentRoute: () => Route$34
});
var AboutRoute = Route$31.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$34
});
var AdminRoute = Route$30.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => Route$34
});
var AuthRoute = Route$35.update({
	id: "/auth",
	path: "/auth",
	getParentRoute: () => Route$34
});
var CategoriesRoute = Route$29.update({
	id: "/categories",
	path: "/categories",
	getParentRoute: () => Route$34
});
var ContactRoute = Route$28.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => Route$34
});
var DashboardRoute = Route$36.update({
	id: "/dashboard",
	path: "/dashboard",
	getParentRoute: () => Route$34
});
var FaqRoute = Route$27.update({
	id: "/faq",
	path: "/faq",
	getParentRoute: () => Route$34
});
var HomeRoute = Route$26.update({
	id: "/home",
	path: "/home",
	getParentRoute: () => Route$34
});
var ResetPasswordRoute = Route$25.update({
	id: "/reset-password",
	path: "/reset-password",
	getParentRoute: () => Route$34
});
var SelectLanguageRoute = Route$38.update({
	id: "/select-language",
	path: "/select-language",
	getParentRoute: () => Route$34
});
var SuperadminRoute = Route$24.update({
	id: "/superadmin",
	path: "/superadmin",
	getParentRoute: () => Route$34
});
var AuthenticatedApplicationsRoute = Route$23.update({
	id: "/applications",
	path: "/applications",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedControlRoute = Route$22.update({
	id: "/control",
	path: "/control",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedEmployerRoute = Route$21.update({
	id: "/employer",
	path: "/employer",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedMessagesRoute = Route$20.update({
	id: "/messages",
	path: "/messages",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedNotificationsRoute = Route$19.update({
	id: "/notifications",
	path: "/notifications",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedPostJobRoute = Route$18.update({
	id: "/post-job",
	path: "/post-job",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedProfileRoute = Route$17.update({
	id: "/profile",
	path: "/profile",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedSalaryRoute = Route$16.update({
	id: "/salary",
	path: "/salary",
	getParentRoute: () => AuthenticatedRouteRoute
});
var CompanyCompanyIdRoute = Route$15.update({
	id: "/company/$companyId",
	path: "/company/$companyId",
	getParentRoute: () => Route$34
});
var JobsIndexRoute = Route$37.update({
	id: "/jobs/",
	path: "/jobs/",
	getParentRoute: () => Route$34
});
var JobsJobIdRoute = Route$14.update({
	id: "/jobs/$jobId",
	path: "/jobs/$jobId",
	getParentRoute: () => Route$34
});
var WorkersIndexRoute = Route$13.update({
	id: "/workers/",
	path: "/workers/",
	getParentRoute: () => Route$34
});
var WorkersWorkerIdRoute = Route$12.update({
	id: "/workers/$workerId",
	path: "/workers/$workerId",
	getParentRoute: () => Route$34
});
var AuthenticatedControlEmployersRoute = Route$11.update({
	id: "/employers",
	path: "/employers",
	getParentRoute: () => AuthenticatedControlRoute
});
var AuthenticatedControlJobsRoute = Route$10.update({
	id: "/jobs",
	path: "/jobs",
	getParentRoute: () => AuthenticatedControlRoute
});
var AuthenticatedControlLanguagesRoute = Route$9.update({
	id: "/languages",
	path: "/languages",
	getParentRoute: () => AuthenticatedControlRoute
});
var AuthenticatedControlReportsRoute = Route$8.update({
	id: "/reports",
	path: "/reports",
	getParentRoute: () => AuthenticatedControlRoute
});
var AuthenticatedControlSalaryRoute = Route$7.update({
	id: "/salary",
	path: "/salary",
	getParentRoute: () => AuthenticatedControlRoute
});
var AuthenticatedControlSettingsRoute = Route$6.update({
	id: "/settings",
	path: "/settings",
	getParentRoute: () => AuthenticatedControlRoute
});
var AuthenticatedControlUsersRoute = Route$5.update({
	id: "/users",
	path: "/users",
	getParentRoute: () => AuthenticatedControlRoute
});
var AuthenticatedEmployerApplicantsRoute = Route$4.update({
	id: "/applicants",
	path: "/applicants",
	getParentRoute: () => AuthenticatedEmployerRoute
});
var AuthenticatedEmployerEmployeesRoute = Route$3.update({
	id: "/employees",
	path: "/employees",
	getParentRoute: () => AuthenticatedEmployerRoute
});
var AuthenticatedEmployerJobsRoute = Route$2.update({
	id: "/jobs",
	path: "/jobs",
	getParentRoute: () => AuthenticatedEmployerRoute
});
var AuthenticatedEmployerReportsRoute = Route$1.update({
	id: "/reports",
	path: "/reports",
	getParentRoute: () => AuthenticatedEmployerRoute
});
var AuthenticatedEmployerSalaryRoute = Route.update({
	id: "/salary",
	path: "/salary",
	getParentRoute: () => AuthenticatedEmployerRoute
});
var AuthenticatedControlRouteChildren = {
	AuthenticatedControlEmployersRoute,
	AuthenticatedControlJobsRoute,
	AuthenticatedControlLanguagesRoute,
	AuthenticatedControlReportsRoute,
	AuthenticatedControlSalaryRoute,
	AuthenticatedControlSettingsRoute,
	AuthenticatedControlUsersRoute
};
var AuthenticatedControlRouteWithChildren = AuthenticatedControlRoute._addFileChildren(AuthenticatedControlRouteChildren);
var AuthenticatedEmployerRouteChildren = {
	AuthenticatedEmployerApplicantsRoute,
	AuthenticatedEmployerEmployeesRoute,
	AuthenticatedEmployerJobsRoute,
	AuthenticatedEmployerReportsRoute,
	AuthenticatedEmployerSalaryRoute
};
var AuthenticatedRouteRouteChildren = {
	AuthenticatedApplicationsRoute,
	AuthenticatedControlRoute: AuthenticatedControlRouteWithChildren,
	AuthenticatedEmployerRoute: AuthenticatedEmployerRoute._addFileChildren(AuthenticatedEmployerRouteChildren),
	AuthenticatedMessagesRoute,
	AuthenticatedNotificationsRoute,
	AuthenticatedPostJobRoute,
	AuthenticatedProfileRoute,
	AuthenticatedSalaryRoute
};
var rootRouteChildren = {
	IndexRoute,
	AuthenticatedRouteRoute: AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren),
	AboutRoute,
	AdminRoute,
	AuthRoute,
	CategoriesRoute,
	ContactRoute,
	DashboardRoute,
	FaqRoute,
	HomeRoute,
	ResetPasswordRoute,
	SelectLanguageRoute,
	SuperadminRoute,
	CompanyCompanyIdRoute,
	JobsJobIdRoute,
	WorkersWorkerIdRoute,
	JobsIndexRoute,
	WorkersIndexRoute
};
var routeTree = Route$34._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
