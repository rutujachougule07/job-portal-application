import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/jobs.index-m4h0_coV.js
var $$splitComponentImporter = () => import("./jobs.index-BBdNxk0w.mjs");
var Route = createFileRoute("/jobs/")({
	validateSearch: (search) => {
		return { category: typeof search["category"] === "string" ? search["category"] : void 0 };
	},
	head: () => ({ meta: [{ title: "Find Jobs — REAL JOB | Find Work | Find Workers" }, {
		name: "description",
		content: "Browse verified factory, construction, driver, ITI and technical jobs across Maharashtra and India."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
