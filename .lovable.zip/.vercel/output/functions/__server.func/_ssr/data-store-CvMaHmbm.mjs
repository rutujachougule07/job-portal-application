import { c as initializeApp, n as isSupported, t as getAnalytics } from "../_libs/@firebase/analytics+[...].mjs";
import "../_libs/firebase.mjs";
import { a as collection, i as updateDoc, n as getDocs, o as doc, r as setDoc, s as getFirestore, t as deleteDoc } from "../_libs/@firebase/firestore+[...].mjs";
import { n as getAuth } from "../_libs/firebase__auth.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/data-store-CvMaHmbm.js
var app = initializeApp({
	apiKey: "AIzaSyAbzKGt_lifA0jsZFc13yO1EgS86dm6pbI",
	authDomain: "job-portal-729b6.firebaseapp.com",
	projectId: "job-portal-729b6",
	storageBucket: "job-portal-729b6.firebasestorage.app",
	messagingSenderId: "1000731725448",
	appId: "1:1000731725448:web:ffde1b8a738849c6bc593d",
	measurementId: "G-BWY14L23SE"
});
var db = getFirestore(app);
getAuth(app);
if (typeof window !== "undefined") isSupported().then((supported) => {
	if (supported) getAnalytics(app);
});
/**
* REAL JOB Unified Data Store & Management System
* Handles Users, Employers, Jobs, Applications, SavedJobs, JobAlerts & Recommendations
*/
function fbSync(fn) {
	if (typeof window !== "undefined") fn().catch(console.error);
}
var DEFAULT_JOB_PACKAGES = [
	{
		id: "plan-100",
		name: "Starter Package",
		price: 100,
		jobCount: 1,
		features: [
			"1 Active Job Posting",
			"Direct Candidate Contacts",
			"Zero Commission",
			"Instant Activation"
		]
	},
	{
		id: "plan-200",
		name: "Growth Package",
		price: 200,
		jobCount: 2,
		popular: true,
		badge: "BEST VALUE",
		features: [
			"2 Active Job Postings",
			"Featured Badge on Listings",
			"Direct Candidate Calls",
			"Priority Support"
		]
	},
	{
		id: "plan-400",
		name: "Business Package",
		price: 400,
		jobCount: 5,
		features: [
			"5 Active Job Postings",
			"Highlighted Listings",
			"Direct WhatsApp & Call Connect",
			"Candidate Resume Access"
		]
	},
	{
		id: "plan-999",
		name: "Enterprise Unlimited",
		price: 999,
		jobCount: 999,
		badge: "UNLIMITED",
		features: [
			"Unlimited Job Postings",
			"Top Priority Ranking",
			"Dedicated Hiring Account Manager",
			"Unlimited Contact Access"
		]
	}
];
var INITIAL_JOBS = [];
var DataStoreManager = class {
	STORAGE_KEYS = {
		USER: "realjob_current_user",
		JOBS: "realjob_db_jobs",
		APPLICATIONS: "realjob_db_applications",
		SAVED_JOBS: "realjob_db_saved_jobs",
		JOB_ALERTS: "realjob_db_job_alerts",
		PROFILES: "realjob_db_profiles",
		EMPLOYERS: "realjob_db_employers",
		INTERVIEWS: "realjob_db_interviews",
		RESUMES: "realjob_db_resumes",
		PACKAGES: "realjob_db_packages",
		EMP_WORKERS: "realjob_db_emp_workers",
		ATTENDANCE: "realjob_db_attendance"
	};
	constructor() {
		this.initializeDefaults();
	}
	initializeDefaults() {
		if (typeof window === "undefined") return;
		if (!localStorage.getItem(this.STORAGE_KEYS.JOBS)) localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify([]));
		if (!localStorage.getItem(this.STORAGE_KEYS.APPLICATIONS)) localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify([]));
		if (!localStorage.getItem(this.STORAGE_KEYS.SAVED_JOBS)) localStorage.setItem(this.STORAGE_KEYS.SAVED_JOBS, JSON.stringify([]));
		if (!localStorage.getItem(this.STORAGE_KEYS.JOB_ALERTS)) localStorage.setItem(this.STORAGE_KEYS.JOB_ALERTS, JSON.stringify([]));
		fbSync(async () => {
			const jobsSnap = await getDocs(collection(db, "jobs"));
			const appsSnap = await getDocs(collection(db, "applications"));
			if (!jobsSnap.empty) {
				const fbJobs = jobsSnap.docs.map((d) => d.data());
				localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify(fbJobs));
			} else {
				const localJobs = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.JOBS) || "[]");
				for (const job of localJobs) await setDoc(doc(db, "jobs", job.id), job);
			}
			if (!appsSnap.empty) {
				const fbApps = appsSnap.docs.map((d) => d.data());
				localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify(fbApps));
			} else {
				const localApps = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.APPLICATIONS) || "[]");
				for (const app of localApps) await setDoc(doc(db, "applications", app.id), app);
			}
		});
	}
	/** Force-push all local data to Firebase (use from Admin panel) */
	async pushAllToFirebase() {
		const jobs = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.JOBS) || "[]");
		const apps = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.APPLICATIONS) || "[]");
		for (const job of jobs) await setDoc(doc(db, "jobs", job.id), job);
		for (const app of apps) await setDoc(doc(db, "applications", app.id), app);
		return {
			jobs: jobs.length,
			applications: apps.length
		};
	}
	getRegisteredUserAccounts() {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem("realjob_db_registered_users");
		if (!raw) return [];
		try {
			return JSON.parse(raw).map((u) => ({
				...u,
				fullName: u.fullName || u.email?.split("@")[0] || "User"
			}));
		} catch {
			return [];
		}
	}
	getRegisteredUsers() {
		return this.getRegisteredUserAccounts();
	}
	registerAccount(user) {
		const list = this.getRegisteredUserAccounts();
		const cleanEmail = user.email.trim().toLowerCase();
		const existingIndex = list.findIndex((u) => u.email.toLowerCase() === cleanEmail);
		const fallbackName = cleanEmail.split("@")[0] || "User";
		const account = {
			id: `usr-${Date.now()}`,
			email: cleanEmail,
			password: user.password || "",
			mobile: user.mobile || "",
			role: user.role,
			fullName: user.fullName || fallbackName,
			profilePhoto: user.profilePhoto || "",
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		if (existingIndex >= 0) list[existingIndex] = {
			...list[existingIndex],
			...account
		};
		else list.push(account);
		if (typeof window !== "undefined") {
			localStorage.setItem("realjob_db_registered_users", JSON.stringify(list));
			fbSync(() => setDoc(doc(db, "users", account.id), account));
		}
		return account;
	}
	findRegisteredAccount(identifier) {
		const clean = identifier.trim().toLowerCase();
		const cleanDigits = clean.replace(/\D/g, "");
		return this.getRegisteredUserAccounts().find((u) => {
			const emailMatch = u.email.toLowerCase() === clean;
			const mobileMatch = u.mobile && cleanDigits && cleanDigits.length >= 7 && u.mobile.replace(/\D/g, "").includes(cleanDigits) || u.email && cleanDigits && cleanDigits.length >= 7 && u.email.replace(/\D/g, "").includes(cleanDigits);
			return emailMatch || mobileMatch;
		});
	}
	deleteRegisteredUser(userId) {
		if (typeof window === "undefined") return false;
		let list = this.getRegisteredUserAccounts();
		list = list.filter((u) => u.id !== userId);
		localStorage.setItem("realjob_db_registered_users", JSON.stringify(list));
		fbSync(() => deleteDoc(doc(db, "users", userId)));
		return true;
	}
	deleteAllRegisteredUsers() {
		if (typeof window === "undefined") return false;
		const users = this.getRegisteredUserAccounts();
		localStorage.setItem("realjob_db_registered_users", JSON.stringify([]));
		for (const u of users) fbSync(() => deleteDoc(doc(db, "users", u.id)));
		return true;
	}
	deleteApplication(appId) {
		if (typeof window === "undefined") return false;
		let apps = this.getAllApplications();
		apps = apps.filter((a) => a.id !== appId);
		localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify(apps));
		fbSync(() => deleteDoc(doc(db, "applications", appId)));
		return true;
	}
	clearAllAdminData() {
		if (typeof window === "undefined") return;
		localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify([]));
		localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify([]));
		localStorage.setItem("realjob_db_registered_users", JSON.stringify([]));
		localStorage.setItem(this.STORAGE_KEYS.PACKAGES, JSON.stringify([]));
	}
	getCurrentUser() {
		if (typeof window === "undefined") return null;
		const raw = localStorage.getItem("realjob-user") || localStorage.getItem(this.STORAGE_KEYS.USER);
		if (!raw) return null;
		try {
			return JSON.parse(raw);
		} catch {
			return null;
		}
	}
	setCurrentUser(userData) {
		if (typeof window === "undefined") return;
		if (!userData) {
			localStorage.removeItem(this.STORAGE_KEYS.USER);
			localStorage.removeItem("realjob-user");
		} else {
			localStorage.setItem(this.STORAGE_KEYS.USER, JSON.stringify(userData));
			localStorage.setItem("realjob-user", JSON.stringify(userData));
		}
	}
	logout() {
		this.setCurrentUser(null);
	}
	getAllJobs() {
		if (typeof window === "undefined") return INITIAL_JOBS;
		const raw = localStorage.getItem(this.STORAGE_KEYS.JOBS);
		if (!raw) {
			localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify(INITIAL_JOBS));
			return INITIAL_JOBS;
		}
		try {
			const parsed = JSON.parse(raw);
			let modified = false;
			const updated = parsed.map((j) => {
				if (!j.approvalStatus) {
					modified = true;
					return {
						...j,
						approvalStatus: "pending"
					};
				}
				return j;
			});
			if (modified) localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify(updated));
			return updated;
		} catch {
			return INITIAL_JOBS;
		}
	}
	getActiveJobs() {
		return this.getAllJobs().filter((j) => j.status === "Active" && j.approvalStatus === "approved");
	}
	getPendingJobs() {
		return this.getAllJobs().filter((j) => j.approvalStatus === "pending");
	}
	getApprovedJobs() {
		return this.getAllJobs().filter((j) => j.approvalStatus === "approved");
	}
	getRejectedJobs() {
		return this.getAllJobs().filter((j) => j.approvalStatus === "rejected");
	}
	getJobById(jobId) {
		return this.getAllJobs().find((j) => j.id === jobId);
	}
	createJob(jobData) {
		const jobs = this.getAllJobs();
		const initials = (jobData.company || "Company").substring(0, 2).toUpperCase();
		const newJob = {
			...jobData,
			id: `job-${Date.now()}`,
			postedDate: (/* @__PURE__ */ new Date()).toISOString(),
			postedAgo: "Just now",
			initials,
			approvalStatus: jobData.approvalStatus || "pending",
			status: jobData.status || "Active"
		};
		jobs.unshift(newJob);
		if (typeof window !== "undefined") {
			localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify(jobs));
			fbSync(() => setDoc(doc(db, "jobs", newJob.id), newJob));
		}
		return newJob;
	}
	updateJobApprovalStatus(jobId, approvalStatus) {
		return this.updateJob(jobId, { approvalStatus });
	}
	updateJob(jobId, updates) {
		const jobs = this.getAllJobs();
		const existing = jobs.find((j) => j.id === jobId);
		if (!existing) return null;
		const index = jobs.findIndex((j) => j.id === jobId);
		const updatedJob = {
			...existing,
			...updates
		};
		jobs[index] = updatedJob;
		if (typeof window !== "undefined") {
			localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify(jobs));
			fbSync(() => setDoc(doc(db, "jobs", updatedJob.id), updatedJob));
		}
		return updatedJob;
	}
	deleteJob(jobId) {
		let jobs = this.getAllJobs();
		jobs = jobs.filter((j) => j.id !== jobId);
		if (typeof window !== "undefined") {
			localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify(jobs));
			fbSync(() => deleteDoc(doc(db, "jobs", jobId)));
		}
		return true;
	}
	deleteAllJobs() {
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify([]));
		return true;
	}
	getEmployerJobs(identifier) {
		const jobs = this.getAllJobs();
		if (!identifier || !identifier.trim()) return [];
		const q = identifier.toLowerCase().trim();
		return jobs.filter((j) => {
			const empId = (j.employerId || "").toLowerCase().trim();
			const comp = (j.company || "").toLowerCase().trim();
			if (!empId && !comp) return false;
			return empId === q || comp === q || q.length >= 4 && (empId.includes(q) || comp.includes(q));
		});
	}
	getAllApplications() {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.APPLICATIONS);
		if (!raw) return [];
		try {
			const apps = JSON.parse(raw);
			let modified = false;
			const updated = apps.map((app) => {
				if (!app.candidateMobile || app.candidateMobile === "9822011223" || app.candidateMobile === "+91 98220 11223") {
					const reg = this.findRegisteredAccount(app.candidateEmail || app.jobSeekerId);
					if (reg?.mobile) {
						modified = true;
						return {
							...app,
							candidateMobile: reg.mobile
						};
					}
				}
				return app;
			});
			if (modified) localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify(updated));
			return updated;
		} catch {
			return [];
		}
	}
	hasAlreadyApplied(jobSeekerId, jobId) {
		return this.getAllApplications().some((a) => (a.jobSeekerId === jobSeekerId || a.candidateEmail === jobSeekerId) && a.jobId === jobId);
	}
	createApplication(appData) {
		const apps = this.getAllApplications();
		if (this.hasAlreadyApplied(appData.jobSeekerId, appData.jobId)) throw new Error("Already applied to this job");
		const newApp = {
			...appData,
			id: `app-${Date.now()}`,
			appliedDate: (/* @__PURE__ */ new Date()).toLocaleDateString("en-IN", {
				day: "numeric",
				month: "short",
				year: "numeric"
			}),
			status: "Applied"
		};
		apps.unshift(newApp);
		if (typeof window !== "undefined") {
			localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify(apps));
			fbSync(() => setDoc(doc(db, "applications", newApp.id), newApp));
		}
		return newApp;
	}
	getEmployerApplications(identifier) {
		const apps = this.getAllApplications();
		if (!identifier || !identifier.trim()) return [];
		const q = identifier.toLowerCase().trim();
		return apps.filter((a) => {
			const empId = (a.employerId || "").toLowerCase().trim();
			const comp = (a.companyName || "").toLowerCase().trim();
			if (!empId && !comp) return false;
			return empId === q || comp === q || q.length >= 4 && (empId.includes(q) || comp.includes(q));
		});
	}
	getJobSeekerApplications(jobSeekerId) {
		return this.getAllApplications().filter((a) => a.jobSeekerId === jobSeekerId || a.candidateEmail === jobSeekerId);
	}
	updateApplicationStatus(applicationId, status) {
		const apps = this.getAllApplications();
		const existing = apps.find((a) => a.id === applicationId);
		if (!existing) return null;
		const index = apps.findIndex((a) => a.id === applicationId);
		const updatedApp = {
			...existing,
			status
		};
		apps[index] = updatedApp;
		if (typeof window !== "undefined") {
			localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify(apps));
			fbSync(() => updateDoc(doc(db, "applications", updatedApp.id), { status }));
		}
		return updatedApp;
	}
	getSavedJobs(jobSeekerId) {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.SAVED_JOBS);
		if (!raw) return [];
		try {
			return JSON.parse(raw).filter((s) => s.jobSeekerId === jobSeekerId);
		} catch {
			return [];
		}
	}
	saveJob(jobSeekerId, jobId) {
		const all = this.getSavedJobs(jobSeekerId);
		if (all.some((s) => s.jobId === jobId)) return all.find((s) => s.jobId === jobId);
		const newSaved = {
			id: `save-${Date.now()}`,
			jobSeekerId,
			jobId,
			savedDate: (/* @__PURE__ */ new Date()).toISOString()
		};
		const raw = localStorage.getItem(this.STORAGE_KEYS.SAVED_JOBS);
		const existing = raw ? JSON.parse(raw) : [];
		existing.push(newSaved);
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.SAVED_JOBS, JSON.stringify(existing));
		return newSaved;
	}
	removeSavedJob(jobSeekerId, jobId) {
		const raw = localStorage.getItem(this.STORAGE_KEYS.SAVED_JOBS);
		if (!raw) return true;
		let existing = JSON.parse(raw);
		existing = existing.filter((s) => !(s.jobSeekerId === jobSeekerId && s.jobId === jobId));
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.SAVED_JOBS, JSON.stringify(existing));
		return true;
	}
	getRecommendedJobs(candidateSkills, candidateCategory) {
		const allJobs = this.getActiveJobs();
		if (!candidateSkills.length && !candidateCategory) return allJobs.slice(0, 4);
		return allJobs.map((job) => {
			let score = 0;
			if (candidateCategory && job.category.toLowerCase().includes(candidateCategory.toLowerCase())) score += 5;
			candidateSkills.forEach((skill) => {
				if (job.requiredSkills.some((s) => s.toLowerCase().includes(skill.toLowerCase())) || job.title.toLowerCase().includes(skill.toLowerCase())) score += 3;
			});
			return {
				job,
				score
			};
		}).sort((a, b) => b.score - a.score).slice(0, 6).map((item) => item.job);
	}
	getApplicationsByJobSeeker(jobSeekerId) {
		return this.getJobSeekerApplications(jobSeekerId);
	}
	getInterviews() {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.INTERVIEWS);
		if (!raw) return [];
		try {
			return JSON.parse(raw);
		} catch {
			return [];
		}
	}
	scheduleInterview(data) {
		const interviews = this.getInterviews();
		const newInt = {
			...data,
			id: `int-${Date.now()}`
		};
		interviews.unshift(newInt);
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.INTERVIEWS, JSON.stringify(interviews));
		return newInt;
	}
	getUserResumes(userId) {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.RESUMES);
		if (!raw) return [];
		try {
			return JSON.parse(raw).filter((r) => r.userId === userId);
		} catch {
			return [];
		}
	}
	addUserResume(data) {
		const raw = localStorage.getItem(this.STORAGE_KEYS.RESUMES);
		const existing = raw ? JSON.parse(raw) : [];
		const newRes = {
			...data,
			id: `res-${Date.now()}`,
			uploadDate: data.uploadDate || (/* @__PURE__ */ new Date()).toLocaleDateString("en-IN", {
				day: "numeric",
				month: "short",
				year: "numeric"
			})
		};
		existing.unshift(newRes);
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.RESUMES, JSON.stringify(existing));
		return newRes;
	}
	deleteUserResume(id) {
		const raw = localStorage.getItem(this.STORAGE_KEYS.RESUMES);
		if (!raw) return true;
		try {
			let existing = JSON.parse(raw);
			existing = existing.filter((r) => r.id !== id);
			if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.RESUMES, JSON.stringify(existing));
		} catch {}
		return true;
	}
	getJobSeekerProfile(userId) {
		if (typeof window === "undefined" || !userId) return null;
		const raw = localStorage.getItem(this.STORAGE_KEYS.PROFILES);
		if (!raw) return null;
		try {
			const profile = JSON.parse(raw).find((p) => p.id === userId || p.email === userId) || null;
			if (profile) {
				if (profile.category === "IT & Software" || profile.category === "General Candidate") profile.category = "";
				if (profile.experience === "2 Years" || profile.experience === "Fresher") profile.experience = "";
				if (profile.education === "B.Tech / Graduate" || profile.education === "Not Specified" || profile.education === "Graduate") profile.education = "";
				if (profile.expectedSalary === "₹ 4.5 LPA" || profile.expectedSalary === "As per standards") profile.expectedSalary = "";
				if (profile.currentLocation === "Pune, Maharashtra" || profile.currentLocation === "Pune") profile.currentLocation = "";
				if (profile.preferredLocation === "Pune, Mumbai, Chakan" || profile.preferredLocation === "Pune, Maharashtra" || profile.preferredLocation === "Pune") profile.preferredLocation = "";
				if (profile.skills?.includes("React") && profile.skills?.includes("JavaScript")) profile.skills = [];
				if (profile.resume?.includes("_resume.pdf")) profile.resume = "";
			}
			return profile;
		} catch {
			return null;
		}
	}
	saveJobSeekerProfile(profile) {
		const raw = typeof window !== "undefined" ? localStorage.getItem(this.STORAGE_KEYS.PROFILES) : null;
		const profiles = raw ? JSON.parse(raw) : [];
		const existingIndex = profiles.findIndex((p) => p.id === profile.id || p.email === profile.email);
		const found = existingIndex >= 0 ? profiles[existingIndex] : void 0;
		const updatedProfile = {
			id: profile.id,
			email: profile.email,
			fullName: profile.fullName ?? found?.fullName ?? "User",
			mobile: profile.mobile ?? found?.mobile ?? "",
			education: profile.education ?? found?.education ?? "",
			skills: profile.skills ?? found?.skills ?? [],
			experience: profile.experience ?? found?.experience ?? "",
			currentLocation: profile.currentLocation ?? found?.currentLocation ?? "",
			preferredLocation: profile.preferredLocation ?? found?.preferredLocation ?? "",
			expectedSalary: profile.expectedSalary ?? found?.expectedSalary ?? "",
			category: profile.category ?? found?.category ?? "",
			subcategory: profile.subcategory ?? found?.subcategory ?? "",
			jobType: profile.jobType ?? found?.jobType ?? "Full Time",
			resume: profile.resume ?? found?.resume ?? "",
			resumeName: profile.resumeName ?? found?.resumeName ?? "",
			profilePhoto: profile.profilePhoto ?? found?.profilePhoto ?? "",
			createdAt: found?.createdAt ?? (/* @__PURE__ */ new Date()).toISOString()
		};
		if (existingIndex >= 0) profiles[existingIndex] = updatedProfile;
		else profiles.push(updatedProfile);
		if (typeof window !== "undefined") {
			localStorage.setItem(this.STORAGE_KEYS.PROFILES, JSON.stringify(profiles));
			fbSync(() => setDoc(doc(db, "profiles", updatedProfile.id), updatedProfile));
			const currentUser = this.getCurrentUser();
			if (currentUser && (currentUser.id === updatedProfile.id || currentUser.email === updatedProfile.email)) this.setCurrentUser({
				...currentUser,
				fullName: updatedProfile.fullName,
				email: updatedProfile.email,
				profilePhoto: updatedProfile.profilePhoto || currentUser.profilePhoto || ""
			});
		}
		return updatedProfile;
	}
	getUserPackages(userId) {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.PACKAGES);
		if (!raw) return [];
		try {
			return JSON.parse(raw).filter((p) => p.userId === userId);
		} catch {
			return [];
		}
	}
	/**
	* Record package purchase transaction
	*/
	addPackagePurchase(data) {
		const raw = localStorage.getItem(this.STORAGE_KEYS.PACKAGES);
		const existing = raw ? JSON.parse(raw) : [];
		const newTx = {
			...data,
			id: `pkg-${Date.now()}`,
			purchaseDate: (/* @__PURE__ */ new Date()).toLocaleDateString("en-IN", {
				day: "numeric",
				month: "short",
				year: "numeric",
				hour: "2-digit",
				minute: "2-digit"
			}),
			status: "Completed"
		};
		existing.unshift(newTx);
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.PACKAGES, JSON.stringify(existing));
		return newTx;
	}
	/**
	* Get available job credits count for user
	*/
	getUserJobCredits(userId) {
		return this.getUserPackages(userId).reduce((acc, p) => acc + (p.jobCount || 0), 0);
	}
	/**
	* Get dynamic job packages
	*/
	getJobPackages() {
		if (typeof window === "undefined") return DEFAULT_JOB_PACKAGES;
		const raw = localStorage.getItem("realjob_db_dynamic_packages");
		if (!raw) return DEFAULT_JOB_PACKAGES;
		try {
			const parsed = JSON.parse(raw);
			return Array.isArray(parsed) && parsed.length > 0 ? parsed : DEFAULT_JOB_PACKAGES;
		} catch {
			return DEFAULT_JOB_PACKAGES;
		}
	}
	/**
	* Save dynamic job packages (SuperAdmin control)
	*/
	saveJobPackages(packages) {
		if (typeof window === "undefined") return;
		localStorage.setItem("realjob_db_dynamic_packages", JSON.stringify(packages));
	}
	/**
	* Get all package purchases across platform (SuperAdmin view)
	*/
	getAllPackagePurchases() {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.PACKAGES);
		if (!raw) return [];
		try {
			return JSON.parse(raw);
		} catch {
			return [];
		}
	}
	deletePackagePurchase(txId) {
		if (typeof window === "undefined") return false;
		let list = this.getAllPackagePurchases();
		list = list.filter((tx) => tx.id !== txId);
		localStorage.setItem(this.STORAGE_KEYS.PACKAGES, JSON.stringify(list));
		return true;
	}
	clearPackagePurchases() {
		if (typeof window === "undefined") return false;
		localStorage.setItem(this.STORAGE_KEYS.PACKAGES, JSON.stringify([]));
		return true;
	}
	/**
	* Consume 1 credit when posting a job
	*/
	consumeJobCredit(userId) {
		if (typeof window === "undefined") return false;
		const raw = localStorage.getItem(this.STORAGE_KEYS.PACKAGES);
		if (!raw) return false;
		try {
			const all = JSON.parse(raw);
			const activePkg = all.find((p) => p.userId === userId && p.jobCount > 0);
			if (!activePkg) return false;
			if (activePkg.jobCount < 999) activePkg.jobCount -= 1;
			localStorage.setItem(this.STORAGE_KEYS.PACKAGES, JSON.stringify(all));
			return true;
		} catch {
			return false;
		}
	}
	getEmployerWorkers(employerId) {
		if (typeof window === "undefined" || !employerId) return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.EMP_WORKERS);
		if (!raw) return [];
		try {
			return JSON.parse(raw).filter((w) => w.employerId === employerId);
		} catch {
			return [];
		}
	}
	saveEmployerWorker(worker) {
		const raw = typeof window !== "undefined" ? localStorage.getItem(this.STORAGE_KEYS.EMP_WORKERS) : null;
		const all = raw ? JSON.parse(raw) : [];
		const workerId = worker.id || `empw-${Date.now()}`;
		const newWorker = {
			...worker,
			id: workerId,
			status: worker.status || "Active"
		};
		const index = all.findIndex((w) => w.id === workerId);
		if (index >= 0) all[index] = newWorker;
		else all.unshift(newWorker);
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.EMP_WORKERS, JSON.stringify(all));
		return newWorker;
	}
	deleteEmployerWorker(workerId) {
		if (typeof window === "undefined" || !workerId) return false;
		const raw = localStorage.getItem(this.STORAGE_KEYS.EMP_WORKERS);
		if (!raw) return false;
		try {
			const filtered = JSON.parse(raw).filter((w) => w.id !== workerId);
			localStorage.setItem(this.STORAGE_KEYS.EMP_WORKERS, JSON.stringify(filtered));
			return true;
		} catch {
			return false;
		}
	}
	getEmployerAttendance(employerId, date) {
		if (typeof window === "undefined" || !employerId) return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.ATTENDANCE);
		if (!raw) return [];
		try {
			let res = JSON.parse(raw).filter((a) => a.employerId === employerId);
			if (date) res = res.filter((a) => a.date === date);
			return res;
		} catch {
			return [];
		}
	}
	getEmployerAttendanceRange(employerId, startDate, endDate) {
		if (typeof window === "undefined" || !employerId) return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.ATTENDANCE);
		if (!raw) return [];
		try {
			let res = JSON.parse(raw).filter((a) => a.employerId === employerId);
			if (startDate) res = res.filter((a) => a.date >= startDate);
			if (endDate) res = res.filter((a) => a.date <= endDate);
			return res;
		} catch {
			return [];
		}
	}
	saveAttendanceStatus(employerId, workerId, workerName, date, status, notes) {
		const raw = typeof window !== "undefined" ? localStorage.getItem(this.STORAGE_KEYS.ATTENDANCE) : null;
		const all = raw ? JSON.parse(raw) : [];
		const recordId = `att-${workerId}-${date}`;
		const newRecord = {
			id: recordId,
			employerId,
			workerId,
			workerName,
			date,
			status,
			notes: notes || "",
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		const index = all.findIndex((a) => a.id === recordId || a.workerId === workerId && a.date === date);
		if (index >= 0) all[index] = newRecord;
		else all.push(newRecord);
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.ATTENDANCE, JSON.stringify(all));
		return newRecord;
	}
};
var dataStore = new DataStoreManager();
//#endregion
export { dataStore as t };
