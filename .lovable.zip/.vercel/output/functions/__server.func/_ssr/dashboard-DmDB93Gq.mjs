import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-DmDB93Gq.js
var $$splitComponentImporter = () => import("./dashboard-D3B2Whn_.mjs");
var Route = createFileRoute("/dashboard")({
	validateSearch: (search) => {
		return { tab: search["tab"] };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
