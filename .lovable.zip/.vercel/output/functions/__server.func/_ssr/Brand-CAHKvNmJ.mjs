import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Brand-CAHKvNmJ.js
var import_jsx_runtime = require_jsx_runtime();
function LogoIcon({ className = "h-14" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: "/logo.png",
		alt: "REAL JOB Logo",
		className: `${className} object-contain shrink-0`
	});
}
function Brand({ className = "h-14 sm:h-16" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/",
		className: "inline-flex items-center gap-2 group select-none shrink-0",
		"aria-label": "REAL JOB Logo",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: "/logo.png",
			alt: "REAL JOB Logo",
			className: `${className} object-contain transition-transform duration-200 group-hover:scale-105`
		})
	});
}
//#endregion
export { LogoIcon as n, Brand as t };
