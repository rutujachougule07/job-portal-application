import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n, r as getCategoryTitle } from "./i18n-CEAlH7ip.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Button, t as Brand } from "./button-DlK03b8v.mjs";
import { t as dataStore } from "./data-store-j7ecARph.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { $ as Info, B as Menu, H as Mail, Mt as Briefcase, N as QrCode, Q as Instagram, St as CircleQuestionMark, Tt as ChevronRight, U as LogOut, Y as LayoutDashboard, c as User, f as Twitter, l as UserRound, n as Youtube, q as Linkedin, r as X, s as Users, w as ShieldCheck, wt as ChevronUp } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/PublicHeader-DazdRGin.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PublicFooter() {
	const { t, n, lang } = useI18n();
	const [email, setEmail] = (0, import_react.useState)("");
	const [subscribed, setSubscribed] = (0, import_react.useState)(false);
	const handleSubscribe = (e) => {
		e.preventDefault();
		if (email.trim()) {
			setSubscribed(true);
			setEmail("");
			setTimeout(() => setSubscribed(false), 4e3);
		}
	};
	const scrollToTop = () => {
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "relative bg-[#082F63] text-slate-200 overflow-hidden font-sans border-t border-[#125BB5]/40",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-transparent via-[#FFC400] to-transparent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto max-w-7xl px-4 pt-14 pb-10 sm:px-6 lg:px-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 gap-8 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-[1.3fr_0.8fr_0.8fr_0.8fr_0.8fr_1.5fr] items-start",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/",
									className: "inline-flex items-center gap-3 group",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "/logo.png",
										alt: "REAL JOB Logo",
										className: "h-20 object-contain bg-white/95 p-2 rounded-xl shadow-md transition-transform group-hover:scale-105"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs leading-relaxed text-slate-300 pr-2",
									children: [
										t("heroSubtitle"),
										" — ",
										t("trustVerified")
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center gap-2.5 pt-1",
									children: [
										{
											icon: Linkedin,
											label: "LinkedIn",
											href: "#"
										},
										{
											icon: Instagram,
											label: "Instagram",
											href: "#"
										},
										{
											icon: Youtube,
											label: "YouTube",
											href: "#"
										},
										{
											icon: Twitter,
											label: "X (Twitter)",
											href: "#"
										}
									].map(({ icon: Icon, label, href }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href,
										"aria-label": label,
										className: "grid size-8 place-items-center rounded-full border border-white/20 bg-white/10 text-white hover:border-[#FFC400] hover:bg-[#FFC400] hover:text-[#082F63] transition-all duration-200",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3.5" })
									}, label))
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-black text-white tracking-wide",
								children: t("seeker")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-1.5 h-[2px] w-8 bg-[#FFC400] rounded-full mb-4" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-2 text-xs font-semibold text-slate-300",
								children: [
									{
										label: t("jobs"),
										to: "/jobs"
									},
									{
										label: t("applications"),
										to: "/auth"
									},
									{
										label: t("profile"),
										to: "/auth"
									},
									{
										label: t("aboutUs"),
										to: "/about"
									},
									{
										label: t("faq"),
										to: "/faq"
									}
								].map(({ label, to }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to,
									className: "inline-flex items-center gap-1 hover:text-[#FFC400] hover:translate-x-1 transition-all duration-150",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-3 text-[#FFC400] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
								}) }, label))
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-black text-white tracking-wide",
								children: t("employer")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-1.5 h-[2px] w-8 bg-[#FFC400] rounded-full mb-4" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-2 text-xs font-semibold text-slate-300",
								children: [
									{
										label: t("hireTalent"),
										to: "/auth"
									},
									{
										label: t("workers"),
										to: "/workers"
									},
									{
										label: t("viewProfile"),
										to: "/workers"
									},
									{
										label: t("contactUs"),
										to: "/contact"
									},
									{
										label: t("register"),
										to: "/auth"
									}
								].map(({ label, to }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to,
									className: "inline-flex items-center gap-1 hover:text-[#FFC400] hover:translate-x-1 transition-all duration-150",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-3 text-[#FFC400] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
								}) }, label))
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-black text-white tracking-wide",
								children: t("categories")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-1.5 h-[2px] w-8 bg-[#FFC400] rounded-full mb-4" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-2 text-xs font-semibold text-slate-300",
								children: [
									{
										id: "factory-workers",
										to: "/jobs"
									},
									{
										id: "construction-workers",
										to: "/jobs"
									},
									{
										id: "technical-staff",
										to: "/jobs"
									},
									{
										id: "logistics-drivers",
										to: "/jobs"
									},
									{
										id: "electricians",
										to: "/jobs"
									},
									{
										id: "security",
										to: "/jobs"
									}
								].map(({ id, to }) => {
									const label = getCategoryTitle(id, lang);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to,
										className: "inline-flex items-center gap-1 hover:text-[#FFC400] hover:translate-x-1 transition-all duration-150",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-3 text-[#FFC400] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
									}) }, id);
								})
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-black text-white tracking-wide",
								children: t("brand")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-1.5 h-[2px] w-8 bg-[#FFC400] rounded-full mb-4" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-2 text-xs font-semibold text-slate-300",
								children: [
									{
										label: t("aboutUs"),
										to: "/about"
									},
									{
										label: t("contactUs"),
										to: "/contact"
									},
									{
										label: t("faq"),
										to: "/faq"
									}
								].map(({ label, to }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to,
									className: "inline-flex items-center gap-1 hover:text-[#FFC400] hover:translate-x-1 transition-all duration-150",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-3 text-[#FFC400] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
								}) }, label))
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:border-l lg:border-white/10 lg:pl-6 space-y-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-lg font-black text-white tracking-wide",
									children: t("downloadTitle")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1.5 text-xs font-medium text-slate-300",
									children: t("downloadSubtitle")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: handleSubscribe,
									className: "mt-3.5 flex items-center rounded-xl border border-white/20 bg-white/10 p-1 focus-within:border-[#FFC400] transition-all",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative flex-1 flex items-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "ml-3 size-4 text-slate-300 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "email",
											required: true,
											placeholder: t("email"),
											value: email,
											onChange: (e) => setEmail(e.target.value),
											className: "w-full h-9 bg-transparent px-3 text-xs text-white placeholder-slate-300 focus:outline-none"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "submit",
										className: "h-9 px-4 rounded-lg bg-[#FFC400] text-[#082F63] font-black text-xs transition-colors shrink-0 shadow-sm hover:bg-[#FFD21F]",
										children: subscribed ? "..." : t("continue")
									})]
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3 rounded-xl border border-white/15 bg-white/5 flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, { className: "size-10 text-[#FFC400] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-black text-white block",
									children: "REAL JOB Mobile App"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-bold text-slate-300",
									children: "Google Play & App Store"
								})] })]
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-t border-white/10 bg-[#063B78] py-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-4 text-xs font-bold text-slate-300 sm:flex-row sm:px-6 lg:px-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-center sm:text-left",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"© ",
								n(2026),
								" REAL JOB. ",
								t("copyright")
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden text-slate-400 sm:inline",
								children: "|"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("tagline") })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1.5",
							children: [
								"Made with ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[#FFC400]",
									children: "💛"
								}),
								" in India."
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: scrollToTop,
							"aria-label": "Scroll to top",
							className: "grid size-8 place-items-center rounded-full bg-[#FFC400] text-[#082F63] transition-all shadow-md hover:scale-105 font-black",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-4 stroke-[3]" })
						})]
					})]
				})
			})
		]
	});
}
function PublicHeader() {
	const { t } = useI18n();
	const [mobileMenuOpen, setMobileMenuOpen] = (0, import_react.useState)(false);
	const [user, setUser] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (typeof window === "undefined") return;
		const checkUser = () => {
			setUser(dataStore.getCurrentUser());
		};
		checkUser();
		window.addEventListener("storage", checkUser);
		return () => {
			window.removeEventListener("storage", checkUser);
		};
	}, []);
	const handleLogout = () => {
		if (typeof window !== "undefined") {
			window.localStorage.removeItem("realjob-user");
			window.localStorage.removeItem("realjob_current_user");
		}
		dataStore.setCurrentUser(null);
		setUser(null);
		toast.info("Logged out successfully!");
		if (typeof window !== "undefined") window.location.href = "/";
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-50 border-b border-[#DCE5F0] bg-white/95 backdrop-blur-md shadow-xs",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-18 max-w-7xl items-center justify-between px-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, { className: "h-14 sm:h-16 scale-105 sm:scale-110 origin-left" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "hidden items-center gap-6 xl:gap-8 lg:flex",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/home",
							className: "nav-link text-sm font-bold hover:text-[#063B78] transition-colors",
							children: t("home")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/jobs",
							className: "nav-link text-sm font-bold hover:text-[#063B78] transition-colors",
							children: t("jobs")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/workers",
							className: "nav-link text-sm font-bold hover:text-[#063B78] transition-colors",
							children: t("workers")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/about",
							className: "nav-link text-sm font-bold hover:text-[#063B78] transition-colors",
							children: t("aboutUs")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/contact",
							className: "nav-link text-sm font-bold hover:text-[#063B78] transition-colors",
							children: t("contactUs")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/faq",
							className: "nav-link text-sm font-bold hover:text-[#063B78] transition-colors",
							children: t("faq")
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 sm:gap-2.5",
					children: [user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#EBF1F8] border border-[#B8D3F2] text-xs font-black text-[#063B78]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-3.5 text-[#063B78]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: user.fullName || user.email?.split("@")[0] || "User" })]
							}),
							user.role !== "worker" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "sm",
								className: "bg-[#063B78] hover:bg-[#082F63] text-white font-extrabold text-xs h-9 px-3 rounded-lg shadow-xs",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: user.role === "admin" ? "/admin" : "/employer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "size-3.5 mr-1" }), "Dashboard"]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: handleLogout,
								size: "sm",
								className: "bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs h-9 px-3 rounded-lg shadow-xs flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Logout" })]
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						className: "hidden sm:inline-flex border-[#063B78] text-[#063B78] font-extrabold hover:bg-[#063B78] hover:text-white text-xs px-3 sm:px-3.5 h-9.5 rounded-lg shadow-2xs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/auth",
							search: {
								mode: "login",
								role: "worker"
							},
							className: "inline-flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("userLogin") })]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						className: "hidden sm:inline-flex bg-[#063B78] hover:bg-[#082F63] text-white font-extrabold text-xs px-3 sm:px-3.5 h-9.5 rounded-lg shadow-xs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/auth",
							search: {
								mode: "login",
								role: "admin"
							},
							className: "inline-flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3.5 text-[#FFC400]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("adminLogin") })]
						})
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: "ghost",
						className: "lg:hidden text-[#063B78]",
						onClick: () => setMobileMenuOpen(!mobileMenuOpen),
						"aria-label": "Toggle Navigation Menu",
						children: mobileMenuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-6" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-6" })
					})]
				})
			]
		}), mobileMenuOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 top-20 z-50 bg-[#082F63]/50 backdrop-blur-sm lg:hidden animate-fade-in",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white border-b border-[#DCE5F0] p-6 shadow-xl space-y-4 max-h-[calc(100vh-5rem)] overflow-y-auto",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center justify-between pb-4 border-b border-[#DCE5F0]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-bold uppercase tracking-wider text-[#5B6B7F]",
							children: "Navigation"
						})
					}),
					user && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 p-3 rounded-xl bg-[#EBF1F8] border border-[#B8D3F2] text-xs font-black text-[#063B78]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-4 text-[#063B78]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Logged in as: ", user.fullName || user.email] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "grid gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/home",
								onClick: () => setMobileMenuOpen(false),
								className: "flex items-center gap-3 rounded-lg px-3 py-2.5 font-bold text-[#10233F] hover:bg-[#F5F8FC]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-5 text-[#063B78]" }), t("home")]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/jobs",
								onClick: () => setMobileMenuOpen(false),
								className: "flex items-center gap-3 rounded-lg px-3 py-2.5 font-bold text-[#10233F] hover:bg-[#F5F8FC]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-5 text-[#125BB5]" }), t("jobs")]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/workers",
								onClick: () => setMobileMenuOpen(false),
								className: "flex items-center gap-3 rounded-lg px-3 py-2.5 font-bold text-[#10233F] hover:bg-[#F5F8FC]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5 text-[#FFC400]" }), t("workers")]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/about",
								onClick: () => setMobileMenuOpen(false),
								className: "flex items-center gap-3 rounded-lg px-3 py-2.5 font-bold text-[#10233F] hover:bg-[#F5F8FC]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-5 text-[#125BB5]" }), t("aboutUs")]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/contact",
								onClick: () => setMobileMenuOpen(false),
								className: "flex items-center gap-3 rounded-lg px-3 py-2.5 font-bold text-[#10233F] hover:bg-[#F5F8FC]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-5 text-[#063B78]" }), t("contactUs")]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/faq",
								onClick: () => setMobileMenuOpen(false),
								className: "flex items-center gap-3 rounded-lg px-3 py-2.5 font-bold text-[#10233F] hover:bg-[#F5F8FC]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleQuestionMark, { className: "size-5 text-[#125BB5]" }), t("faq")]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pt-4 border-t border-[#DCE5F0]",
						children: user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `grid ${user.role === "worker" ? "grid-cols-1" : "grid-cols-2"} gap-2.5`,
							children: [user.role !== "worker" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								className: "w-full bg-[#063B78] text-white font-extrabold text-xs",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: user.role === "admin" ? "/admin" : "/employer",
									onClick: () => setMobileMenuOpen(false),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "size-3.5 mr-1" }), "Dashboard"]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => {
									setMobileMenuOpen(false);
									handleLogout();
								},
								className: "w-full bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-3.5 mr-1" }), "Logout"]
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "outline",
								className: "w-full border-[#063B78] text-[#063B78] font-extrabold text-xs",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/auth",
									search: {
										mode: "login",
										role: "worker"
									},
									onClick: () => setMobileMenuOpen(false),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "size-3.5 mr-1" }), t("userLogin")]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								className: "w-full bg-[#063B78] text-white font-extrabold text-xs",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/auth",
									search: {
										mode: "login",
										role: "admin"
									},
									onClick: () => setMobileMenuOpen(false),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3.5 mr-1 text-[#FFC400]" }), t("adminLogin")]
								})
							})]
						})
					})
				]
			})
		})]
	});
}
//#endregion
export { PublicHeader as n, PublicFooter as t };
