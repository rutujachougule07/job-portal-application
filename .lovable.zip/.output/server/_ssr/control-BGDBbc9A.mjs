import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as GenericAdminPage } from "./Dashboards-Za5rUmr5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/control-BGDBbc9A.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GenericAdminPage, {
	role: "super",
	title: "Platform Control"
});
//#endregion
export { SplitComponent as component };
