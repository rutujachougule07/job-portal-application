import { t as ApplicationsPage } from "./Dashboards-DS6IH2fS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/applications-Bwy9Rb0r.js
var SplitComponent = ApplicationsPage;
//#endregion
export { SplitComponent as component };
