import { c as initializeApp, n as isSupported, t as getAnalytics } from "../_libs/@firebase/analytics+[...].mjs";
import "../_libs/firebase.mjs";
import { a as collection, i as updateDoc, n as getDocs, o as doc, r as setDoc, s as getFirestore, t as deleteDoc } from "../_libs/@firebase/firestore+[...].mjs";
import { n as getAuth } from "../_libs/firebase__auth.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/data-store-BCcScpg-.js
var app = initializeApp({
	apiKey: "AIzaSyAbzKGt_lifA0jsZFc13yO1EgS86dm6pbI",
	authDomain: "job-portal-729b6.firebaseapp.com",
	projectId: "job-portal-729b6",
	storageBucket: "job-portal-729b6.firebasestorage.app",
	messagingSenderId: "1000731725448",
	appId: "1:1000731725448:web:ffde1b8a738849c6bc593d",
	measurementId: "G-BWY14L23SE"
});
var db = getFirestore(app);
getAuth(app);
if (typeof window !== "undefined") isSupported().then((supported) => {
	if (supported) getAnalytics(app);
});
/**
* REAL JOB Unified Data Store & Management System
* Handles Users, Employers, Jobs, Applications, SavedJobs, JobAlerts & Recommendations
*/
function fbSync(fn) {
	if (typeof window !== "undefined") fn().catch(console.error);
}
var INITIAL_JOBS = [];
var DataStoreManager = class {
	STORAGE_KEYS = {
		USER: "realjob_current_user",
		JOBS: "realjob_db_jobs",
		APPLICATIONS: "realjob_db_applications",
		SAVED_JOBS: "realjob_db_saved_jobs",
		JOB_ALERTS: "realjob_db_job_alerts",
		PROFILES: "realjob_db_profiles",
		EMPLOYERS: "realjob_db_employers",
		INTERVIEWS: "realjob_db_interviews",
		RESUMES: "realjob_db_resumes"
	};
	constructor() {
		this.initializeDefaults();
	}
	initializeDefaults() {
		if (typeof window === "undefined") return;
		if (!localStorage.getItem(this.STORAGE_KEYS.JOBS)) localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify([]));
		if (!localStorage.getItem(this.STORAGE_KEYS.APPLICATIONS)) localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify([]));
		if (!localStorage.getItem(this.STORAGE_KEYS.SAVED_JOBS)) localStorage.setItem(this.STORAGE_KEYS.SAVED_JOBS, JSON.stringify([]));
		if (!localStorage.getItem(this.STORAGE_KEYS.JOB_ALERTS)) localStorage.setItem(this.STORAGE_KEYS.JOB_ALERTS, JSON.stringify([]));
		fbSync(async () => {
			const jobsSnap = await getDocs(collection(db, "jobs"));
			const appsSnap = await getDocs(collection(db, "applications"));
			if (!jobsSnap.empty) {
				const fbJobs = jobsSnap.docs.map((d) => d.data());
				localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify(fbJobs));
			} else {
				const localJobs = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.JOBS) || "[]");
				for (const job of localJobs) await setDoc(doc(db, "jobs", job.id), job);
			}
			if (!appsSnap.empty) {
				const fbApps = appsSnap.docs.map((d) => d.data());
				localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify(fbApps));
			} else {
				const localApps = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.APPLICATIONS) || "[]");
				for (const app of localApps) await setDoc(doc(db, "applications", app.id), app);
			}
		});
	}
	/** Force-push all local data to Firebase (use from Admin panel) */
	async pushAllToFirebase() {
		const jobs = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.JOBS) || "[]");
		const apps = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.APPLICATIONS) || "[]");
		for (const job of jobs) await setDoc(doc(db, "jobs", job.id), job);
		for (const app of apps) await setDoc(doc(db, "applications", app.id), app);
		return {
			jobs: jobs.length,
			applications: apps.length
		};
	}
	getRegisteredUserAccounts() {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem("realjob_db_registered_users");
		if (!raw) return [];
		try {
			return JSON.parse(raw).map((u) => ({
				...u,
				fullName: u.fullName || u.email?.split("@")[0] || "User"
			}));
		} catch {
			return [];
		}
	}
	getRegisteredUsers() {
		return this.getRegisteredUserAccounts();
	}
	registerAccount(user) {
		const list = this.getRegisteredUserAccounts();
		const cleanEmail = user.email.trim().toLowerCase();
		const existingIndex = list.findIndex((u) => u.email.toLowerCase() === cleanEmail);
		const fallbackName = cleanEmail.split("@")[0] || "User";
		const account = {
			id: `usr-${Date.now()}`,
			email: cleanEmail,
			password: user.password || "",
			mobile: user.mobile || "",
			role: user.role,
			fullName: user.fullName || fallbackName,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		if (existingIndex >= 0) list[existingIndex] = {
			...list[existingIndex],
			...account
		};
		else list.push(account);
		if (typeof window !== "undefined") {
			localStorage.setItem("realjob_db_registered_users", JSON.stringify(list));
			fbSync(() => setDoc(doc(db, "users", account.id), account));
		}
		return account;
	}
	findRegisteredAccount(email) {
		const cleanEmail = email.trim().toLowerCase();
		return this.getRegisteredUserAccounts().find((u) => u.email.toLowerCase() === cleanEmail);
	}
	getCurrentUser() {
		if (typeof window === "undefined") return null;
		const raw = localStorage.getItem(this.STORAGE_KEYS.USER);
		if (!raw) return null;
		try {
			return JSON.parse(raw);
		} catch {
			return null;
		}
	}
	setCurrentUser(userData) {
		if (typeof window === "undefined") return;
		if (!userData) localStorage.removeItem(this.STORAGE_KEYS.USER);
		else localStorage.setItem(this.STORAGE_KEYS.USER, JSON.stringify(userData));
	}
	logout() {
		this.setCurrentUser(null);
	}
	getAllJobs() {
		if (typeof window === "undefined") return INITIAL_JOBS;
		const raw = localStorage.getItem(this.STORAGE_KEYS.JOBS);
		if (!raw) return INITIAL_JOBS;
		try {
			const parsed = JSON.parse(raw);
			const cleaned = parsed.filter((j) => !j.id.startsWith("job-c") && !j.id.startsWith("job-it") && !j.id.startsWith("job-eng") && !j.id.startsWith("job-hc") && !j.id.startsWith("job-tr") && !j.id.startsWith("job-ag") && !j.id.startsWith("job-fin") && !j.id.startsWith("job-sm") && !j.id.startsWith("job-edu") && !j.id.startsWith("job-mfg") && !j.id.startsWith("job-hr") && !j.id.startsWith("job-hosp") && !j.id.startsWith("job-log") && !j.id.startsWith("job-gov") && !j.id.startsWith("job-legal") && !j.id.startsWith("job-arch") && !j.id.startsWith("job-ret") && !j.id.startsWith("job-bpo") && !j.id.startsWith("job-des") && !j.id.startsWith("c-") && !j.id.startsWith("it-") && !j.id.startsWith("eng-") && !j.id.startsWith("hc-") && !j.id.startsWith("fin-") && !j.id.startsWith("sm-") && !j.id.startsWith("edu-") && !j.id.startsWith("mfg-") && !j.id.startsWith("hr-") && !j.id.startsWith("hosp-") && !j.id.startsWith("log-") && !j.id.startsWith("gov-") && !j.id.startsWith("leg-") && !j.id.startsWith("arch-") && !j.id.startsWith("ret-") && !j.id.startsWith("bpo-") && !j.id.startsWith("des-") && !j.id.startsWith("agri-") && !j.id.startsWith("sci-") && !j.id.startsWith("med-") && j.company?.toLowerCase() !== "alpha byete" && j.title?.toLowerCase() !== "software company");
			if (cleaned.length !== parsed.length) localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify(cleaned));
			return cleaned;
		} catch {
			return INITIAL_JOBS;
		}
	}
	getActiveJobs() {
		return this.getAllJobs().filter((j) => j.status === "Active" && (j.approvalStatus === "approved" || !j.approvalStatus));
	}
	getPendingJobs() {
		return this.getAllJobs().filter((j) => j.approvalStatus === "pending");
	}
	getApprovedJobs() {
		return this.getAllJobs().filter((j) => j.approvalStatus === "approved" || !j.approvalStatus);
	}
	getRejectedJobs() {
		return this.getAllJobs().filter((j) => j.approvalStatus === "rejected");
	}
	getJobById(jobId) {
		return this.getAllJobs().find((j) => j.id === jobId);
	}
	createJob(jobData) {
		const jobs = this.getAllJobs();
		const initials = (jobData.company || "Company").substring(0, 2).toUpperCase();
		const newJob = {
			...jobData,
			id: `job-${Date.now()}`,
			postedDate: (/* @__PURE__ */ new Date()).toISOString(),
			postedAgo: "Just now",
			initials,
			approvalStatus: jobData.approvalStatus || "pending"
		};
		jobs.unshift(newJob);
		if (typeof window !== "undefined") {
			localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify(jobs));
			fbSync(() => setDoc(doc(db, "jobs", newJob.id), newJob));
		}
		return newJob;
	}
	updateJobApprovalStatus(jobId, approvalStatus) {
		return this.updateJob(jobId, { approvalStatus });
	}
	updateJob(jobId, updates) {
		const jobs = this.getAllJobs();
		const existing = jobs.find((j) => j.id === jobId);
		if (!existing) return null;
		const index = jobs.findIndex((j) => j.id === jobId);
		const updatedJob = {
			...existing,
			...updates
		};
		jobs[index] = updatedJob;
		if (typeof window !== "undefined") {
			localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify(jobs));
			fbSync(() => setDoc(doc(db, "jobs", updatedJob.id), updatedJob));
		}
		return updatedJob;
	}
	deleteJob(jobId) {
		let jobs = this.getAllJobs();
		jobs = jobs.filter((j) => j.id !== jobId);
		if (typeof window !== "undefined") {
			localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify(jobs));
			fbSync(() => deleteDoc(doc(db, "jobs", jobId)));
		}
		return true;
	}
	deleteAllJobs() {
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify([]));
		return true;
	}
	getEmployerJobs(identifier) {
		const jobs = this.getAllJobs();
		if (!identifier || !identifier.trim()) return [];
		const q = identifier.toLowerCase().trim();
		return jobs.filter((j) => {
			const empId = (j.employerId || "").toLowerCase().trim();
			const comp = (j.company || "").toLowerCase().trim();
			if (!empId && !comp) return false;
			return empId === q || comp === q || q.length >= 4 && (empId.includes(q) || comp.includes(q));
		});
	}
	getAllApplications() {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.APPLICATIONS);
		if (!raw) return [];
		try {
			const apps = JSON.parse(raw);
			let modified = false;
			const updated = apps.map((app) => {
				if (!app.candidateMobile || app.candidateMobile === "9822011223" || app.candidateMobile === "+91 98220 11223") {
					const reg = this.findRegisteredAccount(app.candidateEmail || app.jobSeekerId);
					if (reg?.mobile) {
						modified = true;
						return {
							...app,
							candidateMobile: reg.mobile
						};
					}
				}
				return app;
			});
			if (modified) localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify(updated));
			return updated;
		} catch {
			return [];
		}
	}
	hasAlreadyApplied(jobSeekerId, jobId) {
		return this.getAllApplications().some((a) => (a.jobSeekerId === jobSeekerId || a.candidateEmail === jobSeekerId) && a.jobId === jobId);
	}
	createApplication(appData) {
		const apps = this.getAllApplications();
		if (this.hasAlreadyApplied(appData.jobSeekerId, appData.jobId)) throw new Error("Already applied to this job");
		const newApp = {
			...appData,
			id: `app-${Date.now()}`,
			appliedDate: (/* @__PURE__ */ new Date()).toLocaleDateString("en-IN", {
				day: "numeric",
				month: "short",
				year: "numeric"
			}),
			status: "Applied"
		};
		apps.unshift(newApp);
		if (typeof window !== "undefined") {
			localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify(apps));
			fbSync(() => setDoc(doc(db, "applications", newApp.id), newApp));
		}
		return newApp;
	}
	getEmployerApplications(identifier) {
		const apps = this.getAllApplications();
		if (!identifier || !identifier.trim()) return [];
		const q = identifier.toLowerCase().trim();
		return apps.filter((a) => {
			const empId = (a.employerId || "").toLowerCase().trim();
			const comp = (a.companyName || "").toLowerCase().trim();
			if (!empId && !comp) return false;
			return empId === q || comp === q || q.length >= 4 && (empId.includes(q) || comp.includes(q));
		});
	}
	getJobSeekerApplications(jobSeekerId) {
		return this.getAllApplications().filter((a) => a.jobSeekerId === jobSeekerId || a.candidateEmail === jobSeekerId);
	}
	updateApplicationStatus(applicationId, status) {
		const apps = this.getAllApplications();
		const existing = apps.find((a) => a.id === applicationId);
		if (!existing) return null;
		const index = apps.findIndex((a) => a.id === applicationId);
		const updatedApp = {
			...existing,
			status
		};
		apps[index] = updatedApp;
		if (typeof window !== "undefined") {
			localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify(apps));
			fbSync(() => updateDoc(doc(db, "applications", updatedApp.id), { status }));
		}
		return updatedApp;
	}
	getSavedJobs(jobSeekerId) {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.SAVED_JOBS);
		if (!raw) return [];
		try {
			return JSON.parse(raw).filter((s) => s.jobSeekerId === jobSeekerId);
		} catch {
			return [];
		}
	}
	saveJob(jobSeekerId, jobId) {
		const all = this.getSavedJobs(jobSeekerId);
		if (all.some((s) => s.jobId === jobId)) return all.find((s) => s.jobId === jobId);
		const newSaved = {
			id: `save-${Date.now()}`,
			jobSeekerId,
			jobId,
			savedDate: (/* @__PURE__ */ new Date()).toISOString()
		};
		const raw = localStorage.getItem(this.STORAGE_KEYS.SAVED_JOBS);
		const existing = raw ? JSON.parse(raw) : [];
		existing.push(newSaved);
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.SAVED_JOBS, JSON.stringify(existing));
		return newSaved;
	}
	removeSavedJob(jobSeekerId, jobId) {
		const raw = localStorage.getItem(this.STORAGE_KEYS.SAVED_JOBS);
		if (!raw) return true;
		let existing = JSON.parse(raw);
		existing = existing.filter((s) => !(s.jobSeekerId === jobSeekerId && s.jobId === jobId));
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.SAVED_JOBS, JSON.stringify(existing));
		return true;
	}
	getRecommendedJobs(candidateSkills, candidateCategory) {
		const allJobs = this.getActiveJobs();
		if (!candidateSkills.length && !candidateCategory) return allJobs.slice(0, 4);
		return allJobs.map((job) => {
			let score = 0;
			if (candidateCategory && job.category.toLowerCase().includes(candidateCategory.toLowerCase())) score += 5;
			candidateSkills.forEach((skill) => {
				if (job.requiredSkills.some((s) => s.toLowerCase().includes(skill.toLowerCase())) || job.title.toLowerCase().includes(skill.toLowerCase())) score += 3;
			});
			return {
				job,
				score
			};
		}).sort((a, b) => b.score - a.score).slice(0, 6).map((item) => item.job);
	}
	getApplicationsByJobSeeker(jobSeekerId) {
		return this.getJobSeekerApplications(jobSeekerId);
	}
	getInterviews() {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.INTERVIEWS);
		if (!raw) return [];
		try {
			return JSON.parse(raw);
		} catch {
			return [];
		}
	}
	scheduleInterview(data) {
		const interviews = this.getInterviews();
		const newInt = {
			...data,
			id: `int-${Date.now()}`
		};
		interviews.unshift(newInt);
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.INTERVIEWS, JSON.stringify(interviews));
		return newInt;
	}
	getUserResumes(userId) {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.RESUMES);
		if (!raw) return [];
		try {
			return JSON.parse(raw).filter((r) => r.userId === userId);
		} catch {
			return [];
		}
	}
	addUserResume(data) {
		const raw = localStorage.getItem(this.STORAGE_KEYS.RESUMES);
		const existing = raw ? JSON.parse(raw) : [];
		const newRes = {
			...data,
			id: `res-${Date.now()}`,
			uploadDate: data.uploadDate || (/* @__PURE__ */ new Date()).toLocaleDateString("en-IN", {
				day: "numeric",
				month: "short",
				year: "numeric"
			})
		};
		existing.unshift(newRes);
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.RESUMES, JSON.stringify(existing));
		return newRes;
	}
	deleteUserResume(id) {
		const raw = localStorage.getItem(this.STORAGE_KEYS.RESUMES);
		if (!raw) return true;
		try {
			let existing = JSON.parse(raw);
			existing = existing.filter((r) => r.id !== id);
			if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.RESUMES, JSON.stringify(existing));
		} catch {}
		return true;
	}
};
var dataStore = new DataStoreManager();
//#endregion
export { dataStore as t };
