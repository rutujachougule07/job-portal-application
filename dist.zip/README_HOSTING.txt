========================================================
REAL JOB PORTAL - DOMAIN HOSTING INSTRUCTIONS
========================================================

1. CPANEL / HOSTINGER / GODADDY / APACHE / SHARED HOSTING:
   - cPanel मध्ये File Manager उघडा.
   - 'public_html' (किंवा तुमच्या domain च्या root फोल्डर) मध्ये जा.
   - या 'dist' मधील सर्व फाईल्स (index.html, .htaccess, assets फोल्डर, इ.) अपलोड करा.
   - .htaccess मुळे सर्व routes (जसे /admin, /auth, /employee-dashboard) आपोआप चालतील!

2. VERCEL HOSTING:
   - Vercel वर थेट GitHub repository कनेक्ट करू शकता किंवा Vercel CLI द्वारे deploy करू शकता.

3. NODE.JS / VPS / CLOUD HOSTING:
   - या फोल्डरमध्ये 'node standalone-server.mjs' चालवा.
   - ॲप port 3000 वर सुरू होईल (किंवा PORT environment variable वापरा).

========================================================
