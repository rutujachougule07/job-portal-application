import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n } from "./i18n-BcT9wMyM.mjs";
import { t as Button } from "./button--9UiOy7A.mjs";
import { S as useParams, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { A as Share2, H as PhoneCall, Ht as CircleCheck, Y as MapPin, c as User, r as X, sn as BadgeCheck } from "../_libs/lucide-react.mjs";
import { t as PublicHeader } from "./PublicHeader-CBfbRu9r.mjs";
import { t as PublicFooter } from "./PublicFooter-Ce7-btPc.mjs";
import { t as Badge } from "./badge-DRaMiws1.mjs";
import { n as workersList } from "./WorkerCard-BpiSE5kp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/workers._workerId-B-LG6_y1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function WorkerProfilePage() {
	const { t, n, lang } = useI18n();
	const { workerId } = useParams({ from: "/workers/$workerId" });
	const worker = workersList.find((w) => w.id === workerId) ?? workersList[0];
	const [showContactModal, setShowContactModal] = (0, import_react.useState)(false);
	const [requestSubmitted, setRequestSubmitted] = (0, import_react.useState)(false);
	const [employerName, setEmployerName] = (0, import_react.useState)("");
	const [employerPhone, setEmployerPhone] = (0, import_react.useState)("");
	const [jobDescription, setJobDescription] = (0, import_react.useState)("");
	const displayProfession = lang === "mr" ? worker.marathiProfession : lang === "hi" ? worker.hindiProfession || worker.profession : worker.profession;
	const handleHireSubmit = (e) => {
		e.preventDefault();
		setRequestSubmitted(true);
		toast.success(`Hire request sent to ${worker.name}! They will contact you shortly.`);
		setTimeout(() => {
			setShowContactModal(false);
			setRequestSubmitted(false);
		}, 2500);
	};
	const handleShare = () => {
		if (navigator.share) navigator.share({
			title: `${worker.name} — ${worker.profession}`,
			text: `Check out ${worker.name} on REAL JOB: ${worker.profession} with ${worker.experience} experience.`,
			url: window.location.href
		});
		else {
			navigator.clipboard.writeText(window.location.href);
			toast.success("Profile link copied to clipboard!");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "bg-[#F5F8FC] min-h-screen py-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-5xl px-4 sm:px-6 lg:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-xs font-bold text-[#5B6B7F] mb-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								className: "hover:text-[#063B78]",
								children: t("home")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "/" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/workers",
								className: "hover:text-[#063B78]",
								children: t("workers")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "/" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[#10233F]",
								children: worker.name
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white rounded-2xl p-6 sm:p-8 border border-[#DCE5F0] shadow-sm mb-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start sm:items-center gap-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative shrink-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: worker.photoUrl,
										alt: worker.name,
										className: "size-24 rounded-2xl object-cover border-4 border-[#063B78] shadow-md"
									}), worker.verified && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { className: "size-7 text-[#FFC400] fill-[#063B78] absolute -bottom-2 -right-2" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 flex-wrap",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
											className: "text-2xl sm:text-3xl font-black text-[#10233F]",
											children: worker.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
											className: "bg-[#FFC400] text-[#082F63] font-black text-xs px-2.5 py-0.5",
											children: [
												"★ ",
												n(worker.rating),
												" (",
												n(worker.reviewsCount),
												" Reviews)"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-base font-extrabold text-[#063B78] mt-1",
										children: displayProfession
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 flex flex-wrap gap-4 text-xs font-semibold text-[#5B6B7F]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4 text-[#125BB5]" }),
												" ",
												worker.location
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-4 text-[#063B78]" }),
												" ",
												t("ageLabel"),
												": ",
												n(worker.age),
												" ",
												t("yearsOld")
											]
										})]
									})
								] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex sm:flex-col gap-3 w-full sm:w-auto shrink-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: () => setShowContactModal(true),
									className: "btn-yellow flex-1 sm:flex-none font-black text-xs px-6 py-3 h-11",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneCall, { className: "size-4 mr-1.5" }),
										" ",
										t("hireWorker")
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: handleShare,
									className: "flex-1 sm:flex-none border-[#063B78] text-[#063B78] font-bold text-xs px-4 h-11",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-4 mr-1.5" }), " Share"]
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 grid grid-cols-2 sm:grid-cols-4 gap-4 bg-[#F5F8FC] p-4 rounded-xl border border-[#DCE5F0]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-bold uppercase text-[#5B6B7F] block",
									children: t("experience")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-black text-[#10233F]",
									children: n(worker.experience)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-bold uppercase text-[#5B6B7F] block",
									children: t("expectedSalary")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-black text-[#063B78]",
									children: n(worker.expectedSalary)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-bold uppercase text-[#5B6B7F] block",
									children: t("availabilityLabel")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-black text-[#125BB5]",
									children: worker.availability
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-bold uppercase text-[#5B6B7F] block",
									children: "Languages"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-bold text-[#10233F]",
									children: worker.languages.join(", ")
								})] })
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid md:grid-cols-3 gap-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "md:col-span-2 space-y-8",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 sm:p-8 rounded-2xl border border-[#DCE5F0] shadow-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
										className: "text-lg font-black text-[#10233F] mb-3 flex items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-5 text-[#063B78]" }),
											" ",
											t("aboutAndExp")
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold text-[#5B6B7F] leading-relaxed",
										children: worker.about
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-6 pt-6 border-t border-[#DCE5F0]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "text-xs font-extrabold text-[#10233F] uppercase tracking-wider mb-3",
											children: t("skillsAndExpertise")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex flex-wrap gap-2",
											children: worker.skills.map((skill, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
												className: "bg-[#EBF1F8] text-[#063B78] font-bold text-xs px-3 py-1 border-0",
												children: ["✓ ", skill]
											}, i))
										})]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 sm:p-8 rounded-2xl border border-[#DCE5F0] shadow-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-lg font-black text-[#10233F] mb-4 flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { className: "size-5 text-[#FFC400]" }),
										" ",
										t("verifiedStatus")
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start gap-3 p-3.5 bg-[#F5F8FC] rounded-xl border border-[#DCE5F0]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5 text-[#063B78] shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-extrabold text-[#10233F] block",
											children: t("aadhaarVerifiedPhone")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[11px] font-semibold text-[#5B6B7F]",
											children: worker.phone.replace(/(\d{3})\d{4}(\d{2})/, "$1****$2")
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start gap-3 p-3.5 bg-[#F5F8FC] rounded-xl border border-[#DCE5F0]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5 text-[#063B78] shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-extrabold text-[#10233F] block",
											children: t("tradeCertVerified")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[11px] font-semibold text-[#5B6B7F]",
											children: "Verified by REAL JOB Field Inspection Team"
										})] })]
									})]
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 rounded-2xl border border-[#DCE5F0] shadow-xs sticky top-24",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-base font-black text-[#10233F] mb-3",
										children: t("directHire")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold text-[#5B6B7F] mb-4",
										children: t("directHireDesc")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										onClick: () => setShowContactModal(true),
										className: "w-full btn-yellow font-black text-xs py-3 h-11 mb-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneCall, { className: "size-4 mr-1.5" }),
											" ",
											t("callWorker")
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] font-bold text-[#5B6B7F] text-center",
										children: t("freeDirectContact")
									})
								]
							})
						})]
					})
				]
			}), showContactModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-[#082F63]/60 backdrop-blur-sm flex items-center justify-center p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white w-full max-w-md rounded-2xl p-6 shadow-2xl relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setShowContactModal(false),
						className: "absolute right-4 top-4 text-[#5B6B7F] hover:text-[#10233F]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					}), requestSubmitted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center py-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-16 text-[#063B78] mx-auto mb-3 animate-bounce" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xl font-black text-[#10233F]",
								children: t("contactSent")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold text-[#5B6B7F] mt-2",
								children: t("contactSentDesc")
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleHireSubmit,
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg font-black text-[#10233F]",
								children: t("contactWorkerTitle")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold text-[#5B6B7F]",
								children: t("enterDetails")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: t("yourName")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								required: true,
								placeholder: "Rajesh Patil",
								value: employerName,
								onChange: (e) => setEmployerName(e.target.value),
								className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: t("phoneNumber")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "tel",
								required: true,
								placeholder: "+91 98220 00000",
								value: employerPhone,
								onChange: (e) => setEmployerPhone(e.target.value),
								className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: t("jobDescription")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								rows: 3,
								placeholder: t("jobDetailsPlaceholder"),
								value: jobDescription,
								onChange: (e) => setJobDescription(e.target.value),
								className: "w-full rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] p-3 text-xs font-bold text-[#10233F]"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								className: "w-full btn-yellow font-black text-xs py-3 h-11",
								children: t("sendRequest")
							})
						]
					})]
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
	] });
}
//#endregion
export { WorkerProfilePage as component };
