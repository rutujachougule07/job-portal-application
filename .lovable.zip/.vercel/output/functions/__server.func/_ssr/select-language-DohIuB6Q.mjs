import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as stringType, t as objectType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/select-language-DohIuB6Q.js
var $$splitComponentImporter = () => import("./select-language-izIRZmA7.mjs");
var Route = createFileRoute("/select-language")({
	validateSearch: objectType({ redirectTo: stringType().optional().catch("/home") }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
