import "../_libs/firebase.mjs";
import { a as deleteDoc, b as doc, c as getDocs, l as setDoc, u as updateDoc, y as collection } from "../_libs/@firebase/firestore+[...].mjs";
import { n as db } from "./firebase-irBfmyIj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/data-store-CPuK80w4.js
/**
* REAL JOB Unified Data Store & Management System
* Handles Users, Employers, Jobs, Applications, SavedJobs, JobAlerts & Recommendations
*/
function fbSync(fn) {
	if (typeof window !== "undefined") fn().catch(console.error);
}
var DEFAULT_JOB_PACKAGES = [
	{
		id: "plan-200",
		name: "Starter Package",
		price: 200,
		jobCount: 1,
		workerCount: 3,
		description: "1 Job Posting + 3 CRM Included",
		features: [
			"1 Active Job Posting",
			"Add up to 3 CRM Users",
			"Attendance Register Access",
			"Zero Commission"
		]
	},
	{
		id: "plan-300",
		name: "Growth Package",
		price: 300,
		jobCount: 2,
		workerCount: 6,
		popular: true,
		badge: "BEST VALUE",
		description: "2 Job Postings + 6 CRM Included",
		features: [
			"2 Active Job Postings",
			"Add up to 6 CRM Users",
			"Featured Badge on Listings",
			"Priority Support"
		]
	},
	{
		id: "plan-500",
		name: "Business Package",
		price: 500,
		jobCount: 5,
		workerCount: 15,
		description: "5 Job Postings + 15 CRM Included",
		features: [
			"5 Active Job Postings",
			"Add up to 15 CRM Users",
			"Highlighted Listings",
			"Direct WhatsApp & Call Connect"
		]
	},
	{
		id: "plan-999",
		name: "Enterprise Unlimited",
		price: 999,
		jobCount: 10,
		workerCount: 9999,
		badge: "UNLIMITED",
		description: "10 Job Postings + Unlimited CRM Included",
		features: [
			"10 Active Job Postings",
			"Unlimited CRM Users",
			"Top Priority Ranking",
			"Dedicated Account Manager"
		]
	}
];
var INITIAL_SUBADMINS = [{
	id: "subadmin_demo_1",
	fullName: "Rahul Patil",
	username: "rahul123",
	email: "rahul.subadmin@realjob.com",
	mobile: "9823456789",
	password: "subadmin123",
	role: "subadmin",
	designation: "Operations & Verification Admin",
	permissions: [
		"job-approvals",
		"users-directory",
		"job-applications"
	],
	status: "active",
	createdBy: "superadmin",
	createdAt: "2026-03-01T10:00:00.000Z"
}, {
	id: "subadmin_demo_2",
	fullName: "Pooja Deshmukh",
	username: "pooja123",
	email: "pooja.subadmin@realjob.com",
	mobile: "9876543210",
	password: "subadmin123",
	role: "subadmin",
	designation: "Content & Portal Moderator",
	permissions: ["landing-page", "job-applications"],
	status: "active",
	createdBy: "superadmin",
	createdAt: "2026-03-15T14:30:00.000Z"
}];
var DEFAULT_SUPERADMIN_CATEGORIES = [
	{
		label: "Factory Worker",
		iconName: "Factory",
		theme: "blue"
	},
	{
		label: "Construction",
		iconName: "HardHat",
		theme: "yellow"
	},
	{
		label: "Technical Staff",
		iconName: "Wrench",
		theme: "purple"
	},
	{
		label: "Transport & Logistics",
		iconName: "Truck",
		theme: "green"
	},
	{
		label: "Electrician",
		iconName: "Zap",
		theme: "orange"
	},
	{
		label: "Security Guard",
		iconName: "Shield",
		theme: "red"
	},
	{
		label: "Office Staff",
		iconName: "Briefcase",
		theme: "blue"
	}
];
var INITIAL_JOBS = [];
function isRemovedTestCategory(_cat) {
	return false;
}
var DataStoreManager = class {
	STORAGE_KEYS = {
		USER: "realjob_current_user",
		JOBS: "realjob_db_jobs",
		APPLICATIONS: "realjob_db_applications",
		SAVED_JOBS: "realjob_db_saved_jobs",
		JOB_ALERTS: "realjob_db_job_alerts",
		PROFILES: "realjob_db_profiles",
		EMPLOYERS: "realjob_db_employers",
		INTERVIEWS: "realjob_db_interviews",
		RESUMES: "realjob_db_resumes",
		PACKAGES: "realjob_db_packages",
		EMP_WORKERS: "realjob_db_emp_workers",
		ATTENDANCE: "realjob_db_attendance",
		SUBADMINS: "realjob_db_subadmins"
	};
	constructor() {
		this.initializeDefaults();
	}
	initializeDefaults() {
		if (typeof window === "undefined") return;
		if (!localStorage.getItem(this.STORAGE_KEYS.JOBS)) localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify([]));
		else try {
			const raw = localStorage.getItem(this.STORAGE_KEYS.JOBS) || "[]";
			const parsed = JSON.parse(raw);
			const cleaned = parsed.filter((j) => !isRemovedTestCategory(j.category));
			if (cleaned.length !== parsed.length) localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify(cleaned));
		} catch {}
		if (!localStorage.getItem(this.STORAGE_KEYS.APPLICATIONS)) localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify([]));
		if (!localStorage.getItem(this.STORAGE_KEYS.SAVED_JOBS)) localStorage.setItem(this.STORAGE_KEYS.SAVED_JOBS, JSON.stringify([]));
		if (!localStorage.getItem(this.STORAGE_KEYS.JOB_ALERTS)) localStorage.setItem(this.STORAGE_KEYS.JOB_ALERTS, JSON.stringify([]));
		if (!localStorage.getItem(this.STORAGE_KEYS.EMP_WORKERS)) localStorage.setItem(this.STORAGE_KEYS.EMP_WORKERS, JSON.stringify([]));
		if (!localStorage.getItem(this.STORAGE_KEYS.ATTENDANCE)) localStorage.setItem(this.STORAGE_KEYS.ATTENDANCE, JSON.stringify([]));
		if (!localStorage.getItem(this.STORAGE_KEYS.SUBADMINS)) localStorage.setItem(this.STORAGE_KEYS.SUBADMINS, JSON.stringify(INITIAL_SUBADMINS));
		fbSync(async () => {
			const jobsSnap = await getDocs(collection(db, "jobs"));
			const appsSnap = await getDocs(collection(db, "applications"));
			const usersSnap = await getDocs(collection(db, "users"));
			const workersSnap = await getDocs(collection(db, "workers"));
			const attendanceSnap = await getDocs(collection(db, "attendance"));
			if (!jobsSnap.empty) {
				const validJobs = [];
				for (const docItem of jobsSnap.docs) {
					const jData = docItem.data();
					if (isRemovedTestCategory(jData.category)) await deleteDoc(doc(db, "jobs", docItem.id)).catch(() => {});
					else validJobs.push({
						...jData,
						id: jData.id || docItem.id
					});
				}
				localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify(validJobs));
			} else localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify([]));
			if (!appsSnap.empty) {
				const fbApps = appsSnap.docs.map((d) => ({
					...d.data(),
					id: d.id
				}));
				localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify(fbApps));
			} else localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify([]));
			if (!usersSnap.empty) {
				const emailToDocs = /* @__PURE__ */ new Map();
				for (const docItem of usersSnap.docs) {
					const u = docItem.data();
					const email = (u.email || "").trim().toLowerCase();
					const cleanMobile = (u.mobile || "").replace(/\D/g, "");
					const key = email || (cleanMobile ? `${cleanMobile}@realjob.com` : docItem.id);
					if (!emailToDocs.has(key)) emailToDocs.set(key, []);
					emailToDocs.get(key).push({
						id: docItem.id,
						data: {
							...u,
							id: u.id || docItem.id
						}
					});
				}
				const validUsers = [];
				for (const [, docList] of emailToDocs.entries()) {
					if (docList.length === 1 && docList[0]) {
						validUsers.push(docList[0].data);
						continue;
					}
					let primary = docList.find((d) => !d.id.startsWith("usr-"));
					if (!primary && docList.length > 0) primary = docList[docList.length - 1];
					if (!primary) continue;
					let mergedData = { ...primary.data };
					for (const d of docList) if (d.id !== primary.id) mergedData = {
						...d.data,
						...mergedData,
						id: primary.id
					};
					validUsers.push(mergedData);
					for (const d of docList) if (d.id !== primary.id) deleteDoc(doc(db, "users", d.id)).catch(() => {});
				}
				localStorage.setItem("realjob_db_registered_users", JSON.stringify(validUsers));
			} else localStorage.setItem("realjob_db_registered_users", JSON.stringify([]));
			if (!workersSnap.empty) {
				const deletedIds = new Set(JSON.parse(localStorage.getItem("realjob_deleted_worker_ids") || "[]"));
				deletedIds.add("empw-1791635953540");
				deletedIds.add("empw-1791785681836");
				for (const docItem of workersSnap.docs) {
					const dData = docItem.data();
					if (deletedIds.has(docItem.id) || dData.status === "Deleted" || dData.isDeleted || dData.status === "Inactive") {
						deletedIds.add(docItem.id);
						deleteDoc(doc(db, "workers", docItem.id)).catch(() => {});
					}
				}
				localStorage.setItem("realjob_deleted_worker_ids", JSON.stringify(Array.from(deletedIds)));
				const fbWorkers = workersSnap.docs.map((d) => ({
					...d.data(),
					id: d.id
				})).filter((w) => !deletedIds.has(w.id) && w.status !== "Inactive" && w.status !== "Deleted" && !w.isDeleted);
				localStorage.setItem(this.STORAGE_KEYS.EMP_WORKERS, JSON.stringify(fbWorkers));
			} else localStorage.setItem(this.STORAGE_KEYS.EMP_WORKERS, JSON.stringify([]));
			if (!attendanceSnap.empty) {
				const fbAtt = attendanceSnap.docs.map((d) => ({
					...d.data(),
					id: d.id
				}));
				localStorage.setItem(this.STORAGE_KEYS.ATTENDANCE, JSON.stringify(fbAtt));
			} else localStorage.setItem(this.STORAGE_KEYS.ATTENDANCE, JSON.stringify([]));
			try {
				const subadminsSnap = await getDocs(collection(db, "subadmins"));
				if (!subadminsSnap.empty) {
					const fbSub = subadminsSnap.docs.map((d) => d.data());
					localStorage.setItem(this.STORAGE_KEYS.SUBADMINS, JSON.stringify(fbSub));
				} else {
					const localSub = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.SUBADMINS) || "[]");
					for (const s of localSub) await setDoc(doc(db, "subadmins", s.id), s);
				}
			} catch (e) {}
		});
	}
	getSubAdmins() {
		if (typeof window === "undefined") return INITIAL_SUBADMINS;
		const raw = localStorage.getItem(this.STORAGE_KEYS.SUBADMINS);
		if (!raw) return INITIAL_SUBADMINS;
		try {
			const list = JSON.parse(raw);
			if (!Array.isArray(list) || list.length === 0) {
				localStorage.setItem(this.STORAGE_KEYS.SUBADMINS, JSON.stringify(INITIAL_SUBADMINS));
				return INITIAL_SUBADMINS;
			}
			return list;
		} catch {
			return INITIAL_SUBADMINS;
		}
	}
	findSubAdminByLogin(credential) {
		if (!credential) return null;
		const list = this.getSubAdmins();
		const clean = credential.trim().toLowerCase();
		return list.find((s) => s.email.toLowerCase() === clean || s.username && s.username.toLowerCase() === clean) || null;
	}
	addSubAdmin(data) {
		const list = this.getSubAdmins();
		const cleanEmail = data.email.trim().toLowerCase();
		const cleanUsername = (data.username || cleanEmail.split("@")[0] || "subadmin").trim().toLowerCase().replace(/\s+/g, "_");
		const newSub = {
			id: `subadmin_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
			fullName: data.fullName.trim(),
			username: cleanUsername,
			email: cleanEmail,
			mobile: data.mobile.trim(),
			password: data.password || "subadmin123",
			role: "subadmin",
			designation: data.designation?.trim() || "Sub-Admin",
			permissions: data.permissions && data.permissions.length > 0 ? data.permissions : [
				"job-approvals",
				"users-directory",
				"job-applications"
			],
			status: data.status || "active",
			createdBy: data.createdBy || "superadmin",
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		list.unshift(newSub);
		if (typeof window !== "undefined") {
			localStorage.setItem(this.STORAGE_KEYS.SUBADMINS, JSON.stringify(list));
			fbSync(() => setDoc(doc(db, "subadmins", newSub.id), newSub));
		}
		return newSub;
	}
	updateSubAdmin(id, updates) {
		const list = this.getSubAdmins();
		const idx = list.findIndex((s) => s.id === id);
		if (idx === -1) return null;
		const updated = {
			...list[idx],
			...updates,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		list[idx] = updated;
		if (typeof window !== "undefined") {
			localStorage.setItem(this.STORAGE_KEYS.SUBADMINS, JSON.stringify(list));
			fbSync(() => updateDoc(doc(db, "subadmins", id), updates));
		}
		return updated;
	}
	deleteSubAdmin(id) {
		let list = this.getSubAdmins();
		list = list.filter((s) => s.id !== id);
		if (typeof window !== "undefined") {
			localStorage.setItem(this.STORAGE_KEYS.SUBADMINS, JSON.stringify(list));
			fbSync(() => deleteDoc(doc(db, "subadmins", id)));
		}
		return true;
	}
	toggleSubAdminStatus(id) {
		const target = this.getSubAdmins().find((s) => s.id === id);
		if (!target) return null;
		const nextStatus = target.status === "active" ? "inactive" : "active";
		return this.updateSubAdmin(id, { status: nextStatus });
	}
	/** Force-push all local data to Firebase (use from Admin panel) */
	async pushAllToFirebase() {
		const jobs = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.JOBS) || "[]");
		const apps = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.APPLICATIONS) || "[]");
		for (const job of jobs) await setDoc(doc(db, "jobs", job.id), job);
		for (const app of apps) await setDoc(doc(db, "applications", app.id), app);
		return {
			jobs: jobs.length,
			applications: apps.length
		};
	}
	getRegisteredUserAccounts() {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem("realjob_db_registered_users");
		if (!raw) return [];
		try {
			return JSON.parse(raw).map((u) => ({
				...u,
				fullName: u.fullName || u.email?.split("@")[0] || "User"
			}));
		} catch {
			return [];
		}
	}
	getRegisteredUsers() {
		return this.getRegisteredUserAccounts();
	}
	registerAccount(user) {
		const list = this.getRegisteredUserAccounts();
		const cleanEmail = user.email.trim().toLowerCase();
		const existingIndex = list.findIndex((u) => u.email && u.email.toLowerCase() === cleanEmail || user.id && u.id === user.id);
		const fallbackName = cleanEmail.split("@")[0] || "User";
		const existing = existingIndex >= 0 ? list[existingIndex] : void 0;
		const finalId = user.id || existing?.id || `usr-${Date.now()}`;
		let oldIdToDelete = null;
		if (existing && existing.id && existing.id !== finalId) oldIdToDelete = existing.id;
		const account = {
			id: finalId,
			email: cleanEmail,
			password: user.password !== void 0 ? user.password : existing?.password || "",
			mobile: user.mobile !== void 0 ? user.mobile : existing?.mobile || "",
			role: user.role || existing?.role || "worker",
			fullName: user.fullName || existing?.fullName || fallbackName,
			profilePhoto: user.profilePhoto !== void 0 ? user.profilePhoto : existing?.profilePhoto || "",
			createdAt: existing?.createdAt || (/* @__PURE__ */ new Date()).toISOString()
		};
		if (existingIndex >= 0) list[existingIndex] = account;
		else list.push(account);
		if (typeof window !== "undefined") {
			localStorage.setItem("realjob_db_registered_users", JSON.stringify(list));
			if (oldIdToDelete) fbSync(() => deleteDoc(doc(db, "users", oldIdToDelete)).catch(() => {}));
			fbSync(() => setDoc(doc(db, "users", account.id), account, { merge: true }).catch(() => {}));
		}
		return account;
	}
	updateRegisteredAccount(userId, updates) {
		const list = this.getRegisteredUserAccounts();
		let index = list.findIndex((u) => u.id === userId);
		if (index < 0 && updates.email) index = list.findIndex((u) => u.email.toLowerCase() === updates.email.toLowerCase());
		let updated;
		let oldIdToDelete = null;
		if (index >= 0 && list[index]) {
			const existing = list[index];
			const newId = updates.id || userId || existing.id;
			if (existing.id && existing.id !== newId) oldIdToDelete = existing.id;
			updated = {
				...existing,
				...updates,
				id: newId
			};
			list[index] = updated;
		} else {
			updated = {
				id: userId || updates.id || `usr-${Date.now()}`,
				email: updates.email || "",
				password: updates.password || "",
				mobile: updates.mobile || "",
				role: updates.role || "employer",
				fullName: updates.fullName || "User",
				profilePhoto: updates.profilePhoto || "",
				createdAt: (/* @__PURE__ */ new Date()).toISOString(),
				...updates
			};
			list.push(updated);
		}
		if (typeof window !== "undefined") {
			localStorage.setItem("realjob_db_registered_users", JSON.stringify(list));
			if (oldIdToDelete) fbSync(() => deleteDoc(doc(db, "users", oldIdToDelete)).catch(() => {}));
			fbSync(() => setDoc(doc(db, "users", updated.id), updated, { merge: true }).catch(() => {}));
			this.setCurrentUser(updated);
		}
		return updated;
	}
	findRegisteredAccount(identifier) {
		const clean = identifier.trim().toLowerCase();
		const cleanDigits = clean.replace(/\D/g, "");
		return this.getRegisteredUserAccounts().find((u) => {
			const emailMatch = u.email.toLowerCase() === clean;
			const storedMobileDigits = (u.mobile || "").replace(/\D/g, "");
			const mobileMatch = cleanDigits.length >= 10 && storedMobileDigits.length >= 10 && storedMobileDigits === cleanDigits;
			return emailMatch || mobileMatch;
		});
	}
	deleteRegisteredUser(userId) {
		if (typeof window === "undefined") return false;
		let list = this.getRegisteredUserAccounts();
		list = list.filter((u) => u.id !== userId);
		localStorage.setItem("realjob_db_registered_users", JSON.stringify(list));
		const current = this.getCurrentUser();
		if (current && (current.id === userId || current.email === userId)) this.setCurrentUser(null);
		fbSync(() => deleteDoc(doc(db, "users", userId)));
		return true;
	}
	clearCurrentUser() {
		this.setCurrentUser(null);
	}
	deleteAllRegisteredUsers() {
		if (typeof window === "undefined") return false;
		const users = this.getRegisteredUserAccounts();
		localStorage.setItem("realjob_db_registered_users", JSON.stringify([]));
		for (const u of users) fbSync(() => deleteDoc(doc(db, "users", u.id)));
		return true;
	}
	deleteApplication(appId) {
		if (typeof window === "undefined") return false;
		let apps = this.getAllApplications();
		apps = apps.filter((a) => a.id !== appId);
		localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify(apps));
		fbSync(() => deleteDoc(doc(db, "applications", appId)));
		return true;
	}
	clearAllAdminData() {
		if (typeof window === "undefined") return;
		localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify([]));
		localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify([]));
		localStorage.setItem("realjob_db_registered_users", JSON.stringify([]));
		localStorage.setItem(this.STORAGE_KEYS.PACKAGES, JSON.stringify([]));
	}
	getCurrentUser(rolePreference) {
		if (typeof window === "undefined") return null;
		const savedRole = localStorage.getItem("realjob-role");
		const activeRole = rolePreference || (savedRole === "admin" ? "employer" : savedRole === "user" || savedRole === "worker" ? "worker" : void 0);
		const sessionRaw = sessionStorage.getItem("realjob_tab_user");
		if (sessionRaw) try {
			const u = JSON.parse(sessionRaw);
			if (!activeRole || u.role === activeRole || (activeRole === "employer" || activeRole === "admin") && (u.role === "admin" || u.role === "employer")) return u;
		} catch {}
		if (activeRole) {
			const prefKey = activeRole === "worker" ? "realjob-user-worker" : "realjob-user-admin";
			const roleRaw = localStorage.getItem(prefKey);
			if (roleRaw) try {
				const u = JSON.parse(roleRaw);
				if (u && u.email && (activeRole === "worker" && u.role === "worker" || (activeRole === "employer" || activeRole === "admin") && (u.role === "admin" || u.role === "employer"))) return u;
			} catch {}
		}
		const raw = localStorage.getItem("realjob-user") || localStorage.getItem(this.STORAGE_KEYS.USER);
		if (!raw) return null;
		try {
			const u = JSON.parse(raw);
			if (activeRole) {
				if (activeRole === "worker" && u.role === "worker" || (activeRole === "employer" || activeRole === "admin") && (u.role === "admin" || u.role === "employer")) return u;
				return null;
			}
			return u;
		} catch {
			return null;
		}
	}
	setCurrentUser(userData, targetRole) {
		if (typeof window === "undefined") return;
		if (!userData) {
			localStorage.removeItem(this.STORAGE_KEYS.USER);
			localStorage.removeItem("realjob-user");
			localStorage.removeItem("realjob-user-worker");
			localStorage.removeItem("realjob-user-admin");
			localStorage.removeItem("realjob-user-employer");
			localStorage.removeItem("realjob-role");
			sessionStorage.removeItem("realjob_tab_user");
		} else {
			const str = JSON.stringify(userData);
			localStorage.setItem(this.STORAGE_KEYS.USER, str);
			localStorage.setItem("realjob-user", str);
			localStorage.setItem("realjob-role", userData.role);
			sessionStorage.setItem("realjob_tab_user", str);
			if (userData.role === "worker") localStorage.setItem("realjob-user-worker", str);
			else {
				localStorage.setItem("realjob-user-admin", str);
				localStorage.setItem("realjob-user-employer", str);
			}
		}
		window.dispatchEvent(new Event("realjob-auth-change"));
		window.dispatchEvent(new Event("storage"));
	}
	logout(targetRole) {
		this.setCurrentUser(null, targetRole);
	}
	getExistingJobCategories() {
		const categoriesSet = /* @__PURE__ */ new Set();
		this.getAllJobs().forEach((job) => {
			if (job.category && job.category.trim()) categoriesSet.add(job.category.trim());
		});
		if (typeof window !== "undefined") try {
			const custom = localStorage.getItem("realjob_custom_categories");
			if (custom) {
				const parsed = JSON.parse(custom);
				if (Array.isArray(parsed)) parsed.forEach((c) => {
					if (typeof c === "string" && c.trim()) categoriesSet.add(c.trim());
				});
			}
		} catch {}
		return Array.from(categoriesSet);
	}
	addCustomCategory(cat) {
		if (!cat || !cat.trim()) return;
		const cleanCat = cat.trim();
		if (typeof window !== "undefined") try {
			const custom = localStorage.getItem("realjob_custom_categories");
			const list = custom ? JSON.parse(custom) : [];
			if (!list.some((c) => c.toLowerCase() === cleanCat.toLowerCase())) {
				list.push(cleanCat);
				localStorage.setItem("realjob_custom_categories", JSON.stringify(list));
			}
		} catch {}
	}
	getSuperadminCategories() {
		if (typeof window !== "undefined") {
			const saved = localStorage.getItem("cms_categories");
			if (saved) try {
				const parsed = JSON.parse(saved);
				if (Array.isArray(parsed) && parsed.length > 0) return parsed.filter((c) => !isRemovedTestCategory(c.label));
			} catch {}
		}
		return DEFAULT_SUPERADMIN_CATEGORIES;
	}
	getAllJobs() {
		if (typeof window === "undefined") return INITIAL_JOBS;
		const raw = localStorage.getItem(this.STORAGE_KEYS.JOBS);
		if (!raw) {
			localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify(INITIAL_JOBS));
			return INITIAL_JOBS;
		}
		try {
			const parsed = JSON.parse(raw);
			const filtered = parsed.filter((j) => !isRemovedTestCategory(j.category));
			let modified = filtered.length !== parsed.length;
			const updated = filtered.map((j) => {
				if (!j.approvalStatus) {
					modified = true;
					return {
						...j,
						approvalStatus: "pending"
					};
				}
				return j;
			});
			if (modified) localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify(updated));
			return updated;
		} catch {
			return INITIAL_JOBS;
		}
	}
	getActiveJobs() {
		return this.getAllJobs().filter((j) => j.status === "Active" && j.approvalStatus === "approved");
	}
	getPendingJobs() {
		return this.getAllJobs().filter((j) => j.approvalStatus === "pending");
	}
	getApprovedJobs() {
		return this.getAllJobs().filter((j) => j.approvalStatus === "approved");
	}
	getRejectedJobs() {
		return this.getAllJobs().filter((j) => j.approvalStatus === "rejected");
	}
	getJobById(jobId) {
		return this.getAllJobs().find((j) => j.id === jobId);
	}
	createJob(jobData) {
		if (jobData.category) this.addCustomCategory(jobData.category);
		const jobs = this.getAllJobs();
		const initials = (jobData.company || "Company").substring(0, 2).toUpperCase();
		const newJob = {
			...jobData,
			id: `job-${Date.now()}`,
			postedDate: (/* @__PURE__ */ new Date()).toISOString(),
			postedAgo: "Just now",
			initials,
			approvalStatus: jobData.approvalStatus || "pending",
			status: jobData.status || "Active"
		};
		jobs.unshift(newJob);
		if (typeof window !== "undefined") {
			localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify(jobs));
			fbSync(() => setDoc(doc(db, "jobs", newJob.id), newJob));
		}
		return newJob;
	}
	updateJobApprovalStatus(jobId, approvalStatus) {
		return this.updateJob(jobId, { approvalStatus });
	}
	updateJob(jobId, updates) {
		const jobs = this.getAllJobs();
		const existing = jobs.find((j) => j.id === jobId);
		if (!existing) return null;
		const index = jobs.findIndex((j) => j.id === jobId);
		const updatedJob = {
			...existing,
			...updates
		};
		jobs[index] = updatedJob;
		if (typeof window !== "undefined") {
			localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify(jobs));
			fbSync(() => setDoc(doc(db, "jobs", updatedJob.id), updatedJob));
		}
		return updatedJob;
	}
	deleteJob(jobId) {
		let jobs = this.getAllJobs();
		jobs = jobs.filter((j) => j.id !== jobId);
		if (typeof window !== "undefined") {
			localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify(jobs));
			fbSync(() => deleteDoc(doc(db, "jobs", jobId)));
		}
		return true;
	}
	deleteAllJobs() {
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify([]));
		return true;
	}
	getEmployerJobs(identifier) {
		const jobs = this.getAllJobs();
		if (!identifier || !identifier.trim()) return [];
		const q = identifier.toLowerCase().trim();
		return jobs.filter((j) => {
			const empId = (j.employerId || "").toLowerCase().trim();
			const comp = (j.company || "").toLowerCase().trim();
			if (!empId && !comp) return false;
			return empId === q || comp === q || q.length >= 4 && (empId.includes(q) || comp.includes(q));
		});
	}
	getApplications() {
		return this.getAllApplications();
	}
	getAllApplications() {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.APPLICATIONS);
		if (!raw) return [];
		try {
			const apps = JSON.parse(raw);
			let modified = false;
			const updated = apps.map((app) => {
				if (!app.candidateMobile || app.candidateMobile === "9822011223" || app.candidateMobile === "+91 98220 11223") {
					const reg = this.findRegisteredAccount(app.candidateEmail || app.jobSeekerId);
					if (reg?.mobile) {
						modified = true;
						return {
							...app,
							candidateMobile: reg.mobile
						};
					}
				}
				return app;
			});
			if (modified) localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify(updated));
			return updated;
		} catch {
			return [];
		}
	}
	hasAlreadyApplied(jobSeekerId, jobId) {
		return this.getAllApplications().some((a) => (a.jobSeekerId === jobSeekerId || a.candidateEmail === jobSeekerId) && a.jobId === jobId);
	}
	createApplication(appData) {
		const apps = this.getAllApplications();
		if (this.hasAlreadyApplied(appData.jobSeekerId, appData.jobId)) throw new Error("Already applied to this job");
		const newApp = {
			...appData,
			id: `app-${Date.now()}`,
			appliedDate: (/* @__PURE__ */ new Date()).toLocaleDateString("en-IN", {
				day: "numeric",
				month: "short",
				year: "numeric"
			}),
			status: "Applied"
		};
		apps.unshift(newApp);
		if (typeof window !== "undefined") {
			localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify(apps));
			fbSync(() => setDoc(doc(db, "applications", newApp.id), newApp));
		}
		return newApp;
	}
	getEmployerApplications(identifier) {
		const apps = this.getAllApplications();
		if (!identifier || !identifier.trim()) return [];
		const q = identifier.toLowerCase().trim();
		return apps.filter((a) => {
			const empId = (a.employerId || "").toLowerCase().trim();
			const comp = (a.companyName || "").toLowerCase().trim();
			if (!empId && !comp) return false;
			return empId === q || comp === q || q.length >= 4 && (empId.includes(q) || comp.includes(q));
		});
	}
	getJobSeekerApplications(jobSeekerId) {
		return this.getAllApplications().filter((a) => a.jobSeekerId === jobSeekerId || a.candidateEmail === jobSeekerId);
	}
	updateApplicationStatus(applicationId, status, replyMessage) {
		const apps = this.getAllApplications();
		const existing = apps.find((a) => a.id === applicationId);
		if (!existing) return null;
		const index = apps.findIndex((a) => a.id === applicationId);
		const updatedApp = {
			...existing,
			status,
			...replyMessage !== void 0 ? {
				replyMessage,
				replyDate: (/* @__PURE__ */ new Date()).toLocaleDateString("en-IN", {
					day: "numeric",
					month: "short",
					year: "numeric"
				})
			} : {}
		};
		apps[index] = updatedApp;
		if (typeof window !== "undefined") {
			localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify(apps));
			fbSync(() => updateDoc(doc(db, "applications", updatedApp.id), updatedApp));
		}
		return updatedApp;
	}
	updateApplicationReply(applicationId, replyMessage) {
		const apps = this.getAllApplications();
		const existing = apps.find((a) => a.id === applicationId);
		if (!existing) return null;
		const index = apps.findIndex((a) => a.id === applicationId);
		const updatedApp = {
			...existing,
			replyMessage,
			replyDate: (/* @__PURE__ */ new Date()).toLocaleDateString("en-IN", {
				day: "numeric",
				month: "short",
				year: "numeric"
			})
		};
		apps[index] = updatedApp;
		if (typeof window !== "undefined") {
			localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify(apps));
			fbSync(() => updateDoc(doc(db, "applications", updatedApp.id), updatedApp));
		}
		return updatedApp;
	}
	getSavedJobs(jobSeekerId) {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.SAVED_JOBS);
		if (!raw) return [];
		try {
			return JSON.parse(raw).filter((s) => s.jobSeekerId === jobSeekerId);
		} catch {
			return [];
		}
	}
	saveJob(jobSeekerId, jobId) {
		const all = this.getSavedJobs(jobSeekerId);
		if (all.some((s) => s.jobId === jobId)) return all.find((s) => s.jobId === jobId);
		const newSaved = {
			id: `save-${Date.now()}`,
			jobSeekerId,
			jobId,
			savedDate: (/* @__PURE__ */ new Date()).toISOString()
		};
		const raw = localStorage.getItem(this.STORAGE_KEYS.SAVED_JOBS);
		const existing = raw ? JSON.parse(raw) : [];
		existing.push(newSaved);
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.SAVED_JOBS, JSON.stringify(existing));
		return newSaved;
	}
	removeSavedJob(jobSeekerId, jobId) {
		const raw = localStorage.getItem(this.STORAGE_KEYS.SAVED_JOBS);
		if (!raw) return true;
		let existing = JSON.parse(raw);
		existing = existing.filter((s) => !(s.jobSeekerId === jobSeekerId && s.jobId === jobId));
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.SAVED_JOBS, JSON.stringify(existing));
		return true;
	}
	getRecommendedJobs(candidateSkills, candidateCategory) {
		const allJobs = this.getActiveJobs();
		if (!candidateSkills.length && !candidateCategory) return allJobs.slice(0, 4);
		return allJobs.map((job) => {
			let score = 0;
			if (candidateCategory && job.category.toLowerCase().includes(candidateCategory.toLowerCase())) score += 5;
			candidateSkills.forEach((skill) => {
				if (job.requiredSkills.some((s) => s.toLowerCase().includes(skill.toLowerCase())) || job.title.toLowerCase().includes(skill.toLowerCase())) score += 3;
			});
			return {
				job,
				score
			};
		}).sort((a, b) => b.score - a.score).slice(0, 6).map((item) => item.job);
	}
	getApplicationsByJobSeeker(jobSeekerId) {
		return this.getJobSeekerApplications(jobSeekerId);
	}
	getInterviews() {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.INTERVIEWS);
		if (!raw) return [];
		try {
			return JSON.parse(raw);
		} catch {
			return [];
		}
	}
	scheduleInterview(data) {
		const interviews = this.getInterviews();
		const newInt = {
			...data,
			id: `int-${Date.now()}`
		};
		interviews.unshift(newInt);
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.INTERVIEWS, JSON.stringify(interviews));
		return newInt;
	}
	getUserResumes(userId) {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.RESUMES);
		if (!raw) return [];
		try {
			return JSON.parse(raw).filter((r) => r.userId === userId);
		} catch {
			return [];
		}
	}
	addUserResume(data) {
		const raw = localStorage.getItem(this.STORAGE_KEYS.RESUMES);
		const existing = raw ? JSON.parse(raw) : [];
		const newRes = {
			...data,
			id: `res-${Date.now()}`,
			uploadDate: data.uploadDate || (/* @__PURE__ */ new Date()).toLocaleDateString("en-IN", {
				day: "numeric",
				month: "short",
				year: "numeric"
			})
		};
		existing.unshift(newRes);
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.RESUMES, JSON.stringify(existing));
		return newRes;
	}
	deleteUserResume(id) {
		const raw = localStorage.getItem(this.STORAGE_KEYS.RESUMES);
		if (!raw) return true;
		try {
			let existing = JSON.parse(raw);
			existing = existing.filter((r) => r.id !== id);
			if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.RESUMES, JSON.stringify(existing));
		} catch {}
		return true;
	}
	getJobSeekerProfile(userId) {
		if (typeof window === "undefined" || !userId) return null;
		const raw = localStorage.getItem(this.STORAGE_KEYS.PROFILES);
		if (!raw) return null;
		try {
			const profile = JSON.parse(raw).find((p) => p.id === userId || p.email === userId) || null;
			if (profile) {
				if (profile.category === "IT & Software" || profile.category === "General Candidate") profile.category = "";
				if (profile.experience === "2 Years" || profile.experience === "Fresher") profile.experience = "";
				if (profile.education === "B.Tech / Graduate" || profile.education === "Not Specified" || profile.education === "Graduate") profile.education = "";
				if (profile.expectedSalary === "₹ 4.5 LPA" || profile.expectedSalary === "As per standards") profile.expectedSalary = "";
				if (profile.currentLocation === "Pune, Maharashtra" || profile.currentLocation === "Pune") profile.currentLocation = "";
				if (profile.preferredLocation === "Pune, Mumbai, Chakan" || profile.preferredLocation === "Pune, Maharashtra" || profile.preferredLocation === "Pune") profile.preferredLocation = "";
				if (profile.skills?.includes("React") && profile.skills?.includes("JavaScript")) profile.skills = [];
				if (profile.resume?.includes("_resume.pdf")) profile.resume = "";
			}
			return profile;
		} catch {
			return null;
		}
	}
	saveJobSeekerProfile(profile) {
		const raw = typeof window !== "undefined" ? localStorage.getItem(this.STORAGE_KEYS.PROFILES) : null;
		const profiles = raw ? JSON.parse(raw) : [];
		const existingIndex = profiles.findIndex((p) => p.id === profile.id || p.email === profile.email);
		const found = existingIndex >= 0 ? profiles[existingIndex] : void 0;
		const updatedProfile = {
			id: profile.id,
			email: profile.email,
			fullName: profile.fullName ?? found?.fullName ?? "User",
			mobile: profile.mobile ?? found?.mobile ?? "",
			education: profile.education ?? found?.education ?? "",
			skills: profile.skills ?? found?.skills ?? [],
			experience: profile.experience ?? found?.experience ?? "",
			currentLocation: profile.currentLocation ?? found?.currentLocation ?? "",
			preferredLocation: profile.preferredLocation ?? found?.preferredLocation ?? "",
			expectedSalary: profile.expectedSalary ?? found?.expectedSalary ?? "",
			category: profile.category ?? found?.category ?? "",
			subcategory: profile.subcategory ?? found?.subcategory ?? "",
			jobType: profile.jobType ?? found?.jobType ?? "Full Time",
			resume: profile.resume ?? found?.resume ?? "",
			resumeName: profile.resumeName ?? found?.resumeName ?? "",
			profilePhoto: profile.profilePhoto ?? found?.profilePhoto ?? "",
			createdAt: found?.createdAt ?? (/* @__PURE__ */ new Date()).toISOString()
		};
		if (existingIndex >= 0) profiles[existingIndex] = updatedProfile;
		else profiles.push(updatedProfile);
		if (typeof window !== "undefined") {
			localStorage.setItem(this.STORAGE_KEYS.PROFILES, JSON.stringify(profiles));
			fbSync(() => setDoc(doc(db, "profiles", updatedProfile.id), updatedProfile));
			const currentUser = this.getCurrentUser();
			if (currentUser && (currentUser.id === updatedProfile.id || currentUser.email === updatedProfile.email)) this.setCurrentUser({
				...currentUser,
				fullName: updatedProfile.fullName,
				email: updatedProfile.email,
				profilePhoto: updatedProfile.profilePhoto || currentUser.profilePhoto || ""
			});
		}
		return updatedProfile;
	}
	getUserPackages(userId) {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.PACKAGES);
		if (!raw) return [];
		try {
			return JSON.parse(raw).filter((p) => p.userId === userId);
		} catch {
			return [];
		}
	}
	/**
	* Record package purchase transaction
	*/
	addPackagePurchase(data) {
		const raw = localStorage.getItem(this.STORAGE_KEYS.PACKAGES);
		const existing = raw ? JSON.parse(raw) : [];
		const newTx = {
			...data,
			id: `pkg-${Date.now()}`,
			purchaseDate: (/* @__PURE__ */ new Date()).toLocaleDateString("en-IN", {
				day: "numeric",
				month: "short",
				year: "numeric",
				hour: "2-digit",
				minute: "2-digit"
			}),
			status: "Completed"
		};
		existing.unshift(newTx);
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.PACKAGES, JSON.stringify(existing));
		return newTx;
	}
	/**
	* Get available job credits count for user
	*/
	getUserJobCredits(userId) {
		return this.getUserPackages(userId).reduce((acc, p) => acc + (p.jobCount || 0), 0);
	}
	/**
	* Get dynamic job packages
	*/
	getJobPackages() {
		if (typeof window === "undefined") return DEFAULT_JOB_PACKAGES;
		const raw = localStorage.getItem("realjob_db_dynamic_packages");
		if (!raw) return DEFAULT_JOB_PACKAGES;
		try {
			const parsed = JSON.parse(raw);
			if (Array.isArray(parsed) && parsed.length > 0) return parsed.map((pkg) => ({
				...pkg,
				description: pkg.description ? pkg.description.replace(/Employees Included/g, "CRM Included").replace(/Employees/g, "CRM") : pkg.description,
				features: Array.isArray(pkg.features) ? pkg.features.map((f) => f.replace(/Employees Addition/g, "CRM Users").replace(/Employees/g, "CRM Users")) : pkg.features
			}));
			return DEFAULT_JOB_PACKAGES;
		} catch {
			return DEFAULT_JOB_PACKAGES;
		}
	}
	/**
	* Save dynamic job packages (SuperAdmin control)
	*/
	saveJobPackages(packages) {
		if (typeof window === "undefined") return;
		localStorage.setItem("realjob_db_dynamic_packages", JSON.stringify(packages));
	}
	/**
	* Get all package purchases across platform (SuperAdmin view)
	*/
	getAllPackagePurchases() {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.PACKAGES);
		if (!raw) return [];
		try {
			return JSON.parse(raw);
		} catch {
			return [];
		}
	}
	deletePackagePurchase(txId) {
		if (typeof window === "undefined") return false;
		let list = this.getAllPackagePurchases();
		list = list.filter((tx) => tx.id !== txId);
		localStorage.setItem(this.STORAGE_KEYS.PACKAGES, JSON.stringify(list));
		return true;
	}
	clearPackagePurchases() {
		if (typeof window === "undefined") return false;
		localStorage.setItem(this.STORAGE_KEYS.PACKAGES, JSON.stringify([]));
		return true;
	}
	/**
	* Consume 1 credit when posting a job
	*/
	consumeJobCredit(userId) {
		if (typeof window === "undefined") return false;
		const raw = localStorage.getItem(this.STORAGE_KEYS.PACKAGES);
		if (!raw) return false;
		try {
			const all = JSON.parse(raw);
			const activePkg = all.find((p) => p.userId === userId && p.jobCount > 0);
			if (!activePkg) return false;
			if (activePkg.jobCount < 999) activePkg.jobCount -= 1;
			localStorage.setItem(this.STORAGE_KEYS.PACKAGES, JSON.stringify(all));
			return true;
		} catch {
			return false;
		}
	}
	/**
	* Get total allowed employee limit for employer based on active package purchases
	*/
	getUserWorkerCredits(userId) {
		if (typeof window === "undefined" || !userId) return 0;
		try {
			const purchases = this.getAllPackagePurchases().filter((p) => p.userId === userId);
			if (!purchases || purchases.length === 0) return 0;
			const livePackages = this.getJobPackages();
			let totalWorkerLimit = 0;
			purchases.forEach((p) => {
				if (typeof p.workerCount === "number" && p.workerCount > 0) totalWorkerLimit += p.workerCount;
				else if (typeof p.workerCount === "string") totalWorkerLimit += isNaN(Number(p.workerCount)) ? 9999 : Number(p.workerCount);
				else {
					const matchingPlan = livePackages.find((dp) => dp.id === p.planId || dp.name.toLowerCase() === p.planName.toLowerCase());
					if (matchingPlan && matchingPlan.workerCount) totalWorkerLimit += typeof matchingPlan.workerCount === "string" ? isNaN(Number(matchingPlan.workerCount)) ? 9999 : Number(matchingPlan.workerCount) : matchingPlan.workerCount;
					else totalWorkerLimit += 3;
				}
			});
			return totalWorkerLimit;
		} catch {
			return 0;
		}
	}
	getEmployerWorkers(employerId) {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.EMP_WORKERS);
		if (!raw) return [];
		try {
			const deletedIds = new Set(JSON.parse(localStorage.getItem("realjob_deleted_worker_ids") || "[]"));
			deletedIds.add("empw-1791635953540");
			deletedIds.add("empw-1791785681836");
			const all = JSON.parse(raw).filter((w) => !deletedIds.has(w.id) && w.status !== "Inactive" && w.status !== "Deleted" && !w.isDeleted);
			if (!employerId) return all;
			const currentUser = this.getCurrentUser();
			const validIdentifiers = /* @__PURE__ */ new Set();
			if (employerId) validIdentifiers.add(employerId.trim().toLowerCase());
			if (currentUser) {
				if (currentUser.id) validIdentifiers.add(currentUser.id.trim().toLowerCase());
				if (currentUser.email) validIdentifiers.add(currentUser.email.trim().toLowerCase());
				if (currentUser.fullName) validIdentifiers.add(currentUser.fullName.trim().toLowerCase());
			}
			return all.filter((w) => {
				if (!w.employerId) return false;
				const wEmp = w.employerId.trim().toLowerCase();
				return validIdentifiers.has(wEmp);
			});
		} catch {
			return [];
		}
	}
	getAllEmployerWorkers() {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.EMP_WORKERS);
		if (!raw) return [];
		try {
			const deletedIds = new Set(JSON.parse(localStorage.getItem("realjob_deleted_worker_ids") || "[]"));
			deletedIds.add("empw-1791635953540");
			deletedIds.add("empw-1791785681836");
			return JSON.parse(raw).filter((w) => !deletedIds.has(w.id) && w.status !== "Inactive" && w.status !== "Deleted" && !w.isDeleted);
		} catch {
			return [];
		}
	}
	saveEmployerWorker(worker) {
		const raw = typeof window !== "undefined" ? localStorage.getItem(this.STORAGE_KEYS.EMP_WORKERS) : null;
		const all = raw ? JSON.parse(raw) : [];
		const workerId = worker.id || `empw-${Date.now()}`;
		const newWorker = {
			...worker,
			id: workerId,
			status: worker.status || "Active",
			isDeleted: false
		};
		const index = all.findIndex((w) => w.id === workerId);
		if (index >= 0) all[index] = newWorker;
		else all.unshift(newWorker);
		if (typeof window !== "undefined") {
			try {
				const filtered = JSON.parse(localStorage.getItem("realjob_deleted_worker_ids") || "[]").filter((id) => id !== workerId);
				localStorage.setItem("realjob_deleted_worker_ids", JSON.stringify(filtered));
			} catch {}
			localStorage.setItem(this.STORAGE_KEYS.EMP_WORKERS, JSON.stringify(all));
			fbSync(() => setDoc(doc(db, "workers", newWorker.id), newWorker, { merge: true }));
		}
		return newWorker;
	}
	deleteEmployerWorker(workerId) {
		if (typeof window === "undefined" || !workerId) return false;
		const raw = localStorage.getItem(this.STORAGE_KEYS.EMP_WORKERS);
		if (!raw) return false;
		try {
			try {
				const deletedIds = JSON.parse(localStorage.getItem("realjob_deleted_worker_ids") || "[]");
				if (!deletedIds.includes(workerId)) {
					deletedIds.push(workerId);
					localStorage.setItem("realjob_deleted_worker_ids", JSON.stringify(deletedIds));
				}
			} catch {}
			const all = JSON.parse(raw);
			const targetWorker = all.find((w) => w.id === workerId);
			const filtered = all.filter((w) => w.id !== workerId);
			localStorage.setItem(this.STORAGE_KEYS.EMP_WORKERS, JSON.stringify(filtered));
			try {
				const sessionUser = JSON.parse(localStorage.getItem("realjob-user") || "null");
				if (sessionUser && (sessionUser.id === workerId || targetWorker?.mobile && (sessionUser.mobile || "").replace(/\D/g, "") === (targetWorker.mobile || "").replace(/\D/g, ""))) localStorage.removeItem("realjob-user");
			} catch {}
			fbSync(async () => {
				try {
					await setDoc(doc(db, "workers", workerId), {
						status: "Deleted",
						isDeleted: true
					}, { merge: true });
				} catch {}
				try {
					await deleteDoc(doc(db, "workers", workerId));
				} catch {}
			});
			return true;
		} catch {
			return false;
		}
	}
	getAllAttendance() {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.ATTENDANCE);
		if (!raw) return [];
		try {
			return JSON.parse(raw);
		} catch {
			return [];
		}
	}
	getEmployerAttendance(employerId, date) {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.ATTENDANCE);
		if (!raw) return [];
		try {
			const all = JSON.parse(raw);
			const currentUser = this.getCurrentUser();
			const validIdentifiers = /* @__PURE__ */ new Set();
			if (employerId) validIdentifiers.add(employerId.trim().toLowerCase());
			if (currentUser) {
				if (currentUser.id) validIdentifiers.add(currentUser.id.trim().toLowerCase());
				if (currentUser.email) validIdentifiers.add(currentUser.email.trim().toLowerCase());
				if (currentUser.fullName) validIdentifiers.add(currentUser.fullName.trim().toLowerCase());
			}
			let res = all.filter((a) => {
				if (!a.employerId) return true;
				return validIdentifiers.has(a.employerId.trim().toLowerCase());
			});
			if (res.length === 0 && all.length > 0) res = all;
			if (date) res = res.filter((a) => a.date === date);
			return res.map((r) => {
				if (r.punchInTime && r.punchOutTime) {
					const parseM = (t) => {
						const match = t.trim().toUpperCase().match(/^(\d{1,2}):(\d{2})\s*(AM|PM)?$/);
						if (!match || !match[1] || !match[2]) return null;
						let h = parseInt(match[1], 10);
						const min = parseInt(match[2], 10);
						if (match[3] === "PM" && h < 12) h += 12;
						if (match[3] === "AM" && h === 12) h = 0;
						return h * 60 + min;
					};
					const inM = parseM(r.punchInTime);
					const outM = parseM(r.punchOutTime);
					if (inM !== null && outM !== null && outM < inM) {
						const copy = { ...r };
						delete copy.punchOutTime;
						delete copy.punchOutLocation;
						return copy;
					}
				}
				return r;
			});
		} catch {
			return [];
		}
	}
	getEmployerAttendanceRange(employerId, startDate, endDate) {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.ATTENDANCE);
		if (!raw) return [];
		try {
			const all = JSON.parse(raw);
			const currentUser = this.getCurrentUser();
			const validIdentifiers = /* @__PURE__ */ new Set();
			if (employerId) validIdentifiers.add(employerId.trim().toLowerCase());
			if (currentUser) {
				if (currentUser.id) validIdentifiers.add(currentUser.id.trim().toLowerCase());
				if (currentUser.email) validIdentifiers.add(currentUser.email.trim().toLowerCase());
				if (currentUser.fullName) validIdentifiers.add(currentUser.fullName.trim().toLowerCase());
			}
			let res = all.filter((a) => {
				if (!a.employerId) return true;
				return validIdentifiers.has(a.employerId.trim().toLowerCase());
			});
			if (res.length === 0 && all.length > 0) res = all;
			if (startDate) res = res.filter((a) => a.date >= startDate);
			if (endDate) res = res.filter((a) => a.date <= endDate);
			return res;
		} catch {
			return [];
		}
	}
	saveAttendanceStatus(employerId, workerId, workerName, date, status, notes, punchData, overtimeHoursOrExtra, extraDataParam) {
		const raw = typeof window !== "undefined" ? localStorage.getItem(this.STORAGE_KEYS.ATTENDANCE) : null;
		const all = raw ? JSON.parse(raw) : [];
		if (date > (/* @__PURE__ */ new Date()).toISOString().split("T")[0]) {
			console.warn(`[dataStore] Attendance cannot be marked for future date: ${date}`);
			return all.find((a) => a.id === `att-${workerId}-${date}`) || {
				id: `att-${workerId}-${date}`,
				employerId,
				workerId,
				workerName,
				date,
				status,
				overtimeHours: 0,
				updatedAt: (/* @__PURE__ */ new Date()).toISOString()
			};
		}
		const recordId = `att-${workerId}-${date}`;
		const index = all.findIndex((a) => a.id === recordId || a.workerId === workerId && a.date === date);
		const extraData = typeof overtimeHoursOrExtra === "object" ? overtimeHoursOrExtra : extraDataParam;
		const numericOtHours = typeof overtimeHoursOrExtra === "number" ? overtimeHoursOrExtra : extraData?.overtimeHours;
		let newRecord;
		const newPunchLogEntry = punchData?.punchInTime && punchData.punchInLocation ? {
			type: "in",
			time: punchData.punchInTime,
			location: punchData.punchInLocation
		} : punchData?.punchOutTime && punchData.punchOutLocation ? {
			type: "out",
			time: punchData.punchOutTime,
			location: punchData.punchOutLocation
		} : null;
		if (index >= 0) {
			const existing = all[index];
			const isRePunchIn = !!punchData?.punchInTime && !punchData?.punchOutTime;
			const updatedPunchLog = existing.punchLog ? [...existing.punchLog] : [];
			if (newPunchLogEntry) updatedPunchLog.unshift(newPunchLogEntry);
			const finalOtHours = numericOtHours !== void 0 ? numericOtHours : status === "Overtime" ? existing.overtimeHours || 2 : 0;
			const finalOtPay = extraData?.overtimePay !== void 0 ? extraData.overtimePay : existing.overtimePay;
			newRecord = {
				...existing,
				status,
				overtimeHours: finalOtHours,
				...finalOtPay !== void 0 ? { overtimePay: finalOtPay } : {},
				punchLog: updatedPunchLog,
				updatedAt: (/* @__PURE__ */ new Date()).toISOString()
			};
			const finalNotes = notes ? existing.notes ? existing.notes + " | " + notes : notes : existing.notes;
			if (finalNotes) newRecord.notes = finalNotes;
			const inTime = punchData?.punchInTime || existing.punchInTime;
			const inLoc = punchData?.punchInLocation || existing.punchInLocation;
			if (inTime) newRecord.punchInTime = inTime;
			if (inLoc) newRecord.punchInLocation = inLoc;
			if (isRePunchIn) {
				delete newRecord.punchOutTime;
				delete newRecord.punchOutLocation;
			} else {
				const outTime = punchData?.punchOutTime || existing.punchOutTime;
				const outLoc = punchData?.punchOutLocation || existing.punchOutLocation;
				if (outTime) newRecord.punchOutTime = outTime;
				if (outLoc) newRecord.punchOutLocation = outLoc;
			}
			all[index] = newRecord;
		} else {
			const finalOtHours = numericOtHours !== void 0 ? numericOtHours : status === "Overtime" ? 2 : 0;
			const finalOtPay = extraData?.overtimePay !== void 0 ? extraData.overtimePay : void 0;
			newRecord = {
				id: recordId,
				employerId,
				workerId,
				workerName,
				date,
				status,
				overtimeHours: finalOtHours,
				...finalOtPay !== void 0 ? { overtimePay: finalOtPay } : {},
				notes: notes || "",
				punchInTime: punchData?.punchInTime,
				punchOutTime: punchData?.punchOutTime,
				punchInLocation: punchData?.punchInLocation,
				punchOutLocation: punchData?.punchOutLocation,
				punchLog: newPunchLogEntry ? [newPunchLogEntry] : [],
				updatedAt: (/* @__PURE__ */ new Date()).toISOString()
			};
			all.push(newRecord);
		}
		if (typeof window !== "undefined") {
			localStorage.setItem(this.STORAGE_KEYS.ATTENDANCE, JSON.stringify(all));
			const cleanRecord = JSON.parse(JSON.stringify(newRecord));
			fbSync(() => setDoc(doc(db, "attendance", newRecord.id), cleanRecord));
		}
		return newRecord;
	}
	saveBulkAttendance(employerId, workerId, workerName, dates, status, overtimeHours, notes) {
		const raw = typeof window !== "undefined" ? localStorage.getItem(this.STORAGE_KEYS.ATTENDANCE) : null;
		const all = raw ? JSON.parse(raw) : [];
		const savedRecords = [];
		const finalOtHours = overtimeHours !== void 0 ? overtimeHours : status === "Overtime" ? 2 : 0;
		const todayStr = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
		dates.filter((d) => d <= todayStr).forEach((date) => {
			const recordId = `att-${workerId}-${date}`;
			const index = all.findIndex((a) => a.id === recordId || a.workerId === workerId && a.date === date);
			let record;
			if (index >= 0) {
				record = {
					...all[index],
					status,
					overtimeHours: finalOtHours,
					updatedAt: (/* @__PURE__ */ new Date()).toISOString()
				};
				if (notes) record.notes = notes;
				all[index] = record;
			} else {
				record = {
					id: recordId,
					employerId,
					workerId,
					workerName,
					date,
					status,
					overtimeHours: finalOtHours,
					notes: notes || "",
					updatedAt: (/* @__PURE__ */ new Date()).toISOString()
				};
				all.push(record);
			}
			savedRecords.push(record);
			const cleanRecord = JSON.parse(JSON.stringify(record));
			fbSync(() => setDoc(doc(db, "attendance", record.id), cleanRecord));
		});
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.ATTENDANCE, JSON.stringify(all));
		return savedRecords;
	}
	deleteAttendanceRecord(workerId, date) {
		if (typeof window === "undefined") return false;
		const raw = localStorage.getItem(this.STORAGE_KEYS.ATTENDANCE);
		if (!raw) return false;
		try {
			const all = JSON.parse(raw);
			const recordId = `att-${workerId}-${date}`;
			const filtered = all.filter((a) => !(a.id === recordId || a.workerId === workerId && a.date === date));
			localStorage.setItem(this.STORAGE_KEYS.ATTENDANCE, JSON.stringify(filtered));
			fbSync(async () => {
				try {
					await deleteDoc(doc(db, "attendance", recordId));
				} catch {}
			});
			return true;
		} catch {
			return false;
		}
	}
	removeAttendanceStatus(workerId, date) {
		return this.deleteAttendanceRecord(workerId, date);
	}
	replyToApplication(applicationId, replyMessage) {
		return this.updateApplicationReply(applicationId, replyMessage);
	}
};
var dataStore = new DataStoreManager();
//#endregion
export { isRemovedTestCategory as n, dataStore as t };
