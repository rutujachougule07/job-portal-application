import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button--9UiOy7A.mjs";
import { t as dataStore } from "./data-store-CvMaHmbm.mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { Bt as CircleX, G as Package, Ht as CircleCheck, Jt as ChartColumn, Kt as Check, Lt as Clock, Mt as DollarSign, N as Search, Nt as CreditCard, O as ShieldCheck, Qt as CalendarCheck, Xt as Calendar, Z as LogOut, Zt as CalendarDays, _ as Trash2, at as Layers, d as UserPlus, en as Building2, f as UserCheck, jt as Download, l as UserX, nn as BriefcaseBusiness, on as Bell, qt as ChartPie, s as Users, t as Zap, w as Smartphone, wt as FileText, x as SquarePen, z as Printer } from "../_libs/lucide-react.mjs";
import { t as LanguageSwitcher } from "./LanguageSwitcher-BQTToBxr.mjs";
import { t as Badge } from "./badge-DRaMiws1.mjs";
import { t as StatCard } from "./Stats-BJplhY8l.mjs";
import { t as Input } from "./input-CZUnWUIa.mjs";
import { t as Label } from "./label-Ckx2BWD4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-CWHex2Cx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function formatWaNumber(phone) {
	const digits = (phone || "").trim().replace(/\D/g, "");
	if (!digits) return "919822011223";
	if (digits.length === 10) return `91${digits}`;
	if (digits.length === 12 && digits.startsWith("91")) return digits;
	if (digits.length === 11 && digits.startsWith("0")) return `91${digits.slice(1)}`;
	return digits.length >= 10 ? digits : `91${digits}`;
}
function formatCallNumber(phone) {
	const raw = (phone || "").trim();
	const digits = raw.replace(/\D/g, "");
	if (!digits) return "+919822011223";
	if (digits.length === 10) return `+91${digits}`;
	if (digits.length === 12 && digits.startsWith("91")) return `+${digits}`;
	if (digits.length === 11 && digits.startsWith("0")) return `+91${digits.slice(1)}`;
	return raw.startsWith("+") ? raw : `+${digits}`;
}
function AdminDashboardPage() {
	useNavigate();
	const [activeTab, setActiveTab] = (0, import_react.useState)("overview");
	const [jobs, setJobs] = (0, import_react.useState)([]);
	const [applications, setApplications] = (0, import_react.useState)([]);
	const [userSearch, setUserSearch] = (0, import_react.useState)("");
	const [jobSearch, setJobSearch] = (0, import_react.useState)("");
	const [appSearch, setAppSearch] = (0, import_react.useState)("");
	const [filterJobId, setFilterJobId] = (0, import_react.useState)(null);
	const [expandedApp, setExpandedApp] = (0, import_react.useState)(null);
	const [workers, setWorkers] = (0, import_react.useState)([]);
	const [selectedAttendanceDate, setSelectedAttendanceDate] = (0, import_react.useState)((/* @__PURE__ */ new Date()).toISOString().split("T")[0]);
	const [dailyAttendanceRecords, setDailyAttendanceRecords] = (0, import_react.useState)([]);
	const [workerSearch, setWorkerSearch] = (0, import_react.useState)("");
	const [showWorkerModal, setShowWorkerModal] = (0, import_react.useState)(false);
	const [editingWorkerId, setEditingWorkerId] = (0, import_react.useState)(null);
	const [attendanceSubView, setAttendanceSubView] = (0, import_react.useState)("daily");
	const [selectedCategoryFilter, setSelectedCategoryFilter] = (0, import_react.useState)("ALL");
	const [reportTimeframe, setReportTimeframe] = (0, import_react.useState)("month");
	const [reportStartDate, setReportStartDate] = (0, import_react.useState)(() => {
		const d = /* @__PURE__ */ new Date();
		d.setDate(1);
		return d.toISOString().split("T")[0];
	});
	const [reportEndDate, setReportEndDate] = (0, import_react.useState)((/* @__PURE__ */ new Date()).toISOString().split("T")[0]);
	const [reportAttendanceRecords, setReportAttendanceRecords] = (0, import_react.useState)([]);
	const [selectedWorkerReport, setSelectedWorkerReport] = (0, import_react.useState)(null);
	const [workerReportPeriod, setWorkerReportPeriod] = (0, import_react.useState)("month");
	const [workerForm, setWorkerForm] = (0, import_react.useState)({
		name: "",
		mobile: "",
		trade: "General Worker",
		category: "Plant Nursery & Care",
		dailyRate: "500",
		joiningDate: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
	});
	const formatCategoryName = (cat) => {
		if (!cat) return "Plant Nursery & Care";
		if (cat.includes("Grafting") || cat.includes("कलमे")) return "Grafting & Propagation";
		if (cat.includes("Tractor") || cat.includes("ट्रॅक्टर") || cat.toLowerCase().includes("tractor")) return "Tractor & Machinery";
		if (cat.includes("Packing") || cat.includes("पॅकिंग")) return "Packing & Loading";
		if (cat.includes("Watering") || cat.includes("पाणी")) return "Irrigation & Spraying";
		if (cat.includes("Soil") || cat.includes("माती")) return "Soil & Fertilizer";
		if (cat.includes("General") || cat.includes("इतर")) return "General Labour";
		if (cat.includes("Plant Nursery") || cat.includes("रोपवाटिका")) return "Plant Nursery & Care";
		return cat;
	};
	const getWorkerReportMetrics = (worker, period) => {
		let startDate = "";
		const now = /* @__PURE__ */ new Date();
		const endDate = now.toISOString().split("T")[0];
		if (period === "week") {
			const d = /* @__PURE__ */ new Date();
			d.setDate(d.getDate() - 6);
			startDate = d.toISOString().split("T")[0];
		} else if (period === "month") startDate = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split("T")[0];
		else startDate = worker.joiningDate || "2020-01-01";
		if (worker.joiningDate && worker.joiningDate > startDate) startDate = worker.joiningDate;
		const workerRecords = dataStore.getEmployerAttendanceRange(empIdentifier, startDate, endDate).filter((r) => r.workerId === worker.id);
		let present = 0;
		let halfDay = 0;
		let absent = 0;
		let overtime = 0;
		let netPay = 0;
		workerRecords.forEach((r) => {
			if (r.status === "Present") {
				present++;
				netPay += worker.dailyRate;
			} else if (r.status === "HalfDay") {
				halfDay++;
				netPay += Math.round(worker.dailyRate / 2);
			} else if (r.status === "Absent") absent++;
			else if (r.status === "Overtime") {
				overtime++;
				netPay += Math.round(worker.dailyRate * 1.5);
			}
		});
		return {
			startDate,
			endDate,
			records: workerRecords,
			present,
			halfDay,
			absent,
			overtime,
			totalDays: workerRecords.length,
			netPay
		};
	};
	const handleDownloadPDFSalarySlip = async (worker, period) => {
		const metrics = getWorkerReportMetrics(worker, period);
		const periodLabel = period === "week" ? "Weekly (Last 7 Days)" : period === "month" ? "Monthly (Current Month)" : "All Time Records";
		const catName = formatCategoryName(worker.category || worker.trade);
		const employerName = currentUser?.fullName || currentUser?.email || "NURSERY & AGRICULTURAL SERVICES";
		const companyTitle = currentUser?.fullName ? `${currentUser.fullName.toUpperCase()} - NURSERY & WORKFORCE SERVICES` : "GREENWOOD PLANT NURSERY & WORKFORCE SERVICES";
		const container = document.createElement("div");
		container.style.position = "fixed";
		container.style.left = "-9999px";
		container.style.top = "0px";
		container.style.width = "720px";
		container.style.background = "#FFFFFF";
		container.innerHTML = `
      <div style="width: 720px; padding: 24px; font-family: Arial, sans-serif; color: #1E293B; background: #FFFFFF; box-sizing: border-box; margin: 0 auto;">
        <!-- Company Banner Header -->
        <table style="width: 100%; border-collapse: collapse; background: linear-gradient(135deg, #021D3D 0%, #063B78 60%, #0B52A8 100%); border-radius: 12px; margin-bottom: 20px;">
          <tr>
            <td style="padding: 20px; vertical-align: middle;">
              <div style="font-size: 10px; font-weight: bold; text-transform: uppercase; color: #F59E0B; letter-spacing: 1.5px; margin-bottom: 4px;">🌱 OFFICIAL WORKFORCE SALARY SLIP</div>
              <h1 style="font-size: 20px; font-weight: 900; margin: 0; color: #FFFFFF; letter-spacing: -0.3px;">${companyTitle}</h1>
              <div style="font-size: 12px; margin-top: 6px; color: #DCE5F0;">
                Employer: <strong style="color: #FFFFFF;">${employerName}</strong> &bull; Work & Salary Settlement
              </div>
            </td>
            <td style="padding: 20px; text-align: right; vertical-align: middle; width: 190px;">
              <div style="background: rgba(255,255,255,0.15); padding: 8px 12px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.25); text-align: right;">
                <div style="font-size: 9px; font-weight: bold; color: #E2E8F0; text-transform: uppercase;">SLIP REFERENCE</div>
                <div style="font-size: 13px; font-weight: 900; color: #FFFFFF; font-family: monospace; margin-top: 2px;">PAY-${worker.id.slice(-6).toUpperCase()}</div>
              </div>
            </td>
          </tr>
        </table>

        <!-- Employee Contract & Workplace Info Table -->
        <table style="width: 100%; border-collapse: collapse; border: 1.5px solid #CBD5E1; border-radius: 10px; background: #F8FAFC; margin-bottom: 20px;">
          <tr>
            <td colspan="2" style="padding: 10px 16px; font-size: 11px; font-weight: 900; color: #063B78; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1.5px solid #E2E8F0; background: #EFF6FF;">
              👤 EMPLOYEE CONTRACT & WORKPLACE DETAILS
            </td>
          </tr>
          <tr>
            <td style="padding: 8px 16px; font-size: 12px; width: 50%; border-bottom: 1px solid #E2E8F0;">
              <span style="color: #64748B; font-weight: 600;">Employee Name:</span> <strong style="color: #0F172A; font-weight: 800;">${worker.name}</strong>
            </td>
            <td style="padding: 8px 16px; font-size: 12px; width: 50%; border-bottom: 1px solid #E2E8F0;">
              <span style="color: #64748B; font-weight: 600;">Work Organization / Firm:</span> <strong style="color: #063B78; font-weight: 800;">${companyTitle}</strong>
            </td>
          </tr>
          <tr>
            <td style="padding: 8px 16px; font-size: 12px; border-bottom: 1px solid #E2E8F0;">
              <span style="color: #64748B; font-weight: 600;">Department:</span> <strong style="color: #063B78; font-weight: 800; background: #DBEAFE; padding: 2px 6px; border-radius: 4px;">${catName}</strong>
            </td>
            <td style="padding: 8px 16px; font-size: 12px; border-bottom: 1px solid #E2E8F0;">
              <span style="color: #64748B; font-weight: 600;">Role / Designation:</span> <strong style="color: #0F172A; font-weight: 700;">${worker.trade || "General Worker"}</strong>
            </td>
          </tr>
          <tr>
            <td style="padding: 8px 16px; font-size: 12px; border-bottom: 1px solid #E2E8F0;">
              <span style="color: #64748B; font-weight: 600;">Mobile Number:</span> <strong style="color: #0F172A; font-weight: 700;">${worker.mobile || "N/A"}</strong>
            </td>
            <td style="padding: 8px 16px; font-size: 12px; border-bottom: 1px solid #E2E8F0;">
              <span style="color: #64748B; font-weight: 600;">Daily Rate:</span> <strong style="color: #059669; font-weight: 900; font-size: 13px;">₹${worker.dailyRate} / day</strong>
            </td>
          </tr>
          <tr>
            <td colspan="2" style="padding: 8px 16px; font-size: 12px;">
              <span style="color: #64748B; font-weight: 600;">Report Timeframe:</span> <strong style="color: #0F172A; font-weight: 700;">${periodLabel} (${metrics.startDate} to ${metrics.endDate})</strong>
            </td>
          </tr>
        </table>

        <!-- Attendance Metrics Grid Table -->
        <table style="width: 100%; border-collapse: separate; border-spacing: 6px 0; margin-bottom: 20px;">
          <tr>
            <td style="width: 20%; background: #F0FDF4; border: 1.5px solid #BBF7D0; border-radius: 8px; padding: 10px 4px; text-align: center;">
              <div style="font-size: 9px; font-weight: 800; color: #166534; text-transform: uppercase;">PRESENT</div>
              <div style="font-size: 20px; font-weight: 900; color: #15803D; margin-top: 2px;">${metrics.present}</div>
            </td>
            <td style="width: 20%; background: #FFFBEB; border: 1.5px solid #FDE68A; border-radius: 8px; padding: 10px 4px; text-align: center;">
              <div style="font-size: 9px; font-weight: 800; color: #92400E; text-transform: uppercase;">HALF DAY</div>
              <div style="font-size: 20px; font-weight: 900; color: #B45309; margin-top: 2px;">${metrics.halfDay}</div>
            </td>
            <td style="width: 20%; background: #FFF1F2; border: 1.5px solid #FECDD3; border-radius: 8px; padding: 10px 4px; text-align: center;">
              <div style="font-size: 9px; font-weight: 800; color: #9F1239; text-transform: uppercase;">ABSENT</div>
              <div style="font-size: 20px; font-weight: 900; color: #BE123C; margin-top: 2px;">${metrics.absent}</div>
            </td>
            <td style="width: 20%; background: #EFF6FF; border: 1.5px solid #BFDBFE; border-radius: 8px; padding: 10px 4px; text-align: center;">
              <div style="font-size: 9px; font-weight: 800; color: #1E40AF; text-transform: uppercase;">OVERTIME</div>
              <div style="font-size: 20px; font-weight: 900; color: #1D4ED8; margin-top: 2px;">${metrics.overtime}</div>
            </td>
            <td style="width: 20%; background: #F3E8FF; border: 1.5px solid #E9D5FF; border-radius: 8px; padding: 10px 4px; text-align: center;">
              <div style="font-size: 9px; font-weight: 800; color: #6B21A8; text-transform: uppercase;">TOTAL DAYS</div>
              <div style="font-size: 20px; font-weight: 900; color: #7E22CE; margin-top: 2px;">${metrics.totalDays}</div>
            </td>
          </tr>
        </table>

        <!-- Attendance History Table -->
        <table style="width: 100%; border-collapse: collapse; border: 1.5px solid #CBD5E1; border-radius: 8px; overflow: hidden; margin-bottom: 20px;">
          <thead>
            <tr style="background: #063B78; color: #FFFFFF; font-size: 11px; font-weight: 800; text-transform: uppercase;">
              <th style="padding: 10px 12px; text-align: left; width: 25%;">DATE</th>
              <th style="padding: 10px 12px; text-align: left; width: 30%;">ATTENDANCE STATUS</th>
              <th style="padding: 10px 12px; text-align: left; width: 25%;">DAILY RATE</th>
              <th style="padding: 10px 12px; text-align: right; width: 20%;">EARNED PAY</th>
            </tr>
          </thead>
          <tbody style="font-size: 12px; font-weight: 600;">
            ${metrics.records.length === 0 ? `<tr><td colspan="4" style="text-align:center; padding: 16px; color:#64748B;">No attendance logs recorded for this period.</td></tr>` : metrics.records.map((r, i) => {
			let pay = worker.dailyRate;
			if (r.status === "HalfDay") pay = Math.round(worker.dailyRate / 2);
			if (r.status === "Absent") pay = 0;
			if (r.status === "Overtime") pay = Math.round(worker.dailyRate * 1.5);
			return `
                      <tr style="background: ${i % 2 === 0 ? "#FFFFFF" : "#F8FAFC"}; border-bottom: 1px solid #E2E8F0;">
                        <td style="padding: 8px 12px; font-weight: 700; color: #0F172A;">${r.date}</td>
                        <td style="padding: 8px 12px;">
                          <span style="font-size: 10px; font-weight: 800; padding: 3px 8px; border-radius: 4px; ${r.status === "Present" ? "background:#DCFCE7; color:#15803D;" : r.status === "HalfDay" ? "background:#FEF3C7; color:#B45309;" : r.status === "Absent" ? "background:#FFE4E6; color:#BE123C;" : "background:#DBEAFE; color:#1D4ED8;"}">
                            ${r.status}
                          </span>
                        </td>
                        <td style="padding: 8px 12px; color: #64748B;">₹${worker.dailyRate} / day</td>
                        <td style="padding: 8px 12px; text-align: right; color:#059669; font-weight:900;">₹${pay}</td>
                      </tr>
                    `;
		}).join("")}
          </tbody>
        </table>

        <!-- Total Net Payable Settlement Table -->
        <table style="width: 100%; border-collapse: collapse; background: linear-gradient(135deg, #ECFDF5 0%, #D1FAE5 100%); border: 2px solid #059669; border-radius: 10px; margin-bottom: 24px;">
          <tr>
            <td style="padding: 16px 20px; vertical-align: middle;">
              <div style="font-size: 10px; font-weight: 900; color: #047857; text-transform: uppercase; letter-spacing: 1px;">TOTAL EARNED SALARY SETTLEMENT</div>
              <div style="font-size: 12px; font-weight: 700; color: #065F46; margin-top: 2px;">Net payable wage amount calculated for ${worker.name}</div>
            </td>
            <td style="padding: 16px 20px; vertical-align: middle; text-align: right; width: 220px;">
              <div style="font-size: 10px; font-weight: 800; color: #047857; text-transform: uppercase;">NET PAYABLE AMOUNT</div>
              <div style="font-size: 28px; font-weight: 900; color: #047857; line-height: 1; margin-top: 2px;">₹${metrics.netPay.toLocaleString("en-IN")}</div>
            </td>
          </tr>
        </table>

        <!-- Official Signatures Footer Table -->
        <table style="width: 100%; border-collapse: collapse; border-top: 1.5px dashed #CBD5E1; padding-top: 14px; font-size: 11px; color: #64748B;">
          <tr>
            <td style="vertical-align: bottom; padding-top: 14px;">
              <div style="font-weight: bold; color: #063B78;">${companyTitle}</div>
              <div>Issued Date: ${(/* @__PURE__ */ new Date()).toLocaleDateString("en-IN")}</div>
              <div style="font-size: 9px; color: #94A3B8; margin-top: 2px;">Computer Generated Payroll Statement &bull; Verified</div>
            </td>
            <td style="vertical-align: bottom; text-align: right; padding-top: 14px;">
              <div style="display: inline-block; text-align: center;">
                <div style="border: 1.5px dashed #94A3B8; border-radius: 4px; padding: 4px 12px; margin-bottom: 6px; font-size: 9px; color: #063B78; font-weight: bold; background: #F8FAFC;">
                  ✔ OFFICIAL STAMP
                </div>
                <div style="border-top: 1.5px solid #063B78; width: 160px; padding-top: 4px; font-weight: bold; color: #063B78;">EMPLOYER SIGNATURE</div>
              </div>
            </td>
          </tr>
        </table>
      </div>
    `;
		document.body.appendChild(container);
		const fileName = `Salary_Slip_${worker.name.replace(/\s+/g, "_")}_${period}.pdf`;
		try {
			toast.info(`Generating high-quality PDF for ${worker.name}...`);
			const html2pdfModule = await import("../_libs/html2pdf.js.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			const html2pdf = html2pdfModule.default || html2pdfModule;
			const opt = {
				margin: [
					5,
					5,
					5,
					5
				],
				filename: fileName,
				image: {
					type: "jpeg",
					quality: .98
				},
				html2canvas: {
					scale: 2,
					useCORS: true,
					logging: false,
					windowWidth: 720
				},
				jsPDF: {
					unit: "mm",
					format: "a4",
					orientation: "portrait"
				}
			};
			if (!container.firstElementChild) return;
			await html2pdf().set(opt).from(container.firstElementChild).save();
			toast.success(`PDF downloaded: ${fileName}`);
		} catch (err) {
			console.error("PDF generation error, falling back", err);
			toast.error("Error creating PDF file.");
		} finally {
			if (document.body.contains(container)) document.body.removeChild(container);
		}
	};
	const handleDownloadCSV = (worker, period) => {
		const metrics = getWorkerReportMetrics(worker, period);
		let csv = `Date,Employee Name,Department,Daily Wage Rate (INR),Attendance Status,Calculated Pay (INR)\n`;
		metrics.records.forEach((r) => {
			let pay = worker.dailyRate;
			if (r.status === "HalfDay") pay = Math.round(worker.dailyRate / 2);
			if (r.status === "Absent") pay = 0;
			if (r.status === "Overtime") pay = Math.round(worker.dailyRate * 1.5);
			csv += `"${r.date}","${worker.name}","${formatCategoryName(worker.category || worker.trade)}",${worker.dailyRate},"${r.status}",${pay}\n`;
		});
		csv += `\nPERIOD SUMMARY,,,,,,\n`;
		csv += `Present Days,${metrics.present},,,,,,\n`;
		csv += `Half Days,${metrics.halfDay},,,,,,\n`;
		csv += `Absent Days,${metrics.absent},,,,,,\n`;
		csv += `Overtime Days,${metrics.overtime},,,,,,\n`;
		csv += `Net Total Payable Wages (INR),${metrics.netPay},,,,,,\n`;
		const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.setAttribute("href", url);
		link.setAttribute("download", `Salary_Slip_${worker.name.replace(/\s+/g, "_")}_${period}.csv`);
		document.body.appendChild(link);
		link.click();
		document.body.removeChild(link);
		toast.success(`Downloaded salary slip for ${worker.name}`);
	};
	const [showPackageModal, setShowPackageModal] = (0, import_react.useState)(false);
	const [selectedPlanId, setSelectedPlanId] = (0, import_react.useState)("plan-100");
	const [paymentMethod, setPaymentMethod] = (0, import_react.useState)("upi");
	const [upiId, setUpiId] = (0, import_react.useState)("");
	const [isProcessingPackage, setIsProcessingPackage] = (0, import_react.useState)(false);
	const [userCredits, setUserCredits] = (0, import_react.useState)(0);
	const [registeredUsers, setRegisteredUsers] = (0, import_react.useState)([]);
	const currentUser = dataStore.getCurrentUser();
	const isSuperAdmin = currentUser?.email?.toLowerCase() === "supera@gmail.com" || currentUser?.email?.toLowerCase() === "superadmin";
	const empIdentifier = currentUser?.fullName || currentUser?.email || "admin-001";
	const refreshCredits = () => {
		if (currentUser?.id) setUserCredits(dataStore.getUserJobCredits(currentUser.id));
	};
	const loadAttendanceData = () => {
		const empWorkers = dataStore.getEmployerWorkers(empIdentifier);
		setWorkers(empWorkers);
		const attRecords = dataStore.getEmployerAttendance(empIdentifier, selectedAttendanceDate);
		setDailyAttendanceRecords(attRecords);
		let start = reportStartDate;
		let end = reportEndDate;
		if (reportTimeframe === "week") {
			const now = /* @__PURE__ */ new Date();
			const first = now.getDate() - now.getDay();
			start = new Date(now.setDate(first)).toISOString().split("T")[0];
			end = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
		} else if (reportTimeframe === "month") {
			const now = /* @__PURE__ */ new Date();
			start = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split("T")[0];
			end = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
		}
		const rangeRecords = dataStore.getEmployerAttendanceRange(empIdentifier, start, end);
		setReportAttendanceRecords(rangeRecords);
	};
	(0, import_react.useEffect)(() => {
		loadAttendanceData();
	}, [
		empIdentifier,
		selectedAttendanceDate,
		reportTimeframe,
		reportStartDate,
		reportEndDate
	]);
	const handleMarkAttendance = (worker, status) => {
		dataStore.saveAttendanceStatus(empIdentifier, worker.id, worker.name, selectedAttendanceDate, status);
		loadAttendanceData();
		toast.success(`Attendance updated: ${worker.name} marked as ${status}`);
	};
	const handleOpenAddWorker = () => {
		setEditingWorkerId(null);
		setWorkerForm({
			name: "",
			mobile: "",
			trade: "General Worker",
			category: "Plant Nursery & Care",
			dailyRate: "500",
			joiningDate: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
		});
		setShowWorkerModal(true);
	};
	const handleOpenEditWorker = (w) => {
		setEditingWorkerId(w.id);
		setWorkerForm({
			name: w.name,
			mobile: w.mobile,
			trade: w.trade,
			category: w.category || w.trade || "Plant Nursery & Care",
			dailyRate: w.dailyRate.toString(),
			joiningDate: w.joiningDate || (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
		});
		setShowWorkerModal(true);
	};
	const handleSaveWorker = (e) => {
		e.preventDefault();
		if (!workerForm.name.trim()) {
			toast.error("Please enter employee name");
			return;
		}
		dataStore.saveEmployerWorker({
			...editingWorkerId ? { id: editingWorkerId } : {},
			employerId: empIdentifier,
			name: workerForm.name.trim(),
			mobile: workerForm.mobile.trim(),
			trade: workerForm.trade.trim() || "General Worker",
			category: workerForm.category.trim() || "Plant Nursery & Care",
			dailyRate: Number(workerForm.dailyRate) || 500,
			joiningDate: workerForm.joiningDate || (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
			status: "Active"
		});
		setShowWorkerModal(false);
		setEditingWorkerId(null);
		loadAttendanceData();
		toast.success("Employee details saved successfully!");
	};
	const handleDeleteWorker = (workerId, name) => {
		if (confirm(`Are you sure you want to delete employee '${name}'?`)) {
			dataStore.deleteEmployerWorker(workerId);
			loadAttendanceData();
			toast.success("Employee removed successfully!");
		}
	};
	const loadAllData = () => {
		if (isSuperAdmin) {
			setJobs(dataStore.getAllJobs());
			setApplications(dataStore.getAllApplications());
		} else {
			setJobs(dataStore.getEmployerJobs(empIdentifier));
			setApplications(dataStore.getEmployerApplications(empIdentifier));
		}
		const reg = dataStore.getRegisteredUsers();
		setRegisteredUsers(reg.map((u) => ({
			id: u.id,
			name: u.fullName,
			role: u.role,
			mobile: u.mobile || "N/A",
			city: "Maharashtra",
			trade: u.role === "worker" ? "Worker" : u.role === "employer" ? "Employer" : "Admin",
			status: "Verified",
			createdAt: u.createdAt || void 0
		})));
		refreshCredits();
	};
	(0, import_react.useEffect)(() => {
		loadAllData();
	}, [empIdentifier]);
	const handleUpdateAppStatus = (appId, status) => {
		dataStore.updateApplicationStatus(appId, status);
		loadAllData();
		toast.success(`Application status updated to '${status}'!`);
	};
	const [showJobForm, setShowJobForm] = (0, import_react.useState)(false);
	const [editingJobId, setEditingJobId] = (0, import_react.useState)(null);
	const [jobForm, setJobForm] = (0, import_react.useState)({
		title: "",
		company: "REAL JOB Platform",
		category: "",
		subcategory: "",
		location: "",
		salaryMin: "",
		salaryMax: "",
		salaryType: "Monthly",
		jobType: "Full Time",
		workMode: "On-site",
		vacancies: "5",
		education: "",
		experience: "",
		skills: "",
		description: "",
		responsibilities: "",
		benefits: "",
		status: "Active"
	});
	const setJ = (k, v) => setJobForm((p) => ({
		...p,
		[k]: v
	}));
	const activeJobPackages = dataStore.getJobPackages();
	const handleActivatePackage = () => {
		if (!currentUser) {
			toast.error("User session expired. Please login again.");
			return;
		}
		const selectedPlan = activeJobPackages.find((p) => p.id === selectedPlanId) || activeJobPackages[0];
		const userId = currentUser.id || currentUser.email || "admin-001";
		setIsProcessingPackage(true);
		setTimeout(() => {
			dataStore.addPackagePurchase({
				userId,
				planId: selectedPlan.id,
				planName: selectedPlan.name,
				price: selectedPlan.price,
				jobCount: selectedPlan.jobCount,
				paymentMethod: paymentMethod.toUpperCase()
			});
			setIsProcessingPackage(false);
			setShowPackageModal(false);
			refreshCredits();
			toast.success(`🎉 ${selectedPlan.name} activated! You now have ${selectedPlan.jobCount} Job Credits.`);
			setEditingJobId(null);
			setJobForm({
				title: "",
				company: currentUser?.fullName || "REAL JOB Platform",
				category: "",
				subcategory: "",
				location: "",
				salaryMin: "",
				salaryMax: "",
				salaryType: "Monthly",
				jobType: "Full Time",
				workMode: "On-site",
				vacancies: "5",
				education: "",
				experience: "",
				skills: "",
				description: "",
				responsibilities: "",
				benefits: "",
				status: "Active"
			});
			setShowJobForm(true);
		}, 1e3);
	};
	const handleEditJobClick = (job) => {
		setEditingJobId(job.id);
		let sMin = job.salaryMin ? String(job.salaryMin) : "";
		let sMax = job.salaryMax ? String(job.salaryMax) : "";
		if (!sMin && !sMax && job.salary) {
			const numbers = job.salary.match(/\d[\d,]*/g);
			if (numbers && numbers.length >= 2 && numbers[0] && numbers[1]) {
				sMin = numbers[0].replace(/,/g, "");
				sMax = numbers[1].replace(/,/g, "");
			}
		}
		setJobForm({
			title: job.title || "",
			company: job.company || "",
			category: job.category || "",
			subcategory: job.subcategory || "",
			location: job.location || "",
			salaryMin: sMin,
			salaryMax: sMax,
			salaryType: job.salaryType || "Monthly",
			jobType: job.jobType || "Full Time",
			workMode: job.workMode || "On-site",
			vacancies: job.vacancies ? String(job.vacancies) : "5",
			education: job.qualification || "",
			experience: job.experience || "",
			skills: (job.requiredSkills || []).join(", "),
			description: job.description || "",
			responsibilities: (job.responsibilities || []).join("\n"),
			benefits: (job.benefits || []).join(", "),
			status: job.status || "Active"
		});
		setShowJobForm(true);
	};
	const handlePublishJob = (e) => {
		e.preventDefault();
		const salaryText = jobForm.salaryMin && jobForm.salaryMax ? `₹${Number(jobForm.salaryMin).toLocaleString("en-IN")} - ₹${Number(jobForm.salaryMax).toLocaleString("en-IN")} / ${jobForm.salaryType === "Monthly" ? "Month" : "Year"}` : "Salary on Interview";
		if (editingJobId) {
			dataStore.updateJob(editingJobId, {
				title: jobForm.title,
				company: jobForm.company || currentUser?.fullName || "Company",
				category: jobForm.category || "General",
				subcategory: jobForm.subcategory || "",
				description: jobForm.description,
				qualification: jobForm.education,
				experience: jobForm.experience,
				salary: salaryText,
				salaryMin: Number(jobForm.salaryMin) || 0,
				salaryMax: Number(jobForm.salaryMax) || 0,
				salaryType: jobForm.salaryType,
				location: jobForm.location,
				jobType: jobForm.jobType,
				workMode: jobForm.workMode,
				vacancies: Number(jobForm.vacancies) || 1,
				status: jobForm.status
			});
			toast.success("✅ Job posting updated successfully!");
		} else {
			const empId = currentUser?.email || currentUser?.fullName || currentUser?.id || "admin-001";
			const compName = jobForm.company || currentUser?.fullName || "Company";
			dataStore.createJob({
				employerId: empId,
				title: jobForm.title,
				company: compName,
				category: jobForm.category || "General",
				subcategory: jobForm.subcategory || "",
				description: jobForm.description,
				responsibilities: [],
				requiredSkills: [],
				qualification: jobForm.education,
				experience: jobForm.experience,
				salary: salaryText,
				salaryMin: Number(jobForm.salaryMin) || 0,
				salaryMax: Number(jobForm.salaryMax) || 0,
				salaryType: jobForm.salaryType,
				location: jobForm.location,
				jobType: jobForm.jobType,
				workMode: jobForm.workMode,
				vacancies: Number(jobForm.vacancies) || 1,
				benefits: [],
				status: jobForm.status,
				approvalStatus: "pending"
			});
			if (!isSuperAdmin && currentUser?.id) {
				dataStore.consumeJobCredit(currentUser.id);
				refreshCredits();
			}
			toast.success("🎉 New job posted successfully!");
		}
		setShowJobForm(false);
		setEditingJobId(null);
		loadAllData();
	};
	const handleToggleJobStatus = (jobId, currentStatus) => {
		const nextStatus = currentStatus === "Active" ? "Closed" : "Active";
		dataStore.updateJob(jobId, { status: nextStatus });
		loadAllData();
		toast.success(`Job status updated to ${nextStatus}!`);
	};
	const handleDeleteJob = (jobId) => {
		dataStore.deleteJob(jobId);
		loadAllData();
		toast.success("Job posting removed!");
	};
	const filteredJobs = jobs.filter((j) => j.title.toLowerCase().includes(jobSearch.toLowerCase()) || j.company.toLowerCase().includes(jobSearch.toLowerCase()) || j.location.toLowerCase().includes(jobSearch.toLowerCase()));
	const activeSelectedPlan = activeJobPackages.find((p) => p.id === selectedPlanId) || activeJobPackages[0];
	if (showJobForm) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 bg-[#F0F4FA] overflow-y-auto flex flex-col font-sans",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bg-[#021D3D] text-white px-6 py-4 flex items-center justify-between border-b border-[#0A4F9E] sticky top-0 z-10 shadow-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setShowJobForm(false),
					className: "px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-bold transition-all flex items-center gap-1",
					children: "← Back to Dashboard"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-base font-black text-white",
					children: editingJobId ? "✏️ Edit Job Posting" : "💼 Post New Job"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-bold text-[#FFC400] bg-white/10 px-3 py-1 rounded-full",
				children: "Direct Hiring (Zero Commission)"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "max-w-5xl w-full mx-auto p-4 sm:p-8 flex-1",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handlePublishJob,
				className: "space-y-6 pb-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm overflow-hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 px-5 py-3 bg-[#F8FAFF] border-b border-[#E0E8F5]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "size-7 rounded-xl bg-[#063B78] text-white flex items-center justify-center text-xs font-black",
								children: "1"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-black text-[#10233F]",
								children: "Basic Job Details"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-5 grid grid-cols-1 md:grid-cols-2 gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-[#5B6B7F] mb-1",
									children: "Job Title *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									required: true,
									value: jobForm.title,
									onChange: (e) => setJ("title", e.target.value),
									placeholder: "e.g. Senior Software Engineer / Store Manager",
									className: "text-xs font-semibold"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-[#5B6B7F] mb-1",
									children: "Company Name *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									required: true,
									value: jobForm.company,
									onChange: (e) => setJ("company", e.target.value),
									placeholder: "e.g. Acme Corporation",
									className: "text-xs font-semibold"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-[#5B6B7F] mb-1",
									children: "Category *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									required: true,
									value: jobForm.category,
									onChange: (e) => setJ("category", e.target.value),
									placeholder: "e.g. Information Technology / Retail",
									className: "text-xs font-semibold"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-[#5B6B7F] mb-1",
									children: "Location *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									required: true,
									value: jobForm.location,
									onChange: (e) => setJ("location", e.target.value),
									placeholder: "e.g. Mumbai, Pune, Hybrid",
									className: "text-xs font-semibold"
								})] })
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm overflow-hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 px-5 py-3 bg-[#F8FAFF] border-b border-[#E0E8F5]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "size-7 rounded-xl bg-[#063B78] text-white flex items-center justify-center text-xs font-black",
								children: "2"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-black text-[#10233F]",
								children: "Salary & Work Mode"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-5 grid grid-cols-1 md:grid-cols-3 gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-[#5B6B7F] mb-1",
									children: "Min Salary (₹)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: jobForm.salaryMin,
									onChange: (e) => setJ("salaryMin", e.target.value),
									placeholder: "e.g. 25000",
									className: "text-xs font-semibold"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-[#5B6B7F] mb-1",
									children: "Max Salary (₹)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: jobForm.salaryMax,
									onChange: (e) => setJ("salaryMax", e.target.value),
									placeholder: "e.g. 45000",
									className: "text-xs font-semibold"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-[#5B6B7F] mb-1",
									children: "Salary Period"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: jobForm.salaryType,
									onChange: (e) => setJ("salaryType", e.target.value),
									className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Monthly",
											children: "Monthly"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Yearly",
											children: "Yearly"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Daily",
											children: "Daily Wage"
										})
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-[#5B6B7F] mb-1",
									children: "Job Type"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: jobForm.jobType,
									onChange: (e) => setJ("jobType", e.target.value),
									className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Full Time",
											children: "Full Time"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Part Time",
											children: "Part Time"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Contract",
											children: "Contract"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Internship",
											children: "Internship"
										})
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-[#5B6B7F] mb-1",
									children: "Work Mode"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: jobForm.workMode,
									onChange: (e) => setJ("workMode", e.target.value),
									className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "On-site",
											children: "On-site"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Work From Home",
											children: "Work From Home"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Hybrid",
											children: "Hybrid"
										})
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-[#5B6B7F] mb-1",
									children: "Vacancies"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: jobForm.vacancies,
									onChange: (e) => setJ("vacancies", e.target.value),
									placeholder: "5",
									className: "text-xs font-semibold"
								})] })
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm overflow-hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 px-5 py-3 bg-[#F8FAFF] border-b border-[#E0E8F5]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "size-7 rounded-xl bg-[#063B78] text-white flex items-center justify-center text-xs font-black",
								children: "3"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-black text-[#10233F]",
								children: "Job Description & Requirements"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-5 space-y-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-bold text-[#5B6B7F] mb-1",
								children: "Job Description *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								required: true,
								rows: 4,
								value: jobForm.description,
								onChange: (e) => setJ("description", e.target.value),
								placeholder: "Enter detailed job description, duties, and candidate expectations...",
								className: "w-full p-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-[#5B6B7F] mb-1",
									children: "Required Qualification"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: jobForm.education,
									onChange: (e) => setJ("education", e.target.value),
									placeholder: "e.g. Graduate / B.E. / Any Degree",
									className: "text-xs font-semibold"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-bold text-[#5B6B7F] mb-1",
									children: "Required Experience"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: jobForm.experience,
									onChange: (e) => setJ("experience", e.target.value),
									placeholder: "e.g. 1 - 3 Years",
									className: "text-xs font-semibold"
								})] })]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white rounded-2xl border border-[#E0E8F5] px-6 py-4 flex items-center justify-between sticky bottom-0 shadow-lg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] text-[#9DAEC5] font-semibold",
							children: "* Required fields must be filled before submitting"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setShowJobForm(false),
								className: "px-5 py-2.5 rounded-xl border border-[#DCE5F0] text-xs font-bold text-[#5B6B7F] hover:bg-[#F5F8FC] transition-all",
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: "px-7 py-2.5 rounded-xl bg-gradient-to-r from-[#063B78] to-[#0A4F9E] text-white font-black text-xs hover:opacity-90 transition-all shadow-md shadow-[#063B78]/20 flex items-center gap-1.5",
								children: editingJobId ? "✦ Update Job Posting" : "✦ Publish Job"
							})]
						})]
					})
				]
			})
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-[#F0F4FA] flex font-sans",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "w-64 bg-[#021D3D] text-white flex flex-col hidden md:flex h-screen sticky top-0 shrink-0 border-r border-white/10 overflow-y-auto",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-6 border-b border-white/10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 text-white",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-10 bg-gradient-to-br from-[#FFC400] to-[#FFA500] rounded-xl flex items-center justify-center shadow-lg border-[2px] border-white/10",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-6 text-[#021D3D]" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-black text-lg leading-none tracking-tight",
								children: "EMPLOYER PORTAL"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] text-[#FFC400] font-black uppercase tracking-widest",
								children: "Master Control"
							})] })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 py-6 px-4 space-y-1 overflow-y-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] font-black uppercase text-[#9DAEC5] tracking-widest px-3 mb-2",
								children: "Main Navigation"
							}),
							[
								{
									id: "overview",
									label: "Dashboard Overview",
									icon: ChartColumn
								},
								{
									id: "jobs",
									label: "Job Listings",
									icon: BriefcaseBusiness,
									count: jobs.length
								},
								{
									id: "applications",
									label: "Job Applications",
									icon: FileText,
									count: applications.length
								},
								{
									id: "attendance",
									label: "Attendance & Payroll",
									icon: CalendarCheck,
									count: workers.length
								}
							].map((item) => {
								const isActive = activeTab === item.id;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setActiveTab(item.id),
									className: `w-full flex items-center justify-between px-4 py-3 rounded-xl text-sm font-bold transition-all duration-200 ${isActive ? "bg-[#FFC400] text-[#021D3D] shadow-md shadow-[#FFC400]/20" : "text-[#9DAEC5] hover:bg-white/5 hover:text-white"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: `size-4 ${isActive ? "text-[#021D3D]" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label })]
									}), item.count !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `px-2 py-0.5 text-[11px] font-black rounded-full ${isActive ? "bg-[#021D3D] text-[#FFC400]" : "bg-amber-500/20 text-amber-300 border border-amber-400/30"}`,
										children: item.count
									}) : null]
								}, item.id);
							}),
							(() => {
								const defaultCategories = [
									"Plant Nursery & Care",
									"Tractor & Machinery",
									"Grafting & Propagation",
									"Packing & Loading",
									"Irrigation & Spraying",
									"Soil & Fertilizers",
									"General Labour"
								];
								const customWorkerCats = workers.map((w) => w.category || w.trade || "Plant Nursery & Care");
								const allCategories = Array.from(/* @__PURE__ */ new Set([...defaultCategories, ...customWorkerCats]));
								const categoryCounts = /* @__PURE__ */ new Map();
								workers.forEach((w) => {
									const cat = w.category || w.trade || "Plant Nursery & Care";
									categoryCounts.set(cat, (categoryCounts.get(cat) || 0) + 1);
								});
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-6 mt-4 border-t border-white/10 space-y-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between px-3 mb-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[10px] font-black uppercase text-[#FFC400] tracking-widest flex items-center gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "size-3.5" }), " Departments"]
											}), selectedCategoryFilter !== "ALL" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => setSelectedCategoryFilter("ALL"),
												className: "text-[10px] font-bold text-rose-400 hover:underline",
												children: "Reset"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => {
												setSelectedCategoryFilter("ALL");
												if (activeTab !== "attendance") setActiveTab("attendance");
											},
											className: `w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${selectedCategoryFilter === "ALL" && activeTab === "attendance" ? "bg-[#0A4F9E] text-white shadow-sm" : "text-[#9DAEC5] hover:bg-white/5 hover:text-white"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "🌐" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "All Categories" })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "px-2 py-0.5 rounded-full text-[10px] font-black bg-white/10 text-white",
												children: workers.length
											})]
										}),
										allCategories.map((cat) => {
											const count = categoryCounts.get(cat) || 0;
											const isSelected = selectedCategoryFilter === cat && activeTab === "attendance";
											const cleanName = formatCategoryName(cat);
											let emoji = "🌱";
											if (cleanName.includes("Tractor")) emoji = "🚜";
											if (cleanName.includes("Grafting")) emoji = "✂️";
											if (cleanName.includes("Packing")) emoji = "📦";
											if (cleanName.includes("Irrigation")) emoji = "💧";
											if (cleanName.includes("Soil")) emoji = "🌿";
											if (cleanName.includes("Labour")) emoji = "🛠️";
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												onClick: () => {
													setSelectedCategoryFilter(cat);
													if (activeTab !== "attendance") setActiveTab("attendance");
												},
												className: `w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${isSelected ? "bg-emerald-600 text-white shadow-md shadow-emerald-600/30" : "text-[#9DAEC5] hover:bg-white/5 hover:text-white"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-2 truncate",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: emoji }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "truncate",
														children: cleanName
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `px-2 py-0.5 rounded-full text-[10px] font-black shrink-0 ${isSelected ? "bg-white text-emerald-800" : "bg-white/10 text-white"}`,
													children: count
												})]
											}, cat);
										})
									]
								});
							})()
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-4 border-t border-white/10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								window.localStorage.removeItem("realjob-user");
								dataStore.setCurrentUser(null);
								toast.info("Logged out successfully");
								window.location.href = "/";
							},
							className: "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold text-rose-400 hover:bg-rose-500/10 transition-all",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Sign Out" })]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 flex flex-col min-h-screen overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "h-20 bg-white border-b border-[#E0E8F5] flex items-center justify-between px-6 sm:px-8 sticky top-0 z-30 shadow-sm shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "text-xl font-black text-[#063B78] capitalize",
							children: [
								activeTab === "overview" && "Dashboard Overview",
								activeTab === "jobs" && "Job Listings",
								activeTab === "applications" && "Job Applications",
								activeTab === "attendance" && "Attendance & Payroll Register"
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 sm:gap-4",
						children: [
							!isSuperAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 bg-amber-50 border border-amber-200 px-3 py-1.5 rounded-xl text-xs font-black text-amber-800",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-4 fill-amber-400 text-amber-500" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Credits: ", userCredits >= 999 ? "Unlimited" : userCredits] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setShowPackageModal(true),
										className: "ml-1 bg-amber-400 hover:bg-amber-500 text-[#063B78] px-2 py-0.5 rounded text-[10px] font-black transition-all",
										children: "+ Add"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative hidden md:block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#9DAEC5]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									placeholder: "Global search...",
									className: "w-48 lg:w-64 h-10 pl-10 pr-4 rounded-full bg-[#F8FAFF] border border-[#DCE5F0] text-sm font-semibold focus:ring-2 focus:ring-[#FFC400]/50 focus:border-[#FFC400] outline-none transition-all text-[#063B78]"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "size-10 bg-[#F8FAFF] border border-[#DCE5F0] rounded-full flex items-center justify-center relative cursor-pointer hover:bg-gray-100 transition-colors",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-5 text-[#5B6B7F]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-2 right-2 size-2 bg-[#FFC400] rounded-full border border-white" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageSwitcher, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 pl-3 sm:pl-4 border-l border-[#E0E8F5]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-right hidden sm:block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-bold text-[#063B78]",
										children: currentUser?.fullName || "Employer Account"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-[10px] font-bold text-amber-600 flex items-center justify-end gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3" }), " Verified Employer"]
									})]
								}), currentUser?.profilePhoto ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: currentUser.profilePhoto,
									alt: currentUser.fullName || "Employer",
									className: "size-10 rounded-xl object-cover shadow-md border-b-[2px] border-[#021D3D]"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-10 bg-gradient-to-br from-[#063B78] to-[#0A4F9E] rounded-xl flex items-center justify-center text-white font-black shadow-md border-b-[2px] border-[#021D3D]",
									children: (currentUser?.fullName || "E").charAt(0).toUpperCase()
								})]
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "flex-1 p-6 sm:p-8 overflow-y-auto",
					children: [
						activeTab === "overview" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-8",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
										label: isSuperAdmin ? "Total Registered Candidates" : "Candidates Applied to Your Jobs",
										value: isSuperAdmin ? registeredUsers.filter((u) => u.role === "worker").length.toString() : new Set(applications.map((a) => a.jobSeekerId || a.candidateEmail)).size.toString(),
										change: isSuperAdmin ? "Verified Platform Candidates" : "Unique Applicants",
										icon: Users
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
										label: "Active Job Listings",
										value: jobs.filter((j) => j.status === "Active").length.toString(),
										change: isSuperAdmin ? "Platform Total" : "Your Active Jobs",
										icon: BriefcaseBusiness
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
										label: "Total Applications Received",
										value: applications.length.toString(),
										change: isSuperAdmin ? "Platform Total" : "Applications for Your Jobs",
										icon: FileText
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "rounded-2xl border border-[#DCE5F0] bg-white p-6 shadow-sm flex flex-col justify-between",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
										className: "text-lg font-black text-[#10233F] flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "📩 Candidates Who Applied To Your Jobs" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] bg-emerald-100 text-emerald-800 border border-emerald-300 font-extrabold px-2.5 py-0.5 rounded-full",
											children: "Last 5 Days Window"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold text-[#5B6B7F] mt-0.5",
										children: "Candidates who applied to your posted jobs are displayed here for up to 5 days."
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
										className: "bg-[#063B78] text-white font-bold text-xs",
										children: [applications.length, " Total Applications"]
									})]
								}), (() => {
									const FIVE_DAYS_MS = 432e6;
									const recentApps = applications.filter((app) => {
										let ts = 0;
										if (app.appliedDate) {
											const parsed = Date.parse(app.appliedDate);
											if (!isNaN(parsed)) ts = parsed;
										}
										if (!ts && app.id?.startsWith("app-")) {
											const parsedTs = Number(app.id.replace("app-", ""));
											if (!isNaN(parsedTs)) ts = parsedTs;
										}
										if (!ts) return true;
										return Date.now() - ts <= FIVE_DAYS_MS;
									});
									if (recentApps.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "py-10 text-center border-2 border-dashed border-[#E0E8F5] rounded-xl bg-[#F8FAFF] my-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-10 text-[#A0AEC0] mx-auto mb-2" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-bold text-[#10233F]",
												children: "No candidate applications received in the last 5 days"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-medium text-[#5B6B7F] mt-1",
												children: "When candidates apply to your posted jobs, they will automatically appear here for 5 days."
											})
										]
									});
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "space-y-3 my-2 max-h-[300px] overflow-y-auto pr-1",
										children: recentApps.map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3.5 rounded-xl border border-[#E2E8F0] bg-[#F8FAFF] hover:bg-[#F0F4FA] transition-all flex items-center justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "size-10 rounded-full bg-[#063B78] text-white font-black text-sm flex items-center justify-center shrink-0",
													children: (app.candidateName || "C").charAt(0).toUpperCase()
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
													className: "text-xs font-black text-[#10233F]",
													children: app.candidateName
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-[11px] font-semibold text-[#5B6B7F]",
													children: [
														"💼 Applied for: ",
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-bold text-[#063B78]",
															children: app.jobTitle
														}),
														" | 📞 ",
														app.candidateMobile || "N/A"
													]
												})] })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-right shrink-0",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "inline-block text-[10px] font-extrabold px-2.5 py-1 rounded-md bg-emerald-100 text-emerald-800 border border-emerald-300",
													children: [
														"Applied: ",
														app.appliedDate || "Recent",
														" (5 Days Active)"
													]
												})
											})]
										}, app.id))
									});
								})()] })
							})]
						}),
						activeTab === "jobs" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white p-6 rounded-2xl border border-[#DCE5F0] shadow-sm space-y-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-xl font-black text-[#10233F]",
									children: "All Platform Job Listings"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold text-[#5B6B7F]",
									children: [
										"Total ",
										jobs.length,
										" job listings available. Manage or update job posts."
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "w-full sm:w-72 relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-3 size-4 text-[#5B6B7F]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: "Search job title, company, or location...",
										value: jobSearch,
										onChange: (e) => setJobSearch(e.target.value),
										className: "pl-9 text-xs font-bold"
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-x-auto rounded-xl border border-[#DCE5F0]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full text-left text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
										className: "bg-[#063B78] text-white font-black uppercase",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3.5",
												children: "Job Title"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3.5",
												children: "Company"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3.5",
												children: "Location & Salary"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3.5",
												children: "Vacancies"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3.5",
												children: "Approval"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3.5",
												children: "Status"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3.5 text-right",
												children: "Actions"
											})
										] })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
										className: "divide-y divide-[#DCE5F0] font-semibold text-[#10233F]",
										children: [filteredJobs.map((j) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: "hover:bg-[#F5F8FC]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
													className: "p-3.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
														className: "block font-black text-[#063B78]",
														children: j.title
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[11px] text-[#5B6B7F]",
														children: j.category
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
													className: "p-3.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
														className: "block font-bold text-[#063B78]",
														children: j.company
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-[10px] text-indigo-700 font-bold block mt-0.5",
														children: ["👤 Posted by: ", j.employerId || j.company]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
													className: "p-3.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: j.location }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-[#125BB5] font-bold",
														children: j.salary
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
													className: "p-3.5 font-black text-[#063B78]",
													children: [j.vacancies || 5, " Openings"]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "p-3.5",
													children: j.approvalStatus === "rejected" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
														className: "bg-red-600 text-white font-bold",
														children: "❌ Rejected"
													}) : j.approvalStatus === "approved" || !j.approvalStatus ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
														className: "bg-emerald-600 text-white font-bold",
														children: "✅ Approved"
													}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
														className: "bg-amber-500 text-white font-bold",
														children: "⏳ Pending Approval"
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "p-3.5",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
														className: j.status === "Active" ? "bg-emerald-600 text-white font-bold" : "bg-gray-500 text-white font-bold",
														children: j.status
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "p-3.5 text-right",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center justify-end gap-2",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
																size: "sm",
																onClick: () => {
																	setFilterJobId(j.id);
																	setActiveTab("applications");
																},
																className: "bg-[#063B78] text-white font-extrabold text-[11px] hover:bg-[#0A4F9E]",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-3.5 mr-1" }),
																	"View Applications (",
																	applications.filter((a) => a.jobId === j.id).length,
																	")"
																]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
																size: "sm",
																variant: "outline",
																onClick: () => handleEditJobClick(j),
																className: "font-extrabold text-[11px] border-[#063B78] text-[#063B78] hover:bg-[#F0F5FF]",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquarePen, { className: "size-3.5 mr-1" }), " Edit"]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
																size: "sm",
																variant: "outline",
																onClick: () => handleToggleJobStatus(j.id, j.status),
																className: "font-extrabold text-[11px] border-gray-400 text-gray-700",
																children: j.status === "Active" ? "Close Job" : "Activate Job"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
																size: "sm",
																variant: "ghost",
																onClick: () => handleDeleteJob(j.id),
																className: "text-red-600 hover:bg-red-50",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
															})
														]
													})
												})
											]
										}, j.id)), filteredJobs.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											colSpan: 7,
											className: "p-8 text-center text-xs font-bold text-[#5B6B7F] bg-[#F8FAFF]",
											children: "No job listings posted yet."
										}) })]
									})]
								})
							})]
						}),
						activeTab === "applications" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white p-6 rounded-2xl border border-[#DCE5F0] shadow-sm space-y-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-xl font-black text-[#10233F]",
									children: "Job Applications & Applicants"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold text-[#5B6B7F]",
									children: [
										"Total ",
										applications.length,
										" candidates applied. Contact candidates directly or update application status."
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-3 w-full sm:w-auto",
									children: [filterJobId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => setFilterJobId(null),
										className: "text-xs font-bold border-[#063B78] text-[#063B78]",
										children: "✕ Show All Applications"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "w-full sm:w-64 relative",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-3 size-4 text-[#5B6B7F]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											placeholder: "Search candidate name, job, or phone...",
											value: appSearch,
											onChange: (e) => setAppSearch(e.target.value),
											className: "pl-9 text-xs font-bold"
										})]
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-x-auto rounded-xl border border-[#DCE5F0]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full text-left text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
										className: "bg-[#063B78] text-white font-black uppercase",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3.5",
												children: "Candidate Name"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3.5",
												children: "Applied Job"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3.5",
												children: "Direct Contact"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3.5",
												children: "Applied Date"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3.5",
												children: "Status"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3.5 text-right",
												children: "Details"
											})
										] })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
										className: "divide-y divide-[#DCE5F0] font-semibold text-[#10233F]",
										children: [applications.filter((a) => !filterJobId || a.jobId === filterJobId).filter((a) => a.candidateName.toLowerCase().includes(appSearch.toLowerCase()) || a.jobTitle.toLowerCase().includes(appSearch.toLowerCase()) || a.candidateMobile.toLowerCase().includes(appSearch.toLowerCase())).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: "hover:bg-[#F5F8FC]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
													className: "p-3.5 font-black text-[#063B78]",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: a.candidateName }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-[11px] text-[#5B6B7F] font-normal",
														children: a.candidateEmail
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
													className: "p-3.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "font-bold text-[#10233F]",
														children: a.jobTitle
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "text-[11px] text-[#125BB5]",
														children: [
															a.companyName || "Company",
															" • ",
															a.location
														]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "p-3.5",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
															href: `tel:${formatCallNumber(a.candidateMobile)}`,
															className: "px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold text-[10px] hover:bg-emerald-700 transition-all flex items-center gap-1",
															children: "📞 Call Candidate"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
															href: `https://wa.me/${formatWaNumber(a.candidateMobile)}?text=${encodeURIComponent(`Hello ${a.candidateName}, regarding your application for ${a.jobTitle}.`)}`,
															target: "_blank",
															rel: "noreferrer",
															className: "px-2.5 py-1 rounded-lg bg-green-600 text-white font-bold text-[10px] hover:bg-green-700 transition-all flex items-center gap-1",
															children: "💬 WhatsApp"
														})]
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "p-3.5 text-[#5B6B7F] font-bold",
													children: a.appliedDate
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "p-3.5",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
														value: a.status,
														onChange: (e) => handleUpdateAppStatus(a.id, e.target.value),
														className: "h-8 px-2 rounded-lg border border-[#DCE5F0] text-xs font-black focus:outline-none focus:border-[#063B78]",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																value: "Applied",
																children: "📝 Applied"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																value: "Viewed",
																children: "👀 Viewed"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																value: "Shortlisted",
																children: "⭐ Shortlisted"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																value: "Interview",
																children: "📅 Interview Scheduled"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																value: "Selected",
																children: "✅ Selected / Hired"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																value: "Rejected",
																children: "❌ Rejected"
															})
														]
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "p-3.5 text-right",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														variant: "outline",
														size: "sm",
														onClick: () => setExpandedApp(expandedApp === a.id ? null : a.id),
														className: "text-[10px] h-7 px-3 border-[#063B78] text-[#063B78] hover:bg-[#063B78] hover:text-white",
														children: expandedApp === a.id ? "Hide Details" : "View Details"
													})
												})
											]
										}), expandedApp === a.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
											className: "bg-[#F8FAFC]",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												colSpan: 6,
												className: "p-4 border-t border-[#DCE5F0]",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "bg-white p-5 rounded-xl border border-[#E2E8F0] shadow-sm",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
														className: "font-bold text-[#10233F] mb-4 border-b pb-2 flex items-center gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4 text-[#063B78]" }), "Candidate Application Details"]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5",
														children: [
															a.fieldValues && Object.entries(a.fieldValues).map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "text-xs bg-[#F5F8FC] p-3 rounded-lg border border-[#DCE5F0]",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																	className: "font-bold text-[#5B6B7F] capitalize mb-1",
																	children: key.replace(/([A-Z])/g, " $1").trim()
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																	className: "font-black text-[#10233F]",
																	children: value
																})]
															}, key)),
															a.customAnswers && Object.entries(a.customAnswers).map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "text-xs bg-[#F5F8FC] p-3 rounded-lg border border-[#DCE5F0]",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																	className: "font-bold text-[#5B6B7F] capitalize mb-1",
																	children: key
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																	className: "font-black text-[#10233F]",
																	children: value
																})]
															}, key)),
															!a.fieldValues && !a.customAnswers && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "text-sm font-semibold text-[#5B6B7F]",
																children: "No additional application details provided."
															})
														]
													})]
												})
											})
										})] }, a.id)), applications.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											colSpan: 6,
											className: "p-8 text-center text-xs font-bold text-[#5B6B7F] bg-[#F8FAFF]",
											children: "No job applications received yet."
										}) })]
									})]
								})
							})]
						}),
						activeTab === "attendance" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-8 animate-fade-in",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-[#DCE5F0] bg-white p-6 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "inline-flex items-center gap-2 rounded-full bg-[#063B78]/10 px-3.5 py-1 text-xs font-black text-[#063B78] mb-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarCheck, { className: "size-4 text-[#063B78]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Employee Attendance & Payroll Management" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-xl sm:text-2xl font-black text-[#10233F]",
										children: "Employee Attendance & Payroll Register"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs sm:text-sm font-semibold text-[#5B6B7F] mt-1",
										children: "Manage employee details by department, set custom daily wage rates, mark daily attendance, and generate weekly/monthly payroll reports."
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap gap-2 shrink-0",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										onClick: handleOpenAddWorker,
										className: "bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs px-5 py-3 rounded-xl shadow-md flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "+ Add Employee" })]
									})
								})]
							}), (() => {
								const defaultCategories = [
									"Plant Nursery & Care",
									"Tractor & Machinery",
									"Grafting & Propagation",
									"Packing & Loading",
									"Irrigation & Spraying",
									"Soil & Fertilizers",
									"General Labour"
								];
								const customWorkerCats = workers.map((w) => w.category || w.trade || "Plant Nursery & Care");
								const allCategories = Array.from(/* @__PURE__ */ new Set([...defaultCategories, ...customWorkerCats]));
								const categoryCounts = /* @__PURE__ */ new Map();
								workers.forEach((w) => {
									const cat = w.category || w.trade || "Plant Nursery & Care";
									categoryCounts.set(cat, (categoryCounts.get(cat) || 0) + 1);
								});
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 lg:grid-cols-4 gap-6 items-start",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "lg:col-span-1 bg-white rounded-2xl border border-[#DCE5F0] p-4 shadow-sm space-y-4 lg:sticky lg:top-24",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between pb-3 border-b border-[#EBF1F8]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
												className: "text-xs font-black text-[#063B78] uppercase tracking-wider flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "size-4 text-[#063B78]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Departments" })]
											}), selectedCategoryFilter !== "ALL" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => setSelectedCategoryFilter("ALL"),
												className: "text-[10px] font-bold text-rose-600 hover:underline",
												children: "✕ Reset"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												onClick: () => setSelectedCategoryFilter("ALL"),
												className: `w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-extrabold transition-all ${selectedCategoryFilter === "ALL" ? "bg-[#063B78] text-white shadow-md shadow-[#063B78]/20" : "text-[#5B6B7F] hover:bg-[#F0F5FF] hover:text-[#063B78]"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "🌐" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "All Categories" })]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `px-2 py-0.5 rounded-full text-[10px] font-black ${selectedCategoryFilter === "ALL" ? "bg-white text-[#063B78]" : "bg-slate-100 text-slate-700"}`,
													children: workers.length
												})]
											}), allCategories.map((cat) => {
												const count = categoryCounts.get(cat) || 0;
												const isSelected = selectedCategoryFilter === cat;
												const cleanName = formatCategoryName(cat);
												let emoji = "🌱";
												if (cleanName.includes("Tractor")) emoji = "🚜";
												if (cleanName.includes("Grafting")) emoji = "✂️";
												if (cleanName.includes("Packing")) emoji = "📦";
												if (cleanName.includes("Irrigation")) emoji = "💧";
												if (cleanName.includes("Soil")) emoji = "🌿";
												if (cleanName.includes("Labour")) emoji = "🛠️";
												return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													onClick: () => setSelectedCategoryFilter(cat),
													className: `w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-extrabold transition-all ${isSelected ? "bg-emerald-600 text-white shadow-md shadow-emerald-600/20" : "text-[#334155] hover:bg-emerald-50/80 hover:text-emerald-800"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "flex items-center gap-2 truncate",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: emoji }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "truncate",
															children: cleanName
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: `px-2 py-0.5 rounded-full text-[10px] font-black shrink-0 ${isSelected ? "bg-white text-emerald-800" : "bg-slate-100 text-slate-700"}`,
														children: count
													})]
												}, cat);
											})]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "lg:col-span-3 space-y-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-wrap items-center justify-between gap-3 bg-white p-2.5 rounded-2xl border border-[#DCE5F0] shadow-sm",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "flex flex-wrap items-center gap-2",
													children: [
														{
															id: "daily",
															label: "📋 Daily Attendance",
															icon: CalendarCheck
														},
														{
															id: "reports",
															label: "📊 Weekly & Monthly Reports",
															icon: ChartPie
														},
														{
															id: "directory",
															label: `👥 Employee Directory (${workers.length})`,
															icon: Users
														}
													].map((tab) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														onClick: () => setAttendanceSubView(tab.id),
														className: `flex items-center gap-2 px-4 py-2.5 rounded-xl font-black text-xs transition-all ${attendanceSubView === tab.id ? "bg-[#063B78] text-white shadow-md shadow-[#063B78]/20" : "bg-[#F8FAFF] text-[#5B6B7F] border border-[#DCE5F0] hover:bg-[#EBF1F8] hover:text-[#063B78]"}`,
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(tab.icon, { className: "size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: tab.label })]
													}, tab.id))
												}), attendanceSubView === "reports" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
													variant: "outline",
													size: "sm",
													onClick: () => window.print(),
													className: "text-xs font-black border-[#063B78] text-[#063B78] hover:bg-blue-50 flex items-center gap-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Print / Export Report" })]
												})]
											}),
											attendanceSubView === "daily" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-6",
												children: [
													(() => {
														const attMap = /* @__PURE__ */ new Map();
														dailyAttendanceRecords.forEach((r) => attMap.set(r.workerId, r));
														let pCount = 0;
														let hCount = 0;
														let aCount = 0;
														let otCount = 0;
														let todayWageSum = 0;
														const filteredByCat = workers.filter((w) => {
															if (selectedCategoryFilter === "ALL") return true;
															return (w.category || w.trade || "Plant Nursery / रोपवाटिका") === selectedCategoryFilter;
														});
														filteredByCat.forEach((w) => {
															const st = attMap.get(w.id)?.status || "Present";
															if (st === "Present") {
																pCount++;
																todayWageSum += w.dailyRate;
															} else if (st === "HalfDay") {
																hCount++;
																todayWageSum += Math.round(w.dailyRate / 2);
															} else if (st === "Absent") aCount++;
															else if (st === "Overtime") {
																otCount++;
																todayWageSum += Math.round(w.dailyRate * 1.5);
															}
														});
														return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-5",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "p-4 rounded-2xl border border-[#DCE5F0] bg-white shadow-sm flex items-center justify-between",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-xs font-extrabold text-[#5B6B7F]",
																		children: "Department Employees"
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
																		className: "text-2xl font-black text-[#10233F] mt-1",
																		children: filteredByCat.length
																	})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																		className: "p-3 bg-blue-50 text-[#063B78] rounded-xl",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5" })
																	})]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "p-4 rounded-2xl border border-[#DCE5F0] bg-white shadow-sm flex items-center justify-between",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-xs font-extrabold text-emerald-700",
																		children: "Present Today"
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
																		className: "text-2xl font-black text-emerald-600 mt-1",
																		children: pCount
																	})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																		className: "p-3 bg-emerald-50 text-emerald-600 rounded-xl",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-5" })
																	})]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "p-4 rounded-2xl border border-[#DCE5F0] bg-white shadow-sm flex items-center justify-between",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-xs font-extrabold text-amber-700",
																		children: "Half Day Today"
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
																		className: "text-2xl font-black text-amber-600 mt-1",
																		children: hCount
																	})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																		className: "p-3 bg-amber-50 text-amber-600 rounded-xl",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-5" })
																	})]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "p-4 rounded-2xl border border-[#DCE5F0] bg-white shadow-sm flex items-center justify-between",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-xs font-extrabold text-rose-700",
																		children: "Absent Today"
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
																		className: "text-2xl font-black text-rose-600 mt-1",
																		children: aCount
																	})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																		className: "p-3 bg-rose-50 text-rose-600 rounded-xl",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserX, { className: "size-5" })
																	})]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "p-4 rounded-2xl border border-[#DCE5F0] bg-white shadow-sm flex items-center justify-between",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-xs font-extrabold text-[#063B78]",
																		children: "Today's Payable Wages"
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
																		className: "text-xl font-black text-[#063B78] mt-1",
																		children: ["₹", todayWageSum.toLocaleString("en-IN")]
																	})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																		className: "p-3 bg-indigo-50 text-[#063B78] rounded-xl",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DollarSign, { className: "size-5" })
																	})]
																})
															]
														});
													})(),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "rounded-2xl border border-[#DCE5F0] bg-white p-5 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex flex-wrap items-center gap-3",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "flex items-center gap-2 bg-[#F0F4FA] px-3.5 py-2 rounded-xl border border-[#DCE5F0]",
																	children: [
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-4 text-[#063B78]" }),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																			className: "text-xs font-extrabold text-[#10233F]",
																			children: "Select Date:"
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
																			type: "date",
																			value: selectedAttendanceDate,
																			onChange: (e) => setSelectedAttendanceDate(e.target.value),
																			className: "bg-transparent font-bold text-xs text-[#063B78] focus:outline-none cursor-pointer"
																		})
																	]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
																	variant: "outline",
																	size: "sm",
																	onClick: () => setSelectedAttendanceDate((/* @__PURE__ */ new Date()).toISOString().split("T")[0]),
																	className: `text-xs font-extrabold rounded-xl border-[#DCE5F0] ${selectedAttendanceDate === (/* @__PURE__ */ new Date()).toISOString().split("T")[0] ? "bg-[#063B78] text-white hover:bg-[#063B78]" : "bg-white text-[#5B6B7F]"}`,
																	children: "Today"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
																	variant: "outline",
																	size: "sm",
																	onClick: () => {
																		const d = /* @__PURE__ */ new Date();
																		d.setDate(d.getDate() - 1);
																		setSelectedAttendanceDate(d.toISOString().split("T")[0]);
																	},
																	className: `text-xs font-extrabold rounded-xl border-[#DCE5F0] ${selectedAttendanceDate === (/* @__PURE__ */ new Date(Date.now() - 864e5)).toISOString().split("T")[0] ? "bg-[#063B78] text-white hover:bg-[#063B78]" : "bg-white text-[#5B6B7F]"}`,
																	children: "Yesterday"
																})
															]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "relative w-full md:w-72",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3.5 top-2.5 size-4 text-[#A0AEC0]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
																placeholder: "Search employee name or role...",
																value: workerSearch,
																onChange: (e) => setWorkerSearch(e.target.value),
																className: "pl-9 text-xs font-semibold h-10 rounded-xl border-[#DCE5F0]"
															})]
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "rounded-2xl border border-[#DCE5F0] bg-white p-6 shadow-sm",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "flex items-center justify-between mb-5",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
																className: "text-lg font-black text-[#10233F] flex items-center gap-2",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "📅 Daily Attendance Sheet" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
																	className: "bg-[#063B78] text-white font-bold text-xs",
																	children: selectedAttendanceDate
																})]
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																className: "text-xs font-semibold text-[#5B6B7F] mt-1",
																children: selectedCategoryFilter === "ALL" ? "Showing attendance records for all departments:" : `Showing attendance records for '${selectedCategoryFilter}' department:`
															})] })
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "overflow-x-auto",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
																className: "w-full text-left border-collapse",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
																	className: "border-b border-[#EBF1F8] bg-[#F8FAFF] text-[11px] uppercase tracking-wider text-[#5B6B7F] font-black",
																	children: [
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4 rounded-l-xl",
																			children: "Employee Name"
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4",
																			children: "Department / Category"
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4",
																			children: "Role / Designation"
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4",
																			children: "Daily Wage Rate"
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4 text-center min-w-[390px]",
																			children: "Mark Attendance"
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4 text-right rounded-r-xl",
																			children: "Today's Pay"
																		})
																	]
																}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
																	className: "divide-y divide-[#EBF1F8] text-xs font-semibold",
																	children: (() => {
																		const attMap = /* @__PURE__ */ new Map();
																		dailyAttendanceRecords.forEach((r) => attMap.set(r.workerId, r));
																		const list = workers.filter((w) => {
																			if (selectedCategoryFilter !== "ALL") {
																				if ((w.category || w.trade || "Plant Nursery & Care") !== selectedCategoryFilter) return false;
																			}
																			const q = workerSearch.toLowerCase().trim();
																			if (!q) return true;
																			return w.name.toLowerCase().includes(q) || w.mobile.includes(q) || w.trade.toLowerCase().includes(q) || w.category && w.category.toLowerCase().includes(q);
																		});
																		if (list.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																			colSpan: 6,
																			className: "py-12 text-center text-xs font-bold text-[#5B6B7F]",
																			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																				className: "max-w-md mx-auto",
																				children: [
																					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-10 text-[#A0AEC0] mx-auto mb-3" }),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																						className: "text-sm font-extrabold text-[#10233F]",
																						children: selectedCategoryFilter === "ALL" ? "No employees registered yet" : `No employees found in '${selectedCategoryFilter}' department`
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
																						className: "text-xs font-medium text-[#5B6B7F] mt-1 mb-4",
																						children: [
																							"Click the ",
																							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																								className: "font-bold text-emerald-700",
																								children: "'+ Add Employee'"
																							}),
																							" button above to register your first worker."
																						]
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
																						onClick: handleOpenAddWorker,
																						className: "bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs px-4 py-2 rounded-xl",
																						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-4 mr-1.5" }), " + Add Employee"]
																					})
																				]
																			})
																		}) });
																		return list.map((worker) => {
																			const currentStatus = attMap.get(worker.id)?.status || "Present";
																			let earnedAmount = worker.dailyRate;
																			if (currentStatus === "HalfDay") earnedAmount = Math.round(worker.dailyRate / 2);
																			if (currentStatus === "Absent") earnedAmount = 0;
																			if (currentStatus === "Overtime") earnedAmount = Math.round(worker.dailyRate * 1.5);
																			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
																				className: "hover:bg-[#F8FAFF] transition-colors",
																				children: [
																					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																						className: "p-4 font-black text-[#10233F]",
																						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																							className: "flex items-center gap-3",
																							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																								className: "size-9 rounded-full bg-[#063B78]/10 text-[#063B78] font-black flex items-center justify-center text-sm shrink-0",
																								children: worker.name.slice(0, 1).toUpperCase()
																							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																								className: "text-sm font-black text-[#10233F]",
																								children: worker.name
																							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																								className: "text-[10px] text-[#5B6B7F]",
																								children: ["📞 ", worker.mobile || "N/A"]
																							})] })]
																						})
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																						className: "p-4",
																						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
																							className: "bg-emerald-50 text-emerald-800 border border-emerald-200 font-extrabold text-[11px]",
																							children: formatCategoryName(worker.category || worker.trade)
																						})
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																						className: "p-4 font-bold text-[#063B78]",
																						children: worker.trade || "General Worker"
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																						className: "p-4 font-black text-[#10233F]",
																						children: [
																							"₹",
																							worker.dailyRate,
																							" ",
																							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																								className: "text-[10px] font-semibold text-[#5B6B7F]",
																								children: "/ day"
																							})
																						]
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																						className: "p-4 text-center min-w-[390px]",
																						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																							className: "inline-flex items-center gap-1 bg-slate-100/90 p-1 rounded-2xl border border-slate-200/80 shadow-inner whitespace-nowrap",
																							children: [
																								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
																									type: "button",
																									onClick: () => handleMarkAttendance(worker, "Present"),
																									className: `px-3 py-1.5 rounded-xl font-black text-xs transition-all flex items-center gap-1.5 shrink-0 ${currentStatus === "Present" ? "bg-emerald-600 text-white shadow-md shadow-emerald-600/30 scale-[1.02]" : "text-slate-600 hover:text-emerald-700 hover:bg-emerald-50/80"}`,
																									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Present" })]
																								}),
																								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
																									type: "button",
																									onClick: () => handleMarkAttendance(worker, "HalfDay"),
																									className: `px-3 py-1.5 rounded-xl font-black text-xs transition-all flex items-center gap-1.5 shrink-0 ${currentStatus === "HalfDay" ? "bg-amber-500 text-white shadow-md shadow-amber-500/30 scale-[1.02]" : "text-slate-600 hover:text-amber-700 hover:bg-amber-50/80"}`,
																									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Half Day" })]
																								}),
																								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
																									type: "button",
																									onClick: () => handleMarkAttendance(worker, "Absent"),
																									className: `px-3 py-1.5 rounded-xl font-black text-xs transition-all flex items-center gap-1.5 shrink-0 ${currentStatus === "Absent" ? "bg-rose-600 text-white shadow-md shadow-rose-600/30 scale-[1.02]" : "text-slate-600 hover:text-rose-700 hover:bg-rose-50/80"}`,
																									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Absent" })]
																								}),
																								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
																									type: "button",
																									onClick: () => handleMarkAttendance(worker, "Overtime"),
																									className: `px-3 py-1.5 rounded-xl font-black text-xs transition-all flex items-center gap-1.5 shrink-0 ${currentStatus === "Overtime" ? "bg-[#063B78] text-white shadow-md shadow-[#063B78]/30 scale-[1.02]" : "text-slate-600 hover:text-[#063B78] hover:bg-blue-50/80"}`,
																									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-3.5 text-amber-400 fill-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Overtime" })]
																								})
																							]
																						})
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																						className: "p-4 text-right font-black text-emerald-700 text-sm",
																						children: ["₹", earnedAmount.toLocaleString("en-IN")]
																					})
																				]
																			}, worker.id);
																		});
																	})()
																})]
															})
														})]
													})
												]
											}),
											attendanceSubView === "reports" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-6",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "rounded-2xl border border-[#DCE5F0] bg-white p-5 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex flex-wrap items-center gap-2",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																	className: "text-xs font-black text-[#10233F] mr-1 flex items-center gap-1",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "size-4 text-[#063B78]" }), "Report Period:"]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																	onClick: () => setReportTimeframe("week"),
																	className: `px-3.5 py-2 rounded-xl text-xs font-black transition-all ${reportTimeframe === "week" ? "bg-[#063B78] text-white shadow-md" : "bg-[#F5F8FC] text-[#5B6B7F] border border-[#DCE5F0] hover:bg-[#EBF1F8]"}`,
																	children: "This Week"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																	onClick: () => setReportTimeframe("month"),
																	className: `px-3.5 py-2 rounded-xl text-xs font-black transition-all ${reportTimeframe === "month" ? "bg-[#063B78] text-white shadow-md" : "bg-[#F5F8FC] text-[#5B6B7F] border border-[#DCE5F0] hover:bg-[#EBF1F8]"}`,
																	children: "This Month"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																	onClick: () => setReportTimeframe("custom"),
																	className: `px-3.5 py-2 rounded-xl text-xs font-black transition-all ${reportTimeframe === "custom" ? "bg-[#063B78] text-white shadow-md" : "bg-[#F5F8FC] text-[#5B6B7F] border border-[#DCE5F0] hover:bg-[#EBF1F8]"}`,
																	children: "Custom Date Range"
																})
															]
														}), reportTimeframe === "custom" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center gap-2",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
																	type: "date",
																	value: reportStartDate,
																	onChange: (e) => setReportStartDate(e.target.value),
																	className: "bg-[#F8FAFF] border border-[#DCE5F0] rounded-xl px-3 py-1.5 text-xs font-bold text-[#063B78]"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "text-xs font-bold text-[#5B6B7F]",
																	children: "to"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
																	type: "date",
																	value: reportEndDate,
																	onChange: (e) => setReportEndDate(e.target.value),
																	className: "bg-[#F8FAFF] border border-[#DCE5F0] rounded-xl px-3 py-1.5 text-xs font-bold text-[#063B78]"
																})
															]
														})]
													}),
													(() => {
														const filteredWorkers = workers.filter((w) => {
															if (selectedCategoryFilter === "ALL") return true;
															return (w.category || w.trade) === selectedCategoryFilter;
														});
														let totalPresentDays = 0;
														let totalHalfDays = 0;
														let totalAbsentDays = 0;
														let totalOvertimeDays = 0;
														let totalPeriodPayroll = 0;
														filteredWorkers.forEach((w) => {
															reportAttendanceRecords.filter((r) => r.workerId === w.id).forEach((r) => {
																if (r.status === "Present") {
																	totalPresentDays++;
																	totalPeriodPayroll += w.dailyRate;
																} else if (r.status === "HalfDay") {
																	totalHalfDays++;
																	totalPeriodPayroll += Math.round(w.dailyRate / 2);
																} else if (r.status === "Absent") totalAbsentDays++;
																else if (r.status === "Overtime") {
																	totalOvertimeDays++;
																	totalPeriodPayroll += Math.round(w.dailyRate * 1.5);
																}
															});
														});
														return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-5",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "p-4 rounded-2xl border border-[#DCE5F0] bg-white shadow-sm flex items-center justify-between",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-xs font-extrabold text-[#5B6B7F]",
																		children: "Total Recorded Days"
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
																		className: "text-2xl font-black text-[#10233F] mt-1",
																		children: reportAttendanceRecords.length
																	})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																		className: "p-3 bg-blue-50 text-[#063B78] rounded-xl",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "size-5" })
																	})]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "p-4 rounded-2xl border border-[#DCE5F0] bg-white shadow-sm flex items-center justify-between",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-xs font-extrabold text-emerald-700",
																		children: "Total Present Days"
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
																		className: "text-2xl font-black text-emerald-600 mt-1",
																		children: totalPresentDays
																	})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																		className: "p-3 bg-emerald-50 text-emerald-600 rounded-xl",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-5" })
																	})]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "p-4 rounded-2xl border border-[#DCE5F0] bg-white shadow-sm flex items-center justify-between",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-xs font-extrabold text-amber-700",
																		children: "Total Half Days"
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
																		className: "text-2xl font-black text-amber-600 mt-1",
																		children: totalHalfDays
																	})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																		className: "p-3 bg-amber-50 text-amber-600 rounded-xl",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-5" })
																	})]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "p-4 rounded-2xl border border-[#DCE5F0] bg-white shadow-sm flex items-center justify-between",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-xs font-extrabold text-rose-700",
																		children: "Total Absent Days"
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
																		className: "text-2xl font-black text-rose-600 mt-1",
																		children: totalAbsentDays
																	})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																		className: "p-3 bg-rose-50 text-rose-600 rounded-xl",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserX, { className: "size-5" })
																	})]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	className: "p-4 rounded-2xl border border-[#DCE5F0] bg-white shadow-sm flex items-center justify-between",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "text-xs font-extrabold text-[#063B78]",
																		children: "Net Total Payroll"
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
																		className: "text-xl font-black text-[#063B78] mt-1",
																		children: ["₹", totalPeriodPayroll.toLocaleString("en-IN")]
																	})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																		className: "p-3 bg-indigo-50 text-[#063B78] rounded-xl",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DollarSign, { className: "size-5" })
																	})]
																})
															]
														});
													})(),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "rounded-2xl border border-[#DCE5F0] bg-white p-6 shadow-sm",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "flex items-center justify-between mb-5",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
																className: "text-lg font-black text-[#10233F] flex items-center gap-2",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "📊 Employee Weekly & Monthly Payroll Summary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
																	className: "bg-[#063B78] text-white font-bold text-xs uppercase",
																	children: reportTimeframe === "week" ? "Weekly Report" : reportTimeframe === "month" ? "Monthly Report" : "Custom Range"
																})]
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																className: "text-xs font-semibold text-[#5B6B7F] mt-1",
																children: "Individual employee present days, half days, absent days, overtime, and calculated net wages:"
															})] })
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "overflow-x-auto",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
																className: "w-full text-left border-collapse",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
																	className: "border-b border-[#EBF1F8] bg-[#F8FAFF] text-[11px] uppercase tracking-wider text-[#5B6B7F] font-black",
																	children: [
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4 rounded-l-xl",
																			children: "Employee Name"
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4",
																			children: "Department / Category"
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4",
																			children: "Daily Wage Rate"
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4 text-center text-emerald-700",
																			children: "Present Days"
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4 text-center text-amber-700",
																			children: "Half Days"
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4 text-center text-rose-700",
																			children: "Absent Days"
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4 text-center text-blue-700",
																			children: "Overtime Days"
																		}),
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																			className: "p-4 text-right rounded-r-xl",
																			children: "Net Payable Wages"
																		})
																	]
																}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
																	className: "divide-y divide-[#EBF1F8] text-xs font-semibold",
																	children: (() => {
																		const filtered = workers.filter((w) => {
																			if (selectedCategoryFilter === "ALL") return true;
																			return (w.category || w.trade) === selectedCategoryFilter;
																		});
																		if (filtered.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																			colSpan: 8,
																			className: "p-8 text-center text-xs font-bold text-[#5B6B7F]",
																			children: "No employee attendance records found for the selected period."
																		}) });
																		return filtered.map((worker) => {
																			const recs = reportAttendanceRecords.filter((r) => r.workerId === worker.id);
																			let presentCount = 0;
																			let halfCount = 0;
																			let absentCount = 0;
																			let otCount = 0;
																			let totalWage = 0;
																			recs.forEach((r) => {
																				if (r.status === "Present") {
																					presentCount++;
																					totalWage += worker.dailyRate;
																				} else if (r.status === "HalfDay") {
																					halfCount++;
																					totalWage += Math.round(worker.dailyRate / 2);
																				} else if (r.status === "Absent") absentCount++;
																				else if (r.status === "Overtime") {
																					otCount++;
																					totalWage += Math.round(worker.dailyRate * 1.5);
																				}
																			});
																			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
																				className: "hover:bg-[#F8FAFF]",
																				children: [
																					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																						className: "p-4 font-black text-[#10233F]",
																						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																							className: "text-sm font-black",
																							children: worker.name
																						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																							className: "text-[10px] text-[#5B6B7F]",
																							children: ["📞 ", worker.mobile || "N/A"]
																						})]
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																						className: "p-4",
																						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
																							className: "bg-blue-50 text-[#063B78] border border-blue-200 font-extrabold text-[11px]",
																							children: formatCategoryName(worker.category || worker.trade)
																						})
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																						className: "p-4 font-black text-[#10233F]",
																						children: [
																							"₹",
																							worker.dailyRate,
																							" / day"
																						]
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																						className: "p-4 text-center font-black text-emerald-600 text-sm",
																						children: presentCount
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																						className: "p-4 text-center font-black text-amber-600 text-sm",
																						children: halfCount
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																						className: "p-4 text-center font-black text-rose-600 text-sm",
																						children: absentCount
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																						className: "p-4 text-center font-black text-blue-600 text-sm",
																						children: otCount
																					}),
																					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																						className: "p-4 text-right font-black text-emerald-700 text-base",
																						children: ["₹", totalWage.toLocaleString("en-IN")]
																					})
																				]
																			}, worker.id);
																		});
																	})()
																})]
															})
														})]
													})
												]
											}),
											attendanceSubView === "directory" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "rounded-2xl border border-[#DCE5F0] bg-white p-6 shadow-sm space-y-5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "flex items-center justify-between",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
														className: "text-lg font-black text-[#10233F] flex items-center gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "👥 Registered Employee Directory" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
															className: "bg-emerald-100 text-emerald-800 font-bold text-xs border border-emerald-300",
															children: [workers.length, " Employees Total"]
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-xs font-semibold text-[#5B6B7F] mt-1",
														children: "Manage department employees, custom daily wage rates, mobile contacts, and designations."
													})] })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "overflow-x-auto",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
														className: "w-full text-left border-collapse",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
															className: "border-b border-[#EBF1F8] bg-[#F8FAFF] text-[11px] uppercase tracking-wider text-[#5B6B7F] font-black",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																	className: "p-4 rounded-l-xl",
																	children: "Employee Name"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																	className: "p-4",
																	children: "Department / Category"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																	className: "p-4",
																	children: "Role / Designation"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																	className: "p-4",
																	children: "Mobile Number"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																	className: "p-4",
																	children: "Daily Wage Rate"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																	className: "p-4",
																	children: "Joining Date"
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
																	className: "p-4 text-center rounded-r-xl",
																	children: "Actions"
																})
															]
														}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
															className: "divide-y divide-[#EBF1F8] text-xs font-semibold",
															children: workers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																colSpan: 7,
																className: "p-8 text-center text-xs font-bold text-[#5B6B7F]",
																children: "No employees registered yet."
															}) }) : workers.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
																className: "hover:bg-[#F8FAFF]",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																		className: "p-4 font-black text-[#10233F]",
																		children: w.name
																	}),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																		className: "p-4",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
																			className: "bg-emerald-50 text-emerald-800 border border-emerald-200 font-extrabold text-[11px]",
																			children: formatCategoryName(w.category || w.trade)
																		})
																	}),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																		className: "p-4 font-bold text-[#063B78]",
																		children: w.trade
																	}),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																		className: "p-4 text-[#5B6B7F]",
																		children: w.mobile || "N/A"
																	}),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																		className: "p-4 font-black text-emerald-700",
																		children: [
																			"₹",
																			w.dailyRate,
																			" / day"
																		]
																	}),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																		className: "p-4 text-[#5B6B7F]",
																		children: w.joiningDate || "N/A"
																	}),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																		className: "p-4 text-center",
																		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																			className: "flex items-center justify-center gap-2",
																			children: [
																				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
																					variant: "outline",
																					size: "sm",
																					onClick: () => setSelectedWorkerReport(w),
																					className: "h-8 px-2.5 rounded-lg border-blue-200 bg-blue-50/50 hover:bg-blue-100 text-xs font-bold text-[#063B78]",
																					title: "View Report & Print Slip",
																					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-3.5 mr-1 text-[#063B78]" }), " Slip"]
																				}),
																				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
																					variant: "outline",
																					size: "sm",
																					onClick: () => handleOpenEditWorker(w),
																					className: "h-8 px-2.5 rounded-lg border-[#DCE5F0] text-xs font-bold text-[#063B78]",
																					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquarePen, { className: "size-3.5 mr-1" }), " Edit"]
																				}),
																				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
																					variant: "outline",
																					size: "sm",
																					onClick: () => handleDeleteWorker(w.id, w.name),
																					className: "h-8 px-2.5 rounded-lg border-rose-200 text-xs font-bold text-rose-600 hover:bg-rose-50",
																					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5 mr-1" }), " Delete"]
																				})
																			]
																		})
																	})
																]
															}, w.id))
														})]
													})
												})]
											})
										]
									})]
								});
							})()]
						})
					]
				})]
			}),
			showWorkerModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white w-full max-w-lg rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-100 relative max-h-[90vh] overflow-y-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setShowWorkerModal(false),
							className: "absolute top-5 right-5 text-slate-400 hover:text-slate-700 font-extrabold text-xl p-2 rounded-full hover:bg-slate-100",
							children: "✕"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 mb-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "p-3 rounded-2xl bg-emerald-50 text-emerald-700",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-6 text-emerald-600" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xl font-black text-[#10233F]",
								children: editingWorkerId ? "Edit Employee Information" : "Add New Employee"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-slate-500 font-semibold mt-0.5",
								children: "Enter employee details, select department, and assign custom daily wage rate."
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: handleSaveWorker,
							className: "space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs font-extrabold text-slate-700 uppercase mb-1 block",
									children: "Employee Name *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									required: true,
									placeholder: "e.g. Ramesh Pawar / Vijay Patil",
									value: workerForm.name,
									onChange: (e) => setWorkerForm((p) => ({
										...p,
										name: e.target.value
									})),
									className: "h-11 rounded-xl text-xs font-bold border-slate-300"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs font-extrabold text-slate-700 uppercase mb-1 block",
									children: "Department / Category *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: workerForm.category,
									onChange: (e) => setWorkerForm((p) => ({
										...p,
										category: e.target.value
									})),
									className: "w-full h-11 px-3 rounded-xl text-xs font-bold border border-slate-300 bg-white text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Plant Nursery & Care",
											children: "🌱 Plant Nursery & Care"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Tractor & Machinery",
											children: "🚜 Tractor & Machinery"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Grafting & Propagation",
											children: "✂️ Grafting & Propagation"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Packing & Loading",
											children: "📦 Packing & Loading"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Irrigation & Spraying",
											children: "💧 Irrigation & Spraying"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Soil & Fertilizer",
											children: "🌿 Soil & Fertilizer"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "General Labour",
											children: "🛠️ General Labour"
										})
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-xs font-extrabold text-slate-700 uppercase mb-1 block",
										children: "Role / Designation"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: "e.g. Tractor Driver / Grafting Specialist",
										value: workerForm.trade,
										onChange: (e) => setWorkerForm((p) => ({
											...p,
											trade: e.target.value
										})),
										className: "h-11 rounded-xl text-xs font-bold border-slate-300"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-xs font-extrabold text-slate-700 uppercase mb-1 block",
										children: "Mobile Number"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: "e.g. 9822112233",
										value: workerForm.mobile,
										onChange: (e) => setWorkerForm((p) => ({
											...p,
											mobile: e.target.value
										})),
										className: "h-11 rounded-xl text-xs font-bold border-slate-300"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-xs font-extrabold text-slate-700 uppercase mb-1 block",
										children: "Custom Daily Wage Rate (₹) *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										required: true,
										placeholder: "500",
										value: workerForm.dailyRate,
										onChange: (e) => setWorkerForm((p) => ({
											...p,
											dailyRate: e.target.value
										})),
										className: "h-11 rounded-xl text-xs font-bold border-slate-300 text-emerald-700"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-xs font-extrabold text-slate-700 uppercase mb-1 block",
										children: "Joining Date"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: workerForm.joiningDate,
										onChange: (e) => setWorkerForm((p) => ({
											...p,
											joiningDate: e.target.value
										})),
										className: "h-11 rounded-xl text-xs font-bold border-slate-300"
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-3 pt-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: "outline",
										onClick: () => setShowWorkerModal(false),
										className: "flex-1 py-5 rounded-xl font-bold border-slate-300 text-xs",
										children: "Cancel"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "submit",
										className: "flex-1 py-5 rounded-xl font-black bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg text-xs",
										children: editingWorkerId ? "Update Employee" : "Save Employee"
									})]
								})
							]
						})
					]
				})
			}),
			showPackageModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white w-full max-w-xl rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-100 relative max-h-[90vh] overflow-y-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setShowPackageModal(false),
							className: "absolute top-5 right-5 text-slate-400 hover:text-slate-700 font-extrabold text-xl p-2 rounded-full hover:bg-slate-100",
							children: "✕"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 mb-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "p-3 rounded-2xl bg-amber-50 text-[#063B78]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "size-6 text-amber-600" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xl font-black text-[#063B78]",
								children: "Activate Job Posting Package"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-slate-500 font-semibold",
								children: "You need an active job posting package to post new job listings."
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3 my-5",
							children: activeJobPackages.map((pkg) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								onClick: () => setSelectedPlanId(pkg.id),
								className: `p-4 rounded-2xl border-2 transition-all cursor-pointer flex items-center justify-between ${selectedPlanId === pkg.id ? "border-[#063B78] bg-blue-50/60 ring-2 ring-[#063B78]/20" : "border-slate-200 hover:border-slate-300 bg-white"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `size-5 rounded-full border-2 flex items-center justify-center ${selectedPlanId === pkg.id ? "border-[#063B78] bg-[#063B78] text-white" : "border-slate-300"}`,
										children: selectedPlanId === pkg.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3 stroke-[3]" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-extrabold text-sm text-[#063B78]",
											children: pkg.name
										}), pkg.badge && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `text-[10px] font-black px-2 py-0.5 rounded-full uppercase ${pkg.popular ? "bg-[#063B78] text-amber-300" : "bg-amber-100 text-amber-800"}`,
											children: pkg.badge
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-slate-500 font-medium mt-0.5",
										children: pkg.description || `${pkg.jobCount >= 999 ? "Unlimited Job Postings" : `${pkg.jobCount} Job Posting Credits`}`
									})] })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-right",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xl font-black text-[#063B78]",
										children: ["₹", pkg.price]
									})
								})]
							}, pkg.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-[#F4F7FB] p-4 rounded-2xl border border-[#DCE5F0] my-4 flex justify-between items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold text-slate-500",
								children: "Selected Plan"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-extrabold text-[#063B78]",
								children: activeSelectedPlan.name
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-bold text-slate-500",
									children: "Total Amount"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-2xl font-black text-emerald-700",
									children: ["₹", activeSelectedPlan.price]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 my-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs font-extrabold text-slate-700 uppercase tracking-wider",
									children: "Select Payment Method"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-3 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setPaymentMethod("upi"),
											className: `p-3 rounded-2xl border text-xs font-bold flex flex-col items-center gap-1.5 transition-all ${paymentMethod === "upi" ? "border-[#063B78] bg-blue-50/70 text-[#063B78] ring-2 ring-[#063B78]/20" : "border-slate-200 text-slate-600 hover:bg-slate-50"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "UPI / GPay" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setPaymentMethod("card"),
											className: `p-3 rounded-2xl border text-xs font-bold flex flex-col items-center gap-1.5 transition-all ${paymentMethod === "card" ? "border-[#063B78] bg-blue-50/70 text-[#063B78] ring-2 ring-[#063B78]/20" : "border-slate-200 text-slate-600 hover:bg-slate-50"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Debit / Card" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setPaymentMethod("netbanking"),
											className: `p-3 rounded-2xl border text-xs font-bold flex flex-col items-center gap-1.5 transition-all ${paymentMethod === "netbanking" ? "border-[#063B78] bg-blue-50/70 text-[#063B78] ring-2 ring-[#063B78]/20" : "border-slate-200 text-slate-600 hover:bg-slate-50"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "NetBanking" })]
										})
									]
								}),
								paymentMethod === "upi" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-xs font-bold text-slate-600 mb-1 block",
										children: "Enter UPI ID (or pay via PhonePe / GPay)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: "e.g. 9876543210@paytm",
										value: upiId,
										onChange: (e) => setUpiId(e.target.value),
										className: "h-11 rounded-xl text-sm font-semibold border-slate-300"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-3 pt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setShowPackageModal(false),
								className: "flex-1 py-6 rounded-2xl font-bold border-slate-300",
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								disabled: isProcessingPackage,
								onClick: handleActivatePackage,
								className: "flex-1 py-6 rounded-2xl font-black bg-[#063B78] hover:bg-[#082F63] text-white shadow-lg",
								children: isProcessingPackage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Activating..." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"Pay ₹",
									activeSelectedPlan.price,
									" & Post Job"
								] })
							})]
						})
					]
				})
			}),
			selectedWorkerReport && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white w-full max-w-2xl rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-100 relative max-h-[90vh] overflow-y-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setSelectedWorkerReport(null),
							className: "absolute top-5 right-5 text-slate-400 hover:text-slate-700 font-extrabold text-xl p-2 rounded-full hover:bg-slate-100",
							children: "✕"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-start justify-between border-b border-slate-100 pb-5 mb-5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-12 rounded-2xl bg-[#063B78] text-white font-black flex items-center justify-center text-xl shadow-md",
									children: selectedWorkerReport.name.slice(0, 1).toUpperCase()
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-xl font-black text-[#10233F]",
										children: selectedWorkerReport.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										className: "bg-emerald-50 text-emerald-800 border border-emerald-200 font-extrabold text-[10px]",
										children: formatCategoryName(selectedWorkerReport.category || selectedWorkerReport.trade)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-[#5B6B7F] font-semibold mt-0.5",
									children: [
										"📞 ",
										selectedWorkerReport.mobile || "N/A",
										" • Role: ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-bold text-[#063B78]",
											children: selectedWorkerReport.trade || "General Worker"
										}),
										" • Rate: ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-extrabold text-emerald-700",
											children: [
												"₹",
												selectedWorkerReport.dailyRate,
												" / day"
											]
										})
									]
								})] })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between bg-[#F8FAFF] p-3 rounded-2xl border border-[#DCE5F0] mb-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs font-black text-[#10233F] flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "size-4 text-[#063B78]" }), " Select Report Period:"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setWorkerReportPeriod("week"),
										className: `px-3 py-1.5 rounded-xl text-xs font-black transition-all ${workerReportPeriod === "week" ? "bg-[#063B78] text-white shadow-md" : "bg-white text-[#5B6B7F] border border-[#DCE5F0] hover:bg-slate-50"}`,
										children: "This Week"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setWorkerReportPeriod("month"),
										className: `px-3 py-1.5 rounded-xl text-xs font-black transition-all ${workerReportPeriod === "month" ? "bg-[#063B78] text-white shadow-md" : "bg-white text-[#5B6B7F] border border-[#DCE5F0] hover:bg-slate-50"}`,
										children: "This Month"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setWorkerReportPeriod("all"),
										className: `px-3 py-1.5 rounded-xl text-xs font-black transition-all ${workerReportPeriod === "all" ? "bg-[#063B78] text-white shadow-md" : "bg-white text-[#5B6B7F] border border-[#DCE5F0] hover:bg-slate-50"}`,
										children: "All Time"
									})
								]
							})]
						}),
						(() => {
							const metrics = getWorkerReportMetrics(selectedWorkerReport, workerReportPeriod);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 sm:grid-cols-5 gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-3.5 rounded-2xl border border-emerald-200 bg-emerald-50/60 text-center",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-[10px] font-black uppercase text-emerald-800",
													children: "Present"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
													className: "text-xl font-black text-emerald-700 mt-1",
													children: [metrics.present, " Days"]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-3.5 rounded-2xl border border-amber-200 bg-amber-50/60 text-center",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-[10px] font-black uppercase text-amber-800",
													children: "Half Day"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
													className: "text-xl font-black text-amber-700 mt-1",
													children: [metrics.halfDay, " Days"]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-3.5 rounded-2xl border border-rose-200 bg-rose-50/60 text-center",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-[10px] font-black uppercase text-rose-800",
													children: "Absent"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
													className: "text-xl font-black text-rose-700 mt-1",
													children: [metrics.absent, " Days"]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-3.5 rounded-2xl border border-blue-200 bg-blue-50/60 text-center",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-[10px] font-black uppercase text-blue-800",
													children: "Overtime"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
													className: "text-xl font-black text-blue-700 mt-1",
													children: [metrics.overtime, " Days"]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-3.5 rounded-2xl border border-emerald-300 bg-emerald-100/70 text-center col-span-2 sm:col-span-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-[10px] font-black uppercase text-emerald-900",
													children: "Total Wage"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
													className: "text-lg font-black text-emerald-800 mt-1",
													children: ["₹", metrics.netPay.toLocaleString("en-IN")]
												})]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "border border-[#DCE5F0] rounded-2xl overflow-hidden",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-[#F8FAFF] p-3 border-b border-[#DCE5F0] flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-xs font-black text-[#10233F]",
												children: [
													"📅 Attendance Log History (",
													metrics.records.length,
													" records)"
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[11px] font-bold text-[#5B6B7F]",
												children: [
													metrics.startDate,
													" to ",
													metrics.endDate
												]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "max-h-48 overflow-y-auto",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
												className: "w-full text-left border-collapse text-xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
													className: "border-b border-[#EBF1F8] bg-slate-50 text-[10px] uppercase font-black text-[#5B6B7F]",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "p-2.5",
															children: "Date"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "p-2.5",
															children: "Status"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "p-2.5",
															children: "Rate"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "p-2.5 text-right",
															children: "Earned Wage"
														})
													]
												}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
													className: "divide-y divide-[#EBF1F8] font-semibold",
													children: metrics.records.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														colSpan: 4,
														className: "p-4 text-center text-slate-400 font-bold",
														children: "No attendance records found for this timeframe."
													}) }) : metrics.records.map((r) => {
														let pay = selectedWorkerReport.dailyRate;
														if (r.status === "HalfDay") pay = Math.round(selectedWorkerReport.dailyRate / 2);
														if (r.status === "Absent") pay = 0;
														if (r.status === "Overtime") pay = Math.round(selectedWorkerReport.dailyRate * 1.5);
														return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
															className: "hover:bg-slate-50",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																	className: "p-2.5 font-bold text-[#10233F]",
																	children: r.date
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																	className: "p-2.5",
																	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																		className: `text-[10px] font-extrabold px-2 py-0.5 rounded-full ${r.status === "Present" ? "bg-emerald-100 text-emerald-800" : r.status === "HalfDay" ? "bg-amber-100 text-amber-800" : r.status === "Absent" ? "bg-rose-100 text-rose-800" : "bg-blue-100 text-blue-800"}`,
																		children: r.status
																	})
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																	className: "p-2.5 text-slate-500",
																	children: ["₹", selectedWorkerReport.dailyRate]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																	className: "p-2.5 text-right font-black text-emerald-700",
																	children: ["₹", pay]
																})
															]
														}, r.id);
													})
												})]
											})
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col sm:flex-row gap-3 pt-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											onClick: () => handleDownloadPDFSalarySlip(selectedWorkerReport, workerReportPeriod),
											className: "flex-1 bg-[#063B78] hover:bg-[#082F63] text-white font-extrabold text-xs py-5 rounded-xl shadow-md flex items-center justify-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), " Download PDF Salary Slip"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											variant: "outline",
											onClick: () => handleDownloadCSV(selectedWorkerReport, workerReportPeriod),
											className: "flex-1 border-[#DCE5F0] text-[#063B78] hover:bg-blue-50 font-extrabold text-xs py-5 rounded-xl flex items-center justify-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), " Export CSV Salary Data"]
										})]
									})
								]
							});
						})()
					]
				})
			})
		]
	});
}
//#endregion
export { AdminDashboardPage as component };
