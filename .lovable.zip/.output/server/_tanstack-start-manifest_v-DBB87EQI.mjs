//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DBB87EQI.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/job-portal-application-main/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/about",
			"/admin",
			"/auth",
			"/categories",
			"/contact",
			"/faq",
			"/home",
			"/reset-password",
			"/select-language",
			"/superadmin",
			"/company/$companyId",
			"/jobs/$jobId",
			"/workers/$workerId",
			"/jobs/",
			"/workers/"
		],
		preloads: [
			"/assets/index-eyGOZjXh.js",
			"/assets/useRouter-ByJ6_rwb.js",
			"/assets/react-dom-Dj2KXnwj.js",
			"/assets/useStore-C9WKQuax.js",
			"/assets/Match-C4nVjwi6.js",
			"/assets/redirect-1Dss4sOM.js",
			"/assets/link-BhBRKPSE.js",
			"/assets/matchContext-DiNYQDBD.js",
			"/assets/useMatch-CnYjb8nr.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-eyGOZjXh.js"
		} }]
	},
	"/": {
		filePath: "C:/job-portal-application-main/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-GDnJHbu6.js",
			"/assets/data-store-SgCA5PEj.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/createLucideIcon-CsVdBA7d.js",
			"/assets/arrow-right-DPAQbfZS.js",
			"/assets/chevron-right-C_Y6lLIw.js",
			"/assets/building-2-DQr5Ddk3.js",
			"/assets/eye-CALmIQFg.js",
			"/assets/wrench-DyNJIg6h.js",
			"/assets/hard-hat-DA-U_GEK.js",
			"/assets/PublicFooter-k72BcUK7.js",
			"/assets/shield-check-Cw8cdOJG.js",
			"/assets/sparkles-CI-MWGDW.js",
			"/assets/star-f2WFfXBm.js",
			"/assets/target-BbSZKkKt.js",
			"/assets/user-check-CDbemUnB.js",
			"/assets/users-BE4J0Cp3.js",
			"/assets/zap-bsku66l3.js",
			"/assets/Brand-6__CKiML.js",
			"/assets/career-team-DHTUSRpW.js"
		]
	},
	"/_authenticated": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/applications",
			"/_authenticated/control",
			"/_authenticated/dashboard",
			"/_authenticated/employer",
			"/_authenticated/messages",
			"/_authenticated/notifications",
			"/_authenticated/post-job",
			"/_authenticated/profile",
			"/_authenticated/salary"
		],
		preloads: ["/assets/route-D7Cm-cfc.js"]
	},
	"/about": {
		filePath: "C:/job-portal-application-main/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-BAQNP2mi.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/building-2-DQr5Ddk3.js",
			"/assets/circle-check-BnpwB6yf.js",
			"/assets/globe-CZc3mwTw.js",
			"/assets/hard-hat-DA-U_GEK.js",
			"/assets/heart-handshake-DXUBTw0d.js",
			"/assets/PublicFooter-k72BcUK7.js",
			"/assets/shield-check-Cw8cdOJG.js",
			"/assets/sparkles-CI-MWGDW.js",
			"/assets/target-BbSZKkKt.js",
			"/assets/zap-bsku66l3.js",
			"/assets/PublicHeader-Cq-bqeSX.js"
		]
	},
	"/admin": {
		filePath: "C:/job-portal-application-main/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-Dmgz6vXz.js",
			"/assets/data-store-SgCA5PEj.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/Stats-CVwebFVk.js",
			"/assets/createLucideIcon-CsVdBA7d.js",
			"/assets/chart-column-BT2mNQIc.js",
			"/assets/cloud-upload-B6XmmKG1.js",
			"/assets/file-text-DKDA1dEy.js",
			"/assets/search-C1E8x3i6.js",
			"/assets/shield-check-Cw8cdOJG.js",
			"/assets/users-BE4J0Cp3.js",
			"/assets/badge-BtmmBMmV.js",
			"/assets/input-B4Rpl8PA.js"
		]
	},
	"/auth": {
		filePath: "C:/job-portal-application-main/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-C1QJq_Yu.js",
			"/assets/data-store-SgCA5PEj.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/createLucideIcon-CsVdBA7d.js",
			"/assets/arrow-left-ChZkzOU7.js",
			"/assets/building-2-DQr5Ddk3.js",
			"/assets/eye-CALmIQFg.js",
			"/assets/mail-C2LeSom6.js",
			"/assets/phone-CktyGyUQ.js",
			"/assets/user-plus-B_NQRjz_.js",
			"/assets/user-tafbVLLs.js",
			"/assets/Brand-6__CKiML.js",
			"/assets/label-BANuCaFW.js"
		]
	},
	"/categories": {
		filePath: "C:/job-portal-application-main/src/routes/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-DRt6XoLM.js",
			"/assets/createLucideIcon-CsVdBA7d.js",
			"/assets/arrow-right-DPAQbfZS.js",
			"/assets/building-2-DQr5Ddk3.js",
			"/assets/wrench-DyNJIg6h.js",
			"/assets/stethoscope-BftPQllm.js",
			"/assets/hard-hat-DA-U_GEK.js",
			"/assets/headphones-X3T6kA1J.js",
			"/assets/PublicFooter-k72BcUK7.js",
			"/assets/search-C1E8x3i6.js",
			"/assets/sparkles-CI-MWGDW.js",
			"/assets/trending-up-DvnCZqWu.js",
			"/assets/user-plus-B_NQRjz_.js",
			"/assets/input-B4Rpl8PA.js",
			"/assets/PublicHeader-Cq-bqeSX.js"
		]
	},
	"/contact": {
		filePath: "C:/job-portal-application-main/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-D5Q0pALU.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/building-2-DQr5Ddk3.js",
			"/assets/circle-check-BnpwB6yf.js",
			"/assets/PublicFooter-k72BcUK7.js",
			"/assets/mail-C2LeSom6.js",
			"/assets/map-pin-CtZps3Ax.js",
			"/assets/message-square-BFODkOXb.js",
			"/assets/phone-CktyGyUQ.js",
			"/assets/sparkles-CI-MWGDW.js",
			"/assets/input-B4Rpl8PA.js",
			"/assets/PublicHeader-Cq-bqeSX.js"
		]
	},
	"/faq": {
		filePath: "C:/job-portal-application-main/src/routes/faq.tsx",
		children: void 0,
		preloads: [
			"/assets/faq-DCZesjqe.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/createLucideIcon-CsVdBA7d.js",
			"/assets/chevron-right-C_Y6lLIw.js",
			"/assets/building-2-DQr5Ddk3.js",
			"/assets/chevron-down-DAPNKV-Z.js",
			"/assets/hard-hat-DA-U_GEK.js",
			"/assets/PublicFooter-k72BcUK7.js",
			"/assets/message-square-BFODkOXb.js",
			"/assets/search-C1E8x3i6.js",
			"/assets/user-check-CDbemUnB.js",
			"/assets/input-B4Rpl8PA.js",
			"/assets/PublicHeader-Cq-bqeSX.js"
		]
	},
	"/home": {
		filePath: "C:/job-portal-application-main/src/routes/home.tsx",
		children: void 0,
		preloads: [
			"/assets/home-MT4q8abx.js",
			"/assets/data-store-SgCA5PEj.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/createLucideIcon-CsVdBA7d.js",
			"/assets/arrow-right-DPAQbfZS.js",
			"/assets/bookmark-DPTMYqi7.js",
			"/assets/chevron-right-C_Y6lLIw.js",
			"/assets/building-2-DQr5Ddk3.js",
			"/assets/circle-check-BnpwB6yf.js",
			"/assets/clock-3-BxoOEZGN.js",
			"/assets/globe-CZc3mwTw.js",
			"/assets/stethoscope-BftPQllm.js",
			"/assets/heart-handshake-DXUBTw0d.js",
			"/assets/PublicFooter-k72BcUK7.js",
			"/assets/PopularCategories-BePqLagH.js",
			"/assets/map-pin-CtZps3Ax.js",
			"/assets/WorkerCard-Dugxtizo.js",
			"/assets/search-C1E8x3i6.js",
			"/assets/shield-check-Cw8cdOJG.js",
			"/assets/sparkles-CI-MWGDW.js",
			"/assets/users-BE4J0Cp3.js",
			"/assets/wallet-CgSiQ_Ja.js",
			"/assets/zap-bsku66l3.js",
			"/assets/input-B4Rpl8PA.js",
			"/assets/PublicHeader-Cq-bqeSX.js",
			"/assets/career-team-DHTUSRpW.js"
		]
	},
	"/reset-password": {
		filePath: "C:/job-portal-application-main/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-klXJKlbv.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/Brand-6__CKiML.js",
			"/assets/input-B4Rpl8PA.js",
			"/assets/label-BANuCaFW.js"
		]
	},
	"/select-language": {
		filePath: "C:/job-portal-application-main/src/routes/select-language.tsx",
		children: void 0,
		preloads: [
			"/assets/select-language-D1m1KkHY.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/check-BX888YMt.js",
			"/assets/Brand-6__CKiML.js"
		]
	},
	"/superadmin": {
		filePath: "C:/job-portal-application-main/src/routes/superadmin.tsx",
		children: void 0,
		preloads: [
			"/assets/superadmin-J39YQOHT.js",
			"/assets/data-store-SgCA5PEj.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/createLucideIcon-CsVdBA7d.js",
			"/assets/LanguageSwitcher-x-LktjEc.js",
			"/assets/chevron-right-C_Y6lLIw.js",
			"/assets/building-2-DQr5Ddk3.js",
			"/assets/chart-column-BT2mNQIc.js",
			"/assets/check-BX888YMt.js",
			"/assets/chevron-down-DAPNKV-Z.js",
			"/assets/chevron-up-CiLbxvMF.js",
			"/assets/circle-check-BnpwB6yf.js",
			"/assets/eye-CALmIQFg.js",
			"/assets/file-text-DKDA1dEy.js",
			"/assets/globe-CZc3mwTw.js",
			"/assets/x-DUEMxRUa.js",
			"/assets/mail-C2LeSom6.js",
			"/assets/map-pin-CtZps3Ax.js",
			"/assets/phone-CktyGyUQ.js",
			"/assets/search-C1E8x3i6.js",
			"/assets/user-check-CDbemUnB.js",
			"/assets/users-BE4J0Cp3.js"
		]
	},
	"/_authenticated/applications": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/applications.tsx",
		children: void 0,
		preloads: ["/assets/applications-DBZD_vAl.js", "/assets/Dashboards-CEiX79QD.js"]
	},
	"/_authenticated/control": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.tsx",
		children: [
			"/_authenticated/control/employers",
			"/_authenticated/control/jobs",
			"/_authenticated/control/languages",
			"/_authenticated/control/reports",
			"/_authenticated/control/salary",
			"/_authenticated/control/settings",
			"/_authenticated/control/users"
		],
		preloads: ["/assets/control-BOUWrawf.js", "/assets/Dashboards-CEiX79QD.js"]
	},
	"/_authenticated/dashboard": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/dashboard.tsx",
		children: void 0,
		preloads: ["/assets/dashboard-oKMLry_U.js", "/assets/Dashboards-CEiX79QD.js"]
	},
	"/_authenticated/employer": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.tsx",
		children: [
			"/_authenticated/employer/applicants",
			"/_authenticated/employer/employees",
			"/_authenticated/employer/jobs",
			"/_authenticated/employer/reports",
			"/_authenticated/employer/salary"
		],
		preloads: ["/assets/employer-BsWuy9vD.js", "/assets/Dashboards-CEiX79QD.js"]
	},
	"/_authenticated/messages": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/messages.tsx",
		children: void 0,
		preloads: [
			"/assets/messages-U1zDTW_9.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/badge-check-DCNAjMju.js",
			"/assets/PublicFooter-k72BcUK7.js",
			"/assets/phone-CktyGyUQ.js",
			"/assets/search-C1E8x3i6.js",
			"/assets/send-CUUtR4KF.js",
			"/assets/input-B4Rpl8PA.js",
			"/assets/PublicHeader-Cq-bqeSX.js"
		]
	},
	"/_authenticated/notifications": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/notifications.tsx",
		children: void 0,
		preloads: ["/assets/notifications-CXDeJqar.js", "/assets/Dashboards-CEiX79QD.js"]
	},
	"/_authenticated/post-job": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/post-job.tsx",
		children: void 0,
		preloads: [
			"/assets/post-job-CnAEaYn0.js",
			"/assets/data-store-SgCA5PEj.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/createLucideIcon-CsVdBA7d.js",
			"/assets/chevron-right-C_Y6lLIw.js",
			"/assets/building-2-DQr5Ddk3.js",
			"/assets/eye-CALmIQFg.js",
			"/assets/file-text-DKDA1dEy.js",
			"/assets/PublicFooter-k72BcUK7.js",
			"/assets/x-DUEMxRUa.js",
			"/assets/send-CUUtR4KF.js",
			"/assets/wallet-CgSiQ_Ja.js",
			"/assets/badge-BtmmBMmV.js",
			"/assets/input-B4Rpl8PA.js",
			"/assets/PublicHeader-Cq-bqeSX.js"
		]
	},
	"/_authenticated/profile": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/profile.tsx",
		children: void 0,
		preloads: ["/assets/profile-DMpMhzS6.js", "/assets/Dashboards-CEiX79QD.js"]
	},
	"/_authenticated/salary": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/salary.tsx",
		children: void 0,
		preloads: ["/assets/salary-BdtU931E.js", "/assets/Dashboards-CEiX79QD.js"]
	},
	"/company/$companyId": {
		filePath: "C:/job-portal-application-main/src/routes/company.$companyId.tsx",
		children: void 0,
		preloads: [
			"/assets/company._companyId-CFP78ual.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/arrow-left-ChZkzOU7.js",
			"/assets/JobCard-D2ZAgk6t.js",
			"/assets/chevron-right-C_Y6lLIw.js",
			"/assets/building-2-DQr5Ddk3.js",
			"/assets/circle-check-BnpwB6yf.js",
			"/assets/PublicFooter-k72BcUK7.js",
			"/assets/map-pin-CtZps3Ax.js",
			"/assets/share-2-JvliyL4B.js",
			"/assets/shield-check-Cw8cdOJG.js",
			"/assets/star-f2WFfXBm.js",
			"/assets/users-BE4J0Cp3.js",
			"/assets/PublicHeader-Cq-bqeSX.js"
		]
	},
	"/jobs/$jobId": {
		filePath: "C:/job-portal-application-main/src/routes/jobs.$jobId.tsx",
		children: void 0,
		preloads: [
			"/assets/jobs._jobId-DM_c9e7U.js",
			"/assets/data-store-SgCA5PEj.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/createLucideIcon-CsVdBA7d.js",
			"/assets/arrow-left-ChZkzOU7.js",
			"/assets/JobCard-D2ZAgk6t.js",
			"/assets/bookmark-DPTMYqi7.js",
			"/assets/chevron-right-C_Y6lLIw.js",
			"/assets/building-2-DQr5Ddk3.js",
			"/assets/circle-check-BnpwB6yf.js",
			"/assets/clock-3-BxoOEZGN.js",
			"/assets/PublicFooter-k72BcUK7.js",
			"/assets/x-DUEMxRUa.js",
			"/assets/map-pin-CtZps3Ax.js",
			"/assets/send-CUUtR4KF.js",
			"/assets/share-2-JvliyL4B.js",
			"/assets/user-tafbVLLs.js",
			"/assets/wallet-CgSiQ_Ja.js",
			"/assets/badge-BtmmBMmV.js",
			"/assets/PublicHeader-Cq-bqeSX.js"
		]
	},
	"/workers/$workerId": {
		filePath: "C:/job-portal-application-main/src/routes/workers.$workerId.tsx",
		children: void 0,
		preloads: [
			"/assets/workers._workerId-BDVnSyWM.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/badge-check-DCNAjMju.js",
			"/assets/circle-check-BnpwB6yf.js",
			"/assets/PublicFooter-k72BcUK7.js",
			"/assets/x-DUEMxRUa.js",
			"/assets/map-pin-CtZps3Ax.js",
			"/assets/WorkerCard-Dugxtizo.js",
			"/assets/share-2-JvliyL4B.js",
			"/assets/user-tafbVLLs.js",
			"/assets/badge-BtmmBMmV.js",
			"/assets/PublicHeader-Cq-bqeSX.js"
		]
	},
	"/jobs/": {
		filePath: "C:/job-portal-application-main/src/routes/jobs.index.tsx",
		children: void 0,
		preloads: [
			"/assets/jobs.index-CyG6W7I0.js",
			"/assets/data-store-SgCA5PEj.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/createLucideIcon-CsVdBA7d.js",
			"/assets/arrow-left-ChZkzOU7.js",
			"/assets/JobCard-D2ZAgk6t.js",
			"/assets/chevron-right-C_Y6lLIw.js",
			"/assets/wrench-DyNJIg6h.js",
			"/assets/sliders-horizontal-1oc-Rsfl.js",
			"/assets/stethoscope-BftPQllm.js",
			"/assets/hard-hat-DA-U_GEK.js",
			"/assets/headphones-X3T6kA1J.js",
			"/assets/PublicFooter-k72BcUK7.js",
			"/assets/PopularCategories-BePqLagH.js",
			"/assets/x-DUEMxRUa.js",
			"/assets/map-pin-CtZps3Ax.js",
			"/assets/search-C1E8x3i6.js",
			"/assets/shield-check-Cw8cdOJG.js",
			"/assets/user-check-CDbemUnB.js",
			"/assets/users-BE4J0Cp3.js",
			"/assets/zap-bsku66l3.js",
			"/assets/input-B4Rpl8PA.js",
			"/assets/PublicHeader-Cq-bqeSX.js"
		]
	},
	"/workers/": {
		filePath: "C:/job-portal-application-main/src/routes/workers.index.tsx",
		children: void 0,
		preloads: [
			"/assets/workers.index-BrDuWDHA.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/badge-check-DCNAjMju.js",
			"/assets/sliders-horizontal-1oc-Rsfl.js",
			"/assets/PublicFooter-k72BcUK7.js",
			"/assets/x-DUEMxRUa.js",
			"/assets/map-pin-CtZps3Ax.js",
			"/assets/WorkerCard-Dugxtizo.js",
			"/assets/search-C1E8x3i6.js",
			"/assets/users-BE4J0Cp3.js",
			"/assets/badge-BtmmBMmV.js",
			"/assets/input-B4Rpl8PA.js",
			"/assets/PublicHeader-Cq-bqeSX.js"
		]
	},
	"/_authenticated/control/employers": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.employers.tsx",
		children: void 0,
		preloads: ["/assets/control.employers-B9PT02PF.js"]
	},
	"/_authenticated/control/jobs": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.jobs.tsx",
		children: void 0,
		preloads: ["/assets/control.jobs-dpDmBtHs.js"]
	},
	"/_authenticated/control/languages": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.languages.tsx",
		children: void 0,
		preloads: ["/assets/control.languages-BnVuExuD.js"]
	},
	"/_authenticated/control/reports": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.reports.tsx",
		children: void 0,
		preloads: ["/assets/control.reports-DPU5XP7N.js"]
	},
	"/_authenticated/control/salary": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.salary.tsx",
		children: void 0,
		preloads: ["/assets/control.salary-DGY8ev7V.js"]
	},
	"/_authenticated/control/settings": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.settings.tsx",
		children: void 0,
		preloads: ["/assets/control.settings-BNxAOGTE.js"]
	},
	"/_authenticated/control/users": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.users.tsx",
		children: void 0,
		preloads: ["/assets/control.users-GM7SvQS5.js"]
	},
	"/_authenticated/employer/applicants": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.applicants.tsx",
		children: void 0,
		preloads: ["/assets/employer.applicants-Dd9II3Uc.js"]
	},
	"/_authenticated/employer/employees": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.employees.tsx",
		children: void 0,
		preloads: ["/assets/employer.employees-nHomZnlr.js"]
	},
	"/_authenticated/employer/jobs": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.jobs.tsx",
		children: void 0,
		preloads: ["/assets/employer.jobs-kJJT3M1t.js"]
	},
	"/_authenticated/employer/reports": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.reports.tsx",
		children: void 0,
		preloads: ["/assets/employer.reports-BeFt0Unc.js"]
	},
	"/_authenticated/employer/salary": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.salary.tsx",
		children: void 0,
		preloads: ["/assets/employer.salary-URmaSJ_e.js"]
	}
} });
//#endregion
export { tsrStartManifest };
