import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n } from "./i18n-BlIP7F54.mjs";
import { t as dataStore } from "./data-store-CPuK80w4.mjs";
import { t as Button } from "./button-KWVQ7n-R.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as ShieldCheck, X as LogOut, Y as Mail, c as User, in as Briefcase, it as LayoutDashboard, lt as Info, n as X, q as Menu, u as UserRound } from "../_libs/lucide-react.mjs";
import { t as LoginDropdown } from "./PublicFooter-DFRUWOC-.mjs";
import { t as Brand } from "./Brand-CcASrIw4.mjs";
import { t as LanguageSwitcher } from "./LanguageSwitcher-DB70GxGK.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/PublicHeader-CcH6UzCG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PublicHeader() {
	const { t } = useI18n();
	const [mobileMenuOpen, setMobileMenuOpen] = (0, import_react.useState)(false);
	const [user, setUser] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (typeof window === "undefined") return;
		const checkUser = () => {
			setUser(dataStore.getCurrentUser());
		};
		checkUser();
		window.addEventListener("storage", checkUser);
		window.addEventListener("realjob-auth-change", checkUser);
		return () => {
			window.removeEventListener("storage", checkUser);
			window.removeEventListener("realjob-auth-change", checkUser);
		};
	}, []);
	const handleLogout = () => {
		dataStore.logout();
		setUser(null);
		toast.info("Logged out successfully!");
		if (typeof window !== "undefined") window.location.replace("/");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-50 border-b border-[#DCE5F0] bg-white/95 backdrop-blur-md shadow-xs",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-18 max-w-7xl items-center justify-between px-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, { className: "h-10 sm:h-12 md:h-14 shrink-0" }),
				!user && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "hidden items-center gap-6 xl:gap-8 lg:flex",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "nav-link text-sm font-bold hover:text-[#063B78] transition-colors",
							children: t("home")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/jobs",
							className: "nav-link text-sm font-bold hover:text-[#063B78] transition-colors",
							children: t("jobs")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/about",
							className: "nav-link text-sm font-bold hover:text-[#063B78] transition-colors",
							children: t("aboutUs")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/contact",
							className: "nav-link text-sm font-bold hover:text-[#063B78] transition-colors",
							children: t("contactUs")
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 sm:gap-2.5 shrink-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageSwitcher, {}),
						user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#EBF1F8] border border-[#B8D3F2] text-xs font-black text-[#063B78]",
									children: [user.profilePhoto ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: user.profilePhoto,
										alt: user.fullName || "User",
										className: "size-5 rounded-full object-cover ring-1 ring-[#063B78]"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-3.5 text-[#063B78]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: user.fullName || user.email?.split("@")[0] || "User" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									size: "sm",
									className: "bg-[#063B78] hover:bg-[#082F63] text-white font-extrabold text-xs h-9 px-3 rounded-lg shadow-xs",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: user.role === "admin" || user.role === "employer" ? "/admin" : "/dashboard",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "size-3.5 mr-1" }), "Dashboard"]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: handleLogout,
									size: "sm",
									className: "bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs h-9 px-3 rounded-lg shadow-xs flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Logout" })]
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoginDropdown, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							className: "lg:hidden text-[#063B78]",
							onClick: () => setMobileMenuOpen(!mobileMenuOpen),
							"aria-label": "Toggle Navigation Menu",
							children: mobileMenuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-6" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-6" })
						})
					]
				})
			]
		}), mobileMenuOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 top-20 z-50 bg-[#082F63]/50 backdrop-blur-sm lg:hidden animate-fade-in",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white border-b border-[#DCE5F0] p-6 shadow-xl space-y-4 max-h-[calc(100vh-5rem)] overflow-y-auto",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center justify-between pb-4 border-b border-[#DCE5F0]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-bold uppercase tracking-wider text-[#5B6B7F]",
							children: "Navigation"
						})
					}),
					user && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 p-3 rounded-xl bg-[#EBF1F8] border border-[#B8D3F2] text-xs font-black text-[#063B78]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-4 text-[#063B78]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Logged in as: ", user.fullName || user.email] })]
					}),
					!user && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "grid gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/",
								onClick: () => setMobileMenuOpen(false),
								className: "flex items-center gap-3 rounded-lg px-3 py-2.5 font-bold text-[#10233F] hover:bg-[#F5F8FC]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-5 text-[#063B78]" }), t("home")]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/jobs",
								onClick: () => setMobileMenuOpen(false),
								className: "flex items-center gap-3 rounded-lg px-3 py-2.5 font-bold text-[#10233F] hover:bg-[#F5F8FC]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-5 text-[#125BB5]" }), t("jobs")]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/about",
								onClick: () => setMobileMenuOpen(false),
								className: "flex items-center gap-3 rounded-lg px-3 py-2.5 font-bold text-[#10233F] hover:bg-[#F5F8FC]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-5 text-[#125BB5]" }), t("aboutUs")]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/contact",
								onClick: () => setMobileMenuOpen(false),
								className: "flex items-center gap-3 rounded-lg px-3 py-2.5 font-bold text-[#10233F] hover:bg-[#F5F8FC]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-5 text-[#063B78]" }), t("contactUs")]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pt-4 border-t border-[#DCE5F0]",
						children: user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `grid ${user.role === "worker" ? "grid-cols-1" : "grid-cols-2"} gap-2.5`,
							children: [user.role !== "worker" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								className: "w-full bg-[#063B78] text-white font-extrabold text-xs",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: user.role === "admin" ? "/admin" : "/employer",
									onClick: () => setMobileMenuOpen(false),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "size-3.5 mr-1" }), "Dashboard"]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => {
									setMobileMenuOpen(false);
									handleLogout();
								},
								className: "w-full bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-3.5 mr-1" }), "Logout"]
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									variant: "outline",
									className: "w-full justify-start border-[#063B78] text-[#063B78] font-extrabold text-xs h-10 px-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/auth",
										search: {
											mode: "login",
											role: "worker"
										},
										onClick: () => setMobileMenuOpen(false),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "size-4 mr-2" }), t("seekerLogin")]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									variant: "outline",
									className: "w-full justify-start border-emerald-600 text-emerald-700 font-extrabold text-xs h-10 px-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/auth",
										search: {
											mode: "login",
											role: "employee"
										},
										onClick: () => setMobileMenuOpen(false),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4 mr-2" }), t("employeeLogin")]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									className: "w-full justify-start bg-[#063B78] hover:bg-[#082F63] text-white font-extrabold text-xs h-10 px-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/auth",
										search: {
											mode: "login",
											role: "admin"
										},
										onClick: () => setMobileMenuOpen(false),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 mr-2 text-[#FFC400]" }), t("adminLogin")]
									})
								})
							]
						})
					})
				]
			})
		})]
	});
}
//#endregion
export { PublicHeader as t };
