import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n } from "./i18n-BlIP7F54.mjs";
import { t as dataStore } from "./data-store-CPuK80w4.mjs";
import { a as isVideoMedia, i as getYouTubeEmbedUrl, t as Button } from "./button-KWVQ7n-R.mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as ShieldCheck, Dt as Factory, E as Shield, Ft as Crown, G as Monitor, M as Search, Ot as Eye, S as Sparkles, Wt as CircleCheck, _ as Target, dn as Award, f as UserCheck, h as TrendingUp, in as Briefcase, m as Truck, mt as Heart, r as Wrench, rn as Building2, s as Users, t as Zap, vt as HardHat, y as Star, yt as Handshake } from "../_libs/lucide-react.mjs";
import { n as PublicFooter, t as LoginDropdown } from "./PublicFooter-DFRUWOC-.mjs";
import { t as Brand } from "./Brand-CcASrIw4.mjs";
import { t as LanguageSwitcher } from "./LanguageSwitcher-DB70GxGK.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as LanguageGate } from "./LanguageGate-BeZTs2_4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C94rOtVJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var career_team_default = "/assets/career-team-CL7SHC2o.jpg";
var CATEGORY_TRANSLATIONS = {
	construction: {
		mr: "बांधकाम (Construction)",
		en: "Construction",
		hi: "निर्माण कार्य (Construction)",
		gu: "બાંધકામ (Construction)",
		kn: "ಕಟ್ಟಡ ನಿರ್ಮಾಣ (Construction)",
		te: "నిర్మాణ రంగం (Construction)",
		ta: "கட்டுமானம் (Construction)",
		bn: "নির্মাণ কাজ (Construction)"
	},
	technical: {
		mr: "तांत्रिक कर्मचारी (Technical)",
		en: "Technical Staff",
		hi: "तकनीकी कर्मचारी (Technical Staff)",
		gu: "ટેકનિકલ સ્ટાફ (Technical Staff)",
		kn: "ತಾಂತ್ರಿಕ ಸಿಬ್ಬಂದಿ (Technical Staff)",
		te: "సాంకేతిక సిబ్బంది (Technical Staff)",
		ta: "தொழில்நுட்ப பணியாளர்கள் (Technical)",
		bn: "প্রযুক্তিগত কর্মী (Technical Staff)"
	},
	logistics: {
		mr: "वाहतूक आणि लॉजिस्टिक्स (Logistics)",
		en: "Transport & Logistics",
		hi: "परिवहन और रसद (Logistics)",
		gu: "પરિવહન અને લોજિસ્ટિક્સ (Logistics)",
		kn: "ಸಾರಿಗೆ ಮತ್ತು ಲಾಜಿಸ್ಟಿಕ್ಸ್ (Logistics)",
		te: "రవాణా & లాజిస్టిక్స్ (Logistics)",
		ta: "போக்குவரத்து & தளவாடங்கள் (Logistics)",
		bn: "পরিবহন ও লজিস্টিকস (Logistics)"
	},
	electrician: {
		mr: "इलेक्ट्रिशियन (Electrician)",
		en: "Electrician",
		hi: "इलेक्ट्रीशियन (Electrician)",
		gu: "ઇલેક્ટ્રિશિયન (Electrician)",
		kn: "ಎಲೆಕ್ಟ್ರಿಷಿಯನ್ (Electrician)",
		te: "ఎలక్ట్రీషియన్ (Electrician)",
		ta: "எலக்ட்ரீஷியன் (Electrician)",
		bn: "ইলেকট্রিশিয়ান (Electrician)"
	},
	office: {
		mr: "कार्यालयीन कर्मचारी (Office Staff)",
		en: "Office Staff",
		hi: "कार्यालय स्टाफ (Office Staff)",
		gu: "ઓફિસ સ્ટાફ (Office Staff)",
		kn: "ಕಚೇರಿ ಸಿಬ್ಬಂದಿ (Office Staff)",
		te: "కార్యాలయ సిబ్బంది (Office Staff)",
		ta: "அலுவலக பணியாளர்கள் (Office Staff)",
		bn: "অফিস কর্মী (Office Staff)"
	},
	factory: {
		mr: "कारखाना कामगार (Factory Worker)",
		en: "Factory Worker",
		hi: "फैक्ट्री कर्मचारी (Factory Worker)",
		gu: "ફેક્ટરી વર્કર (Factory Worker)",
		kn: "ಕಾರ್ಖಾನೆ ಕೆಲಸಗಾರ (Factory Worker)",
		te: "ఫ్యాక్టరీ కార్మికుడు (Factory Worker)",
		ta: "தொழிற்சாலை பணியாளர் (Factory)",
		bn: "কারখানার শ্রমিক (Factory Worker)"
	},
	security: {
		mr: "सुरक्षा रक्षक (Security Guard)",
		en: "Security Guard",
		hi: "सुरक्षा गार्ड (Security Guard)",
		gu: "સિક્યુરિટી ગાર્ડ (Security Guard)",
		kn: "ಭದ್ರತಾ ಸಿಬ್ಬಂದಿ (Security Guard)",
		te: "సెక్యూరిటీ గార్డు (Security Guard)",
		ta: "பாதுகாப்பு காவலர் (Security Guard)",
		bn: "নিরাপত্তা প্রহরী (Security Guard)"
	},
	driver: {
		mr: "ड्रायव्हर / चालक (Driver)",
		en: "Driver",
		hi: "चालक / ड्राइवर (Driver)",
		gu: "ડ્રાઈવર (Driver)",
		kn: "ಚಾಲಕ (Driver)",
		te: "డ్రైవర్ (Driver)",
		ta: "ஓட்டுநர் (Driver)",
		bn: "চালক / ড্রাইভার (Driver)"
	}
};
var ICONS = {
	Factory,
	HardHat,
	Wrench,
	Truck,
	Zap,
	Shield,
	Briefcase,
	Users,
	Monitor,
	Building2,
	Search,
	Target,
	Award,
	Star,
	Heart,
	Crown,
	Sparkles,
	TrendingUp,
	CheckCircle2: CircleCheck
};
var heroImages = [
	"https://firebasestorage.googleapis.com/v0/b/job-portal-729b6.firebasestorage.app/o/hero_media%2F1792129049561_hero_video.mp4?alt=media&token=9b136576-8f2e-4144-8f75-532783dec98b",
	career_team_default,
	"https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80",
	"https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&q=80",
	"https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&q=80"
];
var defaultCompanyPillars = [
	{
		id: "mission",
		title: "Our Mission",
		titleMr: "आमचे ध्येय",
		description: "To provide the right employment opportunity to everyone.",
		descriptionMr: "प्रत्येकाला रोजगाराची योग्य संधी मिळवून देणे.",
		iconName: "Target"
	},
	{
		id: "vision",
		title: "Our Vision",
		titleMr: "आमचे व्हिजन",
		description: "To become the most trusted employment portal in India.",
		descriptionMr: "भारतातील सर्वात विश्वासार्ह रोजगार मंच बनणे.",
		iconName: "Eye"
	},
	{
		id: "values",
		title: "Our Values",
		titleMr: "आमची मूल्ये",
		description: "Trust, transparency, quality, and consistent service.",
		descriptionMr: "विश्वास, पारदर्शकता, गुणवत्ता आणि निरंतर सेवा.",
		iconName: "Users"
	},
	{
		id: "belief",
		title: "Our Belief",
		titleMr: "आमचा विश्वास",
		description: "Right Person\nRight Job\nRight Opportunity",
		descriptionMr: "योग्य व्यक्ती\nयोग्य काम\nयोग्य संधी",
		iconName: "Handshake"
	}
];
var PILLAR_ICONS = {
	Target,
	Eye,
	Users,
	Handshake,
	Star,
	Shield,
	Sparkles,
	TrendingUp,
	Building2,
	Award,
	CheckCircle2: CircleCheck,
	Heart,
	Crown
};
function LandingGatewayPage() {
	const { t, lang } = useI18n();
	const navigate = useNavigate();
	const [currentImageIndex, setCurrentImageIndex] = (0, import_react.useState)(0);
	const [heroTitle, setHeroTitle] = (0, import_react.useState)("Welcome to the\nREAL JOB Portal!");
	const [heroSubtitle, setHeroSubtitle] = (0, import_react.useState)("Right Person • Right Job • Right Opportunity");
	const [images, setImages] = (0, import_react.useState)(heroImages);
	const [metrics, setMetrics] = (0, import_react.useState)([
		{
			value: "10,000+",
			label: "Verified Workers"
		},
		{
			value: "5,000+",
			label: "Live Job Openings"
		},
		{
			value: "2,200+",
			label: "Employers"
		},
		{
			value: "0%",
			label: "Zero Commission"
		}
	]);
	const [aboutData, setAboutData] = (0, import_react.useState)({
		image: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&q=80",
		title: "About Our Company",
		description: "REAL JOB is a reliable employment portal that connects job seekers with trusted companies. We focus on creating real opportunities, building successful careers, and supporting growth for individuals and businesses across India."
	});
	const [companyPillars, setCompanyPillars] = (0, import_react.useState)(defaultCompanyPillars);
	const [categories, setCategories] = (0, import_react.useState)([
		{
			id: "construction",
			label: "Construction",
			jobsCount: "1.5K+ Jobs",
			iconName: "HardHat",
			gradient: "from-amber-500/15 via-amber-400/5 to-transparent",
			iconBg: "bg-amber-100 text-amber-700 group-hover:bg-amber-500 group-hover:text-white",
			hoverBorder: "group-hover:border-amber-400",
			badgeStyle: "bg-amber-50 text-amber-700 border-amber-200",
			btnStyle: "bg-amber-100 text-amber-700 group-hover:bg-amber-500 group-hover:text-white"
		},
		{
			id: "technical",
			label: "Technical Staff",
			jobsCount: "2.8K+ Jobs",
			iconName: "Wrench",
			gradient: "from-blue-500/15 via-blue-400/5 to-transparent",
			iconBg: "bg-blue-100 text-blue-700 group-hover:bg-blue-600 group-hover:text-white",
			hoverBorder: "group-hover:border-blue-400",
			badgeStyle: "bg-blue-50 text-blue-700 border-blue-200",
			btnStyle: "bg-blue-100 text-blue-700 group-hover:bg-blue-600 group-hover:text-white"
		},
		{
			id: "logistics",
			label: "Transport & Logistics",
			jobsCount: "1.9K+ Jobs",
			iconName: "Truck",
			gradient: "from-emerald-500/15 via-emerald-400/5 to-transparent",
			iconBg: "bg-emerald-100 text-emerald-700 group-hover:bg-emerald-600 group-hover:text-white",
			hoverBorder: "group-hover:border-emerald-400",
			badgeStyle: "bg-emerald-50 text-emerald-700 border-emerald-200",
			btnStyle: "bg-emerald-100 text-emerald-700 group-hover:bg-emerald-600 group-hover:text-white"
		},
		{
			id: "electrician",
			label: "Electrician",
			jobsCount: "1.1K+ Jobs",
			iconName: "Zap",
			gradient: "from-purple-500/15 via-purple-400/5 to-transparent",
			iconBg: "bg-purple-100 text-purple-700 group-hover:bg-purple-600 group-hover:text-white",
			hoverBorder: "group-hover:border-purple-400",
			badgeStyle: "bg-purple-50 text-purple-700 border-purple-200",
			btnStyle: "bg-purple-100 text-purple-700 group-hover:bg-purple-600 group-hover:text-white"
		},
		{
			id: "office",
			label: "Office Staff",
			jobsCount: "2.4K+ Jobs",
			iconName: "Briefcase",
			gradient: "from-rose-500/15 via-rose-400/5 to-transparent",
			iconBg: "bg-rose-100 text-rose-700 group-hover:bg-rose-600 group-hover:text-white",
			hoverBorder: "group-hover:border-rose-400",
			badgeStyle: "bg-rose-50 text-rose-700 border-rose-200",
			btnStyle: "bg-rose-100 text-rose-700 group-hover:bg-rose-600 group-hover:text-white"
		}
	]);
	(0, import_react.useEffect)(() => {
		const savedTitle = localStorage.getItem("cms_heroTitle");
		const savedSubtitle = localStorage.getItem("cms_heroSubtitle");
		const savedImages = localStorage.getItem("cms_heroImages");
		const savedMetrics = localStorage.getItem("cms_metrics");
		const savedAbout = localStorage.getItem("cms_aboutData");
		const savedCategories = localStorage.getItem("cms_categories");
		const savedPillars = localStorage.getItem("cms_companyPillars");
		if (savedTitle) setHeroTitle(savedTitle);
		if (savedSubtitle) setHeroSubtitle(savedSubtitle);
		if (savedImages) setImages(JSON.parse(savedImages));
		if (savedMetrics) setMetrics(JSON.parse(savedMetrics));
		if (savedAbout) setAboutData(JSON.parse(savedAbout));
		if (savedPillars) try {
			setCompanyPillars(JSON.parse(savedPillars));
		} catch (e) {}
		if (savedCategories) try {
			const parsed = JSON.parse(savedCategories);
			if (Array.isArray(parsed) && parsed.length > 0) {
				const CATEGORY_PALETTES = [
					{
						gradient: "from-blue-500/20 to-transparent",
						iconBg: "bg-blue-600 text-white"
					},
					{
						gradient: "from-amber-500/20 to-transparent",
						iconBg: "bg-amber-600 text-white"
					},
					{
						gradient: "from-purple-500/20 to-transparent",
						iconBg: "bg-purple-600 text-white"
					},
					{
						gradient: "from-emerald-500/20 to-transparent",
						iconBg: "bg-emerald-600 text-white"
					},
					{
						gradient: "from-orange-500/20 to-transparent",
						iconBg: "bg-orange-600 text-white"
					},
					{
						gradient: "from-rose-500/20 to-transparent",
						iconBg: "bg-rose-600 text-white"
					},
					{
						gradient: "from-cyan-500/20 to-transparent",
						iconBg: "bg-cyan-600 text-white"
					},
					{
						gradient: "from-indigo-500/20 to-transparent",
						iconBg: "bg-indigo-600 text-white"
					}
				];
				const formatted = parsed.map((cat, idx) => {
					const palette = CATEGORY_PALETTES[idx % CATEGORY_PALETTES.length];
					return {
						id: cat.id || `cat_${idx}`,
						label: cat.label || `Category ${idx + 1}`,
						iconName: cat.iconName || "Briefcase",
						gradient: cat.gradient || palette?.gradient || "from-blue-500/20 to-transparent",
						iconBg: cat.iconBg || palette?.iconBg || "bg-[#063B78] text-white",
						...cat
					};
				});
				setCategories(formatted);
			}
		} catch (e) {
			console.error("Failed to load saved categories:", e);
		}
		const syncFromCloud = async () => {
			try {
				const { db } = await import("./firebase-irBfmyIj.mjs").then((n) => n.r).then((n) => n.n);
				const { doc, getDoc } = await import("../_libs/firebase.mjs").then((n) => n.n);
				const snap = await getDoc(doc(db, "cms_settings", "landing_page"));
				if (snap.exists()) {
					const data = snap.data();
					if (Array.isArray(data.heroImages) && data.heroImages.length > 0) {
						setImages(data.heroImages);
						localStorage.setItem("cms_heroImages", JSON.stringify(data.heroImages));
					}
					if (data.heroTitle) setHeroTitle(data.heroTitle);
					if (data.heroSubtitle) setHeroSubtitle(data.heroSubtitle);
					if (data.metrics) setMetrics(data.metrics);
					if (data.aboutData) setAboutData(data.aboutData);
					if (data.companyPillars) setCompanyPillars(data.companyPillars);
					if (data.categories) setCategories(data.categories);
				}
			} catch (err) {
				console.warn("Could not sync CMS settings from cloud:", err);
			}
		};
		syncFromCloud();
	}, []);
	(0, import_react.useEffect)(() => {
		if (images.length <= 1 || isVideoMedia(images[currentImageIndex])) return;
		const timer = setTimeout(() => {
			setCurrentImageIndex((prev) => (prev + 1) % images.length);
		}, 3e3);
		return () => clearTimeout(timer);
	}, [currentImageIndex, images]);
	const [currentUser, setCurrentUser] = (0, import_react.useState)(() => {
		if (typeof window !== "undefined") try {
			const raw = localStorage.getItem("realjob-user") || localStorage.getItem("realjob_db_user");
			if (raw) return JSON.parse(raw);
		} catch {}
		return dataStore.getCurrentUser();
	});
	(0, import_react.useEffect)(() => {
		const syncUser = () => {
			if (typeof window !== "undefined" && window.location.search.includes("view=website")) return;
			let u = dataStore.getCurrentUser();
			if (!u && typeof window !== "undefined") try {
				const raw = localStorage.getItem("realjob-user") || localStorage.getItem("realjob_db_user");
				if (raw) u = JSON.parse(raw);
			} catch {}
			setCurrentUser(u);
			if (u && (u.id || u.email)) {
				const r = (u.role || "").toLowerCase();
				if (r === "employer" || r === "admin" || r === "poster") navigate({
					to: "/admin",
					replace: true
				});
				else if (r === "employee") navigate({
					to: "/employee-dashboard",
					replace: true
				});
				else if (r === "worker" || r === "seeker" || r === "user") navigate({
					to: "/dashboard",
					search: { tab: "overview" },
					replace: true
				});
			}
		};
		syncUser();
		window.addEventListener("realjob-auth-change", syncUser);
		window.addEventListener("storage", syncUser);
		return () => {
			window.removeEventListener("realjob-auth-change", syncUser);
			window.removeEventListener("storage", syncUser);
		};
	}, [navigate]);
	const handleLogout = () => {
		dataStore.logout();
		setCurrentUser(null);
		toast.info("Logged out successfully!");
		if (typeof window !== "undefined") window.location.replace("/");
	};
	if (currentUser && typeof window !== "undefined" && !window.location.search.includes("view=website")) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-white flex flex-col font-sans",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageGate, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "absolute top-0 w-full z-50 bg-transparent p-3 sm:p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-[1400px] items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, { className: "h-10 sm:h-12 md:h-14 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 sm:gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageSwitcher, {}), currentUser ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#EBF1F8] border border-[#B8D3F2] text-xs font-black text-[#063B78]",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["👤 ", currentUser.fullName || currentUser.email?.split("@")[0]] })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: () => navigate({ to: currentUser.role === "admin" || currentUser.role === "employer" ? "/admin" : "/dashboard" }),
									size: "sm",
									className: "bg-[#063B78] hover:bg-[#082F63] text-white font-extrabold text-xs px-3 h-9.5 rounded-lg shadow-xs",
									children: t("viewDashboard")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: handleLogout,
									size: "sm",
									variant: "outline",
									className: "border-red-200 text-red-600 hover:bg-red-50 hover:text-red-700 font-extrabold text-xs px-3 h-9.5 rounded-lg shadow-xs",
									children: t("logout")
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoginDropdown, {})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "relative isolate overflow-hidden h-[50vh] min-h-[350px] md:h-screen md:min-h-[600px] flex items-center justify-center pt-20 pb-16 md:pb-24",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-0 z-0 bg-transparent",
							children: images.map((mediaUrl, index) => {
								const isVideo = isVideoMedia(mediaUrl);
								const ytEmbed = isVideo ? getYouTubeEmbedUrl(mediaUrl) : null;
								const isActive = index === currentImageIndex;
								if (isVideo) {
									if (ytEmbed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `absolute inset-0 h-full w-full pointer-events-none transition-opacity duration-1000 ease-in-out ${isActive ? "opacity-100 z-1" : "opacity-0"}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
											src: ytEmbed,
											title: "Hero Video Background",
											className: "w-full h-full object-cover border-0 pointer-events-none",
											allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
										})
									}, mediaUrl + index);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
										src: mediaUrl,
										autoPlay: true,
										muted: true,
										loop: images.length <= 1,
										playsInline: true,
										preload: "auto",
										ref: (el) => {
											if (el && isActive) {
												el.currentTime = 0;
												el.play().catch(() => {});
											}
										},
										onEnded: () => {
											if (images.length > 1) setCurrentImageIndex((prev) => (prev + 1) % images.length);
										},
										onError: () => {
											if (images.length > 1) setTimeout(() => {
												setCurrentImageIndex((prev) => (prev + 1) % images.length);
											}, 3e3);
										},
										className: `absolute inset-0 h-full w-full object-cover transition-opacity duration-1000 ease-in-out ${isActive ? "opacity-100 z-1" : "opacity-0 pointer-events-none"}`
									}, mediaUrl + index);
								}
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: mediaUrl,
									alt: "REAL JOB India Portal Background",
									className: `absolute inset-0 h-full w-full object-cover object-[70%_20%] transition-opacity duration-1000 ease-in-out ${isActive ? "opacity-100 z-1" : "opacity-0 pointer-events-none"}`
								}, mediaUrl + index);
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "relative z-10 text-center px-4 max-w-4xl mx-auto flex flex-col items-center" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "relative z-20 pt-4 sm:pt-6 lg:pt-8 pb-1 sm:pb-2 bg-[#f8f9fa]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-full px-4 sm:px-8 lg:px-12",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 md:grid-cols-4 lg:flex lg:flex-wrap lg:justify-between items-start sm:items-center gap-y-8 gap-x-2 sm:gap-4 bg-white rounded-[2rem] md:rounded-full shadow-[0_8px_30px_rgb(0,0,0,0.06)] border border-gray-100 p-6 md:p-8 mx-auto w-full max-w-[1400px]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col sm:flex-row items-center text-center sm:text-left gap-2 sm:gap-3 md:gap-4 justify-center sm:justify-start",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex shrink-0 items-center justify-center size-10 sm:size-12 md:size-14 rounded-full bg-[#D4AF37]/10 text-[#D4AF37]",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5 sm:size-6 md:size-7 stroke-[2]" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "block text-xl sm:text-2xl md:text-3xl font-black text-[#10233F] leading-tight",
											children: metrics[0]?.value
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] sm:text-xs font-bold text-gray-500 block",
											children: t("verifiedWorkersMetric")
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col sm:flex-row items-center text-center sm:text-left gap-2 sm:gap-3 md:gap-4 justify-center sm:justify-start",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex shrink-0 items-center justify-center size-10 sm:size-12 md:size-14 rounded-full bg-[#D4AF37]/10 text-[#D4AF37]",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-5 sm:size-6 md:size-7 stroke-[2]" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "block text-xl sm:text-2xl md:text-3xl font-black text-[#10233F] leading-tight",
											children: metrics[1]?.value
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] sm:text-xs font-bold text-gray-500 block",
											children: t("liveJobOpeningsMetric")
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col sm:flex-row items-center text-center sm:text-left gap-2 sm:gap-3 md:gap-4 justify-center sm:justify-start",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex shrink-0 items-center justify-center size-10 sm:size-12 md:size-14 rounded-full bg-[#D4AF37]/10 text-[#D4AF37]",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-5 sm:size-6 md:size-7 stroke-[2]" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "block text-xl sm:text-2xl md:text-3xl font-black text-[#10233F] leading-tight",
											children: metrics[2]?.value
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] sm:text-xs font-bold text-gray-500 block",
											children: t("employersMetric")
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col sm:flex-row items-center text-center sm:text-left gap-2 sm:gap-3 md:gap-4 justify-center sm:justify-start",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex shrink-0 items-center justify-center size-10 sm:size-12 md:size-14 rounded-full bg-[#D4AF37]/10 text-[#D4AF37]",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-5 sm:size-6 md:size-7 stroke-[2]" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "block text-xl sm:text-2xl md:text-3xl font-black text-[#10233F] leading-tight",
											children: metrics[3]?.value
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] sm:text-xs font-bold text-gray-500 block",
											children: t("zeroCommissionMetric")
										})] })]
									})
								]
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "relative bg-[#f8f9fa] pt-2 sm:pt-4 lg:pt-6 pb-10 lg:pb-12 overflow-hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative z-10 mx-auto max-w-[1500px] px-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "bg-white rounded-[30px] border border-gray-100 shadow-[0_10px_40px_rgb(0,0,0,0.05)] overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 lg:grid-cols-12",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "lg:col-span-5 relative bg-white pb-20 lg:pb-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "relative h-[300px] lg:h-[450px] w-full pr-12 lg:pr-16 pt-8 pl-8",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "w-full h-full rounded-tr-[60px] rounded-bl-[60px] overflow-hidden border-r-[8px] border-b-[8px] border-[#D4AF37] relative shadow-lg",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
													src: aboutData.image,
													alt: "Company Overview",
													className: "w-full h-full object-cover"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[#082F63]/10 mix-blend-multiply" })]
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "absolute bottom-0 left-0 right-0 lg:right-[-3.5rem] bg-gradient-to-r from-[#082F63] via-[#0D3B73] to-[#082F63] rounded-tr-[32px] rounded-tl-[32px] lg:rounded-tl-none p-5 lg:p-6 shadow-2xl border-t-[4px] border-[#D4AF37] z-20",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid grid-cols-3 divide-x divide-white/15",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex flex-col items-center text-center px-1 sm:px-2 group",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "size-9 lg:size-10 rounded-xl bg-[#D4AF37]/15 border border-[#D4AF37]/40 flex items-center justify-center mb-1.5 transition-transform duration-300 group-hover:scale-110",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-4 lg:size-5 text-[#D4AF37]" })
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-xs lg:text-sm font-black text-white leading-tight",
																children: t("rightPerson")
															}),
															lang !== "en" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-[9px] lg:text-[10px] text-[#D4AF37] font-semibold mt-0.5",
																children: t("rightPerson")
															})
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex flex-col items-center text-center px-1 sm:px-2 group",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "size-9 lg:size-10 rounded-xl bg-[#D4AF37]/15 border border-[#D4AF37]/40 flex items-center justify-center mb-1.5 transition-transform duration-300 group-hover:scale-110",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4 lg:size-5 text-[#D4AF37]" })
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-xs lg:text-sm font-black text-white leading-tight",
																children: t("rightJob")
															}),
															lang !== "en" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-[9px] lg:text-[10px] text-[#D4AF37] font-semibold mt-0.5",
																children: t("rightJob")
															})
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex flex-col items-center text-center px-1 sm:px-2 group",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "size-9 lg:size-10 rounded-xl bg-[#D4AF37]/15 border border-[#D4AF37]/40 flex items-center justify-center mb-1.5 transition-transform duration-300 group-hover:scale-110",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4 lg:size-5 text-[#D4AF37]" })
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-xs lg:text-sm font-black text-white leading-tight",
																children: t("rightOpportunity")
															}),
															lang !== "en" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-[9px] lg:text-[10px] text-[#D4AF37] font-semibold mt-0.5",
																children: t("rightOpportunity")
															})
														]
													})
												]
											})
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "lg:col-span-7 p-8 lg:p-16 flex flex-col justify-center",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-wrap items-center gap-3 mb-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-[2px] w-8 bg-[#D4AF37]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs font-black text-[#082F63] tracking-[0.1em] uppercase",
														children: t("aboutRealJob")
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FEF9E7] border border-[#FDE68A] text-[#B45309] font-black text-[11px] shadow-2xs",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3 text-[#D97706]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
														t("rightPerson"),
														" • ",
														t("rightJob"),
														" • ",
														t("rightOpportunity")
													] })]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
												className: "text-4xl md:text-5xl font-black text-[#082F63] leading-[1.1] mb-6",
												children: aboutData.title === "About Our Company" ? t("aboutOurCompany") : aboutData.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[15px] font-medium text-gray-600 leading-relaxed mb-10 max-w-3xl whitespace-pre-wrap",
												children: aboutData.description.includes("REAL JOB is a reliable employment portal") ? t("aboutRealJobDescription") : aboutData.description
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
												children: companyPillars.map((pillar) => {
													const IconComponent = PILLAR_ICONS[pillar.iconName] || Target;
													const title = pillar.id === "mission" ? t("ourMission") : pillar.id === "vision" ? t("ourVision") : pillar.id === "values" ? t("ourValues") : pillar.id === "belief" ? t("ourBelief") : lang === "mr" && pillar.titleMr ? pillar.titleMr : pillar.title;
													const desc = pillar.id === "mission" ? t("missionDesc") : pillar.id === "vision" ? t("visionDesc") : pillar.id === "values" ? t("valuesDesc") : pillar.id === "belief" ? `${t("rightPerson")}\n${t("rightJob")}\n${t("rightOpportunity")}` : lang === "mr" && pillar.descriptionMr ? pillar.descriptionMr : pillar.description;
													return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "group bg-white rounded-2xl p-5 shadow-[0_4px_20px_rgb(0,0,0,0.06)] border border-gray-100 flex flex-col items-center text-center transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_15px_30px_rgba(212,175,55,0.15)] hover:border-[#D4AF37]/40 relative overflow-hidden",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-br from-[#D4AF37]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" }),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "size-12 rounded-full border-2 border-[#D4AF37] flex items-center justify-center mb-4 transition-transform duration-500 group-hover:scale-110 group-hover:rotate-12 group-hover:bg-[#D4AF37] z-10",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconComponent, { className: "size-6 text-[#D4AF37] group-hover:text-white transition-colors duration-300" })
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
																className: "text-[14px] font-black text-[#082F63] mb-2 z-10 relative",
																children: title
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																className: "text-[11px] font-semibold text-gray-500 leading-snug z-10 relative whitespace-pre-line",
																children: desc
															})
														]
													}, pillar.id || pillar.title);
												})
											})
										]
									})]
								})
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "relative pt-6 pb-14 bg-gradient-to-b from-[#F5F8FC] via-white to-[#F5F8FC] overflow-hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative z-10 mx-auto max-w-[1600px] px-4 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#FEF9E7] border border-[#FDE68A] text-[#B45309] font-black text-xs uppercase tracking-wider mb-3 shadow-sm hover:scale-105 transition-transform duration-300",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4 text-[#D97706] animate-bounce" }), t("exploreByCategory")]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-3xl sm:text-4xl md:text-5xl font-black text-[#082F63] mb-2 tracking-tight",
									children: t("popularJobCategories")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-center gap-3 mb-10",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-[1.5px] w-12 md:w-20 bg-gradient-to-r from-transparent to-[#D4AF37]/60" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs md:text-sm font-extrabold text-[#5B6B7F]",
											children: t("rightOpportunityField")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-[1.5px] w-12 md:w-20 bg-gradient-to-l from-transparent to-[#D4AF37]/60" })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative w-full overflow-hidden py-6",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute left-0 top-0 bottom-0 w-20 sm:w-32 bg-gradient-to-r from-[#F5F8FC] via-[#F5F8FC]/80 to-transparent z-20" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute right-0 top-0 bottom-0 w-20 sm:w-32 bg-gradient-to-l from-[#F5F8FC] via-[#F5F8FC]/80 to-transparent z-20" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "animate-marquee-slow flex items-center gap-6 sm:gap-8 px-4",
											children: [
												...categories,
												...categories,
												...categories,
												...categories
											].map((catData, i) => {
												const IconComponent = ICONS[catData.iconName] || Briefcase;
												return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													onClick: () => navigate({
														to: "/auth",
														search: {
															mode: "login",
															role: "worker"
														}
													}),
													className: `group relative shrink-0 w-[220px] sm:w-[250px] h-[100px] sm:h-[110px] rounded-[1.5rem] border border-white/60 bg-white/40 backdrop-blur-md p-4 flex items-center justify-center gap-4 cursor-pointer transition-all duration-500 shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:shadow-[0_20px_40px_rgba(212,175,55,0.15)] hover:-translate-y-2 hover:scale-[1.03] overflow-hidden`,
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 rounded-[1.5rem] border-2 border-transparent bg-gradient-to-br from-[#D4AF37]/0 via-[#D4AF37]/0 to-[#D4AF37]/40 opacity-0 transition-opacity duration-500 group-hover:opacity-100 pointer-events-none" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `absolute -top-12 -left-12 size-36 rounded-full bg-gradient-to-br ${catData.gradient || "from-blue-500/20 to-transparent"} blur-2xl opacity-40 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none group-hover:animate-pulse` }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: `relative size-12 sm:size-14 rounded-2xl flex items-center justify-center shrink-0 transition-all duration-500 group-hover:scale-110 group-hover:rotate-12 shadow-sm group-hover:shadow-lg ${catData.iconBg || "bg-blue-600 text-white"}`,
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconComponent, { className: "size-6 sm:size-7 stroke-[2.5]" })
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "flex-1 text-left flex flex-col justify-center overflow-hidden z-10",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
																className: "font-black text-sm sm:text-base text-[#082F63] group-hover:text-[#125BB5] transition-colors truncate leading-tight",
																children: CATEGORY_TRANSLATIONS[catData.id]?.[lang] || catData.label
															})
														})
													]
												}, `${catData.id || i}-${i}`);
											})
										})
									]
								})
							]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
		]
	});
}
//#endregion
export { LandingGatewayPage as component };
