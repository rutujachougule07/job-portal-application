//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CVkuBXU1.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/about",
			"/admin",
			"/auth",
			"/categories",
			"/contact",
			"/dashboard",
			"/faq",
			"/home",
			"/reset-password",
			"/select-language",
			"/superadmin",
			"/company/$companyId",
			"/jobs/$jobId",
			"/workers/$workerId",
			"/jobs/",
			"/workers/"
		],
		preloads: [
			"/assets/index-D1RkdOSv.js",
			"/assets/useRouter-ByJ6_rwb.js",
			"/assets/react-dom-Dj2KXnwj.js",
			"/assets/useStore-C9WKQuax.js",
			"/assets/Match-C4nVjwi6.js",
			"/assets/redirect-1Dss4sOM.js",
			"/assets/link-BhBRKPSE.js",
			"/assets/matchContext-DiNYQDBD.js",
			"/assets/useMatch-CnYjb8nr.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D1RkdOSv.js"
		} }]
	},
	"/": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CMMmOcDz.js",
			"/assets/data-store-SgCA5PEj.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/createLucideIcon-CsVdBA7d.js",
			"/assets/arrow-right-DPAQbfZS.js",
			"/assets/chevron-up-B28jONq0.js",
			"/assets/building-2-DQr5Ddk3.js",
			"/assets/eye-CALmIQFg.js",
			"/assets/wrench-DyNJIg6h.js",
			"/assets/hard-hat-DA-U_GEK.js",
			"/assets/PublicFooter-DPEObxay.js",
			"/assets/shield-check-Cw8cdOJG.js",
			"/assets/sparkles-CI-MWGDW.js",
			"/assets/star-f2WFfXBm.js",
			"/assets/target-BbSZKkKt.js",
			"/assets/user-check-CDbemUnB.js",
			"/assets/users-BE4J0Cp3.js",
			"/assets/zap-bsku66l3.js",
			"/assets/Brand-6__CKiML.js",
			"/assets/career-team-DHTUSRpW.js"
		]
	},
	"/_authenticated": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/applications",
			"/_authenticated/control",
			"/_authenticated/employer",
			"/_authenticated/messages",
			"/_authenticated/notifications",
			"/_authenticated/post-job",
			"/_authenticated/profile",
			"/_authenticated/salary"
		],
		preloads: ["/assets/route-D7Cm-cfc.js"]
	},
	"/about": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-DFjjVCxa.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/building-2-DQr5Ddk3.js",
			"/assets/circle-check-BnpwB6yf.js",
			"/assets/globe-CZc3mwTw.js",
			"/assets/hard-hat-DA-U_GEK.js",
			"/assets/heart-handshake-DXUBTw0d.js",
			"/assets/PublicHeader-BPby5FVI.js",
			"/assets/PublicFooter-DPEObxay.js",
			"/assets/shield-check-Cw8cdOJG.js",
			"/assets/sparkles-CI-MWGDW.js",
			"/assets/target-BbSZKkKt.js",
			"/assets/zap-bsku66l3.js"
		]
	},
	"/admin": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-BY-_ujRe.js",
			"/assets/data-store-SgCA5PEj.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/Stats-CVwebFVk.js",
			"/assets/createLucideIcon-CsVdBA7d.js",
			"/assets/chart-column-BT2mNQIc.js",
			"/assets/file-text-DKDA1dEy.js",
			"/assets/search-C1E8x3i6.js",
			"/assets/shield-check-Cw8cdOJG.js",
			"/assets/users-BE4J0Cp3.js",
			"/assets/badge-BtmmBMmV.js",
			"/assets/input-B4Rpl8PA.js"
		]
	},
	"/auth": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-u0lpNI-r.js",
			"/assets/data-store-SgCA5PEj.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/createLucideIcon-CsVdBA7d.js",
			"/assets/arrow-left-ChZkzOU7.js",
			"/assets/building-2-DQr5Ddk3.js",
			"/assets/eye-CALmIQFg.js",
			"/assets/mail-C2LeSom6.js",
			"/assets/phone-CktyGyUQ.js",
			"/assets/user-plus-B_NQRjz_.js",
			"/assets/user-tafbVLLs.js",
			"/assets/Brand-6__CKiML.js",
			"/assets/label-BANuCaFW.js"
		]
	},
	"/categories": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-D33jEO4R.js",
			"/assets/createLucideIcon-CsVdBA7d.js",
			"/assets/arrow-right-DPAQbfZS.js",
			"/assets/building-2-DQr5Ddk3.js",
			"/assets/wrench-DyNJIg6h.js",
			"/assets/trending-up-DMJtL5pd.js",
			"/assets/hard-hat-DA-U_GEK.js",
			"/assets/headphones-X3T6kA1J.js",
			"/assets/PublicHeader-BPby5FVI.js",
			"/assets/PublicFooter-DPEObxay.js",
			"/assets/search-C1E8x3i6.js",
			"/assets/sparkles-CI-MWGDW.js",
			"/assets/user-plus-B_NQRjz_.js",
			"/assets/input-B4Rpl8PA.js"
		]
	},
	"/contact": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-BAaOpGbl.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/circle-check-BnpwB6yf.js",
			"/assets/PublicHeader-BPby5FVI.js",
			"/assets/PublicFooter-DPEObxay.js",
			"/assets/mail-C2LeSom6.js",
			"/assets/map-pin-CtZps3Ax.js",
			"/assets/message-square-BFODkOXb.js",
			"/assets/phone-CktyGyUQ.js",
			"/assets/send-CUUtR4KF.js",
			"/assets/sparkles-CI-MWGDW.js",
			"/assets/input-B4Rpl8PA.js"
		]
	},
	"/dashboard": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-_2WGeljV.js",
			"/assets/data-store-SgCA5PEj.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/createLucideIcon-CsVdBA7d.js",
			"/assets/bookmark-DPTMYqi7.js",
			"/assets/chevron-up-B28jONq0.js",
			"/assets/building-2-DQr5Ddk3.js",
			"/assets/file-text-DKDA1dEy.js",
			"/assets/map-pin-CtZps3Ax.js",
			"/assets/settings-JHu3mgAP.js",
			"/assets/user-tafbVLLs.js",
			"/assets/UserSidebarLayout-_BX_DGLl.js"
		]
	},
	"/faq": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/faq.tsx",
		children: void 0,
		preloads: [
			"/assets/faq-BqTmaSoM.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/createLucideIcon-CsVdBA7d.js",
			"/assets/chevron-up-B28jONq0.js",
			"/assets/building-2-DQr5Ddk3.js",
			"/assets/chevron-down-DAPNKV-Z.js",
			"/assets/hard-hat-DA-U_GEK.js",
			"/assets/PublicHeader-BPby5FVI.js",
			"/assets/PublicFooter-DPEObxay.js",
			"/assets/message-square-BFODkOXb.js",
			"/assets/search-C1E8x3i6.js",
			"/assets/user-check-CDbemUnB.js",
			"/assets/input-B4Rpl8PA.js"
		]
	},
	"/home": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/home.tsx",
		children: void 0,
		preloads: [
			"/assets/home-HFusWBvq.js",
			"/assets/data-store-SgCA5PEj.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/createLucideIcon-CsVdBA7d.js",
			"/assets/arrow-right-DPAQbfZS.js",
			"/assets/bookmark-DPTMYqi7.js",
			"/assets/chevron-up-B28jONq0.js",
			"/assets/building-2-DQr5Ddk3.js",
			"/assets/circle-check-BnpwB6yf.js",
			"/assets/clock-3-BxoOEZGN.js",
			"/assets/globe-CZc3mwTw.js",
			"/assets/trending-up-DMJtL5pd.js",
			"/assets/heart-handshake-DXUBTw0d.js",
			"/assets/PublicHeader-BPby5FVI.js",
			"/assets/PublicFooter-DPEObxay.js",
			"/assets/PopularCategories-GkUa1U8L.js",
			"/assets/map-pin-CtZps3Ax.js",
			"/assets/search-C1E8x3i6.js",
			"/assets/shield-check-Cw8cdOJG.js",
			"/assets/sparkles-CI-MWGDW.js",
			"/assets/users-BE4J0Cp3.js",
			"/assets/wallet-CgSiQ_Ja.js",
			"/assets/zap-bsku66l3.js",
			"/assets/input-B4Rpl8PA.js",
			"/assets/career-team-DHTUSRpW.js"
		]
	},
	"/reset-password": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-klXJKlbv.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/Brand-6__CKiML.js",
			"/assets/input-B4Rpl8PA.js",
			"/assets/label-BANuCaFW.js"
		]
	},
	"/select-language": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/select-language.tsx",
		children: void 0,
		preloads: [
			"/assets/select-language-CX90Kkc5.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/check-BX888YMt.js",
			"/assets/Brand-6__CKiML.js"
		]
	},
	"/superadmin": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/superadmin.tsx",
		children: void 0,
		preloads: [
			"/assets/superadmin-Dm25ccmK.js",
			"/assets/data-store-SgCA5PEj.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/createLucideIcon-CsVdBA7d.js",
			"/assets/LanguageSwitcher-D63Ey2kU.js",
			"/assets/chevron-up-B28jONq0.js",
			"/assets/building-2-DQr5Ddk3.js",
			"/assets/chart-column-BT2mNQIc.js",
			"/assets/check-BX888YMt.js",
			"/assets/chevron-down-DAPNKV-Z.js",
			"/assets/circle-check-BnpwB6yf.js",
			"/assets/eye-CALmIQFg.js",
			"/assets/file-text-DKDA1dEy.js",
			"/assets/globe-CZc3mwTw.js",
			"/assets/x-DUEMxRUa.js",
			"/assets/mail-C2LeSom6.js",
			"/assets/map-pin-CtZps3Ax.js",
			"/assets/phone-CktyGyUQ.js",
			"/assets/search-C1E8x3i6.js",
			"/assets/settings-JHu3mgAP.js",
			"/assets/user-check-CDbemUnB.js",
			"/assets/users-BE4J0Cp3.js"
		]
	},
	"/_authenticated/applications": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/_authenticated/applications.tsx",
		children: void 0,
		preloads: ["/assets/applications-COZDutCA.js", "/assets/Dashboards-C-okW-Hd.js"]
	},
	"/_authenticated/control": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/_authenticated/control.tsx",
		children: [
			"/_authenticated/control/employers",
			"/_authenticated/control/jobs",
			"/_authenticated/control/languages",
			"/_authenticated/control/reports",
			"/_authenticated/control/salary",
			"/_authenticated/control/settings",
			"/_authenticated/control/users"
		],
		preloads: ["/assets/control-Btt7UWJ0.js", "/assets/Dashboards-C-okW-Hd.js"]
	},
	"/_authenticated/employer": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/_authenticated/employer.tsx",
		children: [
			"/_authenticated/employer/applicants",
			"/_authenticated/employer/employees",
			"/_authenticated/employer/jobs",
			"/_authenticated/employer/reports",
			"/_authenticated/employer/salary"
		],
		preloads: ["/assets/employer-DJKuExMD.js", "/assets/Dashboards-C-okW-Hd.js"]
	},
	"/_authenticated/messages": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/_authenticated/messages.tsx",
		children: void 0,
		preloads: [
			"/assets/messages-5ltYefqG.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/badge-check-DCNAjMju.js",
			"/assets/PublicHeader-BPby5FVI.js",
			"/assets/PublicFooter-DPEObxay.js",
			"/assets/phone-CktyGyUQ.js",
			"/assets/search-C1E8x3i6.js",
			"/assets/send-CUUtR4KF.js",
			"/assets/input-B4Rpl8PA.js"
		]
	},
	"/_authenticated/notifications": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/_authenticated/notifications.tsx",
		children: void 0,
		preloads: ["/assets/notifications-DsUDsGPx.js", "/assets/Dashboards-C-okW-Hd.js"]
	},
	"/_authenticated/post-job": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/_authenticated/post-job.tsx",
		children: void 0,
		preloads: [
			"/assets/post-job-CFbVOaVD.js",
			"/assets/data-store-SgCA5PEj.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/createLucideIcon-CsVdBA7d.js",
			"/assets/chevron-up-B28jONq0.js",
			"/assets/building-2-DQr5Ddk3.js",
			"/assets/eye-CALmIQFg.js",
			"/assets/file-text-DKDA1dEy.js",
			"/assets/PublicHeader-BPby5FVI.js",
			"/assets/PublicFooter-DPEObxay.js",
			"/assets/x-DUEMxRUa.js",
			"/assets/send-CUUtR4KF.js",
			"/assets/wallet-CgSiQ_Ja.js",
			"/assets/badge-BtmmBMmV.js",
			"/assets/input-B4Rpl8PA.js"
		]
	},
	"/_authenticated/profile": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/_authenticated/profile.tsx",
		children: void 0,
		preloads: ["/assets/profile-B1Wmvn_x.js", "/assets/Dashboards-C-okW-Hd.js"]
	},
	"/_authenticated/salary": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/_authenticated/salary.tsx",
		children: void 0,
		preloads: ["/assets/salary-DH-97GvU.js", "/assets/Dashboards-C-okW-Hd.js"]
	},
	"/company/$companyId": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/company.$companyId.tsx",
		children: void 0,
		preloads: [
			"/assets/company._companyId-Dlmn_SAx.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/arrow-left-ChZkzOU7.js",
			"/assets/JobCard-CliAHnhb.js",
			"/assets/chevron-up-B28jONq0.js",
			"/assets/building-2-DQr5Ddk3.js",
			"/assets/circle-check-BnpwB6yf.js",
			"/assets/PublicHeader-BPby5FVI.js",
			"/assets/PublicFooter-DPEObxay.js",
			"/assets/map-pin-CtZps3Ax.js",
			"/assets/share-2-JvliyL4B.js",
			"/assets/shield-check-Cw8cdOJG.js",
			"/assets/star-f2WFfXBm.js",
			"/assets/users-BE4J0Cp3.js"
		]
	},
	"/jobs/$jobId": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/jobs.$jobId.tsx",
		children: void 0,
		preloads: [
			"/assets/jobs._jobId-h7LX8xlV.js",
			"/assets/data-store-SgCA5PEj.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/createLucideIcon-CsVdBA7d.js",
			"/assets/arrow-left-ChZkzOU7.js",
			"/assets/JobCard-CliAHnhb.js",
			"/assets/bookmark-DPTMYqi7.js",
			"/assets/chevron-up-B28jONq0.js",
			"/assets/building-2-DQr5Ddk3.js",
			"/assets/circle-check-BnpwB6yf.js",
			"/assets/clock-3-BxoOEZGN.js",
			"/assets/PublicHeader-BPby5FVI.js",
			"/assets/PublicFooter-DPEObxay.js",
			"/assets/x-DUEMxRUa.js",
			"/assets/map-pin-CtZps3Ax.js",
			"/assets/send-CUUtR4KF.js",
			"/assets/share-2-JvliyL4B.js",
			"/assets/user-tafbVLLs.js",
			"/assets/wallet-CgSiQ_Ja.js",
			"/assets/badge-BtmmBMmV.js"
		]
	},
	"/workers/$workerId": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/workers.$workerId.tsx",
		children: void 0,
		preloads: [
			"/assets/workers._workerId-BWuPXRNU.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/badge-check-DCNAjMju.js",
			"/assets/circle-check-BnpwB6yf.js",
			"/assets/PublicHeader-BPby5FVI.js",
			"/assets/PublicFooter-DPEObxay.js",
			"/assets/x-DUEMxRUa.js",
			"/assets/map-pin-CtZps3Ax.js",
			"/assets/WorkerCard-Dyi_WeP9.js",
			"/assets/share-2-JvliyL4B.js",
			"/assets/user-tafbVLLs.js",
			"/assets/badge-BtmmBMmV.js"
		]
	},
	"/jobs/": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/jobs.index.tsx",
		children: void 0,
		preloads: [
			"/assets/jobs.index-DJvSqx_O.js",
			"/assets/data-store-SgCA5PEj.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/createLucideIcon-CsVdBA7d.js",
			"/assets/arrow-left-ChZkzOU7.js",
			"/assets/JobCard-CliAHnhb.js",
			"/assets/chevron-up-B28jONq0.js",
			"/assets/chevron-down-DAPNKV-Z.js",
			"/assets/wrench-DyNJIg6h.js",
			"/assets/sliders-horizontal-1oc-Rsfl.js",
			"/assets/trending-up-DMJtL5pd.js",
			"/assets/hard-hat-DA-U_GEK.js",
			"/assets/headphones-X3T6kA1J.js",
			"/assets/PublicHeader-BPby5FVI.js",
			"/assets/PublicFooter-DPEObxay.js",
			"/assets/PopularCategories-GkUa1U8L.js",
			"/assets/x-DUEMxRUa.js",
			"/assets/map-pin-CtZps3Ax.js",
			"/assets/search-C1E8x3i6.js",
			"/assets/shield-check-Cw8cdOJG.js",
			"/assets/user-check-CDbemUnB.js",
			"/assets/users-BE4J0Cp3.js",
			"/assets/zap-bsku66l3.js",
			"/assets/input-B4Rpl8PA.js",
			"/assets/UserSidebarLayout-_BX_DGLl.js"
		]
	},
	"/workers/": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/workers.index.tsx",
		children: void 0,
		preloads: [
			"/assets/workers.index-RyczZDfS.js",
			"/assets/button-3RhtYbXs.js",
			"/assets/badge-check-DCNAjMju.js",
			"/assets/sliders-horizontal-1oc-Rsfl.js",
			"/assets/PublicHeader-BPby5FVI.js",
			"/assets/PublicFooter-DPEObxay.js",
			"/assets/x-DUEMxRUa.js",
			"/assets/map-pin-CtZps3Ax.js",
			"/assets/WorkerCard-Dyi_WeP9.js",
			"/assets/search-C1E8x3i6.js",
			"/assets/users-BE4J0Cp3.js",
			"/assets/badge-BtmmBMmV.js",
			"/assets/input-B4Rpl8PA.js"
		]
	},
	"/_authenticated/control/employers": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/_authenticated/control.employers.tsx",
		children: void 0,
		preloads: ["/assets/control.employers-BtjICqqZ.js"]
	},
	"/_authenticated/control/jobs": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/_authenticated/control.jobs.tsx",
		children: void 0,
		preloads: ["/assets/control.jobs-D-HlnF2r.js"]
	},
	"/_authenticated/control/languages": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/_authenticated/control.languages.tsx",
		children: void 0,
		preloads: ["/assets/control.languages-BMFeCG1d.js"]
	},
	"/_authenticated/control/reports": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/_authenticated/control.reports.tsx",
		children: void 0,
		preloads: ["/assets/control.reports-uk0_cd_l.js"]
	},
	"/_authenticated/control/salary": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/_authenticated/control.salary.tsx",
		children: void 0,
		preloads: ["/assets/control.salary-CU5pq-N3.js"]
	},
	"/_authenticated/control/settings": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/_authenticated/control.settings.tsx",
		children: void 0,
		preloads: ["/assets/control.settings-n5gZRwyk.js"]
	},
	"/_authenticated/control/users": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/_authenticated/control.users.tsx",
		children: void 0,
		preloads: ["/assets/control.users-D6hTgRxI.js"]
	},
	"/_authenticated/employer/applicants": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/_authenticated/employer.applicants.tsx",
		children: void 0,
		preloads: ["/assets/employer.applicants-DLamubMD.js"]
	},
	"/_authenticated/employer/employees": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/_authenticated/employer.employees.tsx",
		children: void 0,
		preloads: ["/assets/employer.employees-Dao_ii3_.js"]
	},
	"/_authenticated/employer/jobs": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/_authenticated/employer.jobs.tsx",
		children: void 0,
		preloads: ["/assets/employer.jobs-DnZ1DjYN.js"]
	},
	"/_authenticated/employer/reports": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/_authenticated/employer.reports.tsx",
		children: void 0,
		preloads: ["/assets/employer.reports-eQBgoZ35.js"]
	},
	"/_authenticated/employer/salary": {
		filePath: "D:/payal wankar/job-portal-application-main (1)/job-portal-application-main/src/routes/_authenticated/employer.salary.tsx",
		children: void 0,
		preloads: ["/assets/employer.salary-CbNmH2C9.js"]
	}
} });
//#endregion
export { tsrStartManifest };
