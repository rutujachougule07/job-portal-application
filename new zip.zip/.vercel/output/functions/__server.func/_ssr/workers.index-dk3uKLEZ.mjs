import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n } from "./i18n-CEAlH7ip.mjs";
import { t as Button } from "./button--9UiOy7A.mjs";
import { A as Search, N as RotateCcw, S as SlidersHorizontal, W as MapPin, ht as Funnel, qt as BadgeCheck, r as X, s as Users } from "../_libs/lucide-react.mjs";
import { t as PublicHeader } from "./PublicHeader-D1uPireo.mjs";
import { t as PublicFooter } from "./PublicFooter-zsmeitx6.mjs";
import { t as Badge } from "./badge-DRaMiws1.mjs";
import { t as Input } from "./input-CZUnWUIa.mjs";
import { n as workersList, t as WorkerCard } from "./WorkerCard-CtJ9kGiL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/workers.index-dk3uKLEZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function WorkersListingPage() {
	const { t, n, lang } = useI18n();
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [locationFilter, setLocationFilter] = (0, import_react.useState)("");
	const [professionFilter, setProfessionFilter] = (0, import_react.useState)("all");
	const [availabilityFilter, setAvailabilityFilter] = (0, import_react.useState)("all");
	const [minExp, setMinExp] = (0, import_react.useState)(0);
	const [sortBy, setSortBy] = (0, import_react.useState)("rating");
	const [mobileFilterOpen, setMobileFilterOpen] = (0, import_react.useState)(false);
	const filteredWorkers = (0, import_react.useMemo)(() => {
		return workersList.filter((worker) => {
			const matchesSearch = worker.name.toLowerCase().includes(searchQuery.toLowerCase()) || worker.profession.toLowerCase().includes(searchQuery.toLowerCase()) || worker.marathiProfession.includes(searchQuery) || worker.skills.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase()));
			const matchesLocation = !locationFilter || worker.location.toLowerCase().includes(locationFilter.toLowerCase());
			const matchesProfession = professionFilter === "all" || worker.profession.toLowerCase().includes(professionFilter.toLowerCase());
			const matchesAvailability = availabilityFilter === "all" || worker.availability === availabilityFilter;
			const matchesExp = (parseInt(worker.experience) || 0) >= minExp;
			return matchesSearch && matchesLocation && matchesProfession && matchesAvailability && matchesExp;
		}).sort((a, b) => {
			if (sortBy === "rating") return b.rating - a.rating;
			if (sortBy === "exp") return (parseInt(b.experience) || 0) - (parseInt(a.experience) || 0);
			return 0;
		});
	}, [
		searchQuery,
		locationFilter,
		professionFilter,
		availabilityFilter,
		minExp,
		sortBy
	]);
	const clearFilters = () => {
		setSearchQuery("");
		setLocationFilter("");
		setProfessionFilter("all");
		setAvailabilityFilter("all");
		setMinExp(0);
		setSortBy("rating");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "bg-[#F5F8FC] min-h-screen py-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bg-hero-overlay p-8 rounded-2xl text-white mb-8 shadow-lg relative overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 max-w-3xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-bold uppercase tracking-wider text-[#FFC400] backdrop-blur mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-3.5" }), t("workers")]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "text-3xl sm:text-4xl font-black text-white",
								children: [
									t("verifiedWorkersHeading"),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[#FFC400]",
										children: t("skilledUnskilledSub")
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-white/90 font-medium",
								children: t("workersHeroSub")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 grid sm:grid-cols-[1fr_0.8fr_auto] gap-3 bg-white p-2.5 rounded-xl shadow-md border border-[#DCE5F0]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative flex items-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 size-4 text-[#5B6B7F]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											placeholder: t("skillPlaceholder"),
											value: searchQuery,
											onChange: (e) => setSearchQuery(e.target.value),
											className: "pl-9 h-11 border-0 bg-transparent text-xs text-[#10233F] font-bold focus-visible:ring-0"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative flex items-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "absolute left-3 size-4 text-[#125BB5]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											placeholder: t("cityPlaceholder"),
											value: locationFilter,
											onChange: (e) => setLocationFilter(e.target.value),
											className: "pl-9 h-11 border-0 bg-transparent text-xs text-[#10233F] font-bold focus-visible:ring-0"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										className: "btn-yellow h-11 font-black text-xs px-6",
										children: t("search")
									})
								]
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-8 items-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "hidden lg:block bg-white p-6 rounded-2xl border border-[#DCE5F0] shadow-xs sticky top-24",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between pb-4 border-b border-[#DCE5F0] mb-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-black text-sm text-[#10233F] flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "size-4 text-[#063B78]" }), t("filters")]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: clearFilters,
									className: "text-xs font-bold text-[#125BB5] hover:underline flex items-center gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3" }),
										" ",
										t("reset")
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase tracking-wider",
									children: t("professionLabel")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: professionFilter,
									onChange: (e) => setProfessionFilter(e.target.value),
									className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "all",
											children: t("allProfessions")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "electrician",
											children: "Electrician"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "cnc",
											children: "CNC Operator"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "driver",
											children: "Driver"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "welder",
											children: "Welder"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "mason",
											children: "Mason"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "plumber",
											children: "Plumber"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase tracking-wider",
									children: t("availabilityLabel")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: availabilityFilter,
									onChange: (e) => setAvailabilityFilter(e.target.value),
									className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "all",
											children: t("allStatus")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Available Now",
											children: "Available Now"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Immediate",
											children: "Immediate"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "1 Week Notice",
											children: "1 Week Notice"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase tracking-wider",
										children: [
											t("minExpLabel"),
											": ",
											n(minExp),
											" Years"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "range",
										min: 0,
										max: 10,
										step: 1,
										value: minExp,
										onChange: (e) => setMinExp(Number(e.target.value)),
										className: "w-full accent-[#063B78]"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between text-[10px] font-bold text-[#5B6B7F] mt-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "0 Yr" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "5 Yrs" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "10+ Yrs" })
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3.5 bg-[#EBF1F8] rounded-xl border border-[#063B78]/20 flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { className: "size-5 text-[#FFC400] fill-[#063B78] shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-bold text-[#063B78] leading-tight",
									children: t("verificationNotice")
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-[#DCE5F0] mb-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm font-black text-[#10233F]",
								children: [
									t("totalWorkersCount"),
									": ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[#063B78]",
										children: n(filteredWorkers.length)
									})
								]
							}), searchQuery && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								variant: "secondary",
								className: "text-xs font-bold bg-[#EBF1F8] text-[#063B78]",
								children: [
									"\"",
									searchQuery,
									"\""
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								className: "lg:hidden text-xs font-bold border-[#063B78] text-[#063B78]",
								onClick: () => setMobileFilterOpen(true),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { className: "size-3.5 mr-1" }),
									" ",
									t("filters")
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-bold text-[#5B6B7F] shrink-0",
									children: [t("sortByLabel"), ":"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: sortBy,
									onChange: (e) => setSortBy(e.target.value),
									className: "h-9 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold text-[#10233F]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "rating",
										children: t("highestRated")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "exp",
										children: t("mostExp")
									})]
								})]
							})]
						})]
					}), filteredWorkers.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-6",
						children: filteredWorkers.map((worker) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkerCard, { worker }, worker.id))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "card-realjob p-12 text-center bg-white",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "mx-auto size-14 text-[#5B6B7F] mb-4" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xl font-black text-[#10233F]",
								children: t("noWorkersFound")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold text-[#5B6B7F] mt-2",
								children: t("noWorkersFoundSub")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: clearFilters,
								className: "mt-5 btn-yellow text-xs font-bold px-6",
								children: t("resetFilters")
							})
						]
					})] })]
				})]
			}), mobileFilterOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-[#082F63]/60 backdrop-blur-sm flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-xs bg-white h-full p-6 overflow-y-auto shadow-2xl flex flex-col justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between pb-4 border-b border-[#DCE5F0] mb-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-black text-base text-[#10233F]",
							children: t("filters")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setMobileFilterOpen(false),
							className: "p-1 text-[#5B6B7F]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-6" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
							children: t("professionLabel")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: professionFilter,
							onChange: (e) => setProfessionFilter(e.target.value),
							className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "all",
									children: t("allProfessions")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "electrician",
									children: "Electrician"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "cnc",
									children: "CNC Operator"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "driver",
									children: "Driver"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "welder",
									children: "Welder"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "mason",
									children: "Mason"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "plumber",
									children: "Plumber"
								})
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
							children: t("availabilityLabel")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: availabilityFilter,
							onChange: (e) => setAvailabilityFilter(e.target.value),
							className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "all",
									children: t("allStatus")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Available Now",
									children: "Available Now"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Immediate",
									children: "Immediate"
								})
							]
						})] })]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-6 border-t border-[#DCE5F0] grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: clearFilters,
							className: "text-xs font-bold",
							children: t("reset")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => setMobileFilterOpen(false),
							className: "btn-yellow text-xs font-extrabold",
							children: t("continue")
						})]
					})]
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
	] });
}
//#endregion
export { WorkersListingPage as component };
