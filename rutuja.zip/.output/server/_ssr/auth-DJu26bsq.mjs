import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Button, r as LogoIcon } from "./button-DlK03b8v.mjs";
import { t as dataStore } from "./data-store-j7ecARph.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { F as Phone, G as Lock, H as Mail, Ht as ArrowLeft, K as LoaderCircle, W as LogIn, c as User, ft as Eye, jt as Building2, pt as EyeOff, u as UserPlus } from "../_libs/lucide-react.mjs";
import { t as Route } from "./auth-TmANPNaU.mjs";
import { t as Label } from "./label-DK7u7CDB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-DJu26bsq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AuthPage() {
	const search = Route.useSearch();
	const navigate = useNavigate();
	const [mode, setMode] = (0, import_react.useState)(search.mode || "login");
	const [role, setRole] = (0, import_react.useState)(search.role || "worker");
	const [showPassword, setShowPassword] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [rememberMe, setRememberMe] = (0, import_react.useState)(true);
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		setEmail("");
		setPassword("");
	}, [mode, role]);
	const [workerName, setWorkerName] = (0, import_react.useState)("");
	const [workerPhone, setWorkerPhone] = (0, import_react.useState)("");
	const [companyName, setCompanyName] = (0, import_react.useState)("");
	const handleSubmit = async (e) => {
		e.preventDefault();
		setBusy(true);
		setTimeout(() => {
			setBusy(false);
			if (mode === "forgot") {
				toast.success("Password reset email sent! Check your inbox.");
				setMode("login");
				return;
			}
			if (mode === "register") {
				const rawName = role === "employer" || role === "admin" ? companyName : workerName;
				const nameString = rawName && rawName.trim() ? rawName.trim() : email ? email.split("@")[0] || "User" : "User";
				const userObj = {
					id: role === "employer" || role === "admin" ? companyName ? `emp-${companyName.toLowerCase().replace(/\s+/g, "-")}` : "emp-001" : `seeker-${Date.now()}`,
					email: email || "user@example.com",
					role: role === "admin" ? "employer" : role,
					fullName: nameString
				};
				window.localStorage.setItem("realjob-user", JSON.stringify(userObj));
				dataStore.setCurrentUser(userObj);
				toast.success("Account created successfully! Welcome to REAL JOB.");
				navigate({
					to: "/select-language",
					search: { redirectTo: role === "admin" ? "/admin" : role === "employer" ? "/employer" : "/home" }
				});
				return;
			}
			const userObj = {
				id: role === "admin" ? "admin-001" : role === "employer" ? "emp-tcs" : "seeker-rutuja",
				email: email || "user@example.com",
				role: role === "admin" ? "admin" : role,
				fullName: (email ? email.split("@")[0] : "") || (role === "admin" ? "System Admin" : "User")
			};
			window.localStorage.setItem("realjob-user", JSON.stringify(userObj));
			dataStore.setCurrentUser(userObj);
			toast.success("Successfully logged in!");
			navigate({
				to: "/select-language",
				search: { redirectTo: role === "admin" ? "/admin" : role === "employer" ? "/employer" : "/home" }
			});
		}, 1e3);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "h-screen w-full overflow-hidden relative flex items-center justify-center bg-cover bg-center bg-no-repeat p-3 sm:p-4",
		style: { backgroundImage: `url('/office_desk_bg.png')` },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-black/15 backdrop-blur-[2px] pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute left-4 top-3.5 z-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "ghost",
					size: "sm",
					className: "bg-white/85 hover:bg-white text-[#0A3B7B] font-bold text-xs rounded-full shadow-md backdrop-blur-md px-3.5 py-1.5 h-8 border border-white/70",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "mr-1 size-3.5" }), " Home"]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 w-full max-w-md sm:max-w-[430px] bg-white/80 backdrop-blur-xl rounded-2xl border border-white/80 shadow-2xl px-6 py-5 sm:px-8 sm:py-6 transition-all duration-300",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex justify-center mb-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoIcon, { className: "h-11 sm:h-12 object-contain" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center space-y-0.5 mb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-xl sm:text-2xl font-black text-[#0A3B7B] tracking-tight leading-tight",
							children: role === "admin" ? mode === "register" ? "Employer / Admin Registration" : mode === "forgot" ? "Reset Password" : "Employer / Admin Login" : mode === "register" ? "Worker / User Registration" : mode === "forgot" ? "Reset Password" : "Worker / User Login"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-semibold text-gray-600 mt-1 px-2 leading-tight",
							children: role === "admin" ? mode === "register" ? "For employers & companies: Register an account to find workers." : "For employers & admins: Login to post jobs and search candidates." : mode === "register" ? "For job seekers: Create a new profile and start finding jobs." : "Please enter your email and password to log in and find jobs."
						})]
					}),
					mode !== "forgot" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-gray-200/80 backdrop-blur-md p-1 rounded-full border border-white/70 flex items-center shadow-inner mb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setMode("login"),
							className: `flex-1 py-1.5 rounded-full text-xs font-black transition-all duration-200 flex items-center justify-center gap-1.5 ${mode === "login" ? "bg-[#0A3B7B] text-white shadow-md shadow-[#0A3B7B]/30" : "text-gray-700 hover:text-black font-bold"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-3.5" }), " Login"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setMode("register"),
							className: `flex-1 py-1.5 rounded-full text-xs font-black transition-all duration-200 flex items-center justify-center gap-1.5 ${mode === "register" ? "bg-[#0A3B7B] text-white shadow-md shadow-[#0A3B7B]/30" : "text-gray-700 hover:text-black font-bold"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-3.5" }), " Register"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleSubmit,
						autoComplete: "off",
						className: "space-y-3",
						children: [
							mode === "register" && role === "worker" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[11px] font-extrabold text-gray-800 mb-0.5 block",
									children: "Full Name *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-gray-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										type: "text",
										autoComplete: "off",
										placeholder: "e.g. Rahul Sharma",
										value: workerName,
										onChange: (e) => setWorkerName(e.target.value),
										className: "w-full h-9 pl-9 pr-3 bg-white rounded-lg border border-gray-200 text-xs font-bold text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#0A3B7B]"
									})]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-[11px] font-extrabold text-gray-800 mb-0.5 block",
									children: "Mobile Number *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-gray-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										type: "tel",
										autoComplete: "off",
										placeholder: "+91 98220 00000",
										value: workerPhone,
										onChange: (e) => setWorkerPhone(e.target.value),
										className: "w-full h-9 pl-9 pr-3 bg-white rounded-lg border border-gray-200 text-xs font-bold text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#0A3B7B]"
									})]
								})] })]
							}),
							mode === "register" && (role === "employer" || role === "admin") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-[11px] font-extrabold text-gray-800 mb-0.5 block",
								children: "Company Name *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-gray-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									type: "text",
									autoComplete: "off",
									placeholder: "e.g. Tata Motors / L&T",
									value: companyName,
									onChange: (e) => setCompanyName(e.target.value),
									className: "w-full h-9 pl-9 pr-3 bg-white rounded-lg border border-gray-200 text-xs font-bold text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#0A3B7B]"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "email",
								className: "text-[11px] font-extrabold text-gray-800 mb-0.5 block",
								children: "Email Address *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-gray-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "email",
									type: "email",
									required: true,
									autoComplete: "off",
									placeholder: "name@example.com",
									value: email,
									onChange: (e) => setEmail(e.target.value),
									className: "w-full h-9.5 pl-9 pr-3 bg-white rounded-lg border border-gray-200 text-xs font-bold text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-[#0A3B7B] shadow-xs"
								})]
							})] }),
							mode !== "forgot" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between items-center mb-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "password",
									className: "text-[11px] font-extrabold text-gray-800",
									children: "Password *"
								}), mode === "login" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setMode("forgot"),
									className: "text-[11px] font-bold text-[#0A3B7B] hover:underline",
									children: "Forgot Password?"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-gray-400" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "password",
										type: showPassword ? "text" : "password",
										required: true,
										autoComplete: "new-password",
										placeholder: "••••••••",
										minLength: 6,
										value: password,
										onChange: (e) => setPassword(e.target.value),
										className: "w-full h-9.5 pl-9 pr-9 bg-white rounded-lg border border-gray-200 text-xs font-bold text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-[#0A3B7B] shadow-xs"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setShowPassword(!showPassword),
										className: "absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600",
										children: showPassword ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5" })
									})
								]
							})] }),
							mode === "login" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 pt-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									id: "remember",
									checked: rememberMe,
									onChange: (e) => setRememberMe(e.target.checked),
									className: "size-3.5 rounded border-gray-300 text-[#0A3B7B] focus:ring-[#0A3B7B] accent-[#0A3B7B] cursor-pointer"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "remember",
									className: "text-[11px] font-bold text-gray-700 cursor-pointer select-none",
									children: "Remember me"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								disabled: busy,
								type: "submit",
								className: "w-full h-10 bg-[#0A3B7B] hover:bg-[#072B5B] text-white font-black text-xs rounded-lg shadow-md shadow-[#0A3B7B]/20 hover:shadow-lg transition-all duration-200 flex items-center justify-center gap-2 mt-1",
								children: busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin size-4" }) : mode === "register" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-3.5" }), " Register Account"] }) : mode === "forgot" ? "Send Reset Link" : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogIn, { className: "size-3.5" }), " Sign In"] })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 text-center text-[11px] font-bold text-gray-600",
						children: [
							mode === "register" ? "Already have an account?" : "Don't have an account?",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setMode(mode === "register" ? "login" : "register"),
								className: "text-[#0A3B7B] font-black hover:underline ml-1",
								children: mode === "register" ? "Sign In" : "Register"
							})
						]
					})
				]
			})
		]
	});
}
//#endregion
export { AuthPage as component };
