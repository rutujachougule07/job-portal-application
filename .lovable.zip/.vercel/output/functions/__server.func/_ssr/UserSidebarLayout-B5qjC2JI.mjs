import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n } from "./i18n-BcT9wMyM.mjs";
import { t as dataStore } from "./data-store-CvMaHmbm.mjs";
import { b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as Search, Z as LogOut, c as User, ft as House, rn as Bookmark, sn as BadgeCheck, wt as FileText } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/UserSidebarLayout-B5qjC2JI.js
var import_jsx_runtime = require_jsx_runtime();
function UserSidebarLayout({ children, activeTab }) {
	const navigate = useNavigate();
	const user = dataStore.getCurrentUser();
	const { lang, setLang } = useI18n();
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
	const tabs = [
		{
			id: "overview",
			label: "Dashboard",
			icon: House,
			path: "/dashboard"
		},
		{
			id: "find-jobs",
			label: "Find Jobs",
			icon: Search,
			path: "/jobs"
		},
		{
			id: "applied",
			label: "Applied Jobs",
			icon: FileText,
			path: "/dashboard",
			search: { tab: "applied" }
		},
		{
			id: "saved",
			label: "Saved Jobs",
			icon: Bookmark,
			path: "/dashboard",
			search: { tab: "saved" }
		},
		{
			id: "profile",
			label: "My Profile",
			icon: User,
			path: "/dashboard",
			search: { tab: "profile" }
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-screen bg-[#F5F8FC] flex font-sans overflow-hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex-1 flex overflow-hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "w-64 bg-[#051B38] text-white flex flex-col justify-between shrink-0 h-full px-4 py-2 overflow-y-auto",
				style: { scrollbarWidth: "none" },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pt-1 pb-4 px-2 text-center border-b border-white/10 mb-3",
					children: [
						user.profilePhoto ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: user.profilePhoto,
							alt: user.fullName || "User",
							className: "size-20 rounded-full object-cover mx-auto mb-2 shadow-lg ring-4 ring-white/20 border-2 border-white"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-20 rounded-full bg-[#125BB5] text-white flex items-center justify-center font-black text-3xl mx-auto mb-2 shadow-lg ring-4 ring-white/10",
							children: user.fullName?.charAt(0).toUpperCase() || user.email?.charAt(0).toUpperCase() || "U"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-black text-lg text-white tracking-tight",
							children: user.fullName || user.email?.split("@")[0] || "User"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold text-white/70 truncate px-2",
							children: user.email || ""
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 inline-flex items-center gap-1.5 bg-[#FFC400]/20 border border-[#FFC400] text-[#FFC400] px-3 py-0.5 rounded-full text-[11px] font-black",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { className: "size-3.5" }), " Verified User"]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "space-y-1.5",
					children: tabs.map((item) => {
						const isActive = activeTab === item.id;
						const linkProps = item.search ? {
							to: item.path,
							search: item.search
						} : { to: item.path };
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							...linkProps,
							className: `relative w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all duration-200 ${isActive ? "bg-[#0E356A] text-white shadow-md" : "text-white/70 hover:bg-white/5 hover:text-white"}`,
							children: [
								isActive && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute left-0 top-1/2 -translate-y-1/2 w-1.5 h-6 bg-[#FFC400] rounded-r-full" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: `size-4.5 ${isActive ? "text-[#FFC400]" : "text-white/60"}` }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label })
							]
						}, item.id);
					})
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pt-4 border-t border-white/10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							dataStore.logout();
							navigate({ to: "/" });
						},
						className: "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold text-rose-400 hover:bg-rose-500/10 transition-colors",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Sign Out" })]
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex-1 bg-[#F5F8FC] p-6 overflow-y-auto h-full",
				style: { scrollbarWidth: "none" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-w-7xl mx-auto",
					children
				})
			})]
		})
	});
}
//#endregion
export { UserSidebarLayout as t };
