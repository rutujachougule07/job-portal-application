import { n as EmployerDashboard } from "./Dashboards-CYTAs71H.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/employer-C-pjt69R.js
var SplitComponent = EmployerDashboard;
//#endregion
export { SplitComponent as component };
