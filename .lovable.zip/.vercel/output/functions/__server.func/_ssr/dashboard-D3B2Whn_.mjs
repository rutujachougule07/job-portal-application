import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button--9UiOy7A.mjs";
import { t as dataStore } from "./data-store-CvMaHmbm.mjs";
import { b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { B as Plus, F as Save, Gt as ChevronDown, Ht as CircleCheck, It as CloudUpload, N as Search, U as PenLine, V as Phone, Wt as ChevronRight, X as Mail, Y as MapPin, c as User, cn as Award, g as TrendingUp, j as Settings, r as X, rn as Bookmark, tn as Briefcase, wt as FileText } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-CZUnWUIa.mjs";
import { n as JobCard } from "./JobCard-DBTRplir.mjs";
import { t as Route } from "./dashboard-DmDB93Gq.mjs";
import { t as UserSidebarLayout } from "./UserSidebarLayout-B5qjC2JI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-D3B2Whn_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function UserDashboard() {
	const navigate = useNavigate();
	const activeTab = Route.useSearch().tab || "overview";
	const [user, setUser] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const currentUser = dataStore.getCurrentUser();
		if (!currentUser) navigate({
			to: "/auth",
			search: {
				mode: "login",
				role: "worker"
			}
		});
		else setUser(currentUser);
	}, [navigate]);
	if (!user) return null;
	const applications = dataStore.getJobSeekerApplications(user.id);
	const savedJobRecords = dataStore.getSavedJobs(user.id);
	const savedJobsData = savedJobRecords.map((record) => {
		const dj = dataStore.getJobById(record.jobId);
		if (!dj) return null;
		return {
			id: dj.id,
			title: dj.title,
			company: dj.company,
			location: dj.location,
			salary: dj.salary,
			experience: dj.experience,
			type: dj.jobType,
			workMode: dj.workMode || "On-site",
			posted: dj.postedAgo || "Recently",
			initials: dj.initials || dj.company.slice(0, 2).toUpperCase(),
			category: dj.category,
			featured: dj.featured ?? false,
			openings: dj.vacancies ?? 1
		};
	}).filter(Boolean);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(UserSidebarLayout, {
		activeTab,
		children: [
			activeTab === "overview" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-6 animate-in fade-in duration-300",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full space-y-6 min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative bg-gradient-to-r from-[#EFF6FF] via-[#F4F8FF] to-[#EBEFFA] rounded-3xl p-6 sm:p-8 border border-blue-100 overflow-hidden shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute right-6 top-1/2 -translate-y-1/2 hidden xl:flex items-center gap-4 z-10 pointer-events-none",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "absolute -top-3 -left-12 bg-white px-3.5 py-1.5 rounded-2xl shadow-lg border border-blue-50 text-[11px] font-black text-[#10233F] whitespace-nowrap z-20 flex items-center gap-1.5 animate-bounce",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Find Your Dream Job !" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "/dashboard-hero.png",
										alt: "Hero Illustration",
										className: "h-44 object-contain drop-shadow-md",
										onError: (e) => {
											e.target.style.display = "none";
										}
									})]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative z-20 max-w-xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
										className: "text-2xl sm:text-3xl font-black text-[#10233F] tracking-tight",
										children: [
											"Welcome back, ",
											user.fullName?.split(" ")[0] || user.email?.split("@")[0] || "User",
											"! 👋"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[#5B6B7F] font-semibold mt-1.5 text-sm",
										children: "Here is what's happening with your job search today."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-3 gap-3 mt-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "bg-white/80 backdrop-blur-sm p-2.5 rounded-2xl border border-blue-100/60 flex items-center gap-2.5 shadow-sm",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "size-8 rounded-xl bg-blue-100 flex items-center justify-center text-[#125BB5] shrink-0",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4" })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "min-w-0",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-xs font-black text-[#10233F] truncate",
														children: "Find Opportunities"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-[10px] font-bold text-gray-400 truncate",
														children: "Discover the best jobs"
													})]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "bg-white/80 backdrop-blur-sm p-2.5 rounded-2xl border border-orange-100/60 flex items-center gap-2.5 shadow-sm",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "size-8 rounded-xl bg-orange-100 flex items-center justify-center text-orange-600 shrink-0",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-4" })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "min-w-0",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-xs font-black text-[#10233F] truncate",
														children: "Save Jobs"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-[10px] font-bold text-gray-400 truncate",
														children: "Keep track of interests"
													})]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "bg-white/80 backdrop-blur-sm p-2.5 rounded-2xl border border-emerald-100/60 flex items-center gap-2.5 shadow-sm",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "size-8 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-600 shrink-0",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-4" })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "min-w-0",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-xs font-black text-[#10233F] truncate",
														children: "Grow Your Career"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-[10px] font-bold text-gray-400 truncate",
														children: "Get hired faster"
													})]
												})]
											})
										]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-3 gap-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white p-5 rounded-3xl shadow-sm border border-[#DCE5F0] relative overflow-hidden flex flex-col justify-between",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between mb-4 relative z-10",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "size-10 bg-[#EBF3FF] rounded-xl flex items-center justify-center text-[#125BB5]",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-5" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[11px] font-black text-[#125BB5] bg-[#EBF3FF] px-3 py-1 rounded-full",
												children: "All time"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative z-10 flex items-end justify-between mt-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-xs font-bold text-[#5B6B7F] mb-1",
												children: "Applied Jobs"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-3xl font-black text-[#10233F]",
												children: applications.length
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
												to: "/dashboard",
												search: { tab: "applied" },
												className: "size-8 rounded-full border border-blue-200 text-[#125BB5] hover:bg-[#125BB5] hover:text-white flex items-center justify-center transition-all",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
											className: "absolute bottom-0 left-0 w-full h-12 text-[#EBF3FF]/60 pointer-events-none",
											viewBox: "0 0 100 30",
											preserveAspectRatio: "none",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
												d: "M0,20 Q25,5 50,20 T100,10 L100,30 L0,30 Z",
												fill: "currentColor"
											})
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white p-5 rounded-3xl shadow-sm border border-[#DCE5F0] relative overflow-hidden flex flex-col justify-between",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between mb-4 relative z-10",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "size-10 bg-[#FFF4E5] rounded-xl flex items-center justify-center text-[#D97706]",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-5" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[11px] font-black text-[#D97706] bg-[#FFF4E5] px-3 py-1 rounded-full",
												children: "Saved"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative z-10 flex items-end justify-between mt-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-xs font-bold text-[#5B6B7F] mb-1",
												children: "Saved Jobs"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-3xl font-black text-[#10233F]",
												children: savedJobRecords.length
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
												to: "/dashboard",
												search: { tab: "saved" },
												className: "size-8 rounded-full border border-orange-200 text-[#D97706] hover:bg-[#D97706] hover:text-white flex items-center justify-center transition-all",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
											className: "absolute bottom-0 left-0 w-full h-12 text-[#FFF4E5]/60 pointer-events-none",
											viewBox: "0 0 100 30",
											preserveAspectRatio: "none",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
												d: "M0,15 Q30,28 60,10 T100,20 L100,30 L0,30 Z",
												fill: "currentColor"
											})
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white p-5 rounded-3xl shadow-sm border border-[#DCE5F0] relative overflow-hidden flex flex-col justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between mb-4 relative z-10",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-10 bg-[#E8F8F0] rounded-xl flex items-center justify-center text-emerald-600",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-5" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[11px] font-black text-emerald-600 bg-[#E8F8F0] px-3 py-1 rounded-full",
											children: "This week"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative z-10 flex items-end justify-between mt-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-xs font-bold text-[#5B6B7F] mb-1",
											children: "Profile Views"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-3xl font-black text-[#10233F]",
												children: applications.length > 0 ? applications.length * 2 : 0
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-end gap-1 h-6",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-1.5 h-2 bg-emerald-200 rounded-full" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-1.5 h-3.5 bg-emerald-300 rounded-full" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-1.5 h-5 bg-emerald-400 rounded-full" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-1.5 h-6 bg-emerald-500 rounded-full" })
												]
											})]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/dashboard",
											search: { tab: "profile" },
											className: "size-8 rounded-full border border-emerald-200 text-emerald-600 hover:bg-emerald-600 hover:text-white flex items-center justify-center transition-all",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
										})]
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white p-2.5 rounded-2xl shadow-sm border border-[#DCE5F0] flex flex-col sm:flex-row items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1 flex items-center gap-3 px-4 w-full sm:w-auto h-11",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-gray-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										placeholder: "Search for jobs, skills, or companies...",
										className: "w-full bg-transparent border-none focus:outline-none text-xs font-semibold placeholder:text-gray-400 text-[#10233F]"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-full sm:w-px h-[1px] sm:h-7 bg-gray-200" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2.5 px-4 h-11 w-full sm:w-[220px] cursor-pointer hover:bg-gray-50 rounded-xl transition-colors",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4 text-gray-400 shrink-0" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "flex-1 text-xs font-black text-[#10233F] truncate",
											children: "Pune, Maharashtra"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-3.5 text-gray-400 shrink-0" })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									className: "w-full sm:w-auto h-11 px-7 rounded-xl bg-[#051B38] hover:bg-[#092B57] text-white font-bold text-xs shadow-md transition-all flex items-center gap-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/jobs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-3.5" }), " Search Jobs"]
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white rounded-3xl shadow-sm border border-[#DCE5F0] overflow-hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-5 border-b border-[#DCE5F0] flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-5 text-[#10233F]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-base font-black text-[#10233F]",
										children: "Recent Applications"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/dashboard",
									search: { tab: "applied" },
									className: "text-[#125BB5] font-bold text-xs hover:underline flex items-center gap-1",
									children: ["View All Applications ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-3" })]
								})]
							}), applications.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-x-auto",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full text-left text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-b border-gray-100 text-gray-400 font-bold bg-gray-50/50",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-6",
												children: "Job Title"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-6",
												children: "Company"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-6",
												children: "Applied Date"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-3 px-6",
												children: "Status"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "py-3 px-4 text-right" })
										]
									}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
										className: "divide-y divide-gray-100",
										children: applications.map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: "hover:bg-gray-50/60 transition-colors font-bold text-[#10233F]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-4 px-6 font-black",
													children: app.jobTitle
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-4 px-6 text-gray-600",
													children: app.companyName
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-4 px-6 text-gray-500",
													children: app.appliedDate
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-4 px-6",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "inline-flex items-center px-3 py-1 rounded-lg text-[11px] font-black bg-[#EBF3FF] text-[#125BB5]",
														children: app.status
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "py-4 px-4 text-right",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														className: "text-gray-400 hover:text-gray-600 p-1",
														children: "⋮"
													})
												})
											]
										}, app.id))
									})]
								})
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-8 text-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-bold text-[#5B6B7F]",
										children: "अद्याप कोणत्याही नोकरीसाठी अर्ज केलेला नाही (No Applications Yet)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-gray-400 mt-1",
										children: "तुम्ही नोकरीसाठी अर्ज केल्यावर येथे अर्जाची स्थिती दिसेल."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										className: "mt-4 bg-[#063B78] hover:bg-[#082F63] text-white font-bold text-xs px-6 h-9 rounded-xl",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/jobs",
											children: "नोकऱ्या शोधा (Find Jobs)"
										})
									})
								]
							})]
						})
					]
				})
			}),
			activeTab === "applied" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6 animate-in fade-in duration-500",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-3xl font-black text-[#10233F]",
					children: "Applied Jobs History"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bg-white rounded-2xl shadow-sm border border-[#DCE5F0] p-6 sm:p-8",
					children: applications.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center py-12",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[#5B6B7F] font-semibold text-lg",
							children: "You haven't applied to any jobs yet."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							className: "mt-6 bg-[#063B78] hover:bg-[#082F63] text-white",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/jobs",
								children: "Find Jobs to Apply"
							})
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-4",
						children: applications.map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-xl border border-gray-100 bg-gray-50/30 hover:bg-white hover:border-[#B8D3F2] hover:shadow-sm transition-all",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-black text-[#10233F] text-lg",
									children: app.jobTitle
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm font-semibold text-[#5B6B7F] mt-1",
									children: [
										app.companyName,
										" • ",
										app.location
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "shrink-0 flex flex-col sm:items-end gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-block px-3 py-1.5 rounded-lg text-xs font-black bg-[#EBF1F8] text-[#063B78] border border-[#B8D3F2]",
									children: ["Status: ", app.status]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold text-gray-500",
									children: ["Applied on ", app.appliedDate]
								})]
							})]
						}, app.id))
					})
				})]
			}),
			activeTab === "saved" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6 animate-in fade-in duration-500",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl font-black text-[#10233F]",
						children: "Saved Jobs"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm font-bold text-[#5B6B7F]",
						children: [savedJobsData.length, " jobs saved"]
					})]
				}), savedJobsData.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white rounded-2xl shadow-sm border border-[#DCE5F0] p-12 text-center flex flex-col items-center justify-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "inline-flex items-center justify-center size-20 bg-blue-50 rounded-full mb-5 text-[#063B78]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-10" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xl font-black text-[#10233F] mb-3",
							children: "No Saved Jobs"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[#5B6B7F] font-medium max-w-md mx-auto mb-6",
							children: "You haven't saved any jobs yet. Browse jobs and click the bookmark icon to save them for later."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							className: "bg-[#125BB5] hover:bg-[#063B78] text-white font-bold h-11 px-8 rounded-xl shadow-md transition-all",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/jobs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 mr-2" }), " Browse Jobs"]
							})
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-6",
					children: savedJobsData.map((job) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JobCard, { job }, job.id))
				})]
			}),
			activeTab === "profile" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserProfileSection, { user }),
			activeTab === "settings" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6 animate-in fade-in duration-300",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl font-black text-[#10233F] capitalize",
					children: "Settings"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white rounded-2xl shadow-sm border border-[#DCE5F0] p-12 text-center flex flex-col items-center justify-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "inline-flex items-center justify-center size-20 bg-blue-50 rounded-full mb-5 text-[#063B78]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-10" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xl font-black text-[#10233F] mb-3",
							children: "Settings Module"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[#5B6B7F] font-medium max-w-md mx-auto",
							children: "Configure notifications, account security, and portal preferences here."
						})
					]
				})]
			})
		]
	});
}
function UserProfileSection({ user }) {
	const [profile, setProfile] = (0, import_react.useState)(() => {
		const existing = dataStore.getJobSeekerProfile(user.id || user.email);
		if (existing) return {
			...existing,
			fullName: existing.fullName || user.fullName || user.email?.split("@")[0] || "User",
			email: existing.email || user.email || "",
			mobile: existing.mobile || user.mobile || ""
		};
		return {
			id: user.id || `usr-${Date.now()}`,
			email: user.email || "",
			fullName: user.fullName || user.email?.split("@")[0] || "User",
			mobile: user.mobile || "",
			profilePhoto: user.profilePhoto || "",
			currentLocation: "",
			preferredLocation: "",
			education: "",
			skills: [],
			experience: "",
			expectedSalary: "",
			category: "",
			subcategory: "",
			jobType: "Full Time",
			resume: "",
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
	});
	const [isEditing, setIsEditing] = (0, import_react.useState)(false);
	const [savedSuccess, setSavedSuccess] = (0, import_react.useState)(false);
	const [newSkillInput, setNewSkillInput] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const existing = dataStore.getJobSeekerProfile(user.id || user.email);
		if (existing) setProfile({
			...existing,
			fullName: existing.fullName || user.fullName || user.email?.split("@")[0] || "User",
			email: existing.email || user.email || "",
			mobile: existing.mobile || user.mobile || ""
		});
		else {
			const initial = {
				id: user.id || `usr-${Date.now()}`,
				email: user.email || "",
				fullName: user.fullName || user.email?.split("@")[0] || "User",
				mobile: user.mobile || "",
				profilePhoto: user.profilePhoto || "",
				currentLocation: "",
				preferredLocation: "",
				education: "",
				skills: [],
				experience: "",
				expectedSalary: "",
				category: "",
				subcategory: "",
				jobType: "Full Time",
				resume: "",
				createdAt: (/* @__PURE__ */ new Date()).toISOString()
			};
			dataStore.saveJobSeekerProfile(initial);
			setProfile(initial);
		}
	}, [user]);
	const handleSave = () => {
		dataStore.saveJobSeekerProfile(profile);
		setIsEditing(false);
		setSavedSuccess(true);
		setTimeout(() => setSavedSuccess(false), 4e3);
	};
	const addSkill = () => {
		if (newSkillInput.trim() && !profile.skills.includes(newSkillInput.trim())) {
			setProfile((prev) => ({
				...prev,
				skills: [...prev.skills, newSkillInput.trim()]
			}));
			setNewSkillInput("");
		}
	};
	const removeSkill = (skillToRemove) => {
		setProfile((prev) => ({
			...prev,
			skills: prev.skills.filter((s) => s !== skillToRemove)
		}));
	};
	const handlePhotoUploadInProfile = (e) => {
		const file = e.target.files?.[0];
		if (file) {
			if (file.size > 5242880) {
				toast.error("Photo size should be less than 5MB");
				return;
			}
			const reader = new FileReader();
			reader.onloadend = () => {
				const photoUrl = reader.result;
				const updated = {
					...profile,
					profilePhoto: photoUrl
				};
				setProfile(updated);
				dataStore.saveJobSeekerProfile(updated);
				toast.success("Profile photo updated successfully!");
			};
			reader.readAsDataURL(file);
		}
	};
	const handleResumeUpload = (e) => {
		const file = e.target.files?.[0];
		if (file) {
			if (file.size > 10485760) {
				toast.error("Resume file size should be less than 10MB");
				return;
			}
			const fileName = file.name;
			const reader = new FileReader();
			reader.onloadend = () => {
				const fileDataUrl = reader.result;
				const updated = {
					...profile,
					resume: fileDataUrl,
					resumeName: fileName
				};
				setProfile(updated);
				dataStore.saveJobSeekerProfile(updated);
				toast.success(`Resume "${fileName}" uploaded successfully!`);
			};
			reader.readAsDataURL(file);
		}
	};
	const hasResume = Boolean(profile.resume && !profile.resume.includes("_resume.pdf"));
	const resumeDisplayName = profile.resumeName || (hasResume ? profile.resume?.startsWith("data:") ? "Uploaded_Resume.pdf" : profile.resume : "No resume uploaded yet");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 animate-in fade-in duration-300",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-[#DCE5F0] shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl font-black text-[#10233F]",
					children: "My Profile"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-bold text-[#5B6B7F] mt-1",
					children: "Manage your personal profile, skills, experience, and contact details"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-3",
					children: isEditing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => setIsEditing(false),
						variant: "outline",
						className: "h-10 px-5 rounded-xl border-gray-200 text-gray-700 font-bold text-xs cursor-pointer",
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: handleSave,
						className: "h-10 px-6 rounded-xl bg-[#063B78] hover:bg-[#082F63] text-white font-bold text-xs shadow-md flex items-center gap-2 cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), " Save Changes"]
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => setIsEditing(true),
						className: "h-10 px-6 rounded-xl bg-[#063B78] hover:bg-[#082F63] text-white font-bold text-xs shadow-md flex items-center gap-2 cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "size-4" }), " Edit Profile"]
					})
				})]
			}),
			savedSuccess && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-emerald-50 border border-emerald-200 text-emerald-800 px-5 py-3.5 rounded-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top-2 duration-300",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5 text-emerald-600 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-bold",
					children: "Profile updated successfully! All your changes are saved."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white rounded-3xl p-6 sm:p-8 border border-[#DCE5F0] shadow-sm flex flex-col md:flex-row items-center md:items-start gap-6 relative overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative group",
					children: [profile.profilePhoto || user.profilePhoto ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: profile.profilePhoto || user.profilePhoto,
						alt: profile.fullName,
						className: "size-24 sm:size-28 rounded-3xl object-cover shadow-xl shrink-0 ring-4 ring-blue-50"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-24 sm:size-28 rounded-3xl bg-gradient-to-br from-[#051B38] to-[#125BB5] text-white flex items-center justify-center font-black text-4xl shadow-xl shrink-0 ring-4 ring-blue-50",
						children: profile.fullName?.charAt(0).toUpperCase() || "P"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "absolute -bottom-1 -right-1 p-2 rounded-xl bg-[#063B78] text-white cursor-pointer shadow-md hover:bg-[#082F63] transition-colors",
						title: "Upload new photo",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudUpload, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/*",
							onChange: handlePhotoUploadInProfile,
							className: "hidden"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 text-center md:text-left space-y-2 min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-2xl font-black text-[#10233F] tracking-tight",
							children: profile.fullName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-bold text-[#125BB5] mt-0.5",
							children: profile.category || "Not Specified"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-[#FFC400]/20 text-[#D97706] border border-[#FFC400]/40 self-center md:self-start",
							children: "Verified Candidate"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs font-bold text-[#5B6B7F]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-center md:justify-start gap-2 bg-[#F8FAFC] p-2.5 rounded-xl border border-gray-100",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-4 text-[#125BB5] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate",
									children: profile.email
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-center md:justify-start gap-2 bg-[#F8FAFC] p-2.5 rounded-xl border border-gray-100",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4 text-emerald-600 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: profile.mobile || "Not Specified" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-center md:justify-start gap-2 bg-[#F8FAFC] p-2.5 rounded-xl border border-gray-100",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4 text-orange-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate",
									children: profile.currentLocation || "Not Specified"
								})]
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-2 gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white p-6 rounded-3xl border border-[#DCE5F0] shadow-sm space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2.5 pb-3 border-b border-gray-100",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-5 text-[#063B78]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-base font-black text-[#10233F]",
							children: "Personal & Contact Details"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-bold text-[#5B6B7F] mb-1.5 block",
								children: "Full Name"
							}), isEditing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: profile.fullName,
								onChange: (e) => setProfile({
									...profile,
									fullName: e.target.value
								}),
								className: "h-11 font-bold text-xs"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-black text-[#10233F]",
								children: profile.fullName
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-bold text-[#5B6B7F] mb-1.5 block",
									children: "Email Address"
								}), isEditing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: profile.email,
									onChange: (e) => setProfile({
										...profile,
										email: e.target.value
									}),
									className: "h-11 font-bold text-xs"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-bold text-[#10233F]",
									children: profile.email
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-bold text-[#5B6B7F] mb-1.5 block",
									children: "Mobile Number"
								}), isEditing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: profile.mobile,
									onChange: (e) => setProfile({
										...profile,
										mobile: e.target.value
									}),
									className: "h-11 font-bold text-xs"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-bold text-[#10233F]",
									children: profile.mobile || "Not specified"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-bold text-[#5B6B7F] mb-1.5 block",
									children: "Current Location"
								}), isEditing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: profile.currentLocation,
									onChange: (e) => setProfile({
										...profile,
										currentLocation: e.target.value
									}),
									className: "h-11 font-bold text-xs"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-bold text-[#10233F]",
									children: profile.currentLocation || "Not specified"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-bold text-[#5B6B7F] mb-1.5 block",
									children: "Preferred Location"
								}), isEditing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: profile.preferredLocation,
									onChange: (e) => setProfile({
										...profile,
										preferredLocation: e.target.value
									}),
									className: "h-11 font-bold text-xs"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-bold text-[#10233F]",
									children: profile.preferredLocation || "Not specified"
								})] })]
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white p-6 rounded-3xl border border-[#DCE5F0] shadow-sm space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2.5 pb-3 border-b border-gray-100",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-5 text-[#063B78]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-base font-black text-[#10233F]",
							children: "Professional Preferences"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-bold text-[#5B6B7F] mb-1.5 block",
								children: "Job Category / Field"
							}), isEditing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: profile.category,
								onChange: (e) => setProfile({
									...profile,
									category: e.target.value
								}),
								className: "h-11 font-bold text-xs"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-black text-[#10233F]",
								children: profile.category || "Not specified"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-bold text-[#5B6B7F] mb-1.5 block",
								children: "Total Experience"
							}), isEditing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: profile.experience,
								onChange: (e) => setProfile({
									...profile,
									experience: e.target.value
								}),
								className: "h-11 font-bold text-xs"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-bold text-[#10233F]",
								children: profile.experience || "Not specified"
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-bold text-[#5B6B7F] mb-1.5 block",
								children: "Expected Salary"
							}), isEditing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: profile.expectedSalary,
								onChange: (e) => setProfile({
									...profile,
									expectedSalary: e.target.value
								}),
								className: "h-11 font-bold text-xs"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-bold text-[#10233F]",
								children: profile.expectedSalary || "Not specified"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-bold text-[#5B6B7F] mb-1.5 block",
								children: "Education / Degree"
							}), isEditing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: profile.education,
								onChange: (e) => setProfile({
									...profile,
									education: e.target.value
								}),
								className: "h-11 font-bold text-xs"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-bold text-[#10233F]",
								children: profile.education || "Not specified"
							})] })]
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white p-6 rounded-3xl border border-[#DCE5F0] shadow-sm space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between pb-3 border-b border-gray-100",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "size-5 text-[#063B78]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-base font-black text-[#10233F]",
								children: "Key Skills"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs font-bold text-gray-400",
							children: [profile.skills?.length || 0, " skills added"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2.5 pt-2",
						children: profile.skills?.map((skill, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-black bg-[#EBF3FF] text-[#125BB5] border border-blue-100 shadow-xs",
							children: [skill, isEditing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => removeSkill(skill),
								className: "hover:text-red-600 transition-colors cursor-pointer",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
							})]
						}, idx))
					}),
					isEditing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 pt-2 max-w-md",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "Type a new skill (e.g. React, SQL, Driving)...",
							value: newSkillInput,
							onChange: (e) => setNewSkillInput(e.target.value),
							onKeyDown: (e) => {
								if (e.key === "Enter") {
									e.preventDefault();
									addSkill();
								}
							},
							className: "h-10 text-xs font-bold"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: addSkill,
							className: "h-10 px-4 bg-[#063B78] text-white font-bold text-xs rounded-xl cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Add"]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white p-6 rounded-3xl border border-[#DCE5F0] shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-12 rounded-2xl bg-blue-50 text-[#125BB5] flex items-center justify-center shrink-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-black text-sm text-[#10233F]",
						children: "Uploaded Resume / CV"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-bold text-gray-500 mt-0.5",
						children: resumeDisplayName
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 w-full sm:w-auto",
					children: [hasResume && profile.resume && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: profile.resume,
						download: profile.resumeName || "resume.pdf",
						target: "_blank",
						rel: "noreferrer",
						className: "h-10 px-4 rounded-xl text-xs font-bold bg-blue-50 text-[#125BB5] hover:bg-blue-100 flex items-center gap-2 transition-colors",
						children: "View / Download Resume"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "h-10 px-5 rounded-xl text-xs font-bold border border-blue-200 text-[#125BB5] hover:bg-blue-50 flex items-center gap-2 w-full sm:w-auto justify-center cursor-pointer bg-white transition-colors shadow-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudUpload, { className: "size-4" }),
							" Upload New Resume",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								accept: ".pdf,.doc,.docx,image/*",
								onChange: handleResumeUpload,
								className: "hidden"
							})
						]
					})]
				})]
			})
		]
	});
}
//#endregion
export { UserDashboard as component };
