import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n, r as getCategoryTitle } from "./i18n-BcT9wMyM.mjs";
import { t as Button } from "./button--9UiOy7A.mjs";
import { t as dataStore } from "./data-store-CvMaHmbm.mjs";
import { Gt as ChevronDown, I as RotateCcw, N as Search, O as ShieldCheck, T as SlidersHorizontal, Tt as Factory, Y as MapPin, _t as HardHat, dn as ArrowLeft, g as TrendingUp, h as Truck, i as Wrench, ot as Laptop, pt as Hotel, r as X, rt as LayoutGrid, st as Landmark, tn as Briefcase, tt as List, y as Stethoscope, yt as GraduationCap } from "../_libs/lucide-react.mjs";
import { t as PublicHeader } from "./PublicHeader-CBfbRu9r.mjs";
import { t as PublicFooter } from "./PublicFooter-Ce7-btPc.mjs";
import { t as Input } from "./input-CZUnWUIa.mjs";
import { n as JobCard } from "./JobCard-DBTRplir.mjs";
import { t as UserSidebarLayout } from "./UserSidebarLayout-B5qjC2JI.mjs";
import { t as Route } from "./jobs.index-C9l-tH4E.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/jobs.index-CW6_CXIh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function JobsListingPage() {
	const { t, n, lang } = useI18n();
	const searchParams = Route.useSearch();
	const currentUser = dataStore.getCurrentUser();
	const [searchTerm, setSearchTerm] = (0, import_react.useState)("");
	const [categoryFilter, setCategoryFilter] = (0, import_react.useState)(searchParams.category || "all");
	const [subCategoryFilter, setSubCategoryFilter] = (0, import_react.useState)("all");
	const [locationFilter, setLocationFilter] = (0, import_react.useState)("all");
	const [salaryFilter, setSalaryFilter] = (0, import_react.useState)("all");
	const [experienceFilter, setExperienceFilter] = (0, import_react.useState)("all");
	const [typeFilter, setTypeFilter] = (0, import_react.useState)("all");
	const [sortBy, setSortBy] = (0, import_react.useState)("newest");
	const [mobileFilterOpen, setMobileFilterOpen] = (0, import_react.useState)(false);
	const [workModeFilter, setWorkModeFilter] = (0, import_react.useState)("all");
	(0, import_react.useEffect)(() => {
		setCategoryFilter(searchParams.category || "all");
		setSubCategoryFilter("all");
	}, [searchParams.category]);
	const dynamicMainCategories = (0, import_react.useMemo)(() => {
		const jobsList = dataStore.getAllJobs();
		const catMap = /* @__PURE__ */ new Map();
		jobsList.forEach((job) => {
			if (job.category && job.category.trim()) {
				const name = job.category.trim();
				const slug = name.toLowerCase().replace(/ & /g, "-").replace(/ /g, "-");
				if (!catMap.has(slug)) catMap.set(slug, {
					slug,
					name,
					count: 1
				});
				else catMap.get(slug).count += 1;
			}
		});
		return Array.from(catMap.values());
	}, []);
	const dynamicLocations = (0, import_react.useMemo)(() => {
		const locSet = /* @__PURE__ */ new Set();
		dataStore.getActiveJobs().forEach((job) => {
			if (job.location) locSet.add(job.location.trim());
		});
		return Array.from(locSet);
	}, []);
	(0, import_react.useMemo)(() => {
		if (!categoryFilter || categoryFilter === "all") return [];
		const jobsInCategory = dataStore.getActiveJobs().filter((j) => j.category.toLowerCase().replace(/ & /g, "-").replace(/ /g, "-") === categoryFilter.toLowerCase() || j.category.toLowerCase() === categoryFilter.toLowerCase());
		const subs = /* @__PURE__ */ new Set();
		jobsInCategory.forEach((j) => {
			if (j.subcategory) subs.add(j.subcategory);
		});
		return Array.from(subs).map((sub) => ({
			id: sub,
			label: sub
		}));
	}, [categoryFilter]);
	const resetFilters = () => {
		setSearchTerm("");
		setCategoryFilter("all");
		setLocationFilter("all");
		setSalaryFilter("all");
		setExperienceFilter("all");
		setTypeFilter("all");
		setWorkModeFilter("all");
		setSortBy("newest");
		setSubCategoryFilter("all");
	};
	const filteredJobs = (0, import_react.useMemo)(() => {
		return dataStore.getActiveJobs().map((dj) => ({
			id: dj.id,
			title: dj.title,
			company: dj.company,
			location: dj.location,
			salary: dj.salary,
			experience: dj.experience,
			type: dj.jobType,
			workMode: dj.workMode || "On-site",
			posted: dj.postedAgo || "Recently",
			initials: dj.initials || dj.company.slice(0, 2).toUpperCase(),
			category: dj.category,
			featured: dj.featured ?? false,
			openings: dj.vacancies ?? 1
		})).filter((job) => {
			const term = searchTerm.toLowerCase();
			const matchesSearch = !term || job.title.toLowerCase().includes(term) || job.company.toLowerCase().includes(term) || job.location.toLowerCase().includes(term) || job.category && job.category.toLowerCase().includes(term);
			let matchesCategory = false;
			if (categoryFilter === "all" || !categoryFilter) matchesCategory = true;
			else {
				const normalizedFilter = categoryFilter.toLowerCase().replace(/ & /g, "-").replace(/ /g, "-");
				const jobCatNorm = (job.category || "").toLowerCase().replace(/ & /g, "-").replace(/ /g, "-");
				matchesCategory = jobCatNorm === normalizedFilter || jobCatNorm.includes(normalizedFilter) || normalizedFilter.includes(jobCatNorm);
			}
			if (matchesCategory && subCategoryFilter !== "all" && subCategoryFilter) {
				const subClean = subCategoryFilter.toLowerCase();
				const titleClean = job.title.toLowerCase();
				const catClean = (job.category || "").toLowerCase();
				matchesCategory = titleClean.includes(subClean) || catClean.includes(subClean) || subClean.includes(titleClean);
			}
			const matchesLocation = locationFilter === "all" || job.location.toLowerCase().includes(locationFilter.toLowerCase());
			const matchesType = typeFilter === "all" || job.type.toLowerCase() === typeFilter.toLowerCase();
			const matchesWorkMode = workModeFilter === "all" || job.workMode.toLowerCase() === workModeFilter.toLowerCase();
			let matchesExp = true;
			if (experienceFilter !== "all") {
				const expStr = job.experience.toLowerCase();
				if (experienceFilter === "Fresher") matchesExp = expStr.includes("fresher") || expStr.includes("0-2");
				else if (experienceFilter === "1-3") matchesExp = expStr.includes("1-3") || expStr.includes("1+") || expStr.includes("0-2") || expStr.includes("2-5");
				else if (experienceFilter === "3-5") matchesExp = expStr.includes("3+") || expStr.includes("2-5") || expStr.includes("3-5") || expStr.includes("5+");
				else if (experienceFilter === "5+") matchesExp = expStr.includes("5+");
			}
			let matchesSalary = true;
			if (salaryFilter !== "all") {
				const minTarget = parseInt(salaryFilter);
				const match = job.salary.match(/\d+,\d+/);
				if (match) matchesSalary = parseInt(match[0].replace(",", "")) >= minTarget;
				else if (job.salary.includes("/day")) {
					const dayMatch = job.salary.match(/\d+/);
					if (dayMatch) matchesSalary = parseInt(dayMatch[0]) * 26 >= minTarget;
				}
			}
			return matchesSearch && matchesCategory && matchesLocation && matchesType && matchesWorkMode && matchesExp && matchesSalary;
		});
	}, [
		searchTerm,
		categoryFilter,
		locationFilter,
		typeFilter,
		workModeFilter,
		subCategoryFilter,
		experienceFilter,
		salaryFilter,
		lang
	]);
	const pageContent = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: `bg-[#F5F8FC] min-h-screen ${currentUser ? "" : "py-8"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `mx-auto ${currentUser ? "w-full" : "max-w-7xl px-4 sm:px-6 lg:px-8"}`,
			children: [(!categoryFilter || categoryFilter === "all") && !currentUser ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative p-10 sm:p-16 rounded-[2rem] text-white mb-10 shadow-2xl overflow-hidden bg-[#063B78]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute bottom-0 left-0 w-48 h-48 bg-[#FFC400]/10 rounded-full blur-2xl translate-y-1/3 -translate-x-1/4" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 max-w-4xl mx-auto text-center flex flex-col items-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-1.5 text-xs font-black uppercase tracking-widest text-[#FFC400] backdrop-blur-md mb-6 shadow-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4" }), t("jobs")]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "text-4xl sm:text-5xl lg:text-6xl font-black text-white leading-tight mb-4 tracking-tight drop-shadow-md",
								children: [
									t("jobsInRegion"),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-transparent bg-clip-text bg-gradient-to-r from-[#FFC400] to-[#FDE047] filter drop-shadow-sm",
										children: t("directCompanyContact")
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-base sm:text-lg text-white/90 font-medium max-w-2xl text-center shadow-black/10",
								children: t("jobsSubtext")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-10 w-full max-w-3xl grid sm:grid-cols-[1fr_0.8fr_auto] gap-2 bg-white/10 backdrop-blur-md p-2 rounded-2xl shadow-xl border border-white/20",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative flex items-center bg-white rounded-xl h-14 overflow-hidden",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-4 size-5 text-[#5B6B7F]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											placeholder: t("searchJobPlaceholder"),
											value: searchTerm,
											onChange: (e) => setSearchTerm(e.target.value),
											className: "pl-12 h-full border-0 bg-transparent text-sm text-[#10233F] font-bold focus-visible:ring-0 rounded-none shadow-none"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative flex items-center bg-white rounded-xl h-14 overflow-hidden",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "absolute left-4 size-5 text-[#125BB5]" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
												value: locationFilter,
												onChange: (e) => setLocationFilter(e.target.value),
												className: "w-full h-full border-0 bg-transparent text-sm font-bold text-[#10233F] pl-12 pr-10 focus:outline-none appearance-none cursor-pointer",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "all",
														children: t("allLocations")
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "mumbai",
														children: "Mumbai"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "pune",
														children: "Pune"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "chakan",
														children: "Chakan"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "bengaluru",
														children: "Bengaluru"
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "absolute right-4 size-5 text-[#5B6B7F] pointer-events-none" })
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										className: "btn-yellow h-14 font-black text-sm px-8 rounded-xl shadow-md hover:shadow-lg transition-shadow",
										children: t("search")
									})
								]
							})
						]
					})
				]
			}) : !currentUser && categoryFilter && categoryFilter !== "all" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-10 bg-white p-6 sm:p-8 rounded-[2rem] border border-[#DCE5F0] shadow-sm flex flex-col md:flex-row gap-6 justify-between items-start md:items-center relative overflow-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 right-0 w-48 h-48 bg-[#F5F8FC] rounded-full blur-3xl -translate-y-1/2 translate-x-1/4" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 flex flex-col items-start gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								setCategoryFilter("all");
								setSubCategoryFilter("all");
							},
							className: "px-4 py-2 rounded-full bg-[#F5F8FC] border border-[#DCE5F0] text-xs font-bold text-[#5B6B7F] flex items-center gap-2 hover:bg-[#10233F] hover:text-white transition-all shadow-sm group",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3.5 group-hover:-translate-x-1 transition-transform" }),
								" ",
								lang === "mr" ? "सर्व नोकऱ्या पहा" : "All Jobs"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-16 rounded-2xl bg-gradient-to-br from-[#063B78] to-[#125BB5] flex items-center justify-center text-white shadow-lg shadow-[#063B78]/20",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-7" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-3xl sm:text-4xl font-black text-[#082F63] capitalize tracking-tight",
								children: getCategoryTitle(categoryFilter, lang)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm font-bold text-[#125BB5] mt-1.5 flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse" }),
									filteredJobs.length,
									" ",
									lang === "mr" ? "सक्रिय नोकऱ्या" : "Active Jobs"
								]
							})] })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-full md:w-auto relative z-10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative flex items-center w-full md:w-[320px] group",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-4 size-5 text-[#5B6B7F] group-focus-within:text-[#125BB5] transition-colors" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: lang === "mr" ? "नोकरी शोधा..." : "Search in category...",
								value: searchTerm,
								onChange: (e) => setSearchTerm(e.target.value),
								className: "pl-12 h-14 border-2 border-[#DCE5F0] bg-[#F5F8FC] rounded-xl text-sm text-[#10233F] font-bold focus-visible:ring-0 focus-visible:border-[#125BB5] shadow-sm transition-all"
							})]
						})
					})
				]
			}) : null, !categoryFilter || categoryFilter === "all" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-10 w-full",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center text-center max-w-2xl mx-auto mb-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-14 rounded-2xl bg-[#063B78] text-[#FFC400] flex items-center justify-center shadow-lg mb-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, { className: "size-7" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-3xl sm:text-4xl font-black text-[#10233F]",
							children: lang === "mr" ? "मुख्य नोकरी श्रेणी (Main Job Categories)" : "Main Job Categories"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm font-bold text-[#5B6B7F]",
							children: lang === "mr" ? "नोकऱ्या पाहण्यासाठी खालील कोणत्याही श्रेणी कार्डवर क्लिक करा" : "Select any category card to view jobs in that section"
						})
					]
				}), dynamicMainCategories.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5 max-w-6xl mx-auto",
					children: dynamicMainCategories.map(({ slug, name, count }) => {
						let CategoryIcon = Briefcase;
						const lc = name.toLowerCase();
						if (lc.includes("construction") || lc.includes("builder") || lc.includes("civil")) CategoryIcon = HardHat;
						else if (lc.includes("software") || lc.includes("it") || lc.includes("develop") || lc.includes("computer")) CategoryIcon = Laptop;
						else if (lc.includes("engineer") || lc.includes("tech") || lc.includes("mechanic")) CategoryIcon = Wrench;
						else if (lc.includes("health") || lc.includes("medic") || lc.includes("doctor") || lc.includes("nurse")) CategoryIcon = Stethoscope;
						else if (lc.includes("financ") || lc.includes("account") || lc.includes("bank")) CategoryIcon = Landmark;
						else if (lc.includes("sales") || lc.includes("market")) CategoryIcon = TrendingUp;
						else if (lc.includes("educat") || lc.includes("teach") || lc.includes("school")) CategoryIcon = GraduationCap;
						else if (lc.includes("manufact") || lc.includes("factory") || lc.includes("production") || lc.includes("industrial")) CategoryIcon = Factory;
						else if (lc.includes("logistic") || lc.includes("transport") || lc.includes("driver") || lc.includes("delivery")) CategoryIcon = Truck;
						else if (lc.includes("hotel") || lc.includes("restaurant") || lc.includes("hospitality")) CategoryIcon = Hotel;
						else if (lc.includes("security") || lc.includes("guard")) CategoryIcon = ShieldCheck;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								setCategoryFilter(slug);
								setSubCategoryFilter("all");
							},
							className: "group p-6 rounded-3xl border border-[#DCE5F0] bg-white text-left transition-all duration-300 hover:border-[#063B78] hover:shadow-xl hover:-translate-y-1 flex flex-col justify-between cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between mb-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-14 rounded-2xl bg-[#063B78]/10 text-[#063B78] flex items-center justify-center group-hover:bg-[#063B78] group-hover:text-white transition-colors",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryIcon, { className: "size-7" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-black px-3.5 py-1.5 rounded-full bg-[#EBF1F8] text-[#063B78] group-hover:bg-[#063B78] group-hover:text-white transition-colors",
									children: [
										count,
										" ",
										lang === "mr" ? "नोकऱ्या" : "Jobs"
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg font-black text-[#10233F] group-hover:text-[#063B78] leading-tight",
								children: getCategoryTitle(name, lang) || name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold text-[#5B6B7F] mt-2",
								children: lang === "mr" ? `${count} नोकरी जाहिराती उपलब्ध` : `${count} Active Listings`
							})] })]
						}, slug);
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-realjob p-12 text-center bg-white rounded-3xl border border-[#DCE5F0] max-w-xl mx-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "mx-auto size-14 text-[#5B6B7F] mb-4" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xl font-black text-[#10233F]",
							children: "कोणतीही नोकरी श्रेणी उपलब्ध नाही"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold text-[#5B6B7F] mt-2",
							children: "अद्याप ॲडमिन कडून कोणतीही नोकरी पोस्ट केलेली नाही. ॲडमिन नोकरी पोस्ट करेल तेव्हा येथे श्रेणी दिसेल."
						})
					]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full flex flex-col gap-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white p-6 rounded-3xl border border-[#DCE5F0] shadow-sm flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 flex-wrap",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-black uppercase tracking-wider text-[#063B78] bg-[#EBF1F8] px-3 py-1 rounded-full border border-[#063B78]/10",
								children: lang === "mr" ? "निवडलेली श्रेणी" : "Selected Category"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs font-extrabold text-[#5B6B7F]",
								children: [
									"• ",
									filteredJobs.length,
									" ",
									lang === "mr" ? "नोकऱ्या उपलब्ध" : "Jobs Available"
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl sm:text-3xl font-black text-[#10233F] mt-1.5 capitalize tracking-tight",
							children: getCategoryTitle(categoryFilter, lang) || categoryFilter
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center gap-3 flex-wrap",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => {
									setCategoryFilter("all");
									setSubCategoryFilter("all");
								},
								className: "px-5 py-2.5 rounded-xl bg-[#063B78] text-white text-xs font-black hover:bg-[#082F63] transition-all shadow-md flex items-center gap-2 cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), lang === "mr" ? "सर्व श्रेणी कडे जा (All Categories)" : "Back to All Categories"]
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white p-4 rounded-2xl border border-[#DCE5F0] shadow-sm flex flex-wrap items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 flex-wrap",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 px-3 py-2 bg-[#063B78]/10 text-[#063B78] rounded-xl text-xs font-black mr-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("filters") })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: experienceFilter,
										onChange: (e) => setExperienceFilter(e.target.value),
										className: "h-10 rounded-xl border border-[#DCE5F0] bg-[#F5F8FC] pl-3 pr-8 text-xs font-bold text-[#10233F] focus:border-[#063B78] appearance-none cursor-pointer",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: "all",
												children: ["🎓 ", lang === "mr" ? "अनुभव (सर्व)" : "Experience: All"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Fresher",
												children: "Fresher / फ्रेसर"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: "1-3",
												children: ["1-3 ", lang === "mr" ? "वर्षे" : "Years"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: "3-5",
												children: ["3-5 ", lang === "mr" ? "वर्षे" : "Years"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: "5+",
												children: ["5+ ", lang === "mr" ? "वर्षे" : "Years"]
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "absolute right-2.5 top-1/2 -translate-y-1/2 size-3.5 text-[#5B6B7F] pointer-events-none" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: salaryFilter,
										onChange: (e) => setSalaryFilter(e.target.value),
										className: "h-10 rounded-xl border border-[#DCE5F0] bg-[#F5F8FC] pl-3 pr-8 text-xs font-bold text-[#10233F] focus:border-[#063B78] appearance-none cursor-pointer",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: "all",
												children: ["💰 ", lang === "mr" ? "पगार (सर्व)" : "Salary: All"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "10000",
												children: "₹10,000+ / mo"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "15000",
												children: "₹15,000+ / mo"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "20000",
												children: "₹20,000+ / mo"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "25000",
												children: "₹25,000+ / mo"
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "absolute right-2.5 top-1/2 -translate-y-1/2 size-3.5 text-[#5B6B7F] pointer-events-none" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: typeFilter,
										onChange: (e) => setTypeFilter(e.target.value),
										className: "h-10 rounded-xl border border-[#DCE5F0] bg-[#F5F8FC] pl-3 pr-8 text-xs font-bold text-[#10233F] focus:border-[#063B78] appearance-none cursor-pointer",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: "all",
												children: ["💼 ", t("allTypes")]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Full Time",
												children: t("fullTime")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Part Time",
												children: t("partTime")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Contract",
												children: t("contract")
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "absolute right-2.5 top-1/2 -translate-y-1/2 size-3.5 text-[#5B6B7F] pointer-events-none" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: workModeFilter,
										onChange: (e) => setWorkModeFilter(e.target.value),
										className: "h-10 rounded-xl border border-[#DCE5F0] bg-[#F5F8FC] pl-3 pr-8 text-xs font-bold text-[#10233F] focus:border-[#063B78] appearance-none cursor-pointer",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: "all",
												children: ["🏢 ", lang === "mr" ? "मोड (सर्व)" : "Mode: All"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Work From Home",
												children: "🏠 WFH / Remote"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "On-site",
												children: "🏢 On-site"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Hybrid",
												children: "🔄 Hybrid"
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "absolute right-2.5 top-1/2 -translate-y-1/2 size-3.5 text-[#5B6B7F] pointer-events-none" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: locationFilter,
										onChange: (e) => setLocationFilter(e.target.value),
										className: "h-10 rounded-xl border border-[#DCE5F0] bg-[#F5F8FC] pl-3 pr-8 text-xs font-bold text-[#10233F] focus:border-[#063B78] appearance-none cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
											value: "all",
											children: ["📍 ", t("allLocations")]
										}), dynamicLocations.map((loc) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: loc.toLowerCase(),
											children: loc
										}, loc))]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "absolute right-2.5 top-1/2 -translate-y-1/2 size-3.5 text-[#5B6B7F] pointer-events-none" })]
								}),
								(experienceFilter !== "all" || salaryFilter !== "all" || typeFilter !== "all" || workModeFilter !== "all" || locationFilter !== "all") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: resetFilters,
									className: "h-10 px-3.5 rounded-xl bg-amber-50 text-amber-700 border border-amber-200 text-xs font-extrabold hover:bg-amber-100 transition-colors flex items-center gap-1.5 cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3.5" }), t("reset")]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs font-extrabold text-[#10233F] flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, { className: "size-3.5 text-[#063B78]" }),
									t("totalJobsCount"),
									": ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[#063B78] font-black text-sm",
										children: n(filteredJobs.length)
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5 bg-[#F5F8FC] rounded-xl p-1 border border-[#DCE5F0]/50",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-bold text-[#5B6B7F] pl-2",
									children: t("sortByLabel")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: sortBy,
									onChange: (e) => setSortBy(e.target.value),
									className: "h-8 rounded-lg border-none bg-white shadow-xs px-2.5 text-xs font-bold text-[#10233F] focus:ring-0 appearance-none cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "newest",
										children: t("newestFirst")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "title",
										children: t("byTitle")
									})]
								})]
							})]
						})]
					}),
					filteredJobs.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `grid grid-cols-1 ${filteredJobs.length === 1 ? "" : "xl:grid-cols-2"} gap-6`,
						children: filteredJobs.map((job) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JobCard, { job }, job.id))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "card-realjob p-12 text-center bg-white rounded-3xl border border-[#DCE5F0]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "mx-auto size-14 text-[#5B6B7F] mb-4" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xl font-black text-[#10233F]",
								children: "या श्रेणीमध्ये कोणतीही नोकरी उपलब्ध नाही (No Jobs Found in this Category)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold text-[#5B6B7F] mt-2",
								children: "या श्रेणीमध्ये अद्याप कोणतीही नवीन नोकरी पोस्ट केलेली नाही. ॲडमिन ने नवीन नोकरी पोस्ट केल्यावर ती येथे दिसेल."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => {
									setCategoryFilter("all");
									setSubCategoryFilter("all");
								},
								className: "mt-5 btn-yellow text-xs font-bold px-6",
								children: lang === "mr" ? "सर्व श्रेणी कडे जा (Back to Categories)" : "Back to Categories"
							})
						]
					})
				]
			})]
		}), mobileFilterOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-50 bg-[#082F63]/60 backdrop-blur-sm flex justify-end",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full max-w-xs bg-white h-full p-6 overflow-y-auto shadow-2xl flex flex-col justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between pb-4 border-b border-[#DCE5F0] mb-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-black text-base text-[#10233F]",
						children: t("filters")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setMobileFilterOpen(false),
						className: "p-1 text-[#5B6B7F]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-6" })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
							children: lang === "mr" ? "अनुभव" : "Experience"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: experienceFilter,
							onChange: (e) => setExperienceFilter(e.target.value),
							className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "all",
									children: lang === "mr" ? "सर्व अनुभव" : "Any Experience"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Fresher",
									children: lang === "mr" ? "फ्रेसर" : "Fresher"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: "1-3",
									children: ["1-3 ", lang === "mr" ? "वर्षे" : "Years"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: "3-5",
									children: ["3-5 ", lang === "mr" ? "वर्षे" : "Years"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: "5+",
									children: ["5+ ", lang === "mr" ? "वर्षे" : "Years"]
								})
							]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
							children: lang === "mr" ? "किमान पगार" : "Minimum Salary"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: salaryFilter,
							onChange: (e) => setSalaryFilter(e.target.value),
							className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "all",
									children: lang === "mr" ? "कोणताही पगार" : "Any Salary"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: "10000",
									children: ["₹10,000+ / ", lang === "mr" ? "महिना" : "mo"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: "15000",
									children: ["₹15,000+ / ", lang === "mr" ? "महिना" : "mo"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: "20000",
									children: ["₹20,000+ / ", lang === "mr" ? "महिना" : "mo"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: "25000",
									children: ["₹25,000+ / ", lang === "mr" ? "महिना" : "mo"]
								})
							]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
							children: t("jobTypeLabel")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: typeFilter,
							onChange: (e) => setTypeFilter(e.target.value),
							className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "all",
									children: t("allTypes")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Full-time",
									children: t("fullTime")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Part-time",
									children: t("partTime")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Contract",
									children: t("contract")
								})
							]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-2 uppercase",
							children: "Work Mode / मोड"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: workModeFilter,
							onChange: (e) => setWorkModeFilter(e.target.value),
							className: "w-full h-10 rounded-lg border border-[#DCE5F0] bg-[#F5F8FC] px-3 text-xs font-bold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "all",
									children: "All Modes / सर्व मोड"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Remote",
									children: "🏠 Work From Home (WFH)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "On-site",
									children: "🏢 On-site (Office / Site)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Hybrid",
									children: "🔄 Hybrid"
								})
							]
						})] })
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pt-6 border-t border-[#DCE5F0] grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: resetFilters,
						className: "text-xs font-bold",
						children: t("reset")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => setMobileFilterOpen(false),
						className: "btn-yellow text-xs font-extrabold",
						children: t("continue")
					})]
				})]
			})
		})]
	});
	if (currentUser) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserSidebarLayout, {
		activeTab: "find-jobs",
		children: pageContent
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicHeader, {}),
		pageContent,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
	] });
}
//#endregion
export { JobsListingPage as component };
