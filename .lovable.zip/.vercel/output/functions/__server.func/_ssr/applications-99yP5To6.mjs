import { t as ApplicationsPage } from "./Dashboards-BuSAs1ES.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/applications-99yP5To6.js
var SplitComponent = ApplicationsPage;
//#endregion
export { SplitComponent as component };
