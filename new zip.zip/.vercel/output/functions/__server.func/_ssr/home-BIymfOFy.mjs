import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n } from "./i18n-CEAlH7ip.mjs";
import { t as Button } from "./button--9UiOy7A.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as dataStore } from "./data-store-BCcScpg-.mjs";
import { A as Search, Bt as Building2, Mt as CircleCheck, Ot as Clock3, Q as LayoutGrid, St as Ellipsis, T as ShieldCheck, Tt as Code, Ut as Bookmark, Vt as Briefcase, W as MapPin, Xt as ArrowRight, a as Wallet, ct as HeartHandshake, ft as GraduationCap, pt as Globe, s as Users, st as HeartPulse, t as Zap, tt as Landmark, x as Sparkles } from "../_libs/lucide-react.mjs";
import { t as PublicHeader } from "./PublicHeader-D1uPireo.mjs";
import { t as PublicFooter } from "./PublicFooter-zsmeitx6.mjs";
import { t as Input } from "./input-CZUnWUIa.mjs";
import { t as career_team_default } from "./career-team-C8fmOxDX.mjs";
import { t as PopularCategories } from "./PopularCategories-CnZ-P_9y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/home-BIymfOFy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PopularJobs() {
	const { t } = useI18n();
	const [activeTab, setActiveTab] = (0, import_react.useState)("all");
	const [savedJobs, setSavedJobs] = (0, import_react.useState)({});
	const toggleSave = (id) => {
		setSavedJobs((prev) => ({
			...prev,
			[id]: !prev[id]
		}));
	};
	const filterTabs = [
		{
			id: "all",
			labelKey: "allJobsTab",
			icon: LayoutGrid
		},
		{
			id: "tech",
			labelKey: "itSoftwareTab",
			icon: Code
		},
		{
			id: "health",
			labelKey: "healthcareTab",
			icon: HeartPulse
		},
		{
			id: "banking",
			labelKey: "bankingTab",
			icon: Landmark
		},
		{
			id: "edu",
			labelKey: "educationTab",
			icon: GraduationCap
		},
		{
			id: "mkt",
			labelKey: "marketingTab",
			icon: Briefcase
		}
	];
	const jobsList = dataStore.getAllJobs().map((j) => ({
		id: j.id,
		title: j.title,
		company: j.company,
		location: j.location,
		salary: j.salary,
		posted: j.postedAgo || "Just now",
		type: j.jobType || "Full Time",
		exp: j.experience || "Any",
		mode: j.workMode || "On-site",
		featured: true,
		badgeColor: "bg-[#063B78]",
		btnColor: "bg-[#063B78] hover:bg-[#082F63] text-white",
		waveGlow: "from-[#063B78]/15 via-[#063B78]/5",
		logoSvg: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid size-12 shrink-0 place-items-center rounded-2xl bg-[#063B78] text-white shadow-md font-black text-[#FFC400] text-sm",
			children: j.initials || (j.company ? j.company.substring(0, 2).toUpperCase() : "RJ")
		})
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative bg-[#F8F7F4] py-20 sm:py-28 overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -left-20 top-1/2 h-96 w-96 -translate-y-1/2 rounded-full bg-[#D4AF37]/10 blur-3xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -right-20 top-1/2 h-96 w-96 -translate-y-1/2 rounded-full bg-[#1F2937]/5 blur-3xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col items-start text-left max-w-2xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "inline-flex items-center gap-2 rounded-full border border-[#D4AF37]/40 bg-[#FFFDF5] px-4 py-1 text-[11px] font-bold uppercase tracking-widest text-[#1F2937] shadow-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full bg-[#D4AF37]" }), t("popularJobsEyebrow")]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-4 font-display text-4xl font-bold text-[#111827] sm:text-5xl",
									children: t("popularJobs")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 max-w-xl text-sm leading-6 text-[#374151] sm:text-base",
									children: t("popularJobsSubtitle")
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative shrink-0 sm:ml-auto sm:self-end pb-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								className: "absolute -right-3 -top-5 size-7 text-[#D4AF37] opacity-90",
								viewBox: "0 0 24 24",
								fill: "none",
								stroke: "currentColor",
								strokeWidth: "2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/jobs",
								className: "inline-flex items-center gap-2 rounded-full bg-[#1F2937] px-7 py-3 text-sm font-semibold text-white shadow-lg transition-all duration-200 hover:bg-[#D4AF37] hover:text-[#1F2937] hover:shadow-xl hover:-translate-y-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("browseJobs") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap items-center gap-2.5 overflow-x-auto pb-2 scrollbar-none",
						children: [filterTabs.map((tab) => {
							const Icon = tab.icon;
							const isActive = activeTab === tab.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setActiveTab(tab.id),
								className: `inline-flex items-center gap-2 rounded-full px-4 py-2 text-xs font-semibold transition-all duration-200 shadow-sm ${isActive ? "bg-[#1F2937] text-white shadow-md ring-2 ring-[#D4AF37]/50" : "bg-white border border-[#E5E2DA] text-[#374151] hover:bg-[#F2EFEC] hover:border-[#1F2937]/30"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: `size-3.5 ${isActive ? "text-[#D4AF37]" : "text-[#374151]"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(tab.labelKey) })]
							}, tab.id);
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "inline-flex items-center justify-center size-8 rounded-full bg-white border border-[#E5E2DA] text-[#374151] hover:bg-[#F2EFEC]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-4" })
						})]
					}),
					jobsList.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 p-12 text-center bg-white rounded-3xl border border-[#E5E2DA] shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-12 mx-auto text-[#063B78] mb-3 opacity-60" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg font-black text-[#10233F]",
								children: "अद्याप कोणतीही नोकरी जोडलेली नाही (No Jobs Posted Yet)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold text-[#5B6B7F] mt-1",
								children: "ॲडमिन कंट्रोल पॅनेलवरून नवीन नोकऱ्या जोडल्यावर त्या येथे थेट दिसतील."
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 grid gap-6 lg:grid-cols-2",
						children: jobsList.map((job) => {
							const isSaved = !!savedJobs[job.id];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "group relative flex flex-col justify-between overflow-hidden rounded-3xl border border-[#E5E2DA] bg-white p-6 shadow-sm transition-all duration-300 hover:-translate-y-1.5 hover:border-[#D4AF37]/50 hover:shadow-xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `pointer-events-none absolute -right-12 -top-12 size-44 rounded-full bg-gradient-to-br ${job.waveGlow} to-transparent blur-xl` }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative z-10 flex items-start gap-4",
										children: [job.logoSvg, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0 flex-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-start justify-between gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-wrap items-center gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
														to: "/jobs/$jobId",
														params: { jobId: job.id },
														className: "font-display text-xl font-bold text-[#111827] transition-colors hover:text-[#D4AF37]",
														children: job.title
													}), job.featured && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "rounded-full border border-[#D4AF37]/40 bg-[#FFFDF5] px-2.5 py-0.5 text-[10px] font-extrabold uppercase tracking-wide text-[#B59124]",
														children: t("featured")
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "mt-1 flex items-center gap-1.5 text-xs font-semibold text-[#374151]",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3.5 text-muted-foreground" }), job.company]
												})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => toggleSave(job.id),
													className: `grid size-9 shrink-0 place-items-center rounded-full border transition-all shadow-sm ${isSaved ? "border-[#D4AF37] bg-[#FFFDF5] text-[#D4AF37]" : "border-[#E5E2DA] bg-white text-[#374151] hover:bg-[#F2EFEC]"}`,
													"aria-label": "Save job",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: `size-4 ${isSaved ? "fill-current" : ""}` })
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-[#374151]",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "inline-flex items-center gap-1.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5 text-muted-foreground" }), job.location]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "inline-flex items-center gap-1.5 font-semibold text-[#111827]",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-3.5 text-muted-foreground" }), job.salary]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "inline-flex items-center gap-1.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { className: "size-3.5 text-muted-foreground" }), job.posted]
													})
												]
											})]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative z-10 mt-6 flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-[#F2EFEC]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `rounded-full ${job.badgeColor} px-3.5 py-1 text-xs font-bold text-white shadow-sm`,
													children: job.type === "Full Time" || job.type === "Full-time" ? t("fullTime") : job.type
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "rounded-full bg-[#F2EFEC] border border-[#E5E2DA] px-3.5 py-1 text-xs font-bold text-[#374151]",
													children: job.exp
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "rounded-full bg-[#F2EFEC] border border-[#E5E2DA] px-3.5 py-1 text-xs font-bold text-[#374151]",
													children: job.mode === "On-site" ? t("onSite") : job.mode === "Hybrid" ? t("hybrid") : t("remote")
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/jobs/$jobId",
											params: { jobId: job.id },
											className: `inline-flex items-center gap-1.5 rounded-full ${job.btnColor} px-6 py-2.5 text-xs font-bold text-white shadow-md transition-all duration-200 hover:shadow-lg hover:-translate-y-0.5`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("apply") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5" })]
										})]
									})
								]
							}, job.id);
						})
					})
				]
			})
		]
	});
}
function HomePage() {
	const { t, lang } = useI18n();
	const [searchTab, setSearchTab] = (0, import_react.useState)("job");
	const [keyword, setKeyword] = (0, import_react.useState)("");
	const [location, setLocation] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("all");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "bg-[#F5F8FC]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "relative isolate min-h-[640px] overflow-hidden",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: career_team_default,
							alt: "REAL JOB India Workforce & Construction Workers",
							width: 1600,
							height: 1e3,
							className: "absolute inset-0 h-full w-full object-cover object-center"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-hero-overlay" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative mx-auto flex min-h-[640px] max-w-7xl flex-col justify-center px-4 py-20 sm:px-6 lg:px-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "max-w-3xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mb-4 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-1.5 text-xs font-bold uppercase tracking-wider text-[#FFC400] backdrop-blur",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" }), t("heroBadge")]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
										className: "font-display text-4xl font-black leading-[1.1] text-white sm:text-6xl lg:text-7xl",
										children: [
											t("heroTitleLine1"),
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[#FFC400]",
												children: t("heroTitleLine2")
											}),
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
											t("heroTitleLine3")
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-lg sm:text-xl font-bold text-white/90",
										children: t("heroSubtitle")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-8 flex flex-wrap gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											asChild: true,
											size: "lg",
											className: "btn-yellow h-13 px-8 text-sm font-black shadow-md",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/jobs",
												children: [t("findJob"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "ml-1 size-4" })]
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											asChild: true,
											size: "lg",
											className: "btn-navy h-13 px-8 text-sm font-bold border border-white/30",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/workers",
												children: [t("hireTalent"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "ml-1.5 size-4" })]
											})
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-10 flex flex-wrap gap-6 text-xs sm:text-sm font-bold text-white/90",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-[#FFC400]" }), t("trustPhone")]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-[#FFC400]" }), t("trustCommission")]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-[#FFC400]" }), t("trustVerified")]
											})
										]
									})
								]
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "relative z-20 mx-auto -mt-12 max-w-6xl px-4 sm:px-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-[#DCE5F0] bg-white p-5 shadow-xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 mb-4 border-b border-[#DCE5F0] pb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setSearchTab("job"),
								className: `px-5 py-2 rounded-lg font-black text-xs transition-all ${searchTab === "job" ? "bg-[#063B78] text-white shadow-xs" : "text-[#5B6B7F] hover:bg-[#F5F8FC]"}`,
								children: t("searchJobTab")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setSearchTab("worker"),
								className: `px-5 py-2 rounded-lg font-black text-xs transition-all ${searchTab === "worker" ? "bg-[#063B78] text-white shadow-xs" : "text-[#5B6B7F] hover:bg-[#F5F8FC]"}`,
								children: t("searchWorkerTab")
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 md:grid-cols-[1fr_0.8fr_0.8fr_auto]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative flex items-center bg-[#F5F8FC] rounded-xl px-3 border border-[#DCE5F0]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-[#063B78] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: t("searchPlaceholder"),
										value: keyword,
										onChange: (e) => setKeyword(e.target.value),
										className: "h-11 border-0 bg-transparent text-xs font-bold text-[#10233F] focus-visible:ring-0"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative flex items-center bg-[#F5F8FC] rounded-xl px-3 border border-[#DCE5F0]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4 text-[#125BB5] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: t("location"),
										value: location,
										onChange: (e) => setLocation(e.target.value),
										className: "h-11 border-0 bg-transparent text-xs font-bold text-[#10233F] focus-visible:ring-0"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative flex items-center bg-[#F5F8FC] rounded-xl px-3 border border-[#DCE5F0]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4 text-[#063B78] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: category,
										onChange: (e) => setCategory(e.target.value),
										className: "w-full h-11 border-0 bg-transparent text-xs font-bold text-[#10233F] focus:outline-none",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "all",
												children: t("allCategories")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "construction",
												children: "Construction"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "it-software",
												children: "IT & Software"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "engineering",
												children: "Engineering"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "healthcare-medical",
												children: "Healthcare & Medical"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "finance-accounting",
												children: "Finance & Accounting"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "sales-marketing",
												children: "Sales & Marketing"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "education",
												children: "Education"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "manufacturing",
												children: "Manufacturing"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "hr-recruitment",
												children: "HR & Recruitment"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "hospitality-tourism",
												children: "Hospitality & Tourism"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "logistics-transport",
												children: "Logistics & Transport"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "government-public",
												children: "Government & Public Sector"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "legal",
												children: "Legal"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "architecture-design",
												children: "Architecture & Interior Design"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "retail-ecommerce",
												children: "Retail & E-commerce"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "customer-service-bpo",
												children: "Customer Service & BPO"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "design-creative",
												children: "Design & Creative"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "media-communication",
												children: "Media & Communication"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "agriculture-farming",
												children: "Agriculture & Farming"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "science-research",
												children: "Science & Research"
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									size: "lg",
									className: "btn-yellow h-11 px-8 font-black text-xs",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: searchTab === "job" ? "/jobs" : "/workers",
										search: { ...category !== "all" ? { category } : {} },
										children: searchTab === "job" ? t("jobs") : t("workers")
									})
								})
							]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopularCategories, { limit: 4 }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopularJobs, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-16 sm:py-24",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center max-w-2xl mx-auto mb-14",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-black uppercase tracking-wider text-[#125BB5] bg-[#EBF1F8] px-3 py-1 rounded-full",
									children: t("whyUs")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 text-3xl font-black text-[#10233F] sm:text-4xl",
									children: t("whyUs")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm font-semibold text-[#5B6B7F]",
									children: t("whyUsSubtitle")
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid sm:grid-cols-2 lg:grid-cols-4 gap-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "card-realjob p-6 text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-14 rounded-2xl bg-[#063B78]/10 text-[#063B78] mx-auto flex items-center justify-center mb-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-7" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-black text-lg text-[#10233F]",
											children: t("step1Title")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold text-[#5B6B7F] mt-2",
											children: t("step1Desc")
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "card-realjob p-6 text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-14 rounded-2xl bg-[#FFC400]/20 text-[#082F63] mx-auto flex items-center justify-center mb-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeartHandshake, { className: "size-7" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-black text-lg text-[#10233F]",
											children: t("trustCommission")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold text-[#5B6B7F] mt-2",
											children: t("step3Desc")
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "card-realjob p-6 text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-14 rounded-2xl bg-[#125BB5]/10 text-[#125BB5] mx-auto flex items-center justify-center mb-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "size-7" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-black text-lg text-[#10233F]",
											children: t("chooseLanguage")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold text-[#5B6B7F] mt-2",
											children: t("languageSubtitle")
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "card-realjob p-6 text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-14 rounded-2xl bg-[#063B78]/10 text-[#063B78] mx-auto flex items-center justify-center mb-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-7" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-black text-lg text-[#10233F]",
											children: t("step3Title")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold text-[#5B6B7F] mt-2",
											children: t("step3Desc")
										})
									]
								})
							]
						})]
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
	] });
}
//#endregion
export { HomePage as component };
