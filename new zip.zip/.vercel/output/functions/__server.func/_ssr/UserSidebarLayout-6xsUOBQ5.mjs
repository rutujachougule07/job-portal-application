import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as dataStore } from "./data-store-BCcScpg-.mjs";
import { A as Search, K as LogOut, O as Settings, Pt as ChevronRight, Ut as Bookmark, Vt as Briefcase, _t as FileText, c as User, qt as BadgeCheck } from "../_libs/lucide-react.mjs";
import { t as PublicHeader } from "./PublicHeader-D1uPireo.mjs";
import { t as PublicFooter } from "./PublicFooter-zsmeitx6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/UserSidebarLayout-6xsUOBQ5.js
var import_jsx_runtime = require_jsx_runtime();
function UserSidebarLayout({ children, activeTab }) {
	const navigate = useNavigate();
	const user = dataStore.getCurrentUser();
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
	const tabs = [
		{
			id: "overview",
			label: "Dashboard Overview",
			icon: Briefcase,
			path: "/dashboard"
		},
		{
			id: "find-jobs",
			label: "Find Jobs",
			icon: Search,
			path: "/jobs"
		},
		{
			id: "applied",
			label: "Applied Jobs",
			icon: FileText,
			path: "/dashboard",
			search: { tab: "applied" }
		},
		{
			id: "saved",
			label: "Saved Jobs",
			icon: Bookmark,
			path: "/dashboard",
			search: { tab: "saved" }
		},
		{
			id: "profile",
			label: "My Profile",
			icon: User,
			path: "/dashboard",
			search: { tab: "profile" }
		},
		{
			id: "settings",
			label: "Settings",
			icon: Settings,
			path: "/dashboard",
			search: { tab: "settings" }
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-[#F5F8FC] flex flex-col font-sans",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col lg:flex-row gap-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
						className: "w-full lg:w-72 shrink-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white rounded-2xl shadow-sm border border-[#DCE5F0] overflow-hidden lg:sticky lg:top-24",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-6 bg-gradient-to-br from-[#063B78] to-[#125BB5] text-center text-white relative overflow-hidden",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 right-0 -mr-8 -mt-8 size-32 rounded-full bg-white/10 blur-2xl" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "relative z-10 size-24 bg-white/20 backdrop-blur-md rounded-full mx-auto flex items-center justify-center mb-4 shadow-inner border border-white/30",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-4xl font-black text-white drop-shadow-md",
											children: user.fullName?.charAt(0).toUpperCase()
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "relative z-10 font-black text-xl leading-tight text-white drop-shadow-sm",
										children: user.fullName
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "relative z-10 text-sm font-semibold text-white/90 mt-1",
										children: user.email
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative z-10 mt-4 inline-flex items-center gap-1.5 bg-gradient-to-r from-[#FFC400] to-[#F59E0B] text-[#10233F] px-4 py-1.5 rounded-full text-xs font-black shadow-md",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { className: "size-4" }), " Verified User"]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
								className: "p-4 space-y-1.5",
								children: [tabs.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: item.path,
									search: item.search,
									className: `w-full flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm font-bold transition-all duration-300 ${activeTab === item.id ? "bg-[#EBF1F8] text-[#063B78] shadow-sm translate-x-1" : "text-[#5B6B7F] hover:bg-gray-50 hover:text-[#10233F]"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: `size-5 transition-colors ${activeTab === item.id ? "text-[#063B78]" : "text-gray-400"}` }),
										item.label,
										activeTab === item.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 ml-auto" })
									]
								}, item.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "pt-4 mt-4 border-t border-gray-100",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => {
											dataStore.logout();
											navigate({ to: "/" });
										},
										className: "w-full flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm font-bold text-red-600 hover:bg-red-50 transition-all duration-300 hover:translate-x-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-5" }), "Sign Out"]
									})
								})]
							})]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex-1 min-w-0",
						children
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
		]
	});
}
//#endregion
export { UserSidebarLayout as t };
