import { r as __exportAll } from "../_runtime.mjs";
import "../_libs/firebase.mjs";
import { a as uploadString, i as uploadBytes, r as ref, t as getDownloadURL } from "../_libs/firebase__storage.mjs";
import { i as storage, t as __exportAll$1 } from "./firebase-irBfmyIj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/storage-service-C4LkhGjO.js
var storage_service_C4LkhGjO_exports = /* @__PURE__ */ __exportAll({
	n: () => uploadDataUrlToFirebaseStorage,
	r: () => uploadFileToFirebaseStorage,
	t: () => storage_service_exports
});
var storage_service_exports = /* @__PURE__ */ __exportAll$1({
	uploadDataUrlToFirebaseStorage: () => uploadDataUrlToFirebaseStorage,
	uploadFileToFirebaseStorage: () => uploadFileToFirebaseStorage
});
/**
* Uploads a File or Blob to Firebase Storage under the given folder.
* If Firebase Storage upload succeeds, returns the permanent public download URL.
* In case of permission/network error, gracefully falls back to local data URL so UX is never blocked.
*/
async function uploadFileToFirebaseStorage(file, folder = "uploads", customFileName) {
	const originalName = file.name || "file";
	const cleanExt = originalName.includes(".") ? originalName.split(".").pop() : "";
	const baseName = originalName.replace(/\.[^/.]+$/, "").replace(/[^a-zA-Z0-9_-]/g, "_");
	const finalName = customFileName || `${Date.now()}_${baseName}${cleanExt ? `.${cleanExt}` : ""}`;
	const fullPath = `${folder}/${finalName}`;
	try {
		const storageRef = ref(storage, fullPath);
		const metadata = { contentType: file.type || "application/octet-stream" };
		console.log(`[FirebaseStorage] Uploading to ${fullPath}...`);
		const snapshot = await uploadBytes(storageRef, file, metadata);
		const downloadUrl = await getDownloadURL(snapshot.ref);
		console.log(`[FirebaseStorage] Upload success! Download URL:`, downloadUrl);
		return {
			downloadUrl,
			fullPath,
			fileName: originalName,
			isFirebaseStorage: true
		};
	} catch (error) {
		console.warn(`[FirebaseStorage] Direct storage upload failed, falling back to DataURL:`, error);
		return {
			downloadUrl: await new Promise((resolve, reject) => {
				const reader = new FileReader();
				reader.onloadend = () => resolve(reader.result);
				reader.onerror = reject;
				reader.readAsDataURL(file);
			}),
			fullPath: `local_${finalName}`,
			fileName: originalName,
			isFirebaseStorage: false
		};
	}
}
/**
* Uploads a base64 DataURL (e.g. from camera capture or canvas) to Firebase Storage.
*/
async function uploadDataUrlToFirebaseStorage(dataUrl, folder = "photos", fileName) {
	if (!dataUrl || !dataUrl.startsWith("data:")) return {
		downloadUrl: dataUrl,
		fullPath: "",
		fileName: fileName || "image.png",
		isFirebaseStorage: false
	};
	const cleanName = fileName ? fileName.replace(/[^a-zA-Z0-9._-]/g, "_") : `photo_${Date.now()}.png`;
	const fullPath = `${folder}/${cleanName}`;
	try {
		const storageRef = ref(storage, fullPath);
		console.log(`[FirebaseStorage] Uploading DataURL to ${fullPath}...`);
		const snapshot = await uploadString(storageRef, dataUrl, "data_url");
		const downloadUrl = await getDownloadURL(snapshot.ref);
		console.log(`[FirebaseStorage] DataURL upload success! URL:`, downloadUrl);
		return {
			downloadUrl,
			fullPath,
			fileName: cleanName,
			isFirebaseStorage: true
		};
	} catch (error) {
		console.warn(`[FirebaseStorage] uploadDataUrl failed, keeping DataURL:`, error);
		return {
			downloadUrl: dataUrl,
			fullPath: `local_${cleanName}`,
			fileName: cleanName,
			isFirebaseStorage: false
		};
	}
}
//#endregion
export { uploadDataUrlToFirebaseStorage as n, uploadFileToFirebaseStorage as r, storage_service_C4LkhGjO_exports as t };
