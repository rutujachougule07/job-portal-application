import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n } from "./i18n-CEAlH7ip.mjs";
import { t as Button } from "./button--9UiOy7A.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Brand } from "./Brand-CAHKvNmJ.mjs";
import { t as dataStore } from "./data-store-BCcScpg-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { Bt as Building2, T as ShieldCheck, V as Monitor, Vt as Briefcase, Xt as ArrowRight, _t as Factory, d as UserCheck, g as Target, i as Wrench, lt as HardHat, p as Truck, s as Users, t as Zap, ut as Handshake, v as Star, vt as Eye, w as Shield, x as Sparkles } from "../_libs/lucide-react.mjs";
import { t as PublicFooter } from "./PublicFooter-zsmeitx6.mjs";
import { t as career_team_default } from "./career-team-C8fmOxDX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BaxQC8Qw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ICONS = {
	Factory,
	HardHat,
	Wrench,
	Truck,
	Zap,
	Shield,
	Briefcase,
	Users,
	Monitor
};
var heroImages = [
	career_team_default,
	"https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80",
	"https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&q=80",
	"https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&q=80"
];
function LandingGatewayPage() {
	const { t } = useI18n();
	const navigate = useNavigate();
	const [currentImageIndex, setCurrentImageIndex] = (0, import_react.useState)(0);
	const [heroTitle, setHeroTitle] = (0, import_react.useState)("Welcome to the\nREAL JOB Portal!");
	const [heroSubtitle, setHeroSubtitle] = (0, import_react.useState)("Right Person • Right Job • Right Opportunity");
	const [images, setImages] = (0, import_react.useState)(heroImages);
	const [metrics, setMetrics] = (0, import_react.useState)([
		{
			value: "10,000+",
			label: "Verified Workers"
		},
		{
			value: "5,000+",
			label: "Live Job Openings"
		},
		{
			value: "2,200+",
			label: "Employers"
		},
		{
			value: "0%",
			label: "Zero Commission"
		}
	]);
	const [aboutData, setAboutData] = (0, import_react.useState)({
		image: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&q=80",
		title: "About Our Company",
		description: "REAL JOB is a reliable employment portal that connects job seekers with trusted companies. We focus on creating real opportunities, building successful careers, and supporting growth for individuals and businesses across India."
	});
	const [categories, setCategories] = (0, import_react.useState)([
		{
			id: "construction",
			label: "Construction",
			jobsCount: "1.5K+ Jobs",
			iconName: "HardHat",
			gradient: "from-amber-500/15 via-amber-400/5 to-transparent",
			iconBg: "bg-amber-100 text-amber-700 group-hover:bg-amber-500 group-hover:text-white",
			hoverBorder: "group-hover:border-amber-400",
			badgeStyle: "bg-amber-50 text-amber-700 border-amber-200",
			btnStyle: "bg-amber-100 text-amber-700 group-hover:bg-amber-500 group-hover:text-white"
		},
		{
			id: "technical",
			label: "Technical Staff",
			jobsCount: "2.8K+ Jobs",
			iconName: "Wrench",
			gradient: "from-blue-500/15 via-blue-400/5 to-transparent",
			iconBg: "bg-blue-100 text-blue-700 group-hover:bg-blue-600 group-hover:text-white",
			hoverBorder: "group-hover:border-blue-400",
			badgeStyle: "bg-blue-50 text-blue-700 border-blue-200",
			btnStyle: "bg-blue-100 text-blue-700 group-hover:bg-blue-600 group-hover:text-white"
		},
		{
			id: "logistics",
			label: "Transport & Logistics",
			jobsCount: "1.9K+ Jobs",
			iconName: "Truck",
			gradient: "from-emerald-500/15 via-emerald-400/5 to-transparent",
			iconBg: "bg-emerald-100 text-emerald-700 group-hover:bg-emerald-600 group-hover:text-white",
			hoverBorder: "group-hover:border-emerald-400",
			badgeStyle: "bg-emerald-50 text-emerald-700 border-emerald-200",
			btnStyle: "bg-emerald-100 text-emerald-700 group-hover:bg-emerald-600 group-hover:text-white"
		},
		{
			id: "electrician",
			label: "Electrician",
			jobsCount: "1.1K+ Jobs",
			iconName: "Zap",
			gradient: "from-purple-500/15 via-purple-400/5 to-transparent",
			iconBg: "bg-purple-100 text-purple-700 group-hover:bg-purple-600 group-hover:text-white",
			hoverBorder: "group-hover:border-purple-400",
			badgeStyle: "bg-purple-50 text-purple-700 border-purple-200",
			btnStyle: "bg-purple-100 text-purple-700 group-hover:bg-purple-600 group-hover:text-white"
		},
		{
			id: "office",
			label: "Office Staff",
			jobsCount: "2.4K+ Jobs",
			iconName: "Briefcase",
			gradient: "from-rose-500/15 via-rose-400/5 to-transparent",
			iconBg: "bg-rose-100 text-rose-700 group-hover:bg-rose-600 group-hover:text-white",
			hoverBorder: "group-hover:border-rose-400",
			badgeStyle: "bg-rose-50 text-rose-700 border-rose-200",
			btnStyle: "bg-rose-100 text-rose-700 group-hover:bg-rose-600 group-hover:text-white"
		}
	]);
	(0, import_react.useEffect)(() => {
		const savedTitle = localStorage.getItem("cms_heroTitle");
		const savedSubtitle = localStorage.getItem("cms_heroSubtitle");
		const savedImages = localStorage.getItem("cms_heroImages");
		const savedMetrics = localStorage.getItem("cms_metrics");
		const savedAbout = localStorage.getItem("cms_aboutData");
		const savedCategories = localStorage.getItem("cms_categories");
		if (savedTitle) setHeroTitle(savedTitle);
		if (savedSubtitle) setHeroSubtitle(savedSubtitle);
		if (savedImages) setImages(JSON.parse(savedImages));
		if (savedMetrics) setMetrics(JSON.parse(savedMetrics));
		if (savedAbout) setAboutData(JSON.parse(savedAbout));
		if (savedCategories) try {
			const parsed = JSON.parse(savedCategories);
			if (Array.isArray(parsed) && parsed.length >= 5) setCategories(parsed.slice(0, 5));
		} catch (e) {}
	}, []);
	(0, import_react.useEffect)(() => {
		if (images.length === 0) return;
		const interval = setInterval(() => {
			setCurrentImageIndex((prev) => (prev + 1) % images.length);
		}, 5e3);
		return () => clearInterval(interval);
	}, [images.length]);
	const [currentUser, setCurrentUser] = (0, import_react.useState)(() => dataStore.getCurrentUser());
	const handleLogout = () => {
		window.localStorage.removeItem("realjob-user");
		dataStore.setCurrentUser(null);
		setCurrentUser(null);
		toast.info("Logged out successfully!");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-white flex flex-col font-sans",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "absolute top-0 w-full z-50 bg-transparent p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-[1400px] items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, { className: "h-12 sm:h-16" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-2 sm:gap-3",
						children: currentUser ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#EBF1F8] border border-[#B8D3F2] text-xs font-black text-[#063B78]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["👤 ", currentUser.fullName || currentUser.email?.split("@")[0]] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: handleLogout,
								size: "sm",
								className: "bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs px-3 h-9.5 rounded-lg shadow-xs",
								children: "Logout (लॉग आउट)"
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							className: "border-[#063B78] text-[#063B78] font-extrabold hover:bg-[#063B78] hover:text-white text-xs px-3 sm:px-4 h-9.5 rounded-lg shadow-2xs",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/auth",
								search: {
									mode: "login",
									role: "worker"
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-4 mr-1.5" }), t("userLogin")]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							className: "bg-[#063B78] hover:bg-[#082F63] text-white font-extrabold text-xs px-3 sm:px-4 h-9.5 rounded-lg shadow-xs",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/auth",
								search: {
									mode: "login",
									role: "admin"
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 mr-1.5 text-[#FFC400]" }), t("adminLogin")]
							})
						})] })
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "relative isolate overflow-hidden h-screen min-h-[600px] flex items-center pt-20 pb-24",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-0 z-0 bg-transparent",
							children: images.map((img, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: img,
								alt: "REAL JOB India Portal Background",
								className: `absolute inset-0 h-full w-full object-cover object-[70%_20%] transition-opacity duration-1000 ease-in-out ${index === currentImageIndex ? "opacity-100" : "opacity-0"}`
							}, img))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "relative z-20 pt-8 pb-16 bg-white",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-full px-4 sm:px-8 lg:px-12",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap justify-center md:justify-evenly xl:justify-around items-center gap-6 bg-white rounded-[2rem] md:rounded-full shadow-[0_8px_30px_rgb(0,0,0,0.06)] border border-gray-100 p-6 md:p-8 mx-auto w-full max-w-[1800px] -mt-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[#D4AF37]",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-12 fill-current" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "block text-2xl md:text-3xl font-black text-[#10233F]",
											children: metrics[0]?.value
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] md:text-xs font-bold text-gray-500 leading-tight block",
											children: metrics[0]?.label
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[#D4AF37]",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-12 fill-current" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "block text-2xl md:text-3xl font-black text-[#10233F]",
											children: metrics[1]?.value
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] md:text-xs font-bold text-gray-500 leading-tight block",
											children: metrics[1]?.label
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[#D4AF37]",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-12 fill-current" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "block text-2xl md:text-3xl font-black text-[#10233F]",
											children: metrics[2]?.value
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] md:text-xs font-bold text-gray-500 leading-tight block",
											children: metrics[2]?.label
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[#D4AF37]",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-12 fill-current" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "block text-2xl md:text-3xl font-black text-[#10233F]",
											children: metrics[3]?.value
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] md:text-xs font-bold text-gray-500 leading-tight block",
											children: metrics[3]?.label
										})] })]
									})
								]
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "relative bg-[#f8f9fa] py-20 lg:py-28 overflow-hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative z-10 mx-auto max-w-[1500px] px-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "bg-white rounded-[30px] border border-gray-100 shadow-[0_10px_40px_rgb(0,0,0,0.05)] overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 lg:grid-cols-12",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "lg:col-span-5 relative bg-white pb-24 lg:pb-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "relative h-[300px] lg:h-[450px] w-full pr-12 lg:pr-16 pt-8 pl-8",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "w-full h-full rounded-tr-[60px] rounded-bl-[60px] overflow-hidden border-r-[8px] border-b-[8px] border-[#D4AF37] relative",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
													src: aboutData.image,
													alt: "Company Overview",
													className: "w-full h-full object-cover"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[#082F63]/10 mix-blend-multiply" })]
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "absolute bottom-0 left-0 right-0 lg:right-[-4rem] bg-[#082F63] rounded-tr-[40px] rounded-tl-[40px] lg:rounded-tl-none p-6 lg:p-8 flex justify-between items-center shadow-xl border-t-[4px] border-[#D4AF37] z-20",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-col items-center flex-1 border-r border-white/10 px-2",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-6 lg:size-8 text-[#D4AF37] mb-2" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-xl lg:text-2xl font-black text-white leading-none",
															children: "10K+"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] lg:text-[11px] text-gray-300 mt-1 font-medium text-center",
															children: "Happy Workers"
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-col items-center flex-1 border-r border-white/10 px-2",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-6 lg:size-8 text-[#D4AF37] mb-2" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-xl lg:text-2xl font-black text-white leading-none",
															children: "2.2K+"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] lg:text-[11px] text-gray-300 mt-1 font-medium text-center",
															children: "Trusted Employers"
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-col items-center flex-1 border-r border-white/10 px-2",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-6 lg:size-8 text-[#D4AF37] mb-2" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-xl lg:text-2xl font-black text-white leading-none",
															children: "5K+"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] lg:text-[11px] text-gray-300 mt-1 font-medium text-center",
															children: "Live Job Openings"
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-col items-center flex-1 px-2",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-6 lg:size-8 text-[#D4AF37] mb-2" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-xl lg:text-2xl font-black text-white leading-none",
															children: "98%"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[10px] lg:text-[11px] text-gray-300 mt-1 font-medium text-center",
															children: "Success Rate"
														})
													]
												})
											]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "lg:col-span-7 p-8 lg:p-16 flex flex-col justify-center",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-3 mb-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-[2px] w-10 bg-[#D4AF37]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-black text-[#082F63] tracking-[0.1em] uppercase",
													children: "ABOUT REAL JOB"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
												className: "text-4xl md:text-5xl font-black text-[#082F63] leading-[1.1] mb-6",
												children: [
													aboutData.title.split(" ").slice(0, -1).join(" "),
													" ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[#D4AF37]",
														children: aboutData.title.split(" ").pop()
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[15px] font-medium text-gray-600 leading-relaxed mb-10 max-w-3xl whitespace-pre-wrap",
												children: aboutData.description
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid grid-cols-2 md:grid-cols-4 gap-4",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "bg-white rounded-2xl p-5 shadow-[0_4px_20px_rgb(0,0,0,0.06)] border border-gray-50 flex flex-col items-center text-center hover:-translate-y-1 transition-transform",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "size-12 rounded-full border-2 border-[#D4AF37] flex items-center justify-center mb-4",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "size-6 text-[#D4AF37]" })
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
																className: "text-[14px] font-black text-[#082F63] mb-2",
																children: "Our Mission"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																className: "text-[11px] font-semibold text-gray-500 leading-snug",
																children: "To provide the right employment opportunity to everyone."
															})
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "bg-white rounded-2xl p-5 shadow-[0_4px_20px_rgb(0,0,0,0.06)] border border-gray-50 flex flex-col items-center text-center hover:-translate-y-1 transition-transform",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "size-12 rounded-full border-2 border-[#D4AF37] flex items-center justify-center mb-4",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-6 text-[#D4AF37]" })
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
																className: "text-[14px] font-black text-[#082F63] mb-2",
																children: "Our Vision"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																className: "text-[11px] font-semibold text-gray-500 leading-snug",
																children: "To become the most trusted employment portal in India."
															})
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "bg-white rounded-2xl p-5 shadow-[0_4px_20px_rgb(0,0,0,0.06)] border border-gray-50 flex flex-col items-center text-center hover:-translate-y-1 transition-transform",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "size-12 rounded-full border-2 border-[#D4AF37] flex items-center justify-center mb-4",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-6 text-[#D4AF37]" })
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
																className: "text-[14px] font-black text-[#082F63] mb-2",
																children: "Our Values"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																className: "text-[11px] font-semibold text-gray-500 leading-snug",
																children: "Trust, transparency, quality, and consistent service."
															})
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "bg-white rounded-2xl p-5 shadow-[0_4px_20px_rgb(0,0,0,0.06)] border border-gray-50 flex flex-col items-center text-center hover:-translate-y-1 transition-transform",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "size-12 rounded-full border-2 border-[#D4AF37] flex items-center justify-center mb-4",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Handshake, { className: "size-6 text-[#D4AF37]" })
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
																className: "text-[14px] font-black text-[#082F63] mb-2",
																children: "Our Belief"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
																className: "text-[11px] font-semibold text-gray-500 leading-snug",
																children: [
																	"Right Person",
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
																	"Right Job",
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
																	"Right Opportunity."
																]
															})
														]
													})
												]
											})
										]
									})]
								})
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "relative py-20 bg-white overflow-hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative z-10 mx-auto max-w-[1600px] px-4 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#FEF9E7] border border-[#FDE68A] text-[#B45309] font-black text-xs uppercase tracking-wider mb-4 shadow-2xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4 text-[#D97706]" }), "EXPLORE BY CATEGORY"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
									className: "text-3xl sm:text-4xl md:text-5xl font-black text-[#082F63] mb-3 tracking-tight",
									children: ["Popular Job ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[#D4AF37]",
										children: "Categories"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-center gap-3 mb-12",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-[1.5px] w-12 md:w-20 bg-[#D4AF37]/60" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs md:text-sm font-extrabold text-[#5B6B7F]",
											children: "Right opportunity for you - in your field!"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-[1.5px] w-12 md:w-20 bg-[#D4AF37]/60" })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6 max-w-[1450px] mx-auto px-4",
									children: categories.map((catData, i) => {
										const IconComponent = ICONS[catData.iconName] || Briefcase;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											onClick: () => navigate({
												to: "/auth",
												search: {
													mode: "login",
													role: "worker"
												}
											}),
											className: `group relative rounded-3xl border border-[#DCE5F0] bg-white p-7 flex flex-col items-center justify-between text-center cursor-pointer transition-all duration-500 shadow-sm hover:shadow-2xl hover:-translate-y-3.5 hover:scale-[1.02] ${catData.hoverBorder || "group-hover:border-blue-400"} overflow-hidden min-h-[240px]`,
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `absolute -top-16 -left-16 size-40 rounded-full bg-gradient-to-br ${catData.gradient || "from-blue-500/15 to-transparent"} blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none` }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: `relative size-20 rounded-2xl flex items-center justify-center transition-all duration-500 group-hover:scale-110 group-hover:rotate-3 shadow-xs ${catData.iconBg || "bg-blue-100 text-blue-700"}`,
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconComponent, { className: "size-9 stroke-[1.9] transition-transform duration-500 group-hover:scale-110" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "my-4 flex flex-col items-center",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
														className: "font-black text-base sm:text-lg text-[#10233F] group-hover:text-[#063B78] transition-colors leading-tight",
														children: catData.label
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: `inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-black border tracking-wide mt-2 shadow-2xs ${catData.badgeStyle || "bg-blue-50 text-blue-700 border-blue-200"}`,
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3 animate-pulse" }), catData.jobsCount || "1K+ Jobs"]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "w-full flex justify-end mt-auto",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: `size-10 rounded-full flex items-center justify-center transition-all duration-500 shadow-2xs ${catData.btnStyle || "bg-blue-100 text-blue-700"} group-hover:scale-110 group-hover:shadow-md`,
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-5 transition-transform duration-300 group-hover:translate-x-1" })
													})
												})
											]
										}, catData.id || i);
									})
								})
							]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
		]
	});
}
//#endregion
export { LandingGatewayPage as component };
