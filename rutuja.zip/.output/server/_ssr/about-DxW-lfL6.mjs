import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n } from "./i18n-CEAlH7ip.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Button } from "./button-DlK03b8v.mjs";
import { Ct as CircleCheck, g as Target, it as HardHat, jt as Building2, nt as HeartHandshake, ot as Globe, t as Zap, w as ShieldCheck, x as Sparkles } from "../_libs/lucide-react.mjs";
import { n as PublicHeader, t as PublicFooter } from "./PublicHeader-DazdRGin.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-DxW-lfL6.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	const { t, n } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "bg-[#F5F8FC] min-h-screen",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "bg-hero-overlay text-white py-16 sm:py-24 relative overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-w-3xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-1.5 text-xs font-bold uppercase tracking-wider text-[#FFC400] backdrop-blur-md mb-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" }), t("aboutHeroEyebrow")]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
									className: "text-4xl font-black tracking-tight sm:text-5xl lg:text-6xl text-white",
									children: [
										t("heroTitleLine1"),
										" ",
										t("heroTitleLine2"),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[#FFC400]",
											children: t("heroTitleLine3")
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-6 text-lg sm:text-xl font-medium text-white/90 leading-relaxed",
									children: t("aboutHeroSub")
								})
							]
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 -mt-8 relative z-20",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 md:grid-cols-4 gap-4 bg-white rounded-2xl p-6 shadow-xl border border-[#DCE5F0]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center p-3 border-r border-[#DCE5F0] last:border-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-3xl sm:text-4xl font-black text-[#063B78]",
									children: n("50,000+")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs font-bold text-[#5B6B7F] mt-1",
									children: t("statWorkers")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center p-3 border-r border-[#DCE5F0] last:border-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-3xl sm:text-4xl font-black text-[#125BB5]",
									children: n("10,000+")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs font-bold text-[#5B6B7F] mt-1",
									children: t("statEmployers")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center p-3 border-r border-[#DCE5F0] last:border-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-3xl sm:text-4xl font-black text-[#063B78]",
									children: n("1,50,000+")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs font-bold text-[#5B6B7F] mt-1",
									children: t("statJobs")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-3xl sm:text-4xl font-black text-[#FFC400] text-[#082F63] px-2 py-0.5 rounded bg-[#FFC400]",
									children: n("100%")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs font-bold text-[#5B6B7F] mt-1",
									children: t("statContact")
								})]
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-16 sm:py-24",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid md:grid-cols-2 gap-8 items-stretch",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "card-realjob p-8 flex flex-col justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "size-14 rounded-2xl bg-[#063B78]/10 text-[#063B78] flex items-center justify-center mb-6",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "size-8" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-2xl font-black text-[#10233F]",
										children: t("ourMission")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-sm font-semibold text-[#5B6B7F] leading-relaxed",
										children: t("ourMissionDesc")
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-6 pt-4 border-t border-[#DCE5F0] flex items-center gap-2 text-xs font-extrabold text-[#063B78]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-[#FFC400]" }),
										t("trustCommission"),
										" • ",
										t("trustPhone")
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "card-realjob p-8 flex flex-col justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "size-14 rounded-2xl bg-[#125BB5]/10 text-[#125BB5] flex items-center justify-center mb-6",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "size-8" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-2xl font-black text-[#10233F]",
										children: t("ourVision")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-sm font-semibold text-[#5B6B7F] leading-relaxed",
										children: t("ourVisionDesc")
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-6 pt-4 border-t border-[#DCE5F0] flex items-center gap-2 text-xs font-extrabold text-[#125BB5]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-[#FFC400]" }), t("trustVerified")]
								})]
							})]
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-16 bg-white border-y border-[#DCE5F0]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center max-w-3xl mx-auto mb-16",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-black uppercase tracking-wider text-[#125BB5] bg-[#EBF1F8] px-3 py-1 rounded-full",
									children: t("howWorksSimple")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 text-3xl font-black text-[#10233F] sm:text-4xl",
									children: t("howWorks")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-base font-semibold text-[#5B6B7F]",
									children: t("howWorksSubtitle")
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid md:grid-cols-2 gap-12",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-[#F5F8FC] p-8 rounded-2xl border border-[#DCE5F0]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3 mb-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-10 rounded-xl bg-[#FFC400] text-[#082F63] flex items-center justify-center font-black",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HardHat, { className: "size-5" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-xl font-black text-[#10233F]",
											children: t("forWorkersTitle")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold text-[#125BB5]",
											children: t("seekerDesc")
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex gap-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "size-8 rounded-full bg-[#063B78] text-white font-black text-xs flex items-center justify-center shrink-0",
													children: n(1)
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
													className: "font-extrabold text-[#10233F] text-sm",
													children: t("forWorkersStep1Title")
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-[#5B6B7F] mt-1 font-semibold",
													children: t("forWorkersStep1Desc")
												})] })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex gap-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "size-8 rounded-full bg-[#063B78] text-white font-black text-xs flex items-center justify-center shrink-0",
													children: n(2)
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
													className: "font-extrabold text-[#10233F] text-sm",
													children: t("forWorkersStep2Title")
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-[#5B6B7F] mt-1 font-semibold",
													children: t("forWorkersStep2Desc")
												})] })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex gap-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "size-8 rounded-full bg-[#063B78] text-white font-black text-xs flex items-center justify-center shrink-0",
													children: n(3)
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
													className: "font-extrabold text-[#10233F] text-sm",
													children: t("forWorkersStep3Title")
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-[#5B6B7F] mt-1 font-semibold",
													children: t("forWorkersStep3Desc")
												})] })]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										className: "w-full mt-8 btn-yellow font-extrabold text-sm py-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/jobs",
											children: t("jobs")
										})
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-[#F5F8FC] p-8 rounded-2xl border border-[#DCE5F0]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3 mb-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-10 rounded-xl bg-[#063B78] text-white flex items-center justify-center font-black",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-5" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-xl font-black text-[#10233F]",
											children: t("forEmployersTitle")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold text-[#125BB5]",
											children: t("employerDesc")
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex gap-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "size-8 rounded-full bg-[#125BB5] text-white font-black text-xs flex items-center justify-center shrink-0",
													children: n(1)
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
													className: "font-extrabold text-[#10233F] text-sm",
													children: t("forEmployersStep1Title")
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-[#5B6B7F] mt-1 font-semibold",
													children: t("forEmployersStep1Desc")
												})] })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex gap-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "size-8 rounded-full bg-[#125BB5] text-white font-black text-xs flex items-center justify-center shrink-0",
													children: n(2)
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
													className: "font-extrabold text-[#10233F] text-sm",
													children: t("forEmployersStep2Title")
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-[#5B6B7F] mt-1 font-semibold",
													children: t("forEmployersStep2Desc")
												})] })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex gap-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "size-8 rounded-full bg-[#125BB5] text-white font-black text-xs flex items-center justify-center shrink-0",
													children: n(3)
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
													className: "font-extrabold text-[#10233F] text-sm",
													children: t("forEmployersStep3Title")
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-[#5B6B7F] mt-1 font-semibold",
													children: t("forEmployersStep3Desc")
												})] })]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										className: "w-full mt-8 btn-navy font-extrabold text-sm py-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/workers",
											children: t("workers")
										})
									})
								]
							})]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-16 sm:py-24",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center max-w-2xl mx-auto mb-14",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-3xl font-black text-[#10233F] sm:text-4xl",
								children: t("whyChooseTitle")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-base font-semibold text-[#5B6B7F]",
								children: t("whyUsSubtitle")
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid sm:grid-cols-2 lg:grid-cols-4 gap-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "card-realjob p-6 text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-12 rounded-full bg-[#063B78]/10 text-[#063B78] mx-auto flex items-center justify-center mb-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-6" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-black text-base text-[#10233F]",
											children: t("verifiedUsersTitle")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold text-[#5B6B7F] mt-2",
											children: t("verifiedUsersDesc")
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "card-realjob p-6 text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-12 rounded-full bg-[#FFC400]/20 text-[#082F63] mx-auto flex items-center justify-center mb-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeartHandshake, { className: "size-6" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-black text-base text-[#10233F]",
											children: t("zeroFeesTitle")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold text-[#5B6B7F] mt-2",
											children: t("zeroFeesDesc")
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "card-realjob p-6 text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-12 rounded-full bg-[#125BB5]/10 text-[#125BB5] mx-auto flex items-center justify-center mb-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "size-6" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-black text-base text-[#10233F]",
											children: t("regionalLangTitle")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold text-[#5B6B7F] mt-2",
											children: t("regionalLangDesc")
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "card-realjob p-6 text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-12 rounded-full bg-[#063B78]/10 text-[#063B78] mx-auto flex items-center justify-center mb-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-6" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-black text-base text-[#10233F]",
											children: t("instantHiringTitle")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold text-[#5B6B7F] mt-2",
											children: t("instantHiringDesc")
										})
									]
								})
							]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "bg-hero-overlay text-white py-14",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-3xl font-black sm:text-4xl text-white",
								children: t("joinBannerTitle")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-base text-white/90 max-w-xl mx-auto font-medium",
								children: t("joinBannerSub")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 flex flex-wrap justify-center gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									className: "btn-yellow font-extrabold text-sm px-8 py-3.5 h-auto",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/auth",
										search: {
											mode: "register",
											role: "worker"
										},
										children: t("seeker")
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									variant: "outline",
									className: "border-white text-white font-extrabold text-sm px-8 py-3.5 h-auto hover:bg-white hover:text-[#063B78]",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/auth",
										search: {
											mode: "register",
											role: "employer"
										},
										children: t("employer")
									})
								})]
							})
						]
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
	] });
}
//#endregion
export { AboutPage as component };
