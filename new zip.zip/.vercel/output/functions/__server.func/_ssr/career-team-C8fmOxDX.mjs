//#region node_modules/.nitro/vite/services/ssr/assets/career-team-C8fmOxDX.js
var career_team_default = "/assets/career-team-CL7SHC2o.jpg";
//#endregion
export { career_team_default as t };
