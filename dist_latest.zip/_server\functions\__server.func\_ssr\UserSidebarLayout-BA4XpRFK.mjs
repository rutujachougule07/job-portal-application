import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n } from "./i18n-BlIP7F54.mjs";
import { t as dataStore } from "./data-store-CPuK80w4.mjs";
import { b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { Et as FileText, M as Search, X as LogOut, c as User, ft as House, n as X, on as Bookmark, q as Menu, un as BadgeCheck } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/UserSidebarLayout-BA4XpRFK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function UserSidebarLayout({ children, activeTab }) {
	const navigate = useNavigate();
	const user = dataStore.getCurrentUser("worker");
	const { lang, setLang, t } = useI18n();
	const [isMobileMenuOpen, setIsMobileMenuOpen] = (0, import_react.useState)(false);
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
	const tabs = [
		{
			id: "overview",
			label: t("dashboard"),
			icon: House,
			path: "/dashboard"
		},
		{
			id: "find-jobs",
			label: t("jobs"),
			icon: Search,
			path: "/jobs"
		},
		{
			id: "applied",
			label: t("appliedJobsTab"),
			icon: FileText,
			path: "/dashboard",
			search: { tab: "applied" }
		},
		{
			id: "saved",
			label: t("savedJobsTab"),
			icon: Bookmark,
			path: "/dashboard",
			search: { tab: "saved" }
		},
		{
			id: "profile",
			label: t("myProfile"),
			icon: User,
			path: "/dashboard",
			search: { tab: "profile" }
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "h-screen bg-[#F5F8FC] flex flex-col md:flex-row font-sans max-w-full overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "md:hidden bg-[#051B38] text-white px-4 py-3 sticky top-0 z-40 flex items-center justify-between shadow-md border-b border-white/10 shrink-0 w-full",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 min-w-0 pr-2",
					children: [user.profilePhoto ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: user.profilePhoto,
						alt: user.fullName || "User",
						className: "size-9 rounded-full object-cover shadow-md ring-2 ring-white/20 border border-white shrink-0"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-9 rounded-full bg-[#125BB5] text-white flex items-center justify-center font-black text-sm shadow-md ring-2 ring-white/20 shrink-0",
						children: user.fullName?.charAt(0).toUpperCase() || user.email?.charAt(0).toUpperCase() || "C"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-black text-xs text-white truncate leading-tight",
							children: user.fullName || user.email?.split("@")[0] || "Candidate"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] text-[#FFC400] font-black uppercase block tracking-wider leading-tight mt-0.5",
							children: t("candidatePortal")
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-1.5 shrink-0 ml-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setIsMobileMenuOpen(!isMobileMenuOpen),
						className: "p-2 rounded-xl bg-white/10 text-white hover:bg-white/20 transition-all cursor-pointer",
						"aria-label": "Toggle menu",
						children: isMobileMenuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
					})
				})]
			}),
			isMobileMenuOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-50 md:hidden flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity",
					onClick: () => setIsMobileMenuOpen(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "relative w-4/5 max-w-xs bg-[#051B38] text-white flex flex-col justify-between h-full p-5 shadow-2xl z-10 overflow-y-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between pb-4 border-b border-white/10 mb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [user.profilePhoto ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: user.profilePhoto,
								alt: user.fullName || "User",
								className: "size-12 rounded-full object-cover shadow-md ring-2 ring-white/20"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-12 rounded-full bg-[#125BB5] text-white flex items-center justify-center font-black text-xl shadow-md",
								children: user.fullName?.charAt(0).toUpperCase() || "U"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-black text-sm text-white truncate",
									children: user.fullName || "User"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-white/70 truncate",
									children: user.email || ""
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setIsMobileMenuOpen(false),
							className: "p-1.5 rounded-lg text-white/60 hover:text-white hover:bg-white/10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "space-y-1.5",
						children: tabs.map((item) => {
							const isActive = activeTab === item.id;
							const linkProps = item.search ? {
								to: item.path,
								search: item.search
							} : { to: item.path };
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								...linkProps,
								onClick: () => setIsMobileMenuOpen(false),
								className: `relative w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold transition-all ${isActive ? "bg-[#0E356A] text-white shadow-md font-extrabold" : "text-white/70 hover:bg-white/5 hover:text-white"}`,
								children: [
									isActive && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute left-0 top-1/2 -translate-y-1/2 w-1.5 h-6 bg-[#FFC400] rounded-r-full" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: `size-4 ${isActive ? "text-[#FFC400]" : "text-white/60"}` }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label })
								]
							}, item.id);
						})
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pt-4 border-t border-white/10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								setIsMobileMenuOpen(false);
								dataStore.logout("worker");
								navigate({
									to: "/",
									hash: "main",
									replace: true
								});
								if (typeof window !== "undefined") window.scrollTo(0, 0);
							},
							className: "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold text-rose-400 hover:bg-rose-500/10 transition-colors",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("signOut") })]
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "hidden md:flex w-64 bg-[#051B38] text-white flex-col justify-between shrink-0 h-full px-4 py-4 overflow-y-auto border-r border-white/10",
				style: { scrollbarWidth: "none" },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pt-1 pb-4 px-2 text-center border-b border-white/10 mb-4",
					children: [
						user.profilePhoto ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: user.profilePhoto,
							alt: user.fullName || "User",
							className: "size-20 rounded-full object-cover mx-auto mb-2 shadow-lg ring-4 ring-white/20 border-2 border-white"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-20 rounded-full bg-[#125BB5] text-white flex items-center justify-center font-black text-3xl mx-auto mb-2 shadow-lg ring-4 ring-white/10",
							children: user.fullName?.charAt(0).toUpperCase() || user.email?.charAt(0).toUpperCase() || "U"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-black text-lg text-white tracking-tight",
							children: user.fullName || user.email?.split("@")[0] || "User"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold text-white/70 truncate px-2",
							children: user.email || ""
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2.5 inline-flex items-center gap-1.5 bg-[#FFC400]/20 border border-[#FFC400] text-[#FFC400] px-3 py-0.5 rounded-full text-[11px] font-black",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { className: "size-3.5" }),
								" ",
								t("verifiedUser")
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "space-y-1.5",
					children: tabs.map((item) => {
						const isActive = activeTab === item.id;
						const linkProps = item.search ? {
							to: item.path,
							search: item.search
						} : { to: item.path };
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							...linkProps,
							className: `relative w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all duration-200 ${isActive ? "bg-[#0E356A] text-white shadow-md font-extrabold" : "text-white/70 hover:bg-white/5 hover:text-white"}`,
							children: [
								isActive && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute left-0 top-1/2 -translate-y-1/2 w-1.5 h-6 bg-[#FFC400] rounded-r-full" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: `size-4.5 ${isActive ? "text-[#FFC400]" : "text-white/60"}` }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label })
							]
						}, item.id);
					})
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pt-4 border-t border-white/10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							dataStore.logout("worker");
							navigate({
								to: "/",
								hash: "main",
								replace: true
							});
							if (typeof window !== "undefined") window.scrollTo(0, 0);
						},
						className: "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold text-rose-400 hover:bg-rose-500/10 transition-colors cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("signOut") })]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex-1 h-full bg-[#F5F8FC] p-3 sm:p-6 lg:p-8 overflow-y-auto overflow-x-hidden min-w-0 max-w-full pb-20 md:pb-8 w-full",
				style: { scrollbarWidth: "none" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-w-7xl mx-auto space-y-6 min-w-0 max-w-full overflow-x-hidden",
					children
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "md:hidden fixed bottom-0 left-0 right-0 bg-[#051B38] text-white border-t border-white/10 z-40 px-2 py-1.5 flex items-center justify-around shadow-2xl",
				children: tabs.map((item) => {
					const isActive = activeTab === item.id;
					const linkProps = item.search ? {
						to: item.path,
						search: item.search
					} : { to: item.path };
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						...linkProps,
						className: `flex flex-col items-center gap-0.5 px-2 py-1 rounded-lg text-[10px] font-bold transition-all ${isActive ? "text-[#FFC400]" : "text-white/60 hover:text-white"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: `size-4.5 ${isActive ? "text-[#FFC400]" : "text-white/60"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate max-w-[64px]",
							children: item.label
						})]
					}, item.id);
				})
			})
		]
	});
}
//#endregion
export { UserSidebarLayout as t };
