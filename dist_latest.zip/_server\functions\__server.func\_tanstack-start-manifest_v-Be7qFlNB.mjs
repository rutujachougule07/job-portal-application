//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Be7qFlNB.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/job-portal-application-main/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/about",
			"/admin",
			"/auth",
			"/categories",
			"/contact",
			"/dashboard",
			"/employee-dashboard",
			"/faq",
			"/home",
			"/reset-password",
			"/select-language",
			"/select-role",
			"/superadmin",
			"/company/$companyId",
			"/jobs/$jobId",
			"/workers/$workerId",
			"/jobs/",
			"/workers/"
		],
		preloads: [
			"/assets/index-B1ReQOeT.js",
			"/assets/rolldown-runtime-hePW80VL.js",
			"/assets/jsx-runtime-BNakU3Ej.js",
			"/assets/react-dom-4BxBAy_T.js",
			"/assets/Match-C5nCDhZ2.js",
			"/assets/lazyRouteComponent-1Bn8mebH.js",
			"/assets/link-DXSwUvZ8.js",
			"/assets/useMatch-CAe2qATk.js",
			"/assets/root-DLTE-HSj.js",
			"/assets/useSelector-D2ljeLAE.js",
			"/assets/useRouter-CvmHl-Py.js",
			"/assets/firebase-CZES-SLI.js",
			"/assets/index.esm-B23VuDux.js",
			"/assets/preload-helper-Czpn1I53.js",
			"/assets/types-DKSnJpxg.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B1ReQOeT.js"
		} }]
	},
	"/": {
		filePath: "C:/job-portal-application-main/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DSHb3yzt.js",
			"/assets/useNavigate-qHZ6S4gr.js",
			"/assets/button-B6CcZJD6.js",
			"/assets/award-DuxBo8T7.js",
			"/assets/briefcase-DpM68hSU.js",
			"/assets/building-2-Bxp1bLZF.js",
			"/assets/circle-check-D50E_c-n.js",
			"/assets/LanguageSwitcher-C4zmO-8Y.js",
			"/assets/shield-h5UptCwY.js",
			"/assets/eye-DeLAhnnh.js",
			"/assets/truck-DIjb6dBy.js",
			"/assets/hard-hat-VggsEG9G.js",
			"/assets/search-GlQeEkFt.js",
			"/assets/shield-check-D34QxPw2.js",
			"/assets/sparkles-CAXQcxtp.js",
			"/assets/star-CeGYC2Fc.js",
			"/assets/target-CQYd_hMt.js",
			"/assets/trending-up-CgO96aiD.js",
			"/assets/user-check-BkvNaXEV.js",
			"/assets/users-D9PQXXxK.js",
			"/assets/wrench-BCOJpq-G.js",
			"/assets/zap-Cjdg3w8H.js",
			"/assets/Brand-CeW-s1R_.js",
			"/assets/LanguageGate-CQvn1Mbm.js",
			"/assets/PublicFooter-BTHB0mRK.js"
		]
	},
	"/_authenticated": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/applications",
			"/_authenticated/control",
			"/_authenticated/employer",
			"/_authenticated/messages",
			"/_authenticated/notifications",
			"/_authenticated/post-job",
			"/_authenticated/profile",
			"/_authenticated/salary"
		],
		preloads: ["/assets/route-Cf5ka_dn.js"]
	},
	"/about": {
		filePath: "C:/job-portal-application-main/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-CBt3gE7K.js",
			"/assets/useNavigate-qHZ6S4gr.js",
			"/assets/button-B6CcZJD6.js",
			"/assets/createLucideIcon-C-6I3_er.js",
			"/assets/building-2-Bxp1bLZF.js",
			"/assets/globe-COuJzn8x.js",
			"/assets/circle-check-D50E_c-n.js",
			"/assets/hard-hat-VggsEG9G.js",
			"/assets/shield-check-D34QxPw2.js",
			"/assets/sparkles-CAXQcxtp.js",
			"/assets/target-CQYd_hMt.js",
			"/assets/zap-Cjdg3w8H.js",
			"/assets/PublicFooter-BTHB0mRK.js",
			"/assets/PublicHeader-PufhKadS.js"
		]
	},
	"/admin": {
		filePath: "C:/job-portal-application-main/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-4Hm0phL0.js",
			"/assets/useNavigate-qHZ6S4gr.js",
			"/assets/button-B6CcZJD6.js",
			"/assets/createLucideIcon-C-6I3_er.js",
			"/assets/briefcase-business-CFjp9uvX.js",
			"/assets/building-2-Bxp1bLZF.js",
			"/assets/location-utils-D4G496V4.js",
			"/assets/chart-column-Caau_uQR.js",
			"/assets/check-B9A286jM.js",
			"/assets/chevron-down-CDjcrh-K.js",
			"/assets/chevron-right-BR7kJNO-.js",
			"/assets/circle-check-D50E_c-n.js",
			"/assets/clock-C_q9muCP.js",
			"/assets/external-link-Ci90ydo9.js",
			"/assets/file-text-CS9Gs8Ia.js",
			"/assets/indian-rupee-BnTEt8bL.js",
			"/assets/loader-circle-CZI7SSfT.js",
			"/assets/log-out-IW-fEouz.js",
			"/assets/map-pin-BO_P1FKY.js",
			"/assets/menu-BV2zht-N.js",
			"/assets/plus-9AHZiOfW.js",
			"/assets/phone-BMLDq6iC.js",
			"/assets/search-GlQeEkFt.js",
			"/assets/shield-check-D34QxPw2.js",
			"/assets/sparkles-CAXQcxtp.js",
			"/assets/square-pen-OL_vuVVf.js",
			"/assets/trash-2-Djp0zjDE.js",
			"/assets/user-check-BkvNaXEV.js",
			"/assets/user-plus-B_FuWJ-N.js",
			"/assets/user-C_T3C6us.js",
			"/assets/users-D9PQXXxK.js",
			"/assets/x-CpoVJs46.js",
			"/assets/zap-Cjdg3w8H.js",
			"/assets/badge-cR9Q5Tvm.js",
			"/assets/input-DLoLHtwj.js",
			"/assets/label-tSOuFsVr.js"
		]
	},
	"/auth": {
		filePath: "C:/job-portal-application-main/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-DeI4SxPD.js",
			"/assets/useNavigate-qHZ6S4gr.js",
			"/assets/storage-service-BqAoWjx4.js",
			"/assets/button-B6CcZJD6.js",
			"/assets/createLucideIcon-C-6I3_er.js",
			"/assets/arrow-left-qqtqVSWu.js",
			"/assets/building-2-Bxp1bLZF.js",
			"/assets/camera-Dx7Shswb.js",
			"/assets/check-B9A286jM.js",
			"/assets/eye-off-D32lK6hV.js",
			"/assets/eye-DeLAhnnh.js",
			"/assets/loader-circle-CZI7SSfT.js",
			"/assets/mail-Bw-tBiu7.js",
			"/assets/phone-BMLDq6iC.js",
			"/assets/rotate-ccw-D1ZTZc2Y.js",
			"/assets/user-plus-B_FuWJ-N.js",
			"/assets/user-C_T3C6us.js",
			"/assets/x-CpoVJs46.js",
			"/assets/Brand-CeW-s1R_.js",
			"/assets/label-tSOuFsVr.js"
		]
	},
	"/categories": {
		filePath: "C:/job-portal-application-main/src/routes/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-DvNzSUXE.js",
			"/assets/createLucideIcon-C-6I3_er.js",
			"/assets/arrow-left-qqtqVSWu.js",
			"/assets/arrow-right-D5i9EBPe.js",
			"/assets/building-2-Bxp1bLZF.js",
			"/assets/truck-DIjb6dBy.js",
			"/assets/sprout-d5s3bUuK.js",
			"/assets/hard-hat-VggsEG9G.js",
			"/assets/stethoscope-DTVTGltd.js",
			"/assets/search-GlQeEkFt.js",
			"/assets/sparkles-CAXQcxtp.js",
			"/assets/trending-up-CgO96aiD.js",
			"/assets/user-plus-B_FuWJ-N.js",
			"/assets/wrench-BCOJpq-G.js",
			"/assets/input-DLoLHtwj.js",
			"/assets/PublicFooter-BTHB0mRK.js",
			"/assets/PublicHeader-PufhKadS.js"
		]
	},
	"/contact": {
		filePath: "C:/job-portal-application-main/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-B7gFW6tU.js",
			"/assets/useNavigate-qHZ6S4gr.js",
			"/assets/button-B6CcZJD6.js",
			"/assets/circle-check-D50E_c-n.js",
			"/assets/mail-Bw-tBiu7.js",
			"/assets/map-pin-BO_P1FKY.js",
			"/assets/message-square-Bs7672BP.js",
			"/assets/phone-BMLDq6iC.js",
			"/assets/send-DYkO0ETC.js",
			"/assets/sparkles-CAXQcxtp.js",
			"/assets/input-DLoLHtwj.js",
			"/assets/PublicFooter-BTHB0mRK.js",
			"/assets/PublicHeader-PufhKadS.js"
		]
	},
	"/dashboard": {
		filePath: "C:/job-portal-application-main/src/routes/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-DAiMyHt7.js",
			"/assets/useNavigate-qHZ6S4gr.js",
			"/assets/storage-service-BqAoWjx4.js",
			"/assets/button-B6CcZJD6.js",
			"/assets/award-DuxBo8T7.js",
			"/assets/JobCard-Dpxh5mEx.js",
			"/assets/bookmark-CX2EccEu.js",
			"/assets/briefcase-DpM68hSU.js",
			"/assets/chevron-down-CDjcrh-K.js",
			"/assets/chevron-right-BR7kJNO-.js",
			"/assets/circle-check-D50E_c-n.js",
			"/assets/file-text-CS9Gs8Ia.js",
			"/assets/UserSidebarLayout-Dc3LcpGh.js",
			"/assets/mail-Bw-tBiu7.js",
			"/assets/map-pin-BO_P1FKY.js",
			"/assets/plus-9AHZiOfW.js",
			"/assets/phone-BMLDq6iC.js",
			"/assets/save-xq9BSy_-.js",
			"/assets/search-GlQeEkFt.js",
			"/assets/settings-DympD8sw.js",
			"/assets/trending-up-CgO96aiD.js",
			"/assets/user-C_T3C6us.js",
			"/assets/x-CpoVJs46.js",
			"/assets/input-DLoLHtwj.js"
		]
	},
	"/employee-dashboard": {
		filePath: "C:/job-portal-application-main/src/routes/employee-dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/employee-dashboard-Csr7nJaT.js",
			"/assets/useNavigate-qHZ6S4gr.js",
			"/assets/button-B6CcZJD6.js",
			"/assets/createLucideIcon-C-6I3_er.js",
			"/assets/location-utils-D4G496V4.js",
			"/assets/camera-Dx7Shswb.js",
			"/assets/chevron-right-BR7kJNO-.js",
			"/assets/file-text-CS9Gs8Ia.js",
			"/assets/log-out-IW-fEouz.js",
			"/assets/map-pin-BO_P1FKY.js",
			"/assets/user-C_T3C6us.js"
		]
	},
	"/faq": {
		filePath: "C:/job-portal-application-main/src/routes/faq.tsx",
		children: void 0,
		preloads: [
			"/assets/faq-BbjlEHW7.js",
			"/assets/button-B6CcZJD6.js",
			"/assets/createLucideIcon-C-6I3_er.js",
			"/assets/briefcase-DpM68hSU.js",
			"/assets/building-2-Bxp1bLZF.js",
			"/assets/chevron-down-CDjcrh-K.js",
			"/assets/hard-hat-VggsEG9G.js",
			"/assets/message-square-Bs7672BP.js",
			"/assets/search-GlQeEkFt.js",
			"/assets/user-check-BkvNaXEV.js",
			"/assets/input-DLoLHtwj.js",
			"/assets/PublicFooter-BTHB0mRK.js",
			"/assets/PublicHeader-PufhKadS.js"
		]
	},
	"/reset-password": {
		filePath: "C:/job-portal-application-main/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-CL1ziYRn.js",
			"/assets/button-B6CcZJD6.js",
			"/assets/Brand-CeW-s1R_.js",
			"/assets/input-DLoLHtwj.js",
			"/assets/label-tSOuFsVr.js"
		]
	},
	"/select-language": {
		filePath: "C:/job-portal-application-main/src/routes/select-language.tsx",
		children: void 0,
		preloads: [
			"/assets/select-language-CxBnN_BK.js",
			"/assets/useNavigate-qHZ6S4gr.js",
			"/assets/button-B6CcZJD6.js",
			"/assets/check-B9A286jM.js",
			"/assets/Brand-CeW-s1R_.js"
		]
	},
	"/select-role": {
		filePath: "C:/job-portal-application-main/src/routes/select-role.tsx",
		children: void 0,
		preloads: [
			"/assets/select-role-D6ZUai53.js",
			"/assets/useNavigate-qHZ6S4gr.js",
			"/assets/arrow-left-qqtqVSWu.js",
			"/assets/arrow-right-D5i9EBPe.js",
			"/assets/building-2-Bxp1bLZF.js",
			"/assets/user-round-IyTWFdQ2.js",
			"/assets/Brand-CeW-s1R_.js"
		]
	},
	"/superadmin": {
		filePath: "C:/job-portal-application-main/src/routes/superadmin.tsx",
		children: void 0,
		preloads: [
			"/assets/superadmin-C5wddcLm.js",
			"/assets/useNavigate-qHZ6S4gr.js",
			"/assets/button-B6CcZJD6.js",
			"/assets/createLucideIcon-C-6I3_er.js",
			"/assets/award-DuxBo8T7.js",
			"/assets/bell-Buj7PKR4.js",
			"/assets/briefcase-DpM68hSU.js",
			"/assets/building-2-Bxp1bLZF.js",
			"/assets/chart-column-Caau_uQR.js",
			"/assets/check-B9A286jM.js",
			"/assets/chevron-down-CDjcrh-K.js",
			"/assets/globe-COuJzn8x.js",
			"/assets/circle-check-D50E_c-n.js",
			"/assets/circle-x-B1t7DkDd.js",
			"/assets/clock-C_q9muCP.js",
			"/assets/shield-h5UptCwY.js",
			"/assets/eye-off-D32lK6hV.js",
			"/assets/eye-DeLAhnnh.js",
			"/assets/truck-DIjb6dBy.js",
			"/assets/file-text-CS9Gs8Ia.js",
			"/assets/hard-hat-VggsEG9G.js",
			"/assets/indian-rupee-BnTEt8bL.js",
			"/assets/loader-circle-CZI7SSfT.js",
			"/assets/log-out-IW-fEouz.js",
			"/assets/mail-Bw-tBiu7.js",
			"/assets/map-pin-BO_P1FKY.js",
			"/assets/menu-BV2zht-N.js",
			"/assets/plus-9AHZiOfW.js",
			"/assets/phone-BMLDq6iC.js",
			"/assets/search-GlQeEkFt.js",
			"/assets/settings-DympD8sw.js",
			"/assets/shield-check-D34QxPw2.js",
			"/assets/sparkles-CAXQcxtp.js",
			"/assets/star-CeGYC2Fc.js",
			"/assets/target-CQYd_hMt.js",
			"/assets/trash-2-Djp0zjDE.js",
			"/assets/trending-up-CgO96aiD.js",
			"/assets/user-check-BkvNaXEV.js",
			"/assets/user-plus-B_FuWJ-N.js",
			"/assets/user-C_T3C6us.js",
			"/assets/users-D9PQXXxK.js",
			"/assets/wrench-BCOJpq-G.js",
			"/assets/x-CpoVJs46.js",
			"/assets/zap-Cjdg3w8H.js"
		]
	},
	"/_authenticated/applications": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/applications.tsx",
		children: void 0,
		preloads: ["/assets/applications-CGq1llob.js", "/assets/Dashboards-Bwm_kuJz.js"]
	},
	"/_authenticated/control": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.tsx",
		children: [
			"/_authenticated/control/employers",
			"/_authenticated/control/jobs",
			"/_authenticated/control/languages",
			"/_authenticated/control/reports",
			"/_authenticated/control/salary",
			"/_authenticated/control/settings",
			"/_authenticated/control/users"
		],
		preloads: ["/assets/control-CoTqHMdZ.js", "/assets/Dashboards-Bwm_kuJz.js"]
	},
	"/_authenticated/employer": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.tsx",
		children: [
			"/_authenticated/employer/applicants",
			"/_authenticated/employer/employees",
			"/_authenticated/employer/jobs",
			"/_authenticated/employer/reports",
			"/_authenticated/employer/salary"
		],
		preloads: ["/assets/employer-oOq8NVeJ.js", "/assets/Dashboards-Bwm_kuJz.js"]
	},
	"/_authenticated/messages": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/messages.tsx",
		children: void 0,
		preloads: [
			"/assets/messages-oVRKiG27.js",
			"/assets/button-B6CcZJD6.js",
			"/assets/badge-check-BjkusxqB.js",
			"/assets/phone-BMLDq6iC.js",
			"/assets/search-GlQeEkFt.js",
			"/assets/send-DYkO0ETC.js",
			"/assets/input-DLoLHtwj.js",
			"/assets/PublicFooter-BTHB0mRK.js",
			"/assets/PublicHeader-PufhKadS.js"
		]
	},
	"/_authenticated/notifications": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/notifications.tsx",
		children: void 0,
		preloads: ["/assets/notifications-C_0SEy4i.js", "/assets/Dashboards-Bwm_kuJz.js"]
	},
	"/_authenticated/post-job": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/post-job.tsx",
		children: void 0,
		preloads: [
			"/assets/post-job-YOOV0Brp.js",
			"/assets/useNavigate-qHZ6S4gr.js",
			"/assets/button-B6CcZJD6.js",
			"/assets/briefcase-DpM68hSU.js",
			"/assets/building-2-Bxp1bLZF.js",
			"/assets/eye-DeLAhnnh.js",
			"/assets/file-text-CS9Gs8Ia.js",
			"/assets/save-xq9BSy_-.js",
			"/assets/send-DYkO0ETC.js",
			"/assets/wallet-DI_2oW-F.js",
			"/assets/x-CpoVJs46.js",
			"/assets/badge-cR9Q5Tvm.js",
			"/assets/input-DLoLHtwj.js",
			"/assets/PublicFooter-BTHB0mRK.js",
			"/assets/PublicHeader-PufhKadS.js"
		]
	},
	"/_authenticated/profile": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/profile.tsx",
		children: void 0,
		preloads: ["/assets/profile-C62l5JAD.js", "/assets/Dashboards-Bwm_kuJz.js"]
	},
	"/_authenticated/salary": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/salary.tsx",
		children: void 0,
		preloads: ["/assets/salary-B_uYbpXX.js", "/assets/Dashboards-Bwm_kuJz.js"]
	},
	"/company/$companyId": {
		filePath: "C:/job-portal-application-main/src/routes/company.$companyId.tsx",
		children: void 0,
		preloads: [
			"/assets/company._companyId-3zS9ZYDu.js",
			"/assets/useParams-BM81kNrq.js",
			"/assets/button-B6CcZJD6.js",
			"/assets/arrow-left-qqtqVSWu.js",
			"/assets/award-DuxBo8T7.js",
			"/assets/JobCard-Dpxh5mEx.js",
			"/assets/briefcase-DpM68hSU.js",
			"/assets/building-2-Bxp1bLZF.js",
			"/assets/circle-check-D50E_c-n.js",
			"/assets/external-link-Ci90ydo9.js",
			"/assets/map-pin-BO_P1FKY.js",
			"/assets/share-2-bfMH-W8G.js",
			"/assets/shield-check-D34QxPw2.js",
			"/assets/star-CeGYC2Fc.js",
			"/assets/users-D9PQXXxK.js",
			"/assets/PublicFooter-BTHB0mRK.js",
			"/assets/PublicHeader-PufhKadS.js"
		]
	},
	"/jobs/$jobId": {
		filePath: "C:/job-portal-application-main/src/routes/jobs.$jobId.tsx",
		children: void 0,
		preloads: [
			"/assets/jobs._jobId-wbHzb1Le.js",
			"/assets/useParams-BM81kNrq.js",
			"/assets/button-B6CcZJD6.js",
			"/assets/createLucideIcon-C-6I3_er.js",
			"/assets/arrow-left-qqtqVSWu.js",
			"/assets/JobCard-Dpxh5mEx.js",
			"/assets/bookmark-CX2EccEu.js",
			"/assets/briefcase-DpM68hSU.js",
			"/assets/building-2-Bxp1bLZF.js",
			"/assets/circle-check-D50E_c-n.js",
			"/assets/map-pin-BO_P1FKY.js",
			"/assets/send-DYkO0ETC.js",
			"/assets/share-2-bfMH-W8G.js",
			"/assets/user-C_T3C6us.js",
			"/assets/wallet-DI_2oW-F.js",
			"/assets/x-CpoVJs46.js",
			"/assets/badge-cR9Q5Tvm.js",
			"/assets/PublicFooter-BTHB0mRK.js",
			"/assets/PublicHeader-PufhKadS.js"
		]
	},
	"/workers/$workerId": {
		filePath: "C:/job-portal-application-main/src/routes/workers.$workerId.tsx",
		children: void 0,
		preloads: [
			"/assets/workers._workerId-Chx_pFGN.js",
			"/assets/useParams-BM81kNrq.js",
			"/assets/button-B6CcZJD6.js",
			"/assets/badge-check-BjkusxqB.js",
			"/assets/circle-check-D50E_c-n.js",
			"/assets/map-pin-BO_P1FKY.js",
			"/assets/WorkerCard-qGjDaNVd.js",
			"/assets/share-2-bfMH-W8G.js",
			"/assets/user-C_T3C6us.js",
			"/assets/x-CpoVJs46.js",
			"/assets/badge-cR9Q5Tvm.js",
			"/assets/PublicFooter-BTHB0mRK.js",
			"/assets/PublicHeader-PufhKadS.js"
		]
	},
	"/jobs/": {
		filePath: "C:/job-portal-application-main/src/routes/jobs.index.tsx",
		children: void 0,
		preloads: [
			"/assets/jobs.index-C47p3NIU.js",
			"/assets/button-B6CcZJD6.js",
			"/assets/createLucideIcon-C-6I3_er.js",
			"/assets/arrow-left-qqtqVSWu.js",
			"/assets/JobCard-Dpxh5mEx.js",
			"/assets/briefcase-DpM68hSU.js",
			"/assets/chevron-down-CDjcrh-K.js",
			"/assets/truck-DIjb6dBy.js",
			"/assets/sprout-d5s3bUuK.js",
			"/assets/hard-hat-VggsEG9G.js",
			"/assets/stethoscope-DTVTGltd.js",
			"/assets/UserSidebarLayout-Dc3LcpGh.js",
			"/assets/map-pin-BO_P1FKY.js",
			"/assets/rotate-ccw-D1ZTZc2Y.js",
			"/assets/search-GlQeEkFt.js",
			"/assets/shield-check-D34QxPw2.js",
			"/assets/sliders-horizontal-B629Hfim.js",
			"/assets/trending-up-CgO96aiD.js",
			"/assets/wrench-BCOJpq-G.js",
			"/assets/x-CpoVJs46.js",
			"/assets/zap-Cjdg3w8H.js",
			"/assets/input-DLoLHtwj.js",
			"/assets/PublicFooter-BTHB0mRK.js",
			"/assets/PublicHeader-PufhKadS.js"
		]
	},
	"/workers/": {
		filePath: "C:/job-portal-application-main/src/routes/workers.index.tsx",
		children: void 0,
		preloads: [
			"/assets/workers.index-y4A9kNAg.js",
			"/assets/button-B6CcZJD6.js",
			"/assets/createLucideIcon-C-6I3_er.js",
			"/assets/badge-check-BjkusxqB.js",
			"/assets/map-pin-BO_P1FKY.js",
			"/assets/WorkerCard-qGjDaNVd.js",
			"/assets/rotate-ccw-D1ZTZc2Y.js",
			"/assets/search-GlQeEkFt.js",
			"/assets/sliders-horizontal-B629Hfim.js",
			"/assets/users-D9PQXXxK.js",
			"/assets/x-CpoVJs46.js",
			"/assets/badge-cR9Q5Tvm.js",
			"/assets/input-DLoLHtwj.js",
			"/assets/PublicFooter-BTHB0mRK.js",
			"/assets/PublicHeader-PufhKadS.js"
		]
	},
	"/_authenticated/control/employers": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.employers.tsx",
		children: void 0,
		preloads: ["/assets/control.employers-DKWK-7iI.js"]
	},
	"/_authenticated/control/jobs": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.jobs.tsx",
		children: void 0,
		preloads: ["/assets/control.jobs-BZjtF55c.js"]
	},
	"/_authenticated/control/languages": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.languages.tsx",
		children: void 0,
		preloads: ["/assets/control.languages-DzXA1W5A.js"]
	},
	"/_authenticated/control/reports": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.reports.tsx",
		children: void 0,
		preloads: ["/assets/control.reports-DzN-y5gj.js"]
	},
	"/_authenticated/control/salary": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.salary.tsx",
		children: void 0,
		preloads: ["/assets/control.salary-DYHORNCe.js"]
	},
	"/_authenticated/control/settings": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.settings.tsx",
		children: void 0,
		preloads: ["/assets/control.settings-B2vTGkSa.js"]
	},
	"/_authenticated/control/users": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/control.users.tsx",
		children: void 0,
		preloads: ["/assets/control.users-DgIEokGW.js"]
	},
	"/_authenticated/employer/applicants": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.applicants.tsx",
		children: void 0,
		preloads: ["/assets/employer.applicants-C0QQ9P9Y.js"]
	},
	"/_authenticated/employer/employees": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.employees.tsx",
		children: void 0,
		preloads: [
			"/assets/employer.employees-D1_lClLA.js",
			"/assets/chevron-down-CDjcrh-K.js",
			"/assets/clock-C_q9muCP.js",
			"/assets/plus-9AHZiOfW.js",
			"/assets/shield-check-D34QxPw2.js",
			"/assets/sparkles-CAXQcxtp.js",
			"/assets/square-pen-OL_vuVVf.js",
			"/assets/trash-2-Djp0zjDE.js",
			"/assets/user-plus-B_FuWJ-N.js",
			"/assets/x-CpoVJs46.js",
			"/assets/zap-Cjdg3w8H.js"
		]
	},
	"/_authenticated/employer/jobs": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.jobs.tsx",
		children: void 0,
		preloads: ["/assets/employer.jobs-BXgBjPO_.js"]
	},
	"/_authenticated/employer/reports": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.reports.tsx",
		children: void 0,
		preloads: ["/assets/employer.reports-CAjKFfi0.js"]
	},
	"/_authenticated/employer/salary": {
		filePath: "C:/job-portal-application-main/src/routes/_authenticated/employer.salary.tsx",
		children: void 0,
		preloads: ["/assets/employer.salary-D9T-J6Cb.js"]
	}
} });
//#endregion
export { tsrStartManifest };
