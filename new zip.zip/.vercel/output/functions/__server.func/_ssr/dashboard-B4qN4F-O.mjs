import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-B4qN4F-O.js
var $$splitComponentImporter = () => import("./dashboard-DYU401TI.mjs");
var Route = createFileRoute("/dashboard")({
	validateSearch: (search) => {
		return { tab: search.tab };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
