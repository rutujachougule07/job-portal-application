import { D as isCloudWorkstation, L as globalthis_default, N as isSafari, P as pingServer, R as init_globalthis, S as getDefaultEmulatorHostnameAndPort, T as getUA, _ as createMockUserToken, a as _isFirebaseServerApp, d as Logger, f as Component, h as FirebaseError, i as _getProvider, l as registerVersion, o as _registerComponent, r as SDK_VERSION, s as getApp, u as LogLevel, w as getModularInstance, y as deepEqual } from "./analytics+[...].mjs";

import { Buffer } from "node:buffer";
//#region node_modules/@firebase/webchannel-wrapper/dist/bloom-blob/esm/bloom_blob_es2018.js
init_globalthis();
var commonjsGlobal$1 = typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : typeof globalthis_default !== "undefined" ? globalthis_default : typeof self !== "undefined" ? self : {};
var bloom_blob_es2018 = {};
/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/
var Integer;
var Md5;
(function() {
	var h;
	/** @license
	
	Copyright The Closure Library Authors.
	SPDX-License-Identifier: Apache-2.0
	*/
	function k(d, a) {
		function c() {}
		c.prototype = a.prototype;
		d.F = a.prototype;
		d.prototype = new c();
		d.prototype.constructor = d;
		d.D = function(f, e, g) {
			for (var b = Array(arguments.length - 2), r = 2; r < arguments.length; r++) b[r - 2] = arguments[r];
			return a.prototype[e].apply(f, b);
		};
	}
	function l() {
		this.blockSize = -1;
	}
	function m() {
		this.blockSize = -1;
		this.blockSize = 64;
		this.g = Array(4);
		this.C = Array(this.blockSize);
		this.o = this.h = 0;
		this.u();
	}
	k(m, l);
	m.prototype.u = function() {
		this.g[0] = 1732584193;
		this.g[1] = 4023233417;
		this.g[2] = 2562383102;
		this.g[3] = 271733878;
		this.o = this.h = 0;
	};
	function n(d, a, c) {
		c || (c = 0);
		const f = Array(16);
		if (typeof a === "string") for (var e = 0; e < 16; ++e) f[e] = a.charCodeAt(c++) | a.charCodeAt(c++) << 8 | a.charCodeAt(c++) << 16 | a.charCodeAt(c++) << 24;
		else for (e = 0; e < 16; ++e) f[e] = a[c++] | a[c++] << 8 | a[c++] << 16 | a[c++] << 24;
		a = d.g[0];
		c = d.g[1];
		e = d.g[2];
		let g = d.g[3], b;
		b = a + (g ^ c & (e ^ g)) + f[0] + 3614090360 & 4294967295;
		a = c + (b << 7 & 4294967295 | b >>> 25);
		b = g + (e ^ a & (c ^ e)) + f[1] + 3905402710 & 4294967295;
		g = a + (b << 12 & 4294967295 | b >>> 20);
		b = e + (c ^ g & (a ^ c)) + f[2] + 606105819 & 4294967295;
		e = g + (b << 17 & 4294967295 | b >>> 15);
		b = c + (a ^ e & (g ^ a)) + f[3] + 3250441966 & 4294967295;
		c = e + (b << 22 & 4294967295 | b >>> 10);
		b = a + (g ^ c & (e ^ g)) + f[4] + 4118548399 & 4294967295;
		a = c + (b << 7 & 4294967295 | b >>> 25);
		b = g + (e ^ a & (c ^ e)) + f[5] + 1200080426 & 4294967295;
		g = a + (b << 12 & 4294967295 | b >>> 20);
		b = e + (c ^ g & (a ^ c)) + f[6] + 2821735955 & 4294967295;
		e = g + (b << 17 & 4294967295 | b >>> 15);
		b = c + (a ^ e & (g ^ a)) + f[7] + 4249261313 & 4294967295;
		c = e + (b << 22 & 4294967295 | b >>> 10);
		b = a + (g ^ c & (e ^ g)) + f[8] + 1770035416 & 4294967295;
		a = c + (b << 7 & 4294967295 | b >>> 25);
		b = g + (e ^ a & (c ^ e)) + f[9] + 2336552879 & 4294967295;
		g = a + (b << 12 & 4294967295 | b >>> 20);
		b = e + (c ^ g & (a ^ c)) + f[10] + 4294925233 & 4294967295;
		e = g + (b << 17 & 4294967295 | b >>> 15);
		b = c + (a ^ e & (g ^ a)) + f[11] + 2304563134 & 4294967295;
		c = e + (b << 22 & 4294967295 | b >>> 10);
		b = a + (g ^ c & (e ^ g)) + f[12] + 1804603682 & 4294967295;
		a = c + (b << 7 & 4294967295 | b >>> 25);
		b = g + (e ^ a & (c ^ e)) + f[13] + 4254626195 & 4294967295;
		g = a + (b << 12 & 4294967295 | b >>> 20);
		b = e + (c ^ g & (a ^ c)) + f[14] + 2792965006 & 4294967295;
		e = g + (b << 17 & 4294967295 | b >>> 15);
		b = c + (a ^ e & (g ^ a)) + f[15] + 1236535329 & 4294967295;
		c = e + (b << 22 & 4294967295 | b >>> 10);
		b = a + (e ^ g & (c ^ e)) + f[1] + 4129170786 & 4294967295;
		a = c + (b << 5 & 4294967295 | b >>> 27);
		b = g + (c ^ e & (a ^ c)) + f[6] + 3225465664 & 4294967295;
		g = a + (b << 9 & 4294967295 | b >>> 23);
		b = e + (a ^ c & (g ^ a)) + f[11] + 643717713 & 4294967295;
		e = g + (b << 14 & 4294967295 | b >>> 18);
		b = c + (g ^ a & (e ^ g)) + f[0] + 3921069994 & 4294967295;
		c = e + (b << 20 & 4294967295 | b >>> 12);
		b = a + (e ^ g & (c ^ e)) + f[5] + 3593408605 & 4294967295;
		a = c + (b << 5 & 4294967295 | b >>> 27);
		b = g + (c ^ e & (a ^ c)) + f[10] + 38016083 & 4294967295;
		g = a + (b << 9 & 4294967295 | b >>> 23);
		b = e + (a ^ c & (g ^ a)) + f[15] + 3634488961 & 4294967295;
		e = g + (b << 14 & 4294967295 | b >>> 18);
		b = c + (g ^ a & (e ^ g)) + f[4] + 3889429448 & 4294967295;
		c = e + (b << 20 & 4294967295 | b >>> 12);
		b = a + (e ^ g & (c ^ e)) + f[9] + 568446438 & 4294967295;
		a = c + (b << 5 & 4294967295 | b >>> 27);
		b = g + (c ^ e & (a ^ c)) + f[14] + 3275163606 & 4294967295;
		g = a + (b << 9 & 4294967295 | b >>> 23);
		b = e + (a ^ c & (g ^ a)) + f[3] + 4107603335 & 4294967295;
		e = g + (b << 14 & 4294967295 | b >>> 18);
		b = c + (g ^ a & (e ^ g)) + f[8] + 1163531501 & 4294967295;
		c = e + (b << 20 & 4294967295 | b >>> 12);
		b = a + (e ^ g & (c ^ e)) + f[13] + 2850285829 & 4294967295;
		a = c + (b << 5 & 4294967295 | b >>> 27);
		b = g + (c ^ e & (a ^ c)) + f[2] + 4243563512 & 4294967295;
		g = a + (b << 9 & 4294967295 | b >>> 23);
		b = e + (a ^ c & (g ^ a)) + f[7] + 1735328473 & 4294967295;
		e = g + (b << 14 & 4294967295 | b >>> 18);
		b = c + (g ^ a & (e ^ g)) + f[12] + 2368359562 & 4294967295;
		c = e + (b << 20 & 4294967295 | b >>> 12);
		b = a + (c ^ e ^ g) + f[5] + 4294588738 & 4294967295;
		a = c + (b << 4 & 4294967295 | b >>> 28);
		b = g + (a ^ c ^ e) + f[8] + 2272392833 & 4294967295;
		g = a + (b << 11 & 4294967295 | b >>> 21);
		b = e + (g ^ a ^ c) + f[11] + 1839030562 & 4294967295;
		e = g + (b << 16 & 4294967295 | b >>> 16);
		b = c + (e ^ g ^ a) + f[14] + 4259657740 & 4294967295;
		c = e + (b << 23 & 4294967295 | b >>> 9);
		b = a + (c ^ e ^ g) + f[1] + 2763975236 & 4294967295;
		a = c + (b << 4 & 4294967295 | b >>> 28);
		b = g + (a ^ c ^ e) + f[4] + 1272893353 & 4294967295;
		g = a + (b << 11 & 4294967295 | b >>> 21);
		b = e + (g ^ a ^ c) + f[7] + 4139469664 & 4294967295;
		e = g + (b << 16 & 4294967295 | b >>> 16);
		b = c + (e ^ g ^ a) + f[10] + 3200236656 & 4294967295;
		c = e + (b << 23 & 4294967295 | b >>> 9);
		b = a + (c ^ e ^ g) + f[13] + 681279174 & 4294967295;
		a = c + (b << 4 & 4294967295 | b >>> 28);
		b = g + (a ^ c ^ e) + f[0] + 3936430074 & 4294967295;
		g = a + (b << 11 & 4294967295 | b >>> 21);
		b = e + (g ^ a ^ c) + f[3] + 3572445317 & 4294967295;
		e = g + (b << 16 & 4294967295 | b >>> 16);
		b = c + (e ^ g ^ a) + f[6] + 76029189 & 4294967295;
		c = e + (b << 23 & 4294967295 | b >>> 9);
		b = a + (c ^ e ^ g) + f[9] + 3654602809 & 4294967295;
		a = c + (b << 4 & 4294967295 | b >>> 28);
		b = g + (a ^ c ^ e) + f[12] + 3873151461 & 4294967295;
		g = a + (b << 11 & 4294967295 | b >>> 21);
		b = e + (g ^ a ^ c) + f[15] + 530742520 & 4294967295;
		e = g + (b << 16 & 4294967295 | b >>> 16);
		b = c + (e ^ g ^ a) + f[2] + 3299628645 & 4294967295;
		c = e + (b << 23 & 4294967295 | b >>> 9);
		b = a + (e ^ (c | ~g)) + f[0] + 4096336452 & 4294967295;
		a = c + (b << 6 & 4294967295 | b >>> 26);
		b = g + (c ^ (a | ~e)) + f[7] + 1126891415 & 4294967295;
		g = a + (b << 10 & 4294967295 | b >>> 22);
		b = e + (a ^ (g | ~c)) + f[14] + 2878612391 & 4294967295;
		e = g + (b << 15 & 4294967295 | b >>> 17);
		b = c + (g ^ (e | ~a)) + f[5] + 4237533241 & 4294967295;
		c = e + (b << 21 & 4294967295 | b >>> 11);
		b = a + (e ^ (c | ~g)) + f[12] + 1700485571 & 4294967295;
		a = c + (b << 6 & 4294967295 | b >>> 26);
		b = g + (c ^ (a | ~e)) + f[3] + 2399980690 & 4294967295;
		g = a + (b << 10 & 4294967295 | b >>> 22);
		b = e + (a ^ (g | ~c)) + f[10] + 4293915773 & 4294967295;
		e = g + (b << 15 & 4294967295 | b >>> 17);
		b = c + (g ^ (e | ~a)) + f[1] + 2240044497 & 4294967295;
		c = e + (b << 21 & 4294967295 | b >>> 11);
		b = a + (e ^ (c | ~g)) + f[8] + 1873313359 & 4294967295;
		a = c + (b << 6 & 4294967295 | b >>> 26);
		b = g + (c ^ (a | ~e)) + f[15] + 4264355552 & 4294967295;
		g = a + (b << 10 & 4294967295 | b >>> 22);
		b = e + (a ^ (g | ~c)) + f[6] + 2734768916 & 4294967295;
		e = g + (b << 15 & 4294967295 | b >>> 17);
		b = c + (g ^ (e | ~a)) + f[13] + 1309151649 & 4294967295;
		c = e + (b << 21 & 4294967295 | b >>> 11);
		b = a + (e ^ (c | ~g)) + f[4] + 4149444226 & 4294967295;
		a = c + (b << 6 & 4294967295 | b >>> 26);
		b = g + (c ^ (a | ~e)) + f[11] + 3174756917 & 4294967295;
		g = a + (b << 10 & 4294967295 | b >>> 22);
		b = e + (a ^ (g | ~c)) + f[2] + 718787259 & 4294967295;
		e = g + (b << 15 & 4294967295 | b >>> 17);
		b = c + (g ^ (e | ~a)) + f[9] + 3951481745 & 4294967295;
		d.g[0] = d.g[0] + a & 4294967295;
		d.g[1] = d.g[1] + (e + (b << 21 & 4294967295 | b >>> 11)) & 4294967295;
		d.g[2] = d.g[2] + e & 4294967295;
		d.g[3] = d.g[3] + g & 4294967295;
	}
	m.prototype.v = function(d, a) {
		a === void 0 && (a = d.length);
		const c = a - this.blockSize, f = this.C;
		let e = this.h, g = 0;
		for (; g < a;) {
			if (e == 0) for (; g <= c;) n(this, d, g), g += this.blockSize;
			if (typeof d === "string") {
				for (; g < a;) if (f[e++] = d.charCodeAt(g++), e == this.blockSize) {
					n(this, f);
					e = 0;
					break;
				}
			} else for (; g < a;) if (f[e++] = d[g++], e == this.blockSize) {
				n(this, f);
				e = 0;
				break;
			}
		}
		this.h = e;
		this.o += a;
	};
	m.prototype.A = function() {
		var d = Array((this.h < 56 ? this.blockSize : this.blockSize * 2) - this.h);
		d[0] = 128;
		for (var a = 1; a < d.length - 8; ++a) d[a] = 0;
		a = this.o * 8;
		for (var c = d.length - 8; c < d.length; ++c) d[c] = a & 255, a /= 256;
		this.v(d);
		d = Array(16);
		a = 0;
		for (c = 0; c < 4; ++c) for (let f = 0; f < 32; f += 8) d[a++] = this.g[c] >>> f & 255;
		return d;
	};
	function p(d, a) {
		var c = q;
		return Object.prototype.hasOwnProperty.call(c, d) ? c[d] : c[d] = a(d);
	}
	function t(d, a) {
		this.h = a;
		const c = [];
		let f = true;
		for (let e = d.length - 1; e >= 0; e--) {
			const g = d[e] | 0;
			f && g == a || (c[e] = g, f = false);
		}
		this.g = c;
	}
	var q = {};
	function u(d) {
		return -128 <= d && d < 128 ? p(d, function(a) {
			return new t([a | 0], a < 0 ? -1 : 0);
		}) : new t([d | 0], d < 0 ? -1 : 0);
	}
	function v(d) {
		if (isNaN(d) || !isFinite(d)) return w;
		if (d < 0) return x(v(-d));
		const a = [];
		let c = 1;
		for (let f = 0; d >= c; f++) a[f] = d / c | 0, c *= 4294967296;
		return new t(a, 0);
	}
	function y(d, a) {
		if (d.length == 0) throw Error("number format error: empty string");
		a = a || 10;
		if (a < 2 || 36 < a) throw Error("radix out of range: " + a);
		if (d.charAt(0) == "-") return x(y(d.substring(1), a));
		if (d.indexOf("-") >= 0) throw Error("number format error: interior \"-\" character");
		const c = v(Math.pow(a, 8));
		let f = w;
		for (let g = 0; g < d.length; g += 8) {
			var e = Math.min(8, d.length - g);
			const b = parseInt(d.substring(g, g + e), a);
			e < 8 ? (e = v(Math.pow(a, e)), f = f.j(e).add(v(b))) : (f = f.j(c), f = f.add(v(b)));
		}
		return f;
	}
	var w = u(0), z = u(1), A = u(16777216);
	h = t.prototype;
	h.m = function() {
		if (B(this)) return -x(this).m();
		let d = 0, a = 1;
		for (let c = 0; c < this.g.length; c++) {
			const f = this.i(c);
			d += (f >= 0 ? f : 4294967296 + f) * a;
			a *= 4294967296;
		}
		return d;
	};
	h.toString = function(d) {
		d = d || 10;
		if (d < 2 || 36 < d) throw Error("radix out of range: " + d);
		if (C(this)) return "0";
		if (B(this)) return "-" + x(this).toString(d);
		const a = v(Math.pow(d, 6));
		var c = this;
		let f = "";
		for (;;) {
			const e = D(c, a).g;
			c = F(c, e.j(a));
			let g = ((c.g.length > 0 ? c.g[0] : c.h) >>> 0).toString(d);
			c = e;
			if (C(c)) return g + f;
			for (; g.length < 6;) g = "0" + g;
			f = g + f;
		}
	};
	h.i = function(d) {
		return d < 0 ? 0 : d < this.g.length ? this.g[d] : this.h;
	};
	function C(d) {
		if (d.h != 0) return false;
		for (let a = 0; a < d.g.length; a++) if (d.g[a] != 0) return false;
		return true;
	}
	function B(d) {
		return d.h == -1;
	}
	h.l = function(d) {
		d = F(this, d);
		return B(d) ? -1 : C(d) ? 0 : 1;
	};
	function x(d) {
		const a = d.g.length, c = [];
		for (let f = 0; f < a; f++) c[f] = ~d.g[f];
		return new t(c, ~d.h).add(z);
	}
	h.abs = function() {
		return B(this) ? x(this) : this;
	};
	h.add = function(d) {
		const a = Math.max(this.g.length, d.g.length), c = [];
		let f = 0;
		for (let e = 0; e <= a; e++) {
			let g = f + (this.i(e) & 65535) + (d.i(e) & 65535), b = (g >>> 16) + (this.i(e) >>> 16) + (d.i(e) >>> 16);
			f = b >>> 16;
			g &= 65535;
			b &= 65535;
			c[e] = b << 16 | g;
		}
		return new t(c, c[c.length - 1] & -2147483648 ? -1 : 0);
	};
	function F(d, a) {
		return d.add(x(a));
	}
	h.j = function(d) {
		if (C(this) || C(d)) return w;
		if (B(this)) return B(d) ? x(this).j(x(d)) : x(x(this).j(d));
		if (B(d)) return x(this.j(x(d)));
		if (this.l(A) < 0 && d.l(A) < 0) return v(this.m() * d.m());
		const a = this.g.length + d.g.length, c = [];
		for (var f = 0; f < 2 * a; f++) c[f] = 0;
		for (f = 0; f < this.g.length; f++) for (let e = 0; e < d.g.length; e++) {
			const g = this.i(f) >>> 16, b = this.i(f) & 65535, r = d.i(e) >>> 16, E = d.i(e) & 65535;
			c[2 * f + 2 * e] += b * E;
			G(c, 2 * f + 2 * e);
			c[2 * f + 2 * e + 1] += g * E;
			G(c, 2 * f + 2 * e + 1);
			c[2 * f + 2 * e + 1] += b * r;
			G(c, 2 * f + 2 * e + 1);
			c[2 * f + 2 * e + 2] += g * r;
			G(c, 2 * f + 2 * e + 2);
		}
		for (d = 0; d < a; d++) c[d] = c[2 * d + 1] << 16 | c[2 * d];
		for (d = a; d < 2 * a; d++) c[d] = 0;
		return new t(c, 0);
	};
	function G(d, a) {
		for (; (d[a] & 65535) != d[a];) d[a + 1] += d[a] >>> 16, d[a] &= 65535, a++;
	}
	function H(d, a) {
		this.g = d;
		this.h = a;
	}
	function D(d, a) {
		if (C(a)) throw Error("division by zero");
		if (C(d)) return new H(w, w);
		if (B(d)) return a = D(x(d), a), new H(x(a.g), x(a.h));
		if (B(a)) return a = D(d, x(a)), new H(x(a.g), a.h);
		if (d.g.length > 30) {
			if (B(d) || B(a)) throw Error("slowDivide_ only works with positive integers.");
			for (var c = z, f = a; f.l(d) <= 0;) c = I(c), f = I(f);
			var e = J(c, 1), g = J(f, 1);
			f = J(f, 2);
			for (c = J(c, 2); !C(f);) {
				var b = g.add(f);
				b.l(d) <= 0 && (e = e.add(c), g = b);
				f = J(f, 1);
				c = J(c, 1);
			}
			a = F(d, e.j(a));
			return new H(e, a);
		}
		for (e = w; d.l(a) >= 0;) {
			c = Math.max(1, Math.floor(d.m() / a.m()));
			f = Math.ceil(Math.log(c) / Math.LN2);
			f = f <= 48 ? 1 : Math.pow(2, f - 48);
			g = v(c);
			for (b = g.j(a); B(b) || b.l(d) > 0;) c -= f, g = v(c), b = g.j(a);
			C(g) && (g = z);
			e = e.add(g);
			d = F(d, b);
		}
		return new H(e, d);
	}
	h.B = function(d) {
		return D(this, d).h;
	};
	h.and = function(d) {
		const a = Math.max(this.g.length, d.g.length), c = [];
		for (let f = 0; f < a; f++) c[f] = this.i(f) & d.i(f);
		return new t(c, this.h & d.h);
	};
	h.or = function(d) {
		const a = Math.max(this.g.length, d.g.length), c = [];
		for (let f = 0; f < a; f++) c[f] = this.i(f) | d.i(f);
		return new t(c, this.h | d.h);
	};
	h.xor = function(d) {
		const a = Math.max(this.g.length, d.g.length), c = [];
		for (let f = 0; f < a; f++) c[f] = this.i(f) ^ d.i(f);
		return new t(c, this.h ^ d.h);
	};
	function I(d) {
		const a = d.g.length + 1, c = [];
		for (let f = 0; f < a; f++) c[f] = d.i(f) << 1 | d.i(f - 1) >>> 31;
		return new t(c, d.h);
	}
	function J(d, a) {
		const c = a >> 5;
		a %= 32;
		const f = d.g.length - c, e = [];
		for (let g = 0; g < f; g++) e[g] = a > 0 ? d.i(g + c) >>> a | d.i(g + c + 1) << 32 - a : d.i(g + c);
		return new t(e, d.h);
	}
	m.prototype.digest = m.prototype.A;
	m.prototype.reset = m.prototype.u;
	m.prototype.update = m.prototype.v;
	Md5 = bloom_blob_es2018.Md5 = m;
	t.prototype.add = t.prototype.add;
	t.prototype.multiply = t.prototype.j;
	t.prototype.modulo = t.prototype.B;
	t.prototype.compare = t.prototype.l;
	t.prototype.toNumber = t.prototype.m;
	t.prototype.toString = t.prototype.toString;
	t.prototype.getBits = t.prototype.i;
	t.fromNumber = v;
	t.fromString = y;
	Integer = bloom_blob_es2018.Integer = t;
}).apply(typeof commonjsGlobal$1 !== "undefined" ? commonjsGlobal$1 : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {});
//#endregion
//#region node_modules/@firebase/webchannel-wrapper/dist/webchannel-blob/esm/webchannel_blob_es2018.js
init_globalthis();
var commonjsGlobal = typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : typeof globalthis_default !== "undefined" ? globalthis_default : typeof self !== "undefined" ? self : {};
var webchannel_blob_es2018 = {};
/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/
var XhrIo;
var WebChannel;
var EventType;
var ErrorCode;
var Stat;
var Event;
var getStatEventTarget;
var createWebChannelTransport;
(function() {
	var h, aa = Object.defineProperty;
	function ba(a) {
		a = [
			"object" == typeof globalThis && globalThis,
			a,
			"object" == typeof window && window,
			"object" == typeof self && self,
			"object" == typeof commonjsGlobal && commonjsGlobal
		];
		for (var b = 0; b < a.length; ++b) {
			var c = a[b];
			if (c && c.Math == Math) return c;
		}
		throw Error("Cannot find global object");
	}
	var ca = ba(this);
	function da(a, b) {
		if (b) a: {
			var c = ca;
			a = a.split(".");
			for (var d = 0; d < a.length - 1; d++) {
				var e = a[d];
				if (!(e in c)) break a;
				c = c[e];
			}
			a = a[a.length - 1];
			d = c[a];
			b = b(d);
			b != d && b != null && aa(c, a, {
				configurable: true,
				writable: true,
				value: b
			});
		}
	}
	da("Symbol.dispose", function(a) {
		return a ? a : Symbol("Symbol.dispose");
	});
	da("Array.prototype.values", function(a) {
		return a ? a : function() {
			return this[Symbol.iterator]();
		};
	});
	da("Object.entries", function(a) {
		return a ? a : function(b) {
			var c = [], d;
			for (d in b) Object.prototype.hasOwnProperty.call(b, d) && c.push([d, b[d]]);
			return c;
		};
	});
	/** @license
	
	Copyright The Closure Library Authors.
	SPDX-License-Identifier: Apache-2.0
	*/
	var ea = ea || {}, l = this || self;
	function n(a) {
		var b = typeof a;
		return b == "object" && a != null || b == "function";
	}
	function fa(a, b, c) {
		return a.call.apply(a.bind, arguments);
	}
	function p(a, b, c) {
		p = fa;
		return p.apply(null, arguments);
	}
	function ha(a, b) {
		var c = Array.prototype.slice.call(arguments, 1);
		return function() {
			var d = c.slice();
			d.push.apply(d, arguments);
			return a.apply(this, d);
		};
	}
	function t(a, b) {
		function c() {}
		c.prototype = b.prototype;
		a.Z = b.prototype;
		a.prototype = new c();
		a.prototype.constructor = a;
		a.Ob = function(d, e, f) {
			for (var g = Array(arguments.length - 2), k = 2; k < arguments.length; k++) g[k - 2] = arguments[k];
			return b.prototype[e].apply(d, g);
		};
	}
	var ia = typeof AsyncContext !== "undefined" && typeof AsyncContext.Snapshot === "function" ? (a) => a && AsyncContext.Snapshot.wrap(a) : (a) => a;
	function ja(a) {
		const b = a.length;
		if (b > 0) {
			const c = Array(b);
			for (let d = 0; d < b; d++) c[d] = a[d];
			return c;
		}
		return [];
	}
	function ka(a, b) {
		for (let d = 1; d < arguments.length; d++) {
			const e = arguments[d];
			var c = typeof e;
			c = c != "object" ? c : e ? Array.isArray(e) ? "array" : c : "null";
			if (c == "array" || c == "object" && typeof e.length == "number") {
				c = a.length || 0;
				const f = e.length || 0;
				a.length = c + f;
				for (let g = 0; g < f; g++) a[c + g] = e[g];
			} else a.push(e);
		}
	}
	class la {
		constructor(a, b) {
			this.i = a;
			this.j = b;
			this.h = 0;
			this.g = null;
		}
		get() {
			let a;
			this.h > 0 ? (this.h--, a = this.g, this.g = a.next, a.next = null) : a = this.i();
			return a;
		}
	}
	function ma(a) {
		l.setTimeout(() => {
			throw a;
		}, 0);
	}
	function na() {
		var a = oa;
		let b = null;
		a.g && (b = a.g, a.g = a.g.next, a.g || (a.h = null), b.next = null);
		return b;
	}
	class pa {
		constructor() {
			this.h = this.g = null;
		}
		add(a, b) {
			const c = qa.get();
			c.set(a, b);
			this.h ? this.h.next = c : this.g = c;
			this.h = c;
		}
	}
	var qa = new la(() => new ra(), (a) => a.reset());
	class ra {
		constructor() {
			this.next = this.g = this.h = null;
		}
		set(a, b) {
			this.h = a;
			this.g = b;
			this.next = null;
		}
		reset() {
			this.next = this.g = this.h = null;
		}
	}
	let u, v = false, oa = new pa(), ta = () => {
		const a = Promise.resolve(void 0);
		u = () => {
			a.then(sa);
		};
	};
	function sa() {
		for (var a; a = na();) {
			try {
				a.h.call(a.g);
			} catch (c) {
				ma(c);
			}
			var b = qa;
			b.j(a);
			b.h < 100 && (b.h++, a.next = b.g, b.g = a);
		}
		v = false;
	}
	function w() {
		this.u = this.u;
		this.C = this.C;
	}
	w.prototype.u = false;
	w.prototype.dispose = function() {
		this.u || (this.u = true, this.N());
	};
	w.prototype[Symbol.dispose] = function() {
		this.dispose();
	};
	w.prototype.N = function() {
		if (this.C) for (; this.C.length;) this.C.shift()();
	};
	function x(a, b) {
		this.type = a;
		this.g = this.target = b;
		this.defaultPrevented = false;
	}
	x.prototype.h = function() {
		this.defaultPrevented = true;
	};
	var ua = function() {
		if (!l.addEventListener || !Object.defineProperty) return false;
		var a = false, b = Object.defineProperty({}, "passive", { get: function() {
			a = true;
		} });
		try {
			const c = () => {};
			l.addEventListener("test", c, b);
			l.removeEventListener("test", c, b);
		} catch (c) {}
		return a;
	}();
	function y(a) {
		return /^[\s\xa0]*$/.test(a);
	}
	function z(a, b) {
		x.call(this, a ? a.type : "");
		this.relatedTarget = this.g = this.target = null;
		this.button = this.screenY = this.screenX = this.clientY = this.clientX = 0;
		this.key = "";
		this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = false;
		this.state = null;
		this.pointerId = 0;
		this.pointerType = "";
		this.i = null;
		a && this.init(a, b);
	}
	t(z, x);
	z.prototype.init = function(a, b) {
		const c = this.type = a.type, d = a.changedTouches && a.changedTouches.length ? a.changedTouches[0] : null;
		this.target = a.target || a.srcElement;
		this.g = b;
		b = a.relatedTarget;
		b || (c == "mouseover" ? b = a.fromElement : c == "mouseout" && (b = a.toElement));
		this.relatedTarget = b;
		d ? (this.clientX = d.clientX !== void 0 ? d.clientX : d.pageX, this.clientY = d.clientY !== void 0 ? d.clientY : d.pageY, this.screenX = d.screenX || 0, this.screenY = d.screenY || 0) : (this.clientX = a.clientX !== void 0 ? a.clientX : a.pageX, this.clientY = a.clientY !== void 0 ? a.clientY : a.pageY, this.screenX = a.screenX || 0, this.screenY = a.screenY || 0);
		this.button = a.button;
		this.key = a.key || "";
		this.ctrlKey = a.ctrlKey;
		this.altKey = a.altKey;
		this.shiftKey = a.shiftKey;
		this.metaKey = a.metaKey;
		this.pointerId = a.pointerId || 0;
		this.pointerType = a.pointerType;
		this.state = a.state;
		this.i = a;
		a.defaultPrevented && z.Z.h.call(this);
	};
	z.prototype.h = function() {
		z.Z.h.call(this);
		const a = this.i;
		a.preventDefault ? a.preventDefault() : a.returnValue = false;
	};
	var B = "closure_listenable_" + (Math.random() * 1e6 | 0);
	var va = 0;
	function wa(a, b, c, d, e) {
		this.listener = a;
		this.proxy = null;
		this.src = b;
		this.type = c;
		this.capture = !!d;
		this.ha = e;
		this.key = ++va;
		this.da = this.fa = false;
	}
	function xa(a) {
		a.da = true;
		a.listener = null;
		a.proxy = null;
		a.src = null;
		a.ha = null;
	}
	function ya(a, b, c) {
		for (const d in a) b.call(c, a[d], d, a);
	}
	function Aa(a, b) {
		for (const c in a) b.call(void 0, a[c], c, a);
	}
	function Ba(a) {
		const b = {};
		for (const c in a) b[c] = a[c];
		return b;
	}
	const Ca = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");
	function Da(a, b) {
		let c, d;
		for (let e = 1; e < arguments.length; e++) {
			d = arguments[e];
			for (c in d) a[c] = d[c];
			for (let f = 0; f < Ca.length; f++) c = Ca[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c]);
		}
	}
	function Ea(a) {
		this.src = a;
		this.g = {};
		this.h = 0;
	}
	Ea.prototype.add = function(a, b, c, d, e) {
		const f = a.toString();
		a = this.g[f];
		a || (a = this.g[f] = [], this.h++);
		const g = Fa(a, b, d, e);
		g > -1 ? (b = a[g], c || (b.fa = false)) : (b = new wa(b, this.src, f, !!d, e), b.fa = c, a.push(b));
		return b;
	};
	function Ga(a, b) {
		const c = b.type;
		if (c in a.g) {
			var d = a.g[c], e = Array.prototype.indexOf.call(d, b, void 0), f;
			(f = e >= 0) && Array.prototype.splice.call(d, e, 1);
			f && (xa(b), a.g[c].length == 0 && (delete a.g[c], a.h--));
		}
	}
	function Fa(a, b, c, d) {
		for (let e = 0; e < a.length; ++e) {
			const f = a[e];
			if (!f.da && f.listener == b && f.capture == !!c && f.ha == d) return e;
		}
		return -1;
	}
	var Ha = "closure_lm_" + (Math.random() * 1e6 | 0), Ia = {};
	function Ka(a, b, c, d, e) {
		if (Array.isArray(b)) {
			for (let f = 0; f < b.length; f++) Ka(a, b[f], c, d, e);
			return null;
		}
		c = Ma(c);
		return a && a[B] ? a.J(b, c, n(d) ? !!d.capture : false, e) : Na(a, b, c, false, d, e);
	}
	function Na(a, b, c, d, e, f) {
		if (!b) throw Error("Invalid event type");
		const g = n(e) ? !!e.capture : !!e;
		let k = Oa(a);
		k || (a[Ha] = k = new Ea(a));
		c = k.add(b, c, d, g, f);
		if (c.proxy) return c;
		d = Pa();
		c.proxy = d;
		d.src = a;
		d.listener = c;
		if (a.addEventListener) ua || (e = g), e === void 0 && (e = false), a.addEventListener(b.toString(), d, e);
		else if (a.attachEvent) a.attachEvent(Qa(b.toString()), d);
		else if (a.addListener && a.removeListener) a.addListener(d);
		else throw Error("addEventListener and attachEvent are unavailable.");
		return c;
	}
	function Pa() {
		function a(c) {
			return b.call(a.src, a.listener, c);
		}
		const b = Ra;
		return a;
	}
	function Sa(a, b, c, d, e) {
		if (Array.isArray(b)) for (var f = 0; f < b.length; f++) Sa(a, b[f], c, d, e);
		else (d = n(d) ? !!d.capture : !!d, c = Ma(c), a && a[B]) ? (a = a.i, f = String(b).toString(), f in a.g && (b = a.g[f], c = Fa(b, c, d, e), c > -1 && (xa(b[c]), Array.prototype.splice.call(b, c, 1), b.length == 0 && (delete a.g[f], a.h--)))) : a && (a = Oa(a)) && (b = a.g[b.toString()], a = -1, b && (a = Fa(b, c, d, e)), (c = a > -1 ? b[a] : null) && Ta(c));
	}
	function Ta(a) {
		if (typeof a !== "number" && a && !a.da) {
			var b = a.src;
			if (b && b[B]) Ga(b.i, a);
			else {
				var c = a.type, d = a.proxy;
				b.removeEventListener ? b.removeEventListener(c, d, a.capture) : b.detachEvent ? b.detachEvent(Qa(c), d) : b.addListener && b.removeListener && b.removeListener(d);
				(c = Oa(b)) ? (Ga(c, a), c.h == 0 && (c.src = null, b[Ha] = null)) : xa(a);
			}
		}
	}
	function Qa(a) {
		return a in Ia ? Ia[a] : Ia[a] = "on" + a;
	}
	function Ra(a, b) {
		if (a.da) a = true;
		else {
			b = new z(b, this);
			const c = a.listener, d = a.ha || a.src;
			a.fa && Ta(a);
			a = c.call(d, b);
		}
		return a;
	}
	function Oa(a) {
		a = a[Ha];
		return a instanceof Ea ? a : null;
	}
	var Ua = "__closure_events_fn_" + (Math.random() * 1e9 >>> 0);
	function Ma(a) {
		if (typeof a === "function") return a;
		a[Ua] || (a[Ua] = function(b) {
			return a.handleEvent(b);
		});
		return a[Ua];
	}
	function C() {
		w.call(this);
		this.i = new Ea(this);
		this.M = this;
		this.G = null;
	}
	t(C, w);
	C.prototype[B] = true;
	C.prototype.removeEventListener = function(a, b, c, d) {
		Sa(this, a, b, c, d);
	};
	function D(a, b) {
		var c, d = a.G;
		if (d) for (c = []; d; d = d.G) c.push(d);
		a = a.M;
		d = b.type || b;
		if (typeof b === "string") b = new x(b, a);
		else if (b instanceof x) b.target = b.target || a;
		else {
			var e = b;
			b = new x(d, a);
			Da(b, e);
		}
		e = true;
		let f, g;
		if (c) for (g = c.length - 1; g >= 0; g--) f = b.g = c[g], e = Va(f, d, true, b) && e;
		f = b.g = a;
		e = Va(f, d, true, b) && e;
		e = Va(f, d, false, b) && e;
		if (c) for (g = 0; g < c.length; g++) f = b.g = c[g], e = Va(f, d, false, b) && e;
	}
	C.prototype.N = function() {
		C.Z.N.call(this);
		if (this.i) {
			var a = this.i;
			for (const c in a.g) {
				const d = a.g[c];
				for (let e = 0; e < d.length; e++) xa(d[e]);
				delete a.g[c];
				a.h--;
			}
		}
		this.G = null;
	};
	C.prototype.J = function(a, b, c, d) {
		return this.i.add(String(a), b, false, c, d);
	};
	C.prototype.K = function(a, b, c, d) {
		return this.i.add(String(a), b, true, c, d);
	};
	function Va(a, b, c, d) {
		b = a.i.g[String(b)];
		if (!b) return true;
		b = b.concat();
		let e = true;
		for (let f = 0; f < b.length; ++f) {
			const g = b[f];
			if (g && !g.da && g.capture == c) {
				const k = g.listener, q = g.ha || g.src;
				g.fa && Ga(a.i, g);
				e = k.call(q, d) !== false && e;
			}
		}
		return e && !d.defaultPrevented;
	}
	function Wa(a, b) {
		if (typeof a !== "function") if (a && typeof a.handleEvent == "function") a = p(a.handleEvent, a);
		else throw Error("Invalid listener argument");
		return Number(b) > 2147483647 ? -1 : l.setTimeout(a, b || 0);
	}
	function Xa(a) {
		a.g = Wa(() => {
			a.g = null;
			a.i && (a.i = false, Xa(a));
		}, a.l);
		const b = a.h;
		a.h = null;
		a.m.apply(null, b);
	}
	class Ya extends w {
		constructor(a, b) {
			super();
			this.m = a;
			this.l = b;
			this.h = null;
			this.i = false;
			this.g = null;
		}
		j(a) {
			this.h = arguments;
			this.g ? this.i = true : Xa(this);
		}
		N() {
			super.N();
			this.g && (l.clearTimeout(this.g), this.g = null, this.i = false, this.h = null);
		}
	}
	function E(a) {
		w.call(this);
		this.h = a;
		this.g = {};
	}
	t(E, w);
	var Za = [];
	function $a(a) {
		ya(a.g, function(b, c) {
			this.g.hasOwnProperty(c) && Ta(b);
		}, a);
		a.g = {};
	}
	E.prototype.N = function() {
		E.Z.N.call(this);
		$a(this);
	};
	E.prototype.handleEvent = function() {
		throw Error("EventHandler.handleEvent not implemented");
	};
	var ab = l.JSON.stringify;
	var cb = l.JSON.parse;
	var db = class {
		stringify(a) {
			return l.JSON.stringify(a, void 0);
		}
		parse(a) {
			return l.JSON.parse(a, void 0);
		}
	};
	function eb() {}
	function fb() {}
	var H = {
		OPEN: "a",
		hb: "b",
		ERROR: "c",
		tb: "d"
	};
	function gb() {
		x.call(this, "d");
	}
	t(gb, x);
	function hb() {
		x.call(this, "c");
	}
	t(hb, x);
	var I = {}, ib = null;
	function jb() {
		return ib = ib || new C();
	}
	I.Ia = "serverreachability";
	function kb(a) {
		x.call(this, I.Ia, a);
	}
	t(kb, x);
	function lb(a) {
		const b = jb();
		D(b, new kb(b));
	}
	I.STAT_EVENT = "statevent";
	function mb(a, b) {
		x.call(this, I.STAT_EVENT, a);
		this.stat = b;
	}
	t(mb, x);
	function J(a) {
		const b = jb();
		D(b, new mb(b, a));
	}
	I.Ja = "timingevent";
	function nb(a, b) {
		x.call(this, I.Ja, a);
		this.size = b;
	}
	t(nb, x);
	function ob(a, b) {
		if (typeof a !== "function") throw Error("Fn must not be null and must be a function");
		return l.setTimeout(function() {
			a();
		}, b);
	}
	function pb() {
		this.g = true;
	}
	pb.prototype.ua = function() {
		this.g = false;
	};
	function qb(a, b, c, d, e, f) {
		a.info(function() {
			if (a.g) if (f) {
				var g = "";
				var k = f.split("&");
				for (let m = 0; m < k.length; m++) {
					var q = k[m].split("=");
					if (q.length > 1) {
						const r = q[0];
						q = q[1];
						const A = r.split("_");
						g = A.length >= 2 && A[1] == "type" ? g + (r + "=" + q + "&") : g + (r + "=redacted&");
					}
				}
			} else g = null;
			else g = f;
			return "XMLHTTP REQ (" + d + ") [attempt " + e + "]: " + b + "\n" + c + "\n" + g;
		});
	}
	function rb(a, b, c, d, e, f, g) {
		a.info(function() {
			return "XMLHTTP RESP (" + d + ") [ attempt " + e + "]: " + b + "\n" + c + "\n" + f + " " + g;
		});
	}
	function K(a, b, c, d) {
		a.info(function() {
			return "XMLHTTP TEXT (" + b + "): " + sb(a, c) + (d ? " " + d : "");
		});
	}
	function tb(a, b) {
		a.info(function() {
			return "TIMEOUT: " + b;
		});
	}
	pb.prototype.info = function() {};
	function sb(a, b) {
		if (!a.g) return b;
		if (!b) return null;
		try {
			const f = JSON.parse(b);
			if (f) {
				for (a = 0; a < f.length; a++) if (Array.isArray(f[a])) {
					var c = f[a];
					if (!(c.length < 2)) {
						var d = c[1];
						if (Array.isArray(d) && !(d.length < 1)) {
							var e = d[0];
							if (e != "noop" && e != "stop" && e != "close") for (let g = 1; g < d.length; g++) d[g] = "";
						}
					}
				}
			}
			return ab(f);
		} catch (f) {
			return b;
		}
	}
	var ub = {
		NO_ERROR: 0,
		cb: 1,
		qb: 2,
		pb: 3,
		kb: 4,
		ob: 5,
		rb: 6,
		Ga: 7,
		TIMEOUT: 8,
		ub: 9
	};
	var vb = {
		ib: "complete",
		Fb: "success",
		ERROR: "error",
		Ga: "abort",
		xb: "ready",
		yb: "readystatechange",
		TIMEOUT: "timeout",
		sb: "incrementaldata",
		wb: "progress",
		lb: "downloadprogress",
		Nb: "uploadprogress"
	};
	var wb;
	function xb() {}
	t(xb, eb);
	xb.prototype.g = function() {
		return new XMLHttpRequest();
	};
	wb = new xb();
	function L(a) {
		return encodeURIComponent(String(a));
	}
	function yb(a) {
		var b = 1;
		a = a.split(":");
		const c = [];
		for (; b > 0 && a.length;) c.push(a.shift()), b--;
		a.length && c.push(a.join(":"));
		return c;
	}
	function N(a, b, c, d) {
		this.j = a;
		this.i = b;
		this.l = c;
		this.S = d || 1;
		this.V = new E(this);
		this.H = 45e3;
		this.J = null;
		this.o = false;
		this.u = this.B = this.A = this.M = this.F = this.T = this.D = null;
		this.G = [];
		this.g = null;
		this.C = 0;
		this.m = this.v = null;
		this.X = -1;
		this.K = false;
		this.P = 0;
		this.O = null;
		this.W = this.L = this.U = this.R = false;
		this.h = new zb();
	}
	function zb() {
		this.i = null;
		this.g = "";
		this.h = false;
	}
	var Ab = {}, Bb = {};
	function Cb(a, b, c) {
		a.M = 1;
		a.A = Db(O(b));
		a.u = c;
		a.R = true;
		Eb(a, null);
	}
	function Eb(a, b) {
		a.F = Date.now();
		Fb(a);
		a.B = O(a.A);
		var c = a.B, d = a.S;
		Array.isArray(d) || (d = [String(d)]);
		Gb(c.i, "t", d);
		a.C = 0;
		c = a.j.L;
		a.h = new zb();
		a.g = Hb(a.j, c ? b : null, !a.u);
		a.P > 0 && (a.O = new Ya(p(a.Y, a, a.g), a.P));
		b = a.V;
		c = a.g;
		d = a.ba;
		var e = "readystatechange";
		Array.isArray(e) || (e && (Za[0] = e.toString()), e = Za);
		for (let f = 0; f < e.length; f++) {
			const g = Ka(c, e[f], d || b.handleEvent, false, b.h || b);
			if (!g) break;
			b.g[g.key] = g;
		}
		b = a.J ? Ba(a.J) : {};
		a.u ? (a.v || (a.v = "POST"), b["Content-Type"] = "application/x-www-form-urlencoded", a.g.ea(a.B, a.v, a.u, b)) : (a.v = "GET", a.g.ea(a.B, a.v, null, b));
		lb();
		qb(a.i, a.v, a.B, a.l, a.S, a.u);
	}
	N.prototype.ba = function(a) {
		a = a.target;
		const b = this.O;
		b && P(a) == 3 ? b.j() : this.Y(a);
	};
	N.prototype.Y = function(a) {
		try {
			if (a == this.g) a: {
				const k = P(this.g), q = this.g.ya(), m = this.g.ca();
				if (!(k < 3) && (k != 3 || this.g && (this.h.h || this.g.la() || Ib(this.g)))) {
					this.K || k != 4 || q == 7 || (q == 8 || m <= 0 ? lb(3) : lb(2));
					Jb(this);
					var b = this.g.ca();
					this.X = b;
					var c = Kb(this);
					this.o = b == 200;
					rb(this.i, this.v, this.B, this.l, this.S, k, b);
					if (this.o) {
						if (this.U && !this.L) {
							b: {
								if (this.g) {
									var d, e = this.g;
									if ((d = e.g ? e.g.getResponseHeader("X-HTTP-Initial-Response") : null) && !y(d)) {
										var f = d;
										break b;
									}
								}
								f = null;
							}
							if (a = f) K(this.i, this.l, a, "Initial handshake response via X-HTTP-Initial-Response"), this.L = !0, Lb(this, a);
							else {
								this.o = !1;
								this.m = 3;
								J(12);
								Q(this);
								Mb(this);
								break a;
							}
						}
						if (this.R) {
							a = !0;
							let r;
							for (; !this.K && this.C < c.length;) if (r = Nb(this, c), r == Bb) {
								k == 4 && (this.m = 4, J(14), a = !1);
								K(this.i, this.l, null, "[Incomplete Response]");
								break;
							} else if (r == Ab) {
								this.m = 4;
								J(15);
								K(this.i, this.l, c, "[Invalid Chunk]");
								a = !1;
								break;
							} else K(this.i, this.l, r, null), Lb(this, r);
							Ob(this) && this.C != 0 && (this.h.g = this.h.g.slice(this.C), this.C = 0);
							k != 4 || c.length != 0 || this.h.h || (this.m = 1, J(16), a = !1);
							this.o = this.o && a;
							if (!a) K(this.i, this.l, c, "[Invalid Chunked Response]"), Q(this), Mb(this);
							else if (c.length > 0 && !this.W) {
								this.W = !0;
								var g = this.j;
								g.g == this && g.aa && !g.P && (g.j.info("Great, no buffering proxy detected. Bytes received: " + c.length), Pb(g), g.P = !0, J(11));
							}
						} else K(this.i, this.l, c, null), Lb(this, c);
						k == 4 && Q(this);
						this.o && !this.K && (k == 4 ? Qb(this.j, this) : (this.o = !1, Fb(this)));
					} else Rb(this.g), b == 400 && c.indexOf("Unknown SID") > 0 ? (this.m = 3, J(12)) : (this.m = 0, J(13)), Q(this), Mb(this);
				}
			}
		} catch (k) {}
	};
	function Kb(a) {
		if (!Ob(a)) return a.g.la();
		const b = Ib(a.g);
		if (b === "") return "";
		let c = "";
		const d = b.length, e = P(a.g) == 4;
		if (!a.h.i) {
			if (typeof TextDecoder === "undefined") return Q(a), Mb(a), "";
			a.h.i = new l.TextDecoder();
		}
		for (let f = 0; f < d; f++) a.h.h = true, c += a.h.i.decode(b[f], { stream: !(e && f == d - 1) });
		b.length = 0;
		a.h.g += c;
		a.C = 0;
		return a.h.g;
	}
	function Ob(a) {
		return a.g ? a.v == "GET" && a.M != 2 && a.j.Aa : false;
	}
	function Nb(a, b) {
		var c = a.C, d = b.indexOf("\n", c);
		if (d == -1) return Bb;
		c = Number(b.substring(c, d));
		if (isNaN(c)) return Ab;
		d += 1;
		if (d + c > b.length) return Bb;
		b = b.slice(d, d + c);
		a.C = d + c;
		return b;
	}
	N.prototype.cancel = function() {
		this.K = true;
		Q(this);
	};
	function Fb(a) {
		a.T = Date.now() + a.H;
		Sb(a, a.H);
	}
	function Sb(a, b) {
		if (a.D != null) throw Error("WatchDog timer not null");
		a.D = ob(p(a.aa, a), b);
	}
	function Jb(a) {
		a.D && (l.clearTimeout(a.D), a.D = null);
	}
	N.prototype.aa = function() {
		this.D = null;
		const a = Date.now();
		a - this.T >= 0 ? (tb(this.i, this.B), this.M != 2 && (lb(), J(17)), Q(this), this.m = 2, Mb(this)) : Sb(this, this.T - a);
	};
	function Mb(a) {
		a.j.I == 0 || a.K || Qb(a.j, a);
	}
	function Q(a) {
		Jb(a);
		var b = a.O;
		b && typeof b.dispose == "function" && b.dispose();
		a.O = null;
		$a(a.V);
		a.g && (b = a.g, a.g = null, b.abort(), b.dispose());
	}
	function Lb(a, b) {
		try {
			var c = a.j;
			if (c.I != 0 && (c.g == a || Tb(c.h, a))) {
				if (!a.L && Tb(c.h, a) && c.I == 3) {
					try {
						var d = c.Ba.g.parse(b);
					} catch (m) {
						d = null;
					}
					if (Array.isArray(d) && d.length == 3) {
						var e = d;
						if (e[0] == 0) {
							a: if (!c.v) {
								if (c.g) if (c.g.F + 3e3 < a.F) Ub(c), Vb(c);
								else break a;
								Wb(c);
								J(18);
							}
						} else c.xa = e[1], 0 < c.xa - c.K && e[2] < 37500 && c.F && c.A == 0 && !c.C && (c.C = ob(p(c.Va, c), 6e3));
						Xb(c.h) <= 1 && c.ta && (c.ta = void 0);
					} else R(c, 11);
				} else if ((a.L || c.g == a) && Ub(c), !y(b)) for (e = c.Ba.g.parse(b), b = 0; b < e.length; b++) {
					let m = e[b];
					const r = m[0];
					if (!(r <= c.K)) if (c.K = r, m = m[1], c.I == 2) if (m[0] == "c") {
						c.M = m[1];
						c.ba = m[2];
						const A = m[3];
						A != null && (c.ka = A, c.j.info("VER=" + c.ka));
						const M = m[4];
						M != null && (c.za = M, c.j.info("SVER=" + c.za));
						const F = m[5];
						F != null && typeof F === "number" && F > 0 && (d = 1.5 * F, c.O = d, c.j.info("backChannelRequestTimeoutMs_=" + d));
						d = c;
						const G = a.g;
						if (G) {
							const za = G.g ? G.g.getResponseHeader("X-Client-Wire-Protocol") : null;
							if (za) {
								var f = d.h;
								f.g || za.indexOf("spdy") == -1 && za.indexOf("quic") == -1 && za.indexOf("h2") == -1 || (f.j = f.l, f.g = /* @__PURE__ */ new Set(), f.h && (Yb(f, f.h), f.h = null));
							}
							if (d.G) {
								const bb = G.g ? G.g.getResponseHeader("X-HTTP-Session-Id") : null;
								bb && (d.wa = bb, S(d.J, d.G, bb));
							}
						}
						c.I = 3;
						c.l && c.l.ra();
						c.aa && (c.T = Date.now() - a.F, c.j.info("Handshake RTT: " + c.T + "ms"));
						d = c;
						var g = a;
						d.na = Zb(d, d.L ? d.ba : null, d.W);
						if (g.L) {
							$b(d.h, g);
							var k = g, q = d.O;
							q && (k.H = q);
							k.D && (Jb(k), Fb(k));
							d.g = g;
						} else ac(d);
						c.i.length > 0 && bc(c);
					} else m[0] != "stop" && m[0] != "close" || R(c, 7);
					else c.I == 3 && (m[0] == "stop" || m[0] == "close" ? m[0] == "stop" ? R(c, 7) : cc(c) : m[0] != "noop" && c.l && c.l.qa(m), c.A = 0);
				}
			}
			lb(4);
		} catch (m) {}
	}
	var dc = class {
		constructor(a, b) {
			this.g = a;
			this.map = b;
		}
	};
	function ec(a) {
		this.l = a || 10;
		l.PerformanceNavigationTiming ? (a = l.performance.getEntriesByType("navigation"), a = a.length > 0 && (a[0].nextHopProtocol == "hq" || a[0].nextHopProtocol == "h2")) : a = !!(l.chrome && l.chrome.loadTimes && l.chrome.loadTimes() && l.chrome.loadTimes().wasFetchedViaSpdy);
		this.j = a ? this.l : 1;
		this.g = null;
		this.j > 1 && (this.g = /* @__PURE__ */ new Set());
		this.h = null;
		this.i = [];
	}
	function fc(a) {
		return a.h ? true : a.g ? a.g.size >= a.j : false;
	}
	function Xb(a) {
		return a.h ? 1 : a.g ? a.g.size : 0;
	}
	function Tb(a, b) {
		return a.h ? a.h == b : a.g ? a.g.has(b) : false;
	}
	function Yb(a, b) {
		a.g ? a.g.add(b) : a.h = b;
	}
	function $b(a, b) {
		a.h && a.h == b ? a.h = null : a.g && a.g.has(b) && a.g.delete(b);
	}
	ec.prototype.cancel = function() {
		this.i = hc(this);
		if (this.h) this.h.cancel(), this.h = null;
		else if (this.g && this.g.size !== 0) {
			for (const a of this.g.values()) a.cancel();
			this.g.clear();
		}
	};
	function hc(a) {
		if (a.h != null) return a.i.concat(a.h.G);
		if (a.g != null && a.g.size !== 0) {
			let b = a.i;
			for (const c of a.g.values()) b = b.concat(c.G);
			return b;
		}
		return ja(a.i);
	}
	var ic = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");
	function jc(a, b) {
		if (a) {
			a = a.split("&");
			for (let c = 0; c < a.length; c++) {
				const d = a[c].indexOf("=");
				let e, f = null;
				d >= 0 ? (e = a[c].substring(0, d), f = a[c].substring(d + 1)) : e = a[c];
				b(e, f ? decodeURIComponent(f.replace(/\+/g, " ")) : "");
			}
		}
	}
	function T(a) {
		this.g = this.o = this.j = "";
		this.u = null;
		this.m = this.h = "";
		this.l = false;
		let b;
		a instanceof T ? (this.l = a.l, kc(this, a.j), this.o = a.o, this.g = a.g, lc(this, a.u), this.h = a.h, mc(this, nc(a.i)), this.m = a.m) : a && (b = String(a).match(ic)) ? (this.l = false, kc(this, b[1] || "", true), this.o = oc(b[2] || ""), this.g = oc(b[3] || "", true), lc(this, b[4]), this.h = oc(b[5] || "", true), mc(this, b[6] || "", true), this.m = oc(b[7] || "")) : (this.l = false, this.i = new pc(null, this.l));
	}
	T.prototype.toString = function() {
		const a = [];
		var b = this.j;
		b && a.push(qc(b, rc, true), ":");
		var c = this.g;
		if (c || b == "file") a.push("//"), (b = this.o) && a.push(qc(b, rc, true), "@"), a.push(L(c).replace(/%25([0-9a-fA-F]{2})/g, "%$1")), c = this.u, c != null && a.push(":", String(c));
		if (c = this.h) this.g && c.charAt(0) != "/" && a.push("/"), a.push(qc(c, c.charAt(0) == "/" ? sc : tc, true));
		(c = this.i.toString()) && a.push("?", c);
		(c = this.m) && a.push("#", qc(c, uc));
		return a.join("");
	};
	T.prototype.resolve = function(a) {
		const b = O(this);
		let c = !!a.j;
		c ? kc(b, a.j) : c = !!a.o;
		c ? b.o = a.o : c = !!a.g;
		c ? b.g = a.g : c = a.u != null;
		var d = a.h;
		if (c) lc(b, a.u);
		else if (c = !!a.h) {
			if (d.charAt(0) != "/") if (this.g && !this.h) d = "/" + d;
			else {
				var e = b.h.lastIndexOf("/");
				e != -1 && (d = b.h.slice(0, e + 1) + d);
			}
			e = d;
			if (e == ".." || e == ".") d = "";
			else if (e.indexOf("./") != -1 || e.indexOf("/.") != -1) {
				d = e.lastIndexOf("/", 0) == 0;
				e = e.split("/");
				const f = [];
				for (let g = 0; g < e.length;) {
					const k = e[g++];
					k == "." ? d && g == e.length && f.push("") : k == ".." ? ((f.length > 1 || f.length == 1 && f[0] != "") && f.pop(), d && g == e.length && f.push("")) : (f.push(k), d = true);
				}
				d = f.join("/");
			} else d = e;
		}
		c ? b.h = d : c = a.i.toString() !== "";
		c ? mc(b, nc(a.i)) : c = !!a.m;
		c && (b.m = a.m);
		return b;
	};
	function O(a) {
		return new T(a);
	}
	function kc(a, b, c) {
		a.j = c ? oc(b, true) : b;
		a.j && (a.j = a.j.replace(/:$/, ""));
	}
	function lc(a, b) {
		if (b) {
			b = Number(b);
			if (isNaN(b) || b < 0) throw Error("Bad port number " + b);
			a.u = b;
		} else a.u = null;
	}
	function mc(a, b, c) {
		b instanceof pc ? (a.i = b, vc(a.i, a.l)) : (c || (b = qc(b, wc)), a.i = new pc(b, a.l));
	}
	function S(a, b, c) {
		a.i.set(b, c);
	}
	function Db(a) {
		S(a, "zx", Math.floor(Math.random() * 2147483648).toString(36) + Math.abs(Math.floor(Math.random() * 2147483648) ^ Date.now()).toString(36));
		return a;
	}
	function oc(a, b) {
		return a ? b ? decodeURI(a.replace(/%25/g, "%2525")) : decodeURIComponent(a) : "";
	}
	function qc(a, b, c) {
		return typeof a === "string" ? (a = encodeURI(a).replace(b, xc), c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")), a) : null;
	}
	function xc(a) {
		a = a.charCodeAt(0);
		return "%" + (a >> 4 & 15).toString(16) + (a & 15).toString(16);
	}
	var rc = /[#\/\?@]/g, tc = /[#\?:]/g, sc = /[#\?]/g, wc = /[#\?@]/g, uc = /#/g;
	function pc(a, b) {
		this.h = this.g = null;
		this.i = a || null;
		this.j = !!b;
	}
	function U(a) {
		a.g || (a.g = /* @__PURE__ */ new Map(), a.h = 0, a.i && jc(a.i, function(b, c) {
			a.add(decodeURIComponent(b.replace(/\+/g, " ")), c);
		}));
	}
	h = pc.prototype;
	h.add = function(a, b) {
		U(this);
		this.i = null;
		a = V(this, a);
		let c = this.g.get(a);
		c || this.g.set(a, c = []);
		c.push(b);
		this.h += 1;
		return this;
	};
	function yc(a, b) {
		U(a);
		b = V(a, b);
		a.g.has(b) && (a.i = null, a.h -= a.g.get(b).length, a.g.delete(b));
	}
	function zc(a, b) {
		U(a);
		b = V(a, b);
		return a.g.has(b);
	}
	h.forEach = function(a, b) {
		U(this);
		this.g.forEach(function(c, d) {
			c.forEach(function(e) {
				a.call(b, e, d, this);
			}, this);
		}, this);
	};
	function Ac(a, b) {
		U(a);
		let c = [];
		if (typeof b === "string") zc(a, b) && (c = c.concat(a.g.get(V(a, b))));
		else for (a = Array.from(a.g.values()), b = 0; b < a.length; b++) c = c.concat(a[b]);
		return c;
	}
	h.set = function(a, b) {
		U(this);
		this.i = null;
		a = V(this, a);
		zc(this, a) && (this.h -= this.g.get(a).length);
		this.g.set(a, [b]);
		this.h += 1;
		return this;
	};
	h.get = function(a, b) {
		if (!a) return b;
		a = Ac(this, a);
		return a.length > 0 ? String(a[0]) : b;
	};
	function Gb(a, b, c) {
		yc(a, b);
		c.length > 0 && (a.i = null, a.g.set(V(a, b), ja(c)), a.h += c.length);
	}
	h.toString = function() {
		if (this.i) return this.i;
		if (!this.g) return "";
		const a = [], b = Array.from(this.g.keys());
		for (let d = 0; d < b.length; d++) {
			var c = b[d];
			const e = L(c);
			c = Ac(this, c);
			for (let f = 0; f < c.length; f++) {
				let g = e;
				c[f] !== "" && (g += "=" + L(c[f]));
				a.push(g);
			}
		}
		return this.i = a.join("&");
	};
	function nc(a) {
		const b = new pc();
		b.i = a.i;
		a.g && (b.g = new Map(a.g), b.h = a.h);
		return b;
	}
	function V(a, b) {
		b = String(b);
		a.j && (b = b.toLowerCase());
		return b;
	}
	function vc(a, b) {
		b && !a.j && (U(a), a.i = null, a.g.forEach(function(c, d) {
			const e = d.toLowerCase();
			d != e && (yc(this, d), Gb(this, e, c));
		}, a));
		a.j = b;
	}
	function Bc(a, b) {
		const c = new pb();
		if (l.Image) {
			const d = new Image();
			d.onload = ha(W, c, "TestLoadImage: loaded", true, b, d);
			d.onerror = ha(W, c, "TestLoadImage: error", false, b, d);
			d.onabort = ha(W, c, "TestLoadImage: abort", false, b, d);
			d.ontimeout = ha(W, c, "TestLoadImage: timeout", false, b, d);
			l.setTimeout(function() {
				if (d.ontimeout) d.ontimeout();
			}, 1e4);
			d.src = a;
		} else b(false);
	}
	function Cc(a, b) {
		const c = new pb(), d = new AbortController(), e = setTimeout(() => {
			d.abort();
			W(c, "TestPingServer: timeout", false, b);
		}, 1e4);
		fetch(a, { signal: d.signal }).then((f) => {
			clearTimeout(e);
			f.ok ? W(c, "TestPingServer: ok", true, b) : W(c, "TestPingServer: server error", false, b);
		}).catch(() => {
			clearTimeout(e);
			W(c, "TestPingServer: error", false, b);
		});
	}
	function W(a, b, c, d, e) {
		try {
			e && (e.onload = null, e.onerror = null, e.onabort = null, e.ontimeout = null), d(c);
		} catch (f) {}
	}
	function Dc() {
		this.g = new db();
	}
	function Ec(a) {
		this.i = a.Sb || null;
		this.h = a.ab || false;
	}
	t(Ec, eb);
	Ec.prototype.g = function() {
		return new Fc(this.i, this.h);
	};
	function Fc(a, b) {
		C.call(this);
		this.H = a;
		this.o = b;
		this.m = void 0;
		this.status = this.readyState = 0;
		this.responseType = this.responseText = this.response = this.statusText = "";
		this.onreadystatechange = null;
		this.A = new Headers();
		this.h = null;
		this.F = "GET";
		this.D = "";
		this.g = false;
		this.B = this.j = this.l = null;
		this.v = new AbortController();
	}
	t(Fc, C);
	h = Fc.prototype;
	h.open = function(a, b) {
		if (this.readyState != 0) throw this.abort(), Error("Error reopening a connection");
		this.F = a;
		this.D = b;
		this.readyState = 1;
		Gc(this);
	};
	h.send = function(a) {
		if (this.readyState != 1) throw this.abort(), Error("need to call open() first. ");
		if (this.v.signal.aborted) throw this.abort(), Error("Request was aborted.");
		this.g = true;
		const b = {
			headers: this.A,
			method: this.F,
			credentials: this.m,
			cache: void 0,
			signal: this.v.signal
		};
		a && (b.body = a);
		(this.H || l).fetch(new Request(this.D, b)).then(this.Pa.bind(this), this.ga.bind(this));
	};
	h.abort = function() {
		this.response = this.responseText = "";
		this.A = new Headers();
		this.status = 0;
		this.v.abort();
		this.j && this.j.cancel("Request was aborted.").catch(() => {});
		this.readyState >= 1 && this.g && this.readyState != 4 && (this.g = false, Hc(this));
		this.readyState = 0;
	};
	h.Pa = function(a) {
		if (this.g && (this.l = a, this.h || (this.status = this.l.status, this.statusText = this.l.statusText, this.h = a.headers, this.readyState = 2, Gc(this)), this.g && (this.readyState = 3, Gc(this), this.g))) if (this.responseType === "arraybuffer") a.arrayBuffer().then(this.Na.bind(this), this.ga.bind(this));
		else if (typeof l.ReadableStream !== "undefined" && "body" in a) {
			this.j = a.body.getReader();
			if (this.o) {
				if (this.responseType) throw Error("responseType must be empty for \"streamBinaryChunks\" mode responses.");
				this.response = [];
			} else this.response = this.responseText = "", this.B = new TextDecoder();
			Ic(this);
		} else a.text().then(this.Oa.bind(this), this.ga.bind(this));
	};
	function Ic(a) {
		a.j.read().then(a.Ma.bind(a)).catch(a.ga.bind(a));
	}
	h.Ma = function(a) {
		if (this.g) {
			if (this.o && a.value) this.response.push(a.value);
			else if (!this.o) {
				var b = a.value ? a.value : /* @__PURE__ */ new Uint8Array(0);
				if (b = this.B.decode(b, { stream: !a.done })) this.response = this.responseText += b;
			}
			a.done ? Hc(this) : Gc(this);
			this.readyState == 3 && Ic(this);
		}
	};
	h.Oa = function(a) {
		this.g && (this.response = this.responseText = a, Hc(this));
	};
	h.Na = function(a) {
		this.g && (this.response = a, Hc(this));
	};
	h.ga = function() {
		this.g && Hc(this);
	};
	function Hc(a) {
		a.readyState = 4;
		a.l = null;
		a.j = null;
		a.B = null;
		Gc(a);
	}
	h.setRequestHeader = function(a, b) {
		this.A.append(a, b);
	};
	h.getResponseHeader = function(a) {
		return this.h ? this.h.get(a.toLowerCase()) || "" : "";
	};
	h.getAllResponseHeaders = function() {
		if (!this.h) return "";
		const a = [], b = this.h.entries();
		for (var c = b.next(); !c.done;) c = c.value, a.push(c[0] + ": " + c[1]), c = b.next();
		return a.join("\r\n");
	};
	function Gc(a) {
		a.onreadystatechange && a.onreadystatechange.call(a);
	}
	Object.defineProperty(Fc.prototype, "withCredentials", {
		get: function() {
			return this.m === "include";
		},
		set: function(a) {
			this.m = a ? "include" : "same-origin";
		}
	});
	function Jc(a) {
		let b = "";
		ya(a, function(c, d) {
			b += d;
			b += ":";
			b += c;
			b += "\r\n";
		});
		return b;
	}
	function Kc(a, b, c) {
		a: {
			for (d in c) {
				var d = false;
				break a;
			}
			d = true;
		}
		d || (c = Jc(c), typeof a === "string" || S(a, b, c));
	}
	function X(a) {
		C.call(this);
		this.headers = /* @__PURE__ */ new Map();
		this.L = a || null;
		this.h = false;
		this.g = null;
		this.D = "";
		this.o = 0;
		this.l = "";
		this.j = this.B = this.v = this.A = false;
		this.m = null;
		this.F = "";
		this.H = false;
	}
	t(X, C);
	var Lc = /^https?$/i, Mc = ["POST", "PUT"];
	h = X.prototype;
	h.Fa = function(a) {
		this.H = a;
	};
	h.ea = function(a, b, c, d) {
		if (this.g) throw Error("[goog.net.XhrIo] Object is active with another request=" + this.D + "; newUri=" + a);
		b = b ? b.toUpperCase() : "GET";
		this.D = a;
		this.l = "";
		this.o = 0;
		this.A = false;
		this.h = true;
		this.g = this.L ? this.L.g() : wb.g();
		this.g.onreadystatechange = ia(p(this.Ca, this));
		try {
			this.B = !0, this.g.open(b, String(a), !0), this.B = !1;
		} catch (f) {
			Nc(this, f);
			return;
		}
		a = c || "";
		c = new Map(this.headers);
		if (d) if (Object.getPrototypeOf(d) === Object.prototype) for (var e in d) c.set(e, d[e]);
		else if (typeof d.keys === "function" && typeof d.get === "function") for (const f of d.keys()) c.set(f, d.get(f));
		else throw Error("Unknown input type for opt_headers: " + String(d));
		d = Array.from(c.keys()).find((f) => "content-type" == f.toLowerCase());
		e = l.FormData && a instanceof l.FormData;
		!(Array.prototype.indexOf.call(Mc, b, void 0) >= 0) || d || e || c.set("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
		for (const [f, g] of c) this.g.setRequestHeader(f, g);
		this.F && (this.g.responseType = this.F);
		"withCredentials" in this.g && this.g.withCredentials !== this.H && (this.g.withCredentials = this.H);
		try {
			this.m && (clearTimeout(this.m), this.m = null), this.v = !0, this.g.send(a), this.v = !1;
		} catch (f) {
			Nc(this, f);
		}
	};
	function Nc(a, b) {
		a.h = false;
		a.g && (a.j = true, a.g.abort(), a.j = false);
		a.l = b;
		a.o = 5;
		Oc(a);
		Pc(a);
	}
	function Oc(a) {
		a.A || (a.A = true, D(a, "complete"), D(a, "error"));
	}
	h.abort = function(a) {
		this.g && this.h && (this.h = false, this.j = true, this.g.abort(), this.j = false, this.o = a || 7, D(this, "complete"), D(this, "abort"), Pc(this));
	};
	h.N = function() {
		this.g && (this.h && (this.h = false, this.j = true, this.g.abort(), this.j = false), Pc(this, true));
		X.Z.N.call(this);
	};
	h.Ca = function() {
		this.u || (this.B || this.v || this.j ? Qc(this) : this.Xa());
	};
	h.Xa = function() {
		Qc(this);
	};
	function Qc(a) {
		if (a.h && typeof ea != "undefined") {
			if (a.v && P(a) == 4) setTimeout(a.Ca.bind(a), 0);
			else if (D(a, "readystatechange"), P(a) == 4) {
				a.h = false;
				try {
					const f = a.ca();
					a: switch (f) {
						case 200:
						case 201:
						case 202:
						case 204:
						case 206:
						case 304:
						case 1223:
							var b = !0;
							break a;
						default: b = !1;
					}
					var c;
					if (!(c = b)) {
						var d;
						if (d = f === 0) {
							let g = String(a.D).match(ic)[1] || null;
							!g && l.self && l.self.location && (g = l.self.location.protocol.slice(0, -1));
							d = !Lc.test(g ? g.toLowerCase() : "");
						}
						c = d;
					}
					if (c) D(a, "complete"), D(a, "success");
					else {
						a.o = 6;
						try {
							var e = P(a) > 2 ? a.g.statusText : "";
						} catch (g) {
							e = "";
						}
						a.l = e + " [" + a.ca() + "]";
						Oc(a);
					}
				} finally {
					Pc(a);
				}
			}
		}
	}
	function Pc(a, b) {
		if (a.g) {
			a.m && (clearTimeout(a.m), a.m = null);
			const c = a.g;
			a.g = null;
			b || D(a, "ready");
			try {
				c.onreadystatechange = null;
			} catch (d) {}
		}
	}
	h.isActive = function() {
		return !!this.g;
	};
	function P(a) {
		return a.g ? a.g.readyState : 0;
	}
	h.ca = function() {
		try {
			return P(this) > 2 ? this.g.status : -1;
		} catch (a) {
			return -1;
		}
	};
	h.la = function() {
		try {
			return this.g ? this.g.responseText : "";
		} catch (a) {
			return "";
		}
	};
	h.La = function(a) {
		if (this.g) {
			var b = this.g.responseText;
			a && b.indexOf(a) == 0 && (b = b.substring(a.length));
			return cb(b);
		}
	};
	function Ib(a) {
		try {
			if (!a.g) return null;
			if ("response" in a.g) return a.g.response;
			switch (a.F) {
				case "":
				case "text": return a.g.responseText;
				case "arraybuffer": if ("mozResponseArrayBuffer" in a.g) return a.g.mozResponseArrayBuffer;
			}
			return null;
		} catch (b) {
			return null;
		}
	}
	function Rb(a) {
		const b = {};
		a = (a.g && P(a) >= 2 ? a.g.getAllResponseHeaders() || "" : "").split("\r\n");
		for (let d = 0; d < a.length; d++) {
			if (y(a[d])) continue;
			var c = yb(a[d]);
			const e = c[0];
			c = c[1];
			if (typeof c !== "string") continue;
			c = c.trim();
			const f = b[e] || [];
			b[e] = f;
			f.push(c);
		}
		Aa(b, function(d) {
			return d.join(", ");
		});
	}
	h.ya = function() {
		return this.o;
	};
	h.Ha = function() {
		return typeof this.l === "string" ? this.l : String(this.l);
	};
	function Rc(a, b, c) {
		return c && c.internalChannelParams ? c.internalChannelParams[a] || b : b;
	}
	function Sc(a) {
		this.za = 0;
		this.i = [];
		this.j = new pb();
		this.ba = this.na = this.J = this.W = this.g = this.wa = this.G = this.H = this.u = this.U = this.o = null;
		this.Ya = this.V = 0;
		this.Sa = Rc("failFast", false, a);
		this.F = this.C = this.v = this.m = this.l = null;
		this.X = true;
		this.xa = this.K = -1;
		this.Y = this.A = this.D = 0;
		this.Qa = Rc("baseRetryDelayMs", 5e3, a);
		this.Za = Rc("retryDelaySeedMs", 1e4, a);
		this.Ta = Rc("forwardChannelMaxRetries", 2, a);
		this.va = Rc("forwardChannelRequestTimeoutMs", 2e4, a);
		this.ma = a && a.xmlHttpFactory || void 0;
		this.Ua = a && a.Rb || void 0;
		this.Aa = a && a.useFetchStreams || false;
		this.O = void 0;
		this.L = a && a.supportsCrossDomainXhr || false;
		this.M = "";
		this.h = new ec(a && a.concurrentRequestLimit);
		this.Ba = new Dc();
		this.S = a && a.fastHandshake || false;
		this.R = a && a.encodeInitMessageHeaders || false;
		this.S && this.R && (this.R = false);
		this.Ra = a && a.Pb || false;
		a && a.ua && this.j.ua();
		a && a.forceLongPolling && (this.X = false);
		this.aa = !this.S && this.X && a && a.detectBufferingProxy || false;
		this.ia = void 0;
		a && a.longPollingTimeout && a.longPollingTimeout > 0 && (this.ia = a.longPollingTimeout);
		this.ta = void 0;
		this.T = 0;
		this.P = false;
		this.ja = this.B = null;
	}
	h = Sc.prototype;
	h.ka = 8;
	h.I = 1;
	h.connect = function(a, b, c, d) {
		J(0);
		this.W = a;
		this.H = b || {};
		c && d !== void 0 && (this.H.OSID = c, this.H.OAID = d);
		this.F = this.X;
		this.J = Zb(this, null, this.W);
		bc(this);
	};
	function cc(a) {
		Tc(a);
		if (a.I == 3) {
			var b = a.V++, c = O(a.J);
			S(c, "SID", a.M);
			S(c, "RID", b);
			S(c, "TYPE", "terminate");
			Uc(a, c);
			b = new N(a, a.j, b);
			b.M = 2;
			b.A = Db(O(c));
			c = false;
			if (l.navigator && l.navigator.sendBeacon) try {
				c = l.navigator.sendBeacon(b.A.toString(), "");
			} catch (d) {}
			!c && l.Image && (new Image().src = b.A, c = true);
			c || (b.g = Hb(b.j, null), b.g.ea(b.A));
			b.F = Date.now();
			Fb(b);
		}
		Vc(a);
	}
	function Vb(a) {
		a.g && (Pb(a), a.g.cancel(), a.g = null);
	}
	function Tc(a) {
		Vb(a);
		a.v && (l.clearTimeout(a.v), a.v = null);
		Ub(a);
		a.h.cancel();
		a.m && (typeof a.m === "number" && l.clearTimeout(a.m), a.m = null);
	}
	function bc(a) {
		if (!fc(a.h) && !a.m) {
			a.m = true;
			var b = a.Ea;
			u || ta();
			v || (u(), v = true);
			oa.add(b, a);
			a.D = 0;
		}
	}
	function Wc(a, b) {
		if (Xb(a.h) >= a.h.j - (a.m ? 1 : 0)) return false;
		if (a.m) return a.i = b.G.concat(a.i), true;
		if (a.I == 1 || a.I == 2 || a.D >= (a.Sa ? 0 : a.Ta)) return false;
		a.m = ob(p(a.Ea, a, b), Xc(a, a.D));
		a.D++;
		return true;
	}
	h.Ea = function(a) {
		if (this.m) if (this.m = null, this.I == 1) {
			if (!a) {
				this.V = Math.floor(Math.random() * 1e5);
				a = this.V++;
				const e = new N(this, this.j, a);
				let f = this.o;
				this.U && (f ? (f = Ba(f), Da(f, this.U)) : f = this.U);
				this.u !== null || this.R || (e.J = f, f = null);
				if (this.S) a: {
					var b = 0;
					for (var c = 0; c < this.i.length; c++) {
						b: {
							var d = this.i[c];
							if ("__data__" in d.map && (d = d.map.__data__, typeof d === "string")) {
								d = d.length;
								break b;
							}
							d = void 0;
						}
						if (d === void 0) break;
						b += d;
						if (b > 4096) {
							b = c;
							break a;
						}
						if (b === 4096 || c === this.i.length - 1) {
							b = c + 1;
							break a;
						}
					}
					b = 1e3;
				}
				else b = 1e3;
				b = Yc(this, e, b);
				c = O(this.J);
				S(c, "RID", a);
				S(c, "CVER", 22);
				this.G && S(c, "X-HTTP-Session-Id", this.G);
				Uc(this, c);
				f && (this.R ? b = "headers=" + L(Jc(f)) + "&" + b : this.u && Kc(c, this.u, f));
				Yb(this.h, e);
				this.Ra && S(c, "TYPE", "init");
				this.S ? (S(c, "$req", b), S(c, "SID", "null"), e.U = true, Cb(e, c, null)) : Cb(e, c, b);
				this.I = 2;
			}
		} else this.I == 3 && (a ? Zc(this, a) : this.i.length == 0 || fc(this.h) || Zc(this));
	};
	function Zc(a, b) {
		var c;
		b ? c = b.l : c = a.V++;
		const d = O(a.J);
		S(d, "SID", a.M);
		S(d, "RID", c);
		S(d, "AID", a.K);
		Uc(a, d);
		a.u && a.o && Kc(d, a.u, a.o);
		c = new N(a, a.j, c, a.D + 1);
		a.u === null && (c.J = a.o);
		b && (a.i = b.G.concat(a.i));
		b = Yc(a, c, 1e3);
		c.H = Math.round(a.va * .5) + Math.round(a.va * .5 * Math.random());
		Yb(a.h, c);
		Cb(c, d, b);
	}
	function Uc(a, b) {
		a.H && ya(a.H, function(c, d) {
			S(b, d, c);
		});
		a.l && ya({}, function(c, d) {
			S(b, d, c);
		});
	}
	function Yc(a, b, c) {
		c = Math.min(a.i.length, c);
		const d = a.l ? p(a.l.Ka, a.l, a) : null;
		a: {
			var e = a.i;
			let k = -1;
			for (;;) {
				const q = ["count=" + c];
				k == -1 ? c > 0 ? (k = e[0].g, q.push("ofs=" + k)) : k = 0 : q.push("ofs=" + k);
				let m = true;
				for (let r = 0; r < c; r++) {
					var f = e[r].g;
					const A = e[r].map;
					f -= k;
					if (f < 0) k = Math.max(0, e[r].g - 100), m = false;
					else try {
						f = "req" + f + "_" || "";
						try {
							var g = A instanceof Map ? A : Object.entries(A);
							for (const [M, F] of g) {
								let G = F;
								n(F) && (G = ab(F));
								q.push(f + M + "=" + encodeURIComponent(G));
							}
						} catch (M) {
							throw q.push(f + "type=_badmap"), M;
						}
					} catch (M) {
						d && d(A);
					}
				}
				if (m) {
					g = q.join("&");
					break a;
				}
			}
			g = void 0;
		}
		a = a.i.splice(0, c);
		b.G = a;
		return g;
	}
	function ac(a) {
		if (!a.g && !a.v) {
			a.Y = 1;
			var b = a.Da;
			u || ta();
			v || (u(), v = true);
			oa.add(b, a);
			a.A = 0;
		}
	}
	function Wb(a) {
		if (a.g || a.v || a.A >= 3) return false;
		a.Y++;
		a.v = ob(p(a.Da, a), Xc(a, a.A));
		a.A++;
		return true;
	}
	h.Da = function() {
		this.v = null;
		$c(this);
		if (this.aa && !(this.P || this.g == null || this.T <= 0)) {
			var a = 4 * this.T;
			this.j.info("BP detection timer enabled: " + a);
			this.B = ob(p(this.Wa, this), a);
		}
	};
	h.Wa = function() {
		this.B && (this.B = null, this.j.info("BP detection timeout reached."), this.j.info("Buffering proxy detected and switch to long-polling!"), this.F = false, this.P = true, J(10), Vb(this), $c(this));
	};
	function Pb(a) {
		a.B != null && (l.clearTimeout(a.B), a.B = null);
	}
	function $c(a) {
		a.g = new N(a, a.j, "rpc", a.Y);
		a.u === null && (a.g.J = a.o);
		a.g.P = 0;
		var b = O(a.na);
		S(b, "RID", "rpc");
		S(b, "SID", a.M);
		S(b, "AID", a.K);
		S(b, "CI", a.F ? "0" : "1");
		!a.F && a.ia && S(b, "TO", a.ia);
		S(b, "TYPE", "xmlhttp");
		Uc(a, b);
		a.u && a.o && Kc(b, a.u, a.o);
		a.O && (a.g.H = a.O);
		var c = a.g;
		a = a.ba;
		c.M = 1;
		c.A = Db(O(b));
		c.u = null;
		c.R = true;
		Eb(c, a);
	}
	h.Va = function() {
		this.C != null && (this.C = null, Vb(this), Wb(this), J(19));
	};
	function Ub(a) {
		a.C != null && (l.clearTimeout(a.C), a.C = null);
	}
	function Qb(a, b) {
		var c = null;
		if (a.g == b) {
			Ub(a);
			Pb(a);
			a.g = null;
			var d = 2;
		} else if (Tb(a.h, b)) c = b.G, $b(a.h, b), d = 1;
		else return;
		if (a.I != 0) {
			if (b.o) if (d == 1) {
				c = b.u ? b.u.length : 0;
				b = Date.now() - b.F;
				var e = a.D;
				d = jb();
				D(d, new nb(d, c));
				bc(a);
			} else ac(a);
			else if (e = b.m, e == 3 || e == 0 && b.X > 0 || !(d == 1 && Wc(a, b) || d == 2 && Wb(a))) switch (c && c.length > 0 && (b = a.h, b.i = b.i.concat(c)), e) {
				case 1:
					R(a, 5);
					break;
				case 4:
					R(a, 10);
					break;
				case 3:
					R(a, 6);
					break;
				default: R(a, 2);
			}
		}
	}
	function Xc(a, b) {
		let c = a.Qa + Math.floor(Math.random() * a.Za);
		a.isActive() || (c *= 2);
		return c * b;
	}
	function R(a, b) {
		a.j.info("Error code " + b);
		if (b == 2) {
			var c = p(a.bb, a), d = a.Ua;
			const e = !d;
			d = new T(d || "//www.google.com/images/cleardot.gif");
			l.location && l.location.protocol == "http" || kc(d, "https");
			Db(d);
			e ? Bc(d.toString(), c) : Cc(d.toString(), c);
		} else J(2);
		a.I = 0;
		a.l && a.l.pa(b);
		Vc(a);
		Tc(a);
	}
	h.bb = function(a) {
		a ? (this.j.info("Successfully pinged google.com"), J(2)) : (this.j.info("Failed to ping google.com"), J(1));
	};
	function Vc(a) {
		a.I = 0;
		a.ja = [];
		if (a.l) {
			const b = hc(a.h);
			if (b.length != 0 || a.i.length != 0) ka(a.ja, b), ka(a.ja, a.i), a.h.i.length = 0, ja(a.i), a.i.length = 0;
			a.l.oa();
		}
	}
	function Zb(a, b, c) {
		var d = c instanceof T ? O(c) : new T(c);
		if (d.g != "") b && (d.g = b + "." + d.g), lc(d, d.u);
		else {
			var e = l.location;
			d = e.protocol;
			b = b ? b + "." + e.hostname : e.hostname;
			e = +e.port;
			const f = new T(null);
			d && kc(f, d);
			b && (f.g = b);
			e && lc(f, e);
			c && (f.h = c);
			d = f;
		}
		c = a.G;
		b = a.wa;
		c && b && S(d, c, b);
		S(d, "VER", a.ka);
		Uc(a, d);
		return d;
	}
	function Hb(a, b, c) {
		if (b && !a.L) throw Error("Can't create secondary domain capable XhrIo object.");
		b = a.Aa && !a.ma ? new X(new Ec({ ab: c })) : new X(a.ma);
		b.Fa(a.L);
		return b;
	}
	h.isActive = function() {
		return !!this.l && this.l.isActive(this);
	};
	function ad() {}
	h = ad.prototype;
	h.ra = function() {};
	h.qa = function() {};
	h.pa = function() {};
	h.oa = function() {};
	h.isActive = function() {
		return true;
	};
	h.Ka = function() {};
	function bd() {}
	bd.prototype.g = function(a, b) {
		return new Y(a, b);
	};
	function Y(a, b) {
		C.call(this);
		this.g = new Sc(b);
		this.l = a;
		this.h = b && b.messageUrlParams || null;
		a = b && b.messageHeaders || null;
		b && b.clientProtocolHeaderRequired && (a ? a["X-Client-Protocol"] = "webchannel" : a = { "X-Client-Protocol": "webchannel" });
		this.g.o = a;
		a = b && b.initMessageHeaders || null;
		b && b.messageContentType && (a ? a["X-WebChannel-Content-Type"] = b.messageContentType : a = { "X-WebChannel-Content-Type": b.messageContentType });
		b && b.sa && (a ? a["X-WebChannel-Client-Profile"] = b.sa : a = { "X-WebChannel-Client-Profile": b.sa });
		this.g.U = a;
		(a = b && b.Qb) && !y(a) && (this.g.u = a);
		this.A = b && b.supportsCrossDomainXhr || false;
		this.v = b && b.sendRawJson || false;
		(b = b && b.httpSessionIdParam) && !y(b) && (this.g.G = b, a = this.h, a !== null && b in a && (a = this.h, b in a && delete a[b]));
		this.j = new Z(this);
	}
	t(Y, C);
	Y.prototype.m = function() {
		this.g.l = this.j;
		this.A && (this.g.L = true);
		this.g.connect(this.l, this.h || void 0);
	};
	Y.prototype.close = function() {
		cc(this.g);
	};
	Y.prototype.o = function(a) {
		var b = this.g;
		if (typeof a === "string") {
			var c = {};
			c.__data__ = a;
			a = c;
		} else this.v && (c = {}, c.__data__ = ab(a), a = c);
		b.i.push(new dc(b.Ya++, a));
		b.I == 3 && bc(b);
	};
	Y.prototype.N = function() {
		this.g.l = null;
		delete this.j;
		cc(this.g);
		delete this.g;
		Y.Z.N.call(this);
	};
	function cd(a) {
		gb.call(this);
		a.__headers__ && (this.headers = a.__headers__, this.statusCode = a.__status__, delete a.__headers__, delete a.__status__);
		var b = a.__sm__;
		if (b) {
			a: {
				for (const c in b) {
					a = c;
					break a;
				}
				a = void 0;
			}
			if (this.i = a) a = this.i, b = b !== null && a in b ? b[a] : void 0;
			this.data = b;
		} else this.data = a;
	}
	t(cd, gb);
	function dd() {
		hb.call(this);
		this.status = 1;
	}
	t(dd, hb);
	function Z(a) {
		this.g = a;
	}
	t(Z, ad);
	Z.prototype.ra = function() {
		D(this.g, "a");
	};
	Z.prototype.qa = function(a) {
		D(this.g, new cd(a));
	};
	Z.prototype.pa = function(a) {
		D(this.g, new dd());
	};
	Z.prototype.oa = function() {
		D(this.g, "b");
	};
	bd.prototype.createWebChannel = bd.prototype.g;
	Y.prototype.send = Y.prototype.o;
	Y.prototype.open = Y.prototype.m;
	Y.prototype.close = Y.prototype.close;
	createWebChannelTransport = webchannel_blob_es2018.createWebChannelTransport = function() {
		return new bd();
	};
	getStatEventTarget = webchannel_blob_es2018.getStatEventTarget = function() {
		return jb();
	};
	Event = webchannel_blob_es2018.Event = I;
	Stat = webchannel_blob_es2018.Stat = {
		jb: 0,
		mb: 1,
		nb: 2,
		Hb: 3,
		Mb: 4,
		Jb: 5,
		Kb: 6,
		Ib: 7,
		Gb: 8,
		Lb: 9,
		PROXY: 10,
		NOPROXY: 11,
		Eb: 12,
		Ab: 13,
		Bb: 14,
		zb: 15,
		Cb: 16,
		Db: 17,
		fb: 18,
		eb: 19,
		gb: 20
	};
	ub.NO_ERROR = 0;
	ub.TIMEOUT = 8;
	ub.HTTP_ERROR = 6;
	ErrorCode = webchannel_blob_es2018.ErrorCode = ub;
	vb.COMPLETE = "complete";
	EventType = webchannel_blob_es2018.EventType = vb;
	fb.EventType = H;
	H.OPEN = "a";
	H.CLOSE = "b";
	H.ERROR = "c";
	H.MESSAGE = "d";
	C.prototype.listen = C.prototype.J;
	WebChannel = webchannel_blob_es2018.WebChannel = fb;
	webchannel_blob_es2018.FetchXmlHttpFactory = Ec;
	X.prototype.listenOnce = X.prototype.K;
	X.prototype.getLastError = X.prototype.Ha;
	X.prototype.getLastErrorCode = X.prototype.ya;
	X.prototype.getStatus = X.prototype.ca;
	X.prototype.getResponseJson = X.prototype.La;
	X.prototype.getResponseText = X.prototype.la;
	X.prototype.send = X.prototype.ea;
	X.prototype.setWithCredentials = X.prototype.Fa;
	XhrIo = webchannel_blob_es2018.XhrIo = X;
}).apply(typeof commonjsGlobal !== "undefined" ? commonjsGlobal : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {});
//#endregion
//#region node_modules/re2js/build/index.js
/*!
* re2js
* RE2JS is the JavaScript port of RE2, a regular expression engine that provides linear time matching
*
* @version v2.8.6
* @author Oleksii Vasyliev
* @homepage https://github.com/le0pard/re2js#readme
* @repository github:le0pard/re2js
* @license MIT
*/
var RE2Flags = class RE2Flags {
	static FOLD_CASE = 1;
	static LITERAL = 2;
	static CLASS_NL = 4;
	static DOT_NL = 8;
	static ONE_LINE = 16;
	static NON_GREEDY = 32;
	static PERL_X = 64;
	static UNICODE_GROUPS = 128;
	static WAS_DOLLAR = 256;
	static LOOKBEHIND = 512;
	static MATCH_NL = RE2Flags.CLASS_NL | RE2Flags.DOT_NL;
	static PERL = RE2Flags.CLASS_NL | RE2Flags.ONE_LINE | RE2Flags.PERL_X | RE2Flags.UNICODE_GROUPS;
	static POSIX = 0;
	static UNANCHORED = 0;
	static ANCHOR_START = 1;
	static ANCHOR_BOTH = 2;
};
/**
* Public flags for RE2JS and RE2Set compilation.
*/
var PublicFlags = {
	CASE_INSENSITIVE: 1,
	DOTALL: 2,
	MULTILINE: 4,
	DISABLE_UNICODE_GROUPS: 8,
	LONGEST_MATCH: 16,
	LOOKBEHINDS: 512
};
/**
* Various constants and helper for unicode codepoints.
*/
var ASCII_SIZE = 128;
var ASCII_TO_UPPER = new Int32Array(ASCII_SIZE);
var ASCII_TO_LOWER = new Int32Array(ASCII_SIZE);
var MAX_BMP = 65535;
for (let i = 0; i < ASCII_SIZE; i++) {
	if (i >= 97 && i <= 122) ASCII_TO_UPPER[i] = i - 32;
	else ASCII_TO_UPPER[i] = i;
	if (i >= 65 && i <= 90) ASCII_TO_LOWER[i] = i + 32;
	else ASCII_TO_LOWER[i] = i;
}
var Codepoint = class {
	static CODES = /* @__PURE__ */ new Map([
		["\x07", 7],
		["\b", 8],
		["	", 9],
		["\n", 10],
		["\v", 11],
		["\f", 12],
		["\r", 13],
		[" ", 32],
		["\"", 34],
		["$", 36],
		["&", 38],
		["'", 39],
		["(", 40],
		[")", 41],
		["*", 42],
		["+", 43],
		["-", 45],
		[".", 46],
		["0", 48],
		["1", 49],
		["2", 50],
		["3", 51],
		["4", 52],
		["5", 53],
		["6", 54],
		["7", 55],
		["8", 56],
		["9", 57],
		[":", 58],
		["<", 60],
		[">", 62],
		["?", 63],
		["A", 65],
		["B", 66],
		["C", 67],
		["F", 70],
		["P", 80],
		["Q", 81],
		["U", 85],
		["Z", 90],
		["[", 91],
		["\\", 92],
		["]", 93],
		["^", 94],
		["_", 95],
		["`", 96],
		["a", 97],
		["b", 98],
		["f", 102],
		["i", 105],
		["m", 109],
		["n", 110],
		["r", 114],
		["s", 115],
		["t", 116],
		["v", 118],
		["x", 120],
		["z", 122],
		["{", 123],
		["|", 124],
		["}", 125]
	]);
	static toUpperCase(codepoint) {
		if (codepoint < ASCII_SIZE) return ASCII_TO_UPPER[codepoint];
		const s = String.fromCodePoint(codepoint).toUpperCase();
		const expectedLen = s.codePointAt(0) > MAX_BMP ? 2 : 1;
		if (s.length > expectedLen) return codepoint;
		const sOrigin = String.fromCodePoint(s.codePointAt(0)).toLowerCase();
		const originExpectedLen = sOrigin.codePointAt(0) > MAX_BMP ? 2 : 1;
		if (sOrigin.length > originExpectedLen || sOrigin.codePointAt(0) !== codepoint) return codepoint;
		return s.codePointAt(0);
	}
	static toLowerCase(codepoint) {
		if (codepoint < ASCII_SIZE) return ASCII_TO_LOWER[codepoint];
		const s = String.fromCodePoint(codepoint).toLowerCase();
		const expectedLen = s.codePointAt(0) > MAX_BMP ? 2 : 1;
		if (s.length > expectedLen) return codepoint;
		const sOrigin = String.fromCodePoint(s.codePointAt(0)).toUpperCase();
		const originExpectedLen = sOrigin.codePointAt(0) > MAX_BMP ? 2 : 1;
		if (sOrigin.length > originExpectedLen || sOrigin.codePointAt(0) !== codepoint) return codepoint;
		return s.codePointAt(0);
	}
};
var UnicodeRangeTable = class {
	/**
	* @param {Uint32Array | number[]} data
	* @param {boolean} isStride1
	*/
	constructor(data, isStride1 = false) {
		this.data = data;
		this.isStride1 = isStride1;
		this.SIZE = isStride1 ? 2 : 3;
	}
	getLo(index) {
		return this.data[index * this.SIZE];
	}
	getHi(index) {
		return this.data[index * this.SIZE + 1];
	}
	getStride(index) {
		return this.isStride1 ? 1 : this.data[index * this.SIZE + 2];
	}
	get length() {
		return this.data.length / this.SIZE;
	}
};
var B64_MAP = /* @__PURE__ */ new Uint8Array(256);
for (let i = 0, b = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-"; i < 64; i++) B64_MAP[b.charCodeAt(i)] = i;
var decodeVLQ = (str) => {
	const res = [];
	let value = 0, shift = 0;
	for (let i = 0; i < str.length; i++) {
		let digit = B64_MAP[str.charCodeAt(i)];
		value |= (digit & 31) << shift;
		if ((digit & 32) === 0) {
			res.push(value);
			value = 0;
			shift = 0;
		} else shift += 5;
	}
	return res;
};
var decodeRanges = (str, isStride1) => {
	const res = decodeVLQ(str);
	const numRanges = isStride1 ? res.length / 2 : res.length / 3;
	const out = new Uint32Array(numRanges * 3);
	let current = 0, resIdx = 0;
	for (let i = 0; i < numRanges; i++) {
		current += res[resIdx++];
		out[i * 3] = current;
		current += res[resIdx++];
		out[i * 3 + 1] = current;
		out[i * 3 + 2] = isStride1 ? 1 : res[resIdx++];
	}
	return out;
};
var decodeOrbit = (str) => {
	const res = decodeVLQ(str);
	const map = /* @__PURE__ */ new Map();
	let currentKey = 0;
	for (let i = 0; i < res.length; i += 2) {
		currentKey += res[i];
		const zz = res[i + 1];
		const delta = zz >>> 1 ^ -(zz & 1);
		map.set(currentKey, currentKey + delta);
	}
	return map;
};
var LazyMap = class {
	constructor(initializer) {
		this.initializer = initializer;
		this.cache = /* @__PURE__ */ new Map();
	}
	has(key) {
		return key in this.initializer;
	}
	get(key) {
		if (this.cache.has(key)) return this.cache.get(key);
		const fn = this.initializer[key];
		const val = fn ? fn() : null;
		this.cache.set(key, val);
		return val;
	}
};
var UnicodeTables = class {
	static _CASE_ORBIT = null;
	static get CASE_ORBIT() {
		if (!this._CASE_ORBIT) this._CASE_ORBIT = decodeOrbit("rCgCIgCY+rQI4QiCuuBLgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCCgCBgCBgCBgCBgCBgCBgCB+7OB-BB-BB-BB-BB-BBskQB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BC-BB-BB-BB-BB-BB-BB-BByHBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBDCBBBCBBBCBBCCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBCCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBxHBCBBBCBBBCBBB3SBmMBkNBCBBBCBBB8MBCBBB6MB6MBCBBC+EB0MB2MBCBBB6MB+MBiGBmNBiNBCBBBmKBikzCBmNBqNBkIBsNBCBBBCBBBCBBB0NBCBBB0NDCBBB0NBCBBByNByNBCBBBCBBB2NBCBBDCBBCwDFCBCBDBCBCBDBCBCBDBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBB9EBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBCCBCBDBCBBBhGBvDBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBjICCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBH2iVBCBBBlKBwiVB+jVB+jVBCBBBlMBqEBuEBCBBBCBBBCBBBCBBBCBBB+hVB4hVB8hVBjNB7MC5MB5MCzMC1MB+0yCE5MB20yCC9MBu2yCBwyyCBo0yCChNBlNBo0yCBu-UBi0yCDlNC6-UBpNDrNIu+UDzNCm0yCBzNE0yyCBzNBpEBxNBxNBtEG1NLqxyCBkxyCnFoFrBCBBBCBBDCBBEkIBkIBkICoHHsCCqCBqCBqCCgEC+DB+DBmkOBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCC+BBgCBgCBgCBgCBgCBgCBgCBgCBrCBpCBpCBpCBmjOB-BB8BB-BB-BBgEB-BB-BByBBqgOBsDB-BBtwBB-BB-BB-BBsBBgDBCB-BB-BB-BBeB-BB-BB61OB-BB-BB-DB9DB9DBQB7DBmCE9CBrDBPBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBrFB-EBOBnHB3FB-FCCBBBNBCBBCjIBjIBjIBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCB-BB-BB8kMB-BB6kMB-BB-BB-BB-BB-BB-BB-BB-BB-BBokMB-BB-BBkkMBkkMB-BB-BB-BB-BB-BB-BB-BB4jMB-BB-BB-BB-BB-BB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EBCBBBCBoiMBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBJCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBeBCBBBCBBBCBBBCBBBCBBBCBBBCBBBdBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBCgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDL-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-C64CgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOCgmOGgmODg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FDg8FBg8FBg8FhVg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBQBQBQBQBQBQDPBPBPBPBPBPjkC7mMB5mMBnmMBjmMBCBlmMB3lMBpiMBk8kCBCBBG-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FD-7FB-7FB-7F6FoglCEsuHRwjlCyDCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCB0DBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBG1DD97OCCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQDPBPBPBPBPBPDQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQDPBPBPBPBPBPEQCQCQCQCPCPCPCPBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPB0EB0EBsFBsFBsFBsFBoGBoGBgIBgIBgHBgHB8HB8HDQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQCSFPBPBzEBzEBRCxnOFSFrFBrFBrFBrFBREQBQClkOFPBPBnGBnGFQBQCljOCODPBPB-GB-GBNHSF-HB-HB7HB7HBRqJ53OE9tQBrmQH4Bc3BSgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBfBfBfBfBfBfBfBfBfBfBfBfBfBfBfBfECBByZ0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzB34BgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CBCBBBt-UBruHBt+UB1iVBviVBCBBBCBBBCBBB3hVB5-UB9hVB7hVCCBBCCBBI9jVB9jVBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBICBBBCBBECBBN-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOC-lOG-lOzoeCBBBCBBBCBBBCBBBCBBBCBl8kCBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBTCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBnECBBBCBBBCBBBCBBBCBBBCBBBCBBDCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBKCBBBCBBBnglCBCBBBCBBBCBBBCBBBCBBECBBBvyyCDCBBBCBBBgDCCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBn0yCB90yCB10yCBh0yCBn0yCCjxyCBzyyCBpxyCBg6BBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBB-CBl0yCBvjlCBCBBBCBBBt2yCBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBhkzCZCBB9a-5Bd-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCm6TCBB7gBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCH-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BmlBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvChDwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCFvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvC1DuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCCuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCCuCBuCBuCBuCBuCBuCBuCCuCBuCCtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCCtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCCtCBtCBtCBtCBtCBtCBtCCtCBtCk2BgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEO-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-D+CgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCL-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-B74CgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BhrVgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BhB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BD1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BtxekCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjC");
		return this._CASE_ORBIT;
	}
	static _Print = null;
	static get Print() {
		if (!this._Print) this._Print = new UnicodeRangeTable(decodeRanges("hB9CBjBLBCpWBDFBFGBCCCBSBCsMBClBBDxBBDCBC2BBJaBFFBSVBC-FBCvBBD6BBDkDBP6BBDwBBDOBCbBDCCBJBGfBIqCBCgFBCHBDBBDVBCGBCEEBCBDIBDBBDDBJFFBCCBDBDYBDCBCFBFBBDVBCGBCBBCBBCBBDCCBDBFBBDCBEIIBCBCIIBPBLCBCIBCCBCVBCGBCBBCEBDJBCCBCCBDQQBCBDLBIGBCCBCHBDBBDVBCGBCBBCEBDIBDBBDCBICBFBBCEBDRBLBBCFBECBCDBEBBCCCBEEBEEBBBELBFEBECBCDBDHHPUBGMBCCBCWBCPBDIBCCBCDBIBBCCBCBBDDBDJBIVBCCBCWBCJBCEBDIBCCBCDBIBBGCBCDBDJBCCBNMBCCBCyBBCCBCFBFPBDZBCCBCRBEXBCIBCDDBFBEFFBEBCCCBGBHJBDCBN5BBFcBmBBBCCCBDBCXBCCCBVBDEBCCCBFBCJBDDBhBnCBCjBBFmBBCjBBCOBCMBmBlGBCGGD4LBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBDfBEZBH1CBDFBD-TBCbBE4CBIVBKXBKTBNMBCCBCBBN9CBDJBHJBHNBCKBH4CBIqBBGlCBLeBCLBFLBFEEBoBBDEBMrBBFZBHKBE9BBDgCBCcBDKBHJBHNBDtBBDLBVsCBClFBJ7BBEOBE9BBGqBBDKBJqBBG1QBDFBDlBBDFBDHBCGCBdBD0BBCOBCNBDFBCSBDCBCIBSXBJuBBSBBDaBCMBEhBBPgBBQrEBF5UBXKBWz4BBD9LBGsBBCGGD3BBIBBPXBKGBCGBCGBCGBCGBCGBCGBCGBC9DBjBZBC4CBN1GBbPBC+BBC1CBDmDBGqBBC9CBC1CBKvBBCszcBE2BBK7KBV3FBJ8GBV7BBEJBH3BBJlCBJLBHzDBMdBEtCBCKBFgBBC2BBKNBDJBDmDBZbBLFBDFBDFBKGBCGBC7BBF9DBDJBHj9KBNWBFwBBloItLBDpDBnBGBNEBGZBCEBCCCBCCBCCBoUBhBpBBHyBBCSBCDBFEBCmEBF9FBEFBDFBDFBDCBEGBCGBOBBDLBCZBCSBCBBCOBDNBjB6DBGCBFsBBE3CBCMBEwBwBBsBBjEcBEwBBQbBFjBBKdBGqBBGdBCkBBFNBrB9EBDJBHjBBFjBBFnBBJzBBMLBCOBCGBCBBCKBCOBCGBCBBEzBBN2JBKVBLHBZFBCpBBCIBmCFBDCCBqBBCBBEDDBVBCnCBJIBxBSBCBBGgBBEaBGaBnB3BBFTBDxBBCBBGHBCCBCcBDCBFJBIIBI-BBhBmBBFLBK1BBEcBDaBGZBIDBNGBxCoCB4ByBBOyBBItBBJJBHlBBEcBJBBxGeBCpBBCCBDBBRFBJIBiBtBBJpBBXZBnBbBVWBKtCBFjBBK9BBCEBOYBIJBH0BBCRBJmBBK-CBCTBMRBCuBB-BGBCCCBCBCOBCKBH6BBGJBHDBCHBDBBDVBCGBCBBCEBCJBDBBDCBDHHGGBDGBEEBMJBCDDClBBCJBCDDCDBCJBCBBJBBe7CBCEBfnCBJJBnF1BBDlBBjBkCBMJBHMBU5BBHJBHTBdaBDOBFWB6F7BBlDyCBNHBDDDBGBCBBCdBCBBDLBKJBnCHBDtBBDKBcnCBJyCBOoCBIJB3CHB5ChBBPJBHIBCsBBCNBLcBEfBDVBCNBqCGBCBBCrBBECCBCCBHBJJBHFBCBBCkBBCBBCFBIJBHrBBFJB3HYBIQBCoBBEcB2CQQBwBBO6cBnDuDBCEBMjGBtyCiDBOvhBBRVBL68DBGmSB61G5BBn2B4RBIeBCJBFwCBCJBHdBDFBLlCBLJBCGBCUBGSBxN5BBnG6CBGYBDYBtBqCBF4BBIQBhCEBMGBK1mHBqBfBiDyDB+vIDBCGBCBBCiJBQeeBBBDPPBCBJrMBloCqDBGMBEIBIJBDDBh7D8HBEzNBHWBQQBQtBBDWBKzDB9B1HBLmBBDpCBJvDBWlCB7DTBNTBN2CBKYBoE0CBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDjJBD9VBQEBCOBxiBeBHFB2GGBCQBDGBCBBCEBG9BBiBxDxDBrBBENBDJBFBBhKeBS5BBGxOxOBoBB3GqBBFhGhGBdBCVBJBBhHGBCDBCBBCOBCkGBDPBqBrCBFJBFBByYjCBtC8BBjGDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQB1BBBvIrBBFjDBNOBDOBCOBCkBBLtFB5BcBOrBBFIBIBBPFB7E4eBEQBEMBE5GBHLBFQQBKBF3BBJJBHnBBJdBDLBFBBPIBoB3KBJNBDMBEKBE4BBCFFBOBDLBFJBIyEBCmDBmgB-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIBnkzVvHB", false));
		return this._Print;
	}
	static CATEGORIES = new LazyMap({
		C: () => new UnicodeRangeTable(decodeRanges("AfBgDgBBOrWrWBHHBCBICCVuMuMnBBBzBBBE4B4BBGBcDBHQBXhGhGxBBB8BBBmDNB8BBByBBBQddBCCMEBhBGBsCiFiFJBBDBBXIICCBFBBKBBDBBFHBCDBDGGBaaBEEHDBDBBXIIDGDBCCGDBDBBECBCGBFCCBFBSJBEKKEXXIDDGBBLIEBCCBNBFBBNGBIEEJBBDBBXIIDGGBKKBDDBEEBFBEDBDGGBTTBIBDHHBBBEFFBBBDCCDCBDCBECBNDBGCBEFFBCCBEBCNBWEBOEEYRRBKKEFFBFBDEEDBBFBBLGBXEEYLLGBBKEEFGBDEBEFFBLLELBOEE0BEEHDBRBBbEETCBZKKCBBICBCDBHCCJFBLBBELB7BDBekBBDCCGZZCYYBGGCIILBBFfBpClBlBBCBoBlBlBQOOBjBBnGCCBDBCBB6LFFBIICFFBqBqBFBBiBFFBIICFFBQQ6BFFBkCkCBhBhBBBBbFB3CBBHBB+UCB6CGBXIBZIBVLBOEEDLB-CBBLFBLFBPMMBEB6CGBsBEBnCJBgBNNBCBNDBCCBrBBBGKBtBDBbFBMCB-BBBiCeeBMMBEBLFBPBBvBBBNTBuCnFnFBGB9BCBQCB-BEBsBBBMHBsBEB3QBBHBBnBBBHBBJGCgBBB2BQQPBBHUUBEEKMMBDBbEByBPBDBBcOOBBBjBNBiBOBtEDB7UVBMUB14BBB-LEBuBCCBDBCBB5BGBDNBZIBI4BI-DhBBb6C6CBKB3GZBxC3C3CBoDoDBDBsB-C-C3CIBxBuzcuzcBBB4BIB9KTB5FHB+GTB9BCBLFB5BHBnCHBNFB1DKBfCBvCMMBCBiB4B4BBHBPBBLBBoDXBdJBHBBHBBHIBIII9BDB-DBBLFBl9KLBYDByBjoIBvLBBrDlBBILBGEBbGGCGDrUfBrBFB0BUUFDBGoEoEBCB-FCBHBBHBBHBBECBIIIBLBDBBNbbUDDQBBPhBB8DEBEDBuBCB5COOBBBCuBBvBhEBeCByBOBdDBlBIBfEBsBEBfmBmBBCBPpBB-EBBLFBlBDBlBDBpBHB1BKBNQQIDDMQQIDDBBB1BLB4JIBXJBJXBHrBrBKkCBHBBCtBtBDCBCBBYpCpCBGBKvBBUDDBDBiBCBcEBclBB5BDBVBBzBDDBDBJEEeBBEDBLGBKGBhCfBoBDBNIB3BCBeBBcEBbGBFLBIvCBqC2BB0BMB0BGBvBHBLFBnBCBeHBDvGBgBrBrBEBBDPBHHBKgBBvBHBrBVBblBBdTBYIBvCDBlBIB-BGGBLBaGBLFB2BTTBGBoBIBhDVVBJBTwBwBB8BBICCFQQMFB8BEBLFBFJJBDDBXXIDDGLLBDDBEEBCCBEBCEBIBBICBGKBLCCBCCnBLLCBBCFFLDDBGBDcB9CGGBcBpCHBLlFB3BBBnBhBBmCKBLFBOSB7BFBLFBVbBcBBQDBY4FB9BjDB0CLBJBBCBBJDDfDDBNNBHBLlCBJBBvBBBMaBpCHB0CMBqCGBL1CBJ3CBjBNBLFBKuBuBPJBeCBhBBBXPPBnCBIDDtBCBCDDKHBLFBHDDmBDDHGBLFBtBDBL1HBaGBSqBqBBBBe0CBCOBzBMB8clDBwDGGBJBlGryCBkDMBxhBPBXJB88DEBoS41GB7Bl2BB6RGBgBLLBCByCLLBEBfBBHJBnCJBLIIWEBUvNB7BlGB8CEBaBBarBBsCDB6BGBS-BBGKBIIB3mHoBBhBgDB0D8vIBFIIDkJkJBNBCcBEBBCNBFHBtMjoCBsDEBOCBKGBLBBF-6DB+HCB1NFBYOBSOBvBBBYIB1D7BB3HJBoBBBrCHBxDUBnC5DBVLBVLB4CIBamEB2CoCoCDBBCBBDBBFNNCIIiCFFBJJIddFGGCCBI1K1KBlJlJB-V-VBNBGQQBuiBBgBFBH0GBISSBIIDGGBDB-BgBBCvDBuBCBPBBLDBD-JBgBQB7BEBCvOBrB1GBsBDBC-FBgBXXBGBD-GBIFFDQQmGBBRoBBtCDBLDBDwYBlCrCB+BhGBFccDCCBCCLFFCCCBEBCDBCECEDDCBBCICDCCBFFIKFCLLSEBEGGSzBBDtIBtBDBlDLBQBBQQQmBJBvF3BBeMBtBDBKGBDNBH5EB6eCBSCBOCB7GFBNDBCOBNDB5BHBLFBpBHBfBBNDBDNBKmBB5KHBPBBOCBMCB6BCCBCBRBBNDBLGB0EoDoDBjgBBh3pBfB-oEBBv0FBBypHOBvThtCB-QhvBBs6EEBrpIlkzVBxHvw-FB", false)),
		Cc: () => new UnicodeRangeTable(decodeRanges("AfgDgB", true)),
		Cf: () => new UnicodeRangeTable(decodeRanges("tFzqBzqBBEBXhGhGyBhMhMBxCxCs5D9-B9-BBDBbEByBEBCJBw03B6H6HBBBimEQQj7IPBhjiBDBwmFHBn0rYffB+CB", false)),
		Cn: () => new UnicodeRangeTable(decodeRanges("4bBBHDBICCVuMuMnBBBzBBBE4B4BBGBcDBHKBvI9B9BBmDmDBMB8BBByBBBQddBCCMEBjBEBuHJJBDDBXXICCBBBFBBKBBDBBFHBCDBDGGBaaBEEHDBDBBXIIDGDBCCGDBDBBECBCGBFCCBFBSJBEKKEXXIDDGBBLIEBCCBNBFBBNGBIEEJBBDBBXIIDGGBKKBDDBEEBFBEDBDGGBTTBIBDHHBBBEFFBBBDCCDCBDCBECBNDBGCBEFFBCCBEBCNBWEBOEEYRRBKKEFFBFBDEEDBBFBBLGBXEEYLLGBBKEEFGBDEBEFFBLLELBOEE0BEEHDBRBBbEETCBZKKCBBICBCDBHCCJFBLBBELB7BDBekBBDCCGZZCYYBGGCIILBBFfBpClBlBBCBoBlBlBQOOBjBBnGCCBDBCBB6LFFBIICFFBqBqBFBBiBFFBIICFFBQQ6BFFBkCkCBhBhBBBBbFB3CBBHBB+UCB6CGBXIBZIBVLBOEEDLB-CBBLFBLFBbFB6CGBsBEBnCJBgBNNBCBNDBCCBrBBBGKBtBDBbFBMCB-BBBiCeeBMMBEBLFBPBBvBBBNTBuCnFnFBGB9BCBQCB-BEBsBBBMHBsBEB3QBBHBBnBBBHBBJGCgBBB2BQQPBBHUUBEEKmDmDNBBcOOBBBjBNBiBOBtEDB7UVBMUB14BBB-LEBuBCCBDBCBB5BGBDNBZIBI4BI-DhBBb6C6CBKB3GZBxC3C3CBoDoDBDBsB-C-C3CIBxBuzcuzcBBB4BIB9KTB5FHB+GTB9BCBLFB5BHBnCHBNFB1DKBfCBvCMMBCBiB4B4BBHBPBBLBBoDXBdJBHBBHBBHIBIII9BDB-DBBLFBl9KLBYDByBDBvzIBBrDlBBILBGEBbGGCGDrUfBrBFB0BUUFDBGoEoEBCC-FCBHBBHBBHBBECBIIIBIBGBBNbbUDDQBBPhBB8DEBEDBuBCB5COOBBBCuBBvBhEBeCByBOBdDBlBIBfEBsBEBfmBmBBCBPpBB-EBBLFBlBDBlBDBpBHB1BKBNQQIDDMQQIDDBBB1BLB4JIBXJBJXBHrBrBKkCBHBBCtBtBDCBCBBYpCpCBGBKvBBUDDBDBiBCBcEBclBB5BDBVBBzBDDBDBJEEeBBEDBLGBKGBhCfBoBDBNIB3BCBeBBcEBbGBFLBIvCBqC2BB0BMB0BGBvBHBLFBnBCBeHBDvGBgBrBrBEBBDPBHHBKgBBvBHBrBVBblBBdTBYIBvCDBlBIBlCJBCBBaGBLFB2BTTBGBoBIBhDVVBJBTwBwBB8BBICCFQQMFB8BEBLFBFJJBDDBXXIDDGLLBDDBEEBCCBEBCEBIBBICBGKBLCCBCCnBLLCBBCFFLDDBGBDcB9CGGBcBpCHBLlFB3BBBnBhBBmCKBLFBOSB7BFBLFBVbBcBBQDBY4FB9BjDB0CLBJBBCBBJDDfDDBNNBHBLlCBJBBvBBBMaBpCHB0CMBqCGBL1CBJ3CBjBNBLFBKuBuBPJBeCBhBBBXPPBnCBIDDtBCBCDDKHBLFBHDDmBDDHGBLFBtBDBL1HBaGBSqBqBBBBe0CBCOBzBMB8clDBwDGGBJBlGryCBkDMB3iBJB88DEBoS41GB7Bl2BB6RGBgBLLBCByCLLBEBfBBHJBnCJBLIIWEBUvNB7BlGB8CEBaBBarBBsCDB6BGBS-BBGKBIIB3mHoBBhBgDB0D8vIBFIIDkJkJBNBCcBEBBCNBFHBtMjoCBsDEBOCBKGBLBBJ76DB+HCB1NFBYOBSOBvBBBYIB1D7BB3HJBoBBBjGUBnC5DBVLBVLB4CIBamEB2CoCoCDBBCBBDBBFNNCIIiCFFBJJIddFGGCCBI1K1KBlJlJB-V-VBNBGQQBuiBBgBFBH0GBISSBIIDGGBDB-BgBBCvDBuBCBPBBLDBD-JBgBQB7BEBCvOBrB1GBsBDBC-FBgBXXBGBD-GBIFFDQQmGBBRoBBtCDBLDBDwYBlCrCB+BhGBFccDCCBCCLFFCCCBEBCDBCECEDDCBBCICDCCBFFIKFCLLSEBEGGSzBBDtIBtBDBlDLBQBBQQQmBJBvF3BBeMBtBDBKGBDNBH5EB6eCBSCBOCB7GFBNDBCOBNDB5BHBLFBpBHBfBBNDBDNBKmBB5KHBPBBOCBMCB6BCCBCBRBBNDBLGB0EoDoDBjgBBh3pBfB-oEBBv0FBBypHOBvThtCB-QhvBBs6EEBrpIm8yVBCdBhD-DBxHvw-BB---BBB---BBB", false)),
		Co: () => new UnicodeRangeTable(decodeRanges("gg4B-nGh4hc9--BD9--B", true)),
		Cs: () => new UnicodeRangeTable(decodeRanges("gg2B--B", true)),
		L: () => new UnicodeRangeTable(decodeRanges("hCZBHZBwBLLFGGBVBCeBCpOBFLBPEBICCiEEBCBBDDBCHHCCBCCCBSBCyCBCqEBJlFBClBBDHHBnBBoCaBFDBuBqBBkBBBCiDBCQQBIIBLLBBBDRRCdBe4CBMZZBfBKBBFGGBUBFKKEYYBXBIKBGXBCGBRpBB7B1BBETTIJBQPBFHBDBBDVBCGBCEEBCBERROBBCCBPBBLJJBEBFBBDVBCGBCBBCBBCBBgBDBCUUBBBRIBCCBCVBCGBCBBCEBETTQBBYMMBGBDBBDVBCGBCBBCEBEffBCCBBBQSSCFBECBCDBEBBCCCBEEBEEBBBELBX1B1BBGBCCBCWBCPBEbbBBBCBBDBBfFFBGBCCBCWBCJBCEBEffBBBCBBQBBSIBCCBCoBBDRRGCBJCBZFBGRBEXBCIBCDDBFB7BvBBCBBNGB7BBBCCCBDBCXBCCCBIBCBBKDDBDBCWWBCBhBgCgCBGBCjBBcEB0DqBBVRRBEBFDBEEEBIIBBBFMBNSSBkBBCGGDqBBCsKBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBmBPBR1CBDFBErTBDQBCZBGqCBHHBIRBOSBPRBPMBCCBQzBBkBFFkC4CBIEBDhBBCGGBkCBLeByBdBDEBMrBBFZB3BWBK0BBzC+C+CBtBBSHB3BdBOBBLrBBbjBBqBCBLjBBDKBGqBBDCBqBDBCFBCBBEGGB+FBhC1IBDFBDlBBDFBDHBCGCBdBD0BBCGBCEEBBBCGBEDBDFBFMBGCBCGB1DOORMBmDFFDJBCEEBDBHGCBCBCKBDDBGEBF1B1BB8zC8zCBjHBHDBEBBNlBBCGGD3BBIRRBVBKGBCGBCGBCGBCGBCGBCGBCGBxC2O2OBrBrBBDBGBBF1CBHCBC5CBCDBGqBBC9CBSfBxBPBhQ-tGBhCs0VBkCtBBDsIBEPBLBBVuBBReBDlCByBIBDmDBDxCBVQBCCBCDBCWBezBBPxBB-BFBECCBMMBaBLWBacBIuBBdRRBDBCJBLEBCoBBYCBCHBVWBEEEBwBBCEEBDDBDBDCCZCBDKBICBNFBDFBDFBKGBCGBCqBBCNBHyDBej9KBNWBFwBBloItLBDpDBnBGBNEBGCCBIBCMBCEBCCCBCCBCCBqDBiBqLBT-BBD1BBpBLB1DEBCmEBlBZBHZBM4CBEFBDFBDFBDCBkBLBCZBCSBCBBCOBDNBjB6DBmMcBEwBBwBfBOTBCHBHlBBLdBDjBBFHBxB9EBTjBBFjBBFnBBJzBBNKBCOBCGBCBBCKBCOBCGBCBBEzBBN2JBKVBLHBZFBCpBBCIBmCFBDCCBqBBCBBEDDBVBLWBKeBiCSBCBBLVBLZBHZBnB3BBHBBhCQQBCBCCBCcBrBcBEcBkBHBCbBc1BBLVBLSBORBvDoCB4ByBBOyBBOjBBnBbBKWB7HpBBHBBRFB5BcBLJJBUBrBRBvBUBcWBN0BB6BBBDOOBrBBhBYBbjBBeDDJiBBENNBuBBPDBWCCkBRBCYBUBBgCGBCCCBCBCOBCJBIuBBnBHBDBBDVBCGBCBBCEBETTNEBfJBCDDClBBCaaCtBtBBzBBTDBVCBfvBBVBBC5F5FBtBBqBDBlBvBBV8B8BBpBBOoCoCBZBmBGB6FrBB1D-BBgBHBDDDBGBCBBCXBQCC-CHBDmBBRCCdLLBmBBIWWMtBBUTTBnCBoGgBBgBIBCkBBSyByBBcBxDGBCBBClBBWaaBEBCBBCfBPYYBqBBlISBQCCBLBChBB9DwCwCB4cBnHjGBtyCgDBQvhBBSFBa68DBGmSB61GdBj3B4RBIeBSuCBSdBTvBBRDBgBUBGSBxNsBB0G-BBhBYBDYBtBqCBGjCjCBLBhCBBCPPBNNB0mHBqBfBiDyDB+vIDBCGBCBBCiJBQeeBBBDPPBCBJrMBloCqDBGMBEIBIJBn7F0CBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDYBCYBCeBCYBCeBCYBCeBCYBCeBCYBCHB15BeBHFBmI9BBzEsBBLGBRiKiKBcBTrBBlPbBlHdBDwGwGBdBCCBCBBCGBDEBKBBhHGBCDBCBBCOBCkGB8BjCBI1lB1lBBCBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQBlqE-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIB", false)),
		LC: () => new UnicodeRangeTable(decodeRanges("hCZBHZB7BLLBVBCeBCiGBCDBFvGBDZBhGDBDBBECBCHHCCBCCCBSBCyCBCqEBJlFBClBBKoBB44ClBBCGGDqBBDCBhV1CBDFBjkCKBGqBBDCBhCrBBgCMBChBBmD1IBDFBDlBBDFBDHBCGCBdBD0BBCGBCEEBBBCGBEDBDFBFMBGCBCGBmIFFDJBCEEBDBHGCBCBCFBFDDBCBGEBF1B1BB8zC8zCB6DBDmDBHDBEBBNlBBCGGzoetBBTbBnEtCBCWBEDBCsCBZBBE2Z2ZBpBBGIBIvCBh6TGBNEBqgBZBHZBmlBvCBhDjBBFjBB1DKBCOBCGBCBBCKBCOBCGBCBBk2ByBBOyBB+CVBLVB74C-BBhrV-BBhBYBDYBtpZ0CBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDYBCYBCeBCYBCeBCYBCeBCYBCeBCYBCHB15BJBCTBHFB2uCjCB", false)),
		Ll: () => new UnicodeRangeTable(decodeRanges("hDZB7BqBqBBWBCHBC2BCBQCBuBCDECBBBDCCDEEBFFDEEBBBDDDCCCDCCBCCDEECDDBDDBBBHGDCOCBSCBDDCEEC4BCBFBDDDBCCFICBjCBDZBiGCCEEEBBBTccBhBBCBBECBCWCBDBCGDB0B0BBuBBCgBCK0BCDMCBgDCxBoBBo6CqBBDCB5XFBjkCIBC2D2DBqBBgCMBChBBnD0ECBHBCgDCBHBJFBLHBJHBJFBLHBJHBJNBDHBJHBJHBJEBCBBHEEBBBCBBJDBDBBJHBLCBCBBzIEEBEEcKFDBBJDBF2B2Bs1CvBBCEEBGCFCCBCCBEBGiDCBIICFFNlBBCGG0oesBCUaCoEMCBBBC+BCBGBCCCDICFCCDCCBBBCSCGGGCMCFCCDOCbEE2ZqBBGIBIvCBh6TGBNEBqhBZBumBnBBpEjBB8EKBCOBCGBCBBk4ByBB+DVB75CfBhsVfB8BYBnqZZBbGBCRBbZBbDBCCCBFBCKBbZBbZBbZBbZBbZBbZBbZBbZBbbBdYBCFBbYBCFBbYBCFBbYBCFBbYBCFBC15B15BBIBCTBHFB4vChBB", false)),
		Lm: () => new UnicodeRangeTable(decodeRanges("wVRBFLBPEBICCmEGG-OnHnHlFBBuIBBFgBgBKEEhFoFoF1mBgEgE2R72B72BsDkTkTxOFBvF+BBOjBjBBjBByVOORMBg-CBByHgGgG2OsBsBBDBGiDiDB+C+CBBB34bjnBjnBBEBvIzDzDdBB6DIBxCYYpDDBEBB2OXXqEtDtDWBBoDDBKngVngVuBBBh-BFBCpBBCIB0sBhBhB2K04D04DnrTDB9PCBpBBBnRMBhCBBCPPB9-P9-PBCBCGBCBByhM9BBqGGBud0Q0QsSAB", false)),
		Lo: () => new UnicodeRangeTable(decodeRanges("qFQQhIFFBCBxGBB7ZaBFDBuBfBCJBkBBBCiDBCZZBLLBBBDRRCdBe4CBMZZBfBWVBrBYBIKBGXBCGBRoBB8B1BBETTIJBROBFHBDBBDVBCGBCEEBCBERROBBCCBPBBLJJBEBFBBDVBCGBCBBCBBCBBgBDBCUUBBBRIBCCBCVBCGBCBBCEBETTQBBYMMBGBDBBDVBCGBCBBCEBEffBCCBBBQSSCFBECBCDBEBBCCCBEEBEEBBBELBX1B1BBGBCCBCWBCPBEbbBBBCBBDBBfFFBGBCCBCWBCJBCEBEffBBBCBBQBBSIBCCBCoBBDRRGCBJCBZFBGRBEXBCIBCDDBFB7BvBBCBBNFB8BBBCCCBDBCXBCCCBIBCBBKDDBDBYDBhBgCgCBGBCjBBcEB0DqBBVRRBEBFDBEEEBIIBBBFMBNyDyDBnKBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBmBPByDrTBDQBCZBGqCBHHBIRBOSBPRBPMBCCBQzBBpBkCkCBhBBC0BBIEBDhBBCGGBkCBLeByBdBDEBMrBBFZB3BWBK0BBxFuBBSHB3BdBOBBLrBBbjBBqBCBLdByDDBCFBCBBE7hB7hBBCB4-C3BBZWBKGBCGBCGBCGBCGBCGBCGBCGBoR2B2BF1CBJCCB4CBFGGBpBBC9CBSfBxBPBhQ-tGBhC0wUBC2jBBkCnBBJrIBFPBLBBjCyByBBkCBqFoDoDEGBCCBCDBCWBezBBPxBB-BFBECCBMMBaBLWBacBIuBBuBEBDIBLEBCoBBYCBCHBVPBCFBEEEBwBBCEEBDDBDBDCCZBBEKBIPPBEBDFBDFBKGBCGByEiBBej9KBNWBFwBBloItLBDpDBkCCCBIBCMBCEBCCCBCCBCCBqDBiBqLBT-BBD1BBpBLB1DEBCmEBqDJBCsBBDeBEFBDFBDFBDCBkBLBCZBCSBCBBCOBDNBjB6DBmMcBEwBBwBfBOTBCHBHlBBLdBDjBBFHBhEtCBjDnBBJzBB9CzBBN2JBKVBLHB5EFBDCCBqBBCBBEDDBVBLWBKeBiCSBCBBLVBLZBHZBnB3BBHBBhCQQBCBCCBCcBrBcBEcBkBHBCbBc1BBLVBLSBORBvDoCB4FjBBnBDBCxJxJBoBBHBBRCBCBB5BcBLJJBUBrBRBvBUBcWBN0BB6BBBDOOBrBBhBYBbjBBeDDJiBBENNBuBBPDBWCCkBRBCYBUBBgCGBCCCBCBCOBCJBIuBBnBHBDBBDVBCGBCBBCEBETTNEBfJBCDDClBBCaaCtBtBBzBBTDBVCBfvBBVBBC5F5FBtBBqBDBlBvBBV8B8BBpBBOoCoCBZBmBGB6FrBB0GHBDDDBGBCBBCXBQCC-CHBDmBBRCCdLLBmBBIWWMtBBUTTBnCBoGgBBgBIBCkBBSyByBBcBxDGBCBBClBBWaaBEBCBBCfBPYYBnBBCBBlISBQCCBLBChBB9DwCwCB4cBnHjGBtyCgDBQvhBBSFBa68DBGmSB61GdBj3B4RBIeBSuCBSdBTvBB0BUBGSB0NnBB2MqCBGwFwFB0mHBqBfBiDyDBuwIiJBQeeBBBDPPBCBJrMBloCqDBGMBEIBIJBxzI2P2PBrBBiBiKiKBcBTrBBlPaBmHdBDwGwGBdBCCBCBBCGBDEBKiHiHBFBCDBCBBCOBCkGB8pBDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQBlqE-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIB", false)),
		Lt: () => new UnicodeRangeTable(decodeRanges("lOGDnB2sH2sHBGBJHBJHBNQQwBAB", false)),
		Lu: () => new UnicodeRangeTable(decodeRanges("hCZBmDWBCGBiB2BCDOCDuBCBECEBBCCCBCCBBBDDBCBBCCBEBBCBBCECBCCDCCBCCBBBCCCBEEIJDCMCDQCDDDCCBC4BCIBBCBBDCCBCBCGCiJCCEJJHCCBBBCCCBCCBPBCIBkBDDBBBEWCGDDCBBDyBBxBgBCK2BCBMCD+CCDlBBq6ClBBCGGzW1CB0kCHHBpBBDCBhK0ECKgDCKHBJFBLHBJHBJFBMGCJHBpCDBNDBNDBNEBMDBnIFFECBDCBDEEBDBHGCBCBDDBLBBG+B+B9zCvBBxBCCBBBDGCBCBCDDJCBCgDCJCCFuqeuqeCqBCUaCoEMCE8BCLECBICFCCDCCEUCBDBCEBCOCBCBCCCBQCZs5Vs5VBYBmmBnBBpEjBB9EKBCOBCGBCBBr3ByBB+EVB75CfBhsVfBhCYBoqZZBbZBbZBbCCBGDBDDBCBCHBbZBbBBCDBDHBCGBcBBCDBCEBCEEBFBcZBbZBbZBbZBbZBbZBfYBiBYBiBYBiBYBiBYBiB2pE2pEBgBB", false)),
		M: () => new UnicodeRangeTable(decodeRanges("gYvDB0IGBoIsBBCCCBCCBCCpCKBxBUBRmDmDBFBDFBDBBCDBkBffBZB8CKB7BIBKZZBCBCIBCCBCEBsBCB8BIBrBXBCgBB3BCBCRBCGBLBBeCB5BCCBFBDBBDCBKLLBbbDCB5BCCBDBFBBDCBEffBEEMCB5BCCBGBCCBCCBVBBXFBCCB5BCCBFBDBBDCBICBLBBf8B8BBDBECBCDBKpBpBBDB4BCCBFBCCBCDBIBBMBBeCB5BCCBFBCCBCDBIBBMBBQNNBCB4BBBCGBCCBCDBKLLBeeBBBnCFFBEBCCCBGBTBB+BDDBFBNHBjDDDBHBMGBqCBBcECFBByBTBCBBGKBCjBBKlDlDBSBYDBFCBCCBDGBEDBOLBCLLBCBgWCBzdDBdCBeBBfBBhCfBKuBuBBBBC2D2DBjBjB3DLBFLB8GEB6BJBCcBDxBxBBsBBDLBVEBwBQBnBIBNCBfMB5BNBxBTB5ECBCUBFHHDCBnG-BBxWgBB--CCBuEhDhDBeBrRFBqDBB1udDBCJBhBBBxCBBxIEEFYYBDBF0C0CBzBzBBQBbRBOnBnBBGBaMBtBDBwBNBlBkCkCBMBNJJBuBuBBBBzBCCBBBDBBGBBCqBqBBDBGBBtHHBCBBx5TiXiXBOBRPBuejHjH2EEBn0BCBCBBGDBpBCBFmFmFB+R+RBCBiCEB+JBBuCFBnCKByBDB7DCB2BOBqBDDBLLBCBuBKBI+B+BBBBlBNBRBBtBNNBBBxBNBJDBCBB9CLBHDD+ELBWDB4BBBCGBDBBDCBKLLBDDBFBEEBkCIBCDDCDBCEBCPPBzCzCBQBYyCyCBSBsHGBDIBcBBzCQBrDMBmDOBhIOB2HFBCBBDDBCCCBuEuEBFBDGBEddBIBpBGBCDBJKKBJBvBPBnGHBoGHBCHBzCVBCNB7DFBECCBCCBFBCjCjCBDBCBBCEB8KDBKBBCxBxBBFBEEBYmnFmnFHOBpmLRBhuCEB8BGB5gBCCB1BBIDByCMMBslTslTBizEizEBsBBDWB-QEBEFBJHBDGBfDB1ECB89B2BBFxBBJPPXEBCOBxqBGBCQBDGBCBBCEBlDhFhFBFB4L+B+BBCB9PDB-HBB0HDDIBBG7O7OBFBuDGB29lYvHB", false)),
		Mc: () => new UnicodeRangeTable(decodeRanges("joC4B4BDCBJDBCBBzBBB7BCBHBBDBBLsBsB7BCBjC7B7BBBBJCCB2B2BB7B7BCHHBDDBLLnDBBCBBECBCCBLqBqBBBB+BDB+BBB7BCCBDBDBBCBBKBBdPPB7B7BBBBGCBCCBLrBrBBsCsCBBBHHBTBBrKBBgCsFsFBFFHDDBaaBLLBBBDGBWBBDFBDLLBBB5zBffiEIIBGBCBB7KDBDCBFBBCFBhHBB7BCCKCCBJJBEByExBxBGCCBDBCBB+BffFBBD9B9BDCBCEEBxBxBBGBJBBsFWW35EBB0-dBBD5C5CBzBzBBOBvEBBwBxBxBBFFBDDBBBvDBBDBBZuBuBCuDuDDBBGuHuHBCCBCCBCC0gZCCgEuBuBBBBFBB0DZZB8B8BxBCBKBBO+C+CBBBEBBCrFrFBBBgBBB7BBBCDBDBBDCBKLLB1C1CBBBIDDCDBCBBCmDmDBBBJBBErDrDBBBHCCBCBDuHuHBBBHDBDyDyDBBBJBBCuDuDCBBHoDoDCBBFmImIBBBK4H4HBEBCBBFDDCvEvEBBBJDBF1C1CeBB-BqGqGECCoGPPrDIID2G2GBDBFBBC-K-KBNNxBBBJBBCpvQpvQBBBlxD2BBpDBB0rYBBHFB", false)),
		Me: () => new UnicodeRangeTable(decodeRanges("okBBB1xF-wB-wBBCBCCBsshBCB", false)),
		Mn: () => new UnicodeRangeTable(decodeRanges("gYvDB0IEBqIsBBCCCBCCBCCpCKBxBUBRmDmDBFBDFBDBBCDBkBffBZB8CKB7BIBKZZBCBCIBCCBCEBsBCB8BIBrBXBCfB4BCCFHBFEEBFBLBBe7B7BFDBJVVBbbDBB6BFFBFFBDDBBBEffBEEMBB6BFFBDBCBBFVVBXXBEBC7B7BDCCBCBJIIBMMBff+BNNzBEE4BCCBBBGCBCDBIBBMBBe7B7BDHHGBBVBBdBB6BBBFDBJVVBeepCIIBBBC7C7CDGBNHBjDDDBHBMGBqCBBcEC4BNBCEBCBBGKBCjBBKnDnDBCBCFBCBBDBBaBBFCBRDBODDBHHQgWgWBBBzdCBeBBfBBfBBhCBBCGBJDDBJBKuBuBBBBC2D2DBjBjB3DCBFBBKHHBBB8GBBD7B7BCGBCCCDHBHJBDxBxBBMBCeBDLBVDBxBCCBDBCGGpBIBNBBhBDBDBBCCB5BCCBEECCB7BHBDBB5ECBCMBCGBFHHEBBnG-BBxWMBFEEBKB--CCBuEhDhDBeBrRDBsDBB1udFFBIBhBBBxCBBxIEEFaaBGG4EBBbRBOnBnBBGBaKBvBCBxBDDBCBDBBoBkCkCBEBDBBDBBNJJwB0B0BCCBDBBGBBCrBrBBJJvHDDFx5Tx5TiXPBRPBuejHjH2EEBn0BCBCBBGDBpBCBFmFmFB+R+RBCBiCEB+JBBuCFBnCKByBDB8D3B3BBNBqBDDBLLBBByBDBDBBI+B+BBBBlBEBCHB-BNNB1B1BBHBLDBDgDgDBBBDCCBHHD+E+EEHBWBB6BBBEmBmBBFBEEBnCFBOECPBB2CHBDCBCYY1CFBCFFBCCBvHvHBCBHBBCBBcBB2CHBDCCBrDrDCDDBEBCmDmDCDDBCBCEBkIIBCBBhIBBCFFxEDBDBBFhBhBBIBpBFBDDBJKKBEBDCBvBMBCBBnGCCBBBCqGqGBFBCFBCzCzCBUBDGBCBBCBB7DFBECCBCCBFBCpCpCBEEC8K8KBMMB1B1BBDBGCCYmnFmnFHOBpmLLBECBhuCEB8BGB5gBgCgCBCByC5lT5lTBizEizEBsBBDWBhRCBSHBDGBfDB1ECB89B2BBFxBBJPPXEBCOBxqBGBCQBDGBCBBCEBlDhFhFBFB4L+B+BBCB9PDB-HBB0HDDIBBG7O7OBFBuDGB29lYvHB", false)),
		N: () => new UnicodeRangeTable(decodeRanges("wBJB5DBBGDDBBBitBJBnEJBnGJB9MJB3DJBFFBtDJB3DJB3DJBDFBvDMB0DJBJGBoDJBpDGBISBuDJBhDJB3DJBnCTBtIJBnCJBwWTBybCBwHJBHJBXJBtJJBhEKBmFJBHJB3FJB3CJBnEJBHJB3gBEEBEBHJBnGyBBDEB3W7BBvCVB3TdBqrBqYqYaIBPCB4KDBrEJBfHBCOBhBJBoBOBh7cJB9FJBhKFB7EJBnBJBnGJBXJB3CJB3MJB34UJBuPsBBN4BBSBB2KaBlBDBeJJnEEBrGJBvdHBaGBoBIBsCEBXFBhFBBDPBDtBBhCIB1BBBfCBsCEBpDHBZHBqBGBrKFBxBJBHJB3IeB-EJBrBDBxDGBnEdBhEJB9BJBxEJBITB8HJB3KJB3DJB3LJBnDJBHTBtCLBlNSB+CJB3UJB3CcBkHJBnCJB3BJBnLJBnDUBshBuDBimPJBnpCJB3CJBnEJBCGBvQJBnIWB+KCB6nXJBnuBTBNTBtDYB2iBxBBhqCJBnNJB3PJB4HJBtWIBhEJB4Y6BBCCBCDBtCsBBCOBjeMBk3CJB", false)),
		Nd: () => new UnicodeRangeTable(decodeRanges("wBJnxBJnEJnGJ9MJ3DJ3DJ3DJ3DJ3DJ3DJ3DJ3DJ3DJhDJ3DJnCJ3IJnCJn6BJnBJtJJhEJnFJHJ3FJ3CJnEJHJnuiBJnVJnBJnGJXJ3CJ3MJ34UJnsBJnkCJHJ9YJhEJ9BJxEJ3IJ3KJ3DJ3LJnDJHTtCJnNJnDJ3UJ3CJ3HJnCJ3BJnLJ3uQJnpCJ3CJnEJ3QJ37XJ12CxBhqCJnNJ3PJ4HJ2aJ30EJ", true)),
		Nl: () => new UnicodeRangeTable(decodeRanges("u3FCBwzCiBBDDB-zDaaBHBPCBs1dJBxyW0BBtOJJnEEBrhIuDBm8SCB", false)),
		No: () => new UnicodeRangeTable(decodeRanges("yFBBGDDBBB2pCFB5LFB5DCBmEGB6GGBSIByNJB2hBTB0jBJBhP20B20BEFBHJBnGPBqB3W3WB6BBvCVB3TdBqrB1kB1kBBCBrEJBfHBCOBhBJBoBOBxrdFBymWsBBiCDBSBB2KaBlBDB1pBHBaGBoBIBsCEBXFBhFBBDPBDtBBhCIB1BBBfCBsCEBpDHBZHBqBGBrKFBhLeB-EJBrBDBxDGBnETB8LTBmqBBBvNIBobSB0aUBn8SGB-YWBqhZTBNTBtDYBvqFIBid6BBCCBCDBtCsBBCOBjeMB", false)),
		P: () => new UnicodeRangeTable(decodeRanges("hBCBCFBCDBLBBEBBbCBCccCkBkBGEELBBEEE-VJJzOFBqBBB0BCCDDDtBBBVBBCBBOCCBBBrCDBnDsBsBBMBqHCB3BOBgBmImIBLLtE5D5D6DnMnMNwLwL7CLLBpFpFBNBCmBmBBCBoCrCrCBDBFBBwDFBsFlTlTBHB4EuTuTtBBBvCCBoCBB+ECBCCBmBKB6JBB5GBBhEGBCFBhFBBLGBdCB9DDB8BEB-BBBhCHBM9Z9ZBWBJTBCMBCLBfBBPBB6TDBeBB+hBNBwCBBgBJB0MVBgCDBhBBB8XDBCBBxDwEwEBtBBCfBDLBkNCBFJBDLBRNNjD7C7CjgdBBuICBkDLL0DFB9LDB3CBBpBCBCyByBBwBwBiDMBRBB9DDB-DBBRBB6HzqUzqUBxGxGBIBXiBBCNBCFFCBB2ECBCFBCDBLBBEBBbCBCccCCCBFB7MCB9UxBxB-MoXoXoGgBgBxIIBnBxDxDBFBjCGB6CDByO-J-JjBlElEBDBtBDB+FGBuDBBCDB-DDBxBBBwCDBFOOCCB5CFBsDrJrJBCCBzDzDBDBLBBCpDpD7HWBqDCBdMBtCjEjEBBB9HpIpIBBB8E9C9CBGB0CCBCEB+CJB4GgDgDBDBrBBBmUBBrCMBwFxjBxjBBDB97CBB8zOBBmEiCiCBDBJpRpRBBBoJDBoK9lT9lTovHEB07C-a-aBAB", false)),
		Pc: () => new UnicodeRangeTable(decodeRanges("-Cg-Hg-HBUU-u3BBBZCBwHAB", false)),
		Pd: () => new UnicodeRangeTable(decodeRanges("tB9qB9qB0BiyDiyDmgBqgCqgCBEBiwDDDgBBBFdd-NUUwDxszBxszBBmBmBLqFqFhzD-J-J", false)),
		Pe: () => new UnicodeRangeTable(decodeRanges("pB0B0BgB+1D+1DC-6B-6BqtC4B4BQ7T7TCff-hBMCxChBhBCGC1MUChCCCiBmhBmhBCECtBGCtNICEGCDBB-ozB6G6GeOCESSCCCrF0B0BgBGD", false)),
		Pf: () => new UnicodeRangeTable(decodeRanges("7F+6H+6HEddpuDCCFDDQEE", false)),
		Pi: () => new UnicodeRangeTable(decodeRanges("rFt7Ht7HDBBDaapuDCCFDDQEE", false)),
		Po: () => new UnicodeRangeTable(decodeRanges("hBCBCCBDECBLLBEEBcclCGGPBBI-V-VJzOzOBEBqB3B3BDDDtBBBVBBCBBOCCBBBrCDBnDsBsBBMBqHCB3BOBgBmImIBLLtE5D5D6DnMnMNwLwL7CLLBpFpFBNBCxDxDrCEBFBBwDFBsFlTlTBHBmY9D9DBBBoCBB+ECBCCBmBFBCDB6JBB5GBBhEGBCFBhFBBLGBdCB9DDB8BEB-BBBhCHBMjajaBJJBGBJIBDDBDCBEKBCCCBIB7kDDBCBBxDwEwEBFFBBBDDDBHBCBBCDDBLLBDBCJBDDBCCCBLBDCBtNCB6B+F+FjgdBBuICBkDLL0DFB9LDB3CBBpBCBCyByBBwBwBiDMBRBB9DDB-DBBRBB6HlxUlxUBFBDXXVBBDDBECBCDBICBHCCB2E2EBBBCCBDECBLLBEEBcclBDDB7M7MBBB9UxBxB-MoXoXoGgBgBxIIBnBxDxDBFBjCGB6CDB0ZlElEBDBtBDB+FGBuDBBCDB-DDBxBBBwCDBFOOCCB5CFBsDrJrJBCCBzDzDBDBLBBCpDpD7HWBqDCBdMBtCjEjEBBB9HpIpIBBB8E9C9CBGB0CCBCEB+CJB4GgDgDBDBrBBBmUBBrCMBwFxjBxjBBDB97CBB8zOBBmEiCiCBDBJpRpRBBBoJDBoK9lT9lTovHEB07C-a-aBAB", false)),
		Ps: () => new UnicodeRangeTable(decodeRanges("oBzBzBgB-1D-1DC-6B-6B-rCEEnB4B4BQ7T7TCff-hBMCxChBhBCGC1MUChCCCiBmhBmhBCECaTTCECtNICEGCDipzBipzB4GeeCMCESSCCCrFzBzBgBEEDAB", false)),
		S: () => new UnicodeRangeTable(decodeRanges("kBHHRCBgBCCcCCkBEBCBBDCCBCBDEEfgBgBrODBNNBGGBCCCBPB2DPPBxDxDsErIrIBBB3DCBDDDBvGvGLUUB4H4HIBBpEqLqLBHHB2H2H-DjEjEBGBlEwGwGqBmGmGiGCBQCCBBBDFBVECmEHBCFBCBBGDBmGBBxXJB0WuLuLlL+E+EBgBBiLJBKIBhiBCCBBBMCBOCBOCBOBBmCOOoBCBOCBUhBB-BBBCDBCBBLCCBBBGFBCECFMMBFFBDBGDBC7B7BBFFB2LBFcBD+HBXKByCtCBXnTBtBwBBDeBLyMBX+BBFfBD1LBDpEBmHFBmLBBvBZBC4CBN1GBbPBFOOBNNWBBHBB8CBB0HBBFJBhBlBBKRRBdBMdBJQQBeBLmBBQ-JBhuG-BBx0V2BB6RWBKBBoDBB+EDBLDB+RCBiHPPB+9T+9TpEgBBuLPBhCBB3BHBtBDBjDCCBBBD7E7EHRRBBBgBCCcCCiEGBCGBOBB6JIB6BQBDCBCMBEwBwBBrBB7zBBBwSmWmWBiKiKBGBnjC2kC2kCBbBr6SDBG3qU3qUk7DvHBLCBEzNBHWBQQBgDzDB9B1HBLmBBD7BBGCBXBBIdBF8BBWhCBE7F7FB1CBrbaagBaagBaagBaagBaa9B-PB4BDBzBHBCNBCBBp2BwNwNttCEE+DiOiOBvIvIBqBBFjDBNOBDOBCOBCkBBYgFB5BcBOrBBFIBIBBPFB7E4eBEQBEMBE5GBHLBFQQBKBF3BBJJBHnBBJdBDLBFBBPIBoB3KBJNBDMBEKBE4BBCFFBOBDLBFJBIyEBC7CBLAB", false)),
		Sc: () => new UnicodeRangeTable(decodeRanges("kB+D+DBCBqnB8D8DzPBBzPBBI2H2HoImSmS8sClmClmCBgBB37hBkuVkuVtD7E7E8GBBEBB3-HDB-4wBxtCxtC", false)),
		Sk: () => new UnicodeRangeTable(decodeRanges("+CCCoCHHFEEqQDBNNBGGBCCCBPB2DPPBjoBjoB15FCCBBBMCBOCBOCBOBB9kEBBkzdWBKBBoDBBxePPBniUniUBPB8bCCjF4g9B4g9BBDB", false)),
		Sm: () => new UnicodeRangeTable(decodeRanges("rBRRBBB+BCCuBFFmBgBgB-XwQwQBBB8xGOOoBCBOCBsEoBoBBDBHlClCBDBGBBFGDIgBgBBDDCgBgBBqIBhBBB7CffBXBpBFB2OKK3BHBwDxKxKBDBDeBLPBhIiEBX+BBFfBDhIBxBUBDFB9+zB5Z5ZCCBlFRRBBB+BCCkEHHBCBitDBBhrwBx+Bx+BagBgBagBgBagBgBagBgBat5Ft5FB-uC-uCBHB", false)),
		So: () => new UnicodeRangeTable(decodeRanges("mFDDFCCyerIrIBgEgEBvGvGLUUB4H4HkQ2L2LjEFBClElEwGqBqBoMCBQCCBBBDFBVECmEHBCFBCBBGDBmGBBxXJB0WzWzW+EhBBiLJBKIBksBBBCDBCBBLCCBHHBEBCECFMMBPPCBBC7B7BBKKBDBDDBCBBCBBCGBCeBDBBCCCBdBtIHBFTBDGBDwCBCdBanBBHnCBXKByCtCBX2FBCIBC1BBJuDBC3HBtBrBBhC-HBhQvBBWBBHmBBDpEBmHFBmLBBvBZBC4CBN1GBbPBFOOBNNWBBHBBxKBBFJBhBlBBKRRBdBMdBJQQBeBLmBBQ-JBhuG-BBx0V2BBibDBLBBC+R+RBBBqqUPBuLPBhCBB3BHBuBCBlPEEFBBOBB6JIB6BQBDCBCMBEwBwBBrBB7zBBBwSpgBpgBBGBnjC2kC2kCBGBFQBr6SDBG3qU3qUk7DvHBLCBEzNBHWBQPBhDzDB9B1HBLmBBD7BBGCBXBBIdBF8BBWhCBE7F7FB1CBqlB-PB4BDBzBHBCNBCBBp2B96C96CiEyWyWBqBBFjDBNOBDOBCOBCkBBYgFB5BcBOrBBFIBIBBPFB7E6HBG4WBEQBEMBE5GBHLBFQQBKBF3BBJJBHnBBJdBDLBFBB-B3KBJNBDMBEKBE4BBCFFBOBDLBFJBIyEBC7CBLAB", false)),
		Z: () => new UnicodeRangeTable(decodeRanges("gBgEgEgvFgsCgsCBJBeBBGwBwBh9DAB", false)),
		Zl: () => new UnicodeRangeTable(decodeRanges("ohIA", true)),
		Zp: () => new UnicodeRangeTable(decodeRanges("phIA", true)),
		Zs: () => new UnicodeRangeTable(decodeRanges("gBgEgEgvFgsCgsCBJBlBwBwBh9DAB", false)),
		ASCII_Hex_Digit: () => new UnicodeRangeTable(decodeRanges("wBJIFbF", true)),
		Alphabetic: () => new UnicodeRangeTable(decodeRanges("hCZBHZBwBLLFGGBVBCeBCpOBFLBPEBICC3CeeBQBCBBDDBCHHCCBCCCBSBCyCBCqEBJlFBClBBDHHBnBBoBNBCCCBCCBCCJaBFDBeKBG3BBCGBPlDBCHBFHBFCBLCBDRRBuBBOkDBZgBBKBBFGGBWBDSBUYBIKBGXBCGBIJJBoBBLLBEGBHrCBCPBCCBFOBOSBCHBDBBDVBCGBCEEBCBEHBDBBDBBCJJFBBCEBNBBLFFBBBCFBFBBDVBCGBCBBCBBCBBFEBFBBDBBFIIBCBCSSBEBMCBCIBCCBCVBCGBCBBCEBEIBCCBCBBEQQBCBWDBFCBCHBDBBDVBCGBCBBCEBEHBDBBDBBKBBFBBCEBORRBCCBEBECBCDBEBBCCCBEEBEEBBBELBFEBECBCCBEHHpBMBCCBCWBCPBEHBCCBCCBJBBCCBCBBDDBdDBCHBCCBCWBCJBCEBEHBCCBCCBJBBGCBCDBOCBNMBCCBCoBBDHBCCBCCBCGGBCBIEBXFBCCBCRBEXBCIBCDDBFBJFBCCCBGBTBBO5BBGGBH0B0BBECBDBCXBCCCBRBCCBDEBCHHPDBhBgCgCBGBCjBBFSBFPBCjBBkC2BBCDDBDBR-BBLDBDlBBCGGDqBBCsKBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBmBPBR1CBDFBErTBDQBCZBGqCBEKBITBMUBNTBNMBCCBCBBNzBBDSBPFFkC4CBIqBBGlCBLeBCLBFIBYdBDEBMrBBFZB3BbBF+BBDTBzBYYBMMBBByBzBBCOBCHB0BpBBDDBLrBBCKBP2BBXCBLjBBDKBGqBBDCBqBDBCFBCBBEGGB+FBUhBBM1IBDFBDlBBDFBDHBCGCBdBD0BBCGBCEEBBBCGBEDBDFBFMBGCBCGB1DOORMBmDFFDJBCEEBDBHGCBCBCKBDDBGEBFSSBnBBuZzBB34BkHBHDBEBBNlBBCGGD3BBIRRBVBKGBCGBCGBCGBCGBCGBCGBCGBCfBwB2O2OBBBaIBIEBDEBF1CBHCBC5CBCDBGqBBC9CBSfBxBPBhQ-tGBhCs0VBkCtBBDsIBEPBLBBVuBBGHBEwDBoBIBDmDBDxCBVUBCgBBZzBBNjCBCtBtBBEBECCBBBLgBBGiBBOcBEyBBCLBQRRBOBLEBC2BBKNBTWBEkCBCCCZCBDPBDDBMFBDFBDFBKGBCGBCqBBCNBH6DBWj9KBNWBFwBBloItLBDpDBnBGBNEBGLBCMBCEBCCCBCCBCCBqDBiBqLBT-BBD1BBpBLB1DEBCmEBlBZBHZBM4CBEFBDFBDFBDCBkBLBCZBCSBCBBCOBDNBjB6DBmC0BBsIcBEwBBwBfBOdBGqBBGdBDjBBFHBCEBrB9EBTjBBFjBBFnBBJzBBNKBCOBCGBCBBCKBCOBCGBCBBEzBBN2JBKVBLHBZFBCpBBCIBmCFBDCCBqBBCBBEDDBVBLWBKeBiCSBCBBLVBLZBHZBnB3BBHBBhCDBCBBGHBCCBCcBrBcBEcBkBHBCbBc1BBLVBLSBORBvDoCB4ByBBOyBBOnBBjBbBEGGBVB7HpBBCBBEBBRFBzBCBEcBLJJBUBrBRBvBUBcWBKlCBsBEBL4BBKOOBXBYyBBSDBJiBBEKKB+BBCDBKBBLCCkBRBChBBDHHBCB-BGBCCCBCBCOBCJBI4BBYDBCHBDBBDVBCGBCBBCEBEHBDBBDBBEHHGGBdJBCDDClBBCJBCDDCDBCBBECCtBhCBCCBCDBVCBfhCBDBBC5F5FB0BBDGBaFBjB+BBCEE8B1BBDoCoCBZBDNBWGB6F4BBoD-BBgBHBDDDBGBCBBCdBCBBDBBDDB+CHBDtBBDFBCCCBccBxBBDJBSnCBGTTBnCBoDHB5CgBBgBIBCsBBCGBCyByBBcBDVBCNBqCGBCBBCrBBECCBCCBBBCDDBZZBEBCBBCkBBCBBCDBCYYBqBBlIWBKQBCoBBECBwDwCwCB4cBnDuDBSjGBtyCgDBQvhBBSFBa68DBGmSB61GuBBy2B4RBIeBSuCBSdBTvBBRDBgBUBGSBxNsBB0G-BBhBYBDYBtBqCBF4BBIQBhCBBCNNBFBK1mHBqBfBiDyDB+vIDBCGBCBBCiJBQeeBBBDPPBCBJrMBloCqDBGMBEIBIJBFi7Fi7FBzCBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDYBCYBCeBCYBCeBCYBCeBCYBCeBCYBCHB15BeBHFB2GGBCQBDGBCBBCEBG9BBiBxDxDBrBBLGBRiKiKBcBTrBBlPbBlHdBDwGwGBdBCVBJBBhHGBCDBCBBCOBCkGB8BjCBEEE1lBDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQB1TZBHZBHZB3zD-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIB", false)),
		Dash: () => new UnicodeRangeTable(decodeRanges("tB9qB9qB0BiyDiyDmgBqgCqgCBEB+BoBoBQnMnMlgDDDgBBBFdd-NUUwDxszBxszBBmBmBLqFqFhzD-J-J", false)),
		Emoji: () => new UnicodeRangeTable(decodeRanges("jBHHGJBwDFFu8HNN5GXX7CFBQBBwLBBNnFnFaKBFCBoGoHoHBLLK7B7BBCBCEBKGDBDDFDDCBBDIEBJJBBBGCCGLBMBBDCCBCCTDDBTTBEBCCCBEEBGGDBBFBBMBBGBBDGGBECBVVBGGBEBCDBDFFDDDBEBCDDCCCHEEHLLBQQDFFCFFBBBCMMBxBxBBBBKeP1LBBwOCBUBB0BFF7mBNN6SCCrrvDrGrGhFBBNBBPDDBIBsCZBCBBYVVDIBWBBvFhBBDvDBDBBCCBDyCBDCBCmIBC+BBMFBCXBIBBDHBNDDBCBDFFBOOBDDJBBKGGBBBNCBJCBDCCFHHEHHB0CBxBlCBGHBDDBEJBECCBEEDJBkHLBF8I8IBtBBCJBC4FBxDMBEKBE4BBCFFBOBDLBFJB", false)),
		Emoji_Component: () => new UnicodeRangeTable(decodeRanges("jBHHGJB0+H2G2Gsp3B3+8B3+8BBYB8PEBxtBDBtzhY-CB", false)),
		Emoji_Modifier: () => new UnicodeRangeTable(decodeRanges("7-8DE", true)),
		Emoji_Modifier_Base: () => new UnicodeRangeTable(decodeRanges("9wJ8G8GRDB4jzD9B9BBBBDDDBBB2DBBDKBWSBEFFBBBCCBICCZqGqGBFFWFFBvFvFBBBEEB0CRRBBBKMMgSDDJHBHKKBIBDCB5B+B+BBCCBCCSCBCMBmHCBrBIB", false)),
		Emoji_Presentation: () => new UnicodeRangeTable(decodeRanges("64IBBuGDBEDDqQBBWBBzBLBsBUUOJJBSSBGGBJJGWWIBBCFFDIIFBBdkBkBCFFBBBC+B+BBBBZPP8aBB0BFFvlxDrGrG-FDDBIBsCZBCZZVDDBDBCCBWBBvFgBBNIBClCBCVBNqBBFEBNQBEEEBlCBCCCB5FBD+BBODBCXBTbbBOO3C0CBxBlCBHEEBBBDDBEDBMBBIIBkHLBF8I8IBtBBCJBC4FBxDMBEKBE4BBCFFBOBDLBFJB", false)),
		Extended_Pictographic: () => new UnicodeRangeTable(decodeRanges("pFFFu8HNN5GXX7CFBQBBwLBBNnFnFaKBFCBoGoHoHBLLK7B7BBCBCEBKGDBDDFDDCBBDIEBJJBBBGCCGLBMBBDCCBCCTDDBTTBEBCCCBEEBGGDBBFBBMBBGBBDGGBECBVVBGGBEBCDBDFFDDDBEBCDDCCCHEEHLLBQQDFFCFFBBBCMMBxBxBBBBKeP1LBBwOCBUBB0BFF7mBNN6SCCrrvDoBoBBCBlDLBQBBQPPBmBmBBIBxDBBNBBPDDBIBU3BBcOBLVVDIBCDBKWBH7FBDvDBDBBCCBDyCBDCBCDBG9HBC+BBMFBCXBIBBDHBNDDBCBDFFBOOBDDJBBKGGBBBNCBJCBDCCFHHEHHB0CBxBlCBGHBDQBECCBEBDMB7GlBBNDB5BHBLFBpBHBfBBNDBDNBKmBBNuBBCJBC4FB5CHBPxEBhI9fB", false)),
		Hex_Digit: () => new UnicodeRangeTable(decodeRanges("wBJIFbFq1-BJIFbF", true)),
		Lowercase: () => new UnicodeRangeTable(decodeRanges("hDZBwBLLFlBlBBWBCHBC2BCBQCBuBCDECBBBDCCDEEBFFDEEBBBDDDCCCDCCBCCDEECDDBDDBBBHGDCOCBSCBDDCEEC4BCBFBDDDBCCFICBjCBDiBBIBBfEBhDsBsBCEEDDBTccBhBBCBBECBCWCBDBCGDB0B0BBuBBCgBCK0BCDMCBgDCxBoBBo6CqBBCDB5XFBjkCIBC2D2DB+FBiC0ECBHBCgDCBHBJFBLHBJHBJFBLHBJHBJNBDHBJHBJHBJEBCBBHEEBBBCBBJDBDBBJHBLCBCBB6DOORMBuDEEBEEcKFDBBJDBFiBiBBOBFsasaBYBn6BvBBCEEBGCFCCBCCBGBEiDCBIICFFNlBBCGG0oesBCUaCBBBmEMCBBBC8BCBIBCCCDICFCCDCCBBBCSCGGGCMCFCCDOCWDBCCCBBB2ZqBBCNBHvCBh6TGBNEBqhBZBumBnBBpEjBB8EKBCOBCGBCBBkODDBBBCpBBCIBmoByBB+DVB75CfBhsVfB8BYBnqZZBbGBCRBbZBbDBCCCBFBCKBbZBbZBbZBbZBbZBbZBbZBbZBbbBdYBCFBbYBCFBbYBCFBbYBCFBbYBCFBC15B15BBIBCTBHFBmI9BB1lChBB", false)),
		Math: () => new UnicodeRangeTable(decodeRanges("rBRRBBBgBeeCuBuBFmBmBgB5W5WBBBDbbBDDBBBwQCBuwGccBBBMEEOPPBCBWEBMEBiCMBFEEBFFBDBTFFDJBCDDBEBHEEBDDBCCBBBCFBENBClClCBWBCFBCBBFBBFfBCHHBPPBqIBJDBVBB7CffBZBCZZMGB+NBBNJBFFBFBBDBBEEBPCCDFBMHBGBB6BCCeDBKCBxK-BBhI-PBxBUBDFB9+zB4Z4ZBEBCjFjFRCBeCCeCCkEHHBCBitDBBhrwBwoBwoBBzCBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDjJBDxBBhwFDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQB1BBB-uCIB", false)),
		Quotation_Mark: () => new UnicodeRangeTable(decodeRanges("iBFFkEQQ96HHBaBBowDqOqOBCBOCBixzBDB+FFF7CBB", false)),
		Terminal_Punctuation: () => new UnicodeRangeTable(decodeRanges("hBLLCMMBEE-ZJJiQ6B6BpCPPCCB1FsBsBBJBCsHsHB3B3BBEBCHBgBmImIB1nB1nBBtFtFFFB4JBB2YHBmY9D9DBBBoCBB+ECBEoBoBBCBDBB7JBBjLDBjFBBLBBCCBeCB8FEB-BBBldYYBKKBBBwlDCBzJOOFLLCBBEBBtNBB8ndBBuICBkHEB-LBB3CBBgD4E4EBBB0ECBgERRB6H6HnxUDDB6B6BBBBCDBqFLLCMMBEEiCDD7hBxBxBnkBoGoG3JBB5EFBlCFB6CDB5dEBtBDB+FGBxDDBgECBiEBBHRRB5C5CBDBtDrJrJB2D2DBBBNBBnLDBEOBqDBB6HCBmQCC8HBB4CBBFBB-MCBuBmUmUBrCrCBspBspBBDB6vRBBmEiCiCBBBLqRqRBoJoJBnwTnwTovHDB", false)),
		Uppercase: () => new UnicodeRangeTable(decodeRanges("hCZBmDWBCGBiB2BCDOCDuBCBECEBBCCCBCCBBBDDBCBBCCBEBBCBBCECBCCDCCBCCBBBCCCBEEIJDCMCDQCDDDCCBC4BCIBBCBBDCCBCBCGCiJCCEJJHCCBBBCCCBCCBPBCIBkBDDBBBEWCGDDCBBDyBBxBgBCK2BCBMCD+CCDlBBq6ClBBCGGzW1CB0kCHHBpBBDCBhK0ECKgDCKHBJFBLHBJHBJFBMGCJHBpCDBNDBNDBNEBMDBnIFFECBDCBDEEBDBHGCBCBDDBLBBGbbBOBUzZzZBYBx5BvBBxBCCBBBDGCBCBCDDJCBCgDCJCCFuqeuqeCqBCUaCoEMCE8BCLECBICFCCDCCEUCBDBCEBCOCBCBCCCBQCZs5Vs5VBYBmmBnBBpEjBB9EKBCOBCGBCBBr3ByBB+EVB75CfBhsVfBhCYBoqZZBbZBbZBbCCBGDBDDBCBCHBbZBbBBCDBDHBCGBcBBCDBCEBCEEBFBcZBbZBbZBbZBbZBbZBfYBiBYBiBYBiBYBiBYBiB2pE2pEBgBBvgCZBHZBHZB", false)),
		White_Space: () => new UnicodeRangeTable(decodeRanges("JEBTlDlDbgvFgvFgsCKBeBBGwBwBh9DAB", false))
	});
	static get Upper() {
		return this.CATEGORIES.get("Lu");
	}
	static SCRIPTS = new LazyMap({
		Adlam: () => new UnicodeRangeTable(decodeRanges("go6DrCFJFB", true)),
		Ahom: () => new UnicodeRangeTable(decodeRanges("g4lCaDOFW", true)),
		Anatolian_Hieroglyphs: () => new UnicodeRangeTable(decodeRanges("ggxCmS", true)),
		Arabic: () => new UnicodeRangeTable(decodeRanges("gwBEBCFBCNBCCBCfBCJBMZBCrDBChBBxCvBBxHhBBGqCBCcBxy8BtPBDvEBhBPBxDEBCmEBk7DeBkCFBJIBiBFBh43BDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQB1BBB", false)),
		Armenian: () => new UnicodeRangeTable(decodeRanges("xpBlBDxBDCks9BE", true)),
		Avestan: () => new UnicodeRangeTable(decodeRanges("g4iC1BEG", true)),
		Balinese: () => new UnicodeRangeTable(decodeRanges("g4GsCCxB", true)),
		Bamum: () => new UnicodeRangeTable(decodeRanges("g1pB3CpowB4R", true)),
		Bassa_Vah: () => new UnicodeRangeTable(decodeRanges("w26CdDF", true)),
		Batak: () => new UnicodeRangeTable(decodeRanges("g+GzBJD", true)),
		Bengali: () => new UnicodeRangeTable(decodeRanges("gsCDBCHBDBBDVBCGBCEEBCBDIBDBBDDBJFFBCCBDBDYB", false)),
		Beria_Erfe: () => new UnicodeRangeTable(decodeRanges("g17CYDY", true)),
		Bhaiksuki: () => new UnicodeRangeTable(decodeRanges("ggnCICsBCNLc", true)),
		Bopomofo: () => new UnicodeRangeTable(decodeRanges("qXB6wLqBxDf", true)),
		Brahmi: () => new UnicodeRangeTable(decodeRanges("ggkCtCFjBKA", true)),
		Braille: () => new UnicodeRangeTable(decodeRanges("ggK-H", true)),
		Buginese: () => new UnicodeRangeTable(decodeRanges("gwGbDB", true)),
		Buhid: () => new UnicodeRangeTable(decodeRanges("g6FT", true)),
		Canadian_Aboriginal: () => new UnicodeRangeTable(decodeRanges("ggF-TxRlC7tgCP", true)),
		Carian: () => new UnicodeRangeTable(decodeRanges("g1gCwB", true)),
		Caucasian_Albanian: () => new UnicodeRangeTable(decodeRanges("wphCzBMA", true)),
		Chakma: () => new UnicodeRangeTable(decodeRanges("gokC0BCR", true)),
		Cham: () => new UnicodeRangeTable(decodeRanges("gwqB2BKNDJDD", true)),
		Cherokee: () => new UnicodeRangeTable(decodeRanges("g9E1CDFz7lBvC", true)),
		Chorasmian: () => new UnicodeRangeTable(decodeRanges("w9jCb", true)),
		Common: () => new UnicodeRangeTable(decodeRanges("AgCBbFBbuBBCOBCEBYgBgBiOmBBGEBDTB1DKKHCC+THHPEEhB9E9ElQiEiEB6mB6mB2MDBjJwvBwvBBBBoCBBsGBBCumBumBOIIBCBCFBCCBDmYmYBKBD2CBCKBEKBCOBShBB-BlBBCCBDFBCaBCQBqBCBF5UBXKBW-cBhIzTBDpEBhQ9CBzMUBCCCBXBQHBFDB8CBBE7C7CB0E0EBOBhBlBBKxBxBB+BBgBwCBwB5C5CBmFBhuG-BBhoWhBBnDCBmFJB1HhFhFsMPPBzuUzuUBxGxGBIBXiBBCSBCDB0ECCBeBbFBbKBLuBuBBhChCBFBCGBLEBjICBFsBBEIBxCMB0BsBBlHaBltuBDB96D8HBEzNBHWBQQBgDzDB9B1HBLmBBD9BBEQBJBBIdBF8BB2GTBNTBN2CBKYBoE0CBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDjJBDxBByjFjCBtC8BBjWrBBFjDBNOBDOBCOBCkBBLtFB5BZBCBBOrBBFIBIBBPFB7E4eBEQBEMBE5GBHLBFQQBKBF3BBJJBHnBBJdBDLBFBBPIBoB3KBJNBDMBEKBE4BBCFFBOBDLBFJBIyEBCmDBnghYffB+CB", false)),
		Coptic: () => new UnicodeRangeTable(decodeRanges("ifNxkKzDGG", true)),
		Cuneiform: () => new UnicodeRangeTable(decodeRanges("ggoC5cnDuDCEMjG", true)),
		Cypriot: () => new UnicodeRangeTable(decodeRanges("ggiCFBDCCBqBBCBBEDD", false)),
		Cypro_Minoan: () => new UnicodeRangeTable(decodeRanges("w8rCiD", true)),
		Cyrillic: () => new UnicodeRangeTable(decodeRanges("ggBkEBDoFBx6FKBhFtCtCojEfBhie-CBv8VBBhw4B9BBiBAB", false)),
		Deseret: () => new UnicodeRangeTable(decodeRanges("gghCvC", true)),
		Devanagari: () => new UnicodeRangeTable(decodeRanges("goCwCFODZh7nBfhwcJ", true)),
		Dives_Akuru: () => new UnicodeRangeTable(decodeRanges("gomCGBDDDBGBCBBCdBCBBDLBKJB", false)),
		Dogra: () => new UnicodeRangeTable(decodeRanges("ggmC7B", true)),
		Duployan: () => new UnicodeRangeTable(decodeRanges("ggvDqDGMEIIJDD", true)),
		Egyptian_Hieroglyphs: () => new UnicodeRangeTable(decodeRanges("ggsC1iBL68D", true)),
		Elbasan: () => new UnicodeRangeTable(decodeRanges("gohCnB", true)),
		Elymaic: () => new UnicodeRangeTable(decodeRanges("g-jCW", true)),
		Ethiopic: () => new UnicodeRangeTable(decodeRanges("gwEoCBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBDfBEZBnvGWBKGBCGBCGBCGBCGBCGBCGBCGBjpfFBDFBDFBKGBCGBylvCGBCDBCBBCOB", false)),
		Garay: () => new UnicodeRangeTable(decodeRanges("gqjClBEcJB", true)),
		Georgian: () => new UnicodeRangeTable(decodeRanges("glElBBCGGDqBBCDBx8CqBBDCBhiElBBCGG", false)),
		Glagolitic: () => new UnicodeRangeTable(decodeRanges("ggL-Ch9sDGCQDGCBCE", true)),
		Gothic: () => new UnicodeRangeTable(decodeRanges("w5gCa", true)),
		Grantha: () => new UnicodeRangeTable(decodeRanges("g4kCDBCHBDBBDVBCGBCBBCEBDIBDBBDCBDHHGGBDGBEEB", false)),
		Greek: () => new UnicodeRangeTable(decodeRanges("wbDBCCBDDBCFFCCCBBBCCCBSBC+BBPPBnpGEBzBEBFEB1ChKhKBUBDFBDlBBDFBDHBCGCBdBD0BBCOBCNBDFBCSBDCBCIBoJ-xiB-xiB7uVuCBSgj0Bgj0BBkCB", false)),
		Gujarati: () => new UnicodeRangeTable(decodeRanges("h0CCBCIBCCBCVBCGBCBBCEBDJBCCBCCBDQQBCBDLBIGB", false)),
		Gunjala_Gondi: () => new UnicodeRangeTable(decodeRanges("grnCFCBCkBCBCFIJ", true)),
		Gurmukhi: () => new UnicodeRangeTable(decodeRanges("hwCCBCFBFBBDVBCGBCBBCBBCBBDCCBDBFBBDCBEIIBCBCIIBPB", false)),
		Gurung_Khema: () => new UnicodeRangeTable(decodeRanges("go4C5B", true)),
		Han: () => new UnicodeRangeTable(decodeRanges("g0LZBC4CBN1GBwBCCaIBPDBle-tGBhC-vUBhoWtLBDpDBpodBBNGBqgkB-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIB", false)),
		Hangul: () => new UnicodeRangeTable(decodeRanges("goE-HvxHBiI9CyDeiCei3dckUj9KNWFwBl9JeEFDFDFDC", true)),
		Hanifi_Rohingya: () => new UnicodeRangeTable(decodeRanges("gojCnBJJ", true)),
		Hanunoo: () => new UnicodeRangeTable(decodeRanges("g5FU", true)),
		Hatran: () => new UnicodeRangeTable(decodeRanges("gniCSCBGE", true)),
		Hebrew: () => new UnicodeRangeTable(decodeRanges("xsB2BBJaBFFBpp9BZBCEBCCCBCCBCCBIB", false)),
		Hiragana: () => new UnicodeRangeTable(decodeRanges("hiM1CBHCBi7-C+IBTeeBBBulQAB", false)),
		Imperial_Aramaic: () => new UnicodeRangeTable(decodeRanges("giiCVCI", true)),
		Inherited: () => new UnicodeRangeTable(decodeRanges("gYvDB2IBBlOKBbhXhXBCB8qEtBBDLBlPCBCMBCGBFHHEBBnG-BBtQBBjGgBB65DDBsDBBmrzBPBRNBwejHjH7iEl+uBl+uBBsBBDWBhRCBSHBDGBfDBz6rYvHB", false)),
		Inscriptional_Pahlavi: () => new UnicodeRangeTable(decodeRanges("g7iCSGH", true)),
		Inscriptional_Parthian: () => new UnicodeRangeTable(decodeRanges("g6iCVDH", true)),
		Javanese: () => new UnicodeRangeTable(decodeRanges("gsqBtCDJFB", true)),
		Kaithi: () => new UnicodeRangeTable(decodeRanges("gkkCiCLA", true)),
		Kannada: () => new UnicodeRangeTable(decodeRanges("gkDMCCCWCJCEDICCCDIBGCCDDJCC", true)),
		Katakana: () => new UnicodeRangeTable(decodeRanges("hlM5CBDCBxHPBxGuBBC3CBvgzBJBCsBBzisBDBCGBCBBCgJgJBBBzBPPBCB", false)),
		Kawi: () => new UnicodeRangeTable(decodeRanges("g4nCQCoBEc", true)),
		Kayah_Li: () => new UnicodeRangeTable(decodeRanges("goqBtBCA", true)),
		Kharoshthi: () => new UnicodeRangeTable(decodeRanges("gwiCDCBGHCCCcDCFJII", true)),
		Khitan_Small_Script: () => new UnicodeRangeTable(decodeRanges("k-7C84G84GB0OBqBAB", false)),
		Khmer: () => new UnicodeRangeTable(decodeRanges("g8F9CDJHJnPf", true)),
		Khojki: () => new UnicodeRangeTable(decodeRanges("gwkCRCuB", true)),
		Khudawadi: () => new UnicodeRangeTable(decodeRanges("w1kC6BGJ", true)),
		Kirat_Rai: () => new UnicodeRangeTable(decodeRanges("gq7C5B", true)),
		Lao: () => new UnicodeRangeTable(decodeRanges("h0DBBCCCBDBCXBCCCBVBDEBCCCBFBCJBDDB", false)),
		Latin: () => new UnicodeRangeTable(decodeRanges("hCZBHZBwBQQGWBCeBCgOBoBEB8wGlBBHwBBGDBGMBClCBiC-HByLOORMBuEBBHccSoBB42CfBj1elDBExCBVOBxZqBBCIBCDB38TGB7gBZBHZBmhCFBCpBBCIBm61BeBHFB", false)),
		Lepcha: () => new UnicodeRangeTable(decodeRanges("ggH3BEOEC", true)),
		Limbu: () => new UnicodeRangeTable(decodeRanges("goGeBCLBFLBFEEBKB", false)),
		Linear_A: () => new UnicodeRangeTable(decodeRanges("gwhC2JKVLH", true)),
		Linear_B: () => new UnicodeRangeTable(decodeRanges("gggCLCZCSCBCODNjB6D", true)),
		Lisu: () => new UnicodeRangeTable(decodeRanges("wmpBvBx1eA", true)),
		Lycian: () => new UnicodeRangeTable(decodeRanges("g0gCc", true)),
		Lydian: () => new UnicodeRangeTable(decodeRanges("gpiCZGA", true)),
		Mahajani: () => new UnicodeRangeTable(decodeRanges("wqkCmB", true)),
		Makasar: () => new UnicodeRangeTable(decodeRanges("g3nCY", true)),
		Malayalam: () => new UnicodeRangeTable(decodeRanges("goDMCCCyBCCCFFPDZ", true)),
		Mandaic: () => new UnicodeRangeTable(decodeRanges("giCbDA", true)),
		Manichaean: () => new UnicodeRangeTable(decodeRanges("g2iCmBFL", true)),
		Marchen: () => new UnicodeRangeTable(decodeRanges("wjnCfDVCN", true)),
		Masaram_Gondi: () => new UnicodeRangeTable(decodeRanges("gonCGBCBBCrBBECCBCCBHBJJB", false)),
		Medefaidrin: () => new UnicodeRangeTable(decodeRanges("gy7C6C", true)),
		Meetei_Mayek: () => new UnicodeRangeTable(decodeRanges("g3qBWqGtBDJ", true)),
		Mende_Kikakui: () => new UnicodeRangeTable(decodeRanges("gg6DkGDP", true)),
		Meroitic_Cursive: () => new UnicodeRangeTable(decodeRanges("gtiCXFTDtB", true)),
		Meroitic_Hieroglyphs: () => new UnicodeRangeTable(decodeRanges("gsiCf", true)),
		Miao: () => new UnicodeRangeTable(decodeRanges("g47CqCF4BIQ", true)),
		Modi: () => new UnicodeRangeTable(decodeRanges("gwlCkCMJ", true)),
		Mongolian: () => new UnicodeRangeTable(decodeRanges("ggGBBDCCBSBH4CBIqBB2t-BMB", false)),
		Mro: () => new UnicodeRangeTable(decodeRanges("gy6CeCJFB", true)),
		Multani: () => new UnicodeRangeTable(decodeRanges("g0kCGBCCCBCBCOBCKB", false)),
		Myanmar: () => new UnicodeRangeTable(decodeRanges("ggE-EhqmBeiDfxibT", true)),
		Nabataean: () => new UnicodeRangeTable(decodeRanges("gkiCeJI", true)),
		Nag_Mundari: () => new UnicodeRangeTable(decodeRanges("wm5DpB", true)),
		Nandinagari: () => new UnicodeRangeTable(decodeRanges("gtmCHDtBDK", true)),
		New_Tai_Lue: () => new UnicodeRangeTable(decodeRanges("gsGrBFZHKEB", true)),
		Newa: () => new UnicodeRangeTable(decodeRanges("gglC7CCE", true)),
		Nko: () => new UnicodeRangeTable(decodeRanges("g+B6BDC", true)),
		Nushu: () => new UnicodeRangeTable(decodeRanges("h-7CvsQvsQBqMB", false)),
		Nyiakeng_Puachue_Hmong: () => new UnicodeRangeTable(decodeRanges("go4DsBENDJFB", true)),
		Ogham: () => new UnicodeRangeTable(decodeRanges("g0Fc", true)),
		Ol_Chiki: () => new UnicodeRangeTable(decodeRanges("wiHvB", true)),
		Ol_Onal: () => new UnicodeRangeTable(decodeRanges("wu5DqBFA", true)),
		Old_Hungarian: () => new UnicodeRangeTable(decodeRanges("gkjCyBOyBIF", true)),
		Old_Italic: () => new UnicodeRangeTable(decodeRanges("g4gCjBKC", true)),
		Old_North_Arabian: () => new UnicodeRangeTable(decodeRanges("g0iCf", true)),
		Old_Permic: () => new UnicodeRangeTable(decodeRanges("w6gCqB", true)),
		Old_Persian: () => new UnicodeRangeTable(decodeRanges("g9gCjBFN", true)),
		Old_Sogdian: () => new UnicodeRangeTable(decodeRanges("g4jCnB", true)),
		Old_South_Arabian: () => new UnicodeRangeTable(decodeRanges("gziCf", true)),
		Old_Turkic: () => new UnicodeRangeTable(decodeRanges("ggjCoC", true)),
		Old_Uyghur: () => new UnicodeRangeTable(decodeRanges("w7jCZ", true)),
		Oriya: () => new UnicodeRangeTable(decodeRanges("h4CCCHDBDVCGCBCEDIDBDCICFBCEDR", true)),
		Osage: () => new UnicodeRangeTable(decodeRanges("wlhCjBFjB", true)),
		Osmanya: () => new UnicodeRangeTable(decodeRanges("gkhCdDJ", true)),
		Pahawh_Hmong: () => new UnicodeRangeTable(decodeRanges("g46ClCLJCGCUGS", true)),
		Palmyrene: () => new UnicodeRangeTable(decodeRanges("gjiCf", true)),
		Pau_Cin_Hau: () => new UnicodeRangeTable(decodeRanges("g2mC4B", true)),
		Phags_Pa: () => new UnicodeRangeTable(decodeRanges("giqB3B", true)),
		Phoenician: () => new UnicodeRangeTable(decodeRanges("goiCbEA", true)),
		Psalter_Pahlavi: () => new UnicodeRangeTable(decodeRanges("g8iCRIDNG", true)),
		Rejang: () => new UnicodeRangeTable(decodeRanges("wpqBjBMA", true)),
		Runic: () => new UnicodeRangeTable(decodeRanges("g1FqCEK", true)),
		Samaritan: () => new UnicodeRangeTable(decodeRanges("ggCtBDO", true)),
		Saurashtra: () => new UnicodeRangeTable(decodeRanges("gkqBlCJL", true)),
		Sharada: () => new UnicodeRangeTable(decodeRanges("gskC-ChsCH", true)),
		Shavian: () => new UnicodeRangeTable(decodeRanges("wihCvB", true)),
		Siddham: () => new UnicodeRangeTable(decodeRanges("gslC1BDlB", true)),
		Sidetic: () => new UnicodeRangeTable(decodeRanges("gqiCZ", true)),
		SignWriting: () => new UnicodeRangeTable(decodeRanges("gg2DrUQECO", true)),
		Sinhala: () => new UnicodeRangeTable(decodeRanges("hsDCBCRBEXBCIBCDDBFBEFFBEBCCCBGBHJBDCBt-gCTB", false)),
		Sogdian: () => new UnicodeRangeTable(decodeRanges("w5jCpB", true)),
		Sora_Sompeng: () => new UnicodeRangeTable(decodeRanges("wmkCYIJ", true)),
		Soyombo: () => new UnicodeRangeTable(decodeRanges("wymCyC", true)),
		Sundanese: () => new UnicodeRangeTable(decodeRanges("g8G-BhIH", true)),
		Sunuwar: () => new UnicodeRangeTable(decodeRanges("g+mChBPJ", true)),
		Syloti_Nagri: () => new UnicodeRangeTable(decodeRanges("ggqBsB", true)),
		Syriac: () => new UnicodeRangeTable(decodeRanges("g4BNC7BDCxIK", true)),
		Tagalog: () => new UnicodeRangeTable(decodeRanges("g4FVKA", true)),
		Tagbanwa: () => new UnicodeRangeTable(decodeRanges("g7FMCCCB", true)),
		Tai_Le: () => new UnicodeRangeTable(decodeRanges("wqGdDE", true)),
		Tai_Tham: () => new UnicodeRangeTable(decodeRanges("gxG+BCcDKHJHN", true)),
		Tai_Viet: () => new UnicodeRangeTable(decodeRanges("g0qBiCZE", true)),
		Tai_Yo: () => new UnicodeRangeTable(decodeRanges("g25DeCVJB", true)),
		Takri: () => new UnicodeRangeTable(decodeRanges("g0lC5BHJ", true)),
		Tamil: () => new UnicodeRangeTable(decodeRanges("i8CBBCFBECBCDBEBBCCCBEEBEEBBBELBFEBECBCDBDHHPUBm+kCxBBOAB", false)),
		Tangsa: () => new UnicodeRangeTable(decodeRanges("wz6CuCCJ", true)),
		Tangut: () => new UnicodeRangeTable(decodeRanges("g-7CgBgBB+3GBhQeBiDyDB", false)),
		Telugu: () => new UnicodeRangeTable(decodeRanges("ggDMCCCWCPDICCCDIBCCCBDDDJII", true)),
		Thaana: () => new UnicodeRangeTable(decodeRanges("g8BxB", true)),
		Thai: () => new UnicodeRangeTable(decodeRanges("hwD5BGb", true)),
		Tibetan: () => new UnicodeRangeTable(decodeRanges("g4DnCCjBFmBCjBCOCGFB", true)),
		Tifinagh: () => new UnicodeRangeTable(decodeRanges("wpL3BIBPA", true)),
		Tirhuta: () => new UnicodeRangeTable(decodeRanges("gklCnCJJ", true)),
		Todhri: () => new UnicodeRangeTable(decodeRanges("guhCzB", true)),
		Tolong_Siki: () => new UnicodeRangeTable(decodeRanges("wtnCrBFJ", true)),
		Toto: () => new UnicodeRangeTable(decodeRanges("w04De", true)),
		Tulu_Tigalari: () => new UnicodeRangeTable(decodeRanges("g8kCJBCDDClBBCJBCDDCDBCJBCBBJBB", false)),
		Ugaritic: () => new UnicodeRangeTable(decodeRanges("g8gCdCA", true)),
		Unknown: () => new UnicodeRangeTable(decodeRanges("4bBBHDBICCVuMuMnBBBzBBBE4B4BBGBcDBHKBvI9B9BBmDmDBMB8BBByBBBQddBCCMEBjBEBuHJJBDDBXXICCBBBFBBKBBDBBFHBCDBDGGBaaBEEHDBDBBXIIDGDBCCGDBDBBECBCGBFCCBFBSJBEKKEXXIDDGBBLIEBCCBNBFBBNGBIEEJBBDBBXIIDGGBKKBDDBEEBFBEDBDGGBTTBIBDHHBBBEFFBBBDCCDCBDCBECBNDBGCBEFFBCCBEBCNBWEBOEEYRRBKKEFFBFBDEEDBBFBBLGBXEEYLLGBBKEEFGBDEBEFFBLLELBOEE0BEEHDBRBBbEETCBZKKCBBICBCDBHCCJFBLBBELB7BDBekBBDCCGZZCYYBGGCIILBBFfBpClBlBBCBoBlBlBQOOBjBBnGCCBDBCBB6LFFBIICFFBqBqBFBBiBFFBIICFFBQQ6BFFBkCkCBhBhBBBBbFB3CBBHBB+UCB6CGBXIBZIBVLBOEEDLB-CBBLFBLFBbFB6CGBsBEBnCJBgBNNBCBNDBCCBrBBBGKBtBDBbFBMCB-BBBiCeeBMMBEBLFBPBBvBBBNTBuCnFnFBGB9BCBQCB-BEBsBBBMHBsBEB3QBBHBBnBBBHBBJGCgBBB2BQQPBBHUUBEEKmDmDNBBcOOBBBjBNBiBOBtEDB7UVBMUB14BBB-LEBuBCCBDBCBB5BGBDNBZIBI4BI-DhBBb6C6CBKB3GZBxC3C3CBoDoDBDBsB-C-C3CIBxBuzcuzcBBB4BIB9KTB5FHB+GTB9BCBLFB5BHBnCHBNFB1DKBfCBvCMMBCBiB4B4BBHBPBBLBBoDXBdJBHBBHBBHIBIII9BDB-DBBLFBl9KLBYDByBjoIBvLBBrDlBBILBGEBbGGCGDrUfBrBFB0BUUFDBGoEoEBCC-FCBHBBHBBHBBECBIIIBIBGBBNbbUDDQBBPhBB8DEBEDBuBCB5COOBBBCuBBvBhEBeCByBOBdDBlBIBfEBsBEBfmBmBBCBPpBB-EBBLFBlBDBlBDBpBHB1BKBNQQIDDMQQIDDBBB1BLB4JIBXJBJXBHrBrBKkCBHBBCtBtBDCBCBBYpCpCBGBKvBBUDDBDBiBCBcEBclBB5BDBVBBzBDDBDBJEEeBBEDBLGBKGBhCfBoBDBNIB3BCBeBBcEBbGBFLBIvCBqC2BB0BMB0BGBvBHBLFBnBCBeHBDvGBgBrBrBEBBDPBHHBKgBBvBHBrBVBblBBdTBYIBvCDBlBIBlCJBCBBaGBLFB2BTTBGBoBIBhDVVBJBTwBwBB8BBICCFQQMFB8BEBLFBFJJBDDBXXIDDGLLBDDBEEBCCBEBCEBIBBICBGKBLCCBCCnBLLCBBCFFLDDBGBDcB9CGGBcBpCHBLlFB3BBBnBhBBmCKBLFBOSB7BFBLFBVbBcBBQDBY4FB9BjDB0CLBJBBCBBJDDfDDBNNBHBLlCBJBBvBBBMaBpCHB0CMBqCGBL1CBJ3CBjBNBLFBKuBuBPJBeCBhBBBXPPBnCBIDDtBCBCDDKHBLFBHDDmBDDHGBLFBtBDBL1HBaGBSqBqBBBBe0CBCOBzBMB8clDBwDGGBJBlGryCBkDMB3iBJB88DEBoS41GB7Bl2BB6RGBgBLLBCByCLLBEBfBBHJBnCJBLIIWEBUvNB7BlGB8CEBaBBarBBsCDB6BGBS-BBGKBIIB3mHoBBhBgDB0D8vIBFIIDkJkJBNBCcBEBBCNBFHBtMjoCBsDEBOCBKGBLBBJ76DB+HCB1NFBYOBSOBvBBBYIB1D7BB3HJBoBBBjGUBnC5DBVLBVLB4CIBamEB2CoCoCDBBCBBDBBFNNCIIiCFFBJJIddFGGCCBI1K1KBlJlJB-V-VBNBGQQBuiBBgBFBH0GBISSBIIDGGBDB-BgBBCvDBuBCBPBBLDBD-JBgBQB7BEBCvOBrB1GBsBDBC-FBgBXXBGBD-GBIFFDQQmGBBRoBBtCDBLDBDwYBlCrCB+BhGBFccDCCBCCLFFCCCBEBCDBCECEDDCBBCICDCCBFFIKFCLLSEBEGGSzBBDtIBtBDBlDLBQBBQQQmBJBvF3BBeMBtBDBKGBDNBH5EB6eCBSCBOCB7GFBNDBCOBNDB5BHBLFBpBHBfBBNDBDNBKmBB5KHBPBBOCBMCB6BCCBCBRBBNDBLGB0EoDoDBjgBBh3pBfB-oEBBv0FBBypHOBvThtCB-QhvBBs6EEBrpIm8yVBCdBhD-DBxHvw-FB", false)),
		Vai: () => new UnicodeRangeTable(decodeRanges("gopBrJ", true)),
		Vithkuqi: () => new UnicodeRangeTable(decodeRanges("wrhCKCOCGCBCKCOCGCB", true)),
		Wancho: () => new UnicodeRangeTable(decodeRanges("g24D5BGA", true)),
		Warang_Citi: () => new UnicodeRangeTable(decodeRanges("glmCyCNA", true)),
		Yezidi: () => new UnicodeRangeTable(decodeRanges("g0jCpBCCDB", true)),
		Yi: () => new UnicodeRangeTable(decodeRanges("ggoBskBE2B", true)),
		Zanabazar_Square: () => new UnicodeRangeTable(decodeRanges("gwmCnC", true))
	});
	static FOLD_CATEGORIES = new LazyMap({
		L: () => new UnicodeRangeTable(decodeRanges("laA", true)),
		LC: () => new UnicodeRangeTable(decodeRanges("laA", true)),
		Ll: () => new UnicodeRangeTable(decodeRanges("hCZBmDWBCGBiBuBCEECDOCDuBCBECEBBCCCBCCBBBDDBCBBCCBEBBCBBCECBCCDCCBCCBBBCCCBEEIBBCBBCBBCOCDQCDBBCCCBBBC4BCIBBCBBDCCBCBCGC3HrBrBCEEJHHCCBCCCBCCBPBCIBkBJJCUCGDDCBBDyBBxBgBCK2BCBMCD+CCDlBBq6ClBBCGGzW1CB0kCHHBpBBDCBhK0ECKgDCKHBJFBLHBJHBJFBMGCJHBZHBJHBJHBJEBMEBMDBNEBMEBqJEEBHHxC9zC9zCBuBBxBCCBBBDGCBCBCDDJCBCgDCJCCFuqeuqeCqBCUaCoEMCE8BCLECBICFCCDCCEUCBDBCEBCOCBCBCCCBQCZs5Vs5VBYBmmBnBBpEjBB9EKBCOBCGBCBBr3ByBB+EVB75CfBhsVfBhCYBoyehBB", false)),
		Lt: () => new UnicodeRangeTable(decodeRanges("kOCCBCCBCClBCCtsHHBJHBJHBMQQwBAB", false)),
		Lu: () => new UnicodeRangeTable(decodeRanges("hDZB7BqBqBBWBCHBCuBCEECDOCDsBCDECBBBDCCDEEGDDECBDDDCCCDFFDEECDDECCGBBCBBCBBCOCBSCDBBCEECkBCEQCJDDBCCFICBEBCBBCCCBEEBCCBCBCEBDCCBDDIDDCBBEFBGLLBnFnFsBCCEEEBBBvBDBCdBCBBECBCWCBDBCGD1BvBBCgBCK0BCDMCBgDCyBlBBq6CqBBDCB5XFBjkCIBCvHvHERRzD0ECGGGC8CCBHBJFBLHBJHBJFBMGCJHBJNBzBBBNSSBPPBEEpL2B2Bs1CvBBCEEBGCHDDLiDCJCCFNNBkBBCGG0oesBCUaCoEMCE8BCLCCDICFFFCBBDSCMOCFCCDOCb9a9advCBi8UZBumBnBBpEjBB8EKBCOBCGBCBBk4ByBB+DVB75CfBhsVfB8BYBvyehBB", false)),
		M: () => new UnicodeRangeTable(decodeRanges("5cgBgBlgHAB", false)),
		Mn: () => new UnicodeRangeTable(decodeRanges("5cgBgBlgHAB", false)),
		Emoji: () => new UnicodeRangeTable(decodeRanges("8mJA", true)),
		Extended_Pictographic: () => new UnicodeRangeTable(decodeRanges("8mJA", true)),
		Lowercase: () => new UnicodeRangeTable(decodeRanges("hCZBmDWBCGBiBuBCEECDOCDuBCBECEBBCCCBCCBBBDDBCBBCCBEBBCBBCECBCCDCCBCCBBBCCCBEEIBBCBBCBBCOCDQCDBBCCCBBBC4BCIBBCBBDCCBCBCGCiJCCEJJHCCBBBCCCBCCBPBCIBkBJJCUCGDDCBBDyBBxBgBCK2BCBMCD+CCDlBBq6ClBBCGGzW1CB0kCHHBpBBDCBhK0ECKgDCKHBJFBLHBJHBJFBMGCJHBZHBJHBJHBJEBMEBMDBNEBMEBqJEEBHHuBPBUzZzZBYBx5BvBBxBCCBBBDGCBCBCDDJCBCgDCJCCFuqeuqeCqBCUaCoEMCE8BCLECBICFCCDCCEUCBDBCEBCOCBCBCCCBQCZs5Vs5VBYBmmBnBBpEjBB9EKBCOBCGBCBBr3ByBB+EVB75CfBhsVfBhCYBoyehBB", false)),
		Math: () => new UnicodeRangeTable(decodeRanges("ycGDCHHFMMDDDCHHFAB", false)),
		Uppercase: () => new UnicodeRangeTable(decodeRanges("hDZB7BqBqBBWBCHBCuBCEECDOCDsBCDECBBBDCCDEEGDDECBDDDCCCDFFDEECDDECCGBBCBBCBBCOCBSCDBBCEECkBCEQCJDDBCCFICBEBCBBCCCBEEBCCBCBCEBDCCBDDIDDCBBEFBGLLBnFnFsBCCEEEBBBvBDBCdBCBBECBCWCBDBCGD1BvBBCgBCK0BCDMCBgDCyBlBBq6CqBBDCB5XFBjkCIBCvHvHERRzD0ECGGGC8CCBHBJFBLHBJHBJFBMGCJHBJNBzBBBNSSBPPBEEpLiBiBBOBFsasaBYBn6BvBBCEEBGCHDDLiDCJCCFNNBkBBCGG0oesBCUaCoEMCE8BCLCCDICFFFCBBDSCMOCFCCDOCb9a9advCBi8UZBumBnBBpEjBB8EKBCOBCGBCBBk4ByBB+DVB75CfBhsVfB8BYBvyehBB", false))
	});
	static FOLD_SCRIPT = new LazyMap({
		Common: () => new UnicodeRangeTable(decodeRanges("8cgBgB", false)),
		Greek: () => new UnicodeRangeTable(decodeRanges("1FwUwU", false)),
		Inherited: () => new UnicodeRangeTable(decodeRanges("5cgBgBlgHAB", false))
	});
};
/**
* Utilities for dealing with Unicode better than JS does.
*/
var Unicode = class Unicode {
	static MAX_RUNE = 1114111;
	static MAX_ASCII = 127;
	static MAX_LATIN1 = 255;
	static MAX_BMP = 65535;
	static MIN_FOLD = 65;
	static MAX_FOLD = 125251;
	static MIN_HIGH_SURROGATE = 55296;
	static MAX_HIGH_SURROGATE = 56319;
	static MIN_LOW_SURROGATE = 56320;
	static MAX_LOW_SURROGATE = 57343;
	static MIN_SUPPLEMENTARY_CODE_POINT = 65536;
	static is32(ranges, r) {
		let lo = 0;
		let hi = ranges.length;
		while (lo < hi) {
			const m = lo + Math.floor((hi - lo) / 2);
			const rlo = ranges.getLo(m);
			const rhi = ranges.getHi(m);
			if (rlo <= r && r <= rhi) {
				const stride = ranges.getStride(m);
				return (r - rlo) % stride === 0;
			}
			if (r < rlo) hi = m;
			else lo = m + 1;
		}
		return false;
	}
	static is(ranges, r) {
		if (r <= Unicode.MAX_LATIN1) {
			for (let i = 0; i < ranges.length; i++) {
				if (r > ranges.getHi(i)) continue;
				const rlo = ranges.getLo(i);
				if (r < rlo) return false;
				const stride = ranges.getStride(i);
				return (r - rlo) % stride === 0;
			}
			return false;
		}
		return ranges.length > 0 && r >= ranges.getLo(0) && Unicode.is32(ranges, r);
	}
	static isUpper(r) {
		if (r <= Unicode.MAX_LATIN1) {
			const s = String.fromCodePoint(r);
			return s.toUpperCase() === s && s.toLowerCase() !== s;
		}
		return Unicode.is(UnicodeTables.Upper, r);
	}
	static isPrint(r) {
		if (r <= Unicode.MAX_LATIN1) return r >= 32 && r < Unicode.MAX_ASCII || r >= 161 && r !== 173;
		return Unicode.is(UnicodeTables.Print, r);
	}
	static simpleFold(r) {
		if (UnicodeTables.CASE_ORBIT.has(r)) return UnicodeTables.CASE_ORBIT.get(r);
		const l = Codepoint.toLowerCase(r);
		if (l !== r) return l;
		return Codepoint.toUpperCase(r);
	}
	static equalsIgnoreCase(r1, r2) {
		if (r1 === r2) return true;
		if (r1 < 0 || r2 < 0) return false;
		if (r1 <= Unicode.MAX_ASCII && r2 <= Unicode.MAX_ASCII) {
			if (65 <= r1 && r1 <= 90) r1 |= 32;
			if (65 <= r2 && r2 <= 90) r2 |= 32;
			return r1 === r2;
		}
		for (let r = Unicode.simpleFold(r1); r !== r1; r = Unicode.simpleFold(r)) if (r === r2) return true;
		return false;
	}
};
/**
* Size of the precomputed single-byte lookup table.
* Covers standard ASCII and Latin-1 characters for fast-path execution.
*/
var FAST_PATH_TABLE_SIZE = 256;
/**
* Precomputed lookup table for Word Boundary (\b, \B) assertions.
* * By precomputing the boolean results for standard ASCII word ranges
* ('a'-'z', 'A'-'Z', '0'-'9', '_'), we completely eliminate 4 logical
* branches from the NFA's hot execution loop. This prevents costly
* CPU branch mispredictions when scanning large strings.
*/
var WORD_RUNE_TABLE = new Uint8Array(FAST_PATH_TABLE_SIZE);
for (let i = 0; i < FAST_PATH_TABLE_SIZE; i++) WORD_RUNE_TABLE[i] = 97 <= i && i <= 122 || 65 <= i && i <= 90 || 48 <= i && i <= 57 || i === 95 ? 1 : 0;
var cachedNativeEncoder = null;
var cachedNativeDecoder = null;
/**
* Various constants and helper utilities.
*/
var Utils = class Utils {
	static METACHARACTERS = "\\.+*?()|[]{}^$";
	static EMPTY_BEGIN_LINE = 1;
	static EMPTY_END_LINE = 2;
	static EMPTY_BEGIN_TEXT = 4;
	static EMPTY_END_TEXT = 8;
	static EMPTY_WORD_BOUNDARY = 16;
	static EMPTY_NO_WORD_BOUNDARY = 32;
	static EMPTY_ALL = -1;
	static emptyInts() {
		return [];
	}
	static isByteArray(input) {
		return Array.isArray(input) || input instanceof Uint8Array;
	}
	static isalnum(c) {
		return Codepoint.CODES.get("0") <= c && c <= Codepoint.CODES.get("9") || Codepoint.CODES.get("a") <= c && c <= Codepoint.CODES.get("z") || Codepoint.CODES.get("A") <= c && c <= Codepoint.CODES.get("Z");
	}
	static unhex(c) {
		if (Codepoint.CODES.get("0") <= c && c <= Codepoint.CODES.get("9")) return c - Codepoint.CODES.get("0");
		if (Codepoint.CODES.get("a") <= c && c <= Codepoint.CODES.get("f")) return c - Codepoint.CODES.get("a") + 10;
		if (Codepoint.CODES.get("A") <= c && c <= Codepoint.CODES.get("F")) return c - Codepoint.CODES.get("A") + 10;
		return -1;
	}
	static escapeRune(rune) {
		let out = "";
		if (Unicode.isPrint(rune)) {
			if (Utils.METACHARACTERS.indexOf(String.fromCodePoint(rune)) >= 0) out += "\\";
			out += String.fromCodePoint(rune);
		} else switch (rune) {
			case Codepoint.CODES.get("\""):
				out += "\\\"";
				break;
			case Codepoint.CODES.get("\\"):
				out += "\\\\";
				break;
			case Codepoint.CODES.get("	"):
				out += "\\t";
				break;
			case Codepoint.CODES.get("\n"):
				out += "\\n";
				break;
			case Codepoint.CODES.get("\r"):
				out += "\\r";
				break;
			case Codepoint.CODES.get("\b"):
				out += "\\b";
				break;
			case Codepoint.CODES.get("\f"):
				out += "\\f";
				break;
			default: {
				let s = rune.toString(16);
				if (rune < 256) {
					out += "\\x";
					if (s.length === 1) out += "0";
					out += s;
				} else out += `\\x{${s}}`;
				break;
			}
		}
		return out;
	}
	static stringToRunes(str) {
		const string = String(str);
		const runes = [];
		let i = 0;
		while (i < string.length) {
			const cp = string.codePointAt(i);
			runes.push(cp);
			i += cp > Unicode.MAX_BMP ? 2 : 1;
		}
		return runes;
	}
	static runeToString(r) {
		return String.fromCodePoint(r);
	}
	static isWordRune(r) {
		return r < FAST_PATH_TABLE_SIZE ? WORD_RUNE_TABLE[r] === 1 : false;
	}
	static emptyOpContext(r1, r2) {
		let op = 0;
		if (r1 < 0) op |= Utils.EMPTY_BEGIN_TEXT | Utils.EMPTY_BEGIN_LINE;
		if (r1 === 10) op |= Utils.EMPTY_BEGIN_LINE;
		if (r2 < 0) op |= Utils.EMPTY_END_TEXT | Utils.EMPTY_END_LINE;
		if (r2 === 10) op |= Utils.EMPTY_END_LINE;
		if (Utils.isWordRune(r1) !== Utils.isWordRune(r2)) op |= Utils.EMPTY_WORD_BOUNDARY;
		else op |= Utils.EMPTY_NO_WORD_BOUNDARY;
		return op;
	}
	/**
	* Returns a string that quotes all regular expression metacharacters inside the argument text;
	* the returned string is a regular expression matching the literal text. For example,
	* {@code quoteMeta("[foo]").equals("\\[foo\\]")}.
	* @param {string} str
	* @returns {string}
	*/
	static quoteMeta(str) {
		return str.split("").map((s) => {
			if (Utils.METACHARACTERS.indexOf(s) >= 0) return `\\${s}`;
			return s;
		}).join("");
	}
	static charCount(codePoint) {
		return codePoint > Unicode.MAX_BMP ? 2 : 1;
	}
	/**
	* High-speed conversion from TypedArrays to standard JS Arrays.
	* Bypasses the expensive Symbol.iterator overhead of Array.from()
	*/
	static toArray(typedArray) {
		const len = typedArray.length;
		const res = new Array(len);
		for (let i = 0; i < len; i++) res[i] = typedArray[i];
		return res;
	}
	static stringToUtf8ByteArray(str) {
		if (globalThis.TextEncoder) {
			if (!cachedNativeEncoder) cachedNativeEncoder = new TextEncoder();
			return cachedNativeEncoder.encode(str);
		} else {
			let out = [], p = 0;
			for (let i = 0; i < str.length; i++) {
				let c = str.charCodeAt(i);
				if (c < 128) out[p++] = c;
				else if (c < 2048) {
					out[p++] = c >> 6 | 192;
					out[p++] = c & 63 | 128;
				} else if ((c & 64512) === Unicode.MIN_HIGH_SURROGATE && i + 1 < str.length && (str.charCodeAt(i + 1) & 64512) === Unicode.MIN_LOW_SURROGATE) {
					c = Unicode.MIN_SUPPLEMENTARY_CODE_POINT + ((c & 1023) << 10) + (str.charCodeAt(++i) & 1023);
					out[p++] = c >> 18 | 240;
					out[p++] = c >> 12 & 63 | 128;
					out[p++] = c >> 6 & 63 | 128;
					out[p++] = c & 63 | 128;
				} else {
					out[p++] = c >> 12 | 224;
					out[p++] = c >> 6 & 63 | 128;
					out[p++] = c & 63 | 128;
				}
			}
			return out;
		}
	}
	static utf8ByteArrayToString(bytes) {
		if (globalThis.TextDecoder) {
			if (!cachedNativeDecoder) cachedNativeDecoder = new TextDecoder("utf-8");
			const view = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
			return cachedNativeDecoder.decode(view);
		} else {
			let out = [], pos = 0, c = 0;
			while (pos < bytes.length) {
				let c1 = bytes[pos++];
				if (c1 < 128) out[c++] = String.fromCharCode(c1);
				else if (c1 > 191 && c1 < 224) {
					let c2 = bytes[pos++];
					out[c++] = String.fromCharCode((c1 & 31) << 6 | c2 & 63);
				} else if (c1 > 239 && c1 < 365) {
					let c2 = bytes[pos++];
					let c3 = bytes[pos++];
					let c4 = bytes[pos++];
					let u = ((c1 & 7) << 18 | (c2 & 63) << 12 | (c3 & 63) << 6 | c4 & 63) - Unicode.MIN_SUPPLEMENTARY_CODE_POINT;
					out[c++] = String.fromCharCode(Unicode.MIN_HIGH_SURROGATE + (u >> 10));
					out[c++] = String.fromCharCode(Unicode.MIN_LOW_SURROGATE + (u & 1023));
				} else {
					let c2 = bytes[pos++];
					let c3 = bytes[pos++];
					out[c++] = String.fromCharCode((c1 & 15) << 12 | (c2 & 63) << 6 | c3 & 63);
				}
			}
			return out.join("");
		}
	}
};
var createEnum = (values = [], initNum = 0) => {
	const enumObject = Object.create(null);
	for (let i = 0; i < values.length; i++) {
		const val = values[i];
		const keyVal = initNum + i;
		enumObject[val] = keyVal;
		enumObject[keyVal] = val;
	}
	return Object.freeze(enumObject);
};
/**
* Abstract the representations of input text supplied to Matcher.
*/
var MatcherInputBase = class MatcherInputBase {
	static Encoding = createEnum(["UTF_16", "UTF_8"]);
	getEncoding() {
		throw Error("not implemented");
	}
	/** @returns {string} */
	asCharSequence() {
		throw Error("not implemented");
	}
	/** @returns {Uint8Array|number[]} */
	asBytes() {
		throw Error("not implemented");
	}
	/** @returns {number} */
	length() {
		throw Error("not implemented");
	}
	/**
	*
	* @returns {boolean}
	*/
	isUTF8Encoding() {
		return this.getEncoding() === MatcherInputBase.Encoding.UTF_8;
	}
	/**
	*
	* @returns {boolean}
	*/
	isUTF16Encoding() {
		return this.getEncoding() === MatcherInputBase.Encoding.UTF_16;
	}
};
var Utf8MatcherInput = class extends MatcherInputBase {
	/** @param {Uint8Array|number[]|null} bytes */
	constructor(bytes = null) {
		super();
		this.bytes = bytes;
	}
	getEncoding() {
		return MatcherInputBase.Encoding.UTF_8;
	}
	/**
	*
	* @returns {string}
	*/
	asCharSequence() {
		return Utils.utf8ByteArrayToString(this.bytes);
	}
	/**
	*
	* @returns {Uint8Array|number[]|null}
	*/
	asBytes() {
		return this.bytes;
	}
	/**
	*
	* @returns {number}
	*/
	length() {
		return this.bytes.length;
	}
};
var Utf16MatcherInput = class extends MatcherInputBase {
	/** @param {string|null} charSequence */
	constructor(charSequence = null) {
		super();
		this.charSequence = charSequence;
	}
	getEncoding() {
		return MatcherInputBase.Encoding.UTF_16;
	}
	/**
	*
	* @returns {string}
	*/
	asCharSequence() {
		return this.charSequence;
	}
	/**
	*
	* @returns {number[]}
	*/
	asBytes() {
		return Utils.stringToUtf8ByteArray(this.charSequence.toString());
	}
	/**
	*
	* @returns {number}
	*/
	length() {
		return this.charSequence.length;
	}
};
var MatcherInput = class {
	/**
	* Return the MatcherInput for UTF_16 encoding.
	* @returns {Utf16MatcherInput}
	*/
	static utf16(charSequence) {
		return new Utf16MatcherInput(charSequence);
	}
	/**
	* Return the MatcherInput for UTF_8 encoding.
	* @returns {Utf8MatcherInput}
	*/
	static utf8(input) {
		if (Utils.isByteArray(input)) return new Utf8MatcherInput(input);
		return new Utf8MatcherInput(Utils.stringToUtf8ByteArray(input));
	}
};
/**
* MachineInput abstracts different representations of the input text supplied to the Machine. It
* provides one-character lookahead.
*/
var MachineInputBase = class {
	static EOF() {
		return -8;
	}
	constructor() {
		this.end = 0;
	}
	canCheckPrefix() {
		return true;
	}
	endPos() {
		return this.end;
	}
	hasString() {
		return false;
	}
	hasAnyString() {
		return false;
	}
	prefixLength() {
		return 0;
	}
};
var MachineUTF8Input = class extends MachineInputBase {
	constructor(bytes, start = 0, end = bytes.length) {
		super();
		this.bytes = bytes;
		this.start = start;
		this.end = end;
	}
	hasString(prefilter, pos) {
		const target = prefilter.bytes;
		if (target.length === 0) return true;
		const idx = this.indexOf(this.bytes, target, this.start + pos);
		return idx !== -1 && idx <= this.end - target.length;
	}
	hasAnyString(prefilter, pos) {
		if (!prefilter.ac8) return false;
		return prefilter.ac8.searchUTF8(this.bytes, this.start + pos, this.end);
	}
	step(pos) {
		pos += this.start;
		if (pos >= this.end) return MachineInputBase.EOF();
		const c = this.bytes[pos] & 255;
		if (c < 128) return c << 3 | 1;
		else if (c >= 194 && c <= 223 && pos + 1 < this.end) {
			const c1 = this.bytes[pos + 1] & 255;
			if ((c1 & 192) !== 128) return c << 3 | 1;
			return ((c & 31) << 6 | c1 & 63) << 3 | 2;
		} else if (c >= 224 && c <= 239 && pos + 2 < this.end) {
			const c1 = this.bytes[pos + 1] & 255;
			if ((c1 & 192) !== 128) return c << 3 | 1;
			const c2 = this.bytes[pos + 2] & 255;
			if ((c2 & 192) !== 128) return c << 3 | 1;
			return ((c & 15) << 12 | (c1 & 63) << 6 | c2 & 63) << 3 | 3;
		} else if (c >= 240 && c <= 244 && pos + 3 < this.end) {
			const c1 = this.bytes[pos + 1] & 255;
			if ((c1 & 192) !== 128) return c << 3 | 1;
			const c2 = this.bytes[pos + 2] & 255;
			if ((c2 & 192) !== 128) return c << 3 | 1;
			const c3 = this.bytes[pos + 3] & 255;
			if ((c3 & 192) !== 128) return c << 3 | 1;
			return ((c & 7) << 18 | (c1 & 63) << 12 | (c2 & 63) << 6 | c3 & 63) << 3 | 4;
		} else return c << 3 | 1;
	}
	index(re2, pos) {
		pos += this.start;
		const i = this.indexOf(this.bytes, re2.prefixUTF8, pos);
		return i < 0 ? i : i - pos;
	}
	context(pos) {
		pos += this.start;
		let r1 = -1;
		if (pos > this.start && pos <= this.end) {
			let start = pos - 1;
			r1 = this.bytes[start--];
			if (r1 >= 128) {
				let lim = pos - 4;
				if (lim < this.start) lim = this.start;
				while (start >= lim && (this.bytes[start] & 192) === 128) start--;
				if (start < this.start) start = this.start;
				r1 = this.step(start - this.start) >> 3;
			}
		}
		const r2 = pos < this.end ? this.step(pos - this.start) >> 3 : -1;
		return Utils.emptyOpContext(r1, r2);
	}
	indexOf(source, target, fromIndex = 0) {
		let targetLength = target.length;
		if (targetLength === 0) return fromIndex <= this.end ? fromIndex : -1;
		const firstByte = target[0];
		let limit = this.end - targetLength;
		const hasNativeIndexOf = typeof source.indexOf === "function";
		let i = fromIndex;
		while (i <= limit) {
			if (hasNativeIndexOf) {
				i = source.indexOf(firstByte, i);
				if (i === -1 || i > limit) return -1;
			} else {
				while (i <= limit && source[i] !== firstByte) i++;
				if (i > limit) return -1;
			}
			let match = true;
			for (let j = 1; j < targetLength; j++) if (source[i + j] !== target[j]) {
				match = false;
				break;
			}
			if (match) return i;
			i++;
		}
		return -1;
	}
	prefixLength(re2) {
		return re2.prefixUTF8.length;
	}
};
var MachineUTF16Input = class extends MachineInputBase {
	constructor(charSequence, start = 0, end = charSequence.length) {
		super();
		this.charSequence = charSequence;
		this.start = start;
		this.end = end;
	}
	hasString(prefilter, pos) {
		const idx = this.charSequence.indexOf(prefilter.str, this.start + pos);
		return idx !== -1 && idx <= this.end - prefilter.str.length;
	}
	hasAnyString(prefilter, pos) {
		if (!prefilter.ac16) return false;
		return prefilter.ac16.searchUTF16(this.charSequence, this.start + pos, this.end);
	}
	step(pos) {
		pos += this.start;
		if (pos >= this.end) return MachineInputBase.EOF();
		const c1 = this.charSequence.charCodeAt(pos);
		if (c1 < Unicode.MIN_HIGH_SURROGATE || c1 > Unicode.MAX_HIGH_SURROGATE || pos + 1 >= this.end) return c1 << 3 | 1;
		const c2 = this.charSequence.charCodeAt(pos + 1);
		if (c2 >= Unicode.MIN_LOW_SURROGATE && c2 <= Unicode.MAX_LOW_SURROGATE) return (c1 - Unicode.MIN_HIGH_SURROGATE) * 1024 + (c2 - Unicode.MIN_LOW_SURROGATE) + Unicode.MIN_SUPPLEMENTARY_CODE_POINT << 3 | 2;
		return c1 << 3 | 1;
	}
	index(re2, pos) {
		pos += this.start;
		const i = this.charSequence.indexOf(re2.prefix, pos);
		if (i < 0 || i > this.end - re2.prefix.length) return -1;
		return i - pos;
	}
	context(pos) {
		pos += this.start;
		const r1 = pos > this.start && pos <= this.end ? this.charSequence.charCodeAt(pos - 1) : -1;
		const r2 = pos < this.end ? this.charSequence.charCodeAt(pos) : -1;
		return Utils.emptyOpContext(r1, r2);
	}
	prefixLength(re2) {
		return re2.prefix.length;
	}
};
var MachineInput = class {
	static fromUTF8(bytes, start = 0, end = bytes.length) {
		return new MachineUTF8Input(bytes, start, end);
	}
	static fromUTF16(charSequence, start = 0, end = charSequence.length) {
		return new MachineUTF16Input(charSequence, start, end);
	}
};
var RE2JSException = class extends Error {
	/** @param {string} message */
	constructor(message) {
		super(message);
		this.name = "RE2JSException";
	}
};
/**
* An exception thrown by the parser if the pattern was invalid.
*/
var RE2JSSyntaxException = class extends RE2JSException {
	/**
	* @param {string} error
	* @param {string|null} [input=null]
	*/
	constructor(error, input = null) {
		let message = `error parsing regexp: ${error}`;
		if (input) message += `: \`${input}\``;
		super(message);
		this.name = "RE2JSSyntaxException";
		this.message = message;
		/** @type {string} */
		this.error = error;
		/** @type {string|null} */
		this.input = input;
	}
	/**
	* Retrieves the description of the error.
	* @returns {string}
	*/
	getDescription() {
		return this.error;
	}
	/**
	* Retrieves the erroneous regular-expression pattern.
	* @returns {string|null}
	*/
	getPattern() {
		return this.input;
	}
};
/**
* An exception thrown by the compiler
*/
var RE2JSCompileException = class extends RE2JSException {
	/** @param {string} message */
	constructor(message) {
		super(message);
		this.name = "RE2JSCompileException";
	}
};
/**
* An exception thrown by using groups
*/
var RE2JSGroupException = class extends RE2JSException {
	/** @param {string} message */
	constructor(message) {
		super(message);
		this.name = "RE2JSGroupException";
	}
};
/**
* An exception thrown by flags
*/
var RE2JSFlagsException = class extends RE2JSException {
	/** @param {string} message */
	constructor(message) {
		super(message);
		this.name = "RE2JSFlagsException";
	}
};
/**
* An exception thrown for internal engine errors, such as corrupted bytecodes.
*/
var RE2JSInternalException = class extends RE2JSException {
	/** @param {string} message */
	constructor(message) {
		super(message);
		this.name = "RE2JSInternalException";
	}
};
/**
* A stateful iterator that interprets a regex {@code RE2JS} on a specific input.
*
* Conceptually, a Matcher consists of four parts:
* <ol>
* <li>A compiled regular expression {@code RE2JS}, set at construction and fixed for the lifetime
* of the matcher.</li>
*
* <li>The remainder of the input string, set at construction or {@link #reset()} and advanced by
* each match operation such as {@link #find}, {@link #matches} or {@link #lookingAt}.</li>
*
* <li>The current match information, accessible via {@link #start}, {@link #end}, and
* {@link #group}, and updated by each match operation.</li>
*
* <li>The append position, used and advanced by {@link #appendReplacement} and {@link #appendTail}
* if performing a search and replace from the input to an external {@code StringBuffer}.
*
* </ol>
*
*
* @author rsc@google.com (Russ Cox)
*/
var Matcher = class Matcher {
	/**
	* V8 and WebKit have historical hard limits on the number of arguments
	* that can be passed to a function. We cap replacer arguments to prevent
	* Call Stack Overflow (DoS) vulnerabilities on massive ASTs.
	*/
	static MAX_REPLACER_ARGS = 65535;
	/**
	* Quotes '\' and '$' in {@code s}, so that the returned string could be used in
	* {@link #appendReplacement} as a literal replacement of {@code s}.
	*
	* @param {string} str the string to be quoted
	* @param {boolean} [javaMode=false] whether the replacement will be used in javaMode
	* @returns {string} the quoted string
	*/
	static quoteReplacement(str, javaMode = false) {
		if (javaMode) {
			if (str.indexOf("\\") < 0 && str.indexOf("$") < 0) return str;
			return str.split("").map((s) => {
				const c = s.codePointAt(0);
				if (c === Codepoint.CODES.get("\\") || c === Codepoint.CODES.get("$")) return `\\${s}`;
				return s;
			}).join("");
		}
		if (str.indexOf("$") < 0) return str;
		return str.split("").map((s) => {
			if (s.codePointAt(0) === Codepoint.CODES.get("$")) return "$$";
			return s;
		}).join("");
	}
	/**
	*
	* @param {import('./index.js').RE2JS} pattern
	* @param {string|number[]|Uint8Array|MatcherInputBase} input
	*/
	constructor(pattern, input) {
		if (pattern === null) throw new Error("pattern is null");
		/**
		* The pattern being matched.
		* @type {import('./index.js').RE2JS}
		*/
		this.patternInput = pattern;
		const re2 = this.patternInput.re2();
		/** @type {number} */
		this.patternGroupCount = re2.numberOfCapturingGroups();
		/** @type {number[]} */
		this.groups = [];
		/** @type {Record<string, number>} */
		this.namedGroups = re2.namedGroups;
		/** @type {number} */
		this.numberOfInstructions = re2.numberOfInstructions();
		if (input instanceof MatcherInputBase) this.resetMatcherInput(input);
		else if (Utils.isByteArray(input)) this.resetMatcherInput(MatcherInput.utf8(input));
		else this.resetMatcherInput(MatcherInput.utf16(input));
	}
	/**
	* Returns the {@code RE2JS} associated with this {@code Matcher}.
	* @returns {import('./index.js').RE2JS}
	*/
	pattern() {
		return this.patternInput;
	}
	/**
	* Resets the {@code Matcher}, rewinding input and discarding any match information.
	*
	* @returns {Matcher} the {@code Matcher} itself, for chained method calls
	*/
	reset() {
		/** @type {number} */
		this.matcherInputLength = this.matcherInput.length();
		/** @type {number} */
		this.appendPos = 0;
		this.hasMatch = false;
		this.hasGroups = false;
		this.anchorFlag = 0;
		return this;
	}
	/**
	* Resets the {@code Matcher} and changes the input.
	* @param {string|number[]|Uint8Array|MatcherInputBase} input
	* @returns {Matcher} the {@code Matcher} itself, for chained method calls
	*/
	resetMatcherInput(input) {
		if (input === null) throw new Error("input is null");
		if (!(input instanceof MatcherInputBase)) if (Utils.isByteArray(input)) input = MatcherInput.utf8(input);
		else input = MatcherInput.utf16(input);
		this.matcherInput = input;
		this.reset();
		return this;
	}
	/**
	* Returns the start of the named group of the most recent match, or -1 if the group was not
	* matched.
	* @param {string|number} [group=0]
	* @returns {number}
	*/
	start(group = 0) {
		if (typeof group === "string") {
			const groupInt = this.namedGroups[group];
			if (!Number.isFinite(groupInt)) throw new RE2JSGroupException(`group '${group}' not found`);
			group = groupInt;
		}
		this.loadGroup(group);
		return this.groups[2 * group];
	}
	/**
	* Returns the end of the named group of the most recent match, or -1 if the group was not
	* matched.
	* @param {string|number} [group=0]
	* @returns {number}
	*/
	end(group = 0) {
		if (typeof group === "string") {
			const groupInt = this.namedGroups[group];
			if (!Number.isFinite(groupInt)) throw new RE2JSGroupException(`group '${group}' not found`);
			group = groupInt;
		}
		this.loadGroup(group);
		return this.groups[2 * group + 1];
	}
	/**
	* Returns the program size of this pattern.
	*
	* <p>
	* Similar to the C++ implementation, the program size is a very approximate measure of a regexp's
	* "cost". Larger numbers are more expensive than smaller numbers.
	* </p>
	*
	* @returns {number} the program size of this pattern
	*/
	programSize() {
		return this.numberOfInstructions;
	}
	/**
	* Returns the named group of the most recent match, or {@code null} if the group was not matched.
	* @param {string|number} [group=0]
	* @returns {string|null}
	*/
	group(group = 0) {
		if (typeof group === "string") {
			const groupInt = this.namedGroups[group];
			if (!Number.isFinite(groupInt)) throw new RE2JSGroupException(`group '${group}' not found`);
			group = groupInt;
		}
		const start = this.start(group);
		const end = this.end(group);
		if (start < 0 && end < 0) return null;
		return this.substring(start, end);
	}
	/**
	* Returns a dictionary map of all named capturing groups and their matched values.
	* If a group was not matched, its value will be `null`.
	* @returns {Record<string, string|null>}
	*/
	getNamedGroups() {
		if (!this.hasMatch) throw new RE2JSGroupException("perhaps no match attempted");
		const result = Object.create(null);
		for (const name of Object.keys(this.namedGroups)) result[name] = this.group(name);
		return result;
	}
	/**
	* Returns the number of subgroups in this pattern.
	*
	* @returns {number} the number of subgroups; the overall match (group 0) does not count
	*/
	groupCount() {
		return this.patternGroupCount;
	}
	/**
	* Helper: finds subgroup information if needed for group.
	* @param {number} group
	* @private
	*/
	loadGroup(group) {
		if (group < 0 || group > this.patternGroupCount) throw new RE2JSGroupException(`Group index out of bounds: ${group}`);
		if (!this.hasMatch) throw new RE2JSGroupException("perhaps no match attempted");
		if (group === 0 || this.hasGroups) return;
		const end = this.matcherInputLength;
		const res = this.patternInput.re2().matchMachineInput(this.matcherInput, this.groups[0], end, this.anchorFlag, 1 + this.patternGroupCount);
		if (!res[0]) throw new RE2JSGroupException("inconsistency in matching group data");
		this.groups = res[1];
		this.hasGroups = true;
	}
	/**
	* Matches the entire input against the pattern (anchored start and end). If there is a match,
	* {@code matches} sets the match state to describe it.
	*
	* @returns {boolean} true if the entire input matches the pattern
	*/
	matches() {
		return this.genMatch(0, RE2Flags.ANCHOR_BOTH);
	}
	/**
	* Matches the beginning of input against the pattern (anchored start). If there is a match,
	* {@code lookingAt} sets the match state to describe it.
	*
	* @returns {boolean} true if the beginning of the input matches the pattern
	*/
	lookingAt() {
		return this.genMatch(0, RE2Flags.ANCHOR_START);
	}
	/**
	* Matches the input against the pattern (unanchored), starting at a specified position. If there
	* is a match, {@code find} sets the match state to describe it.
	*
	* @param {number|null} [start=null] the input position where the search begins
	* @returns {boolean} if it finds a match
	* @throws IndexOutOfBoundsException if start is not a valid input position
	*/
	find(start = null) {
		if (start !== null) {
			if (start < 0 || start > this.matcherInputLength) throw new RE2JSGroupException(`start index out of bounds: ${start}`);
			this.reset();
			return this.genMatch(start, 0);
		}
		start = 0;
		if (this.hasMatch) {
			start = this.groups[1];
			if (this.groups[0] === this.groups[1]) {
				const r = (this.matcherInput.isUTF16Encoding() ? MachineInput.fromUTF16(this.matcherInput.asCharSequence(), 0, this.matcherInputLength) : MachineInput.fromUTF8(this.matcherInput.asBytes(), 0, this.matcherInputLength)).step(start);
				if (r < 0) start++;
				else start += r & 7;
			}
		}
		return this.genMatch(start, RE2Flags.UNANCHORED);
	}
	/**
	* Helper: does match starting at start, with RE2 anchor flag.
	* @param {number} startByte
	* @param {number} anchor
	* @returns {boolean}
	* @private
	*/
	genMatch(startByte, anchor) {
		const res = this.patternInput.re2().matchMachineInput(this.matcherInput, startByte, this.matcherInputLength, anchor, 1);
		if (!res[0]) {
			this.hasMatch = false;
			return false;
		}
		this.groups = res[1];
		this.hasMatch = true;
		this.hasGroups = this.patternGroupCount === 0;
		this.anchorFlag = anchor;
		return true;
	}
	/**
	* Helper: return substring for [start, end).
	* @param {number} start
	* @param {number} end
	* @returns {string}
	*/
	substring(start, end) {
		if (this.matcherInput.isUTF8Encoding()) return Utils.utf8ByteArrayToString(this.matcherInput.asBytes().slice(start, end));
		return this.matcherInput.asCharSequence().substring(start, end).toString();
	}
	/**
	* Helper for Pattern: return input length.
	* @returns {number}
	*/
	inputLength() {
		return this.matcherInputLength;
	}
	/**
	* Appends to result two strings: the text from the append position up to the beginning of the
	* most recent match, and then the replacement with submatch groups substituted for references of
	* the form {@code $n}, where {@code n} is the group number in decimal. It advances the append
	* position to where the most recent match ended.
	*
	* To embed a literal {@code $}, use \$ (actually {@code "\\$"} with string escapes). The escape
	* is only necessary when {@code $} is followed by a digit, but it is always allowed. Only
	* {@code $} and {@code \} need escaping, but any character can be escaped.
	*
	* The group number {@code n} in {@code $n} is always at least one digit and expands to use more
	* digits as long as the resulting number is a valid group number for this pattern. To cut it off
	* earlier, escape the first digit that should not be used.
	*
	* @param {string} replacement the replacement string
	* @param {boolean} [javaMode=false] activate java mode (different behaviour for capture groups and special characters)
	* @returns {string}
	* @throws IllegalStateException if there was no most recent match
	* @throws IndexOutOfBoundsException if replacement refers to an invalid group
	* @private
	*/
	appendReplacement(replacement, javaMode = false) {
		let res = "";
		const s = this.start();
		const e = this.end();
		if (this.appendPos < s) res += this.substring(this.appendPos, s);
		this.appendPos = e;
		res += javaMode ? this.appendReplacementInternalJava(replacement) : this.appendReplacementInternalJs(replacement);
		return res;
	}
	/**
	* @param {string} replacement - the replacement string
	* @returns {string}
	* @private
	*/
	appendReplacementInternalJava(replacement) {
		let res = "";
		let last = 0;
		const m = replacement.length;
		let i = 0;
		while (i < m) {
			const cCode = replacement.codePointAt(i);
			if (cCode === Codepoint.CODES.get("\\")) {
				if (last < i) res += replacement.substring(last, i);
				i++;
				if (i >= m) throw new RE2JSGroupException("character to be escaped is missing");
				last = i;
				i++;
				continue;
			}
			if (cCode === Codepoint.CODES.get("$")) {
				if (last < i) res += replacement.substring(last, i);
				if (i + 1 >= m) throw new RE2JSGroupException("Illegal group reference: group index is missing");
				const nextCode = replacement.codePointAt(i + 1);
				if (Codepoint.CODES.get("0") <= nextCode && nextCode <= Codepoint.CODES.get("9")) {
					let n = nextCode - Codepoint.CODES.get("0");
					let j = i + 2;
					for (; j < m; j++) {
						const digit = replacement.codePointAt(j);
						if (digit < Codepoint.CODES.get("0") || digit > Codepoint.CODES.get("9") || n * 10 + digit - Codepoint.CODES.get("0") > this.patternGroupCount) break;
						n = n * 10 + digit - Codepoint.CODES.get("0");
					}
					if (n > this.patternGroupCount) throw new RE2JSGroupException(`n > number of groups: ${n}`);
					const group = this.group(n);
					if (group !== null) res += group;
					i = j;
					last = i;
				} else if (nextCode === Codepoint.CODES.get("{")) {
					let j = i + 2;
					while (j < m && replacement.codePointAt(j) !== Codepoint.CODES.get("}")) j++;
					if (j >= m) throw new RE2JSGroupException("named capture group is missing trailing '}'");
					const groupName = replacement.substring(i + 2, j);
					const groupVal = this.group(groupName);
					if (groupVal !== null) res += groupVal;
					i = j + 1;
					last = i;
				} else throw new RE2JSGroupException("Illegal group reference");
				continue;
			}
			i++;
		}
		if (last < m) res += replacement.substring(last, m);
		return res;
	}
	/**
	* @param {string} replacement - the replacement string
	* @returns {string}
	* @private
	*/
	appendReplacementInternalJs(replacement) {
		let res = "";
		let last = 0;
		const m = replacement.length;
		for (let i = 0; i < m - 1; i++) if (replacement.codePointAt(i) === Codepoint.CODES.get("$")) {
			let c = replacement.codePointAt(i + 1);
			if (Codepoint.CODES.get("$") === c) {
				if (last < i) res += replacement.substring(last, i);
				res += "$";
				i++;
				last = i + 1;
				continue;
			} else if (Codepoint.CODES.get("&") === c) {
				if (last < i) res += replacement.substring(last, i);
				const group = this.group(0);
				if (group !== null) res += group;
				else res += "$&";
				i++;
				last = i + 1;
				continue;
			} else if (Codepoint.CODES.get("`") === c) {
				if (last < i) res += replacement.substring(last, i);
				res += this.substring(0, this.start(0));
				i++;
				last = i + 1;
				continue;
			} else if (Codepoint.CODES.get("'") === c) {
				if (last < i) res += replacement.substring(last, i);
				res += this.substring(this.end(0), this.matcherInputLength);
				i++;
				last = i + 1;
				continue;
			} else if (Codepoint.CODES.get("1") <= c && c <= Codepoint.CODES.get("9")) {
				let n = c - Codepoint.CODES.get("0");
				if (last < i) res += replacement.substring(last, i);
				for (i += 2; i < m; i++) {
					c = replacement.codePointAt(i);
					if (c < Codepoint.CODES.get("0") || c > Codepoint.CODES.get("9") || n * 10 + c - Codepoint.CODES.get("0") > this.patternGroupCount) break;
					n = n * 10 + c - Codepoint.CODES.get("0");
				}
				if (n > this.patternGroupCount) {
					res += `$${n}`;
					last = i;
					i--;
					continue;
				}
				const group = this.group(n);
				if (group !== null) res += group;
				last = i;
				i--;
				continue;
			} else if (c === Codepoint.CODES.get("<")) {
				if (last < i) res += replacement.substring(last, i);
				i++;
				let j = i + 1;
				while (j < replacement.length && replacement.codePointAt(j) !== Codepoint.CODES.get(">") && replacement.codePointAt(j) !== Codepoint.CODES.get(" ")) j++;
				if (j === replacement.length || replacement.codePointAt(j) !== Codepoint.CODES.get(">")) {
					res += replacement.substring(i - 1, j + 1);
					last = j + 1;
					i = j;
					continue;
				}
				const groupName = replacement.substring(i + 1, j);
				if (Object.prototype.hasOwnProperty.call(this.namedGroups, groupName)) {
					const groupVal = this.group(groupName);
					if (groupVal !== null) res += groupVal;
				} else res += `$<${groupName}>`;
				last = j + 1;
				i = j;
				continue;
			}
		}
		if (last < m) res += replacement.substring(last, m);
		return res;
	}
	/**
	* Return the substring of the input from the append position to the end of the
	* input.
	* @returns {string}
	*/
	appendTail() {
		return this.substring(this.appendPos, this.matcherInputLength);
	}
	/**
	* Returns the input with all matches replaced by {@code replacement}, interpreted as for
	* {@code appendReplacement}.
	*
	* @param {string|((...args: any[]) => string)} replacement - the replacement string or a replacer function
	* @param {boolean} [javaMode=false] - activate java mode (different behaviour for capture groups and special characters)
	* @returns {string} the input string with the matches replaced
	* @throws IndexOutOfBoundsException if replacement refers to an invalid group and javaMode is true
	*/
	replaceAll(replacement, javaMode = false) {
		return this.replace(replacement, true, javaMode);
	}
	/**
	* Returns the input with the first match replaced by {@code replacement}, interpreted as for
	* {@code appendReplacement}.
	*
	* @param {string|((...args: any[]) => string)} replacement - the replacement string or a replacer function
	* @param {boolean} [javaMode=false] - activate java mode (different behaviour for capture groups and special characters)
	* @returns {string} the input string with the first match replaced
	* @throws IndexOutOfBoundsException if replacement refers to an invalid group and javaMode is true
	*/
	replaceFirst(replacement, javaMode = false) {
		return this.replace(replacement, false, javaMode);
	}
	/**
	* Helper: replaceAll/replaceFirst hybrid.
	* @param {string|((...args: any[]) => string)} replacement - the replacement string or a replacer function
	* @param {boolean} [all=true] - replace all matches
	* @param {boolean} [javaMode=false] - activate java mode (different behaviour for capture groups and special characters)
	* @returns {string}
	* @private
	*/
	replace(replacement, all = true, javaMode = false) {
		let res = "";
		this.reset();
		const isFunc = typeof replacement === "function";
		const hasNamedGroups = Object.keys(this.namedGroups).length > 0;
		let originalInput = null;
		if (isFunc) {
			if (this.groupCount() >= Matcher.MAX_REPLACER_ARGS) throw new RE2JSGroupException("Too many capture groups to safely invoke replacer function");
			originalInput = this.matcherInput.isUTF8Encoding() ? this.matcherInput.asBytes() : this.matcherInput.asCharSequence();
		}
		while (this.find()) {
			res += isFunc ? this.appendReplacementFunc(replacement, hasNamedGroups, originalInput) : this.appendReplacement(replacement, javaMode);
			if (!all) break;
		}
		res += this.appendTail();
		return res;
	}
	/**
	* Evaluates a replacer function for the current match and appends the result,
	* along with any un-matched preceding text, advancing the append position.
	* @param {Function} replacer - the replacer function
	* @param {boolean} hasNamedGroups - cached flag if pattern has named groups
	* @param {string|Uint8Array|number[]} originalInput - the cached original input reference
	* @returns {string} the evaluated string to append
	* @private
	*/
	appendReplacementFunc(replacer, hasNamedGroups, originalInput) {
		let res = "";
		const s = this.start();
		const e = this.end();
		if (this.appendPos < s) res += this.substring(this.appendPos, s);
		this.appendPos = e;
		const args = this.buildReplacerArgs(s, hasNamedGroups, originalInput);
		res += String(replacer(...args));
		return res;
	}
	/**
	* Builds the argument array for the replacer function matching the standard
	* JS String.prototype.replace(regex, replacer) signature.
	* @param {number} matchStart - the start index of the match
	* @param {boolean} hasNamedGroups - cached flag if pattern has named groups
	* @param {string|Uint8Array|number[]} originalInput - the cached original input reference
	* @returns {Array} array of arguments
	* @private
	*/
	buildReplacerArgs(matchStart, hasNamedGroups, originalInput) {
		const args = [this.group(0)];
		const numGroups = this.groupCount();
		for (let i = 1; i <= numGroups; i++) {
			const start = this.start(i);
			if (start < 0) args.push(void 0);
			else args.push(this.substring(start, this.end(i)));
		}
		args.push(matchStart);
		args.push(originalInput);
		if (hasNamedGroups) {
			const parsedGroups = this.getNamedGroups();
			for (const key in parsedGroups) if (parsedGroups[key] === null) parsedGroups[key] = void 0;
			args.push(parsedGroups);
		}
		return args;
	}
};
/**
* A single instruction in the regular expression virtual machine.
*
* @see http://swtch.com/~rsc/regexp/regexp2.html
*/
var Inst = class Inst {
	static ALT = 1;
	static ALT_MATCH = 2;
	static CAPTURE = 3;
	static EMPTY_WIDTH = 4;
	static FAIL = 5;
	static MATCH = 6;
	static NOP = 7;
	static RUNE = 8;
	static RUNE1 = 9;
	static RUNE_ANY = 10;
	static RUNE_ANY_NOT_NL = 11;
	static LB_WRITE = 12;
	static LB_CHECK = 13;
	static isRuneOp(op) {
		return Inst.RUNE <= op && op <= Inst.RUNE_ANY_NOT_NL;
	}
	static escapeRunes(runes) {
		let out = "\"";
		for (let rune of runes) out += Utils.escapeRune(rune);
		out += "\"";
		return out;
	}
	constructor(op) {
		this.op = op;
		this.out = 0;
		this.arg = 0;
		this.runes = [];
		/** @type {Uint32Array | number[] | null} */
		this.next = null;
	}
	matchRune(r) {
		if (this.runes.length === 1) {
			const r0 = this.runes[0];
			if ((this.arg & RE2Flags.FOLD_CASE) !== 0) return Unicode.equalsIgnoreCase(r0, r);
			return r === r0;
		}
		const len = this.runes.length;
		if (len === 0) return false;
		if (len === 2 || len === 4 || len === 6 || len === 8) {
			for (let j = 0; j < len; j += 2) {
				if (r < this.runes[j]) return false;
				if (r <= this.runes[j + 1]) return true;
			}
			return false;
		}
		let base = 0;
		let n = len >> 1;
		while (n > 1) {
			const half = n >> 1;
			base += this.runes[base + half << 1] <= r ? half : 0;
			n -= half;
		}
		base += this.runes[base << 1] <= r ? 1 : 0;
		const m = base - 1;
		return m >= 0 && r <= this.runes[m << 1 | 1];
	}
	matchRunePos(r) {
		if (this.runes.length === 1) {
			const r0 = this.runes[0];
			if ((this.arg & RE2Flags.FOLD_CASE) !== 0) return Unicode.equalsIgnoreCase(r0, r) ? 0 : -1;
			return r === r0 ? 0 : -1;
		}
		const len = this.runes.length;
		if (len === 0) return -1;
		if (len === 2 || len === 4 || len === 6 || len === 8) {
			for (let j = 0; j < len; j += 2) {
				if (r < this.runes[j]) return -1;
				if (r <= this.runes[j + 1]) return Math.floor(j / 2);
			}
			return -1;
		}
		let base = 0;
		let n = len >> 1;
		while (n > 1) {
			const half = n >> 1;
			base += this.runes[base + half << 1] <= r ? half : 0;
			n -= half;
		}
		base += this.runes[base << 1] <= r ? 1 : 0;
		const m = base - 1;
		return m >= 0 && r <= this.runes[m << 1 | 1] ? m : -1;
	}
	/**
	*
	* @returns {string}
	*/
	toString() {
		switch (this.op) {
			case Inst.ALT: return `alt -> ${this.out}, ${this.arg}`;
			case Inst.ALT_MATCH: return `altmatch -> ${this.out}, ${this.arg}`;
			case Inst.CAPTURE: return `cap ${this.arg} -> ${this.out}`;
			case Inst.EMPTY_WIDTH: return `empty ${this.arg} -> ${this.out}`;
			case Inst.MATCH: return `match${this.arg !== 0 ? ` ${this.arg}` : ""}`;
			case Inst.FAIL: return "fail";
			case Inst.NOP: return `nop -> ${this.out}`;
			case Inst.LB_WRITE: return `lbwrite ${this.arg} -> ${this.out}`;
			case Inst.LB_CHECK: return `lbcheck ${this.arg} -> ${this.out}`;
			case Inst.RUNE:
				if (this.runes === null) return "rune <null>";
				return [
					"rune ",
					Inst.escapeRunes(this.runes),
					(this.arg & RE2Flags.FOLD_CASE) !== 0 ? "/i" : "",
					" -> ",
					this.out
				].join("");
			case Inst.RUNE1: return `rune1 ${Inst.escapeRunes(this.runes)} -> ${this.out}`;
			case Inst.RUNE_ANY: return `any -> ${this.out}`;
			case Inst.RUNE_ANY_NOT_NL: return `anynotnl -> ${this.out}`;
			default: throw new Error("unhandled case in Inst.toString");
		}
	}
};
var Queue = class {
	constructor(numInst) {
		this.sparse = new Int32Array(numInst);
		this.densePcs = new Int32Array(numInst);
		this.denseCaps = null;
		this.size = 0;
		this.ncap = 0;
	}
	init(ncap) {
		this.ncap = ncap;
		const needed = this.densePcs.length * ncap;
		if (!this.denseCaps || this.denseCaps.length < needed) this.denseCaps = new Int32Array(needed);
	}
	contains(pc) {
		const j = this.sparse[pc];
		return j < this.size && this.densePcs[j] === pc;
	}
	isEmpty() {
		return this.size === 0;
	}
	add(pc) {
		const j = this.size++;
		this.sparse[pc] = j;
		this.densePcs[j] = pc;
		return j;
	}
	clear() {
		this.size = 0;
	}
	toString() {
		let out = "{";
		for (let i = 0; i < this.size; i++) {
			if (i !== 0) out += ", ";
			out += this.densePcs[i];
		}
		out += "}";
		return out;
	}
};
var Machine = class Machine {
	static fromRE2(re2) {
		const m = new Machine();
		m.prog = re2.prog;
		m.re2 = re2;
		m.q0 = new Queue(m.prog.numInst());
		m.q1 = new Queue(m.prog.numInst());
		m.matched = false;
		m.matchcap = new Int32Array(m.prog.numCap < 2 ? 2 : m.prog.numCap);
		m.ncap = 0;
		return m;
	}
	static fromMachine(machine) {
		return Machine.fromRE2(machine.re2);
	}
	constructor() {
		this.prog = null;
		this.re2 = null;
		this.q0 = null;
		this.q1 = null;
		this.matched = false;
		this.matchcap = null;
		this.ncap = 0;
		this.lbTable = null;
	}
	init(ncap) {
		this.ncap = ncap;
		if (ncap > this.matchcap.length) this.matchcap = new Int32Array(ncap).fill(-1);
		else this.matchcap.fill(-1);
		this.q0.init(ncap);
		this.q1.init(ncap);
		if (this.prog.numLb > 0) {
			if (!this.lbTable || this.lbTable.length < this.prog.numLb + 1) this.lbTable = new Int32Array(this.prog.numLb + 1);
			this.lbTable.fill(-1);
		}
	}
	submatches() {
		if (this.ncap === 0) return Utils.emptyInts();
		return Utils.toArray(this.matchcap.subarray(0, this.ncap));
	}
	match(input, pos, anchor) {
		const startCond = this.re2.cond;
		if (startCond === Utils.EMPTY_ALL) return false;
		if ((anchor === RE2Flags.ANCHOR_START || anchor === RE2Flags.ANCHOR_BOTH) && pos !== 0) return false;
		this.matched = false;
		this.matchcap.fill(-1);
		let currentPos = this.prog.numLb > 0 ? 0 : pos;
		let matchStartPos = pos;
		let runq = this.q0;
		let nextq = this.q1;
		let r = input.step(currentPos);
		let rune = r >> 3;
		let width = r & 7;
		let rune1 = -1;
		let width1 = 0;
		if (r !== MachineInputBase.EOF()) {
			r = input.step(currentPos + width);
			rune1 = r >> 3;
			width1 = r & 7;
		}
		let flag;
		if (currentPos === 0) flag = Utils.emptyOpContext(-1, rune);
		else flag = input.context(currentPos);
		while (true) {
			if (runq.isEmpty()) {
				if ((startCond & Utils.EMPTY_BEGIN_TEXT) !== 0 && currentPos !== 0) break;
				if ((anchor === RE2Flags.ANCHOR_START || anchor === RE2Flags.ANCHOR_BOTH) && currentPos !== 0) break;
				if (this.matched) break;
				if (this.prog.numLb === 0 && !(this.re2.prefix.length === 0) && rune1 !== this.re2.prefixRune && input.canCheckPrefix()) {
					const advance = input.index(this.re2, currentPos);
					if (advance < 0) break;
					currentPos += advance;
					r = input.step(currentPos);
					rune = r >> 3;
					width = r & 7;
					r = input.step(currentPos + width);
					rune1 = r >> 3;
					width1 = r & 7;
					flag = input.context(currentPos);
				}
			}
			if (currentPos === 0 && this.prog.numLb > 0) for (let i = 0; i < this.prog.lbStarts.length; i++) this.add(runq, this.prog.lbStarts[i], currentPos, this.matchcap, 0, flag);
			if (!this.matched && (currentPos === 0 || anchor === RE2Flags.UNANCHORED)) {
				if (currentPos >= matchStartPos) {
					if (this.ncap > 0) this.matchcap[0] = currentPos;
					this.add(runq, this.prog.start, currentPos, this.matchcap, 0, flag);
				}
			}
			const nextPos = currentPos + width;
			flag = input.context(nextPos);
			this.step(runq, nextq, currentPos, nextPos, rune, flag, anchor, currentPos === input.endPos());
			if (width === 0) break;
			if (this.ncap === 0 && this.matched) break;
			currentPos += width;
			rune = rune1;
			width = width1;
			if (rune !== -1) {
				r = input.step(currentPos + width);
				rune1 = r >> 3;
				width1 = r & 7;
			}
			const tmpq = runq;
			runq = nextq;
			nextq = tmpq;
		}
		nextq.clear();
		return this.matched;
	}
	matchSet(input, pos, anchor) {
		const startCond = this.re2.cond;
		if (startCond === Utils.EMPTY_ALL) return [];
		if ((anchor === RE2Flags.ANCHOR_START || anchor === RE2Flags.ANCHOR_BOTH) && pos !== 0) return [];
		let currentPos = this.prog.numLb > 0 ? 0 : pos;
		let matchStartPos = pos;
		let runq = this.q0;
		let nextq = this.q1;
		let r = input.step(currentPos);
		let rune = r >> 3;
		let width = r & 7;
		let rune1 = -1;
		let width1 = 0;
		if (r !== MachineInputBase.EOF()) {
			r = input.step(currentPos + width);
			rune1 = r >> 3;
			width1 = r & 7;
		}
		let flag = currentPos === 0 ? Utils.emptyOpContext(-1, rune) : input.context(currentPos);
		const matches = /* @__PURE__ */ new Set();
		while (true) {
			if (runq.isEmpty()) {
				if ((startCond & Utils.EMPTY_BEGIN_TEXT) !== 0 && currentPos !== 0) break;
				if ((anchor === RE2Flags.ANCHOR_START || anchor === RE2Flags.ANCHOR_BOTH) && currentPos !== 0) break;
			}
			if (currentPos === 0 && this.prog.numLb > 0) for (let i = 0; i < this.prog.lbStarts.length; i++) this.add(runq, this.prog.lbStarts[i], currentPos, this.matchcap, 0, flag);
			if (currentPos === 0 || anchor === RE2Flags.UNANCHORED) {
				if (currentPos >= matchStartPos) this.add(runq, this.prog.start, currentPos, this.matchcap, 0, flag);
			}
			const nextPos = currentPos + width;
			flag = input.context(nextPos);
			for (let j = 0; j < runq.size; j++) {
				const pc = runq.densePcs[j];
				const i = this.prog.inst[pc];
				const capOffset = j * this.ncap;
				let add = false;
				switch (i.op) {
					case Inst.MATCH:
						if (anchor === RE2Flags.ANCHOR_BOTH && currentPos !== input.endPos()) break;
						matches.add(i.arg);
						break;
					case Inst.RUNE:
						add = i.matchRune(rune);
						break;
					case Inst.RUNE1:
						add = rune === i.runes[0];
						break;
					case Inst.RUNE_ANY:
						add = true;
						break;
					case Inst.RUNE_ANY_NOT_NL:
						add = rune !== 10;
						break;
					default: continue;
				}
				if (add) this.add(nextq, i.out, nextPos, runq.denseCaps, capOffset, flag);
			}
			runq.clear();
			if (width === 0) break;
			currentPos += width;
			rune = rune1;
			width = width1;
			if (rune !== -1) {
				r = input.step(currentPos + width);
				rune1 = r >> 3;
				width1 = r & 7;
			}
			const tmpq = runq;
			runq = nextq;
			nextq = tmpq;
		}
		nextq.clear();
		return Array.from(matches).sort((a, b) => a - b);
	}
	step(runq, nextq, pos, nextPos, c, nextCond, anchor, atEnd) {
		const longest = this.re2.longest;
		for (let j = 0; j < runq.size; j++) {
			const pc = runq.densePcs[j];
			const capOffset = j * this.ncap;
			if (longest && this.matched && this.ncap > 0 && this.matchcap[0] < runq.denseCaps[capOffset]) continue;
			const i = this.prog.inst[pc];
			let add = false;
			switch (i.op) {
				case Inst.MATCH:
					if (anchor === RE2Flags.ANCHOR_BOTH && !atEnd) break;
					if (this.ncap > 0 && (!longest || !this.matched || this.matchcap[1] < pos)) {
						runq.denseCaps[capOffset + 1] = pos;
						for (let k = 0; k < this.ncap; k++) this.matchcap[k] = runq.denseCaps[capOffset + k];
					}
					if (!longest) runq.size = 0;
					this.matched = true;
					break;
				case Inst.RUNE:
					add = i.matchRune(c);
					break;
				case Inst.RUNE1:
					add = c === i.runes[0];
					break;
				case Inst.RUNE_ANY:
					add = true;
					break;
				case Inst.RUNE_ANY_NOT_NL:
					add = c !== 10;
					break;
				default: continue;
			}
			if (add) this.add(nextq, i.out, nextPos, runq.denseCaps, capOffset, nextCond);
		}
		runq.clear();
	}
	add(q, pc, pos, capArray, capOffset, cond) {
		while (true) {
			if (pc === 0) return;
			if (q.contains(pc)) return;
			const d = q.add(pc);
			const inst = this.prog.inst[pc];
			switch (inst.op) {
				case Inst.FAIL: return;
				case Inst.ALT:
				case Inst.ALT_MATCH:
					this.add(q, inst.out, pos, capArray, capOffset, cond);
					pc = inst.arg;
					continue;
				case Inst.EMPTY_WIDTH:
					if ((inst.arg & ~cond) === 0) {
						pc = inst.out;
						continue;
					}
					return;
				case Inst.NOP:
					pc = inst.out;
					continue;
				case Inst.CAPTURE: if (inst.arg < this.ncap) {
					const opos = capArray[capOffset + inst.arg];
					capArray[capOffset + inst.arg] = pos;
					this.add(q, inst.out, pos, capArray, capOffset, cond);
					capArray[capOffset + inst.arg] = opos;
					return;
				} else {
					pc = inst.out;
					continue;
				}
				case Inst.LB_WRITE:
					this.lbTable[Math.abs(inst.arg)] = pos;
					pc = inst.out;
					continue;
				case Inst.LB_CHECK:
					if (inst.arg > 0) {
						if (this.lbTable[inst.arg] === pos) {
							pc = inst.out;
							continue;
						}
					} else if (this.lbTable[-inst.arg] !== pos) {
						pc = inst.out;
						continue;
					}
					return;
				case Inst.MATCH:
				case Inst.RUNE:
				case Inst.RUNE1:
				case Inst.RUNE_ANY:
				case Inst.RUNE_ANY_NOT_NL:
					if (this.ncap > 0) {
						const destOffset = d * this.ncap;
						for (let c = 0; c < this.ncap; c++) q.denseCaps[destOffset + c] = capArray[capOffset + c];
					}
					return;
				default: throw new RE2JSInternalException("unhandled");
			}
		}
	}
};
var hashPCs = (pcs) => {
	let h = -2128831035;
	for (let i = 0; i < pcs.length; i++) {
		h ^= pcs[i];
		h = Math.imul(h, 16777619);
	}
	return h;
};
var arraysEqual = (a, b) => {
	if (a.length !== b.length) return false;
	for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
	return true;
};
var DFAState = class {
	constructor(nfaStates, isMatch, matchIDs = []) {
		this.nfaStates = nfaStates;
		this.isMatch = isMatch;
		this.matchIDs = matchIDs;
		this.nextLatin1 = new Array(Unicode.MAX_LATIN1 + 1).fill(null);
		this.nextLatin1Anchored = new Array(Unicode.MAX_LATIN1 + 1).fill(null);
		this.transKeys = [];
		this.transVals = [];
		this.lastSeen = 0;
	}
};
var DFA = class DFA {
	static MAX_CACHE_CLEARS = 5;
	static STATE_MEMORY_ESTIMATE = 838;
	constructor(prog, maxMem = 8388608) {
		this.prog = prog;
		this.stateCache = /* @__PURE__ */ new Map();
		this.stateCount = 0;
		this.startState = null;
		this.stateLimit = Math.max(1, Math.floor(maxMem / DFA.STATE_MEMORY_ESTIMATE));
		this.cacheClears = 0;
		this.failed = false;
		this.clock = 0;
	}
	computeClosure(pcs) {
		const closure = /* @__PURE__ */ new Set();
		const stack = [...pcs];
		let isMatch = false;
		const matchIDs = [];
		while (stack.length > 0) {
			const pc = stack.pop();
			if (closure.has(pc)) continue;
			closure.add(pc);
			const inst = this.prog.getInst(pc);
			switch (inst.op) {
				case Inst.MATCH:
					isMatch = true;
					if (!matchIDs.includes(inst.arg)) matchIDs.push(inst.arg);
					break;
				case Inst.ALT:
				case Inst.ALT_MATCH:
					stack.push(inst.out);
					stack.push(inst.arg);
					break;
				case Inst.NOP:
				case Inst.CAPTURE:
					stack.push(inst.out);
					break;
				case Inst.EMPTY_WIDTH:
				case Inst.LB_WRITE:
				case Inst.LB_CHECK: return null;
			}
		}
		const sortedPCs = Int32Array.from(closure).sort();
		matchIDs.sort((a, b) => a - b);
		return {
			pcs: sortedPCs,
			isMatch,
			matchIDs
		};
	}
	getState(pcs) {
		const closureResult = this.computeClosure(pcs);
		if (!closureResult) return null;
		const sortedPCs = closureResult.pcs;
		const hash = hashPCs(sortedPCs);
		let bucket = this.stateCache.get(hash);
		if (bucket) for (let i = 0; i < bucket.length; i++) {
			const state = bucket[i];
			if (arraysEqual(state.nfaStates, sortedPCs)) {
				state.lastSeen = ++this.clock;
				return state;
			}
		}
		else {
			bucket = [];
			this.stateCache.set(hash, bucket);
		}
		if (this.failed) return null;
		if (this.stateCount >= this.stateLimit) {
			this.cacheClears++;
			if (this.cacheClears >= DFA.MAX_CACHE_CLEARS) {
				this.failed = true;
				this.stateCache.clear();
				this.stateCount = 0;
				this.startState = null;
				return null;
			}
			this.evictCache();
			bucket = this.stateCache.get(hash);
			if (!bucket) {
				bucket = [];
				this.stateCache.set(hash, bucket);
			}
		}
		const state = new DFAState(sortedPCs, closureResult.isMatch, closureResult.matchIDs);
		state.lastSeen = ++this.clock;
		bucket.push(state);
		this.stateCount++;
		return state;
	}
	evictCache() {
		const allStates = [];
		for (const bucket of this.stateCache.values()) for (let i = 0; i < bucket.length; i++) allStates.push(bucket[i]);
		allStates.sort((a, b) => a.lastSeen - b.lastSeen);
		const keepCount = Math.max(1, Math.floor(this.stateLimit / 2));
		const startIndex = allStates.length - keepCount;
		const survivorsArray = allStates.slice(startIndex);
		const survivors = new Set(survivorsArray);
		this.stateCache.clear();
		this.stateCount = 0;
		for (let i = 0; i < survivorsArray.length; i++) {
			const state = survivorsArray[i];
			state.nextLatin1.fill(null);
			state.nextLatin1Anchored.fill(null);
			state.transKeys.length = 0;
			state.transVals.length = 0;
			const hash = hashPCs(state.nfaStates);
			let bucket = this.stateCache.get(hash);
			if (!bucket) {
				bucket = [];
				this.stateCache.set(hash, bucket);
			}
			bucket.push(state);
			this.stateCount++;
		}
		if (this.startState && !survivors.has(this.startState)) this.startState = null;
	}
	step(state, charCode, anchor) {
		if (charCode <= Unicode.MAX_LATIN1) if (anchor === RE2Flags.UNANCHORED) {
			const next = state.nextLatin1[charCode];
			if (next !== null) return next;
		} else {
			const next = state.nextLatin1Anchored[charCode];
			if (next !== null) return next;
		}
		else {
			const key = charCode + (anchor === RE2Flags.UNANCHORED ? 0 : Unicode.MAX_RUNE + 1);
			const keys = state.transKeys;
			const len = keys.length;
			for (let i = 0; i < len; i++) if (keys[i] === key) return state.transVals[i];
		}
		const nextPCs = [];
		for (let i = 0; i < state.nfaStates.length; i++) {
			const pc = state.nfaStates[i];
			const inst = this.prog.getInst(pc);
			if (Inst.isRuneOp(inst.op) && inst.matchRune(charCode)) nextPCs.push(inst.out);
		}
		if (anchor === RE2Flags.UNANCHORED) nextPCs.push(this.prog.start);
		const nextState = this.getState(nextPCs);
		if (charCode <= Unicode.MAX_LATIN1) if (anchor === RE2Flags.UNANCHORED) state.nextLatin1[charCode] = nextState;
		else state.nextLatin1Anchored[charCode] = nextState;
		else {
			const key = charCode + (anchor === RE2Flags.UNANCHORED ? 0 : Unicode.MAX_RUNE + 1);
			state.transKeys.push(key);
			state.transVals.push(nextState);
		}
		return nextState;
	}
	match(input, pos, anchor) {
		if ((anchor === RE2Flags.ANCHOR_START || anchor === RE2Flags.ANCHOR_BOTH) && pos !== 0) return false;
		if (!this.startState) {
			this.startState = this.getState([this.prog.start]);
			if (!this.startState) return null;
		}
		let endPos = input.endPos();
		let currentState = this.startState;
		if (currentState.isMatch) if (anchor === RE2Flags.ANCHOR_BOTH) {
			if (pos === endPos) return true;
		} else return true;
		let i = pos;
		while (i < endPos) {
			const r = input.step(i);
			const rune = r >> 3;
			const width = r & 7;
			if (width === 0) break;
			currentState = anchor === RE2Flags.UNANCHORED && rune <= Unicode.MAX_LATIN1 && currentState.nextLatin1[rune] || this.step(currentState, rune, anchor);
			if (currentState === null) return null;
			currentState.lastSeen = ++this.clock;
			if (currentState.isMatch) if (anchor === RE2Flags.ANCHOR_BOTH) {
				if (i + width === endPos) return true;
			} else return true;
			if (currentState.nfaStates.length === 0) {
				if (anchor !== RE2Flags.UNANCHORED) return false;
			}
			i += width;
		}
		return false;
	}
	matchSet(input, pos, anchor) {
		if ((anchor === RE2Flags.ANCHOR_START || anchor === RE2Flags.ANCHOR_BOTH) && pos !== 0) return [];
		if (!this.startState) {
			this.startState = this.getState([this.prog.start]);
			if (!this.startState) return null;
		}
		let endPos = input.endPos();
		let currentState = this.startState;
		const matches = /* @__PURE__ */ new Set();
		const checkMatch = (state, currentPos) => {
			if (state.isMatch) if (anchor === RE2Flags.ANCHOR_BOTH) {
				if (currentPos === endPos) state.matchIDs.forEach((id) => matches.add(id));
			} else state.matchIDs.forEach((id) => matches.add(id));
		};
		checkMatch(currentState, pos);
		let i = pos;
		while (i < endPos) {
			const r = input.step(i);
			const rune = r >> 3;
			const width = r & 7;
			if (width === 0) break;
			currentState = anchor === RE2Flags.UNANCHORED && rune <= Unicode.MAX_LATIN1 && currentState.nextLatin1[rune] || this.step(currentState, rune, anchor);
			if (currentState === null) return null;
			currentState.lastSeen = ++this.clock;
			i += width;
			checkMatch(currentState, i);
			if (currentState.nfaStates.length === 0) {
				if (anchor !== RE2Flags.UNANCHORED) break;
			}
		}
		return Array.from(matches).sort((a, b) => a - b);
	}
};
var VISITED_BITS = 32;
var MAX_BACKTRACK_PROG = 500;
var INITIAL_JOB_CAPACITY = 256;
var MAX_BACKTRACK_VECTOR = 262144;
var BitState = class {
	constructor() {
		this.end = 0;
		this.cap = /* @__PURE__ */ new Int32Array(0);
		this.matchcap = /* @__PURE__ */ new Int32Array(0);
		this.ncap = 0;
		this.jobPc = new Int32Array(INITIAL_JOB_CAPACITY);
		this.jobArg = new Uint8Array(INITIAL_JOB_CAPACITY);
		this.jobPos = new Int32Array(INITIAL_JOB_CAPACITY);
		this.jobLen = 0;
		this.visited = /* @__PURE__ */ new Uint32Array(0);
	}
	reset(prog, end, ncap) {
		this.end = end;
		this.jobLen = 0;
		this.ncap = ncap;
		const visitedSize = prog.numInst() * (end + 1) + VISITED_BITS - 1 >>> 5;
		if (this.visited.length < visitedSize) this.visited = new Uint32Array(visitedSize);
		else this.visited.fill(0, 0, visitedSize);
		if (this.cap.length < ncap) this.cap = new Int32Array(ncap).fill(-1);
		else this.cap.fill(-1, 0, ncap);
		if (this.matchcap.length < ncap) this.matchcap = new Int32Array(ncap).fill(-1);
		else this.matchcap.fill(-1, 0, ncap);
	}
	shouldVisit(pc, pos) {
		const n = pc * (this.end + 1) + pos;
		const idx = n >>> 5;
		const mask = 1 << (n & 31);
		if ((this.visited[idx] & mask) !== 0) return false;
		this.visited[idx] |= mask;
		return true;
	}
	push(re2, pc, pos, arg) {
		if (re2.prog.getInst(pc).op !== Inst.FAIL && (arg || this.shouldVisit(pc, pos))) {
			if (this.jobLen >= this.jobPc.length) {
				const newSize = this.jobPc.length * 2;
				const newPc = new Int32Array(newSize);
				newPc.set(this.jobPc);
				this.jobPc = newPc;
				const newArg = new Uint8Array(newSize);
				newArg.set(this.jobArg);
				this.jobArg = newArg;
				const newPos = new Int32Array(newSize);
				newPos.set(this.jobPos);
				this.jobPos = newPos;
			}
			this.jobPc[this.jobLen] = pc;
			this.jobArg[this.jobLen] = arg ? 1 : 0;
			this.jobPos[this.jobLen] = pos;
			this.jobLen++;
		}
	}
	tryBacktrack(re2, input, pc, pos, anchor) {
		const longest = re2.longest;
		this.push(re2, pc, pos, false);
		while (this.jobLen > 0) {
			this.jobLen--;
			let currentPc = this.jobPc[this.jobLen];
			let arg = this.jobArg[this.jobLen] === 1;
			let currentPos = this.jobPos[this.jobLen];
			let skipShouldVisit = true;
			while (true) {
				if (!skipShouldVisit) {
					if (!this.shouldVisit(currentPc, currentPos)) break;
				}
				skipShouldVisit = false;
				const inst = re2.prog.getInst(currentPc);
				switch (inst.op) {
					case Inst.FAIL: throw new RE2JSInternalException("unexpected InstFail");
					case Inst.ALT: if (arg) {
						arg = false;
						currentPc = inst.arg;
						continue;
					} else {
						this.push(re2, currentPc, currentPos, true);
						currentPc = inst.out;
						continue;
					}
					case Inst.ALT_MATCH: {
						const outInst = re2.prog.getInst(inst.out);
						if (Inst.isRuneOp(outInst.op)) {
							this.push(re2, inst.arg, currentPos, false);
							currentPc = inst.arg;
							currentPos = this.end;
							continue;
						}
						this.push(re2, inst.out, this.end, false);
						currentPc = inst.out;
						continue;
					}
					case Inst.RUNE: {
						const r = input.step(currentPos);
						if (r === MachineInputBase.EOF()) break;
						if (!inst.matchRune(r >> 3)) break;
						currentPos += r & 7;
						currentPc = inst.out;
						continue;
					}
					case Inst.RUNE1: {
						const r = input.step(currentPos);
						if (r === MachineInputBase.EOF()) break;
						if (r >> 3 !== inst.runes[0]) break;
						currentPos += r & 7;
						currentPc = inst.out;
						continue;
					}
					case Inst.RUNE_ANY_NOT_NL: {
						const r = input.step(currentPos);
						if (r === MachineInputBase.EOF()) break;
						if (r >> 3 === 10) break;
						currentPos += r & 7;
						currentPc = inst.out;
						continue;
					}
					case Inst.RUNE_ANY: {
						const r = input.step(currentPos);
						if (r === MachineInputBase.EOF()) break;
						currentPos += r & 7;
						currentPc = inst.out;
						continue;
					}
					case Inst.CAPTURE: if (arg) {
						this.cap[inst.arg] = currentPos;
						break;
					} else {
						if (inst.arg < this.ncap) {
							this.push(re2, currentPc, this.cap[inst.arg], true);
							this.cap[inst.arg] = currentPos;
						}
						currentPc = inst.out;
						continue;
					}
					case Inst.EMPTY_WIDTH: {
						const flag = input.context(currentPos);
						if ((inst.arg & ~flag) !== 0) break;
						currentPc = inst.out;
						continue;
					}
					case Inst.NOP:
						currentPc = inst.out;
						continue;
					case Inst.MATCH: {
						if (anchor === RE2Flags.ANCHOR_BOTH && currentPos !== this.end) break;
						if (this.ncap === 0) return true;
						if (this.ncap > 1) this.cap[1] = currentPos;
						const old = this.matchcap[1];
						if (old === -1 || longest && currentPos > 0 && currentPos > old) this.matchcap.set(this.cap);
						if (!longest) return true;
						if (currentPos === this.end) return true;
						break;
					}
					case Inst.LB_WRITE:
					case Inst.LB_CHECK: throw new RE2JSInternalException("Backtracker cannot evaluate Lookbehind instructions");
					default: throw new RE2JSInternalException("bad inst");
				}
				break;
			}
		}
		return longest && this.matchcap.length > 1 && this.matchcap[1] >= 0;
	}
};
var bitStatePool = [];
var Backtracker = class Backtracker {
	static shouldBacktrack(prog) {
		return prog.numInst() <= MAX_BACKTRACK_PROG;
	}
	static maxBitStateLen(prog) {
		if (!Backtracker.shouldBacktrack(prog)) return 0;
		return Math.floor(MAX_BACKTRACK_VECTOR / prog.numInst());
	}
	static execute(re2, input, pos, anchor, ncap) {
		const startCond = re2.cond;
		if (startCond === Utils.EMPTY_ALL) return null;
		if ((anchor === RE2Flags.ANCHOR_START || anchor === RE2Flags.ANCHOR_BOTH) && pos !== 0) return null;
		if ((startCond & Utils.EMPTY_BEGIN_TEXT) !== 0 && pos !== 0) return null;
		const b = bitStatePool.length > 0 ? bitStatePool.pop() : new BitState();
		const end = input.endPos();
		b.reset(re2.prog, end, ncap);
		let matched = false;
		if ((startCond & Utils.EMPTY_BEGIN_TEXT) !== 0 || anchor === RE2Flags.ANCHOR_START || anchor === RE2Flags.ANCHOR_BOTH) {
			if (b.ncap > 0) b.cap[0] = pos;
			if (b.tryBacktrack(re2, input, re2.prog.start, pos, anchor)) matched = true;
		} else {
			let width = -1;
			for (; pos <= end && width !== 0; pos += width) {
				if (re2.prefix.length > 0) {
					const advance = input.index(re2, pos);
					if (advance < 0) break;
					pos += advance;
				}
				if (b.ncap > 0) b.cap[0] = pos;
				if (b.tryBacktrack(re2, input, re2.prog.start, pos, anchor)) {
					matched = true;
					break;
				}
				const r = input.step(pos);
				width = r === MachineInputBase.EOF() ? 0 : r & 7;
			}
		}
		if (!matched) {
			bitStatePool.push(b);
			return null;
		}
		const result = ncap === 0 ? [] : Utils.toArray(b.matchcap.subarray(0, ncap));
		bitStatePool.push(b);
		return result;
	}
};
var QueueOnePass = class {
	constructor(size) {
		this.sparse = new Uint32Array(size);
		this.dense = new Uint32Array(size);
		this.size = 0;
		this.nextIndex = 0;
	}
	empty() {
		return this.nextIndex >= this.size;
	}
	next() {
		return this.dense[this.nextIndex++];
	}
	clear() {
		this.size = 0;
		this.nextIndex = 0;
	}
	contains(u) {
		return u < this.sparse.length && this.sparse[u] < this.size && this.dense[this.sparse[u]] === u;
	}
	insert(u) {
		if (!this.contains(u)) this.insertNew(u);
	}
	insertNew(u) {
		if (u >= this.sparse.length) return;
		this.sparse[u] = this.size;
		this.dense[this.size] = u;
		this.size++;
	}
};
var mergeRuneSets = (leftRunes, rightRunes, leftPC, rightPC) => {
	const leftLen = leftRunes.length;
	const rightLen = rightRunes.length;
	let lx = 0, rx = 0;
	const merged = [];
	const next = [];
	let ok = true;
	let ix = -1;
	const extend = (isLeft) => {
		const newArray = isLeft ? leftRunes : rightRunes;
		const low = isLeft ? lx : rx;
		const pc = isLeft ? leftPC : rightPC;
		if (ix > 0 && newArray[low] <= merged[ix]) return false;
		merged.push(newArray[low], newArray[low + 1]);
		if (isLeft) lx += 2;
		else rx += 2;
		ix += 2;
		next.push(pc);
		return true;
	};
	while (lx < leftLen || rx < rightLen) {
		if (rx >= rightLen) ok = extend(true);
		else if (lx >= leftLen) ok = extend(false);
		else if (rightRunes[rx] < leftRunes[lx]) ok = extend(false);
		else ok = extend(true);
		if (!ok) return null;
	}
	return {
		merged,
		next
	};
};
var OnePassProg = class {
	constructor(prog) {
		this.start = prog.start;
		this.numCap = prog.numCap;
		this.inst = new Array(prog.inst.length);
		for (let i = 0; i < prog.inst.length; i++) {
			const orig = prog.inst[i];
			const inst = new Inst(orig.op);
			inst.out = orig.out;
			inst.arg = orig.arg;
			inst.runes = orig.runes ? orig.runes.slice() : [];
			inst.next = null;
			this.inst[i] = inst;
		}
	}
};
var onePassCopy = (prog) => {
	const p = new OnePassProg(prog);
	for (let pc = 0; pc < p.inst.length; pc++) {
		const inst = p.inst[pc];
		if (inst.op !== Inst.ALT && inst.op !== Inst.ALT_MATCH) continue;
		let pAOther = "out";
		let pAAlt = "arg";
		let instAlt = p.inst[inst[pAAlt]];
		if (instAlt.op !== Inst.ALT && instAlt.op !== Inst.ALT_MATCH) {
			pAOther = "arg";
			pAAlt = "out";
			instAlt = p.inst[inst[pAAlt]];
			if (instAlt.op !== Inst.ALT && instAlt.op !== Inst.ALT_MATCH) continue;
		}
		const instOther = p.inst[inst[pAOther]];
		if (instOther.op === Inst.ALT || instOther.op === Inst.ALT_MATCH) continue;
		let pBAlt = "out";
		let pBOther = "arg";
		let patch = false;
		if (instAlt.out === pc) patch = true;
		else if (instAlt.arg === pc) {
			patch = true;
			pBAlt = "arg";
			pBOther = "out";
		}
		if (patch) instAlt[pBAlt] = inst[pAOther];
		if (inst[pAOther] === instAlt[pBAlt]) inst[pAAlt] = instAlt[pBOther];
	}
	return p;
};
var makeOnePass = (p) => {
	if (p.inst.length >= 1e3) return null;
	const instQueue = new QueueOnePass(p.inst.length);
	const visitQueue = new QueueOnePass(p.inst.length);
	const onePassRunes = new Array(p.inst.length);
	const m = new Array(p.inst.length).fill(false);
	const check = (pc) => {
		let ok = true;
		const inst = p.inst[pc];
		if (visitQueue.contains(pc)) return true;
		visitQueue.insert(pc);
		switch (inst.op) {
			case Inst.ALT:
			case Inst.ALT_MATCH: {
				ok = check(inst.out) && check(inst.arg);
				let matchOut = m[inst.out];
				let matchArg = m[inst.arg];
				if (matchOut && matchArg) return false;
				if (matchArg) {
					const tempOut = inst.out;
					inst.out = inst.arg;
					inst.arg = tempOut;
					const tempMatch = matchOut;
					matchOut = matchArg;
					matchArg = tempMatch;
				}
				if (matchOut) {
					m[pc] = true;
					inst.op = Inst.ALT_MATCH;
				}
				const mergeRes = mergeRuneSets(onePassRunes[inst.out] || [], onePassRunes[inst.arg] || [], inst.out, inst.arg);
				if (!mergeRes) return false;
				onePassRunes[pc] = mergeRes.merged;
				inst.next = new Uint32Array(mergeRes.next);
				break;
			}
			case Inst.CAPTURE:
			case Inst.EMPTY_WIDTH:
			case Inst.NOP:
				ok = check(inst.out);
				m[pc] = m[inst.out];
				onePassRunes[pc] = onePassRunes[inst.out] ? onePassRunes[inst.out].slice() : [];
				inst.next = new Uint32Array(Math.floor(onePassRunes[pc].length / 2) + 1).fill(inst.out);
				break;
			case Inst.MATCH:
			case Inst.FAIL:
				m[pc] = inst.op === Inst.MATCH;
				break;
			case Inst.RUNE: {
				m[pc] = false;
				if (inst.next && inst.next.length > 0) break;
				instQueue.insert(inst.out);
				if (!inst.runes || inst.runes.length === 0) {
					onePassRunes[pc] = [];
					inst.next = new Uint32Array([inst.out]);
					break;
				}
				let runes = [];
				if (inst.runes.length === 1 && (inst.arg & RE2Flags.FOLD_CASE) !== 0) {
					const r0 = inst.runes[0];
					runes.push(r0, r0);
					for (let r1 = Unicode.simpleFold(r0); r1 !== r0; r1 = Unicode.simpleFold(r1)) runes.push(r1, r1);
					runes.sort((a, b) => a - b);
				} else for (let j = 0; j < inst.runes.length; j++) runes.push(inst.runes[j]);
				onePassRunes[pc] = runes;
				inst.next = new Uint32Array(Math.floor(runes.length / 2) + 1).fill(inst.out);
				inst.op = Inst.RUNE;
				break;
			}
			case Inst.RUNE1: {
				m[pc] = false;
				if (inst.next && inst.next.length > 0) break;
				instQueue.insert(inst.out);
				let runes = [];
				if ((inst.arg & RE2Flags.FOLD_CASE) !== 0) {
					const r0 = inst.runes[0];
					runes.push(r0, r0);
					for (let r1 = Unicode.simpleFold(r0); r1 !== r0; r1 = Unicode.simpleFold(r1)) runes.push(r1, r1);
					runes.sort((a, b) => a - b);
				} else runes.push(inst.runes[0], inst.runes[0]);
				onePassRunes[pc] = runes;
				inst.next = new Uint32Array(Math.floor(runes.length / 2) + 1).fill(inst.out);
				inst.op = Inst.RUNE;
				break;
			}
			case Inst.RUNE_ANY:
				m[pc] = false;
				if (inst.next && inst.next.length > 0) break;
				instQueue.insert(inst.out);
				onePassRunes[pc] = [0, Unicode.MAX_RUNE];
				inst.next = new Uint32Array([inst.out]);
				break;
			case Inst.RUNE_ANY_NOT_NL:
				m[pc] = false;
				if (inst.next && inst.next.length > 0) break;
				instQueue.insert(inst.out);
				onePassRunes[pc] = [
					0,
					9,
					11,
					Unicode.MAX_RUNE
				];
				inst.next = new Uint32Array(Math.floor(onePassRunes[pc].length / 2) + 1).fill(inst.out);
		}
		return ok;
	};
	instQueue.clear();
	instQueue.insert(p.start);
	while (!instQueue.empty()) {
		visitQueue.clear();
		if (!check(instQueue.next())) return null;
	}
	for (let i = 0; i < p.inst.length; i++) if (onePassRunes[i]) p.inst[i].runes = onePassRunes[i];
	return p;
};
var cleanupOnePass = (p, original) => {
	for (let ix = 0; ix < original.inst.length; ix++) {
		const instOriginal = original.inst[ix];
		switch (instOriginal.op) {
			case Inst.ALT:
			case Inst.ALT_MATCH:
			case Inst.RUNE: break;
			case Inst.CAPTURE:
			case Inst.EMPTY_WIDTH:
			case Inst.NOP:
			case Inst.MATCH:
			case Inst.FAIL:
				p.inst[ix].next = null;
				break;
			case Inst.RUNE1:
			case Inst.RUNE_ANY:
			case Inst.RUNE_ANY_NOT_NL:
				p.inst[ix].next = null;
				p.inst[ix].op = instOriginal.op;
				p.inst[ix].runes = instOriginal.runes ? instOriginal.runes.slice() : [];
		}
	}
};
var OnePass = class OnePass {
	static compile(prog) {
		if (prog.start === 0) return null;
		if (prog.numLb > 0) return null;
		const startInst = prog.inst[prog.start];
		if (startInst.op !== Inst.EMPTY_WIDTH || (startInst.arg & Utils.EMPTY_BEGIN_TEXT) === 0) return null;
		let hasAlt = false;
		for (let i = 0; i < prog.inst.length; i++) if (prog.inst[i].op === Inst.ALT || prog.inst[i].op === Inst.ALT_MATCH) {
			hasAlt = true;
			break;
		}
		for (let i = 0; i < prog.inst.length; i++) {
			const inst = prog.inst[i];
			const opOut = prog.inst[inst.out].op;
			switch (inst.op) {
				case Inst.ALT:
				case Inst.ALT_MATCH:
					if (opOut === Inst.MATCH || prog.inst[inst.arg].op === Inst.MATCH) return null;
					break;
				case Inst.EMPTY_WIDTH:
					if (opOut === Inst.MATCH) {
						if ((inst.arg & Utils.EMPTY_END_TEXT) === Utils.EMPTY_END_TEXT) continue;
						return null;
					}
					break;
				default: if (opOut === Inst.MATCH && hasAlt) return null;
			}
		}
		let p = onePassCopy(prog);
		p = makeOnePass(p);
		if (p !== null) cleanupOnePass(p, prog);
		return p;
	}
	static next(inst, r) {
		const nextIdx = inst.matchRunePos(r);
		if (nextIdx >= 0) return inst.next[nextIdx];
		if (inst.op === Inst.ALT_MATCH) return inst.out;
		return 0;
	}
	static execute(re2, input, pos, anchor, ncap) {
		const onepass = re2.onepass;
		if (!onepass) return null;
		const matchcap = new Int32Array(ncap).fill(-1);
		let matched = false;
		let r = input.step(pos);
		let rune = r >> 3;
		let width = r & 7;
		let r1 = MachineInputBase.EOF();
		let rune1 = -1;
		let width1 = 0;
		if (r !== MachineInputBase.EOF()) {
			r1 = input.step(pos + width);
			if (r1 !== MachineInputBase.EOF()) {
				rune1 = r1 >> 3;
				width1 = r1 & 7;
			}
		}
		let flag = pos === 0 ? Utils.emptyOpContext(-1, rune) : input.context(pos);
		let pc = onepass.start;
		let inst;
		while (true) {
			inst = onepass.inst[pc];
			pc = inst.out;
			switch (inst.op) {
				case Inst.MATCH:
					if (anchor === RE2Flags.ANCHOR_BOTH && pos !== input.endPos()) return null;
					matched = true;
					if (matchcap.length > 0) {
						matchcap[0] = 0;
						matchcap[1] = pos;
					}
					return ncap === 0 ? [] : Utils.toArray(matchcap);
				case Inst.RUNE:
					if (!inst.matchRune(rune)) return null;
					break;
				case Inst.RUNE1:
					if (rune !== inst.runes[0]) return null;
					break;
				case Inst.RUNE_ANY: break;
				case Inst.RUNE_ANY_NOT_NL:
					if (rune === 10) return null;
					break;
				case Inst.ALT:
				case Inst.ALT_MATCH:
					pc = OnePass.next(inst, rune);
					continue;
				case Inst.FAIL: return null;
				case Inst.NOP: continue;
				case Inst.EMPTY_WIDTH:
					if ((inst.arg & ~flag) !== 0) return null;
					continue;
				case Inst.CAPTURE:
					if (inst.arg < matchcap.length) matchcap[inst.arg] = pos;
					continue;
				default: throw new RE2JSInternalException("bad inst");
			}
			if (width === 0) break;
			flag = Utils.emptyOpContext(rune, rune1);
			pos += width;
			rune = rune1;
			width = width1;
			if (rune !== -1) {
				r1 = input.step(pos + width);
				if (r1 !== MachineInputBase.EOF()) {
					rune1 = r1 >> 3;
					width1 = r1 & 7;
				} else {
					rune1 = -1;
					width1 = 0;
				}
			}
		}
		if (!matched) return null;
		return ncap === 0 ? [] : Utils.toArray(matchcap);
	}
};
/**
* Regular expression abstract syntax tree. Produced by parser, used by compiler. NB, this
* corresponds to {@code syntax.regexp} in the Go implementation; Go's {@code regexp} is called
* {@code RE2} in Java.
*/
var Regexp = class Regexp {
	static Op = createEnum([
		"NO_MATCH",
		"EMPTY_MATCH",
		"LITERAL",
		"CHAR_CLASS",
		"ANY_CHAR_NOT_NL",
		"ANY_CHAR",
		"BEGIN_LINE",
		"END_LINE",
		"BEGIN_TEXT",
		"END_TEXT",
		"WORD_BOUNDARY",
		"NO_WORD_BOUNDARY",
		"CAPTURE",
		"STAR",
		"PLUS",
		"QUEST",
		"REPEAT",
		"CONCAT",
		"ALTERNATE",
		"PLB",
		"NLB",
		"LEFT_PAREN",
		"VERTICAL_BAR"
	]);
	static isPseudoOp(op) {
		return op >= Regexp.Op.LEFT_PAREN;
	}
	static emptySubs() {
		return [];
	}
	static quoteIfHyphen(rune) {
		if (rune === Codepoint.CODES.get("-")) return "\\";
		return "";
	}
	static fromRegexp(re) {
		const regex = new Regexp(re.op);
		regex.flags = re.flags;
		regex.subs = re.subs;
		regex.runes = re.runes;
		regex.cap = re.cap;
		regex.min = re.min;
		regex.max = re.max;
		regex.name = re.name;
		regex.namedGroups = re.namedGroups;
		regex.lb = re.lb;
		return regex;
	}
	constructor(op) {
		this.op = op;
		this.flags = 0;
		this.subs = Regexp.emptySubs();
		this.runes = [];
		this.min = 0;
		this.max = 0;
		this.cap = 0;
		this.name = null;
		this.namedGroups = Object.create(null);
		this.lb = 0;
	}
	reinit() {
		this.flags = 0;
		this.subs = Regexp.emptySubs();
		this.runes = [];
		this.cap = 0;
		this.min = 0;
		this.max = 0;
		this.name = null;
		this.namedGroups = Object.create(null);
		this.lb = 0;
	}
	toString() {
		return this.appendTo();
	}
	appendTo() {
		let out = "";
		switch (this.op) {
			case Regexp.Op.NO_MATCH:
				out += "[^\\x00-\\x{10FFFF}]";
				break;
			case Regexp.Op.EMPTY_MATCH:
				out += "(?:)";
				break;
			case Regexp.Op.STAR:
			case Regexp.Op.PLUS:
			case Regexp.Op.QUEST:
			case Regexp.Op.REPEAT: {
				const sub = this.subs[0];
				if (sub.op > Regexp.Op.CAPTURE || sub.op === Regexp.Op.LITERAL && sub.runes.length > 1) out += `(?:${sub.appendTo()})`;
				else out += sub.appendTo();
				switch (this.op) {
					case Regexp.Op.STAR:
						out += "*";
						break;
					case Regexp.Op.PLUS:
						out += "+";
						break;
					case Regexp.Op.QUEST:
						out += "?";
						break;
					case Regexp.Op.REPEAT:
						out += `{${this.min}`;
						if (this.min !== this.max) {
							out += ",";
							if (this.max >= 0) out += this.max;
						}
						out += "}";
				}
				if ((this.flags & RE2Flags.NON_GREEDY) !== 0) out += "?";
				break;
			}
			case Regexp.Op.CONCAT:
				for (let sub of this.subs) if (sub.op === Regexp.Op.ALTERNATE) out += `(?:${sub.appendTo()})`;
				else out += sub.appendTo();
				break;
			case Regexp.Op.ALTERNATE: {
				let sep = "";
				for (let sub of this.subs) {
					out += sep;
					sep = "|";
					out += sub.appendTo();
				}
				break;
			}
			case Regexp.Op.LITERAL:
				if ((this.flags & RE2Flags.FOLD_CASE) !== 0) out += "(?i:";
				for (let rune of this.runes) out += Utils.escapeRune(rune);
				if ((this.flags & RE2Flags.FOLD_CASE) !== 0) out += ")";
				break;
			case Regexp.Op.ANY_CHAR_NOT_NL:
				out += "(?-s:.)";
				break;
			case Regexp.Op.ANY_CHAR:
				out += "(?s:.)";
				break;
			case Regexp.Op.PLB:
				out += `(?<=${this.subs[0].appendTo()})`;
				break;
			case Regexp.Op.NLB:
				out += `(?<!${this.subs[0].appendTo()})`;
				break;
			case Regexp.Op.CAPTURE:
				if (this.name === null || this.name.length === 0) out += "(";
				else out += `(?P<${this.name}>`;
				if (this.subs[0].op !== Regexp.Op.EMPTY_MATCH) out += this.subs[0].appendTo();
				out += ")";
				break;
			case Regexp.Op.BEGIN_TEXT:
				out += "\\A";
				break;
			case Regexp.Op.END_TEXT:
				if ((this.flags & RE2Flags.WAS_DOLLAR) !== 0) out += "(?-m:$)";
				else out += "\\z";
				break;
			case Regexp.Op.BEGIN_LINE:
				out += "^";
				break;
			case Regexp.Op.END_LINE:
				out += "$";
				break;
			case Regexp.Op.WORD_BOUNDARY:
				out += "\\b";
				break;
			case Regexp.Op.NO_WORD_BOUNDARY:
				out += "\\B";
				break;
			case Regexp.Op.CHAR_CLASS:
				if (this.runes.length % 2 !== 0) {
					out += "[invalid char class]";
					break;
				}
				out += "[";
				if (this.runes.length === 0) out += "^\\x00-\\x{10FFFF}";
				else if (this.runes[0] === 0 && this.runes[this.runes.length - 1] === Unicode.MAX_RUNE) {
					out += "^";
					for (let i = 1; i < this.runes.length - 1; i += 2) {
						const lo = this.runes[i] + 1;
						const hi = this.runes[i + 1] - 1;
						out += Regexp.quoteIfHyphen(lo);
						out += Utils.escapeRune(lo);
						if (lo !== hi) {
							out += "-";
							out += Regexp.quoteIfHyphen(hi);
							out += Utils.escapeRune(hi);
						}
					}
				} else for (let i = 0; i < this.runes.length; i += 2) {
					const lo = this.runes[i];
					const hi = this.runes[i + 1];
					out += Regexp.quoteIfHyphen(lo);
					out += Utils.escapeRune(lo);
					if (lo !== hi) {
						out += "-";
						out += Regexp.quoteIfHyphen(hi);
						out += Utils.escapeRune(hi);
					}
				}
				out += "]";
				break;
			default: out += this.op;
		}
		return out;
	}
	maxCap() {
		let m = 0;
		if (this.op === Regexp.Op.CAPTURE) m = this.cap;
		if (this.subs !== null) for (let sub of this.subs) {
			const n = sub.maxCap();
			if (m < n) m = n;
		}
		return m;
	}
	equals(that) {
		if (!(that !== null && that instanceof Regexp)) return false;
		if (this.op !== that.op) return false;
		switch (this.op) {
			case Regexp.Op.END_TEXT:
				if ((this.flags & RE2Flags.WAS_DOLLAR) !== (that.flags & RE2Flags.WAS_DOLLAR)) return false;
				break;
			case Regexp.Op.LITERAL:
			case Regexp.Op.CHAR_CLASS:
				if (this.runes === null && that.runes === null) break;
				if (this.runes === null || that.runes === null) return false;
				if (this.runes.length !== that.runes.length) return false;
				for (let i = 0; i < this.runes.length; i++) if (this.runes[i] !== that.runes[i]) return false;
				break;
			case Regexp.Op.ALTERNATE:
			case Regexp.Op.CONCAT:
				if (this.subs.length !== that.subs.length) return false;
				for (let i = 0; i < this.subs.length; ++i) if (!this.subs[i].equals(that.subs[i])) return false;
				break;
			case Regexp.Op.STAR:
			case Regexp.Op.PLUS:
			case Regexp.Op.QUEST:
				if ((this.flags & RE2Flags.NON_GREEDY) !== (that.flags & RE2Flags.NON_GREEDY) || !this.subs[0].equals(that.subs[0])) return false;
				break;
			case Regexp.Op.REPEAT:
				if ((this.flags & RE2Flags.NON_GREEDY) !== (that.flags & RE2Flags.NON_GREEDY) || this.min !== that.min || this.max !== that.max || !this.subs[0].equals(that.subs[0])) return false;
				break;
			case Regexp.Op.CAPTURE:
				if (this.cap !== that.cap || (this.name === null ? that.name !== null : this.name !== that.name) || !this.subs[0].equals(that.subs[0])) return false;
				break;
			case Regexp.Op.PLB:
			case Regexp.Op.NLB: if (this.lb !== that.lb || !this.subs[0].equals(that.subs[0])) return false;
		}
		return true;
	}
};
var AhoCorasick = class {
	constructor(wordArrays) {
		this.next = [Object.create(null)];
		this.fail = [0];
		this.match = [false];
		for (const word of wordArrays) {
			let node = 0;
			for (let i = 0; i < word.length; i++) {
				const val = word[i];
				if (!(val in this.next[node])) {
					this.next.push(Object.create(null));
					this.fail.push(0);
					this.match.push(false);
					this.next[node][val] = this.next.length - 1;
				}
				node = this.next[node][val];
			}
			this.match[node] = true;
		}
		const queue = [];
		for (const val in this.next[0]) if (Object.prototype.hasOwnProperty.call(this.next[0], val)) {
			const child = this.next[0][val];
			this.fail[child] = 0;
			queue.push(child);
		}
		while (queue.length > 0) {
			const curr = queue.shift();
			for (const val in this.next[curr]) if (Object.prototype.hasOwnProperty.call(this.next[curr], val)) {
				const child = this.next[curr][val];
				let failNode = this.fail[curr];
				while (failNode !== 0 && !(val in this.next[failNode])) failNode = this.fail[failNode];
				if (val in this.next[failNode]) this.fail[child] = this.next[failNode][val];
				else this.fail[child] = 0;
				this.match[child] = this.match[child] || this.match[this.fail[child]];
				queue.push(child);
			}
		}
	}
	searchUTF16(charSeq, start, end) {
		let node = 0;
		for (let i = start; i < end; i++) {
			const val = charSeq.charCodeAt(i);
			while (node !== 0 && !(val in this.next[node])) node = this.fail[node];
			if (val in this.next[node]) node = this.next[node][val];
			if (this.match[node]) return true;
		}
		return false;
	}
	searchUTF8(bytes, start, end) {
		let node = 0;
		for (let i = start; i < end; i++) {
			const val = bytes[i];
			while (node !== 0 && !(val in this.next[node])) node = this.fail[node];
			if (val in this.next[node]) node = this.next[node][val];
			if (this.match[node]) return true;
		}
		return false;
	}
};
var Prefilter = class Prefilter {
	static Type = {
		NONE: 0,
		EXACT: 1,
		AND: 2,
		OR: 3
	};
	constructor(type) {
		this.type = type;
		this.subs = [];
		this.str = "";
		this.bytes = null;
		this.ac16 = null;
		this.ac8 = null;
	}
	eval(input, pos) {
		switch (this.type) {
			case Prefilter.Type.NONE: return true;
			case Prefilter.Type.EXACT: return input.hasString(this, pos);
			case Prefilter.Type.AND:
				for (let i = 0; i < this.subs.length; i++) if (!this.subs[i].eval(input, pos)) return false;
				return true;
			case Prefilter.Type.OR:
				if (this.ac16 && this.ac8) return input.hasAnyString(this, pos);
				for (let i = 0; i < this.subs.length; i++) if (this.subs[i].eval(input, pos)) return true;
				return false;
			default: return true;
		}
	}
};
var PrefilterTree = class PrefilterTree {
	static build(re) {
		const pf = PrefilterTree.fromRegexp(re);
		return PrefilterTree.simplify(pf);
	}
	static fromRegexp(re) {
		if (!re) return new Prefilter(Prefilter.Type.NONE);
		switch (re.op) {
			case Regexp.Op.PLB:
			case Regexp.Op.NLB:
			case Regexp.Op.NO_MATCH:
			case Regexp.Op.EMPTY_MATCH:
			case Regexp.Op.BEGIN_LINE:
			case Regexp.Op.END_LINE:
			case Regexp.Op.BEGIN_TEXT:
			case Regexp.Op.END_TEXT:
			case Regexp.Op.WORD_BOUNDARY:
			case Regexp.Op.NO_WORD_BOUNDARY:
			case Regexp.Op.CHAR_CLASS:
			case Regexp.Op.ANY_CHAR_NOT_NL:
			case Regexp.Op.ANY_CHAR: return new Prefilter(Prefilter.Type.NONE);
			case Regexp.Op.LITERAL: {
				if (re.runes.length === 0 || (re.flags & RE2Flags.FOLD_CASE) !== 0) return new Prefilter(Prefilter.Type.NONE);
				const pf = new Prefilter(Prefilter.Type.EXACT);
				let str = "";
				for (let i = 0; i < re.runes.length; i++) str += String.fromCodePoint(re.runes[i]);
				pf.str = str;
				pf.bytes = Utils.stringToUtf8ByteArray(pf.str);
				return pf;
			}
			case Regexp.Op.CAPTURE:
			case Regexp.Op.PLUS: return PrefilterTree.fromRegexp(re.subs[0]);
			case Regexp.Op.REPEAT:
				if (re.min >= 1) return PrefilterTree.fromRegexp(re.subs[0]);
				return new Prefilter(Prefilter.Type.NONE);
			case Regexp.Op.CONCAT: {
				const pf = new Prefilter(Prefilter.Type.AND);
				for (const sub of re.subs) pf.subs.push(PrefilterTree.fromRegexp(sub));
				return pf;
			}
			case Regexp.Op.ALTERNATE: {
				const pf = new Prefilter(Prefilter.Type.OR);
				for (const sub of re.subs) pf.subs.push(PrefilterTree.fromRegexp(sub));
				return pf;
			}
			default: return new Prefilter(Prefilter.Type.NONE);
		}
	}
	static simplify(pf) {
		if (pf.type === Prefilter.Type.EXACT || pf.type === Prefilter.Type.NONE) return pf;
		if (pf.type === Prefilter.Type.AND) {
			const newSubs = [];
			for (const sub of pf.subs) {
				const s = PrefilterTree.simplify(sub);
				if (s.type !== Prefilter.Type.NONE) if (s.type === Prefilter.Type.AND) for (let j = 0; j < s.subs.length; j++) newSubs.push(s.subs[j]);
				else newSubs.push(s);
			}
			if (newSubs.length === 0) return new Prefilter(Prefilter.Type.NONE);
			if (newSubs.length === 1) return newSubs[0];
			pf.subs = newSubs;
			return pf;
		}
		if (pf.type === Prefilter.Type.OR) {
			const newSubs = [];
			for (const sub of pf.subs) {
				const s = PrefilterTree.simplify(sub);
				if (s.type === Prefilter.Type.NONE) return new Prefilter(Prefilter.Type.NONE);
				if (s.type === Prefilter.Type.OR) for (let j = 0; j < s.subs.length; j++) newSubs.push(s.subs[j]);
				else newSubs.push(s);
			}
			if (newSubs.length === 0) return new Prefilter(Prefilter.Type.NONE);
			if (newSubs.length === 1) return newSubs[0];
			const seen = /* @__PURE__ */ new Set();
			const uniqueSubs = [];
			for (const sub of newSubs) if (sub.type === Prefilter.Type.EXACT) {
				if (!seen.has(sub.str)) {
					seen.add(sub.str);
					uniqueSubs.push(sub);
				}
			} else uniqueSubs.push(sub);
			pf.subs = uniqueSubs;
			let allExact = true;
			for (const sub of uniqueSubs) if (sub.type !== Prefilter.Type.EXACT) {
				allExact = false;
				break;
			}
			if (allExact && uniqueSubs.length > 1) {
				pf.ac16 = new AhoCorasick(uniqueSubs.map((s) => {
					const arr = [];
					for (let i = 0; i < s.str.length; i++) arr.push(s.str.charCodeAt(i));
					return arr;
				}));
				pf.ac8 = new AhoCorasick(uniqueSubs.map((s) => s.bytes));
			}
			return pf;
		}
		return pf;
	}
};
/**
* A list of instruction pointers waiting to be patched.
* Tracks both `head` and `tail` to allow O(1) appending during compilation.
* * Values are encoded integers, not standard memory pointers:
* - Program instruction index: `l >> 1`
* - Patch `.out` field if: `(l & 1) === 0`
* - Patch `.arg` field if: `(l & 1) === 1`
* - `0` denotes an empty list.
* * @see https://swtch.com/~rsc/regexp/regexp1.html
*/
var PatchList = class {
	/**
	* @param {number} head - Encoded pointer to the start of the patch list.
	* @param {number} tail - Encoded pointer to the end of the patch list.
	*/
	constructor(head = 0, tail = 0) {
		this.head = head;
		this.tail = tail;
	}
};
/**
* A Prog is a compiled regular expression program.
*/
var Prog = class {
	constructor() {
		this.inst = [];
		this.start = 0;
		this.numCap = 2;
		this.lbStarts = [];
		this.numLb = 0;
	}
	getInst(pc) {
		return this.inst[pc];
	}
	numInst() {
		return this.inst.length;
	}
	addInst(op) {
		this.inst.push(new Inst(op));
	}
	skipNop(pc) {
		let i = this.inst[pc];
		while (i.op === Inst.NOP || i.op === Inst.CAPTURE) {
			i = this.inst[pc];
			pc = i.out;
		}
		return i;
	}
	prefix() {
		let prefix = "";
		let i = this.skipNop(this.start);
		if (!Inst.isRuneOp(i.op) || i.runes.length !== 1) return [i.op === Inst.MATCH, prefix];
		while (Inst.isRuneOp(i.op) && i.runes.length === 1 && (i.arg & RE2Flags.FOLD_CASE) === 0) {
			prefix += String.fromCodePoint(i.runes[0]);
			i = this.skipNop(i.out);
		}
		return [i.op === Inst.MATCH, prefix];
	}
	startCond() {
		let flag = 0;
		let pc = this.start;
		loop: for (;;) {
			const i = this.inst[pc];
			switch (i.op) {
				case Inst.EMPTY_WIDTH:
					flag |= i.arg;
					break;
				case Inst.FAIL: return -1;
				case Inst.CAPTURE:
				case Inst.NOP: break;
				default: break loop;
			}
			pc = i.out;
		}
		return flag;
	}
	patch(l, val) {
		let head = l.head;
		while (head !== 0) {
			const i = this.inst[head >> 1];
			if ((head & 1) === 0) {
				head = i.out;
				i.out = val;
			} else {
				head = i.arg;
				i.arg = val;
			}
		}
	}
	append(l1, l2) {
		if (l1.head === 0) return l2;
		if (l2.head === 0) return l1;
		const i = this.inst[l1.tail >> 1];
		if ((l1.tail & 1) === 0) i.out = l2.head;
		else i.arg = l2.head;
		return new PatchList(l1.head, l2.tail);
	}
	/**
	*
	* @returns {string}
	*/
	toString() {
		let out = "";
		for (let pc = 0; pc < this.inst.length; pc++) {
			const len = out.length;
			out += pc;
			if (pc === this.start) out += "*";
			out += "        ".substring(out.length - len);
			out += this.inst[pc];
			out += "\n";
		}
		return out;
	}
};
/**
* A fragment of a compiled regular expression program.
*
* @see http://swtch.com/~rsc/regexp/regexp1.html
* @class
*/
var Frag = class {
	constructor(i = 0, out = new PatchList(), nullable = false) {
		this.i = i;
		this.out = out;
		this.nullable = nullable;
	}
};
/**
* Compiler from {@code Regexp} (RE2 abstract syntax) to {@code RE2} (compiled regular expression).
*
* The only entry point is {@link #compileRegexp}.
*/
var Compiler = class Compiler {
	static ANY_RUNE_NOT_NL() {
		return [
			0,
			Codepoint.CODES.get("\n") - 1,
			Codepoint.CODES.get("\n") + 1,
			Unicode.MAX_RUNE
		];
	}
	static ANY_RUNE() {
		return [0, Unicode.MAX_RUNE];
	}
	static compileRegexp(re) {
		const c = new Compiler();
		const f = c.compile(re);
		c.prog.patch(f.out, c.newInst(Inst.MATCH).i);
		c.prog.start = f.i;
		return c.prog;
	}
	static compileSet(regexps) {
		const c = new Compiler();
		if (regexps.length === 0) {
			c.prog.start = c.newInst(Inst.FAIL).i;
			return c.prog;
		}
		let starts = [];
		for (let i = 0; i < regexps.length; i++) {
			const f = c.compile(regexps[i]);
			const m = c.newInst(Inst.MATCH);
			c.prog.getInst(m.i).arg = i;
			c.prog.patch(f.out, m.i);
			starts.push(f.i);
		}
		let start = starts[0];
		for (let i = 1; i < starts.length; i++) {
			const f = c.newInst(Inst.ALT);
			const inst = c.prog.getInst(f.i);
			inst.out = start;
			inst.arg = starts[i];
			start = f.i;
		}
		c.prog.start = start;
		return c.prog;
	}
	constructor() {
		this.prog = new Prog();
		this.newInst(Inst.FAIL);
	}
	newInst(op) {
		this.prog.addInst(op);
		return new Frag(this.prog.numInst() - 1, new PatchList(), true);
	}
	nop() {
		const f = this.newInst(Inst.NOP);
		f.out = new PatchList(f.i << 1, f.i << 1);
		return f;
	}
	fail() {
		return new Frag();
	}
	cap(arg) {
		const f = this.newInst(Inst.CAPTURE);
		f.out = new PatchList(f.i << 1, f.i << 1);
		this.prog.getInst(f.i).arg = arg;
		if (this.prog.numCap < arg + 1) this.prog.numCap = arg + 1;
		return f;
	}
	cat(f1, f2) {
		if (f1.i === 0 || f2.i === 0) return this.fail();
		this.prog.patch(f1.out, f2.i);
		return new Frag(f1.i, f2.out, f1.nullable && f2.nullable);
	}
	alt(f1, f2) {
		if (f1.i === 0) return f2;
		if (f2.i === 0) return f1;
		const f = this.newInst(Inst.ALT);
		const i = this.prog.getInst(f.i);
		i.out = f1.i;
		i.arg = f2.i;
		f.out = this.prog.append(f1.out, f2.out);
		f.nullable = f1.nullable || f2.nullable;
		return f;
	}
	loop(f1, nongreedy) {
		const f = this.newInst(Inst.ALT);
		const i = this.prog.getInst(f.i);
		if (nongreedy) {
			i.arg = f1.i;
			f.out = new PatchList(f.i << 1, f.i << 1);
		} else {
			i.out = f1.i;
			f.out = new PatchList(f.i << 1 | 1, f.i << 1 | 1);
		}
		this.prog.patch(f1.out, f.i);
		return f;
	}
	quest(f1, nongreedy) {
		const f = this.newInst(Inst.ALT);
		const i = this.prog.getInst(f.i);
		if (nongreedy) {
			i.arg = f1.i;
			f.out = new PatchList(f.i << 1, f.i << 1);
		} else {
			i.out = f1.i;
			f.out = new PatchList(f.i << 1 | 1, f.i << 1 | 1);
		}
		f.out = this.prog.append(f.out, f1.out);
		return f;
	}
	star(f1, nongreedy) {
		if (f1.nullable) return this.quest(this.plus(f1, nongreedy), nongreedy);
		return this.loop(f1, nongreedy);
	}
	plus(f1, nongreedy) {
		return new Frag(f1.i, this.loop(f1, nongreedy).out, f1.nullable);
	}
	empty(op) {
		const f = this.newInst(Inst.EMPTY_WIDTH);
		this.prog.getInst(f.i).arg = op;
		f.out = new PatchList(f.i << 1, f.i << 1);
		return f;
	}
	rune(runes, flags) {
		const f = this.newInst(Inst.RUNE);
		f.nullable = false;
		const i = this.prog.getInst(f.i);
		i.runes = runes;
		flags &= RE2Flags.FOLD_CASE;
		if (runes.length !== 1 || Unicode.simpleFold(runes[0]) === runes[0]) flags &= ~RE2Flags.FOLD_CASE;
		i.arg = flags;
		f.out = new PatchList(f.i << 1, f.i << 1);
		if ((flags & RE2Flags.FOLD_CASE) === 0 && runes.length === 1 || runes.length === 2 && runes[0] === runes[1]) i.op = Inst.RUNE1;
		else if (runes.length === 2 && runes[0] === 0 && runes[1] === Unicode.MAX_RUNE) i.op = Inst.RUNE_ANY;
		else if (runes.length === 4 && runes[0] === 0 && runes[1] === Codepoint.CODES.get("\n") - 1 && runes[2] === Codepoint.CODES.get("\n") + 1 && runes[3] === Unicode.MAX_RUNE) i.op = Inst.RUNE_ANY_NOT_NL;
		return f;
	}
	lookBehind(a, lb) {
		const id = this.newInst(Inst.LB_WRITE);
		this.prog.getInst(id.i).arg = lb;
		const any = this.rune(Compiler.ANY_RUNE(), 0);
		const dotStar = this.star(any, true);
		const lbAutomaton = this.cat(dotStar, a);
		this.prog.patch(lbAutomaton.out, id.i);
		const checkId = this.newInst(Inst.LB_CHECK);
		this.prog.getInst(checkId.i).arg = lb;
		this.prog.lbStarts.push(lbAutomaton.i);
		if (Math.abs(lb) > this.prog.numLb) this.prog.numLb = Math.abs(lb);
		checkId.out = new PatchList(checkId.i << 1, checkId.i << 1);
		return checkId;
	}
	compile(re) {
		switch (re.op) {
			case Regexp.Op.NO_MATCH: return this.fail();
			case Regexp.Op.EMPTY_MATCH: return this.nop();
			case Regexp.Op.LITERAL: if (re.runes.length === 0) return this.nop();
			else {
				let f = null;
				for (let r of re.runes) {
					const f1 = this.rune([r], re.flags);
					f = f === null ? f1 : this.cat(f, f1);
				}
				return f;
			}
			case Regexp.Op.CHAR_CLASS: return this.rune(re.runes, re.flags);
			case Regexp.Op.ANY_CHAR_NOT_NL: return this.rune(Compiler.ANY_RUNE_NOT_NL(), 0);
			case Regexp.Op.ANY_CHAR: return this.rune(Compiler.ANY_RUNE(), 0);
			case Regexp.Op.BEGIN_LINE: return this.empty(Utils.EMPTY_BEGIN_LINE);
			case Regexp.Op.END_LINE: return this.empty(Utils.EMPTY_END_LINE);
			case Regexp.Op.BEGIN_TEXT: return this.empty(Utils.EMPTY_BEGIN_TEXT);
			case Regexp.Op.END_TEXT: return this.empty(Utils.EMPTY_END_TEXT);
			case Regexp.Op.WORD_BOUNDARY: return this.empty(Utils.EMPTY_WORD_BOUNDARY);
			case Regexp.Op.NO_WORD_BOUNDARY: return this.empty(Utils.EMPTY_NO_WORD_BOUNDARY);
			case Regexp.Op.PLB:
			case Regexp.Op.NLB: return this.lookBehind(this.compile(re.subs[0]), re.lb);
			case Regexp.Op.CAPTURE: {
				const bra = this.cap(re.cap << 1);
				const sub = this.compile(re.subs[0]);
				const ket = this.cap(re.cap << 1 | 1);
				return this.cat(this.cat(bra, sub), ket);
			}
			case Regexp.Op.STAR: return this.star(this.compile(re.subs[0]), (re.flags & RE2Flags.NON_GREEDY) !== 0);
			case Regexp.Op.PLUS: return this.plus(this.compile(re.subs[0]), (re.flags & RE2Flags.NON_GREEDY) !== 0);
			case Regexp.Op.QUEST: return this.quest(this.compile(re.subs[0]), (re.flags & RE2Flags.NON_GREEDY) !== 0);
			case Regexp.Op.CONCAT: if (re.subs.length === 0) return this.nop();
			else {
				let f = null;
				for (let sub of re.subs) {
					const f1 = this.compile(sub);
					f = f === null ? f1 : this.cat(f, f1);
				}
				return f;
			}
			case Regexp.Op.ALTERNATE: if (re.subs.length === 0) return this.nop();
			else {
				let f = null;
				for (let sub of re.subs) {
					const f1 = this.compile(sub);
					f = f === null ? f1 : this.alt(f, f1);
				}
				return f;
			}
			default: throw new RE2JSCompileException("regexp: unhandled case in compile");
		}
	}
};
var Simplify = class Simplify {
	static simplify(re) {
		if (re === null) return null;
		switch (re.op) {
			case Regexp.Op.PLB:
			case Regexp.Op.NLB:
			case Regexp.Op.CAPTURE: {
				const sub = Simplify.simplify(re.subs[0]);
				if (sub !== re.subs[0]) {
					const nre = Regexp.fromRegexp(re);
					nre.runes = [];
					nre.subs = [sub];
					return nre;
				}
				return re;
			}
			case Regexp.Op.CONCAT:
			case Regexp.Op.ALTERNATE: {
				const newSubs = [];
				let changed = false;
				for (let i = 0; i < re.subs.length; i++) {
					const sub = re.subs[i];
					const nsub = Simplify.simplify(sub);
					if (nsub !== sub) changed = true;
					if (re.op === Regexp.Op.CONCAT) {
						if (nsub.op === Regexp.Op.NO_MATCH) return new Regexp(Regexp.Op.NO_MATCH);
						if (nsub.op === Regexp.Op.EMPTY_MATCH) {
							changed = true;
							continue;
						}
						if (nsub.op === Regexp.Op.CONCAT) {
							changed = true;
							for (let j = 0; j < nsub.subs.length; j++) newSubs.push(nsub.subs[j]);
							continue;
						}
					} else if (re.op === Regexp.Op.ALTERNATE) {
						if (nsub.op === Regexp.Op.NO_MATCH) {
							changed = true;
							continue;
						}
						if (nsub.op === Regexp.Op.ALTERNATE) {
							changed = true;
							for (let j = 0; j < nsub.subs.length; j++) newSubs.push(nsub.subs[j]);
							continue;
						}
					}
					newSubs.push(nsub);
				}
				if (changed) {
					if (newSubs.length === 0) return new Regexp(re.op === Regexp.Op.CONCAT ? Regexp.Op.EMPTY_MATCH : Regexp.Op.NO_MATCH);
					if (newSubs.length === 1) return newSubs[0];
					const nre = Regexp.fromRegexp(re);
					nre.runes = [];
					nre.subs = newSubs;
					return nre;
				}
				return re;
			}
			case Regexp.Op.CHAR_CLASS:
				if (re.runes === null) return re;
				if (re.runes.length === 0) return new Regexp(Regexp.Op.NO_MATCH);
				if (re.runes.length === 2 && re.runes[0] === 0 && re.runes[1] === Unicode.MAX_RUNE) return new Regexp(Regexp.Op.ANY_CHAR);
				if (re.runes.length === 4 && re.runes[0] === 0 && re.runes[1] === Codepoint.CODES.get("\n") - 1 && re.runes[2] === Codepoint.CODES.get("\n") + 1 && re.runes[3] === Unicode.MAX_RUNE) return new Regexp(Regexp.Op.ANY_CHAR_NOT_NL);
				return re;
			case Regexp.Op.STAR:
			case Regexp.Op.PLUS:
			case Regexp.Op.QUEST: {
				const sub = Simplify.simplify(re.subs[0]);
				return Simplify.simplify1(re.op, re.flags, sub, re);
			}
			case Regexp.Op.REPEAT: {
				if (re.min === 0 && re.max === 0) return new Regexp(Regexp.Op.EMPTY_MATCH);
				const sub = Simplify.simplify(re.subs[0]);
				if (re.max === -1) {
					if (re.min === 0) return Simplify.simplify1(Regexp.Op.STAR, re.flags, sub, null);
					if (re.min === 1) return Simplify.simplify1(Regexp.Op.PLUS, re.flags, sub, null);
					const nre = new Regexp(Regexp.Op.CONCAT);
					const subs = [];
					for (let i = 0; i < re.min - 1; i++) subs.push(sub);
					subs.push(Simplify.simplify1(Regexp.Op.PLUS, re.flags, sub, null));
					nre.subs = subs.slice(0);
					return Simplify.simplify(nre);
				}
				if (re.min === 1 && re.max === 1) return sub;
				let prefixSubs = null;
				if (re.min > 0) {
					prefixSubs = [];
					for (let i = 0; i < re.min; i++) prefixSubs.push(sub);
				}
				if (re.max > re.min) {
					let suffix = Simplify.simplify1(Regexp.Op.QUEST, re.flags, sub, null);
					for (let i = re.min + 1; i < re.max; i++) {
						const nre2 = new Regexp(Regexp.Op.CONCAT);
						nre2.subs = [sub, suffix];
						suffix = Simplify.simplify1(Regexp.Op.QUEST, re.flags, nre2, null);
					}
					if (prefixSubs === null) return suffix;
					prefixSubs.push(suffix);
				}
				if (prefixSubs !== null) {
					const prefix = new Regexp(Regexp.Op.CONCAT);
					prefix.subs = prefixSubs.slice(0);
					return Simplify.simplify(prefix);
				}
				return new Regexp(Regexp.Op.NO_MATCH);
			}
		}
		return re;
	}
	static simplify1(op, flags, sub, re) {
		if (sub.op === Regexp.Op.EMPTY_MATCH) return sub;
		if (sub.op === Regexp.Op.NO_MATCH) {
			if (op === Regexp.Op.PLUS) return sub;
			return new Regexp(Regexp.Op.EMPTY_MATCH);
		}
		if (op === sub.op && (flags & RE2Flags.NON_GREEDY) === (sub.flags & RE2Flags.NON_GREEDY)) return sub;
		if (re !== null && re.op === op && (re.flags & RE2Flags.NON_GREEDY) === (flags & RE2Flags.NON_GREEDY) && sub === re.subs[0]) return re;
		const nre = new Regexp(op);
		nre.flags = flags;
		nre.subs = [sub];
		return nre;
	}
};
var CharGroup = class {
	constructor(sign, cls) {
		this.sign = sign;
		this.cls = cls;
	}
};
var code1 = [48, 57];
var code2 = [
	9,
	10,
	12,
	13,
	32,
	32
];
var code3 = [
	48,
	57,
	65,
	90,
	95,
	95,
	97,
	122
];
var PERL_GROUPS = /* @__PURE__ */ new Map([
	["\\d", new CharGroup(1, code1)],
	["\\D", new CharGroup(-1, code1)],
	["\\s", new CharGroup(1, code2)],
	["\\S", new CharGroup(-1, code2)],
	["\\w", new CharGroup(1, code3)],
	["\\W", new CharGroup(-1, code3)]
]);
var code4 = [
	48,
	57,
	65,
	90,
	97,
	122
];
var code5 = [
	65,
	90,
	97,
	122
];
var code6 = [0, 127];
var code7 = [
	9,
	9,
	32,
	32
];
var code8 = [
	0,
	31,
	127,
	127
];
var code9 = [48, 57];
var code10 = [33, 126];
var code11 = [97, 122];
var code12 = [32, 126];
var code13 = [
	33,
	47,
	58,
	64,
	91,
	96,
	123,
	126
];
var code14 = [
	9,
	13,
	32,
	32
];
var code15 = [65, 90];
var code16 = [
	48,
	57,
	65,
	90,
	95,
	95,
	97,
	122
];
var code17 = [
	48,
	57,
	65,
	70,
	97,
	102
];
var POSIX_GROUPS = /* @__PURE__ */ new Map([
	["[:alnum:]", new CharGroup(1, code4)],
	["[:^alnum:]", new CharGroup(-1, code4)],
	["[:alpha:]", new CharGroup(1, code5)],
	["[:^alpha:]", new CharGroup(-1, code5)],
	["[:ascii:]", new CharGroup(1, code6)],
	["[:^ascii:]", new CharGroup(-1, code6)],
	["[:blank:]", new CharGroup(1, code7)],
	["[:^blank:]", new CharGroup(-1, code7)],
	["[:cntrl:]", new CharGroup(1, code8)],
	["[:^cntrl:]", new CharGroup(-1, code8)],
	["[:digit:]", new CharGroup(1, code9)],
	["[:^digit:]", new CharGroup(-1, code9)],
	["[:graph:]", new CharGroup(1, code10)],
	["[:^graph:]", new CharGroup(-1, code10)],
	["[:lower:]", new CharGroup(1, code11)],
	["[:^lower:]", new CharGroup(-1, code11)],
	["[:print:]", new CharGroup(1, code12)],
	["[:^print:]", new CharGroup(-1, code12)],
	["[:punct:]", new CharGroup(1, code13)],
	["[:^punct:]", new CharGroup(-1, code13)],
	["[:space:]", new CharGroup(1, code14)],
	["[:^space:]", new CharGroup(-1, code14)],
	["[:upper:]", new CharGroup(1, code15)],
	["[:^upper:]", new CharGroup(-1, code15)],
	["[:word:]", new CharGroup(1, code16)],
	["[:^word:]", new CharGroup(-1, code16)],
	["[:xdigit:]", new CharGroup(1, code17)],
	["[:^xdigit:]", new CharGroup(-1, code17)]
]);
/**
* A "builder"-style helper class for manipulating character classes represented as an array of
* pairs of runes [lo, hi], each denoting an inclusive interval.
*
* All methods mutate the internal state and return {@code this}, allowing operations to be chained.
*/
var CharClass = class CharClass {
	static charClassToString(r, len) {
		let result = "[";
		for (let i = 0; i < len; i += 2) {
			if (i > 0) result += " ";
			const lo = r[i];
			const hi = r[i + 1];
			if (lo === hi) result += `0x${lo.toString(16)}`;
			else result += `0x${lo.toString(16)}-0x${hi.toString(16)}`;
		}
		result += "]";
		return result;
	}
	static cmp(array, i, pivotFrom, pivotTo) {
		const cmp = array[i] - pivotFrom;
		return cmp !== 0 ? cmp : pivotTo - array[i + 1];
	}
	static qsortIntPair(array, left, right) {
		const pivotIndex = ((left + right) / 2 | 0) & -2;
		const pivotFrom = array[pivotIndex];
		const pivotTo = array[pivotIndex + 1];
		let i = left;
		let j = right;
		while (i <= j) {
			while (i < right && CharClass.cmp(array, i, pivotFrom, pivotTo) < 0) i += 2;
			while (j > left && CharClass.cmp(array, j, pivotFrom, pivotTo) > 0) j -= 2;
			if (i <= j) {
				if (i !== j) {
					let temp = array[i];
					array[i] = array[j];
					array[j] = temp;
					temp = array[i + 1];
					array[i + 1] = array[j + 1];
					array[j + 1] = temp;
				}
				i += 2;
				j -= 2;
			}
		}
		if (left < j) CharClass.qsortIntPair(array, left, j);
		if (i < right) CharClass.qsortIntPair(array, i, right);
	}
	constructor(r = Utils.emptyInts()) {
		this.r = r;
		this.len = r.length;
	}
	toArray() {
		if (this.len === this.r.length) return this.r;
		else return this.r.slice(0, this.len);
	}
	cleanClass() {
		if (this.len < 4) return this;
		CharClass.qsortIntPair(this.r, 0, this.len - 2);
		let w = 2;
		for (let i = 2; i < this.len; i += 2) {
			const lo = this.r[i];
			const hi = this.r[i + 1];
			if (lo <= this.r[w - 1] + 1) {
				if (hi > this.r[w - 1]) this.r[w - 1] = hi;
				continue;
			}
			this.r[w] = lo;
			this.r[w + 1] = hi;
			w += 2;
		}
		this.len = w;
		return this;
	}
	appendLiteral(x, flags) {
		return (flags & RE2Flags.FOLD_CASE) !== 0 ? this.appendFoldedRange(x, x) : this.appendRange(x, x);
	}
	appendRange(lo, hi) {
		if (this.len > 0) {
			for (let i = 2; i <= 4; i += 2) if (this.len >= i) {
				const rlo = this.r[this.len - i];
				const rhi = this.r[this.len - i + 1];
				if (lo <= rhi + 1 && rlo <= hi + 1) {
					if (lo < rlo) this.r[this.len - i] = lo;
					if (hi > rhi) this.r[this.len - i + 1] = hi;
					return this;
				}
			}
		}
		this.r[this.len++] = lo;
		this.r[this.len++] = hi;
		return this;
	}
	appendFoldedRange(lo, hi) {
		if (lo <= Unicode.MIN_FOLD && hi >= Unicode.MAX_FOLD) return this.appendRange(lo, hi);
		if (hi < Unicode.MIN_FOLD || lo > Unicode.MAX_FOLD) return this.appendRange(lo, hi);
		if (lo < Unicode.MIN_FOLD) {
			this.appendRange(lo, Unicode.MIN_FOLD - 1);
			lo = Unicode.MIN_FOLD;
		}
		if (hi > Unicode.MAX_FOLD) {
			this.appendRange(Unicode.MAX_FOLD + 1, hi);
			hi = Unicode.MAX_FOLD;
		}
		for (let c = lo; c <= hi; c++) {
			this.appendRange(c, c);
			for (let f = Unicode.simpleFold(c); f !== c; f = Unicode.simpleFold(f)) this.appendRange(f, f);
		}
		return this;
	}
	appendClass(x) {
		for (let i = 0; i < x.length; i += 2) this.appendRange(x[i], x[i + 1]);
		return this;
	}
	appendFoldedClass(x) {
		for (let i = 0; i < x.length; i += 2) this.appendFoldedRange(x[i], x[i + 1]);
		return this;
	}
	appendNegatedClass(x) {
		let nextLo = 0;
		for (let i = 0; i < x.length; i += 2) {
			const lo = x[i];
			const hi = x[i + 1];
			if (nextLo <= lo - 1) this.appendRange(nextLo, lo - 1);
			nextLo = hi + 1;
		}
		if (nextLo <= Unicode.MAX_RUNE) this.appendRange(nextLo, Unicode.MAX_RUNE);
		return this;
	}
	appendTable(table) {
		for (let i = 0; i < table.length; ++i) {
			const lo = table.getLo(i);
			const hi = table.getHi(i);
			const stride = table.getStride(i);
			if (stride === 1) {
				this.appendRange(lo, hi);
				continue;
			}
			for (let c = lo; c <= hi; c += stride) this.appendRange(c, c);
		}
		return this;
	}
	appendNegatedTable(table) {
		let nextLo = 0;
		for (let i = 0; i < table.length; ++i) {
			const lo = table.getLo(i);
			const hi = table.getHi(i);
			const stride = table.getStride(i);
			if (stride === 1) {
				if (nextLo <= lo - 1) this.appendRange(nextLo, lo - 1);
				nextLo = hi + 1;
				continue;
			}
			for (let c = lo; c <= hi; c += stride) {
				if (nextLo <= c - 1) this.appendRange(nextLo, c - 1);
				nextLo = c + 1;
			}
		}
		if (nextLo <= Unicode.MAX_RUNE) this.appendRange(nextLo, Unicode.MAX_RUNE);
		return this;
	}
	appendTableWithSign(table, sign) {
		return sign < 0 ? this.appendNegatedTable(table) : this.appendTable(table);
	}
	negateClass() {
		let nextLo = 0;
		let w = 0;
		for (let i = 0; i < this.len; i += 2) {
			const lo = this.r[i];
			const hi = this.r[i + 1];
			if (nextLo <= lo - 1) {
				this.r[w] = nextLo;
				this.r[w + 1] = lo - 1;
				w += 2;
			}
			nextLo = hi + 1;
		}
		this.len = w;
		if (nextLo <= Unicode.MAX_RUNE) {
			this.r[this.len++] = nextLo;
			this.r[this.len++] = Unicode.MAX_RUNE;
		}
		return this;
	}
	appendClassWithSign(x, sign) {
		return sign < 0 ? this.appendNegatedClass(x) : this.appendClass(x);
	}
	appendGroup(g, foldCase) {
		let cls = g.cls;
		if (foldCase) cls = new CharClass().appendFoldedClass(cls).cleanClass().toArray();
		return this.appendClassWithSign(cls, g.sign);
	}
	toString() {
		return CharClass.charClassToString(this.r, this.len);
	}
};
var StringIterator = class {
	constructor(str) {
		this.str = str;
		this.position = 0;
	}
	pos() {
		return this.position;
	}
	rewindTo(pos) {
		this.position = pos;
	}
	more() {
		return this.position < this.str.length;
	}
	peek() {
		return this.str.codePointAt(this.position);
	}
	skip(n) {
		this.position += n;
	}
	skipString(s) {
		this.position += s.length;
	}
	pop() {
		const r = this.str.codePointAt(this.position);
		this.position += Utils.charCount(r);
		return r;
	}
	lookingAt(s) {
		return this.str.startsWith(s, this.position);
	}
	rest() {
		return this.str.substring(this.position);
	}
	from(beforePos) {
		return this.str.substring(beforePos, this.position);
	}
	toString() {
		return this.rest();
	}
};
/**
* A parser of regular expression patterns.
*
* The only public entry point is {@link #parse(String pattern, int flags)}.
*/
var Parser = class Parser {
	static ERR_INTERNAL_ERROR = "regexp/syntax: internal error";
	static ERR_INVALID_CHAR_RANGE = "invalid character class range";
	static ERR_INVALID_ESCAPE = "invalid escape sequence";
	static ERR_INVALID_NAMED_CAPTURE = "invalid named capture";
	static ERR_INVALID_PERL_OP = "invalid or unsupported Perl syntax";
	static ERR_INVALID_REPEAT_OP = "invalid nested repetition operator";
	static ERR_INVALID_REPEAT_SIZE = "invalid repeat count";
	static ERR_MISSING_BRACKET = "missing closing ]";
	static ERR_MISSING_PAREN = "missing closing )";
	static ERR_MISSING_REPEAT_ARGUMENT = "missing argument to repetition operator";
	static ERR_TRAILING_BACKSLASH = "trailing backslash at end of expression";
	static ERR_DUPLICATE_NAMED_CAPTURE = "duplicate capture group name";
	static ERR_UNEXPECTED_PAREN = "unexpected )";
	static ERR_NESTING_DEPTH = "expression nests too deeply";
	static ERR_LARGE = "expression too large";
	static ERR_INVALID_CAPTURE_IN_LOOKBEHIND = "invalid capture in lookbehind";
	static MAX_HEIGHT = 1e3;
	static MAX_SIZE = 3355443;
	static MAX_RUNES = 33554432;
	static ANY_TABLE = new UnicodeRangeTable(new Uint32Array([
		0,
		Unicode.MAX_RUNE,
		1
	]));
	static ASCII_TABLE = new UnicodeRangeTable(new Uint32Array([
		0,
		127,
		1
	]));
	static ASCII_FOLD_TABLE = new UnicodeRangeTable(new Uint32Array([
		0,
		127,
		1,
		383,
		383,
		1,
		8490,
		8490,
		1
	]));
	static unicodeTable(name) {
		if (name === "Any") return {
			tab: Parser.ANY_TABLE,
			fold: Parser.ANY_TABLE,
			sign: 1
		};
		if (name === "Ascii") return {
			tab: Parser.ASCII_TABLE,
			fold: Parser.ASCII_FOLD_TABLE,
			sign: 1
		};
		if (name === "Assigned") return {
			tab: UnicodeTables.CATEGORIES.get("Cn"),
			fold: UnicodeTables.CATEGORIES.get("Cn"),
			sign: -1
		};
		if (name === "Lc") return {
			tab: UnicodeTables.CATEGORIES.get("LC"),
			fold: UnicodeTables.FOLD_CATEGORIES.get("LC"),
			sign: 1
		};
		if (UnicodeTables.CATEGORIES.has(name)) return {
			tab: UnicodeTables.CATEGORIES.get(name),
			fold: UnicodeTables.FOLD_CATEGORIES.get(name),
			sign: 1
		};
		if (UnicodeTables.SCRIPTS.has(name)) return {
			tab: UnicodeTables.SCRIPTS.get(name),
			fold: UnicodeTables.FOLD_SCRIPT.get(name),
			sign: 1
		};
		return null;
	}
	static minFoldRune(r) {
		if (r < Unicode.MIN_FOLD || r > Unicode.MAX_FOLD) return r;
		let min = r;
		const r0 = r;
		for (r = Unicode.simpleFold(r); r !== r0; r = Unicode.simpleFold(r)) if (min > r) min = r;
		return min;
	}
	static leadingRegexp(re) {
		if (re.op === Regexp.Op.EMPTY_MATCH) return null;
		if (re.op === Regexp.Op.CONCAT && re.subs.length > 0) {
			const sub = re.subs[0];
			if (sub.op === Regexp.Op.EMPTY_MATCH) return null;
			return sub;
		}
		return re;
	}
	static literalRegexp(s, flags) {
		const re = new Regexp(Regexp.Op.LITERAL);
		re.flags = flags;
		re.runes = Utils.stringToRunes(s);
		return re;
	}
	/**
	* Parse regular expression pattern {@code pattern} with mode flags {@code flags}.
	* @param {string} pattern
	* @param {number} flags
	*/
	static parse(pattern, flags) {
		return new Parser(pattern, flags).parseInternal();
	}
	static parseRepeat(t) {
		const start = t.pos();
		if (!t.more() || !t.lookingAt("{")) return -1;
		t.skip(1);
		const min = Parser.parseInt(t);
		if (min === -1) return -1;
		if (!t.more()) return -1;
		let max;
		if (!t.lookingAt(",")) max = min;
		else {
			t.skip(1);
			if (!t.more()) return -1;
			if (t.lookingAt("}")) max = -1;
			else if ((max = Parser.parseInt(t)) === -1) return -1;
		}
		if (!t.more() || !t.lookingAt("}")) return -1;
		t.skip(1);
		if (min < 0 || min > 1e3 || max === -2 || max > 1e3 || max >= 0 && min > max) throw new RE2JSSyntaxException(Parser.ERR_INVALID_REPEAT_SIZE, t.from(start));
		return min << 16 | max & Unicode.MAX_BMP;
	}
	static isValidCaptureName(name) {
		if (name.length === 0) return false;
		for (let i = 0; i < name.length; i++) {
			const c = name.codePointAt(i);
			if (c !== Codepoint.CODES.get("_") && !Utils.isalnum(c)) return false;
		}
		return true;
	}
	static parseInt(t) {
		const start = t.pos();
		while (t.more() && t.peek() >= Codepoint.CODES.get("0") && t.peek() <= Codepoint.CODES.get("9")) t.skip(1);
		const n = t.from(start);
		if (n.length === 0 || n.length > 1 && n.codePointAt(0) === Codepoint.CODES.get("0")) return -1;
		if (n.length > 8) return -2;
		return parseInt(n, 10);
	}
	static isCharClass(re) {
		return re.op === Regexp.Op.LITERAL && re.runes.length === 1 || re.op === Regexp.Op.CHAR_CLASS || re.op === Regexp.Op.ANY_CHAR_NOT_NL || re.op === Regexp.Op.ANY_CHAR;
	}
	static matchRune(re, r) {
		switch (re.op) {
			case Regexp.Op.LITERAL: return re.runes.length === 1 && re.runes[0] === r;
			case Regexp.Op.CHAR_CLASS:
				for (let i = 0; i < re.runes.length; i += 2) if (re.runes[i] <= r && r <= re.runes[i + 1]) return true;
				return false;
			case Regexp.Op.ANY_CHAR_NOT_NL: return r !== Codepoint.CODES.get("\n");
			case Regexp.Op.ANY_CHAR: return true;
		}
		return false;
	}
	static mergeCharClass(dst, src) {
		switch (dst.op) {
			case Regexp.Op.ANY_CHAR: break;
			case Regexp.Op.ANY_CHAR_NOT_NL:
				if (Parser.matchRune(src, Codepoint.CODES.get("\n"))) dst.op = Regexp.Op.ANY_CHAR;
				break;
			case Regexp.Op.CHAR_CLASS:
				if (src.op === Regexp.Op.LITERAL) dst.runes = new CharClass(dst.runes).appendLiteral(src.runes[0], src.flags).toArray();
				else dst.runes = new CharClass(dst.runes).appendClass(src.runes).toArray();
				break;
			case Regexp.Op.LITERAL:
				if (src.runes[0] === dst.runes[0] && src.flags === dst.flags) break;
				dst.op = Regexp.Op.CHAR_CLASS;
				dst.runes = new CharClass().appendLiteral(dst.runes[0], dst.flags).appendLiteral(src.runes[0], src.flags).toArray();
		}
	}
	static parseEscape(t) {
		const startPos = t.pos();
		t.skip(1);
		if (!t.more()) throw new RE2JSSyntaxException(Parser.ERR_TRAILING_BACKSLASH);
		let c = t.pop();
		bigswitch: switch (c) {
			case Codepoint.CODES.get("1"):
			case Codepoint.CODES.get("2"):
			case Codepoint.CODES.get("3"):
			case Codepoint.CODES.get("4"):
			case Codepoint.CODES.get("5"):
			case Codepoint.CODES.get("6"):
			case Codepoint.CODES.get("7"): if (!t.more() || t.peek() < Codepoint.CODES.get("0") || t.peek() > Codepoint.CODES.get("7")) break;
			case Codepoint.CODES.get("0"): {
				let r = c - Codepoint.CODES.get("0");
				for (let i = 1; i < 3; i++) {
					if (!t.more() || t.peek() < Codepoint.CODES.get("0") || t.peek() > Codepoint.CODES.get("7")) break;
					r = r * 8 + t.peek() - Codepoint.CODES.get("0");
					t.skip(1);
				}
				return r;
			}
			case Codepoint.CODES.get("x"): {
				if (!t.more()) break;
				c = t.pop();
				if (c === Codepoint.CODES.get("{")) {
					let nhex = 0;
					let r = 0;
					while (true) {
						if (!t.more()) break bigswitch;
						c = t.pop();
						if (c === Codepoint.CODES.get("}")) break;
						const v = Utils.unhex(c);
						if (v < 0) break bigswitch;
						r = r * 16 + v;
						if (r > Unicode.MAX_RUNE) break bigswitch;
						nhex++;
					}
					if (nhex === 0) break bigswitch;
					return r;
				}
				const x = Utils.unhex(c);
				if (!t.more()) break;
				c = t.pop();
				const y = Utils.unhex(c);
				if (x < 0 || y < 0) break;
				return x * 16 + y;
			}
			case Codepoint.CODES.get("a"): return Codepoint.CODES.get("\x07");
			case Codepoint.CODES.get("f"): return Codepoint.CODES.get("\f");
			case Codepoint.CODES.get("n"): return Codepoint.CODES.get("\n");
			case Codepoint.CODES.get("r"): return Codepoint.CODES.get("\r");
			case Codepoint.CODES.get("t"): return Codepoint.CODES.get("	");
			case Codepoint.CODES.get("v"): return Codepoint.CODES.get("\v");
			default: if (c <= Unicode.MAX_ASCII && !Utils.isalnum(c)) return c;
		}
		throw new RE2JSSyntaxException(Parser.ERR_INVALID_ESCAPE, t.from(startPos));
	}
	static parseClassChar(t, wholeClassPos) {
		if (!t.more()) throw new RE2JSSyntaxException(Parser.ERR_MISSING_BRACKET, t.from(wholeClassPos));
		if (t.lookingAt("\\")) return Parser.parseEscape(t);
		return t.pop();
	}
	static concatRunes(x, y) {
		for (let i = 0; i < y.length; i++) x.push(y[i]);
		return x;
	}
	static hasCapture(re) {
		if (re === null) return false;
		if (re.op === Regexp.Op.CAPTURE) return true;
		if (re.subs) {
			for (let sub of re.subs) if (Parser.hasCapture(sub)) return true;
		}
		return false;
	}
	constructor(wholeRegexp, flags = 0) {
		this.wholeRegexp = wholeRegexp;
		this.flags = flags;
		this.numCap = 0;
		this.namedGroups = Object.create(null);
		this.stack = [];
		this.free = null;
		this.numRegexp = 0;
		this.numRunes = 0;
		this.repeats = 0;
		this.height = null;
		this.size = null;
		this.nlb = 0;
	}
	newRegexp(op) {
		let re = this.free;
		if (re !== null && re.subs !== null && re.subs.length > 0) {
			this.free = re.subs[0];
			re.reinit();
			re.op = op;
		} else {
			re = new Regexp(op);
			this.numRegexp += 1;
		}
		return re;
	}
	reuse(re) {
		if (this.height !== null && this.height.has(re)) this.height.delete(re);
		if (re.subs !== null && re.subs.length > 0) re.subs[0] = this.free;
		this.free = re;
	}
	checkLimits(re) {
		if (this.numRunes > Parser.MAX_RUNES) throw new RE2JSSyntaxException(Parser.ERR_LARGE);
		this.checkSize(re);
		this.checkHeight(re);
	}
	checkSize(re) {
		if (this.size === null) {
			if (this.repeats === 0) this.repeats = 1;
			if (re.op === Regexp.Op.REPEAT) {
				let n = re.max;
				if (n === -1) n = re.min;
				if (n <= 0) n = 1;
				if (n > Math.floor(Parser.MAX_SIZE / this.repeats)) this.repeats = Parser.MAX_SIZE;
				else this.repeats *= n;
			}
			if (this.numRegexp < Math.floor(Parser.MAX_SIZE / this.repeats)) return;
			this.size = /* @__PURE__ */ new Map();
			for (let reEx of this.stack) this.checkSize(reEx);
		}
		if (this.calcSize(re, true) > Parser.MAX_SIZE) throw new RE2JSSyntaxException(Parser.ERR_LARGE);
	}
	calcSize(re, force = false) {
		if (!force && this.size !== null) {
			if (this.size.has(re)) return this.size.get(re);
		}
		let size = 0;
		switch (re.op) {
			case Regexp.Op.LITERAL:
				size = re.runes.length;
				break;
			case Regexp.Op.PLB:
			case Regexp.Op.NLB:
			case Regexp.Op.CAPTURE:
			case Regexp.Op.STAR:
				size = 2 + this.calcSize(re.subs[0]);
				break;
			case Regexp.Op.PLUS:
			case Regexp.Op.QUEST:
				size = 1 + this.calcSize(re.subs[0]);
				break;
			case Regexp.Op.CONCAT:
				for (let sub of re.subs) size = size + this.calcSize(sub);
				break;
			case Regexp.Op.ALTERNATE:
				for (let sub of re.subs) size = size + this.calcSize(sub);
				if (re.subs.length > 1) size = size + re.subs.length - 1;
				break;
			case Regexp.Op.REPEAT: {
				let sub = this.calcSize(re.subs[0]);
				if (re.max === -1) {
					if (re.min === 0) size = 2 + sub;
					else size = 1 + re.min * sub;
					break;
				}
				size = re.max * sub + (re.max - re.min);
				break;
			}
		}
		size = Math.max(1, size);
		if (this.size === null) this.size = /* @__PURE__ */ new Map();
		this.size.set(re, size);
		return size;
	}
	checkHeight(re) {
		if (this.numRegexp < Parser.MAX_HEIGHT) return;
		if (this.height === null) {
			this.height = /* @__PURE__ */ new Map();
			for (let reEx of this.stack) this.checkHeight(reEx);
		}
		if (this.calcHeight(re, true) > Parser.MAX_HEIGHT) throw new RE2JSSyntaxException(Parser.ERR_NESTING_DEPTH);
	}
	calcHeight(re, force = false) {
		if (!force && this.height !== null) {
			if (this.height.has(re)) return this.height.get(re);
		}
		let h = 1;
		for (let sub of re.subs) {
			const hsub = this.calcHeight(sub);
			if (h < 1 + hsub) h = 1 + hsub;
		}
		if (this.height === null) this.height = /* @__PURE__ */ new Map();
		this.height.set(re, h);
		return h;
	}
	pop() {
		return this.stack.pop();
	}
	popToPseudo() {
		const n = this.stack.length;
		let i = n;
		while (i > 0 && !Regexp.isPseudoOp(this.stack[i - 1].op)) i--;
		const r = this.stack.slice(i, n);
		this.stack = this.stack.slice(0, i);
		return r;
	}
	push(re) {
		this.numRunes += re.runes.length;
		if (re.op === Regexp.Op.CHAR_CLASS && re.runes.length === 2 && re.runes[0] === re.runes[1]) {
			if (this.maybeConcat(re.runes[0], this.flags & ~RE2Flags.FOLD_CASE)) return null;
			re.op = Regexp.Op.LITERAL;
			re.runes = [re.runes[0]];
			re.flags = this.flags & ~RE2Flags.FOLD_CASE;
		} else if (re.op === Regexp.Op.CHAR_CLASS && re.runes.length === 4 && re.runes[0] === re.runes[1] && re.runes[2] === re.runes[3] && Unicode.simpleFold(re.runes[0]) === re.runes[2] && Unicode.simpleFold(re.runes[2]) === re.runes[0] || re.op === Regexp.Op.CHAR_CLASS && re.runes.length === 2 && re.runes[0] + 1 === re.runes[1] && Unicode.simpleFold(re.runes[0]) === re.runes[1] && Unicode.simpleFold(re.runes[1]) === re.runes[0]) {
			if (this.maybeConcat(re.runes[0], this.flags | RE2Flags.FOLD_CASE)) return null;
			re.op = Regexp.Op.LITERAL;
			re.runes = [re.runes[0]];
			re.flags = this.flags | RE2Flags.FOLD_CASE;
		} else this.maybeConcat(-1, 0);
		this.stack.push(re);
		this.checkLimits(re);
		return re;
	}
	maybeConcat(r, flags) {
		const n = this.stack.length;
		if (n < 2) return false;
		const re1 = this.stack[n - 1];
		const re2 = this.stack[n - 2];
		if (re1.op !== Regexp.Op.LITERAL || re2.op !== Regexp.Op.LITERAL || (re1.flags & RE2Flags.FOLD_CASE) !== (re2.flags & RE2Flags.FOLD_CASE)) return false;
		re2.runes = Parser.concatRunes(re2.runes, re1.runes);
		if (r >= 0) {
			re1.runes = [r];
			re1.flags = flags;
			return true;
		}
		this.pop();
		this.reuse(re1);
		return false;
	}
	newLiteral(r, flags) {
		const re = this.newRegexp(Regexp.Op.LITERAL);
		re.flags = flags;
		if ((flags & RE2Flags.FOLD_CASE) !== 0) r = Parser.minFoldRune(r);
		re.runes = [r];
		return re;
	}
	literal(r) {
		this.push(this.newLiteral(r, this.flags));
	}
	op(op) {
		const re = this.newRegexp(op);
		re.flags = this.flags;
		return this.push(re);
	}
	repeat(op, min, max, beforePos, t, lastRepeatPos) {
		let flags = this.flags;
		if ((flags & RE2Flags.PERL_X) !== 0) {
			if (t.more() && t.lookingAt("?")) {
				t.skip(1);
				flags ^= RE2Flags.NON_GREEDY;
			}
			if (lastRepeatPos !== -1) throw new RE2JSSyntaxException(Parser.ERR_INVALID_REPEAT_OP, t.from(lastRepeatPos));
		}
		const n = this.stack.length;
		if (n === 0) throw new RE2JSSyntaxException(Parser.ERR_MISSING_REPEAT_ARGUMENT, t.from(beforePos));
		const sub = this.stack[n - 1];
		if (Regexp.isPseudoOp(sub.op)) throw new RE2JSSyntaxException(Parser.ERR_MISSING_REPEAT_ARGUMENT, t.from(beforePos));
		const re = this.newRegexp(op);
		re.min = min;
		re.max = max;
		re.flags = flags;
		re.subs = [sub];
		this.stack[n - 1] = re;
		this.checkLimits(re);
		if (op === Regexp.Op.REPEAT && (min >= 2 || max >= 2) && !this.repeatIsValid(re, 1e3)) throw new RE2JSSyntaxException(Parser.ERR_INVALID_REPEAT_SIZE, t.from(beforePos));
	}
	repeatIsValid(re, n) {
		if (re.op === Regexp.Op.REPEAT) {
			let m = re.max;
			if (m === 0) return true;
			if (m < 0) m = re.min;
			if (m > n) return false;
			if (m > 0) n = Math.trunc(n / m);
		}
		for (let sub of re.subs) if (!this.repeatIsValid(sub, n)) return false;
		return true;
	}
	concat() {
		this.maybeConcat(-1, 0);
		const subs = this.popToPseudo();
		if (subs.length === 0) return this.push(this.newRegexp(Regexp.Op.EMPTY_MATCH));
		return this.push(this.collapse(subs, Regexp.Op.CONCAT));
	}
	alternate() {
		const subs = this.popToPseudo();
		if (subs.length > 0) this.cleanAlt(subs[subs.length - 1]);
		if (subs.length === 0) return this.push(this.newRegexp(Regexp.Op.NO_MATCH));
		return this.push(this.collapse(subs, Regexp.Op.ALTERNATE));
	}
	cleanAlt(re) {
		if (re.op === Regexp.Op.CHAR_CLASS) {
			re.runes = new CharClass(re.runes).cleanClass().toArray();
			if (re.runes.length === 2 && re.runes[0] === 0 && re.runes[1] === Unicode.MAX_RUNE) {
				re.runes = [];
				re.op = Regexp.Op.ANY_CHAR;
			} else if (re.runes.length === 4 && re.runes[0] === 0 && re.runes[1] === Codepoint.CODES.get("\n") - 1 && re.runes[2] === Codepoint.CODES.get("\n") + 1 && re.runes[3] === Unicode.MAX_RUNE) {
				re.runes = [];
				re.op = Regexp.Op.ANY_CHAR_NOT_NL;
			}
		}
	}
	collapse(subs, op) {
		if (subs.length === 1) return subs[0];
		let len = 0;
		for (let sub of subs) len += sub.op === op ? sub.subs.length : 1;
		let newsubs = new Array(len).fill(null);
		let i = 0;
		for (let sub of subs) if (sub.op === op) {
			for (let j = 0; j < sub.subs.length; j++) newsubs[i++] = sub.subs[j];
			this.reuse(sub);
		} else newsubs[i++] = sub;
		let re = this.newRegexp(op);
		re.subs = newsubs;
		if (op === Regexp.Op.ALTERNATE) {
			re.subs = this.factor(re.subs);
			if (re.subs.length === 1) {
				const old = re;
				re = re.subs[0];
				this.reuse(old);
			}
		}
		return re;
	}
	factor(array) {
		if (array.length < 2) return array;
		let s = 0;
		let lensub = array.length;
		let lenout = 0;
		let str = null;
		let strlen = 0;
		let strflags = 0;
		let start = 0;
		for (let i = 0; i <= lensub; i++) {
			let istr = null;
			let istrlen = 0;
			let iflags = 0;
			if (i < lensub) {
				let re = array[s + i];
				if (re.op === Regexp.Op.CONCAT && re.subs.length > 0) re = re.subs[0];
				if (re.op === Regexp.Op.LITERAL) {
					istr = re.runes;
					istrlen = re.runes.length;
					iflags = re.flags & RE2Flags.FOLD_CASE;
				}
				if (iflags === strflags) {
					let same = 0;
					while (same < strlen && same < istrlen && str[same] === istr[same]) same++;
					if (same > 0) {
						strlen = same;
						continue;
					}
				}
			}
			if (i === start) {} else if (i === start + 1) array[lenout++] = array[s + start];
			else {
				const prefix = this.newRegexp(Regexp.Op.LITERAL);
				prefix.flags = strflags;
				prefix.runes = str.slice(0, strlen);
				for (let j = start; j < i; j++) {
					array[s + j] = this.removeLeadingString(array[s + j], strlen);
					this.checkLimits(array[s + j]);
				}
				const suffix = this.collapse(array.slice(s + start, s + i), Regexp.Op.ALTERNATE);
				const re = this.newRegexp(Regexp.Op.CONCAT);
				re.subs = [prefix, suffix];
				array[lenout++] = re;
			}
			start = i;
			str = istr;
			strlen = istrlen;
			strflags = iflags;
		}
		lensub = lenout;
		s = 0;
		start = 0;
		lenout = 0;
		let first = null;
		for (let i = 0; i <= lensub; i++) {
			let ifirst = null;
			if (i < lensub) {
				ifirst = Parser.leadingRegexp(array[s + i]);
				if (first !== null && first.equals(ifirst) && (Parser.isCharClass(first) || first.op === Regexp.Op.REPEAT && first.min === first.max && Parser.isCharClass(first.subs[0]))) continue;
			}
			if (i === start) {} else if (i === start + 1) array[lenout++] = array[s + start];
			else {
				const prefix = first;
				for (let j = start; j < i; j++) {
					const reuse = j !== start;
					array[s + j] = this.removeLeadingRegexp(array[s + j], reuse);
					this.checkLimits(array[s + j]);
				}
				const suffix = this.collapse(array.slice(s + start, s + i), Regexp.Op.ALTERNATE);
				const re = this.newRegexp(Regexp.Op.CONCAT);
				re.subs = [prefix, suffix];
				array[lenout++] = re;
			}
			start = i;
			first = ifirst;
		}
		lensub = lenout;
		s = 0;
		start = 0;
		lenout = 0;
		for (let i = 0; i <= lensub; i++) {
			if (i < lensub && Parser.isCharClass(array[s + i])) continue;
			if (i === start) {} else if (i === start + 1) array[lenout++] = array[s + start];
			else {
				let max = start;
				for (let j = start + 1; j < i; j++) {
					const subMax = array[s + max];
					const subJ = array[s + j];
					if (subMax.op < subJ.op || subMax.op === subJ.op && (subMax.runes !== null ? subMax.runes.length : 0) < (subJ.runes !== null ? subJ.runes.length : 0)) max = j;
				}
				const tmp = array[s + start];
				array[s + start] = array[s + max];
				array[s + max] = tmp;
				for (let j = start + 1; j < i; j++) {
					Parser.mergeCharClass(array[s + start], array[s + j]);
					this.reuse(array[s + j]);
				}
				this.cleanAlt(array[s + start]);
				array[lenout++] = array[s + start];
			}
			if (i < lensub) array[lenout++] = array[s + i];
			start = i + 1;
		}
		lensub = lenout;
		s = 0;
		start = 0;
		lenout = 0;
		for (let i = 0; i < lensub; ++i) {
			if (i + 1 < lensub && array[s + i].op === Regexp.Op.EMPTY_MATCH && array[s + i + 1].op === Regexp.Op.EMPTY_MATCH) continue;
			array[lenout++] = array[s + i];
		}
		lensub = lenout;
		s = 0;
		return array.slice(s, lensub);
	}
	removeLeadingString(re, n) {
		if (re.op === Regexp.Op.CONCAT && re.subs.length > 0) {
			const sub = this.removeLeadingString(re.subs[0], n);
			re.subs[0] = sub;
			if (sub.op === Regexp.Op.EMPTY_MATCH) {
				this.reuse(sub);
				switch (re.subs.length) {
					case 0:
					case 1:
						re.op = Regexp.Op.EMPTY_MATCH;
						re.subs = Regexp.emptySubs();
						break;
					case 2: {
						const old = re;
						re = re.subs[1];
						this.reuse(old);
						break;
					}
					default: re.subs = re.subs.slice(1, re.subs.length);
				}
			}
			return re;
		}
		if (re.op === Regexp.Op.LITERAL) {
			re.runes = re.runes.slice(n, re.runes.length);
			if (re.runes.length === 0) re.op = Regexp.Op.EMPTY_MATCH;
		}
		return re;
	}
	removeLeadingRegexp(re, reuse) {
		if (re.op === Regexp.Op.CONCAT && re.subs.length > 0) {
			if (reuse) this.reuse(re.subs[0]);
			re.subs = re.subs.slice(1, re.subs.length);
			switch (re.subs.length) {
				case 0:
					re.op = Regexp.Op.EMPTY_MATCH;
					re.subs = Regexp.emptySubs();
					break;
				case 1: {
					const old = re;
					re = re.subs[0];
					this.reuse(old);
					break;
				}
			}
			return re;
		}
		if (reuse) this.reuse(re);
		return this.newRegexp(Regexp.Op.EMPTY_MATCH);
	}
	parseInternal() {
		if ((this.flags & RE2Flags.LITERAL) !== 0) return Parser.literalRegexp(this.wholeRegexp, this.flags);
		let lastRepeatPos = -1;
		let min = -1;
		let max = -1;
		const t = new StringIterator(this.wholeRegexp);
		while (t.more()) {
			let repeatPos = -1;
			bigswitch: switch (t.peek()) {
				case Codepoint.CODES.get("("):
					if ((this.flags & RE2Flags.LOOKBEHIND) !== 0) {
						if (t.lookingAt("(?<=")) {
							this.parsePosLookBehind();
							t.skip(4);
							break;
						}
						if (t.lookingAt("(?<!")) {
							this.parseNegLookBehind();
							t.skip(4);
							break;
						}
					}
					if ((this.flags & RE2Flags.PERL_X) !== 0 && t.lookingAt("(?")) {
						this.parsePerlFlags(t);
						break;
					}
					this.op(Regexp.Op.LEFT_PAREN).cap = ++this.numCap;
					t.skip(1);
					break;
				case Codepoint.CODES.get("|"):
					this.parseVerticalBar();
					t.skip(1);
					break;
				case Codepoint.CODES.get(")"):
					this.parseRightParen();
					t.skip(1);
					break;
				case Codepoint.CODES.get("^"):
					if ((this.flags & RE2Flags.ONE_LINE) !== 0) this.op(Regexp.Op.BEGIN_TEXT);
					else this.op(Regexp.Op.BEGIN_LINE);
					t.skip(1);
					break;
				case Codepoint.CODES.get("$"):
					if ((this.flags & RE2Flags.ONE_LINE) !== 0) this.op(Regexp.Op.END_TEXT).flags |= RE2Flags.WAS_DOLLAR;
					else this.op(Regexp.Op.END_LINE);
					t.skip(1);
					break;
				case Codepoint.CODES.get("."):
					if ((this.flags & RE2Flags.DOT_NL) !== 0) this.op(Regexp.Op.ANY_CHAR);
					else this.op(Regexp.Op.ANY_CHAR_NOT_NL);
					t.skip(1);
					break;
				case Codepoint.CODES.get("["):
					this.parseClass(t);
					break;
				case Codepoint.CODES.get("*"):
				case Codepoint.CODES.get("+"):
				case Codepoint.CODES.get("?"): {
					repeatPos = t.pos();
					let op = null;
					switch (t.pop()) {
						case Codepoint.CODES.get("*"):
							op = Regexp.Op.STAR;
							break;
						case Codepoint.CODES.get("+"):
							op = Regexp.Op.PLUS;
							break;
						case Codepoint.CODES.get("?"): op = Regexp.Op.QUEST;
					}
					this.repeat(op, min, max, repeatPos, t, lastRepeatPos);
					break;
				}
				case Codepoint.CODES.get("{"): {
					repeatPos = t.pos();
					const minMax = Parser.parseRepeat(t);
					if (minMax < 0) {
						t.rewindTo(repeatPos);
						this.literal(t.pop());
						break;
					}
					min = minMax >> 16;
					max = (minMax & Unicode.MAX_BMP) << 16 >> 16;
					this.repeat(Regexp.Op.REPEAT, min, max, repeatPos, t, lastRepeatPos);
					break;
				}
				case Codepoint.CODES.get("\\"): {
					const savedPos = t.pos();
					t.skip(1);
					if ((this.flags & RE2Flags.PERL_X) !== 0 && t.more()) switch (t.pop()) {
						case Codepoint.CODES.get("A"):
							this.op(Regexp.Op.BEGIN_TEXT);
							break bigswitch;
						case Codepoint.CODES.get("b"):
							this.op(Regexp.Op.WORD_BOUNDARY);
							break bigswitch;
						case Codepoint.CODES.get("B"):
							this.op(Regexp.Op.NO_WORD_BOUNDARY);
							break bigswitch;
						case Codepoint.CODES.get("C"): throw new RE2JSSyntaxException(Parser.ERR_INVALID_ESCAPE, "\\C");
						case Codepoint.CODES.get("Q"): {
							let lit = t.rest();
							const i = lit.indexOf("\\E");
							if (i >= 0) {
								lit = lit.substring(0, i);
								t.skipString(lit);
								t.skipString("\\E");
							} else t.skipString(lit);
							let j = 0;
							while (j < lit.length) {
								const codepoint = lit.codePointAt(j);
								this.literal(codepoint);
								j += Utils.charCount(codepoint);
							}
							break bigswitch;
						}
						case Codepoint.CODES.get("z"):
							this.op(Regexp.Op.END_TEXT);
							break bigswitch;
						default:
							t.rewindTo(savedPos);
							break;
					}
					else t.rewindTo(savedPos);
					const re = this.newRegexp(Regexp.Op.CHAR_CLASS);
					re.flags = this.flags;
					if (t.lookingAt("\\p") || t.lookingAt("\\P")) {
						const cc = new CharClass();
						if (this.parseUnicodeClass(t, cc)) {
							re.runes = cc.toArray();
							this.push(re);
							break bigswitch;
						}
					}
					const cc = new CharClass();
					if (this.parsePerlClassEscape(t, cc)) {
						re.runes = cc.toArray();
						this.push(re);
						break bigswitch;
					}
					t.rewindTo(savedPos);
					this.reuse(re);
					this.literal(Parser.parseEscape(t));
					break;
				}
				default: this.literal(t.pop());
			}
			lastRepeatPos = repeatPos;
		}
		this.concat();
		if (this.swapVerticalBar()) this.pop();
		this.alternate();
		if (this.stack.length !== 1) throw new RE2JSSyntaxException(Parser.ERR_MISSING_PAREN, this.wholeRegexp);
		this.stack[0].namedGroups = this.namedGroups;
		return this.stack[0];
	}
	parsePerlFlags(t) {
		const startPos = t.pos();
		const s = t.rest();
		if (s.startsWith("(?P<") || s.startsWith("(?<")) {
			const begin = s.charAt(2) === "P" ? 4 : 3;
			const end = s.indexOf(">");
			if (end < 0) throw new RE2JSSyntaxException(Parser.ERR_INVALID_NAMED_CAPTURE, s);
			const name = s.substring(begin, end);
			t.skipString(name);
			t.skip(begin + 1);
			if (!Parser.isValidCaptureName(name)) throw new RE2JSSyntaxException(Parser.ERR_INVALID_NAMED_CAPTURE, s.substring(0, end + 1));
			const re = this.op(Regexp.Op.LEFT_PAREN);
			re.cap = ++this.numCap;
			if (this.namedGroups[name]) throw new RE2JSSyntaxException(Parser.ERR_DUPLICATE_NAMED_CAPTURE, name);
			this.namedGroups[name] = this.numCap;
			re.name = name;
			return;
		}
		t.skip(2);
		let flags = this.flags;
		let sign = 1;
		let sawFlag = false;
		loop: while (t.more()) {
			const c = t.pop();
			switch (c) {
				case Codepoint.CODES.get("i"):
					flags |= RE2Flags.FOLD_CASE;
					sawFlag = true;
					break;
				case Codepoint.CODES.get("m"):
					flags &= ~RE2Flags.ONE_LINE;
					sawFlag = true;
					break;
				case Codepoint.CODES.get("s"):
					flags |= RE2Flags.DOT_NL;
					sawFlag = true;
					break;
				case Codepoint.CODES.get("U"):
					flags |= RE2Flags.NON_GREEDY;
					sawFlag = true;
					break;
				case Codepoint.CODES.get("-"):
					if (sign < 0) break loop;
					sign = -1;
					flags = ~flags;
					sawFlag = false;
					break;
				case Codepoint.CODES.get(":"):
				case Codepoint.CODES.get(")"):
					if (sign < 0) {
						if (!sawFlag) break loop;
						flags = ~flags;
					}
					if (c === Codepoint.CODES.get(":")) this.op(Regexp.Op.LEFT_PAREN);
					this.flags = flags;
					return;
				default: break loop;
			}
		}
		throw new RE2JSSyntaxException(Parser.ERR_INVALID_PERL_OP, t.from(startPos));
	}
	parsePosLookBehind() {
		const re = this.newRegexp(Regexp.Op.LEFT_PAREN);
		re.flags = this.flags;
		re.lb = ++this.nlb;
		return this.push(re);
	}
	parseNegLookBehind() {
		const re = this.newRegexp(Regexp.Op.LEFT_PAREN);
		re.flags = this.flags;
		re.lb = -++this.nlb;
		return this.push(re);
	}
	parseVerticalBar() {
		this.concat();
		if (!this.swapVerticalBar()) this.op(Regexp.Op.VERTICAL_BAR);
	}
	swapVerticalBar() {
		const n = this.stack.length;
		if (n >= 3 && this.stack[n - 2].op === Regexp.Op.VERTICAL_BAR && Parser.isCharClass(this.stack[n - 1]) && Parser.isCharClass(this.stack[n - 3])) {
			let re1 = this.stack[n - 1];
			let re3 = this.stack[n - 3];
			if (re1.op > re3.op) {
				const tmp = re3;
				re3 = re1;
				re1 = tmp;
				this.stack[n - 3] = re3;
			}
			Parser.mergeCharClass(re3, re1);
			this.reuse(re1);
			this.pop();
			return true;
		}
		if (n >= 2) {
			const re1 = this.stack[n - 1];
			const re2 = this.stack[n - 2];
			if (re2.op === Regexp.Op.VERTICAL_BAR) {
				if (n >= 3) this.cleanAlt(this.stack[n - 3]);
				this.stack[n - 2] = re1;
				this.stack[n - 1] = re2;
				return true;
			}
		}
		return false;
	}
	parseRightParen() {
		this.concat();
		if (this.swapVerticalBar()) this.pop();
		this.alternate();
		if (this.stack.length < 2) throw new RE2JSSyntaxException(Parser.ERR_UNEXPECTED_PAREN, this.wholeRegexp);
		const re1 = this.pop();
		const re2 = this.pop();
		if (re2.op !== Regexp.Op.LEFT_PAREN) throw new RE2JSSyntaxException(Parser.ERR_UNEXPECTED_PAREN, this.wholeRegexp);
		this.flags = re2.flags;
		if (re2.lb !== 0) {
			if (Parser.hasCapture(re1)) throw new RE2JSSyntaxException(Parser.ERR_INVALID_CAPTURE_IN_LOOKBEHIND, this.wholeRegexp);
			if (re2.lb > 0) re2.op = Regexp.Op.PLB;
			else re2.op = Regexp.Op.NLB;
			re2.subs = [re1];
			this.push(re2);
			return;
		}
		if (re2.cap === 0) this.push(re1);
		else {
			re2.op = Regexp.Op.CAPTURE;
			re2.subs = [re1];
			this.push(re2);
		}
	}
	parsePerlClassEscape(t, cc) {
		const beforePos = t.pos();
		if ((this.flags & RE2Flags.PERL_X) === 0 || !t.more() || t.pop() !== Codepoint.CODES.get("\\") || !t.more()) return false;
		t.pop();
		const p = t.from(beforePos);
		const g = PERL_GROUPS.has(p) ? PERL_GROUPS.get(p) : null;
		if (g === null) return false;
		cc.appendGroup(g, (this.flags & RE2Flags.FOLD_CASE) !== 0);
		return true;
	}
	parseNamedClass(t, cc) {
		const cls = t.rest();
		const i = cls.indexOf(":]");
		if (i < 0) return false;
		const name = cls.substring(0, i + 2);
		t.skipString(name);
		const g = POSIX_GROUPS.has(name) ? POSIX_GROUPS.get(name) : null;
		if (g === null) throw new RE2JSSyntaxException(Parser.ERR_INVALID_CHAR_RANGE, name);
		cc.appendGroup(g, (this.flags & RE2Flags.FOLD_CASE) !== 0);
		return true;
	}
	parseUnicodeClass(t, cc) {
		const startPos = t.pos();
		if ((this.flags & RE2Flags.UNICODE_GROUPS) === 0 || !t.lookingAt("\\p") && !t.lookingAt("\\P")) return false;
		t.skip(1);
		let sign = 1;
		let c = t.pop();
		if (c === Codepoint.CODES.get("P")) sign = -1;
		if (!t.more()) {
			t.rewindTo(startPos);
			throw new RE2JSSyntaxException(Parser.ERR_INVALID_CHAR_RANGE, t.rest());
		}
		c = t.pop();
		let name;
		if (c !== Codepoint.CODES.get("{")) name = Utils.runeToString(c);
		else {
			const rest = t.rest();
			const end = rest.indexOf("}");
			if (end < 0) {
				t.rewindTo(startPos);
				throw new RE2JSSyntaxException(Parser.ERR_INVALID_CHAR_RANGE, t.rest());
			}
			name = rest.substring(0, end);
			t.skipString(name);
			t.skip(1);
		}
		if (!(name.length === 0) && name.codePointAt(0) === Codepoint.CODES.get("^")) {
			sign = 0 - sign;
			name = name.substring(1);
		}
		const pair = Parser.unicodeTable(name);
		if (pair === null) throw new RE2JSSyntaxException(Parser.ERR_INVALID_CHAR_RANGE, t.from(startPos));
		if (pair.sign < 0) sign = 0 - sign;
		const tab = pair.tab;
		const fold = pair.fold;
		if ((this.flags & RE2Flags.FOLD_CASE) === 0 || fold === null) cc.appendTableWithSign(tab, sign);
		else {
			const tmp = new CharClass().appendTable(tab).appendTable(fold).cleanClass().toArray();
			cc.appendClassWithSign(tmp, sign);
		}
		return true;
	}
	parseClass(t) {
		const startPos = t.pos();
		t.skip(1);
		const re = this.newRegexp(Regexp.Op.CHAR_CLASS);
		re.flags = this.flags;
		const cc = new CharClass();
		let sign = 1;
		if (t.more() && t.lookingAt("^")) {
			sign = -1;
			t.skip(1);
			if ((this.flags & RE2Flags.CLASS_NL) === 0) cc.appendRange(Codepoint.CODES.get("\n"), Codepoint.CODES.get("\n"));
		}
		let first = true;
		while (!t.more() || t.peek() !== Codepoint.CODES.get("]") || first) {
			if (t.more() && t.lookingAt("-") && (this.flags & RE2Flags.PERL_X) === 0 && !first) {
				const s = t.rest();
				if (s === "-" || !s.startsWith("-]")) {
					t.rewindTo(startPos);
					throw new RE2JSSyntaxException(Parser.ERR_INVALID_CHAR_RANGE, t.rest());
				}
			}
			first = false;
			const beforePos = t.pos();
			if (t.lookingAt("[:")) {
				if (this.parseNamedClass(t, cc)) continue;
				t.rewindTo(beforePos);
			}
			if (this.parseUnicodeClass(t, cc)) continue;
			if (this.parsePerlClassEscape(t, cc)) continue;
			t.rewindTo(beforePos);
			const lo = Parser.parseClassChar(t, startPos);
			let hi = lo;
			if (t.more() && t.lookingAt("-")) {
				t.skip(1);
				if (t.more() && t.lookingAt("]")) t.skip(-1);
				else {
					hi = Parser.parseClassChar(t, startPos);
					if (hi < lo) throw new RE2JSSyntaxException(Parser.ERR_INVALID_CHAR_RANGE, t.from(beforePos));
				}
			}
			if ((this.flags & RE2Flags.FOLD_CASE) === 0) cc.appendRange(lo, hi);
			else cc.appendFoldedRange(lo, hi);
		}
		t.skip(1);
		cc.cleanClass();
		if (sign < 0) cc.negateClass();
		re.runes = cc.toArray();
		this.push(re);
	}
};
/**
* An RE2 class instance is a compiled representation of an RE2 regular expression, independent of
* the public Java-like Pattern/Matcher API.
*
* This class also contains various implementation helpers for RE2 regular expressions.
*
* Use the {@link #quoteMeta(String)} utility function to quote all regular expression
* metacharacters in an arbitrary string.
*
*/
var RE2 = class RE2 {
	static initTest(expr) {
		const re2 = RE2.compile(expr);
		const res = new RE2(re2.expr, re2.prog, re2.numSubexp, re2.longest);
		res.cond = re2.cond;
		res.prefix = re2.prefix;
		res.prefixUTF8 = re2.prefixUTF8;
		res.prefixComplete = re2.prefixComplete;
		res.prefixRune = re2.prefixRune;
		res.prefilter = re2.prefilter;
		return res;
	}
	/**
	* Parses a regular expression and returns, if successful, an {@code RE2} instance that can be
	* used to match against text.
	*
	* When matching against text, the regexp returns a match that begins as early as possible in the
	* input (leftmost), and among those it chooses the one that a backtracking search would have
	* found first. This so-called leftmost-first matching is the same semantics that Perl, Python,
	* and other implementations use, although this package implements it without the expense of
	* backtracking. For POSIX leftmost-longest matching, see {@link #compilePOSIX}.
	*/
	static compile(expr) {
		return RE2.compileImpl(expr, RE2Flags.PERL, false);
	}
	/**
	* {@code compilePOSIX} is like {@link #compile} but restricts the regular expression to POSIX ERE
	* (egrep) syntax and changes the match semantics to leftmost-longest.
	*
	* That is, when matching against text, the regexp returns a match that begins as early as
	* possible in the input (leftmost), and among those it chooses a match that is as long as
	* possible. This so-called leftmost-longest matching is the same semantics that early regular
	* expression implementations used and that POSIX specifies.
	*
	* However, there can be multiple leftmost-longest matches, with different submatch choices, and
	* here this package diverges from POSIX. Among the possible leftmost-longest matches, this
	* package chooses the one that a backtracking search would have found first, while POSIX
	* specifies that the match be chosen to maximize the length of the first subexpression, then the
	* second, and so on from left to right. The POSIX rule is computationally prohibitive and not
	* even well-defined. See http://swtch.com/~rsc/regexp/regexp2.html#posix
	*/
	static compilePOSIX(expr) {
		return RE2.compileImpl(expr, RE2Flags.POSIX, true);
	}
	static compileImpl(expr, mode, longest) {
		let re = Parser.parse(expr, mode);
		const maxCap = re.maxCap();
		re = Simplify.simplify(re);
		const prefilter = PrefilterTree.build(re);
		const prog = Compiler.compileRegexp(re);
		const re2 = new RE2(expr, prog, maxCap, longest);
		re2.prefilter = prefilter.type === Prefilter.Type.NONE ? null : prefilter;
		const [prefixCompl, prefixStr] = prog.prefix();
		re2.prefixComplete = prefixCompl;
		re2.prefix = prefixStr;
		re2.prefixUTF8 = Utils.stringToUtf8ByteArray(re2.prefix);
		if (re2.prefix.length > 0) re2.prefixRune = re2.prefix.codePointAt(0);
		re2.namedGroups = re.namedGroups;
		return re2;
	}
	/**
	* Returns true iff textual regular expression {@code pattern} matches string {@code s}.
	*
	* More complicated queries need to use {@link #compile} and the full {@code RE2} interface.
	*/
	static match(pattern, s) {
		return RE2.compile(pattern).match(s);
	}
	constructor(expr, prog, numSubexp = 0, longest = 0) {
		this.expr = expr;
		this.prog = prog;
		this.numSubexp = numSubexp;
		this.longest = longest;
		this.cond = prog.startCond();
		this.prefix = null;
		this.prefixUTF8 = null;
		this.prefixComplete = false;
		this.prefixRune = 0;
		this.machinePool = [];
		this.dfa = new DFA(this.prog);
		this.onepass = OnePass.compile(this.prog);
		this.prefilter = null;
	}
	matchPrefixComplete(input, pos, anchor, ncap) {
		if ((anchor === RE2Flags.ANCHOR_START || anchor === RE2Flags.ANCHOR_BOTH) && pos !== 0) return null;
		let matchStart = -1;
		let matchEnd = -1;
		const pLen = input.prefixLength(this);
		if (anchor === RE2Flags.UNANCHORED) {
			const idx = input.index(this, pos);
			if (idx < 0) return null;
			matchStart = pos + idx;
			matchEnd = matchStart + pLen;
		} else if (anchor === RE2Flags.ANCHOR_BOTH) {
			if (input.endPos() !== pLen) return null;
			if (input.index(this, 0) !== 0) return null;
			matchStart = 0;
			matchEnd = pLen;
		} else if (anchor === RE2Flags.ANCHOR_START) {
			if (input.index(this, 0) !== 0) return null;
			matchStart = 0;
			matchEnd = pLen;
		}
		if (matchStart < 0) return null;
		if (ncap > 0) {
			const matchcap = new Int32Array(ncap).fill(-1);
			matchcap[0] = matchStart;
			matchcap[1] = matchEnd;
			return Array.from(matchcap);
		}
		return [];
	}
	executeEngine(input, pos, anchor, ncap) {
		if (this.prefixComplete && (ncap === 0 || this.numSubexp === 0)) return this.matchPrefixComplete(input, pos, anchor, ncap);
		if (this.prefilter !== null && anchor === RE2Flags.UNANCHORED) {
			if (!this.prefilter.eval(input, pos)) return null;
		}
		if (this.onepass !== null) return OnePass.execute(this, input, pos, anchor, ncap);
		if (ncap > 0) {
			if (this.prog.numLb === 0 && input.endPos() <= Backtracker.maxBitStateLen(this.prog)) return Backtracker.execute(this, input, pos, anchor, ncap);
			return this.doExecuteNFA(input, pos, anchor, ncap);
		}
		if (this.prog.numLb === 0) {
			const dfaResult = this.dfa.match(input, pos, anchor);
			if (dfaResult !== null) return dfaResult ? [] : null;
			if (input.endPos() <= Backtracker.maxBitStateLen(this.prog)) return Backtracker.execute(this, input, pos, anchor, ncap);
		}
		return this.doExecuteNFA(input, pos, anchor, ncap);
	}
	/**
	* Returns the number of parenthesized subexpressions in this regular expression.
	*/
	numberOfCapturingGroups() {
		return this.numSubexp;
	}
	/**
	* Returns the number of instructions in this compiled regular expression program.
	*/
	numberOfInstructions() {
		return this.prog.numInst();
	}
	get() {
		return this.machinePool.length > 0 ? this.machinePool.pop() : null;
	}
	reset() {
		this.machinePool.length = 0;
	}
	put(m) {
		this.machinePool.push(m);
	}
	toString() {
		return this.expr;
	}
	doExecuteNFA(input, pos, anchor, ncap) {
		let m = this.get();
		if (!m) m = Machine.fromRE2(this);
		m.init(ncap);
		const cap = m.match(input, pos, anchor) ? m.submatches() : null;
		this.put(m);
		return cap;
	}
	match(s) {
		return this.executeEngine(MachineInput.fromUTF16(s), 0, RE2Flags.UNANCHORED, 0) !== null;
	}
	/**
	* Matches the regular expression against input starting at position start and ending at position
	* end, with the given anchoring. Records the submatch boundaries in group, which is [start, end)
	* pairs of byte offsets. The number of boundaries needed is inferred from the size of the group
	* array. It is most efficient not to ask for submatch boundaries.
	*
	* @param input the input byte array
	* @param start the beginning position in the input
	* @param end the end position in the input
	* @param anchor the anchoring flag (UNANCHORED, ANCHOR_START, ANCHOR_BOTH)
	* @param group the array to fill with submatch positions
	* @param ngroup the number of array pairs to fill in
	* @returns true if a match was found
	*/
	matchWithGroup(input, start, end, anchor, ngroup) {
		if (!(input instanceof MatcherInputBase)) if (Utils.isByteArray(input)) input = MatcherInput.utf8(input);
		else input = MatcherInput.utf16(input);
		return this.matchMachineInput(input, start, end, anchor, ngroup);
	}
	matchMachineInput(input, start, end, anchor, ngroup) {
		if (start > end) return [false, null];
		const machineInput = input.isUTF16Encoding() ? MachineInput.fromUTF16(input.asCharSequence(), 0, end) : MachineInput.fromUTF8(input.asBytes(), 0, end);
		const groupMatch = this.executeEngine(machineInput, start, anchor, 2 * ngroup);
		if (groupMatch === null) return [false, null];
		return [true, groupMatch];
	}
	/**
	* Returns true iff this regexp matches the UTF-8 byte array {@code b}.
	*/
	matchUTF8(b) {
		return this.executeEngine(MachineInput.fromUTF8(b), 0, RE2Flags.UNANCHORED, 0) !== null;
	}
	/**
	* Returns a copy of {@code src} in which all matches for this regexp have been replaced by
	* {@code repl}. No support is provided for expressions (e.g. {@code \1} or {@code $1}) in the
	* replacement string.
	*/
	replaceAll(src, repl) {
		return this.replaceAllFunc(src, () => repl, 2 * src.length + 1);
	}
	/**
	* Returns a copy of {@code src} in which only the first match for this regexp has been replaced
	* by {@code repl}. No support is provided for expressions (e.g. {@code \1} or {@code $1}) in the
	* replacement string.
	*/
	replaceFirst(src, repl) {
		return this.replaceAllFunc(src, () => repl, 1);
	}
	/**
	* Returns a copy of {@code src} in which at most {@code maxReplaces} matches for this regexp have
	* been replaced by the return value of of function {@code repl} (whose first argument is the
	* matched string). No support is provided for expressions (e.g. {@code \1} or {@code $1}) in the
	* replacement string.
	*/
	replaceAllFunc(src, replFunc, maxReplaces) {
		let lastMatchEnd = 0;
		let searchPos = 0;
		let out = "";
		const input = MachineInput.fromUTF16(src);
		let numReplaces = 0;
		while (searchPos <= src.length) {
			const a = this.executeEngine(input, searchPos, RE2Flags.UNANCHORED, 2);
			if (a === null || a.length === 0) break;
			out += src.substring(lastMatchEnd, a[0]);
			if (a[1] > lastMatchEnd || a[0] === 0) {
				out += replFunc(src.substring(a[0], a[1]));
				numReplaces++;
			}
			lastMatchEnd = a[1];
			const width = input.step(searchPos) & 7;
			if (searchPos + width > a[1]) searchPos += width;
			else if (searchPos + 1 > a[1]) searchPos++;
			else searchPos = a[1];
			if (numReplaces >= maxReplaces) break;
		}
		out += src.substring(lastMatchEnd);
		return out;
	}
	pad(a) {
		if (a === null) return null;
		let n = (1 + this.numSubexp) * 2;
		if (a.length < n) {
			let a2 = new Array(n).fill(-1);
			for (let i = 0; i < a.length; i++) a2[i] = a[i];
			a = a2;
		}
		return a;
	}
	allMatches(input, n, deliverFun = (v) => v) {
		let result = [];
		const end = input.endPos();
		if (n < 0) n = end + 1;
		let pos = 0;
		let i = 0;
		let prevMatchEnd = -1;
		while (i < n && pos <= end) {
			const matches = this.executeEngine(input, pos, RE2Flags.UNANCHORED, this.prog.numCap);
			if (matches === null || matches.length === 0) break;
			let accept = true;
			if (matches[1] === pos) {
				if (matches[0] === prevMatchEnd) accept = false;
				const r = input.step(pos);
				if (r < 0) pos = end + 1;
				else pos += r & 7;
			} else pos = matches[1];
			prevMatchEnd = matches[1];
			if (accept) {
				result.push(deliverFun(this.pad(matches)));
				i++;
			}
		}
		return result;
	}
	/**
	* Returns an array holding the text of the leftmost match in {@code b} of this regular
	* expression.
	*
	* A return value of null indicates no match.
	*/
	findUTF8(b) {
		const a = this.executeEngine(MachineInput.fromUTF8(b), 0, RE2Flags.UNANCHORED, 2);
		if (a === null) return null;
		return b.slice(a[0], a[1]);
	}
	/**
	* Returns a two-element array of integers defining the location of the leftmost match in
	* {@code b} of this regular expression. The match itself is at {@code b[loc[0]...loc[1]]}.
	*
	* A return value of null indicates no match.
	*/
	findUTF8Index(b) {
		const a = this.executeEngine(MachineInput.fromUTF8(b), 0, RE2Flags.UNANCHORED, 2);
		if (a === null) return null;
		return a.slice(0, 2);
	}
	/**
	* Returns a string holding the text of the leftmost match in {@code s} of this regular
	* expression.
	*
	* If there is no match, the return value is an empty string, but it will also be empty if the
	* regular expression successfully matches an empty string. Use {@link #findIndex} or
	* {@link #findSubmatch} if it is necessary to distinguish these cases.
	*/
	find(s) {
		const a = this.executeEngine(MachineInput.fromUTF16(s), 0, RE2Flags.UNANCHORED, 2);
		if (a === null) return "";
		return s.substring(a[0], a[1]);
	}
	/**
	* Returns a two-element array of integers defining the location of the leftmost match in
	* {@code s} of this regular expression. The match itself is at
	* {@code s.substring(loc[0], loc[1])}.
	*
	* A return value of null indicates no match.
	*/
	findIndex(s) {
		return this.executeEngine(MachineInput.fromUTF16(s), 0, RE2Flags.UNANCHORED, 2);
	}
	/**
	* Returns an array of arrays the text of the leftmost match of the regular expression in
	* {@code b} and the matches, if any, of its subexpressions, as defined by the <a
	* href='#submatch'>Submatch</a> description above.
	*
	* A return value of null indicates no match.
	*/
	findUTF8Submatch(b) {
		const a = this.executeEngine(MachineInput.fromUTF8(b), 0, RE2Flags.UNANCHORED, this.prog.numCap);
		if (a === null) return null;
		const ret = new Array(1 + this.numSubexp).fill(null);
		for (let i = 0; i < ret.length; i++) if (2 * i < a.length && a[2 * i] >= 0) ret[i] = b.slice(a[2 * i], a[2 * i + 1]);
		return ret;
	}
	/**
	* Returns an array holding the index pairs identifying the leftmost match of this regular
	* expression in {@code b} and the matches, if any, of its subexpressions, as defined by the the
	* <a href='#submatch'>Submatch</a> and <a href='#index'>Index</a> descriptions above.
	*
	* A return value of null indicates no match.
	*/
	findUTF8SubmatchIndex(b) {
		return this.pad(this.executeEngine(MachineInput.fromUTF8(b), 0, RE2Flags.UNANCHORED, this.prog.numCap));
	}
	/**
	* Returns an array of strings holding the text of the leftmost match of the regular expression in
	* {@code s} and the matches, if any, of its subexpressions, as defined by the <a
	* href='#submatch'>Submatch</a> description above.
	*
	* A return value of null indicates no match.
	*/
	findSubmatch(s) {
		const a = this.executeEngine(MachineInput.fromUTF16(s), 0, RE2Flags.UNANCHORED, this.prog.numCap);
		if (a === null) return null;
		const ret = new Array(1 + this.numSubexp).fill(null);
		for (let i = 0; i < ret.length; i++) if (2 * i < a.length && a[2 * i] >= 0) ret[i] = s.substring(a[2 * i], a[2 * i + 1]);
		return ret;
	}
	/**
	* Returns an array holding the index pairs identifying the leftmost match of this regular
	* expression in {@code s} and the matches, if any, of its subexpressions, as defined by the <a
	* href='#submatch'>Submatch</a> description above.
	*
	* A return value of null indicates no match.
	*/
	findSubmatchIndex(s) {
		return this.pad(this.executeEngine(MachineInput.fromUTF16(s), 0, RE2Flags.UNANCHORED, this.prog.numCap));
	}
	/**
	* {@code findAllUTF8()} is the <a href='#all'>All</a> version of {@link #findUTF8}; it returns a
	* list of up to {@code n} successive matches of the expression, as defined by the <a
	* href='#all'>All</a> description above.
	*
	* A return value of null indicates no match.
	*
	* TODO(adonovan): think about defining a byte slice view class, like a read-only Go slice backed
	* by |b|.
	*/
	findAllUTF8(b, n) {
		const result = this.allMatches(MachineInput.fromUTF8(b), n, (match) => b.slice(match[0], match[1]));
		if (result.length === 0) return null;
		return result;
	}
	/**
	* {@code findAllUTF8Index} is the <a href='#all'>All</a> version of {@link #findUTF8Index}; it
	* returns a list of up to {@code n} successive matches of the expression, as defined by the <a
	* href='#all'>All</a> description above.
	*
	* A return value of null indicates no match.
	*/
	findAllUTF8Index(b, n) {
		const result = this.allMatches(MachineInput.fromUTF8(b), n, (match) => match.slice(0, 2));
		if (result.length === 0) return null;
		return result;
	}
	/**
	* {@code findAll} is the <a href='#all'>All</a> version of {@link #find}; it returns a list of up
	* to {@code n} successive matches of the expression, as defined by the <a href='#all'>All</a>
	* description above.
	*
	* A return value of null indicates no match.
	*/
	findAll(s, n) {
		const result = this.allMatches(MachineInput.fromUTF16(s), n, (match) => s.substring(match[0], match[1]));
		if (result.length === 0) return null;
		return result;
	}
	/**
	* {@code findAllIndex} is the <a href='#all'>All</a> version of {@link #findIndex}; it returns a
	* list of up to {@code n} successive matches of the expression, as defined by the <a
	* href='#all'>All</a> description above.
	*
	* A return value of null indicates no match.
	*/
	findAllIndex(s, n) {
		const result = this.allMatches(MachineInput.fromUTF16(s), n, (match) => match.slice(0, 2));
		if (result.length === 0) return null;
		return result;
	}
	/**
	* {@code findAllUTF8Submatch} is the <a href='#all'>All</a> version of {@link #findUTF8Submatch};
	* it returns a list of up to {@code n} successive matches of the expression, as defined by the <a
	* href='#all'>All</a> description above.
	*
	* A return value of null indicates no match.
	*/
	findAllUTF8Submatch(b, n) {
		const result = this.allMatches(MachineInput.fromUTF8(b), n, (match) => {
			let slice = new Array(match.length / 2 | 0).fill(null);
			for (let j = 0; j < slice.length; j++) if (match[2 * j] >= 0) slice[j] = b.slice(match[2 * j], match[2 * j + 1]);
			return slice;
		});
		if (result.length === 0) return null;
		return result;
	}
	/**
	* {@code findAllUTF8SubmatchIndex} is the <a href='#all'>All</a> version of
	* {@link #findUTF8SubmatchIndex}; it returns a list of up to {@code n} successive matches of the
	* expression, as defined by the <a href='#all'>All</a> description above.
	*
	* A return value of null indicates no match.
	*/
	findAllUTF8SubmatchIndex(b, n) {
		const result = this.allMatches(MachineInput.fromUTF8(b), n);
		if (result.length === 0) return null;
		return result;
	}
	/**
	* {@code findAllSubmatch} is the <a href='#all'>All</a> version of {@link #findSubmatch}; it
	* returns a list of up to {@code n} successive matches of the expression, as defined by the <a
	* href='#all'>All</a> description above.
	*
	* A return value of null indicates no match.
	*/
	findAllSubmatch(s, n) {
		const result = this.allMatches(MachineInput.fromUTF16(s), n, (match) => {
			let slice = new Array(match.length / 2 | 0).fill(null);
			for (let j = 0; j < slice.length; j++) if (match[2 * j] >= 0) slice[j] = s.substring(match[2 * j], match[2 * j + 1]);
			return slice;
		});
		if (result.length === 0) return null;
		return result;
	}
	/**
	* {@code findAllSubmatchIndex} is the <a href='#all'>All</a> version of
	* {@link #findSubmatchIndex}; it returns a list of up to {@code n} successive matches of the
	* expression, as defined by the <a href='#all'>All</a> description above.
	*
	* A return value of null indicates no match.
	*/
	findAllSubmatchIndex(s, n) {
		const result = this.allMatches(MachineInput.fromUTF16(s), n);
		if (result.length === 0) return null;
		return result;
	}
};
(class RE2Set {
	/** @type {number} */
	static UNANCHORED = RE2Flags.UNANCHORED;
	/** @type {number} */
	static ANCHOR_START = RE2Flags.ANCHOR_START;
	/** @type {number} */
	static ANCHOR_BOTH = RE2Flags.ANCHOR_BOTH;
	/**
	* Constructs a new RE2Set with the specified anchor mode and flags.
	* @param {number} [anchor=RE2Set.UNANCHORED] - The anchoring mode (e.g., RE2Set.UNANCHORED).
	* @param {number} [flags=0] - The public flags to apply to all patterns in the set.
	* @param {number} [maxMem=8388608] - The maximum memory in bytes to use for the DFA (default 8MB).
	*/
	constructor(anchor = RE2Set.UNANCHORED, flags = 0, maxMem = 8388608) {
		this.anchor = anchor;
		this.jsFlags = flags;
		this.maxMem = maxMem;
		let re2Flags = RE2Flags.PERL;
		if ((flags & PublicFlags.DISABLE_UNICODE_GROUPS) !== 0) re2Flags &= ~RE2Flags.UNICODE_GROUPS;
		if ((flags & PublicFlags.LOOKBEHINDS) !== 0) re2Flags |= RE2Flags.LOOKBEHIND;
		this.re2Flags = re2Flags;
		this.regexps = [];
		this.prog = null;
		this.dfa = null;
		this.dummyRe2 = null;
	}
	/**
	* Adds a new regular expression pattern to the set.
	* Patterns cannot be added after the set has been compiled.
	* @param {string} pattern - The regular expression pattern to add.
	* @returns {number} The integer index assigned to the added pattern.
	* @throws {RE2JSCompileException} If patterns are added after compilation.
	*/
	add(pattern) {
		if (this.prog) throw new RE2JSCompileException("Cannot add patterns after compile");
		let fregex = pattern;
		if ((this.jsFlags & PublicFlags.CASE_INSENSITIVE) !== 0) fregex = `(?i)${fregex}`;
		if ((this.jsFlags & PublicFlags.DOTALL) !== 0) fregex = `(?s)${fregex}`;
		if ((this.jsFlags & PublicFlags.MULTILINE) !== 0) fregex = `(?m)${fregex}`;
		const re = Parser.parse(fregex, this.re2Flags);
		this.regexps.push(Simplify.simplify(re));
		return this.regexps.length - 1;
	}
	/**
	* Compiles the added patterns into a single state machine.
	* This is automatically called on the first match if not called explicitly.
	* @returns {void}
	*/
	compile() {
		if (this.prog) return;
		this.prog = Compiler.compileSet(this.regexps);
		this.dfa = new DFA(this.prog, this.maxMem);
		this.dummyRe2 = {
			prog: this.prog,
			cond: this.prog.startCond(),
			prefix: "",
			prefixRune: 0,
			longest: false
		};
	}
	/**
	* Matches the input against the compiled set of regular expressions.
	* @param {string|number[]|Uint8Array} input - The input string or UTF-8 byte array to match against.
	* @returns {number[]} An array of indices representing the patterns that successfully matched the input.
	*/
	match(input) {
		if (!this.prog) this.compile();
		const machineInput = Utils.isByteArray(input) ? MachineInput.fromUTF8(input) : MachineInput.fromUTF16(input);
		let internalAnchor = RE2Flags.UNANCHORED;
		if (this.anchor === RE2Set.ANCHOR_START) internalAnchor = RE2Flags.ANCHOR_START;
		else if (this.anchor === RE2Set.ANCHOR_BOTH) internalAnchor = RE2Flags.ANCHOR_BOTH;
		const dfaResult = this.dfa.matchSet(machineInput, 0, internalAnchor);
		if (dfaResult !== null) return dfaResult;
		const machine = Machine.fromRE2(this.dummyRe2);
		machine.init(0);
		return machine.matchSet(machineInput, 0, internalAnchor);
	}
});
/**
* Transform JS regex string to RE2 regex string
*/
var TranslateRegExpString = class TranslateRegExpString {
	static isHexadecimal(ch) {
		return "0" <= ch && ch <= "9" || "A" <= ch && ch <= "F" || "a" <= ch && ch <= "f";
	}
	static translate(data) {
		let prefixFlags = "";
		if (data instanceof RegExp) {
			if (data.ignoreCase) prefixFlags += "i";
			if (data.multiline) prefixFlags += "m";
			if (data.dotAll) prefixFlags += "s";
			data = data.source;
		}
		if (typeof data !== "string") return data;
		let result = "";
		let changed = false;
		let size = data.length;
		if (size === 0) {
			result = "(?:)";
			changed = true;
		}
		let inCharClass = false;
		let i = 0;
		while (i < size) {
			let ch = data[i];
			if (ch === "\\") {
				if (i + 1 < size) {
					ch = data[i + 1];
					switch (ch) {
						case "\\":
							result += "\\\\";
							i += 2;
							continue;
						case "c":
							if (i + 2 < size) {
								let code = data[i + 2].charCodeAt(0);
								if (code >= 65 && code <= 90 || code >= 97 && code <= 122) {
									let val = code % 32;
									result += "\\x";
									result += (val >> 4).toString(16).toUpperCase();
									result += (val & 15).toString(16).toUpperCase();
									i += 3;
									changed = true;
									continue;
								}
							}
							result += "c";
							i += 2;
							changed = true;
							continue;
						case "u":
							if (i + 2 < size) {
								if (data[i + 2] === "{") {
									let j = i + 3;
									let hasHex = false;
									let closed = false;
									while (j < size) {
										const hexChar = data[j];
										if (hexChar === "}") {
											closed = true;
											break;
										}
										if (!TranslateRegExpString.isHexadecimal(hexChar)) break;
										hasHex = true;
										j++;
									}
									if (closed && hasHex) {
										result += "\\x";
										i += 2;
										changed = true;
										continue;
									}
								} else if (i + 5 < size) {
									let isHex4 = true;
									for (let j = 0; j < 4; j++) if (!TranslateRegExpString.isHexadecimal(data[i + 2 + j])) {
										isHex4 = false;
										break;
									}
									if (isHex4) {
										result += "\\x{" + data.substring(i + 2, i + 6) + "}";
										i += 6;
										changed = true;
										continue;
									}
								}
							}
							result += "u";
							i += 2;
							changed = true;
							continue;
						case "x": {
							let isValidHex = false;
							if (i + 2 < size && data[i + 2] === "{") {
								let j = i + 3;
								let hasHex = false;
								let closed = false;
								while (j < size) {
									const hexChar = data[j];
									if (hexChar === "}") {
										closed = true;
										break;
									}
									if (!TranslateRegExpString.isHexadecimal(hexChar)) break;
									hasHex = true;
									j++;
								}
								if (closed && hasHex) isValidHex = true;
							} else if (i + 3 < size && TranslateRegExpString.isHexadecimal(data[i + 2]) && TranslateRegExpString.isHexadecimal(data[i + 3])) isValidHex = true;
							if (isValidHex) {
								result += "\\x";
								i += 2;
							} else {
								result += "x";
								i += 2;
								changed = true;
							}
							continue;
						}
						case "n":
						case "r":
						case "t":
						case "a":
						case "f":
						case "v":
						case "d":
						case "D":
						case "s":
						case "S":
						case "w":
						case "W":
						case "b":
						case "B":
						case "p":
						case "P":
						case "A":
						case "z":
						case "Q":
						case "E":
						case "0":
						case "1":
						case "2":
						case "3":
						case "4":
						case "5":
						case "6":
						case "7":
							result += "\\" + ch;
							i += 2;
							continue;
						default: {
							let cp = data.codePointAt(i + 1);
							if (cp >= 48 && cp <= 57 || cp >= 65 && cp <= 90 || cp >= 97 && cp <= 122) {
								let symSize = Utils.charCount(cp);
								result += data.substring(i + 1, i + 1 + symSize);
								i += symSize + 1;
								changed = true;
							} else {
								result += "\\";
								let symSize = Utils.charCount(cp);
								result += data.substring(i + 1, i + 1 + symSize);
								i += symSize + 1;
							}
							continue;
						}
					}
				}
			} else if (ch === "/") {
				result += "\\/";
				i += 1;
				changed = true;
				continue;
			} else if (ch === "[") inCharClass = true;
			else if (ch === "]") inCharClass = false;
			else if (!inCharClass && ch === "(" && i + 2 < size && data[i + 1] === "?" && data[i + 2] === "<") {
				if (i + 3 < size && !"=!>)".includes(data[i + 3])) {
					result += "(?P<";
					i += 3;
					changed = true;
					continue;
				}
			}
			let cp = data.codePointAt(i);
			let symSize = Utils.charCount(cp);
			result += data.substring(i, i + symSize);
			i += symSize;
		}
		const finalResult = changed ? result : data;
		if (prefixFlags.length > 0) return `(?${prefixFlags})${finalResult}`;
		return finalResult;
	}
};
/**
* A compiled representation of an RE2 regular expression
*
* The matching functions take {@code String} arguments instead of the more general Java
* {@code CharSequence} since the latter doesn't provide UTF-16 decoding.
*
*
* @author rsc@google.com (Russ Cox)
* @class
*/
var RE2JS = class RE2JS {
	/**
	* Flag: case insensitive matching.
	*/
	static CASE_INSENSITIVE = PublicFlags.CASE_INSENSITIVE;
	/**
	* Flag: dot ({@code .}) matches all characters, including newline.
	*/
	static DOTALL = PublicFlags.DOTALL;
	/**
	* Flag: multiline matching: {@code ^} and {@code $} match at beginning and end of line, not just
	* beginning and end of input.
	*/
	static MULTILINE = PublicFlags.MULTILINE;
	/**
	* Flag: Unicode groups (e.g. {@code \p\ Greek\} ) will be syntax errors.
	*/
	static DISABLE_UNICODE_GROUPS = PublicFlags.DISABLE_UNICODE_GROUPS;
	/**
	* Flag: matches longest possible string.
	*/
	static LONGEST_MATCH = PublicFlags.LONGEST_MATCH;
	/**
	* Flag: enable linear-time captureless lookbehinds.
	*/
	static LOOKBEHINDS = PublicFlags.LOOKBEHINDS;
	/**
	* Returns a literal pattern string for the specified string.
	*
	* This method produces a string that can be used to create a <code>RE2JS</code> that would
	* match the string <code>s</code> as if it were a literal pattern.
	*
	* Metacharacters or escape sequences in the input sequence will be given no special meaning.
	*
	* @param {string} str The string to be literalized
	* @returns {string} A literal string replacement
	*/
	static quote(str) {
		return Utils.quoteMeta(str);
	}
	/**
	* Quotes '\' and '$' in {@code str}, so that the returned string could be used in
	* replacement methods as a literal replacement of {@code str}.
	*
	* This is a convenience delegation to {@link Matcher.quoteReplacement}.
	*
	* @param {string} str the string to be quoted
	* @param {boolean} [javaMode=false] whether the replacement will be used in javaMode
	* @returns {string} the quoted string
	*/
	static quoteReplacement(str, javaMode = false) {
		return Matcher.quoteReplacement(str, javaMode);
	}
	/**
	* Translates a given regular expression string to ensure compatibility with RE2JS.
	*
	* This function preprocesses the input regex string by applying necessary transformations,
	* such as escaping special characters (e.g., `/`), converting named capture groups to
	* RE2JS-compatible syntax, and handling Unicode sequences properly. It ensures that the
	* resulting regex is safe and properly formatted before compilation.
	*
	* @param {string|RegExp} expr - The regular expression string to be translated.
	* @returns {string} - The transformed regular expression string, ready for compilation.
	*/
	static translateRegExp(expr) {
		return TranslateRegExpString.translate(expr);
	}
	/**
	* Helper: create new RE2JS with given regex and flags. Flregex is the regex with flags applied.
	* @param {string} regex
	* @param {number} [flags=0]
	* @returns {RE2JS}
	*/
	static compile(regex, flags = 0) {
		let fregex = regex;
		if ((flags & RE2JS.CASE_INSENSITIVE) !== 0) fregex = `(?i)${fregex}`;
		if ((flags & RE2JS.DOTALL) !== 0) fregex = `(?s)${fregex}`;
		if ((flags & RE2JS.MULTILINE) !== 0) fregex = `(?m)${fregex}`;
		if ((flags & ~(RE2JS.MULTILINE | RE2JS.DOTALL | RE2JS.CASE_INSENSITIVE | RE2JS.DISABLE_UNICODE_GROUPS | RE2JS.LONGEST_MATCH | RE2JS.LOOKBEHINDS)) !== 0) throw new RE2JSFlagsException("Flags should only be a combination of MULTILINE, DOTALL, CASE_INSENSITIVE, DISABLE_UNICODE_GROUPS, LONGEST_MATCH, LOOKBEHINDS");
		let re2Flags = RE2Flags.PERL;
		if ((flags & RE2JS.DISABLE_UNICODE_GROUPS) !== 0) re2Flags &= ~RE2Flags.UNICODE_GROUPS;
		if ((flags & RE2JS.LOOKBEHINDS) !== 0) re2Flags |= RE2Flags.LOOKBEHIND;
		const p = new RE2JS(regex, flags);
		p.re2Input = RE2.compileImpl(fregex, re2Flags, (flags & RE2JS.LONGEST_MATCH) !== 0);
		return p;
	}
	/**
	* Matches a string against a regular expression.
	*
	* @param {string} regex the regular expression
	* @param {string|number[]|Uint8Array} input the input
	* @returns {boolean} true if the regular expression matches the entire input
	* @throws RE2JSSyntaxException if the regular expression is malformed
	*/
	static matches(regex, input) {
		return RE2JS.compile(regex).testExact(input);
	}
	/**
	* This is visible for testing.
	* @private
	*/
	static initTest(pattern, flags, re2) {
		if (pattern == null) throw new Error("pattern is null");
		if (re2 == null) throw new Error("re2 is null");
		const p = new RE2JS(pattern, flags);
		p.re2Input = re2;
		return p;
	}
	/**
	*
	* @param {string} pattern
	* @param {number} flags
	*/
	constructor(pattern, flags) {
		this.patternInput = pattern;
		this.flagsInput = flags;
		/** @type {import('./RE2.js').RE2} */
		this.re2Input = null;
	}
	/**
	* Releases memory used by internal caches associated with this pattern. Does not change the
	* observable behaviour. Useful for tests that detect memory leaks via allocation tracking.
	*/
	reset() {
		this.re2Input.reset();
	}
	/**
	* Returns the flags used in the constructor.
	* @returns {number}
	*/
	flags() {
		return this.flagsInput;
	}
	/**
	* Returns the pattern used in the constructor.
	* @returns {string}
	*/
	pattern() {
		return this.patternInput;
	}
	re2() {
		return this.re2Input;
	}
	/**
	* Matches a string against a regular expression.
	*
	* @param {string|number[]|Uint8Array} input the input
	* @returns {boolean} true if the regular expression matches the entire input
	*/
	matches(input) {
		return this.testExact(input);
	}
	/**
	* Creates a new {@code Matcher} matching the pattern against the input.
	*
	* @param {string|number[]|Uint8Array|MatcherInputBase} input the input string
	* @returns {Matcher}
	*/
	matcher(input) {
		if (Utils.isByteArray(input)) input = MatcherInput.utf8(input);
		return new Matcher(this, input);
	}
	/**
	* Tests whether the regular expression matches any part of the input string.
	* Performance Note: This method is highly optimized. Because it only returns
	* a boolean and does not extract capture groups, it bypasses the `Matcher` overhead
	* and guarantees execution on the high-speed DFA engine whenever possible.
	*
	* @param {string|number[]|Uint8Array} input - The input string or UTF-8 byte array to test against.
	* @returns {boolean} `true` if the pattern is found anywhere in the input, `false` otherwise.
	*/
	test(input) {
		if (Utils.isByteArray(input)) return this.re2Input.matchUTF8(input);
		return this.re2Input.match(input);
	}
	/**
	* Tests whether the regular expression matches the ENTIRE input string.
	* * **Performance Note:** This operates identically to `.matches()`, but is significantly
	* faster because it does not request capture group data. By requesting 0 capture groups,
	* it securely routes execution through the DFA fast-path.
	*
	* @param {string|number[]|Uint8Array} input - The input string or UTF-8 byte array to test against.
	* @returns {boolean} `true` if the exact input string fully matches the pattern, `false` otherwise.
	*/
	testExact(input) {
		const machineInput = Utils.isByteArray(input) ? MachineInput.fromUTF8(input) : MachineInput.fromUTF16(input);
		return this.re2Input.executeEngine(machineInput, 0, RE2Flags.ANCHOR_BOTH, 0) !== null;
	}
	/**
	* Executes a search for a match in a specified string.
	* Returns a result array, or null if no match is found.
	* The returned array perfectly mirrors standard JavaScript `RegExpExecArray`,
	* including `.index`, `.input`, and `.groups` properties.
	*
	* @param {string|number[]|Uint8Array} input the input string or byte array
	* @returns {Array|null} the match array with index, input, and groups properties, or null
	*/
	exec(input) {
		const m = this.matcher(input);
		if (!m.find()) return null;
		const result = [m.group(0)];
		for (let i = 1; i <= m.groupCount(); i++) {
			const val = m.group(i);
			result.push(val === null ? void 0 : val);
		}
		result.index = m.start(0);
		result.input = input;
		const namedGroups = this.namedGroups();
		if (Object.keys(namedGroups).length > 0) {
			const parsedGroups = m.getNamedGroups();
			for (const key in parsedGroups) if (parsedGroups[key] === null) parsedGroups[key] = void 0;
			result.groups = parsedGroups;
		} else result.groups = void 0;
		return result;
	}
	/**
	* Splits input around instances of the regular expression. It returns an array giving the strings
	* that occur before, between, and after instances of the regular expression.
	*
	* If {@code limit <= 0}, there is no limit on the size of the returned array. If
	* {@code limit == 0}, empty strings that would occur at the end of the array are omitted. If
	* {@code limit > 0}, at most limit strings are returned. The final string contains the remainder
	* of the input, possibly including additional matches of the pattern.
	*
	* @param {string} input the input string to be split
	* @param {number} [limit=0] the limit
	* @returns {string[]} the split strings
	*/
	split(input, limit = 0) {
		const m = this.matcher(input);
		const result = [];
		let emptiesSkipped = 0;
		let last = 0;
		while (m.find()) {
			if (last === 0 && m.end() === 0) {
				last = m.end();
				continue;
			}
			if (limit > 0 && result.length === limit - 1) break;
			if (last === m.start()) {
				if (limit === 0) {
					emptiesSkipped += 1;
					last = m.end();
					continue;
				}
			} else while (emptiesSkipped > 0) {
				result.push("");
				emptiesSkipped -= 1;
			}
			result.push(m.substring(last, m.start()));
			last = m.end();
		}
		if (limit === 0 && last !== m.inputLength()) {
			while (emptiesSkipped > 0) {
				result.push("");
				emptiesSkipped -= 1;
			}
			result.push(m.substring(last, m.inputLength()));
		}
		if (limit !== 0 || result.length === 0 && !(last === m.inputLength() && last > 0)) result.push(m.substring(last, m.inputLength()));
		return result;
	}
	/**
	* Returns an iterator of all results matching a string against the regular expression,
	* including capturing groups.
	*
	* @param {string|number[]|Uint8Array} input the input string or byte array
	* @returns {IterableIterator<RegExpMatchArray>}
	*/
	*matchAll(input) {
		const m = this.matcher(input);
		while (m.find()) {
			const result = [m.group(0)];
			for (let i = 1; i <= m.groupCount(); i++) {
				const groupVal = m.group(i);
				result.push(groupVal === null ? void 0 : groupVal);
			}
			result.index = m.start(0);
			result.input = input;
			const namedGroups = this.namedGroups();
			if (Object.keys(namedGroups).length > 0) {
				const parsedGroups = m.getNamedGroups();
				for (const key in parsedGroups) if (parsedGroups[key] === null) parsedGroups[key] = void 0;
				result.groups = parsedGroups;
			} else result.groups = void 0;
			yield result;
		}
	}
	/**
	*
	* @returns {string}
	*/
	toString() {
		return this.patternInput;
	}
	/**
	* Returns the program size of this pattern.
	*
	* <p>
	* Similar to the C++ implementation, the program size is a very approximate measure of a regexp's
	* "cost". Larger numbers are more expensive than smaller numbers.
	* </p>
	*
	* @returns {number} the program size of this pattern
	*/
	programSize() {
		return this.re2Input.numberOfInstructions();
	}
	/**
	* Returns the number of capturing groups in this matcher's pattern. Group zero denotes the entire
	* pattern and is excluded from this count.
	*
	* @returns {number} the number of capturing groups in this pattern
	*/
	groupCount() {
		return this.re2Input.numberOfCapturingGroups();
	}
	/**
	* Return a map of the capturing groups in this matcher's pattern, where key is the name and value
	* is the index of the group in the pattern.
	* @returns {Record<string, number>}
	*/
	namedGroups() {
		return this.re2Input.namedGroups;
	}
	/**
	*
	* @param {*} other
	* @returns {boolean}
	*/
	equals(other) {
		if (this === other) return true;
		if (other === null || this.constructor !== other.constructor) return false;
		return this.flagsInput === other.flagsInput && this.patternInput === other.patternInput;
	}
};
//#endregion
//#region node_modules/@firebase/firestore/dist/common-CLMydGSF.esm.js
/**
* @license
* Copyright 2023 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/** The semver (www.semver.org) version of the SDK. */
var Se = "12.19.0";
function __PRIVATE_setSDKVersion(e) {
	Se = e;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/** Formats an object as a JSON string, suitable for logging. */
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var ve = new Logger("@firebase/firestore");
function __PRIVATE_getLogLevel() {
	return ve.logLevel;
}
function __PRIVATE_logDebug(e, ...t) {
	if (ve.logLevel <= LogLevel.DEBUG) {
		const n = t.map(__PRIVATE_argToString);
		ve.debug(`Firestore (${Se}): ${e}`, ...n);
	}
}
function __PRIVATE_logError(e, ...t) {
	if (ve.logLevel <= LogLevel.ERROR) {
		const n = t.map(__PRIVATE_argToString);
		ve.error(`Firestore (${Se}): ${e}`, ...n);
	}
}
/**
* @internal
*/ function __PRIVATE_logWarn(e, ...t) {
	if (ve.logLevel <= LogLevel.WARN) {
		const n = t.map(__PRIVATE_argToString);
		ve.warn(`Firestore (${Se}): ${e}`, ...n);
	}
}
/**
* Converts an additional log parameter to a string representation.
*/ function __PRIVATE_argToString(e) {
	if ("string" == typeof e) return e;
	try {
		return function __PRIVATE_formatJSON(e) {
			return JSON.stringify(e);
		}(e);
	} catch (t) {
		return e;
	}
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ function l(e, t, n) {
	let r = "Unexpected state";
	"string" == typeof t ? r = t : n = t, __PRIVATE__fail(e, r, n);
}
function __PRIVATE__fail(e, t, n) {
	let r = `FIRESTORE (${Se}) INTERNAL ASSERTION FAILED: ${t} (ID: ${e.toString(16)})`;
	if (void 0 !== n) try {
		r += " CONTEXT: " + JSON.stringify(n);
	} catch (e) {
		r += " CONTEXT: " + n;
	}
	throw __PRIVATE_logError(r), new Error(r);
}
function __PRIVATE_hardAssert(e, t, n, r) {
	let i = "Unexpected state";
	"string" == typeof n ? i = n : r = n, e || __PRIVATE__fail(t, i, r);
}
/**
* Casts `obj` to `T`. In non-production builds, verifies that `obj` is an
* instance of `T` before casting.
*/ function __PRIVATE_debugCast(e, t) {
	return e;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Generates `nBytes` of random bytes.
*
* If `nBytes < 0` , an error will be thrown.
*/ function __PRIVATE_randomBytes(e) {
	const t = "undefined" != typeof self && (self.crypto || self.msCrypto), n = new Uint8Array(e);
	if (t && "function" == typeof t.getRandomValues) t.getRandomValues(n);
	else for (let t = 0; t < e; t++) n[t] = Math.floor(256 * Math.random());
	return n;
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A utility class for generating unique alphanumeric IDs of a specified length.
*
* @internal
* Exported internally for testing purposes.
*/ var __PRIVATE_AutoId = class {
	static newId() {
		const e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", t = 62 * Math.floor(256 / 62);
		let n = "";
		for (; n.length < 20;) {
			const r = __PRIVATE_randomBytes(40);
			for (let i = 0; i < r.length; ++i) n.length < 20 && r[i] < t && (n += e.charAt(r[i] % 62));
		}
		return n;
	}
};
function __PRIVATE_primitiveComparator(e, t) {
	return e < t ? -1 : e > t ? 1 : 0;
}
/** Compare strings in UTF-8 encoded byte order */ function __PRIVATE_compareUtf8Strings(e, t) {
	const n = Math.min(e.length, t.length);
	for (let r = 0; r < n; r++) {
		const n = e.charAt(r), i = t.charAt(r);
		if (n !== i) return __PRIVATE_isSurrogate(n) === __PRIVATE_isSurrogate(i) ? __PRIVATE_primitiveComparator(n, i) : __PRIVATE_isSurrogate(n) ? 1 : -1;
	}
	return __PRIVATE_primitiveComparator(e.length, t.length);
}
var De = 55296;
var xe = 57343;
function __PRIVATE_isSurrogate(e) {
	const t = e.charCodeAt(0);
	return t >= De && t <= xe;
}
/** Helper to compare arrays using isEqual(). */ function __PRIVATE_arrayEquals(e, t, n) {
	return e.length === t.length && e.every(((e, r) => n(e, t[r])));
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var SortedMap = class SortedMap {
	constructor(e, t) {
		this.comparator = e, this.root = t || LLRBNode.EMPTY;
	}
	insert(e, t) {
		return new SortedMap(this.comparator, this.root.insert(e, t, this.comparator).copy(null, null, LLRBNode.BLACK, null, null));
	}
	remove(e) {
		return new SortedMap(this.comparator, this.root.remove(e, this.comparator).copy(null, null, LLRBNode.BLACK, null, null));
	}
	get(e) {
		let t = this.root;
		for (; !t.isEmpty();) {
			const n = this.comparator(e, t.key);
			if (0 === n) return t.value;
			n < 0 ? t = t.left : n > 0 && (t = t.right);
		}
		return null;
	}
	indexOf(e) {
		let t = 0, n = this.root;
		for (; !n.isEmpty();) {
			const r = this.comparator(e, n.key);
			if (0 === r) return t + n.left.size;
			r < 0 ? n = n.left : (t += n.left.size + 1, n = n.right);
		}
		return -1;
	}
	isEmpty() {
		return this.root.isEmpty();
	}
	get size() {
		return this.root.size;
	}
	minKey() {
		return this.root.minKey();
	}
	maxKey() {
		return this.root.maxKey();
	}
	inorderTraversal(e) {
		return this.root.inorderTraversal(e);
	}
	forEach(e) {
		this.inorderTraversal(((t, n) => (e(t, n), false)));
	}
	toString() {
		const e = [];
		return this.inorderTraversal(((t, n) => (e.push(`${t}:${n}`), false))), `{${e.join(", ")}}`;
	}
	reverseTraversal(e) {
		return this.root.reverseTraversal(e);
	}
	getIterator() {
		return new SortedMapIterator(this.root, null, this.comparator, false);
	}
	getIteratorFrom(e) {
		return new SortedMapIterator(this.root, e, this.comparator, false);
	}
	getReverseIterator() {
		return new SortedMapIterator(this.root, null, this.comparator, true);
	}
	getReverseIteratorFrom(e) {
		return new SortedMapIterator(this.root, e, this.comparator, true);
	}
};
var SortedMapIterator = class {
	constructor(e, t, n, r) {
		this.isReverse = r, this.nodeStack = [];
		let i = 1;
		for (; !e.isEmpty();) if (i = t ? n(e.key, t) : 1, t && r && (i *= -1), i < 0) e = this.isReverse ? e.left : e.right;
		else {
			if (0 === i) {
				this.nodeStack.push(e);
				break;
			}
			this.nodeStack.push(e), e = this.isReverse ? e.right : e.left;
		}
	}
	getNext() {
		let e = this.nodeStack.pop();
		const t = {
			key: e.key,
			value: e.value
		};
		if (this.isReverse) for (e = e.left; !e.isEmpty();) this.nodeStack.push(e), e = e.right;
		else for (e = e.right; !e.isEmpty();) this.nodeStack.push(e), e = e.left;
		return t;
	}
	hasNext() {
		return this.nodeStack.length > 0;
	}
	peek() {
		if (0 === this.nodeStack.length) return null;
		const e = this.nodeStack[this.nodeStack.length - 1];
		return {
			key: e.key,
			value: e.value
		};
	}
};
var LLRBNode = class LLRBNode {
	constructor(e, t, n, r, i) {
		this.key = e, this.value = t, this.color = null != n ? n : LLRBNode.RED, this.left = null != r ? r : LLRBNode.EMPTY, this.right = null != i ? i : LLRBNode.EMPTY, this.size = this.left.size + 1 + this.right.size;
	}
	copy(e, t, n, r, i) {
		return new LLRBNode(null != e ? e : this.key, null != t ? t : this.value, null != n ? n : this.color, null != r ? r : this.left, null != i ? i : this.right);
	}
	isEmpty() {
		return false;
	}
	inorderTraversal(e) {
		return this.left.inorderTraversal(e) || e(this.key, this.value) || this.right.inorderTraversal(e);
	}
	reverseTraversal(e) {
		return this.right.reverseTraversal(e) || e(this.key, this.value) || this.left.reverseTraversal(e);
	}
	min() {
		return this.left.isEmpty() ? this : this.left.min();
	}
	minKey() {
		return this.min().key;
	}
	maxKey() {
		return this.right.isEmpty() ? this.key : this.right.maxKey();
	}
	insert(e, t, n) {
		let r = this;
		const i = n(e, r.key);
		return r = i < 0 ? r.copy(null, null, null, r.left.insert(e, t, n), null) : 0 === i ? r.copy(null, t, null, null, null) : r.copy(null, null, null, null, r.right.insert(e, t, n)), r.fixUp();
	}
	removeMin() {
		if (this.left.isEmpty()) return LLRBNode.EMPTY;
		let e = this;
		return e.left.isRed() || e.left.left.isRed() || (e = e.moveRedLeft()), e = e.copy(null, null, null, e.left.removeMin(), null), e.fixUp();
	}
	remove(e, t) {
		let n, r = this;
		if (t(e, r.key) < 0) r.left.isEmpty() || r.left.isRed() || r.left.left.isRed() || (r = r.moveRedLeft()), r = r.copy(null, null, null, r.left.remove(e, t), null);
		else {
			if (r.left.isRed() && (r = r.rotateRight()), r.right.isEmpty() || r.right.isRed() || r.right.left.isRed() || (r = r.moveRedRight()), 0 === t(e, r.key)) {
				if (r.right.isEmpty()) return LLRBNode.EMPTY;
				n = r.right.min(), r = r.copy(n.key, n.value, null, null, r.right.removeMin());
			}
			r = r.copy(null, null, null, null, r.right.remove(e, t));
		}
		return r.fixUp();
	}
	isRed() {
		return this.color;
	}
	fixUp() {
		let e = this;
		return e.right.isRed() && !e.left.isRed() && (e = e.rotateLeft()), e.left.isRed() && e.left.left.isRed() && (e = e.rotateRight()), e.left.isRed() && e.right.isRed() && (e = e.colorFlip()), e;
	}
	moveRedLeft() {
		let e = this.colorFlip();
		return e.right.left.isRed() && (e = e.copy(null, null, null, null, e.right.rotateRight()), e = e.rotateLeft(), e = e.colorFlip()), e;
	}
	moveRedRight() {
		let e = this.colorFlip();
		return e.left.left.isRed() && (e = e.rotateRight(), e = e.colorFlip()), e;
	}
	rotateLeft() {
		const e = this.copy(null, null, LLRBNode.RED, null, this.right.left);
		return this.right.copy(null, null, this.color, e, null);
	}
	rotateRight() {
		const e = this.copy(null, null, LLRBNode.RED, this.left.right, null);
		return this.left.copy(null, null, this.color, null, e);
	}
	colorFlip() {
		const e = this.left.copy(null, null, !this.left.color, null, null), t = this.right.copy(null, null, !this.right.color, null, null);
		return this.copy(null, null, !this.color, e, t);
	}
	checkMaxDepth() {
		const e = this.check();
		return Math.pow(2, e) <= this.size + 1;
	}
	check() {
		if (this.isRed() && this.left.isRed()) throw l(43730, {
			key: this.key,
			value: this.value
		});
		if (this.right.isRed()) throw l(14113, {
			key: this.key,
			value: this.value
		});
		const e = this.left.check();
		if (e !== this.right.check()) throw l(27949);
		return e + (this.isRed() ? 0 : 1);
	}
};
LLRBNode.EMPTY = null, LLRBNode.RED = true, LLRBNode.BLACK = false;
LLRBNode.EMPTY = new class LLRBEmptyNode {
	constructor() {
		this.size = 0;
	}
	get key() {
		throw l(57766);
	}
	get value() {
		throw l(16141);
	}
	get color() {
		throw l(16727);
	}
	get left() {
		throw l(29726);
	}
	get right() {
		throw l(36894);
	}
	copy(e, t, n, r, i) {
		return this;
	}
	insert(e, t, n) {
		return new LLRBNode(e, t);
	}
	remove(e, t) {
		return this;
	}
	isEmpty() {
		return true;
	}
	inorderTraversal(e) {
		return false;
	}
	reverseTraversal(e) {
		return false;
	}
	minKey() {
		return null;
	}
	maxKey() {
		return null;
	}
	isRed() {
		return false;
	}
	checkMaxDepth() {
		return true;
	}
	check() {
		return 0;
	}
}();
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* SortedSet is an immutable (copy-on-write) collection that holds elements
* in order specified by the provided comparator.
*
* NOTE: if provided comparator returns 0 for two elements, we consider them to
* be equal!
*/
var SortedSet = class SortedSet {
	constructor(e) {
		this.comparator = e, this.data = new SortedMap(this.comparator);
	}
	has(e) {
		return null !== this.data.get(e);
	}
	first() {
		return this.data.minKey();
	}
	last() {
		return this.data.maxKey();
	}
	get size() {
		return this.data.size;
	}
	indexOf(e) {
		return this.data.indexOf(e);
	}
	/** Iterates elements in order defined by "comparator" */ forEach(e) {
		this.data.inorderTraversal(((t, n) => (e(t), false)));
	}
	/** Iterates over `elem`s such that: range[0] &lt;= elem &lt; range[1]. */ forEachInRange(e, t) {
		const n = this.data.getIteratorFrom(e[0]);
		for (; n.hasNext();) {
			const r = n.getNext();
			if (this.comparator(r.key, e[1]) >= 0) return;
			t(r.key);
		}
	}
	/**
	* Iterates over `elem`s such that: start &lt;= elem until false is returned.
	*/ forEachWhile(e, t) {
		let n;
		for (n = void 0 !== t ? this.data.getIteratorFrom(t) : this.data.getIterator(); n.hasNext();) if (!e(n.getNext().key)) return;
	}
	/** Finds the least element greater than or equal to `elem`. */ firstAfterOrEqual(e) {
		const t = this.data.getIteratorFrom(e);
		return t.hasNext() ? t.getNext().key : null;
	}
	getIterator() {
		return new SortedSetIterator(this.data.getIterator());
	}
	getIteratorFrom(e) {
		return new SortedSetIterator(this.data.getIteratorFrom(e));
	}
	/** Inserts or updates an element */ add(e) {
		return this.copy(this.data.remove(e).insert(e, true));
	}
	/** Deletes an element */ delete(e) {
		return this.has(e) ? this.copy(this.data.remove(e)) : this;
	}
	isEmpty() {
		return this.data.isEmpty();
	}
	unionWith(e) {
		let t = this;
		return t.size < e.size && (t = e, e = this), e.forEach(((e) => {
			t = t.add(e);
		})), t;
	}
	isEqual(e) {
		if (!(e instanceof SortedSet)) return false;
		if (this.size !== e.size) return false;
		const t = this.data.getIterator(), n = e.data.getIterator();
		for (; t.hasNext();) {
			const e = t.getNext().key, r = n.getNext().key;
			if (0 !== this.comparator(e, r)) return false;
		}
		return true;
	}
	toArray() {
		const e = [];
		return this.forEach(((t) => {
			e.push(t);
		})), e;
	}
	toString() {
		const e = [];
		return this.forEach(((t) => e.push(t))), "SortedSet(" + e.toString() + ")";
	}
	copy(e) {
		const t = new SortedSet(this.comparator);
		return t.data = e, t;
	}
};
var SortedSetIterator = class {
	constructor(e) {
		this.iter = e;
	}
	getNext() {
		return this.iter.getNext().key;
	}
	hasNext() {
		return this.iter.hasNext();
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var ta = {
	/** Not an error; returned on success. */
	OK: "ok",
	/** The operation was cancelled (typically by the caller). */
	CANCELLED: "cancelled",
	/** Unknown error or an error from a different error domain. */
	UNKNOWN: "unknown",
	/**
	* Client specified an invalid argument. Note that this differs from
	* FAILED_PRECONDITION. INVALID_ARGUMENT indicates arguments that are
	* problematic regardless of the state of the system (e.g., a malformed file
	* name).
	*/
	INVALID_ARGUMENT: "invalid-argument",
	/**
	* Deadline expired before operation could complete. For operations that
	* change the state of the system, this error may be returned even if the
	* operation has completed successfully. For example, a successful response
	* from a server could have been delayed long enough for the deadline to
	* expire.
	*/
	DEADLINE_EXCEEDED: "deadline-exceeded",
	/** Some requested entity (e.g., file or directory) was not found. */
	NOT_FOUND: "not-found",
	/**
	* Some entity that we attempted to create (e.g., file or directory) already
	* exists.
	*/
	ALREADY_EXISTS: "already-exists",
	/**
	* The caller does not have permission to execute the specified operation.
	* PERMISSION_DENIED must not be used for rejections caused by exhausting
	* some resource (use RESOURCE_EXHAUSTED instead for those errors).
	* PERMISSION_DENIED must not be used if the caller cannot be identified
	* (use UNAUTHENTICATED instead for those errors).
	*/
	PERMISSION_DENIED: "permission-denied",
	/**
	* The request does not have valid authentication credentials for the
	* operation.
	*/
	UNAUTHENTICATED: "unauthenticated",
	/**
	* Some resource has been exhausted, perhaps a per-user quota, or perhaps the
	* entire file system is out of space.
	*/
	RESOURCE_EXHAUSTED: "resource-exhausted",
	/**
	* Operation was rejected because the system is not in a state required for
	* the operation's execution. For example, directory to be deleted may be
	* non-empty, an rmdir operation is applied to a non-directory, etc.
	*
	* A litmus test that may help a service implementor in deciding
	* between FAILED_PRECONDITION, ABORTED, and UNAVAILABLE:
	*  (a) Use UNAVAILABLE if the client can retry just the failing call.
	*  (b) Use ABORTED if the client should retry at a higher-level
	*      (e.g., restarting a read-modify-write sequence).
	*  (c) Use FAILED_PRECONDITION if the client should not retry until
	*      the system state has been explicitly fixed. E.g., if an "rmdir"
	*      fails because the directory is non-empty, FAILED_PRECONDITION
	*      should be returned since the client should not retry unless
	*      they have first fixed up the directory by deleting files from it.
	*  (d) Use FAILED_PRECONDITION if the client performs conditional
	*      REST Get/Update/Delete on a resource and the resource on the
	*      server does not match the condition. E.g., conflicting
	*      read-modify-write on the same resource.
	*/
	FAILED_PRECONDITION: "failed-precondition",
	/**
	* The operation was aborted, typically due to a concurrency issue like
	* sequencer check failures, transaction aborts, etc.
	*
	* See litmus test above for deciding between FAILED_PRECONDITION, ABORTED,
	* and UNAVAILABLE.
	*/
	ABORTED: "aborted",
	/**
	* Operation was attempted past the valid range. E.g., seeking or reading
	* past end of file.
	*
	* Unlike INVALID_ARGUMENT, this error indicates a problem that may be fixed
	* if the system state changes. For example, a 32-bit file system will
	* generate INVALID_ARGUMENT if asked to read at an offset that is not in the
	* range [0,2^32-1], but it will generate OUT_OF_RANGE if asked to read from
	* an offset past the current file size.
	*
	* There is a fair bit of overlap between FAILED_PRECONDITION and
	* OUT_OF_RANGE. We recommend using OUT_OF_RANGE (the more specific error)
	* when it applies so that callers who are iterating through a space can
	* easily look for an OUT_OF_RANGE error to detect when they are done.
	*/
	OUT_OF_RANGE: "out-of-range",
	/** Operation is not implemented or not supported/enabled in this service. */
	UNIMPLEMENTED: "unimplemented",
	/**
	* Internal errors. Means some invariants expected by underlying System has
	* been broken. If you see one of these errors, Something is very broken.
	*/
	INTERNAL: "internal",
	/**
	* The service is currently unavailable. This is a most likely a transient
	* condition and may be corrected by retrying with a backoff.
	*
	* See litmus test above for deciding between FAILED_PRECONDITION, ABORTED,
	* and UNAVAILABLE.
	*/
	UNAVAILABLE: "unavailable",
	/** Unrecoverable data loss or corruption. */
	DATA_LOSS: "data-loss"
};
/** An error returned by a Firestore operation. */ var e = class extends FirebaseError {
	/** @hideconstructor */
	constructor(e, t) {
		super(e, t), this.code = e, this.message = t, this.toString = () => `${this.name}: [code=${this.code}]: ${this.message}`;
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var Ce = "__name__";
/**
* Path represents an ordered sequence of string segments.
*/
var BasePath = class BasePath {
	constructor(e, t, n) {
		void 0 === t ? t = 0 : t > e.length && l(637, {
			offset: t,
			range: e.length
		}), void 0 === n ? n = e.length - t : n > e.length - t && l(1746, {
			length: n,
			range: e.length - t
		}), this.segments = e, this.offset = t, this.len = n;
	}
	get length() {
		return this.len;
	}
	isEqual(e) {
		return 0 === BasePath.comparator(this, e);
	}
	child(e) {
		const t = this.segments.slice(this.offset, this.limit());
		return e instanceof BasePath ? e.forEach(((e) => {
			t.push(e);
		})) : t.push(e), this.construct(t);
	}
	/** The index of one past the last segment of the path. */ limit() {
		return this.offset + this.length;
	}
	popFirst(e) {
		return e = void 0 === e ? 1 : e, this.construct(this.segments, this.offset + e, this.length - e);
	}
	popLast() {
		return this.construct(this.segments, this.offset, this.length - 1);
	}
	firstSegment() {
		return this.segments[this.offset];
	}
	lastSegment() {
		return this.get(this.length - 1);
	}
	get(e) {
		return this.segments[this.offset + e];
	}
	isEmpty() {
		return 0 === this.length;
	}
	isPrefixOf(e) {
		if (e.length < this.length) return false;
		for (let t = 0; t < this.length; t++) if (this.get(t) !== e.get(t)) return false;
		return true;
	}
	isImmediateParentOf(e) {
		if (this.length + 1 !== e.length) return false;
		for (let t = 0; t < this.length; t++) if (this.get(t) !== e.get(t)) return false;
		return true;
	}
	forEach(e) {
		for (let t = this.offset, n = this.limit(); t < n; t++) e(this.segments[t]);
	}
	toArray() {
		return this.segments.slice(this.offset, this.limit());
	}
	/**
	* Compare 2 paths segment by segment, prioritizing numeric IDs
	* (e.g., "__id123__") in numeric ascending order, followed by string
	* segments in lexicographical order.
	*/ static comparator(e, t) {
		const n = Math.min(e.length, t.length);
		for (let r = 0; r < n; r++) {
			const n = BasePath.compareSegments(e.get(r), t.get(r));
			if (0 !== n) return n;
		}
		return __PRIVATE_primitiveComparator(e.length, t.length);
	}
	static compareSegments(e, t) {
		const n = BasePath.isNumericId(e), r = BasePath.isNumericId(t);
		return n && !r ? -1 : !n && r ? 1 : n && r ? BasePath.extractNumericId(e).compare(BasePath.extractNumericId(t)) : __PRIVATE_compareUtf8Strings(e, t);
	}
	static isNumericId(e) {
		return e.startsWith("__id") && e.endsWith("__");
	}
	static extractNumericId(e) {
		return Integer.fromString(e.substring(4, e.length - 2));
	}
};
/**
* A slash-separated path for navigating resources (documents and collections)
* within Firestore.
*
* @internal
*/ var ResourcePath = class ResourcePath extends BasePath {
	construct(e, t, n) {
		return new ResourcePath(e, t, n);
	}
	canonicalString() {
		return this.toArray().join("/");
	}
	toString() {
		return this.canonicalString();
	}
	toStringWithLeadingSlash() {
		return `/${this.canonicalString()}`;
	}
	/**
	* Returns a string representation of this path
	* where each path segment has been encoded with
	* `encodeURIComponent`.
	*/ toUriEncodedString() {
		return this.toArray().map(encodeURIComponent).join("/");
	}
	/**
	* Creates a resource path from the given slash-delimited string. If multiple
	* arguments are provided, all components are combined. Leading and trailing
	* slashes from all components are ignored.
	*/ static fromString(...t) {
		const n = [];
		for (const r of t) {
			if (r.indexOf("//") >= 0) throw new e(ta.INVALID_ARGUMENT, `Invalid segment (${r}). Paths must not contain // in them.`);
			n.push(...r.split("/").filter(((e) => e.length > 0)));
		}
		return new ResourcePath(n);
	}
	static emptyPath() {
		return new ResourcePath([]);
	}
};
var Fe = /^[_a-zA-Z][_a-zA-Z0-9]*$/;
/**
* A dot-separated path for navigating sub-objects within a document.
* @internal
*/ var Oe = class FieldPath extends BasePath {
	construct(e, t, n) {
		return new FieldPath(e, t, n);
	}
	/**
	* Returns true if the string could be used as a segment in a field path
	* without escaping.
	*/ static isValidIdentifier(e) {
		return Fe.test(e);
	}
	canonicalString() {
		return this.toArray().map(((e) => (e = e.replace(/\\/g, "\\\\").replace(/`/g, "\\`"), FieldPath.isValidIdentifier(e) || (e = "`" + e + "`"), e))).join(".");
	}
	toString() {
		return this.canonicalString();
	}
	/**
	* Returns true if this field references the key of a document.
	*/ isKeyField() {
		return 1 === this.length && this.get(0) === Ce;
	}
	/**
	* The field designating the key of a document.
	*/ static keyField() {
		return new FieldPath([Ce]);
	}
	/**
	* Parses a field string from the given server-formatted string.
	*
	* - Splitting the empty string is not allowed (for now at least).
	* - Empty segments within the string (e.g. if there are two consecutive
	*   separators) are not allowed.
	*
	* TODO(b/37244157): we should make this more strict. Right now, it allows
	* non-identifier path components, even if they aren't escaped.
	*/ static fromServerFormat(t) {
		const n = [];
		let r = "", i = 0;
		const __PRIVATE_addCurrentSegment = () => {
			if (0 === r.length) throw new e(ta.INVALID_ARGUMENT, `Invalid field path (${t}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);
			n.push(r), r = "";
		};
		let s = false;
		for (; i < t.length;) {
			const n = t[i];
			if ("\\" === n) {
				if (i + 1 === t.length) throw new e(ta.INVALID_ARGUMENT, "Path has trailing escape character: " + t);
				const n = t[i + 1];
				if ("\\" !== n && "." !== n && "`" !== n) throw new e(ta.INVALID_ARGUMENT, "Path has invalid escape sequence: " + t);
				r += n, i += 2;
			} else "`" === n ? (s = !s, i++) : "." !== n || s ? (r += n, i++) : (__PRIVATE_addCurrentSegment(), i++);
		}
		if (__PRIVATE_addCurrentSegment(), s) throw new e(ta.INVALID_ARGUMENT, "Unterminated ` in path: " + t);
		return new FieldPath(n);
	}
	static emptyPath() {
		return new FieldPath([]);
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Provides a set of fields that can be used to partially patch a document.
* FieldMask is used in conjunction with ObjectValue.
* Examples:
*   foo - Overwrites foo entirely with the provided value. If foo is not
*         present in the companion ObjectValue, the field is deleted.
*   foo.bar - Overwrites only the field bar of the object foo.
*             If foo is not an object, foo is replaced with an object
*             containing foo
*/ var FieldMask = class FieldMask {
	constructor(e) {
		this.fields = e, e.sort(Oe.comparator);
	}
	static empty() {
		return new FieldMask([]);
	}
	/**
	* Returns a new FieldMask object that is the result of adding all the given
	* fields paths to this field mask.
	*/ unionWith(e) {
		let t = new SortedSet(Oe.comparator);
		for (const e of this.fields) t = t.add(e);
		for (const n of e) t = t.add(n);
		return new FieldMask(t.toArray());
	}
	/**
	* Verifies that `fieldPath` is included by at least one field in this field
	* mask.
	*
	* This is an O(n) operation, where `n` is the size of the field mask.
	*/ covers(e) {
		for (const t of this.fields) if (t.isPrefixOf(e)) return true;
		return false;
	}
	isEqual(e) {
		return __PRIVATE_arrayEquals(this.fields, e.fields, ((e, t) => e.isEqual(t)));
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ function __PRIVATE_objectSize(e) {
	let t = 0;
	for (const n in e) Object.prototype.hasOwnProperty.call(e, n) && t++;
	return t;
}
function forEach(e, t) {
	for (const n in e) Object.prototype.hasOwnProperty.call(e, n) && t(n, e[n]);
}
function __PRIVATE_mapToArray(e, t) {
	const n = [];
	for (const r in e) Object.prototype.hasOwnProperty.call(e, r) && n.push(t(e[r], r, e));
	return n;
}
function isEmpty(e) {
	for (const t in e) if (Object.prototype.hasOwnProperty.call(e, t)) return false;
	return true;
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @internal
*/ var DocumentKey = class DocumentKey {
	constructor(e) {
		this.path = e;
	}
	static fromPath(e) {
		return new DocumentKey(ResourcePath.fromString(e));
	}
	static fromName(e) {
		return new DocumentKey(ResourcePath.fromString(e).popFirst(5));
	}
	static empty() {
		return new DocumentKey(ResourcePath.emptyPath());
	}
	get collectionGroup() {
		return this.path.popLast().lastSegment();
	}
	/** Returns true if the document is in the specified collectionId. */ hasCollectionId(e) {
		return this.path.length >= 2 && this.path.get(this.path.length - 2) === e;
	}
	/** Returns the collection group (i.e. the name of the parent collection) for this key. */ getCollectionGroup() {
		return this.path.get(this.path.length - 2);
	}
	/** Returns the fully qualified path to the parent collection. */ getCollectionPath() {
		return this.path.popLast();
	}
	isEqual(e) {
		return null !== e && 0 === ResourcePath.comparator(this.path, e.path);
	}
	toString() {
		return this.path.toString();
	}
	static comparator(e, t) {
		return ResourcePath.comparator(e.path, t.path);
	}
	static isDocumentKey(e) {
		return e.length % 2 == 0;
	}
	/**
	* Creates and returns a new document key with the given segments.
	*
	* @param segments - The segments of the path to the document
	* @returns A new instance of DocumentKey
	*/ static fromSegments(e) {
		return new DocumentKey(new ResourcePath(e.slice()));
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ function __PRIVATE_validateNonEmptyArgument(t, n, r) {
	if (!r) throw new e(ta.INVALID_ARGUMENT, `Function ${t}() cannot be called with an empty ${n}.`);
}
/**
* Validates that two boolean options are not set at the same time.
* @internal
*/ function __PRIVATE_validateIsNotUsedTogether(t, n, r, i) {
	if (true === n && true === i) throw new e(ta.INVALID_ARGUMENT, `${t} and ${r} cannot be used together.`);
}
/**
* Validates that `path` refers to a document (indicated by the fact it contains
* an even numbers of segments).
*/ function __PRIVATE_validateDocumentPath(t) {
	if (!DocumentKey.isDocumentKey(t)) throw new e(ta.INVALID_ARGUMENT, `Invalid document reference. Document references must have an even number of segments, but ${t} has ${t.length}.`);
}
/**
* Validates that `path` refers to a collection (indicated by the fact it
* contains an odd numbers of segments).
*/ function __PRIVATE_validateCollectionPath(t) {
	if (DocumentKey.isDocumentKey(t)) throw new e(ta.INVALID_ARGUMENT, `Invalid collection reference. Collection references must have an odd number of segments, but ${t} has ${t.length}.`);
}
/**
* Returns true if it's a non-null object without a custom prototype
* (i.e. excludes Array, Date, etc.).
*/ function p(e) {
	return "object" == typeof e && null !== e && (Object.getPrototypeOf(e) === Object.prototype || null === Object.getPrototypeOf(e));
}
/** Returns a string describing the type / value of the provided input. */ function __PRIVATE_valueDescription(e) {
	if (void 0 === e) return "undefined";
	if (null === e) return "null";
	if ("string" == typeof e) return e.length > 20 && (e = `${e.substring(0, 20)}...`), JSON.stringify(e);
	if ("number" == typeof e || "boolean" == typeof e) return "" + e;
	if ("object" == typeof e) {
		if (e instanceof Array) return "an array";
		{
			const t = function __PRIVATE_tryGetCustomObjectType(e) {
				if (e.constructor) return e.constructor.name;
				return null;
			}(e);
			return t ? `a custom ${t} object` : "an object";
		}
	}
	return "function" == typeof e ? "a function" : l(12329, { type: typeof e });
}
function ra(t, n) {
	if ("_delegate" in t && (t = t._delegate), !(t instanceof n)) {
		if (n.name === t.constructor.name) throw new e(ta.INVALID_ARGUMENT, "Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");
		{
			const r = __PRIVATE_valueDescription(t);
			throw new e(ta.INVALID_ARGUMENT, `Expected type '${n.name}', but it was: ${r}`);
		}
	}
	return t;
}
/**
* @license
* Copyright 2025 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Helper function to define a JSON schema {@link Property}.
* @private
* @internal
*/ function property(e, t) {
	const n = { typeString: e };
	return t && (n.value = t), n;
}
/**
* Validates the JSON object based on the provided schema, and narrows the type to the provided
* JSON schema.
* @private
* @internal
*
* @param json - A JSON object to validate.
* @param scheme - a {@link JsonSchema} that defines the properties to validate.
* @returns true if the JSON schema exists within the object. Throws a FirestoreError otherwise.
*/ function __PRIVATE_validateJSON(t, n) {
	if (!p(t)) throw new e(ta.INVALID_ARGUMENT, "JSON must be an object");
	let r;
	for (const e in n) if (n[e]) {
		const i = n[e].typeString, s = "value" in n[e] ? { value: n[e].value } : void 0;
		if (!(e in t)) {
			r = `JSON missing required field: '${e}'`;
			break;
		}
		const _ = t[e];
		if (i && typeof _ !== i) {
			r = `JSON field '${e}' must be a ${i}.`;
			break;
		}
		if (void 0 !== s && _ !== s.value) {
			r = `Expected '${e}' field to equal '${s.value}'`;
			break;
		}
	}
	if (r) throw new e(ta.INVALID_ARGUMENT, r);
	return true;
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var Me$1 = -62135596800;
var Ne = 1e6;
/**
* A `Timestamp` represents a point in time independent of any time zone or
* calendar, represented as seconds and fractions of seconds at nanosecond
* resolution in UTC Epoch time.
*
* It is encoded using the Proleptic Gregorian Calendar which extends the
* Gregorian calendar backwards to year one. It is encoded assuming all minutes
* are 60 seconds long, i.e. leap seconds are "smeared" so that no leap second
* table is needed for interpretation. Range is from 0001-01-01T00:00:00Z to
* 9999-12-31T23:59:59.999999999Z.
*
* For examples and further specifications, refer to the
* {@link https://github.com/google/protobuf/blob/master/src/google/protobuf/timestamp.proto | Timestamp definition}.
*/
var Timestamp = class Timestamp {
	/**
	* Creates a new timestamp with the current date, with millisecond precision.
	*
	* @returns a new timestamp representing the current date.
	*/
	static now() {
		return Timestamp.fromMillis(Date.now());
	}
	/**
	* Creates a new timestamp from the given date.
	*
	* @param date - The date to initialize the `Timestamp` from.
	* @returns A new `Timestamp` representing the same point in time as the given
	*     date.
	*/ static fromDate(e) {
		return Timestamp.fromMillis(e.getTime());
	}
	/**
	* Creates a new timestamp from the given number of milliseconds.
	*
	* @param milliseconds - Number of milliseconds since Unix epoch
	*     1970-01-01T00:00:00Z.
	* @returns A new `Timestamp` representing the same point in time as the given
	*     number of milliseconds.
	*/ static fromMillis(e) {
		const t = Math.floor(e / 1e3), n = Math.floor((e - 1e3 * t) * Ne);
		return new Timestamp(t, n);
	}
	/**
	* Creates a new timestamp from the given `Temporal.Instant`.
	*
	* @param instant - The `Temporal.Instant` to initialize the `Timestamp` from.
	* @returns A new `Timestamp` representing the same point in time as the given
	*     instant.
	*/ static fromInstant(t) {
		if (!t || "bigint" != typeof t.t) throw new e(ta.INVALID_ARGUMENT, "Invalid Temporal.Instant object provided.");
		return Timestamp._fromEpochNanoseconds(t.t);
	}
	static _fromEpochNanoseconds(e) {
		let t, n;
		if (e >= 0n) t = Number(e / 1000000000n), n = Number(e % 1000000000n);
		else {
			const r = e % 1000000000n;
			0n === r ? (t = Number(e / 1000000000n), n = 0) : (t = Number(e / 1000000000n - 1n), n = Number(r + 1000000000n));
		}
		return new Timestamp(t, n);
	}
	/**
	* Creates a new timestamp.
	*
	* @param seconds - The number of seconds of UTC time since Unix epoch
	*     1970-01-01T00:00:00Z. Must be from 0001-01-01T00:00:00Z to
	*     9999-12-31T23:59:59Z inclusive.
	* @param nanoseconds - The non-negative fractions of a second at nanosecond
	*     resolution. Negative second values with fractions must still have
	*     non-negative nanoseconds values that count forward in time. Must be
	*     from 0 to 999,999,999 inclusive.
	*/ constructor(t, n) {
		if (this.seconds = t, this.nanoseconds = n, n < 0) throw new e(ta.INVALID_ARGUMENT, "Timestamp nanoseconds out of range: " + n);
		if (n >= 1e9) throw new e(ta.INVALID_ARGUMENT, "Timestamp nanoseconds out of range: " + n);
		if (t < Me$1) throw new e(ta.INVALID_ARGUMENT, "Timestamp seconds out of range: " + t);
		if (t >= 253402300800) throw new e(ta.INVALID_ARGUMENT, "Timestamp seconds out of range: " + t);
	}
	/**
	* Converts a `Timestamp` to a JavaScript `Date` object. This conversion
	* causes a loss of precision since `Date` objects only support millisecond
	* precision.
	*
	* @returns JavaScript `Date` object representing the same point in time as
	*     this `Timestamp`, with millisecond precision.
	*/ toDate() {
		return new Date(this.toMillis());
	}
	/**
	* Converts a `Timestamp` to a numeric timestamp (in milliseconds since
	* epoch). This operation causes a loss of precision.
	*
	* @returns The point in time corresponding to this timestamp, represented as
	*     the number of milliseconds since Unix epoch 1970-01-01T00:00:00Z.
	*/ toMillis() {
		return 1e3 * this.seconds + this.nanoseconds / Ne;
	}
	/**
	* Converts a `Timestamp` to a `Temporal.Instant` object.
	*
	* @returns `Temporal.Instant` object representing the same point in time as
	*     this `Timestamp`.
	*/ toInstant() {
		if ("undefined" == typeof Temporal || !Temporal.Instant) throw new e(ta.FAILED_PRECONDITION, "The Temporal object is not available in the current environment.");
		const t = 1000000000n * BigInt(this.seconds) + BigInt(this.nanoseconds);
		return Temporal.Instant.__PRIVATE_fromEpochNanoseconds(t);
	}
	_compareTo(e) {
		return this.seconds === e.seconds ? __PRIVATE_primitiveComparator(this.nanoseconds, e.nanoseconds) : __PRIVATE_primitiveComparator(this.seconds, e.seconds);
	}
	/**
	* Returns true if this `Timestamp` is equal to the provided one.
	*
	* @param other - The `Timestamp` to compare against.
	* @returns true if this `Timestamp` is equal to the provided one.
	*/ isEqual(e) {
		return e.seconds === this.seconds && e.nanoseconds === this.nanoseconds;
	}
	/** Returns a textual representation of this `Timestamp`. */ toString() {
		return "Timestamp(seconds=" + this.seconds + ", nanoseconds=" + this.nanoseconds + ")";
	}
	/**
	* Returns a JSON-serializable representation of this `Timestamp`.
	*/ toJSON() {
		return {
			type: Timestamp._jsonSchemaVersion,
			seconds: this.seconds,
			nanoseconds: this.nanoseconds
		};
	}
	/**
	* Builds a `Timestamp` instance from a JSON object created by {@link Timestamp.toJSON}.
	*/ static fromJSON(e) {
		if (__PRIVATE_validateJSON(e, Timestamp._jsonSchema)) return new Timestamp(e.seconds, e.nanoseconds);
	}
	/**
	* Converts this object to a primitive string, which allows `Timestamp` objects
	* to be compared using the `>`, `<=`, `>=` and `>` operators.
	*/ valueOf() {
		const e = this.seconds - Me$1;
		return String(e).padStart(12, "0") + "." + String(this.nanoseconds).padStart(9, "0");
	}
};
Timestamp._jsonSchemaVersion = "firestore/timestamp/1.0", Timestamp._jsonSchema = {
	type: property("string", Timestamp._jsonSchemaVersion),
	seconds: property("number"),
	nanoseconds: property("number")
};
/**
* @license
* Copyright 2023 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An error encountered while decoding base64 string.
*/
var __PRIVATE_Base64DecodeError = class extends Error {
	constructor() {
		super(...arguments), this.name = "Base64DecodeError";
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Immutable class that represents a "proto" byte string.
*
* Proto byte strings can either be Base64-encoded strings or Uint8Arrays when
* sent on the wire. This class abstracts away this differentiation by holding
* the proto byte string in a common class that must be converted into a string
* before being sent as a proto.
* @internal
*/ var ByteString = class ByteString {
	constructor(e) {
		this.binaryString = e;
	}
	static fromBase64String(e) {
		const t = function __PRIVATE_decodeBase64(e) {
			try {
				return atob(e);
			} catch (e) {
				throw "undefined" != typeof DOMException && e instanceof DOMException ? new __PRIVATE_Base64DecodeError("Invalid base64 string: " + e) : e;
			}
		}(e);
		return new ByteString(t);
	}
	static fromUint8Array(e) {
		const t = function __PRIVATE_binaryStringFromUint8Array(e) {
			let t = "";
			for (let n = 0; n < e.length; ++n) t += String.fromCharCode(e[n]);
			return t;
		}(e);
		return new ByteString(t);
	}
	[Symbol.iterator]() {
		let e = 0;
		return { next: () => e < this.binaryString.length ? {
			value: this.binaryString.charCodeAt(e++),
			done: false
		} : {
			value: void 0,
			done: true
		} };
	}
	toBase64() {
		return function __PRIVATE_encodeBase64(e) {
			return btoa(e);
		}(this.binaryString);
	}
	toUint8Array() {
		return function __PRIVATE_uint8ArrayFromBinaryString(e) {
			const t = new Uint8Array(e.length);
			for (let n = 0; n < e.length; n++) t[n] = e.charCodeAt(n);
			return t;
		}(this.binaryString);
		/**
		* @license
		* Copyright 2020 Google LLC
		*
		* Licensed under the Apache License, Version 2.0 (the "License");
		* you may not use this file except in compliance with the License.
		* You may obtain a copy of the License at
		*
		*   http://www.apache.org/licenses/LICENSE-2.0
		*
		* Unless required by applicable law or agreed to in writing, software
		* distributed under the License is distributed on an "AS IS" BASIS,
		* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
		* See the License for the specific language governing permissions and
		* limitations under the License.
		*/
	}
	approximateByteSize() {
		return 2 * this.binaryString.length;
	}
	compareTo(e) {
		return __PRIVATE_primitiveComparator(this.binaryString, e.binaryString);
	}
	isEqual(e) {
		return this.binaryString === e.binaryString;
	}
};
ByteString.EMPTY_BYTE_STRING = new ByteString("");
var Le = /* @__PURE__ */ new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);
/**
* Converts the possible Proto values for a timestamp value into a "seconds and
* nanos" representation.
*/ function __PRIVATE_normalizeTimestamp(e) {
	if (__PRIVATE_hardAssert(!!e, 39018), "string" == typeof e) {
		let t = 0;
		const n = Le.exec(e);
		if (__PRIVATE_hardAssert(!!n, 46558, { timestamp: e }), n[1]) {
			let e = n[1];
			e = (e + "000000000").substr(0, 9), t = Number(e);
		}
		const r = new Date(e);
		return {
			seconds: Math.floor(r.getTime() / 1e3),
			nanos: t
		};
	}
	return {
		seconds: __PRIVATE_normalizeNumber(e.seconds),
		nanos: __PRIVATE_normalizeNumber(e.nanos)
	};
}
/**
* Converts the possible Proto types for numbers into a JavaScript number.
* Returns 0 if the value is not numeric.
*/ function __PRIVATE_normalizeNumber(e) {
	return "number" == typeof e ? e : "string" == typeof e ? Number(e) : 0;
}
/** Converts the possible Proto types for Blobs into a ByteString. */ function __PRIVATE_normalizeByteString(e) {
	return "string" == typeof e ? ByteString.fromBase64String(e) : ByteString.fromUint8Array(e);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Represents a locally-applied ServerTimestamp.
*
* Server Timestamps are backed by MapValues that contain an internal field
* `__type__` with a value of `server_timestamp`. The previous value and local
* write time are stored in its `__previous_value__` and `__local_write_time__`
* fields respectively.
*
* Notes:
* - ServerTimestampValue instances are created as the result of applying a
*   transform. They can only exist in the local view of a document. Therefore
*   they do not need to be parsed or serialized.
* - When evaluated locally (e.g. for snapshot.data()), they by default
*   evaluate to `null`. This behavior can be configured by passing custom
*   FieldValueOptions to value().
* - With respect to other ServerTimestampValues, they sort by their
*   localWriteTime.
*/ var Be$1 = "server_timestamp";
var Ue = "__type__";
var ke = "__previous_value__";
var qe = "__local_write_time__";
function __PRIVATE_isServerTimestamp(e) {
	return (e?.mapValue?.fields || {})[Ue]?.stringValue === Be$1;
}
/**
* Creates a new ServerTimestamp proto value (using the internal format).
*/
/**
* Returns the value of the field before this ServerTimestamp was set.
*
* Preserving the previous values allows the user to display the last resoled
* value until the backend responds with the timestamp.
*/
function __PRIVATE_getPreviousValue(e) {
	const t = e.mapValue.fields[ke];
	return __PRIVATE_isServerTimestamp(t) ? __PRIVATE_getPreviousValue(t) : t;
}
/**
* Returns the local time at which this timestamp was first set.
*/ function __PRIVATE_getLocalWriteTime(e) {
	const t = __PRIVATE_normalizeTimestamp(e.mapValue.fields[qe].timestampValue);
	return new Timestamp(t.seconds, t.nanos);
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var DatabaseInfo = class {
	/**
	* Constructs a DatabaseInfo using the provided host, databaseId and
	* persistenceKey.
	*
	* @param databaseId - The database to use.
	* @param appId - The Firebase App Id.
	* @param persistenceKey - A unique identifier for this Firestore's local
	* storage (used in conjunction with the databaseId).
	* @param host - The Firestore backend host to connect to.
	* @param ssl - Whether to use SSL when connecting.
	* @param forceLongPolling - Whether to use the forceLongPolling option
	* when using WebChannel as the network transport.
	* @param autoDetectLongPolling - Whether to use the detectBufferingProxy
	* option when using WebChannel as the network transport.
	* @param longPollingOptions - Options that configure long-polling.
	* @param useFetchStreams - Whether to use the Fetch API instead of
	* XMLHTTPRequest
	*/
	constructor(e, t, n, r, i, s, _, o, a, u, c, l, E) {
		this.databaseId = e, this.appId = t, this.persistenceKey = n, this.host = r, this.ssl = i, this.forceLongPolling = s, this.autoDetectLongPolling = _, this.longPollingOptions = o, this.useFetchStreams = a, this.isUsingEmulator = u, this.apiKey = c, this._customHeaders = l, this.grpcFlowControlWindow = E;
	}
};
/** The default database name for a project. */ var $e = "(default)";
/**
* Represents the database ID a Firestore client is associated with.
* @internal
*/ var DatabaseId = class DatabaseId {
	constructor(e, t) {
		this.projectId = e, this.database = t || $e;
	}
	static empty() {
		return new DatabaseId("", "");
	}
	get isDefaultDatabase() {
		return this.database === $e;
	}
	isEqual(e) {
		return e instanceof DatabaseId && e.projectId === this.projectId && e.database === this.database;
	}
};
function __PRIVATE_databaseIdFromApp(t, n) {
	if (!Object.prototype.hasOwnProperty.apply(t.options, ["projectId"])) throw new e(ta.INVALID_ARGUMENT, "\"projectId\" not provided in firebase.initializeApp.");
	return new DatabaseId(t.options.projectId, n);
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/** Sentinel value that sorts before any Mutation Batch ID. */ var Ke = -1;
/**
* Returns whether a variable is either undefined or null.
*/ function __PRIVATE_isNullOrUndefined(e) {
	return null == e;
}
/** Returns whether the value represents -0. */ function __PRIVATE_isNegativeZero(e) {
	return 0 === e && 1 / e == -Infinity;
}
/**
* Returns whether a value is an integer and in the safe integer range
* @param value - The value to test for being an integer and in the safe range
*/ function isSafeInteger(e) {
	return "number" == typeof e && Number.isInteger(e) && !__PRIVATE_isNegativeZero(e) && e <= Number.MAX_SAFE_INTEGER && e >= Number.MIN_SAFE_INTEGER;
}
function __PRIVATE_isString$1(e) {
	return "string" == typeof e;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var Qe = "__type__";
var We = "__max__";
var Ge = { mapValue: { fields: { __type__: { stringValue: We } } } };
var ze = "__vector__";
var je = "value";
var He = { nullValue: "NULL_VALUE" };
var Je = { booleanValue: true };
var Ye = { booleanValue: false };
/** Extracts the backend's type order for the provided value. */
function __PRIVATE_typeOrder(e) {
	return "nullValue" in e ? 0 : "booleanValue" in e ? 1 : "integerValue" in e || "doubleValue" in e ? 2 : "timestampValue" in e ? 3 : "stringValue" in e ? 5 : "bytesValue" in e ? 6 : "referenceValue" in e ? 7 : "geoPointValue" in e ? 8 : "arrayValue" in e ? 9 : "mapValue" in e ? __PRIVATE_isServerTimestamp(e) ? 4 : __PRIVATE_isMaxValue(e) ? 9007199254740991 : __PRIVATE_isVectorValue(e) ? 10 : 11 : l(28295, { value: e });
}
/** Tests `left` and `right` for equality based on the backend semantics. */ function __PRIVATE_valueEquals$1(e, t, n) {
	if (e === t) return true;
	const r = __PRIVATE_typeOrder(e);
	if (r !== __PRIVATE_typeOrder(t)) return false;
	switch (r) {
		case 0:
		case 9007199254740991: return true;
		case 1: return e.booleanValue === t.booleanValue;
		case 4: return __PRIVATE_getLocalWriteTime(e).isEqual(__PRIVATE_getLocalWriteTime(t));
		case 3: return function __PRIVATE_timestampEquals(e, t) {
			if ("string" == typeof e.timestampValue && "string" == typeof t.timestampValue && e.timestampValue.length === t.timestampValue.length) return e.timestampValue === t.timestampValue;
			const n = __PRIVATE_normalizeTimestamp(e.timestampValue), r = __PRIVATE_normalizeTimestamp(t.timestampValue);
			return n.seconds === r.seconds && n.nanos === r.nanos;
		}(e, t);
		case 5: return e.stringValue === t.stringValue;
		case 6: return function __PRIVATE_blobEquals(e, t) {
			return __PRIVATE_normalizeByteString(e.bytesValue).isEqual(__PRIVATE_normalizeByteString(t.bytesValue));
		}(e, t);
		case 7: return e.referenceValue === t.referenceValue;
		case 8: return function __PRIVATE_geoPointEquals(e, t) {
			return __PRIVATE_normalizeNumber(e.geoPointValue.latitude) === __PRIVATE_normalizeNumber(t.geoPointValue.latitude) && __PRIVATE_normalizeNumber(e.geoPointValue.longitude) === __PRIVATE_normalizeNumber(t.geoPointValue.longitude);
		}(e, t);
		case 2: return function __PRIVATE_numberEquals(e, t, n) {
			if ("integerValue" in e && "integerValue" in t) return __PRIVATE_normalizeNumber(e.integerValue) === __PRIVATE_normalizeNumber(t.integerValue);
			let r, i;
			if ("doubleValue" in e && "doubleValue" in t) r = __PRIVATE_normalizeNumber(e.doubleValue), i = __PRIVATE_normalizeNumber(t.doubleValue);
			else {
				if (!n?.i) return false;
				r = __PRIVATE_normalizeNumber(e.integerValue ?? e.doubleValue), i = __PRIVATE_normalizeNumber(t.integerValue ?? t.doubleValue);
			}
			if (r === i) return !!n?.o || __PRIVATE_isNegativeZero(r) === __PRIVATE_isNegativeZero(i);
			return !!(void 0 === n || n.u) && isNaN(r) && isNaN(i);
		}(e, t, n);
		case 9: return __PRIVATE_arrayEquals(e.arrayValue.values || [], t.arrayValue.values || [], ((e, t) => __PRIVATE_valueEquals$1(e, t, n)));
		case 10:
		case 11: return function __PRIVATE_objectEquals(e, t, n) {
			const r = e.mapValue.fields || {}, i = t.mapValue.fields || {};
			if (__PRIVATE_objectSize(r) !== __PRIVATE_objectSize(i)) return false;
			for (const e in r) if (r.hasOwnProperty(e) && (void 0 === i[e] || !__PRIVATE_valueEquals$1(r[e], i[e], n))) return false;
			return true;
		}(e, t, n);
		default: return l(52216, { left: e });
	}
}
function __PRIVATE_arrayValueContains(e, t) {
	return void 0 !== (e.values || []).find(((e) => __PRIVATE_valueEquals$1(e, t)));
}
function __PRIVATE_valueCompare(e, t) {
	if (e === t) return 0;
	const n = __PRIVATE_typeOrder(e), r = __PRIVATE_typeOrder(t);
	if (n !== r) return __PRIVATE_primitiveComparator(n, r);
	switch (n) {
		case 0:
		case 9007199254740991: return 0;
		case 1: return __PRIVATE_primitiveComparator(e.booleanValue, t.booleanValue);
		case 2: return function __PRIVATE_compareNumbers(e, t) {
			const n = __PRIVATE_normalizeNumber(e.integerValue || e.doubleValue), r = __PRIVATE_normalizeNumber(t.integerValue || t.doubleValue);
			return n < r ? -1 : n > r ? 1 : n === r ? 0 : isNaN(n) ? isNaN(r) ? 0 : -1 : 1;
		}(e, t);
		case 3: return __PRIVATE_compareTimestamps(e.timestampValue, t.timestampValue);
		case 4: return __PRIVATE_compareTimestamps(__PRIVATE_getLocalWriteTime(e), __PRIVATE_getLocalWriteTime(t));
		case 5: return __PRIVATE_compareUtf8Strings(e.stringValue, t.stringValue);
		case 6: return function __PRIVATE_compareBlobs(e, t) {
			const n = __PRIVATE_normalizeByteString(e), r = __PRIVATE_normalizeByteString(t);
			return n.compareTo(r);
		}(e.bytesValue, t.bytesValue);
		case 7: return function __PRIVATE_compareReferences(e, t) {
			const n = e.split("/"), r = t.split("/");
			for (let e = 0; e < n.length && e < r.length; e++) {
				const t = __PRIVATE_primitiveComparator(n[e], r[e]);
				if (0 !== t) return t;
			}
			return __PRIVATE_primitiveComparator(n.length, r.length);
		}(e.referenceValue, t.referenceValue);
		case 8: return function __PRIVATE_compareGeoPoints(e, t) {
			const n = __PRIVATE_primitiveComparator(__PRIVATE_normalizeNumber(e.latitude), __PRIVATE_normalizeNumber(t.latitude));
			if (0 !== n) return n;
			return __PRIVATE_primitiveComparator(__PRIVATE_normalizeNumber(e.longitude), __PRIVATE_normalizeNumber(t.longitude));
		}(e.geoPointValue, t.geoPointValue);
		case 9: return __PRIVATE_compareArrays(e.arrayValue, t.arrayValue);
		case 10: return function __PRIVATE_compareVectors(e, t) {
			const n = e.fields || {}, r = t.fields || {}, i = n[je]?.arrayValue, s = r[je]?.arrayValue, _ = __PRIVATE_primitiveComparator(i?.values?.length || 0, s?.values?.length || 0);
			if (0 !== _) return _;
			return __PRIVATE_compareArrays(i, s);
		}(e.mapValue, t.mapValue);
		case 11: return function __PRIVATE_compareMaps(e, t) {
			if (e === Ge.mapValue && t === Ge.mapValue) return 0;
			if (e === Ge.mapValue) return 1;
			if (t === Ge.mapValue) return -1;
			const n = e.fields || {}, r = Object.keys(n), i = t.fields || {}, s = Object.keys(i);
			r.sort(), s.sort();
			for (let e = 0; e < r.length && e < s.length; ++e) {
				const t = __PRIVATE_compareUtf8Strings(r[e], s[e]);
				if (0 !== t) return t;
				const _ = __PRIVATE_valueCompare(n[r[e]], i[s[e]]);
				if (0 !== _) return _;
			}
			return __PRIVATE_primitiveComparator(r.length, s.length);
		}(e.mapValue, t.mapValue);
		default: throw l(23264, { l: n });
	}
}
function __PRIVATE_compareTimestamps(e, t) {
	if ("string" == typeof e && "string" == typeof t && e.length === t.length) return __PRIVATE_primitiveComparator(e, t);
	const n = __PRIVATE_normalizeTimestamp(e), r = __PRIVATE_normalizeTimestamp(t), i = __PRIVATE_primitiveComparator(n.seconds, r.seconds);
	return 0 !== i ? i : __PRIVATE_primitiveComparator(n.nanos, r.nanos);
}
function __PRIVATE_compareArrays(e, t) {
	const n = e.values || [], r = t.values || [];
	for (let e = 0; e < n.length && e < r.length; ++e) {
		const t = __PRIVATE_valueCompare(n[e], r[e]);
		if (void 0 !== t && 0 !== t) return t;
	}
	return __PRIVATE_primitiveComparator(n.length, r.length);
}
function canonicalId(e) {
	return __PRIVATE_canonifyValue(e);
}
function __PRIVATE_canonifyValue(e) {
	return "nullValue" in e ? "null" : "booleanValue" in e ? "" + e.booleanValue : "integerValue" in e ? "" + e.integerValue : "doubleValue" in e ? "" + e.doubleValue : "timestampValue" in e ? function __PRIVATE_canonifyTimestamp(e) {
		const t = __PRIVATE_normalizeTimestamp(e);
		return `time(${t.seconds},${t.nanos})`;
	}(e.timestampValue) : "stringValue" in e ? e.stringValue : "bytesValue" in e ? function __PRIVATE_canonifyByteString(e) {
		return __PRIVATE_normalizeByteString(e).toBase64();
	}(e.bytesValue) : "referenceValue" in e ? function __PRIVATE_canonifyReference(e) {
		return DocumentKey.fromName(e).toString();
	}(e.referenceValue) : "geoPointValue" in e ? function __PRIVATE_canonifyGeoPoint(e) {
		return `geo(${e.latitude},${e.longitude})`;
	}(e.geoPointValue) : "arrayValue" in e ? function __PRIVATE_canonifyArray(e) {
		let t = "[", n = true;
		for (const r of e.values || []) n ? n = false : t += ",", t += __PRIVATE_canonifyValue(r);
		return t + "]";
	}(e.arrayValue) : "mapValue" in e ? function __PRIVATE_canonifyMap(e) {
		const t = Object.keys(e.fields || {}).sort();
		let n = "{", r = true;
		for (const i of t) r ? r = false : n += ",", n += `${i}:${__PRIVATE_canonifyValue(e.fields[i])}`;
		return n + "}";
	}(e.mapValue) : l(61005, { value: e });
}
function __PRIVATE_estimateByteSize(e) {
	switch (__PRIVATE_typeOrder(e)) {
		case 0:
		case 1: return 4;
		case 2: return 8;
		case 3:
		case 8: return 16;
		case 4:
			const t = __PRIVATE_getPreviousValue(e);
			return t ? 16 + __PRIVATE_estimateByteSize(t) : 16;
		case 5: return 2 * e.stringValue.length;
		case 6: return __PRIVATE_normalizeByteString(e.bytesValue).approximateByteSize();
		case 7: return e.referenceValue.length;
		case 9: return function __PRIVATE_estimateArrayByteSize(e) {
			return (e.values || []).reduce(((e, t) => e + __PRIVATE_estimateByteSize(t)), 0);
		}(e.arrayValue);
		case 10:
		case 11: return function __PRIVATE_estimateMapByteSize(e) {
			let t = 0;
			return forEach(e.fields, ((e, n) => {
				t += e.length + __PRIVATE_estimateByteSize(n);
			})), t;
		}(e.mapValue);
		default: throw l(13486, { value: e });
	}
}
/** Returns true if `value` is an BooleanValue . */
/** Returns true if `value` is an IntegerValue . */
function isInteger(e) {
	return !!e && "integerValue" in e;
}
/** Returns true if `value` is a DoubleValue. */ function __PRIVATE_isDouble(e) {
	return !!e && "doubleValue" in e;
}
/** Returns true if `value` is either an IntegerValue or a DoubleValue. */ function R(e) {
	return isInteger(e) || __PRIVATE_isDouble(e);
}
/** Returns true if `value` is an ArrayValue. */ function isArray(e) {
	return !!e && "arrayValue" in e;
}
/** Returns true if `value` is an ArrayValue. */
/** Returns true if `value` is a NullValue. */
function __PRIVATE_isNullValue(e) {
	return !!e && "nullValue" in e;
}
/** Returns true if `value` is NaN. */ function __PRIVATE_isNanValue(e) {
	return !!e && "doubleValue" in e && isNaN(Number(e.doubleValue));
}
/** Returns true if `value` is Timestamp. */
/** Returns true if `value` is a MapValue. */
function __PRIVATE_isMapValue(e) {
	return !!e && "mapValue" in e;
}
/** Returns true if `value` is a VetorValue. */ function __PRIVATE_isVectorValue(e) {
	return (e?.mapValue?.fields || {})[Qe]?.stringValue === ze;
}
/** Returns true if `value` is a VetorValue. */ function __PRIVATE_getVectorValue(e) {
	return (e?.mapValue?.fields || {})[je]?.arrayValue;
}
/** Creates a deep copy of `source`. */ function __PRIVATE_deepClone(e) {
	if (e.geoPointValue) return { geoPointValue: { ...e.geoPointValue } };
	if (e.timestampValue && "object" == typeof e.timestampValue) return { timestampValue: { ...e.timestampValue } };
	if (e.mapValue) {
		const t = { mapValue: { fields: {} } };
		return forEach(e.mapValue.fields, ((e, n) => t.mapValue.fields[e] = __PRIVATE_deepClone(n))), t;
	}
	if (e.arrayValue) {
		const t = { arrayValue: { values: [] } };
		for (let n = 0; n < (e.arrayValue.values || []).length; ++n) t.arrayValue.values[n] = __PRIVATE_deepClone(e.arrayValue.values[n]);
		return t;
	}
	return { ...e };
}
/** Returns true if the Value represents the canonical {@link #MAX_VALUE} . */ function __PRIVATE_isMaxValue(e) {
	return (((e.mapValue || {}).fields || {}).__type__ || {}).stringValue === We;
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An ObjectValue represents a MapValue in the Firestore Proto and offers the
* ability to add and remove fields (via the ObjectValueBuilder).
*/ var ObjectValue = class ObjectValue {
	constructor(e) {
		this.value = e;
	}
	static empty() {
		return new ObjectValue({ mapValue: {} });
	}
	/**
	* Returns the value at the given path or null.
	*
	* @param path - the path to search
	* @returns The value at the path or null if the path is not set.
	*/ field(e) {
		if (e.isEmpty()) return this.value;
		{
			let t = this.value;
			for (let n = 0; n < e.length - 1; ++n) if (t = (t.mapValue.fields || {})[e.get(n)], !__PRIVATE_isMapValue(t)) return null;
			return t = (t.mapValue.fields || {})[e.lastSegment()], t || null;
		}
	}
	/**
	* Sets the field to the provided value.
	*
	* @param path - The field path to set.
	* @param value - The value to set.
	*/ set(e, t) {
		this.getFieldsMap(e.popLast())[e.lastSegment()] = __PRIVATE_deepClone(t);
	}
	/**
	* Sets the provided fields to the provided values.
	*
	* @param data - A map of fields to values (or null for deletes).
	*/ setAll(e) {
		let t = Oe.emptyPath(), n = {}, r = [];
		e.forEach(((e, i) => {
			if (!t.isImmediateParentOf(i)) {
				const e = this.getFieldsMap(t);
				this.applyChanges(e, n, r), n = {}, r = [], t = i.popLast();
			}
			e ? n[i.lastSegment()] = __PRIVATE_deepClone(e) : r.push(i.lastSegment());
		}));
		const i = this.getFieldsMap(t);
		this.applyChanges(i, n, r);
	}
	/**
	* Removes the field at the specified path. If there is no field at the
	* specified path, nothing is changed.
	*
	* @param path - The field path to remove.
	*/ delete(e) {
		const t = this.field(e.popLast());
		__PRIVATE_isMapValue(t) && t.mapValue.fields && delete t.mapValue.fields[e.lastSegment()];
	}
	isEqual(e) {
		return __PRIVATE_valueEquals$1(this.value, e.value);
	}
	/**
	* Returns the map that contains the leaf element of `path`. If the parent
	* entry does not yet exist, or if it is not a map, a new map will be created.
	*/ getFieldsMap(e) {
		let t = this.value;
		t.mapValue.fields || (t.mapValue = { fields: {} });
		for (let n = 0; n < e.length; ++n) {
			let r = t.mapValue.fields[e.get(n)];
			__PRIVATE_isMapValue(r) && r.mapValue.fields || (r = { mapValue: { fields: {} } }, t.mapValue.fields[e.get(n)] = r), t = r;
		}
		return t.mapValue.fields;
	}
	/**
	* Modifies `fieldsMap` by adding, replacing or deleting the specified
	* entries.
	*/ applyChanges(e, t, n) {
		forEach(t, ((t, n) => e[t] = n));
		for (const t of n) delete e[t];
	}
	clone() {
		return new ObjectValue(__PRIVATE_deepClone(this.value));
	}
};
/**
* Returns a FieldMask built from all fields in a MapValue.
*/ function __PRIVATE_extractFieldMask(e) {
	const t = [];
	return forEach(e.fields, ((e, n) => {
		const r = new Oe([e]);
		if (__PRIVATE_isMapValue(n)) {
			const e = __PRIVATE_extractFieldMask(n.mapValue).fields;
			if (0 === e.length) t.push(r);
			else for (const n of e) t.push(r.child(n));
		} else t.push(r);
	})), new FieldMask(t);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Returns an DoubleValue for `value` that is encoded based the serializer's
* `useProto3Json` setting.
*/ function __PRIVATE_toDouble(e, t) {
	if (e.useProto3Json) {
		if (isNaN(t)) return { doubleValue: "NaN" };
		if (t === Infinity) return { doubleValue: "Infinity" };
		if (t === -Infinity) return { doubleValue: "-Infinity" };
	}
	return { doubleValue: __PRIVATE_isNegativeZero(t) ? "-0" : t };
}
/**
* Returns an IntegerValue for `value`.
*/ function __PRIVATE_toInteger(e) {
	return { integerValue: "" + e };
}
/**
* Returns a value for a number that's appropriate to put into a proto.
* The return value is an IntegerValue if it can safely represent the value,
* otherwise a DoubleValue is returned.
*/ function toNumber(e, t, n) {
	return isSafeInteger(t) ? __PRIVATE_toInteger(t) : __PRIVATE_toDouble(e, t);
}
/**
* @license
* Copyright 2018 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/** Used to represent a field transform on a mutation. */ var TransformOperation = class {
	constructor() {
		this._ = void 0;
	}
};
/**
* Computes the local transform result against the provided `previousValue`,
* optionally using the provided localWriteTime.
*/ function __PRIVATE_applyTransformOperationToLocalView(e, t, n) {
	return e instanceof __PRIVATE_ServerTimestampTransform ? function serverTimestamp$1(e, t) {
		const n = { fields: {
			[Ue]: { stringValue: Be$1 },
			[qe]: { timestampValue: {
				seconds: e.seconds,
				nanos: e.nanoseconds
			} }
		} };
		return t && __PRIVATE_isServerTimestamp(t) && (t = __PRIVATE_getPreviousValue(t)), t && (n.fields[ke] = t), { mapValue: n };
	}(n, t) : e instanceof __PRIVATE_ArrayUnionTransformOperation ? __PRIVATE_applyArrayUnionTransformOperation(e, t) : e instanceof __PRIVATE_ArrayRemoveTransformOperation ? __PRIVATE_applyArrayRemoveTransformOperation(e, t) : e instanceof __PRIVATE_NumericIncrementTransformOperation ? function __PRIVATE_applyNumericIncrementTransformOperationToLocalView(e, t) {
		const n = __PRIVATE_computeTransformOperationBaseValue(e, t), r = asNumber(n) + asNumber(e.h);
		return isInteger(n) && isInteger(e.h) ? __PRIVATE_toInteger(r) : __PRIVATE_toDouble(e.serializer, r);
	}(e, t) : e instanceof __PRIVATE_NumericMinimumTransformOperation ? function __PRIVATE_applyNumericMinimumTransformOperationToLocalView(e, t) {
		return __PRIVATE_applyNumericTransformOperationToLocalView(e, t, Math.min);
	}(e, t) : e instanceof __PRIVATE_NumericMaximumTransformOperation ? function __PRIVATE_applyNumericMaximumTransformOperationToLocalView(e, t) {
		return __PRIVATE_applyNumericTransformOperationToLocalView(e, t, Math.max);
	}(e, t) : void 0;
}
/**
* Computes a final transform result after the transform has been acknowledged
* by the server, potentially using the server-provided transformResult.
*/ function __PRIVATE_applyTransformOperationToRemoteDocument(e, t, n) {
	return e instanceof __PRIVATE_ArrayUnionTransformOperation ? __PRIVATE_applyArrayUnionTransformOperation(e, t) : e instanceof __PRIVATE_ArrayRemoveTransformOperation ? __PRIVATE_applyArrayRemoveTransformOperation(e, t) : n;
}
/**
* If this transform operation is not idempotent, returns the base value to
* persist for this transform. If a base value is returned, the transform
* operation is always applied to this base value, even if document has
* already been updated.
*
* Base values provide consistent behavior for non-idempotent transforms and
* allow us to return the same latency-compensated value even if the backend
* has already applied the transform operation. The base value is null for
* idempotent transforms, as they can be re-played even if the backend has
* already applied them.
*
* @returns a base value to store along with the mutation, or null for
* idempotent transforms.
*/ function __PRIVATE_computeTransformOperationBaseValue(e, t) {
	return e instanceof __PRIVATE_NumericIncrementTransformOperation ? R(t) ? t : { integerValue: 0 } : null;
}
/** Transforms a value into a server-generated timestamp. */
var __PRIVATE_ServerTimestampTransform = class extends TransformOperation {};
/** Transforms an array value via a union operation. */ var __PRIVATE_ArrayUnionTransformOperation = class extends TransformOperation {
	constructor(e) {
		super(), this.elements = e;
	}
};
function __PRIVATE_applyArrayUnionTransformOperation(e, t) {
	const n = __PRIVATE_coercedFieldValuesArray(t);
	for (const t of e.elements) n.some(((e) => __PRIVATE_valueEquals$1(e, t))) || n.push(t);
	return { arrayValue: { values: n } };
}
/** Transforms an array value via a remove operation. */ var __PRIVATE_ArrayRemoveTransformOperation = class extends TransformOperation {
	constructor(e) {
		super(), this.elements = e;
	}
};
function __PRIVATE_applyArrayRemoveTransformOperation(e, t) {
	let n = __PRIVATE_coercedFieldValuesArray(t);
	for (const t of e.elements) n = n.filter(((e) => !__PRIVATE_valueEquals$1(e, t)));
	return { arrayValue: { values: n } };
}
/**
* Implements the backend semantics for locally computed NUMERIC_ADD (increment)
* transforms. Converts all field values to integers or doubles, but unlike the
* backend does not cap integer values at 2^63. Instead, JavaScript number
* arithmetic is used and precision loss can occur for values greater than 2^53.
*/ var __PRIVATE_NumericTransformOperation = class extends TransformOperation {
	constructor(e, t) {
		super(), this.serializer = e, this.h = t;
	}
};
var __PRIVATE_NumericIncrementTransformOperation = class extends __PRIVATE_NumericTransformOperation {};
var __PRIVATE_NumericMinimumTransformOperation = class extends __PRIVATE_NumericTransformOperation {};
var __PRIVATE_NumericMaximumTransformOperation = class extends __PRIVATE_NumericTransformOperation {};
function __PRIVATE_applyNumericTransformOperationToLocalView(e, t, n) {
	if (!R(t)) return e.h;
	const r = n(asNumber(t), asNumber(e.h));
	return isInteger(t) && isInteger(e.h) ? __PRIVATE_toInteger(r) : __PRIVATE_toDouble(e.serializer, r);
}
function asNumber(e) {
	return __PRIVATE_normalizeNumber(e.integerValue || e.doubleValue);
}
function __PRIVATE_coercedFieldValuesArray(e) {
	return isArray(e) && e.arrayValue.values ? e.arrayValue.values.slice() : [];
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function __PRIVATE_fieldTransformEquals(e, t) {
	return e.field.isEqual(t.field) && function __PRIVATE_transformOperationEquals(e, t) {
		return e instanceof __PRIVATE_ArrayUnionTransformOperation && t instanceof __PRIVATE_ArrayUnionTransformOperation || e instanceof __PRIVATE_ArrayRemoveTransformOperation && t instanceof __PRIVATE_ArrayRemoveTransformOperation ? __PRIVATE_arrayEquals(e.elements, t.elements, __PRIVATE_valueEquals$1) : e instanceof __PRIVATE_NumericIncrementTransformOperation && t instanceof __PRIVATE_NumericIncrementTransformOperation || e instanceof __PRIVATE_NumericMinimumTransformOperation && t instanceof __PRIVATE_NumericMinimumTransformOperation || e instanceof __PRIVATE_NumericMaximumTransformOperation && t instanceof __PRIVATE_NumericMaximumTransformOperation ? __PRIVATE_valueEquals$1(e.h, t.h) : e instanceof __PRIVATE_ServerTimestampTransform && t instanceof __PRIVATE_ServerTimestampTransform;
	}(e.transform, t.transform);
}
/** The result of successfully applying a mutation to the backend. */
var MutationResult = class {
	constructor(e, t) {
		this.version = e, this.transformResults = t;
	}
};
/**
* Encodes a precondition for a mutation. This follows the model that the
* backend accepts with the special case of an explicit "empty" precondition
* (meaning no precondition).
*/ var Precondition = class Precondition {
	constructor(e, t) {
		this.updateTime = e, this.exists = t;
	}
	/** Creates a new empty Precondition. */ static none() {
		return new Precondition();
	}
	/** Creates a new Precondition with an exists flag. */ static exists(e) {
		return new Precondition(void 0, e);
	}
	/** Creates a new Precondition based on a version a document exists at. */ static updateTime(e) {
		return new Precondition(e);
	}
	/** Returns whether this Precondition is empty. */ get isNone() {
		return void 0 === this.updateTime && void 0 === this.exists;
	}
	isEqual(e) {
		return this.exists === e.exists && (this.updateTime ? !!e.updateTime && this.updateTime.isEqual(e.updateTime) : !e.updateTime);
	}
};
/** Returns true if the preconditions is valid for the given document. */ function __PRIVATE_preconditionIsValidForDocument(e, t) {
	return void 0 !== e.updateTime ? t.isFoundDocument() && t.version.isEqual(e.updateTime) : void 0 === e.exists || e.exists === t.isFoundDocument();
}
/**
* A mutation describes a self-contained change to a document. Mutations can
* create, replace, delete, and update subsets of documents.
*
* Mutations not only act on the value of the document but also its version.
*
* For local mutations (mutations that haven't been committed yet), we preserve
* the existing version for Set and Patch mutations. For Delete mutations, we
* reset the version to 0.
*
* Here's the expected transition table.
*
* MUTATION           APPLIED TO            RESULTS IN
*
* SetMutation        Document(v3)          Document(v3)
* SetMutation        NoDocument(v3)        Document(v0)
* SetMutation        InvalidDocument(v0)   Document(v0)
* PatchMutation      Document(v3)          Document(v3)
* PatchMutation      NoDocument(v3)        NoDocument(v3)
* PatchMutation      InvalidDocument(v0)   UnknownDocument(v3)
* DeleteMutation     Document(v3)          NoDocument(v0)
* DeleteMutation     NoDocument(v3)        NoDocument(v0)
* DeleteMutation     InvalidDocument(v0)   NoDocument(v0)
*
* For acknowledged mutations, we use the updateTime of the WriteResponse as
* the resulting version for Set and Patch mutations. As deletes have no
* explicit update time, we use the commitTime of the WriteResponse for
* Delete mutations.
*
* If a mutation is acknowledged by the backend but fails the precondition check
* locally, we transition to an `UnknownDocument` and rely on Watch to send us
* the updated version.
*
* Field transforms are used only with Patch and Set Mutations. We use the
* `updateTransforms` message to store transforms, rather than the `transforms`s
* messages.
*
* ## Subclassing Notes
*
* Every type of mutation needs to implement its own applyToRemoteDocument() and
* applyToLocalView() to implement the actual behavior of applying the mutation
* to some source document (see `setMutationApplyToRemoteDocument()` for an
* example).
*/ var Mutation = class {};
/**
* A utility method to calculate a `Mutation` representing the overlay from the
* final state of the document, and a `FieldMask` representing the fields that
* are mutated by the local mutations.
*/ function __PRIVATE_calculateOverlayMutation(e, t) {
	if (!e.hasLocalMutations || t && 0 === t.fields.length) return null;
	if (null === t) return e.isNoDocument() ? new __PRIVATE_DeleteMutation(e.key, Precondition.none()) : new __PRIVATE_SetMutation(e.key, e.data, Precondition.none());
	{
		const n = e.data, r = ObjectValue.empty();
		let i = new SortedSet(Oe.comparator);
		for (let e of t.fields) if (!i.has(e)) {
			let t = n.field(e);
			null === t && e.length > 1 && (e = e.popLast(), t = n.field(e)), null === t ? r.delete(e) : r.set(e, t), i = i.add(e);
		}
		return new __PRIVATE_PatchMutation(e.key, r, new FieldMask(i.toArray()), Precondition.none());
	}
}
/**
* Applies this mutation to the given document for the purposes of computing a
* new remote document. If the input document doesn't match the expected state
* (e.g. it is invalid or outdated), the document type may transition to
* unknown.
*
* @param mutation - The mutation to apply.
* @param document - The document to mutate. The input document can be an
*     invalid document if the client has no knowledge of the pre-mutation state
*     of the document.
* @param mutationResult - The result of applying the mutation from the backend.
*/ function __PRIVATE_mutationApplyToRemoteDocument(e, t, n) {
	e instanceof __PRIVATE_SetMutation ? function __PRIVATE_setMutationApplyToRemoteDocument(e, t, n) {
		const r = e.value.clone(), i = __PRIVATE_serverTransformResults(e.fieldTransforms, t, n.transformResults);
		r.setAll(i), t.convertToFoundDocument(n.version, r).setHasCommittedMutations();
	}(e, t, n) : e instanceof __PRIVATE_PatchMutation ? function __PRIVATE_patchMutationApplyToRemoteDocument(e, t, n) {
		if (!__PRIVATE_preconditionIsValidForDocument(e.precondition, t)) return void t.convertToUnknownDocument(n.version);
		const r = __PRIVATE_serverTransformResults(e.fieldTransforms, t, n.transformResults), i = t.data;
		i.setAll(__PRIVATE_getPatch(e)), i.setAll(r), t.convertToFoundDocument(n.version, i).setHasCommittedMutations();
	}(e, t, n) : function __PRIVATE_deleteMutationApplyToRemoteDocument(e, t, n) {
		t.convertToNoDocument(n.version).setHasCommittedMutations();
	}(0, t, n);
}
/**
* Applies this mutation to the given document for the purposes of computing
* the new local view of a document. If the input document doesn't match the
* expected state, the document is not modified.
*
* @param mutation - The mutation to apply.
* @param document - The document to mutate. The input document can be an
*     invalid document if the client has no knowledge of the pre-mutation state
*     of the document.
* @param previousMask - The fields that have been updated before applying this mutation.
* @param localWriteTime - A timestamp indicating the local write time of the
*     batch this mutation is a part of.
* @returns A `FieldMask` representing the fields that are changed by applying this mutation.
*/ function __PRIVATE_mutationApplyToLocalView(e, t, n, r) {
	return e instanceof __PRIVATE_SetMutation ? function __PRIVATE_setMutationApplyToLocalView(e, t, n, r) {
		if (!__PRIVATE_preconditionIsValidForDocument(e.precondition, t)) return n;
		const i = e.value.clone(), s = __PRIVATE_localTransformResults(e.fieldTransforms, r, t);
		return i.setAll(s), t.convertToFoundDocument(t.version, i).setHasLocalMutations(), null;
	}(e, t, n, r) : e instanceof __PRIVATE_PatchMutation ? function __PRIVATE_patchMutationApplyToLocalView(e, t, n, r) {
		if (!__PRIVATE_preconditionIsValidForDocument(e.precondition, t)) return n;
		const i = __PRIVATE_localTransformResults(e.fieldTransforms, r, t), s = t.data;
		if (s.setAll(__PRIVATE_getPatch(e)), s.setAll(i), t.convertToFoundDocument(t.version, s).setHasLocalMutations(), null === n) return null;
		return n.unionWith(e.fieldMask.fields).unionWith(e.fieldTransforms.map(((e) => e.field)));
	}(e, t, n, r) : function __PRIVATE_deleteMutationApplyToLocalView(e, t, n) {
		if (__PRIVATE_preconditionIsValidForDocument(e.precondition, t)) return t.convertToNoDocument(t.version).setHasLocalMutations(), null;
		return n;
	}(e, t, n);
}
/**
* If this mutation is not idempotent, returns the base value to persist with
* this mutation. If a base value is returned, the mutation is always applied
* to this base value, even if document has already been updated.
*
* The base value is a sparse object that consists of only the document
* fields for which this mutation contains a non-idempotent transformation
* (e.g. a numeric increment). The provided value guarantees consistent
* behavior for non-idempotent transforms and allow us to return the same
* latency-compensated value even if the backend has already applied the
* mutation. The base value is null for idempotent mutations, as they can be
* re-played even if the backend has already applied them.
*
* @returns a base value to store along with the mutation, or null for
* idempotent mutations.
*/ function __PRIVATE_mutationExtractBaseValue(e, t) {
	let n = null;
	for (const r of e.fieldTransforms) {
		const e = t.data.field(r.field), i = __PRIVATE_computeTransformOperationBaseValue(r.transform, e || null);
		null != i && (null === n && (n = ObjectValue.empty()), n.set(r.field, i));
	}
	return n || null;
}
function __PRIVATE_mutationEquals(e, t) {
	return e.type === t.type && !!e.key.isEqual(t.key) && !!e.precondition.isEqual(t.precondition) && !!function __PRIVATE_fieldTransformsAreEqual(e, t) {
		return void 0 === e && void 0 === t || !(!e || !t) && __PRIVATE_arrayEquals(e, t, ((e, t) => __PRIVATE_fieldTransformEquals(e, t)));
	}(e.fieldTransforms, t.fieldTransforms) && (0 === e.type ? e.value.isEqual(t.value) : 1 !== e.type || e.data.isEqual(t.data) && e.fieldMask.isEqual(t.fieldMask));
}
/**
* A mutation that creates or replaces the document at the given key with the
* object value contents.
*/ var __PRIVATE_SetMutation = class extends Mutation {
	constructor(e, t, n, r = []) {
		super(), this.key = e, this.value = t, this.precondition = n, this.fieldTransforms = r, this.type = 0;
	}
	getFieldMask() {
		return null;
	}
};
var __PRIVATE_PatchMutation = class extends Mutation {
	constructor(e, t, n, r, i = []) {
		super(), this.key = e, this.data = t, this.fieldMask = n, this.precondition = r, this.fieldTransforms = i, this.type = 1;
	}
	getFieldMask() {
		return this.fieldMask;
	}
};
function __PRIVATE_getPatch(e) {
	const t = /* @__PURE__ */ new Map();
	return e.fieldMask.fields.forEach(((n) => {
		if (!n.isEmpty()) {
			const r = e.data.field(n);
			t.set(n, r);
		}
	})), t;
}
/**
* Creates a list of "transform results" (a transform result is a field value
* representing the result of applying a transform) for use after a mutation
* containing transforms has been acknowledged by the server.
*
* @param fieldTransforms - The field transforms to apply the result to.
* @param mutableDocument - The current state of the document after applying all
* previous mutations.
* @param serverTransformResults - The transform results received by the server.
* @returns The transform results list.
*/ function __PRIVATE_serverTransformResults(e, t, n) {
	const r = /* @__PURE__ */ new Map();
	__PRIVATE_hardAssert(e.length === n.length, 32656, {
		T: n.length,
		P: e.length
	});
	for (let i = 0; i < n.length; i++) {
		const s = e[i], _ = s.transform, o = t.data.field(s.field);
		r.set(s.field, __PRIVATE_applyTransformOperationToRemoteDocument(_, o, n[i]));
	}
	return r;
}
/**
* Creates a list of "transform results" (a transform result is a field value
* representing the result of applying a transform) for use when applying a
* transform locally.
*
* @param fieldTransforms - The field transforms to apply the result to.
* @param localWriteTime - The local time of the mutation (used to
*     generate ServerTimestampValues).
* @param mutableDocument - The document to apply transforms on.
* @returns The transform results list.
*/ function __PRIVATE_localTransformResults(e, t, n) {
	const r = /* @__PURE__ */ new Map();
	for (const i of e) {
		const e = i.transform, s = n.data.field(i.field);
		r.set(i.field, __PRIVATE_applyTransformOperationToLocalView(e, s, t));
	}
	return r;
}
/** A mutation that deletes the document at the given key. */ var __PRIVATE_DeleteMutation = class extends Mutation {
	constructor(e, t) {
		super(), this.key = e, this.precondition = t, this.type = 2, this.fieldTransforms = [];
	}
	getFieldMask() {
		return null;
	}
};
var __PRIVATE_VerifyMutation = class extends Mutation {
	constructor(e, t) {
		super(), this.key = e, this.precondition = t, this.type = 3, this.fieldTransforms = [];
	}
	getFieldMask() {
		return null;
	}
};
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Represents a bound of a query.
*
* The bound is specified with the given components representing a position and
* whether it's just before or just after the position (relative to whatever the
* query order is).
*
* The position represents a logical index position for a query. It's a prefix
* of values for the (potentially implicit) order by clauses of a query.
*
* Bound provides a function to determine whether a document comes before or
* after a bound. This is influenced by whether the position is just before or
* just after the provided values.
*/ var Bound = class {
	constructor(e, t) {
		this.position = e, this.inclusive = t;
	}
};
function __PRIVATE_boundCompareToDocument(e, t, n) {
	let r = 0;
	for (let i = 0; i < e.position.length; i++) {
		const s = t[i], _ = e.position[i];
		if (s.field.isKeyField()) r = DocumentKey.comparator(DocumentKey.fromName(_.referenceValue), n.key);
		else r = __PRIVATE_valueCompare(_, n.data.field(s.field));
		if ("desc" === s.dir && (r *= -1), 0 !== r) break;
	}
	return r;
}
/**
* Returns true if a document sorts after a bound using the provided sort
* order.
*/ function __PRIVATE_boundEquals(e, t) {
	if (null === e) return null === t;
	if (null === t) return false;
	if (e.inclusive !== t.inclusive || e.position.length !== t.position.length) return false;
	for (let n = 0; n < e.position.length; n++) if (!__PRIVATE_valueEquals$1(e.position[n], t.position[n])) return false;
	return true;
}
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var Filter = class {};
var FieldFilter = class FieldFilter extends Filter {
	constructor(e, t, n) {
		super(), this.field = e, this.op = t, this.value = n;
	}
	/**
	* Creates a filter based on the provided arguments.
	*/ static create(e, t, n) {
		return e.isKeyField() ? "in" === t || "not-in" === t ? this.createKeyFieldInFilter(e, t, n) : new __PRIVATE_KeyFieldFilter(e, t, n) : "array-contains" === t ? new __PRIVATE_ArrayContainsFilter(e, n) : "in" === t ? new __PRIVATE_InFilter(e, n) : "not-in" === t ? new __PRIVATE_NotInFilter(e, n) : "array-contains-any" === t ? new __PRIVATE_ArrayContainsAnyFilter(e, n) : new FieldFilter(e, t, n);
	}
	static createKeyFieldInFilter(e, t, n) {
		return "in" === t ? new __PRIVATE_KeyFieldInFilter(e, n) : new __PRIVATE_KeyFieldNotInFilter(e, n);
	}
	matches(e) {
		const t = e.data.field(this.field);
		return "!=" === this.op ? null !== t && void 0 === t.nullValue && this.matchesComparison(__PRIVATE_valueCompare(t, this.value)) : null !== t && __PRIVATE_typeOrder(this.value) === __PRIVATE_typeOrder(t) && this.matchesComparison(__PRIVATE_valueCompare(t, this.value));
	}
	matchesComparison(e) {
		switch (this.op) {
			case "<": return e < 0;
			case "<=": return e <= 0;
			case "==": return 0 === e;
			case "!=": return 0 !== e;
			case ">": return e > 0;
			case ">=": return e >= 0;
			default: return l(47266, { operator: this.op });
		}
	}
	isInequality() {
		return [
			"<",
			"<=",
			">",
			">=",
			"!=",
			"not-in"
		].indexOf(this.op) >= 0;
	}
	getFlattenedFilters() {
		return [this];
	}
	getFilters() {
		return [this];
	}
};
var CompositeFilter = class CompositeFilter extends Filter {
	constructor(e, t) {
		super(), this.filters = e, this.op = t, this.I = null;
	}
	/**
	* Creates a filter based on the provided arguments.
	*/ static create(e, t) {
		return new CompositeFilter(e, t);
	}
	matches(e) {
		return __PRIVATE_compositeFilterIsConjunction(this) ? void 0 === this.filters.find(((t) => !t.matches(e))) : void 0 !== this.filters.find(((t) => t.matches(e)));
	}
	getFlattenedFilters() {
		return null !== this.I || (this.I = this.filters.reduce(((e, t) => e.concat(t.getFlattenedFilters())), [])), this.I;
	}
	getFilters() {
		return Object.assign([], this.filters);
	}
};
function __PRIVATE_compositeFilterIsConjunction(e) {
	return "and" === e.op;
}
/**
* Returns true if this filter is a conjunction of field filters only. Returns false otherwise.
*/ function __PRIVATE_compositeFilterIsFlatConjunction(e) {
	return __PRIVATE_compositeFilterIsFlat(e) && __PRIVATE_compositeFilterIsConjunction(e);
}
/**
* Returns true if this filter does not contain any composite filters. Returns false otherwise.
*/ function __PRIVATE_compositeFilterIsFlat(e) {
	for (const t of e.filters) if (t instanceof CompositeFilter) return false;
	return true;
}
function __PRIVATE_canonifyFilter(e) {
	if (e instanceof FieldFilter) return e.field.canonicalString() + e.op.toString() + canonicalId(e.value);
	if (__PRIVATE_compositeFilterIsFlatConjunction(e)) return e.filters.map(((e) => __PRIVATE_canonifyFilter(e))).join(",");
	{
		const t = e.filters.map(((e) => __PRIVATE_canonifyFilter(e))).join(",");
		return `${e.op}(${t})`;
	}
}
function __PRIVATE_filterEquals(e, t) {
	return e instanceof FieldFilter ? function __PRIVATE_fieldFilterEquals(e, t) {
		return t instanceof FieldFilter && e.op === t.op && e.field.isEqual(t.field) && __PRIVATE_valueEquals$1(e.value, t.value);
	}(e, t) : e instanceof CompositeFilter ? function __PRIVATE_compositeFilterEquals(e, t) {
		if (t instanceof CompositeFilter && e.op === t.op && e.filters.length === t.filters.length) return e.filters.reduce(((e, n, r) => e && __PRIVATE_filterEquals(n, t.filters[r])), true);
		return false;
	}(e, t) : void l(19439);
}
/** Returns a debug description for `filter`. */ function __PRIVATE_stringifyFilter(e) {
	return e instanceof FieldFilter ? function __PRIVATE_stringifyFieldFilter(e) {
		return `${e.field.canonicalString()} ${e.op} ${canonicalId(e.value)}`;
	}(e) : e instanceof CompositeFilter ? function __PRIVATE_stringifyCompositeFilter(e) {
		return e.op.toString() + " {" + e.getFilters().map(__PRIVATE_stringifyFilter).join(" ,") + "}";
	}(e) : "Filter";
}
var __PRIVATE_KeyFieldFilter = class extends FieldFilter {
	constructor(e, t, n) {
		super(e, t, n), this.key = DocumentKey.fromName(n.referenceValue);
	}
	matches(e) {
		const t = DocumentKey.comparator(e.key, this.key);
		return this.matchesComparison(t);
	}
};
/** Filter that matches on key fields within an array. */ var __PRIVATE_KeyFieldInFilter = class extends FieldFilter {
	constructor(e, t) {
		super(e, "in", t), this.keys = __PRIVATE_extractDocumentKeysFromArrayValue("in", t);
	}
	matches(e) {
		return this.keys.some(((t) => t.isEqual(e.key)));
	}
};
/** Filter that matches on key fields not present within an array. */ var __PRIVATE_KeyFieldNotInFilter = class extends FieldFilter {
	constructor(e, t) {
		super(e, "not-in", t), this.keys = __PRIVATE_extractDocumentKeysFromArrayValue("not-in", t);
	}
	matches(e) {
		return !this.keys.some(((t) => t.isEqual(e.key)));
	}
};
function __PRIVATE_extractDocumentKeysFromArrayValue(e, t) {
	return (t.arrayValue?.values || []).map(((e) => DocumentKey.fromName(e.referenceValue)));
}
/** A Filter that implements the array-contains operator. */ var __PRIVATE_ArrayContainsFilter = class extends FieldFilter {
	constructor(e, t) {
		super(e, "array-contains", t);
	}
	matches(e) {
		const t = e.data.field(this.field);
		return isArray(t) && __PRIVATE_arrayValueContains(t.arrayValue, this.value);
	}
};
/** A Filter that implements the IN operator. */ var __PRIVATE_InFilter = class extends FieldFilter {
	constructor(e, t) {
		super(e, "in", t);
	}
	matches(e) {
		const t = e.data.field(this.field);
		return null !== t && __PRIVATE_arrayValueContains(this.value.arrayValue, t);
	}
};
/** A Filter that implements the not-in operator. */ var __PRIVATE_NotInFilter = class extends FieldFilter {
	constructor(e, t) {
		super(e, "not-in", t);
	}
	matches(e) {
		if (__PRIVATE_arrayValueContains(this.value.arrayValue, { nullValue: "NULL_VALUE" })) return false;
		const t = e.data.field(this.field);
		return null !== t && void 0 === t.nullValue && !__PRIVATE_arrayValueContains(this.value.arrayValue, t);
	}
};
/** A Filter that implements the array-contains-any operator. */ var __PRIVATE_ArrayContainsAnyFilter = class extends FieldFilter {
	constructor(e, t) {
		super(e, "array-contains-any", t);
	}
	matches(e) {
		const t = e.data.field(this.field);
		return !(!isArray(t) || !t.arrayValue.values) && t.arrayValue.values.some(((e) => __PRIVATE_arrayValueContains(this.value.arrayValue, e)));
	}
};
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An ordering on a field, in some Direction. Direction defaults to ASCENDING.
*/ var OrderBy = class {
	constructor(e, t = "asc") {
		this.field = e, this.dir = t;
	}
};
function __PRIVATE_orderByEquals(e, t) {
	return e.dir === t.dir && e.field.isEqual(t.field);
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A version of a document in Firestore. This corresponds to the version
* timestamp, such as update_time or read_time.
*/ var SnapshotVersion = class SnapshotVersion {
	static fromTimestamp(e) {
		return new SnapshotVersion(e);
	}
	static min() {
		return new SnapshotVersion(new Timestamp(0, 0));
	}
	static max() {
		return new SnapshotVersion(new Timestamp(253402300799, 999999999));
	}
	constructor(e) {
		this.timestamp = e;
	}
	compareTo(e) {
		return this.timestamp._compareTo(e.timestamp);
	}
	isEqual(e) {
		return this.timestamp.isEqual(e.timestamp);
	}
	/** Returns a number representation of the version for use in spec tests. */ toMicroseconds() {
		return 1e6 * this.timestamp.seconds + this.timestamp.nanoseconds / 1e3;
	}
	toString() {
		return "SnapshotVersion(" + this.timestamp.toString() + ")";
	}
	toTimestamp() {
		return this.timestamp;
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Represents a document in Firestore with a key, version, data and whether it
* has local mutations applied to it.
*
* Documents can transition between states via `convertToFoundDocument()`,
* `convertToNoDocument()` and `convertToUnknownDocument()`. If a document does
* not transition to one of these states even after all mutations have been
* applied, `isValidDocument()` returns false and the document should be removed
* from all views.
*/ var MutableDocument = class MutableDocument {
	constructor(e, t, n, r, i, s, _) {
		this.key = e, this.documentType = t, this.version = n, this.readTime = r, this.createTime = i, this.data = s, this.documentState = _;
	}
	/**
	* Creates a document with no known version or data, but which can serve as
	* base document for mutations.
	*/ static newInvalidDocument(e) {
		return new MutableDocument(e, 0, SnapshotVersion.min(), SnapshotVersion.min(), SnapshotVersion.min(), ObjectValue.empty(), 0);
	}
	/**
	* Creates a new document that is known to exist with the given data at the
	* given version.
	*/ static newFoundDocument(e, t, n, r) {
		return new MutableDocument(e, 1, t, SnapshotVersion.min(), n, r, 0);
	}
	/** Creates a new document that is known to not exist at the given version. */ static newNoDocument(e, t) {
		return new MutableDocument(e, 2, t, SnapshotVersion.min(), SnapshotVersion.min(), ObjectValue.empty(), 0);
	}
	/**
	* Creates a new document that is known to exist at the given version but
	* whose data is not known (e.g. a document that was updated without a known
	* base document).
	*/ static newUnknownDocument(e, t) {
		return new MutableDocument(e, 3, t, SnapshotVersion.min(), SnapshotVersion.min(), ObjectValue.empty(), 2);
	}
	/**
	* Changes the document type to indicate that it exists and that its version
	* and data are known.
	*/ convertToFoundDocument(e, t) {
		return !this.createTime.isEqual(SnapshotVersion.min()) || 2 !== this.documentType && 0 !== this.documentType || (this.createTime = e), this.version = e, this.documentType = 1, this.data = t, this.documentState = 0, this;
	}
	/**
	* Changes the document type to indicate that it doesn't exist at the given
	* version.
	*/ convertToNoDocument(e) {
		return this.version = e, this.documentType = 2, this.data = ObjectValue.empty(), this.documentState = 0, this;
	}
	/**
	* Changes the document type to indicate that it exists at a given version but
	* that its data is not known (e.g. a document that was updated without a known
	* base document).
	*/ convertToUnknownDocument(e) {
		return this.version = e, this.documentType = 3, this.data = ObjectValue.empty(), this.documentState = 2, this;
	}
	setHasCommittedMutations() {
		return this.documentState = 2, this;
	}
	setHasLocalMutations() {
		return this.documentState = 1, this.version = SnapshotVersion.min(), this;
	}
	setReadTime(e) {
		return this.readTime = e, this;
	}
	get hasLocalMutations() {
		return 1 === this.documentState;
	}
	get hasCommittedMutations() {
		return 2 === this.documentState;
	}
	get hasPendingWrites() {
		return this.hasLocalMutations || this.hasCommittedMutations;
	}
	isValidDocument() {
		return 0 !== this.documentType;
	}
	isFoundDocument() {
		return 1 === this.documentType;
	}
	isNoDocument() {
		return 2 === this.documentType;
	}
	isUnknownDocument() {
		return 3 === this.documentType;
	}
	isEqual(e) {
		return e instanceof MutableDocument && this.key.isEqual(e.key) && this.version.isEqual(e.version) && this.documentType === e.documentType && this.documentState === e.documentState && this.data.isEqual(e.data);
	}
	mutableCopy() {
		return new MutableDocument(this.key, this.documentType, this.version, this.readTime, this.createTime, this.data.clone(), this.documentState);
	}
	toString() {
		return `Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`;
	}
};
/**
* Compares the value for field `field` in the provided documents. Throws if
* the field does not exist in both documents.
*/
/**
* @license
* Copyright 2021 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* The initial mutation batch id for each index. Gets updated during index
* backfill.
*/
var Xe = -1;
/**
* The initial sequence number for each index. Gets updated during index
* backfill.
*/
/**
* An index definition for field indexes in Firestore.
*
* Every index is associated with a collection. The definition contains a list
* of fields and their index kind (which can be `ASCENDING`, `DESCENDING` or
* `CONTAINS` for ArrayContains/ArrayContainsAny queries).
*
* Unlike the backend, the SDK does not differentiate between collection or
* collection group-scoped indices. Every index can be used for both single
* collection and collection group queries.
*/
var FieldIndex = class {
	constructor(e, t, n, r) {
		this.indexId = e, this.collectionGroup = t, this.fields = n, this.indexState = r;
	}
};
/** Returns a debug representation of the field index */ FieldIndex.UNKNOWN_ID = -1;
/**
* Creates an offset that matches all documents with a read time higher than
* `readTime`.
*/ function __PRIVATE_newIndexOffsetSuccessorFromReadTime(e, t) {
	const n = e.toTimestamp().seconds, r = e.toTimestamp().nanoseconds + 1;
	return new IndexOffset(SnapshotVersion.fromTimestamp(1e9 === r ? new Timestamp(n + 1, 0) : new Timestamp(n, r)), DocumentKey.empty(), t);
}
/** Creates a new offset based on the provided document. */ function __PRIVATE_newIndexOffsetFromDocument(e) {
	return new IndexOffset(e.readTime, e.key, Xe);
}
/**
* Stores the latest read time, document and batch ID that were processed for an
* index.
*/ var IndexOffset = class IndexOffset {
	constructor(e, t, n) {
		this.readTime = e, this.documentKey = t, this.largestBatchId = n;
	}
	/** Returns an offset that sorts before all regular offsets. */ static min() {
		return new IndexOffset(SnapshotVersion.min(), DocumentKey.empty(), Xe);
	}
	/** Returns an offset that sorts after all regular offsets. */ static max() {
		return new IndexOffset(SnapshotVersion.max(), DocumentKey.empty(), Xe);
	}
};
function __PRIVATE_indexOffsetComparator(e, t) {
	let n = e.readTime.compareTo(t.readTime);
	return 0 !== n ? n : (n = DocumentKey.comparator(e.documentKey, t.documentKey), 0 !== n ? n : __PRIVATE_primitiveComparator(e.largestBatchId, t.largestBatchId));
}
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var __PRIVATE_TargetImpl = class {
	constructor(e, t = null, n = [], r = [], i = null, s = null, _ = null) {
		this.path = e, this.collectionGroup = t, this.orderBy = n, this.filters = r, this.limit = i, this.startAt = s, this.endAt = _, this.R = null;
	}
};
/**
* Initializes a Target with a path and optional additional query constraints.
* Path must currently be empty if this is a collection group query.
*
* NOTE: you should always construct `Target` from `Query.toTarget` instead of
* using this factory method, because `Query` provides an implicit `orderBy`
* property.
*/ function __PRIVATE_newTarget(e, t = null, n = [], r = [], i = null, s = null, _ = null) {
	return new __PRIVATE_TargetImpl(e, t, n, r, i, s, _);
}
function __PRIVATE_canonifyTarget(e) {
	const t = __PRIVATE_debugCast(e);
	if (null === t.R) {
		let e = t.path.canonicalString();
		null !== t.collectionGroup && (e += "|cg:" + t.collectionGroup), e += "|f:", e += t.filters.map(((e) => __PRIVATE_canonifyFilter(e))).join(","), e += "|ob:", e += t.orderBy.map(((e) => function __PRIVATE_canonifyOrderBy(e) {
			return e.field.canonicalString() + e.dir;
		}(e))).join(","), __PRIVATE_isNullOrUndefined(t.limit) || (e += "|l:", e += t.limit), t.startAt && (e += "|lb:", e += t.startAt.inclusive ? "b:" : "a:", e += t.startAt.position.map(((e) => canonicalId(e))).join(",")), t.endAt && (e += "|ub:", e += t.endAt.inclusive ? "a:" : "b:", e += t.endAt.position.map(((e) => canonicalId(e))).join(",")), t.R = e;
	}
	return t.R;
}
function __PRIVATE_targetEquals(e, t) {
	if (e.limit !== t.limit) return false;
	if (e.orderBy.length !== t.orderBy.length) return false;
	for (let n = 0; n < e.orderBy.length; n++) if (!__PRIVATE_orderByEquals(e.orderBy[n], t.orderBy[n])) return false;
	if (e.filters.length !== t.filters.length) return false;
	for (let n = 0; n < e.filters.length; n++) if (!__PRIVATE_filterEquals(e.filters[n], t.filters[n])) return false;
	return e.collectionGroup === t.collectionGroup && !!e.path.isEqual(t.path) && !!__PRIVATE_boundEquals(e.startAt, t.startAt) && __PRIVATE_boundEquals(e.endAt, t.endAt);
}
function __PRIVATE_targetIsPipelineTarget(e) {
	return !!e.isCorePipeline;
}
function __PRIVATE_targetIsDocumentTarget(e) {
	return !!e.path && DocumentKey.isDocumentKey(e.path) && null === e.collectionGroup && 0 === e.filters.length;
}
/** Returns the number of segments of a perfect index for this target. */
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Query encapsulates all the query attributes we support in the SDK. It can
* be run against the LocalStore, as well as be converted to a `Target` to
* query the RemoteStore results.
*
* Visible for testing.
*/
var __PRIVATE_QueryImpl = class {
	/**
	* Initializes a Query with a path and optional additional query constraints.
	* Path must currently be empty if this is a collection group query.
	*/
	constructor(e, t = null, n = [], r = [], i = null, s = "F", _ = null, o = null) {
		this.path = e, this.collectionGroup = t, this.explicitOrderBy = n, this.filters = r, this.limit = i, this.limitType = s, this.startAt = _, this.endAt = o, this.A = null, this.V = null, this.m = null, this.startAt, this.endAt;
	}
};
/** Creates a new Query instance with the options provided. */ function __PRIVATE_newQuery(e, t, n, r, i, s, _, o) {
	return new __PRIVATE_QueryImpl(e, t, n, r, i, s, _, o);
}
/** Creates a new Query for a query that matches all documents at `path` */ function __PRIVATE_newQueryForPath(e) {
	return new __PRIVATE_QueryImpl(e);
}
/**
* Helper to convert a collection group query into a collection query at a
* specific path. This is used when executing collection group queries, since
* we have to split the query into a set of collection queries at multiple
* paths.
*/
/**
* Returns true if this query does not specify any query constraints that
* could remove results.
*/
function __PRIVATE_queryMatchesAllDocuments(e) {
	return 0 === e.filters.length && null === e.limit && null == e.startAt && null == e.endAt && (0 === e.explicitOrderBy.length || 1 === e.explicitOrderBy.length && e.explicitOrderBy[0].field.isKeyField());
}
/**
* Returns whether the query matches a single document by path (rather than a
* collection).
*/
function __PRIVATE_isDocumentQuery$1(e) {
	return DocumentKey.isDocumentKey(e.path) && null === e.collectionGroup && 0 === e.filters.length;
}
/**
* Returns whether the query matches a collection group rather than a specific
* collection.
*/ function __PRIVATE_isCollectionGroupQuery(e) {
	return null !== e.collectionGroup;
}
/**
* Returns the normalized order-by constraint that is used to execute the Query,
* which can be different from the order-by constraints the user provided (e.g.
* the SDK and backend always orders by `__name__`). The normalized order-by
* includes implicit order-bys in addition to the explicit user provided
* order-bys.
*/ function __PRIVATE_queryNormalizedOrderBy(e) {
	const t = __PRIVATE_debugCast(e);
	if (null === t.A) {
		t.A = [];
		const e = /* @__PURE__ */ new Set();
		for (const n of t.explicitOrderBy) t.A.push(n), e.add(n.field.canonicalString());
		const n = t.explicitOrderBy.length > 0 ? t.explicitOrderBy[t.explicitOrderBy.length - 1].dir : "asc";
		(function __PRIVATE_getInequalityFilterFields(e) {
			let t = new SortedSet(Oe.comparator);
			return e.filters.forEach(((e) => {
				e.getFlattenedFilters().forEach(((e) => {
					e.isInequality() && (t = t.add(e.field));
				}));
			})), t;
		})(t).forEach(((r) => {
			e.has(r.canonicalString()) || r.isKeyField() || t.A.push(new OrderBy(r, n));
		})), e.has(Oe.keyField().canonicalString()) || t.A.push(new OrderBy(Oe.keyField(), n));
	}
	return t.A;
}
/**
* Converts this `Query` instance to its corresponding `Target` representation.
*/ function __PRIVATE_queryToTarget(e) {
	const t = __PRIVATE_debugCast(e);
	return t.V || (t.V = __PRIVATE__queryToTarget(t, __PRIVATE_queryNormalizedOrderBy(e))), t.V;
}
function __PRIVATE__queryToTarget(e, t) {
	if ("F" === e.limitType) return __PRIVATE_newTarget(e.path, e.collectionGroup, t, e.filters, e.limit, e.startAt, e.endAt);
	{
		t = t.map(((e) => {
			const t = "desc" === e.dir ? "asc" : "desc";
			return new OrderBy(e.field, t);
		}));
		const n = e.endAt ? new Bound(e.endAt.position, e.endAt.inclusive) : null, r = e.startAt ? new Bound(e.startAt.position, e.startAt.inclusive) : null;
		return __PRIVATE_newTarget(e.path, e.collectionGroup, t, e.filters, e.limit, n, r);
	}
}
function __PRIVATE_queryWithLimit(e, t, n) {
	return new __PRIVATE_QueryImpl(e.path, e.collectionGroup, e.explicitOrderBy.slice(), e.filters.slice(), t, n, e.startAt, e.endAt);
}
function __PRIVATE_queryEquals(e, t) {
	return __PRIVATE_targetEquals(__PRIVATE_queryToTarget(e), __PRIVATE_queryToTarget(t)) && e.limitType === t.limitType;
}
function __PRIVATE_stringifyQuery(e) {
	return `Query(target=${function __PRIVATE_stringifyTarget(e) {
		let t = e.path.canonicalString();
		return null !== e.collectionGroup && (t += " collectionGroup=" + e.collectionGroup), e.filters.length > 0 && (t += `, filters: [${e.filters.map(((e) => __PRIVATE_stringifyFilter(e))).join(", ")}]`), __PRIVATE_isNullOrUndefined(e.limit) || (t += ", limit: " + e.limit), e.orderBy.length > 0 && (t += `, orderBy: [${e.orderBy.map(((e) => function __PRIVATE_stringifyOrderBy(e) {
			return `${e.field.canonicalString()} (${e.dir})`;
		}(e))).join(", ")}]`), e.startAt && (t += ", startAt: ", t += e.startAt.inclusive ? "b:" : "a:", t += e.startAt.position.map(((e) => canonicalId(e))).join(",")), e.endAt && (t += ", endAt: ", t += e.endAt.inclusive ? "a:" : "b:", t += e.endAt.position.map(((e) => canonicalId(e))).join(",")), `Target(${t})`;
	}(__PRIVATE_queryToTarget(e))}; limitType=${e.limitType})`;
}
/** Returns whether `doc` matches the constraints of `query`. */ function __PRIVATE_queryMatches(e, t) {
	return t.isFoundDocument() && function __PRIVATE_queryMatchesPathAndCollectionGroup(e, t) {
		const n = t.key.path;
		return null !== e.collectionGroup ? t.key.hasCollectionId(e.collectionGroup) && e.path.isPrefixOf(n) : DocumentKey.isDocumentKey(e.path) ? e.path.isEqual(n) : e.path.isImmediateParentOf(n);
	}(e, t) && function __PRIVATE_queryMatchesOrderBy(e, t) {
		for (const n of __PRIVATE_queryNormalizedOrderBy(e)) if (!n.field.isKeyField() && null === t.data.field(n.field)) return false;
		return true;
	}(e, t) && function __PRIVATE_queryMatchesFilters(e, t) {
		for (const n of e.filters) if (!n.matches(t)) return false;
		return true;
	}(e, t) && function __PRIVATE_queryMatchesBounds(e, t) {
		if (e.startAt && !function __PRIVATE_boundSortsBeforeDocument(e, t, n) {
			const r = __PRIVATE_boundCompareToDocument(e, t, n);
			return e.inclusive ? r <= 0 : r < 0;
		}(e.startAt, __PRIVATE_queryNormalizedOrderBy(e), t)) return false;
		if (e.endAt && !function __PRIVATE_boundSortsAfterDocument(e, t, n) {
			const r = __PRIVATE_boundCompareToDocument(e, t, n);
			return e.inclusive ? r >= 0 : r > 0;
		}(e.endAt, __PRIVATE_queryNormalizedOrderBy(e), t)) return false;
		return true;
	}(e, t);
}
/**
* Returns a new comparator function that can be used to compare two documents
* based on the Query's ordering constraint.
*/
function __PRIVATE_newQueryComparator(e) {
	return (t, n) => {
		let r = false;
		for (const i of __PRIVATE_queryNormalizedOrderBy(e)) {
			const e = __PRIVATE_compareDocs(i, t, n);
			if (0 !== e) return e;
			r = r || i.field.isKeyField();
		}
		return 0;
	};
}
function __PRIVATE_compareDocs(e, t, n) {
	const r = e.field.isKeyField() ? DocumentKey.comparator(t.key, n.key) : function __PRIVATE_compareDocumentsByField(e, t, n) {
		const r = t.data.field(e), i = n.data.field(e);
		return null !== r && null !== i ? __PRIVATE_valueCompare(r, i) : l(42886);
	}(e.field, t, n);
	switch (e.dir) {
		case "asc": return r;
		case "desc": return -1 * r;
		default: return l(19790, { direction: e.dir });
	}
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var ExistenceFilter = class {
	constructor(e, t) {
		this.count = e, this.unchangedNames = t;
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Error Codes describing the different ways GRPC can fail. These are copied
* directly from GRPC's sources here:
*
* https://github.com/grpc/grpc/blob/bceec94ea4fc5f0085d81235d8e1c06798dc341a/include/grpc%2B%2B/impl/codegen/status_code_enum.h
*
* Important! The names of these identifiers matter because the string forms
* are used for reverse lookups from the webchannel stream. Do NOT change the
* names of these identifiers or change this into a const enum.
*/ var et;
var tt;
/**
* Determines whether an error code represents a permanent error when received
* in response to a non-write operation.
*
* See isPermanentWriteError for classifying write errors.
*/
function __PRIVATE_isPermanentError(e) {
	switch (e) {
		case ta.OK: return l(64938);
		case ta.CANCELLED:
		case ta.UNKNOWN:
		case ta.DEADLINE_EXCEEDED:
		case ta.RESOURCE_EXHAUSTED:
		case ta.INTERNAL:
		case ta.UNAVAILABLE:
		case ta.UNAUTHENTICATED: return false;
		case ta.INVALID_ARGUMENT:
		case ta.NOT_FOUND:
		case ta.ALREADY_EXISTS:
		case ta.PERMISSION_DENIED:
		case ta.FAILED_PRECONDITION:
		case ta.ABORTED:
		case ta.OUT_OF_RANGE:
		case ta.UNIMPLEMENTED:
		case ta.DATA_LOSS: return true;
		default: return l(15467, { code: e });
	}
}
/**
* Determines whether an error code represents a permanent error when received
* in response to a write operation.
*
* Write operations must be handled specially because as of b/119437764, ABORTED
* errors on the write stream should be retried too (even though ABORTED errors
* are not generally retryable).
*
* Note that during the initial handshake on the write stream an ABORTED error
* signals that we should discard our stream token (i.e. it is permanent). This
* means a handshake error should be classified with isPermanentError, above.
*/
/**
* Maps an error Code from GRPC status code number, like 0, 1, or 14. These
* are not the same as HTTP status codes.
*
* @returns The Code equivalent to the given GRPC status code. Fails if there
*     is no match.
*/
function __PRIVATE_mapCodeFromRpcCode(e) {
	if (void 0 === e) return __PRIVATE_logError("GRPC error has no .code"), ta.UNKNOWN;
	switch (e) {
		case et.OK: return ta.OK;
		case et.CANCELLED: return ta.CANCELLED;
		case et.UNKNOWN: return ta.UNKNOWN;
		case et.DEADLINE_EXCEEDED: return ta.DEADLINE_EXCEEDED;
		case et.RESOURCE_EXHAUSTED: return ta.RESOURCE_EXHAUSTED;
		case et.INTERNAL: return ta.INTERNAL;
		case et.UNAVAILABLE: return ta.UNAVAILABLE;
		case et.UNAUTHENTICATED: return ta.UNAUTHENTICATED;
		case et.INVALID_ARGUMENT: return ta.INVALID_ARGUMENT;
		case et.NOT_FOUND: return ta.NOT_FOUND;
		case et.ALREADY_EXISTS: return ta.ALREADY_EXISTS;
		case et.PERMISSION_DENIED: return ta.PERMISSION_DENIED;
		case et.FAILED_PRECONDITION: return ta.FAILED_PRECONDITION;
		case et.ABORTED: return ta.ABORTED;
		case et.OUT_OF_RANGE: return ta.OUT_OF_RANGE;
		case et.UNIMPLEMENTED: return ta.UNIMPLEMENTED;
		case et.DATA_LOSS: return ta.DATA_LOSS;
		default: return l(39323, { code: e });
	}
}
/**
* Converts an HTTP response's error status to the equivalent error code.
*
* @param status - An HTTP error response status ("FAILED_PRECONDITION",
* "UNKNOWN", etc.)
* @returns The equivalent Code. Non-matching responses are mapped to
*     Code.UNKNOWN.
*/ (tt = et || (et = {}))[tt.OK = 0] = "OK", tt[tt.CANCELLED = 1] = "CANCELLED", tt[tt.UNKNOWN = 2] = "UNKNOWN", tt[tt.INVALID_ARGUMENT = 3] = "INVALID_ARGUMENT", tt[tt.DEADLINE_EXCEEDED = 4] = "DEADLINE_EXCEEDED", tt[tt.NOT_FOUND = 5] = "NOT_FOUND", tt[tt.ALREADY_EXISTS = 6] = "ALREADY_EXISTS", tt[tt.PERMISSION_DENIED = 7] = "PERMISSION_DENIED", tt[tt.UNAUTHENTICATED = 16] = "UNAUTHENTICATED", tt[tt.RESOURCE_EXHAUSTED = 8] = "RESOURCE_EXHAUSTED", tt[tt.FAILED_PRECONDITION = 9] = "FAILED_PRECONDITION", tt[tt.ABORTED = 10] = "ABORTED", tt[tt.OUT_OF_RANGE = 11] = "OUT_OF_RANGE", tt[tt.UNIMPLEMENTED = 12] = "UNIMPLEMENTED", tt[tt.INTERNAL = 13] = "INTERNAL", tt[tt.UNAVAILABLE = 14] = "UNAVAILABLE", tt[tt.DATA_LOSS = 15] = "DATA_LOSS";
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A map implementation that uses objects as keys. Objects must have an
* associated equals function and must be immutable. Entries in the map are
* stored together with the key being produced from the mapKeyFn. This map
* automatically handles collisions of keys.
*/
var ObjectMap = class {
	constructor(e, t) {
		this.mapKeyFn = e, this.equalsFn = t, this.inner = {}, this.innerSize = 0;
	}
	/** Get a value for this key, or undefined if it does not exist. */ get(e) {
		const t = this.mapKeyFn(e), n = this.inner[t];
		if (void 0 !== n) {
			for (const [t, r] of n) if (this.equalsFn(t, e)) return r;
		}
	}
	has(e) {
		return void 0 !== this.get(e);
	}
	/** Put this key and value in the map. */ set(e, t) {
		const n = this.mapKeyFn(e), r = this.inner[n];
		if (void 0 === r) return this.inner[n] = [[e, t]], void this.innerSize++;
		for (let n = 0; n < r.length; n++) if (this.equalsFn(r[n][0], e)) return void (r[n] = [e, t]);
		r.push([e, t]), this.innerSize++;
	}
	/**
	* Remove this key from the map. Returns a boolean if anything was deleted.
	*/ delete(e) {
		const t = this.mapKeyFn(e), n = this.inner[t];
		if (void 0 === n) return false;
		for (let r = 0; r < n.length; r++) if (this.equalsFn(n[r][0], e)) return 1 === n.length ? delete this.inner[t] : n.splice(r, 1), this.innerSize--, true;
		return false;
	}
	forEach(e) {
		forEach(this.inner, ((t, n) => {
			for (const [t, r] of n) e(t, r);
		}));
	}
	isEmpty() {
		return isEmpty(this.inner);
	}
	size() {
		return this.innerSize;
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var nt = new SortedMap(DocumentKey.comparator);
function __PRIVATE_mutableDocumentMap() {
	return nt;
}
var rt = new SortedMap(DocumentKey.comparator);
function documentMap(...e) {
	let t = rt;
	for (const n of e) t = t.insert(n.key, n);
	return t;
}
function __PRIVATE_convertOverlayedDocumentMapToDocumentMap(e) {
	let t = rt;
	return e.forEach(((e, n) => t = t.insert(e, n.overlayedDocument))), t;
}
function __PRIVATE_newOverlayMap() {
	return __PRIVATE_newDocumentKeyMap();
}
function __PRIVATE_newMutationMap() {
	return __PRIVATE_newDocumentKeyMap();
}
function __PRIVATE_newDocumentKeyMap() {
	return new ObjectMap(((e) => e.toString()), ((e, t) => e.isEqual(t)));
}
var it = new SortedMap(DocumentKey.comparator);
var st = new SortedSet(DocumentKey.comparator);
function __PRIVATE_documentKeySet(...e) {
	let t = st;
	for (const n of e) t = t.add(n);
	return t;
}
var _t = new SortedSet(__PRIVATE_primitiveComparator);
function __PRIVATE_targetIdSet() {
	return _t;
}
/**
* @license
* Copyright 2023 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* The global, singleton instance of TestingHooksSpi.
*
* This variable will be `null` in all cases _except_ when running from
* integration tests that have registered callbacks to be notified of events
* that happen during the test execution.
*/ var ot = null;
/**
* @license
* Copyright 2023 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An instance of the Platform's 'TextEncoder' implementation.
*/ function __PRIVATE_newTextEncoder() {
	return new TextEncoder();
}
/**
* An instance of the Platform's 'TextDecoder' implementation.
*/
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var at = new Integer([4294967295, 4294967295], 0);
function __PRIVATE_getMd5HashValue(e) {
	const t = __PRIVATE_newTextEncoder().encode(e), n = new Md5();
	return n.update(t), new Uint8Array(n.digest());
}
function __PRIVATE_get64BitUints(e) {
	const t = new DataView(e.buffer), n = t.getUint32(0, true), r = t.getUint32(4, true), i = t.getUint32(8, true), s = t.getUint32(12, true);
	return [new Integer([n, r], 0), new Integer([i, s], 0)];
}
var BloomFilter = class BloomFilter {
	constructor(e, t, n) {
		if (this.bitmap = e, this.padding = t, this.hashCount = n, t < 0 || t >= 8) throw new __PRIVATE_BloomFilterError(`Invalid padding: ${t}`);
		if (n < 0) throw new __PRIVATE_BloomFilterError(`Invalid hash count: ${n}`);
		if (e.length > 0 && 0 === this.hashCount) throw new __PRIVATE_BloomFilterError(`Invalid hash count: ${n}`);
		if (0 === e.length && 0 !== t) throw new __PRIVATE_BloomFilterError(`Invalid padding when bitmap length is 0: ${t}`);
		this.p = 8 * e.length - t, this.S = Integer.fromNumber(this.p);
	}
	v(e, t, n) {
		let r = e.add(t.multiply(Integer.fromNumber(n)));
		return 1 === r.compare(at) && (r = new Integer([r.getBits(0), r.getBits(1)], 0)), r.modulo(this.S).toNumber();
	}
	D(e) {
		return !!(this.bitmap[Math.floor(e / 8)] & 1 << e % 8);
	}
	mightContain(e) {
		if (0 === this.p) return false;
		const [n, r] = __PRIVATE_get64BitUints(__PRIVATE_getMd5HashValue(e));
		for (let e = 0; e < this.hashCount; e++) {
			const t = this.v(n, r, e);
			if (!this.D(t)) return false;
		}
		return true;
	}
	/** Create bloom filter for testing purposes only. */ static create(e, t, n) {
		const r = e % 8 == 0 ? 0 : 8 - e % 8, i = new Uint8Array(Math.ceil(e / 8)), s = new BloomFilter(i, r, t);
		return n.forEach(((e) => s.insert(e))), s;
	}
	insert(e) {
		if (0 === this.p) return;
		const [n, r] = __PRIVATE_get64BitUints(__PRIVATE_getMd5HashValue(e));
		for (let e = 0; e < this.hashCount; e++) {
			const t = this.v(n, r, e);
			this.C(t);
		}
	}
	C(e) {
		const t = Math.floor(e / 8), n = e % 8;
		this.bitmap[t] |= 1 << n;
	}
};
var __PRIVATE_BloomFilterError = class extends Error {
	constructor() {
		super(...arguments), this.name = "BloomFilterError";
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An event from the RemoteStore. It is split into targetChanges (changes to the
* state or the set of documents in our watched targets) and documentUpdates
* (changes to the actual documents).
*/ var RemoteEvent = class RemoteEvent {
	constructor(e, t, n, r, i, s) {
		this.snapshotVersion = e, this.targetChanges = t, this.targetMismatches = n, this.documentUpdates = r, this.augmentedDocumentUpdates = i, this.resolvedLimboDocuments = s;
	}
	/**
	* HACK: Views require RemoteEvents in order to determine whether the view is
	* CURRENT, but secondary tabs don't receive remote events. So this method is
	* used to create a synthesized RemoteEvent that can be used to apply a
	* CURRENT status change to a View, for queries executed in a different tab.
	*/
	static createSynthesizedRemoteEventForCurrentChange(e, t, n) {
		const r = /* @__PURE__ */ new Map();
		return r.set(e, TargetChange.createSynthesizedTargetChangeForCurrentChange(e, t, n)), new RemoteEvent(SnapshotVersion.min(), r, new SortedMap(__PRIVATE_primitiveComparator), __PRIVATE_mutableDocumentMap(), __PRIVATE_mutableDocumentMap(), __PRIVATE_documentKeySet());
	}
};
/**
* A TargetChange specifies the set of changes for a specific target as part of
* a RemoteEvent. These changes track which documents are added, modified or
* removed, as well as the target's resume token and whether the target is
* marked CURRENT.
* The actual changes *to* documents are not part of the TargetChange since
* documents may be part of multiple targets.
*/ var TargetChange = class TargetChange {
	constructor(e, t, n, r, i) {
		this.resumeToken = e, this.current = t, this.addedDocuments = n, this.modifiedDocuments = r, this.removedDocuments = i;
	}
	/**
	* This method is used to create a synthesized TargetChanges that can be used to
	* apply a CURRENT status change to a View (for queries executed in a different
	* tab) or for new queries (to raise snapshots with correct CURRENT status).
	*/ static createSynthesizedTargetChangeForCurrentChange(e, t, n) {
		return new TargetChange(n, t, __PRIVATE_documentKeySet(), __PRIVATE_documentKeySet(), __PRIVATE_documentKeySet());
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Represents a changed document and a list of target ids to which this change
* applies.
*
* If document has been deleted NoDocument will be provided.
*/ var __PRIVATE_DocumentWatchChange = class {
	constructor(e, t, n, r) {
		this.F = e, this.removedTargetIds = t, this.key = n, this.O = r;
	}
};
var __PRIVATE_ExistenceFilterChange = class {
	constructor(e, t) {
		this.targetId = e, this.M = t;
	}
};
var __PRIVATE_WatchTargetChange = class {
	constructor(e, t, n = ByteString.EMPTY_BYTE_STRING, r = null) {
		this.state = e, this.targetIds = t, this.resumeToken = n, this.cause = r;
	}
};
/** Tracks the internal state of a Watch target. */ var __PRIVATE_TargetState = class {
	/**
	* Track the targetId for logging.
	*/
	constructor(e) {
		this.targetId = e, this.N = 0, this.L = __PRIVATE_snapshotChangesMap(), this.B = ByteString.EMPTY_BYTE_STRING, this.U = false, this.k = true;
	}
	/**
	* Whether this target has been marked 'current'.
	*
	* 'Current' has special meaning in the RPC protocol: It implies that the
	* Watch backend has sent us all changes up to the point at which the target
	* was added and that the target is consistent with the rest of the watch
	* stream.
	*/ get current() {
		return this.U;
	}
	/** The last resume token sent to us for this target. */ get resumeToken() {
		return this.B;
	}
	/** Whether this target has pending target adds or target removes. */ get q() {
		return 0 !== this.N;
	}
	/** Whether we have modified any state that should trigger a snapshot. */ get $() {
		return this.k;
	}
	/**
	* Applies the resume token to the TargetChange, but only when it has a new
	* value. Empty resumeTokens are discarded.
	*/ K(e) {
		e.approximateByteSize() > 0 && (this.k = true, this.B = e);
	}
	/**
	* Creates a target change from the current set of changes.
	*
	* To reset the document changes after raising this snapshot, call
	* `clearPendingChanges()`.
	*/ W() {
		let e = __PRIVATE_documentKeySet(), t = __PRIVATE_documentKeySet(), n = __PRIVATE_documentKeySet();
		return this.L.forEach(((r, i) => {
			switch (i) {
				case 0:
					e = e.add(r);
					break;
				case 2:
					t = t.add(r);
					break;
				case 1:
					n = n.add(r);
					break;
				default: l(38017, { changeType: i });
			}
		})), new TargetChange(this.B, this.U, e, t, n);
	}
	/**
	* Resets the document changes and sets `hasPendingChanges` to false.
	*/ G() {
		this.k = false, this.L = __PRIVATE_snapshotChangesMap();
	}
	j(e, t) {
		this.k = true, this.L = this.L.insert(e, t);
	}
	H(e) {
		this.k = true, this.L = this.L.remove(e);
	}
	J() {
		this.N += 1;
	}
	Y() {
		this.N -= 1, __PRIVATE_hardAssert(this.N >= 0, 3241, {
			N: this.N,
			targetId: this.targetId
		});
	}
	Z() {
		this.k = true, this.U = true;
	}
};
var ut = "WatchChangeAggregator";
/**
* A helper class to accumulate watch changes into a RemoteEvent.
*/ var __PRIVATE_WatchChangeAggregator = class {
	constructor(e) {
		this.X = e, this.ee = /* @__PURE__ */ new Map(), this.te = __PRIVATE_mutableDocumentMap(), this.ne = __PRIVATE_documentTargetMap(), this.re = __PRIVATE_mutableDocumentMap(), this.ie = __PRIVATE_documentTargetMap(), this.se = new SortedMap(__PRIVATE_primitiveComparator);
	}
	/**
	* Processes and adds the DocumentWatchChange to the current set of changes.
	*/ _e(e) {
		for (const t of e.F) e.O && e.O.isFoundDocument() ? this.oe(t, e.O) : this.ae(t, e.key, e.O);
		for (const t of e.removedTargetIds) this.ae(t, e.key, e.O);
	}
	/** Processes and adds the WatchTargetChange to the current set of changes. */ ue(e) {
		this.forEachTarget(e, ((t) => {
			const n = this.ee.get(t);
			if (n) switch (e.state) {
				case 0:
					this.ce(t) && n.K(e.resumeToken);
					break;
				case 1:
					n.Y(), n.q || n.G(), n.K(e.resumeToken);
					break;
				case 2:
					n.Y(), n.q || this.removeTarget(t);
					break;
				case 3:
					this.ce(t) && (n.Z(), n.K(e.resumeToken));
					break;
				case 4:
					this.ce(t) && (this.le(t), n.K(e.resumeToken));
					break;
				default: l(56790, { state: e.state });
			}
			else __PRIVATE_logDebug(ut, `handleTargetChange received targetChange for untracked target ID (${t}) with state (${e.state})`);
		}));
	}
	/**
	* Iterates over all targetIds that the watch change applies to: either the
	* targetIds explicitly listed in the change or the targetIds of all currently
	* active targets.
	*/ forEachTarget(e, t) {
		e.targetIds.length > 0 ? e.targetIds.forEach(t) : this.ee.forEach(((e, n) => {
			this.ce(n) && t(n);
		}));
	}
	Ee(e) {
		return __PRIVATE_targetIsPipelineTarget(e) ? "documents" === e.getPipelineSourceType() && 1 === e.getPipelineDocuments()?.length : __PRIVATE_targetIsDocumentTarget(e);
	}
	/**
	* Handles existence filters and synthesizes deletes for filter mismatches.
	* Targets that are invalidated by filter mismatches are added to
	* `pendingTargetResets`.
	*/ he(e) {
		const t = e.targetId, n = e.M.count, r = this.Te(t);
		if (r) {
			const i = r.target;
			if (this.Ee(i)) if (0 === n) {
				const e = new DocumentKey(__PRIVATE_targetIsPipelineTarget(i) ? ResourcePath.fromString(i.getPipelineDocuments()[0]) : i.path);
				this.ae(t, e, MutableDocument.newNoDocument(e, SnapshotVersion.min()));
			} else __PRIVATE_hardAssert(1 === n, 20013, "Single document existence filter with count: " + n);
			else {
				const r = this.Pe(t);
				if (r !== n) {
					const n = this.Ie(e), i = n ? this.Re(n, e, r) : 1;
					if (0 !== i) {
						this.le(t);
						const e = 2 === i ? "TargetPurposeExistenceFilterMismatchBloom" : "TargetPurposeExistenceFilterMismatch";
						this.se = this.se.insert(t, e);
					}
					ot?.Ae(function __PRIVATE_createExistenceFilterMismatchInfoForTestingHooks(e, t, n, r, i) {
						const s = {
							localCacheCount: e,
							existenceFilterCount: t.count,
							databaseId: n.database,
							projectId: n.projectId
						}, _ = t.unchangedNames;
						_ && (s.bloomFilter = {
							applied: 0 === i,
							hashCount: _?.hashCount ?? 0,
							bitmapLength: _?.bits?.bitmap?.length ?? 0,
							padding: _?.bits?.padding ?? 0,
							mightContain: (e) => r?.mightContain(e) ?? false
						});
						return s;
					}(r, e.M, this.X.Ve(), n, i));
					/**
					* @license
					* Copyright 2017 Google LLC
					*
					* Licensed under the Apache License, Version 2.0 (the "License");
					* you may not use this file except in compliance with the License.
					* You may obtain a copy of the License at
					*
					*   http://www.apache.org/licenses/LICENSE-2.0
					*
					* Unless required by applicable law or agreed to in writing, software
					* distributed under the License is distributed on an "AS IS" BASIS,
					* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
					* See the License for the specific language governing permissions and
					* limitations under the License.
					*/
				}
			}
		}
	}
	/**
	* Parse the bloom filter from the "unchanged_names" field of an existence
	* filter.
	*/ Ie(e) {
		const t = e.M.unchangedNames;
		if (!t || !t.bits) return null;
		const { bits: { bitmap: n = "", padding: r = 0 }, hashCount: i = 0 } = t;
		let s, _;
		try {
			s = __PRIVATE_normalizeByteString(n).toUint8Array();
		} catch (e) {
			if (e instanceof __PRIVATE_Base64DecodeError) return __PRIVATE_logWarn("Decoding the base64 bloom filter in existence filter failed (" + e.message + "); ignoring the bloom filter and falling back to full re-query."), null;
			throw e;
		}
		try {
			_ = new BloomFilter(s, r, i);
		} catch (e) {
			return __PRIVATE_logWarn(e instanceof __PRIVATE_BloomFilterError ? "BloomFilter error: " : "Applying bloom filter failed: ", e), null;
		}
		return 0 === _.p ? null : _;
	}
	/**
	* Apply bloom filter to remove the deleted documents, and return the
	* application status.
	*/ Re(e, t, n) {
		return t.M.count === n - this.de(e, t.targetId) ? 0 : 2;
	}
	/**
	* Filter out removed documents based on bloom filter membership result and
	* return number of documents removed.
	*/ de(e, t) {
		const n = this.X.getRemoteKeysForTarget(t);
		let r = 0;
		return n.forEach(((n) => {
			const i = this.X.Ve(), s = `projects/${i.projectId}/databases/${i.database}/documents/${n.path.canonicalString()}`;
			e.mightContain(s) || (this.ae(t, n, null), r++);
		})), r;
	}
	/**
	* Converts the currently accumulated state into a remote event at the
	* provided snapshot version. Resets the accumulated changes before returning.
	*/ fe(e) {
		const t = /* @__PURE__ */ new Map();
		this.ee.forEach(((n, r) => {
			const i = this.Te(r);
			if (i) {
				if (n.current && this.Ee(i.target)) {
					const n = new DocumentKey(__PRIVATE_targetIsPipelineTarget(i.target) ? ResourcePath.fromString(i.target.getPipelineDocuments()[0]) : i.target.path);
					this.me(n).has(r) || this.pe(r, n) || this.ae(r, n, MutableDocument.newNoDocument(n, e));
				}
				n.$ && (t.set(r, n.W()), n.G());
			}
		}));
		let n = __PRIVATE_documentKeySet();
		this.ie.forEach(((e, t) => {
			let r = true;
			t.forEachWhile(((e) => {
				const t = this.Te(e);
				return !t || "TargetPurposeLimboResolution" === t.purpose || (r = false, false);
			})), r && (n = n.add(e));
		})), this.te.forEach(((t, n) => n.setReadTime(e))), this.re.forEach(((t, n) => n.setReadTime(e)));
		const r = new RemoteEvent(e, t, this.se, this.te, this.re, n);
		return this.te = __PRIVATE_mutableDocumentMap(), this.ne = __PRIVATE_documentTargetMap(), this.re = __PRIVATE_mutableDocumentMap(), this.ie = __PRIVATE_documentTargetMap(), this.se = new SortedMap(__PRIVATE_primitiveComparator), r;
	}
	/**
	* Adds the provided document to the internal list of document updates and
	* its document key to the given target's mapping.
	*/
	oe(e, t) {
		const n = this.ee.get(e);
		if (!n || !this.ce(e)) return void __PRIVATE_logDebug(ut, `addDocumentToTarget received document for unknown inactive target (${e})`);
		const r = this.pe(e, t.key) ? 2 : 0;
		n.j(t.key, r), __PRIVATE_targetIsPipelineTarget(this.Te(e).target) && "exact" !== this.Te(e).target.getPipelineFlavor() ? this.re = this.re.insert(t.key, t) : this.te = this.te.insert(t.key, t), this.ne = this.ne.insert(t.key, this.me(t.key).add(e)), this.ie = this.ie.insert(t.key, this.ge(t.key).add(e));
	}
	/**
	* Removes the provided document from the target mapping. If the
	* document no longer matches the target, but the document's state is still
	* known (e.g. we know that the document was deleted or we received the change
	* that caused the filter mismatch), the new document can be provided
	* to update the remote document cache.
	*/
	ae(e, t, n) {
		const r = this.ee.get(e);
		r && this.ce(e) ? (this.pe(e, t) ? r.j(t, 1) : r.H(t), this.ie = this.ie.insert(t, this.ge(t).delete(e)), this.ie = this.ie.insert(t, this.ge(t).add(e)), n && (__PRIVATE_targetIsPipelineTarget(this.Te(e).target) && "exact" !== this.Te(e).target.getPipelineFlavor() ? this.re = this.re.insert(t, n) : this.te = this.te.insert(t, n))) : __PRIVATE_logDebug(ut, `removeDocumentFromTarget received document for unknown or inactive target (${e})`);
	}
	removeTarget(e) {
		this.ee.delete(e);
	}
	/**
	* Returns the current count of documents in the target. This includes both
	* the number of documents that the LocalStore considers to be part of the
	* target as well as any accumulated changes.
	*/ Pe(e) {
		const t = this.ee.get(e);
		if (!t) return 0;
		const n = t.W();
		return this.X.getRemoteKeysForTarget(e).size + n.addedDocuments.size - n.removedDocuments.size;
	}
	/**
	* Increment the number of acks needed from watch before we can consider the
	* server to be 'in-sync' with the client's active targets.
	*/ J(e) {
		let t = this.ee.get(e);
		t || (__PRIVATE_logDebug(ut, `recordPendingTargetRequest set up tracking for target ID ${e}`), t = new __PRIVATE_TargetState(e), this.ee.set(e, t)), t.J();
	}
	ge(e) {
		let t = this.ie.get(e);
		return t || (t = new SortedSet(__PRIVATE_primitiveComparator), this.ie = this.ie.insert(e, t)), t;
	}
	me(e) {
		let t = this.ne.get(e);
		return t || (t = new SortedSet(__PRIVATE_primitiveComparator), this.ne = this.ne.insert(e, t)), t;
	}
	/**
	* Verifies that the user is still interested in this target (by calling
	* `getTargetDataForTarget()`) and that we are not waiting for pending ADDs
	* from watch.
	*/ ce(e) {
		const t = null !== this.Te(e);
		return t || __PRIVATE_logDebug(ut, "Detected inactive target", e), t;
	}
	/**
	* Returns the TargetData for an active target (i.e. a target that the user
	* is still interested in that has no outstanding target change requests).
	*/ Te(e) {
		const t = this.ee.get(e);
		return void 0 === t || t.q ? null : this.X.ye(e);
	}
	/**
	* Resets the state of a Watch target to its initial state (e.g. sets
	* 'current' to false, clears the resume token and removes its target mapping
	* from all documents).
	*/ le(e) {
		this.ee.set(e, new __PRIVATE_TargetState(e));
		this.X.getRemoteKeysForTarget(e).forEach(((t) => {
			this.ae(e, t, null);
		}));
	}
	/**
	* Returns whether the LocalStore considers the document to be part of the
	* specified target.
	*/ pe(e, t) {
		return this.X.getRemoteKeysForTarget(e).has(t);
	}
};
function __PRIVATE_documentTargetMap() {
	return new SortedMap(DocumentKey.comparator);
}
function __PRIVATE_snapshotChangesMap() {
	return new SortedMap(DocumentKey.comparator);
}
var ct = (() => {
	return {
		asc: "ASCENDING",
		desc: "DESCENDING"
	};
})();
var lt = (() => {
	return {
		"<": "LESS_THAN",
		"<=": "LESS_THAN_OR_EQUAL",
		">": "GREATER_THAN",
		">=": "GREATER_THAN_OR_EQUAL",
		"==": "EQUAL",
		"!=": "NOT_EQUAL",
		"array-contains": "ARRAY_CONTAINS",
		in: "IN",
		"not-in": "NOT_IN",
		"array-contains-any": "ARRAY_CONTAINS_ANY"
	};
})();
var Et = (() => {
	return {
		and: "AND",
		or: "OR"
	};
})();
/**
* This class generates JsonObject values for the Datastore API suitable for
* sending to either GRPC stub methods or via the JSON/HTTP REST API.
*
* The serializer supports both Protobuf.js and Proto3 JSON formats. By
* setting `useProto3Json` to true, the serializer will use the Proto3 JSON
* format.
*
* For a description of the Proto3 JSON format check
* https://developers.google.com/protocol-buffers/docs/proto3#json
*
* TODO(klimt): We can remove the databaseId argument if we keep the full
* resource name in documents.
*/
var JsonProtoSerializer = class {
	constructor(e, t) {
		this.databaseId = e, this.useProto3Json = t;
	}
};
/**
* Returns a value for a number (or null) that's appropriate to put into
* a google.protobuf.Int32Value proto.
* DO NOT USE THIS FOR ANYTHING ELSE.
* This method cheats. It's typed as returning "number" because that's what
* our generated proto interfaces say Int32Value must be. But GRPC actually
* expects a { value: <number> } struct.
*/
function __PRIVATE_toInt32Proto(e, t) {
	return e.useProto3Json || __PRIVATE_isNullOrUndefined(t) ? t : { value: t };
}
/**
* Returns a number (or null) from a google.protobuf.Int32Value proto.
*/
/**
* Returns a value for a Date that's appropriate to put into a proto.
*/
function toTimestamp(e, t) {
	if (e.useProto3Json) return `${(/* @__PURE__ */ new Date(1e3 * t.seconds)).toISOString().replace(/\.\d*/, "").replace("Z", "")}.${("000000000" + t.nanoseconds).slice(-9)}Z`;
	return {
		seconds: "" + t.seconds,
		nanos: t.nanoseconds
	};
}
/**
* Returns a Timestamp typed object given protobuf timestamp value.
*/ function fromTimestamp(e) {
	const t = __PRIVATE_normalizeTimestamp(e);
	return new Timestamp(t.seconds, t.nanos);
}
/**
* Returns a value for bytes that's appropriate to put in a proto.
*
* Visible for testing.
*/ function __PRIVATE_toBytes(e, t) {
	return e.useProto3Json ? t.toBase64() : t.toUint8Array();
}
/**
* Returns a ByteString based on the proto string value.
*/ function __PRIVATE_toVersion(e, t) {
	return toTimestamp(e, t.toTimestamp());
}
function __PRIVATE_fromVersion(e) {
	return __PRIVATE_hardAssert(!!e, 49232), SnapshotVersion.fromTimestamp(fromTimestamp(e));
}
function __PRIVATE_toResourceName(e, t) {
	return __PRIVATE_toResourcePath(e, t).canonicalString();
}
function __PRIVATE_toResourcePath(e, t) {
	const n = function __PRIVATE_fullyQualifiedPrefixPath(e) {
		return new ResourcePath([
			"projects",
			e.projectId,
			"databases",
			e.database
		]);
	}(e).child("documents");
	return void 0 === t ? n : n.child(t);
}
function __PRIVATE_fromResourceName(e) {
	const t = ResourcePath.fromString(e);
	return __PRIVATE_hardAssert(__PRIVATE_isValidResourceName(t), 10190, { key: t.toString() }), t;
}
function __PRIVATE_toName(e, t) {
	return __PRIVATE_toResourceName(e.databaseId, t.path);
}
function fromName(t, n) {
	const r = __PRIVATE_fromResourceName(n);
	if (r.get(1) !== t.databaseId.projectId) throw new e(ta.INVALID_ARGUMENT, "Tried to deserialize key from different project: " + r.get(1) + " vs " + t.databaseId.projectId);
	if (r.get(3) !== t.databaseId.database) throw new e(ta.INVALID_ARGUMENT, "Tried to deserialize key from different database: " + r.get(3) + " vs " + t.databaseId.database);
	return new DocumentKey(__PRIVATE_extractLocalPathFromResourceName(r));
}
function __PRIVATE_toQueryPath(e, t) {
	return __PRIVATE_toResourceName(e.databaseId, t);
}
function __PRIVATE_fromQueryPath(e) {
	const t = __PRIVATE_fromResourceName(e);
	return 4 === t.length ? ResourcePath.emptyPath() : __PRIVATE_extractLocalPathFromResourceName(t);
}
function __PRIVATE_getEncodedDatabaseId(e) {
	return new ResourcePath([
		"projects",
		e.databaseId.projectId,
		"databases",
		e.databaseId.database
	]).canonicalString();
}
function __PRIVATE_extractLocalPathFromResourceName(e) {
	return __PRIVATE_hardAssert(e.length > 4 && "documents" === e.get(4), 29091, { key: e.toString() }), e.popFirst(5);
}
/** Creates a Document proto from key and fields (but no create/update time) */ function __PRIVATE_toMutationDocument(e, t, n) {
	return {
		name: __PRIVATE_toName(e, t),
		fields: n.value.mapValue.fields
	};
}
function __PRIVATE_fromWatchChange(t, n) {
	let r;
	if ("targetChange" in n) {
		n.targetChange;
		const i = function __PRIVATE_fromWatchTargetChangeState(e) {
			return "NO_CHANGE" === e ? 0 : "ADD" === e ? 1 : "REMOVE" === e ? 2 : "CURRENT" === e ? 3 : "RESET" === e ? 4 : l(39313, { state: e });
		}(n.targetChange.targetChangeType || "NO_CHANGE"), s = n.targetChange.targetIds || [], _ = function __PRIVATE_fromBytes(e, t) {
			return e.useProto3Json ? (__PRIVATE_hardAssert(void 0 === t || "string" == typeof t, 58123), ByteString.fromBase64String(t || "")) : (__PRIVATE_hardAssert(void 0 === t || t instanceof Buffer || t instanceof Uint8Array, 16193), ByteString.fromUint8Array(t || /* @__PURE__ */ new Uint8Array()));
		}(t, n.targetChange.resumeToken), o = n.targetChange.cause;
		r = new __PRIVATE_WatchTargetChange(i, s, _, o && function __PRIVATE_fromRpcStatus(t) {
			return new e(void 0 === t.code ? ta.UNKNOWN : __PRIVATE_mapCodeFromRpcCode(t.code), t.message || "");
		}(o) || null);
	} else if ("documentChange" in n) {
		n.documentChange;
		const e = n.documentChange;
		e.document, e.document.name, e.document.updateTime;
		const i = fromName(t, e.document.name), s = __PRIVATE_fromVersion(e.document.updateTime), _ = e.document.createTime ? __PRIVATE_fromVersion(e.document.createTime) : SnapshotVersion.min(), o = new ObjectValue({ mapValue: { fields: e.document.fields } }), a = MutableDocument.newFoundDocument(i, s, _, o);
		r = new __PRIVATE_DocumentWatchChange(e.targetIds || [], e.removedTargetIds || [], a.key, a);
	} else if ("documentDelete" in n) {
		n.documentDelete;
		const e = n.documentDelete;
		e.document;
		const i = fromName(t, e.document), s = e.readTime ? __PRIVATE_fromVersion(e.readTime) : SnapshotVersion.min(), _ = MutableDocument.newNoDocument(i, s);
		r = new __PRIVATE_DocumentWatchChange([], e.removedTargetIds || [], _.key, _);
	} else if ("documentRemove" in n) {
		n.documentRemove;
		const e = n.documentRemove;
		e.document;
		const i = fromName(t, e.document);
		r = new __PRIVATE_DocumentWatchChange([], e.removedTargetIds || [], i, null);
	} else {
		if (!("filter" in n)) return l(11601, { we: n });
		{
			n.filter;
			const e = n.filter;
			e.targetId;
			const { count: t = 0, unchangedNames: i } = e, s = new ExistenceFilter(t, i), _ = e.targetId;
			r = new __PRIVATE_ExistenceFilterChange(_, s);
		}
	}
	return r;
}
function toMutation(e, t) {
	let n;
	if (t instanceof __PRIVATE_SetMutation) n = { update: __PRIVATE_toMutationDocument(e, t.key, t.value) };
	else if (t instanceof __PRIVATE_DeleteMutation) n = { delete: __PRIVATE_toName(e, t.key) };
	else if (t instanceof __PRIVATE_PatchMutation) n = {
		update: __PRIVATE_toMutationDocument(e, t.key, t.data),
		updateMask: __PRIVATE_toDocumentMask(t.fieldMask)
	};
	else {
		if (!(t instanceof __PRIVATE_VerifyMutation)) return l(16599, { be: t.type });
		n = { verify: __PRIVATE_toName(e, t.key) };
	}
	return t.fieldTransforms.length > 0 && (n.updateTransforms = t.fieldTransforms.map(((e) => function __PRIVATE_toFieldTransform(e, t) {
		const n = t.transform;
		if (n instanceof __PRIVATE_ServerTimestampTransform) return {
			fieldPath: t.field.canonicalString(),
			setToServerValue: "REQUEST_TIME"
		};
		if (n instanceof __PRIVATE_ArrayUnionTransformOperation) return {
			fieldPath: t.field.canonicalString(),
			appendMissingElements: { values: n.elements }
		};
		if (n instanceof __PRIVATE_ArrayRemoveTransformOperation) return {
			fieldPath: t.field.canonicalString(),
			removeAllFromArray: { values: n.elements }
		};
		if (n instanceof __PRIVATE_NumericIncrementTransformOperation) return {
			fieldPath: t.field.canonicalString(),
			increment: n.h
		};
		if (n instanceof __PRIVATE_NumericMinimumTransformOperation) return {
			fieldPath: t.field.canonicalString(),
			minimum: n.h
		};
		if (n instanceof __PRIVATE_NumericMaximumTransformOperation) return {
			fieldPath: t.field.canonicalString(),
			maximum: n.h
		};
		throw l(20930, { transform: t.transform });
	}(0, e)))), t.precondition.isNone || (n.currentDocument = function __PRIVATE_toPrecondition(e, t) {
		return void 0 !== t.updateTime ? { updateTime: __PRIVATE_toVersion(e, t.updateTime) } : void 0 !== t.exists ? { exists: t.exists } : l(27497);
	}(e, t.precondition)), n;
}
function __PRIVATE_fromWriteResults(e, t) {
	return e && e.length > 0 ? (__PRIVATE_hardAssert(void 0 !== t, 14353), e.map(((e) => function __PRIVATE_fromWriteResult(e, t) {
		let n = e.updateTime ? __PRIVATE_fromVersion(e.updateTime) : __PRIVATE_fromVersion(t);
		return n.isEqual(SnapshotVersion.min()) && (n = __PRIVATE_fromVersion(t)), new MutationResult(n, e.transformResults || []);
	}(e, t)))) : [];
}
function __PRIVATE_toDocumentsTarget(e, t) {
	return { documents: [__PRIVATE_toQueryPath(e, t.path)] };
}
function __PRIVATE_toQueryTarget(e, t) {
	const n = { structuredQuery: {} }, r = t.path;
	let i;
	null !== t.collectionGroup ? (i = r, n.structuredQuery.from = [{
		collectionId: t.collectionGroup,
		allDescendants: true
	}]) : (i = r.popLast(), n.structuredQuery.from = [{ collectionId: r.lastSegment() }]), n.parent = __PRIVATE_toQueryPath(e, i);
	const s = function __PRIVATE_toFilters(e) {
		if (0 === e.length) return;
		return __PRIVATE_toFilter(CompositeFilter.create(e, "and"));
	}(t.filters);
	s && (n.structuredQuery.where = s);
	const _ = function __PRIVATE_toOrder(e) {
		if (0 === e.length) return;
		return e.map(((e) => function __PRIVATE_toPropertyOrder(e) {
			return {
				field: __PRIVATE_toFieldPathReference(e.field),
				direction: __PRIVATE_toDirection(e.dir)
			};
		}(e)));
	}(t.orderBy);
	_ && (n.structuredQuery.orderBy = _);
	const o = __PRIVATE_toInt32Proto(e, t.limit);
	return null !== o && (n.structuredQuery.limit = o), t.startAt && (n.structuredQuery.startAt = function __PRIVATE_toStartAtCursor(e) {
		return {
			before: e.inclusive,
			values: e.position
		};
	}(t.startAt)), t.endAt && (n.structuredQuery.endAt = function __PRIVATE_toEndAtCursor(e) {
		return {
			before: !e.inclusive,
			values: e.position
		};
	}(t.endAt)), {
		Se: n,
		parent: i
	};
}
function __PRIVATE_convertQueryTargetToQuery(e) {
	let t = __PRIVATE_fromQueryPath(e.parent);
	const n = e.structuredQuery, r = n.from ? n.from.length : 0;
	let i = null;
	if (r > 0) {
		__PRIVATE_hardAssert(1 === r, 65062);
		const e = n.from[0];
		e.allDescendants ? i = e.collectionId : t = t.child(e.collectionId);
	}
	let s = [];
	n.where && (s = function __PRIVATE_fromFilters(e) {
		const t = __PRIVATE_fromFilter(e);
		if (t instanceof CompositeFilter && __PRIVATE_compositeFilterIsFlatConjunction(t)) return t.getFilters();
		return [t];
	}(n.where));
	let _ = [];
	n.orderBy && (_ = function __PRIVATE_fromOrder(e) {
		return e.map(((e) => function __PRIVATE_fromPropertyOrder(e) {
			return new OrderBy(__PRIVATE_fromFieldPathReference(e.field), function __PRIVATE_fromDirection(e) {
				switch (e) {
					case "ASCENDING": return "asc";
					case "DESCENDING": return "desc";
					default: return;
				}
			}(e.direction));
		}(e)));
	}(n.orderBy));
	let o = null;
	n.limit && (o = function __PRIVATE_fromInt32Proto(e) {
		let t;
		return t = "object" == typeof e ? e.value : e, __PRIVATE_isNullOrUndefined(t) ? null : t;
	}(n.limit));
	let a = null;
	n.startAt && (a = function __PRIVATE_fromStartAtCursor(e) {
		const t = !!e.before;
		return new Bound(e.values || [], t);
	}(n.startAt));
	let u = null;
	return n.endAt && (u = function __PRIVATE_fromEndAtCursor(e) {
		const t = !e.before;
		return new Bound(e.values || [], t);
	}(n.endAt)), __PRIVATE_newQuery(t, i, _, s, o, "F", a, u);
}
function __PRIVATE_toListenRequestLabels(e, t) {
	const n = function __PRIVATE_toLabel(e) {
		switch (e) {
			case "TargetPurposeListen": return null;
			case "TargetPurposeExistenceFilterMismatch": return "existence-filter-mismatch";
			case "TargetPurposeExistenceFilterMismatchBloom": return "existence-filter-mismatch-bloom";
			case "TargetPurposeLimboResolution": return "limbo-document";
			default: return l(28987, { purpose: e });
		}
	}(t.purpose);
	return null == n ? null : { "goog-listen-tags": n };
}
function __PRIVATE_toPipelineTarget(e, t) {
	return { structuredPipeline: { pipeline: { stages: t.stages.map(((t) => t._toProto(e))) } } };
}
function __PRIVATE_fromFilter(e) {
	return void 0 !== e.unaryFilter ? function __PRIVATE_fromUnaryFilter(e) {
		switch (e.unaryFilter.op) {
			case "IS_NAN":
				const t = __PRIVATE_fromFieldPathReference(e.unaryFilter.field);
				return FieldFilter.create(t, "==", { doubleValue: NaN });
			case "IS_NULL":
				const n = __PRIVATE_fromFieldPathReference(e.unaryFilter.field);
				return FieldFilter.create(n, "==", { nullValue: "NULL_VALUE" });
			case "IS_NOT_NAN":
				const r = __PRIVATE_fromFieldPathReference(e.unaryFilter.field);
				return FieldFilter.create(r, "!=", { doubleValue: NaN });
			case "IS_NOT_NULL":
				const i = __PRIVATE_fromFieldPathReference(e.unaryFilter.field);
				return FieldFilter.create(i, "!=", { nullValue: "NULL_VALUE" });
			case "OPERATOR_UNSPECIFIED": return l(61313);
			default: return l(60726);
		}
	}(e) : void 0 !== e.fieldFilter ? function __PRIVATE_fromFieldFilter(e) {
		return FieldFilter.create(__PRIVATE_fromFieldPathReference(e.fieldFilter.field), function __PRIVATE_fromOperatorName(e) {
			switch (e) {
				case "EQUAL": return "==";
				case "NOT_EQUAL": return "!=";
				case "GREATER_THAN": return ">";
				case "GREATER_THAN_OR_EQUAL": return ">=";
				case "LESS_THAN": return "<";
				case "LESS_THAN_OR_EQUAL": return "<=";
				case "ARRAY_CONTAINS": return "array-contains";
				case "IN": return "in";
				case "NOT_IN": return "not-in";
				case "ARRAY_CONTAINS_ANY": return "array-contains-any";
				case "OPERATOR_UNSPECIFIED": return l(58110);
				default: return l(50506);
			}
		}(e.fieldFilter.op), e.fieldFilter.value);
	}(e) : void 0 !== e.compositeFilter ? function __PRIVATE_fromCompositeFilter(e) {
		return CompositeFilter.create(e.compositeFilter.filters.map(((e) => __PRIVATE_fromFilter(e))), function __PRIVATE_fromCompositeOperatorName(e) {
			switch (e) {
				case "AND": return "and";
				case "OR": return "or";
				default: return l(1026);
			}
		}(e.compositeFilter.op));
	}(e) : l(30097, { filter: e });
}
function __PRIVATE_toDirection(e) {
	return ct[e];
}
function __PRIVATE_toOperatorName(e) {
	return lt[e];
}
function __PRIVATE_toCompositeOperatorName(e) {
	return Et[e];
}
function __PRIVATE_toFieldPathReference(e) {
	return { fieldPath: e.canonicalString() };
}
function __PRIVATE_fromFieldPathReference(e) {
	return Oe.fromServerFormat(e.fieldPath);
}
function __PRIVATE_toFilter(e) {
	return e instanceof FieldFilter ? function __PRIVATE_toUnaryOrFieldFilter(e) {
		if ("==" === e.op) {
			if (__PRIVATE_isNanValue(e.value)) return { unaryFilter: {
				field: __PRIVATE_toFieldPathReference(e.field),
				op: "IS_NAN"
			} };
			if (__PRIVATE_isNullValue(e.value)) return { unaryFilter: {
				field: __PRIVATE_toFieldPathReference(e.field),
				op: "IS_NULL"
			} };
		} else if ("!=" === e.op) {
			if (__PRIVATE_isNanValue(e.value)) return { unaryFilter: {
				field: __PRIVATE_toFieldPathReference(e.field),
				op: "IS_NOT_NAN"
			} };
			if (__PRIVATE_isNullValue(e.value)) return { unaryFilter: {
				field: __PRIVATE_toFieldPathReference(e.field),
				op: "IS_NOT_NULL"
			} };
		}
		return { fieldFilter: {
			field: __PRIVATE_toFieldPathReference(e.field),
			op: __PRIVATE_toOperatorName(e.op),
			value: e.value
		} };
	}(e) : e instanceof CompositeFilter ? function __PRIVATE_toCompositeFilter(e) {
		const t = e.getFilters().map(((e) => __PRIVATE_toFilter(e)));
		if (1 === t.length) return t[0];
		return { compositeFilter: {
			op: __PRIVATE_toCompositeOperatorName(e.op),
			filters: t
		} };
	}(e) : l(54877, { filter: e });
}
function __PRIVATE_toDocumentMask(e) {
	const t = [];
	return e.fields.forEach(((e) => t.push(e.canonicalString()))), { fieldPaths: t };
}
function __PRIVATE_isValidResourceName(e) {
	return e.length >= 4 && "projects" === e.get(0) && "databases" === e.get(2);
}
function __PRIVATE_isProtoValueSerializable(e) {
	return !!e && "function" == typeof e._toProto && "ProtoValue" === e._protoValueType;
}
function toMapValue(e, t) {
	const n = { fields: {} };
	return t.forEach(((t, r) => {
		if ("string" != typeof r) throw new Error(`Cannot encode map with non-string key: ${r}`);
		n.fields[r] = t._toProto(e);
	})), { mapValue: n };
}
function __PRIVATE_toStringValue(e) {
	return { stringValue: e };
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ function __PRIVATE_newSerializer(e) {
	return new JsonProtoSerializer(e, true);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An immutable object representing an array of bytes.
*/ var Bytes = class Bytes {
	/** @hideconstructor */
	constructor(e) {
		this._byteString = e;
	}
	/**
	* Creates a new `Bytes` object from the given Base64 string, converting it to
	* bytes.
	*
	* @param base64 - The Base64 string used to create the `Bytes` object.
	*/ static fromBase64String(t) {
		try {
			return new Bytes(ByteString.fromBase64String(t));
		} catch (t) {
			throw new e(ta.INVALID_ARGUMENT, "Failed to construct data from Base64 string: " + t);
		}
	}
	/**
	* Creates a new `Bytes` object from the given Uint8Array.
	*
	* @param array - The Uint8Array used to create the `Bytes` object.
	*/ static fromUint8Array(e) {
		return new Bytes(ByteString.fromUint8Array(e));
	}
	/**
	* Returns the underlying bytes as a Base64-encoded string.
	*
	* @returns The Base64-encoded string created from the `Bytes` object.
	*/ toBase64() {
		return this._byteString.toBase64();
	}
	/**
	* Returns the underlying bytes in a new `Uint8Array`.
	*
	* @returns The Uint8Array created from the `Bytes` object.
	*/ toUint8Array() {
		return this._byteString.toUint8Array();
	}
	/**
	* Returns a string representation of the `Bytes` object.
	*
	* @returns A string representation of the `Bytes` object.
	*/ toString() {
		return "Bytes(base64: " + this.toBase64() + ")";
	}
	/**
	* Returns true if this `Bytes` object is equal to the provided one.
	*
	* @param other - The `Bytes` object to compare against.
	* @returns true if this `Bytes` object is equal to the provided one.
	*/ isEqual(e) {
		return this._byteString.isEqual(e._byteString);
	}
	/**
	* Returns a JSON-serializable representation of this `Bytes` instance.
	*
	* @returns a JSON representation of this object.
	*/ toJSON() {
		return {
			type: Bytes._jsonSchemaVersion,
			bytes: this.toBase64()
		};
	}
	/**
	* Builds a `Bytes` instance from a JSON object created by {@link Bytes.toJSON}.
	*
	* @param json - a JSON object represention of a `Bytes` instance
	* @returns an instance of {@link Bytes} if the JSON object could be parsed. Throws a
	* {@link FirestoreError} if an error occurs.
	*/ static fromJSON(e) {
		if (__PRIVATE_validateJSON(e, Bytes._jsonSchema)) return Bytes.fromBase64String(e.bytes);
	}
};
Bytes._jsonSchemaVersion = "firestore/bytes/1.0", Bytes._jsonSchema = {
	type: property("string", Bytes._jsonSchemaVersion),
	bytes: property("string")
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A `FieldPath` refers to a field in a document. The path may consist of a
* single field name (referring to a top-level field in the document), or a
* list of field names (referring to a nested field in the document).
*
* Create a `FieldPath` by providing field names. If more than one field
* name is provided, the path will point to a nested field in a document.
*/
var FieldPath = class {
	/**
	* Creates a `FieldPath` from the provided field names. If more than one field
	* name is provided, the path will point to a nested field in a document.
	*
	* @param fieldNames - A list of field names.
	*/
	constructor(...t) {
		for (let n = 0; n < t.length; ++n) if (0 === t[n].length) throw new e(ta.INVALID_ARGUMENT, "Invalid field name at argument $(i + 1). Field names must not be empty.");
		this._internalPath = new Oe(t);
	}
	/**
	* Returns true if this `FieldPath` is equal to the provided one.
	*
	* @param other - The `FieldPath` to compare against.
	* @returns true if this `FieldPath` is equal to the provided one.
	*/ isEqual(e) {
		return this._internalPath.isEqual(e._internalPath);
	}
};
/**
* Returns a special sentinel `FieldPath` to refer to the ID of a document.
* It can be used in queries to sort or filter by the document ID.
*/ function documentId$1() {
	return new FieldPath(Ce);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Sentinel values that can be used when writing document fields with `set()`
* or `update()`.
*/ var FieldValue = class {
	/**
	* @param _methodName - The public API endpoint that returns this class.
	* @hideconstructor
	*/
	constructor(e) {
		this._methodName = e;
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An immutable object representing a geographic location in Firestore. The
* location is represented as latitude/longitude pair.
*
* Latitude values are in the range of [-90, 90].
* Longitude values are in the range of [-180, 180].
*/ var GeoPoint = class GeoPoint {
	/**
	* Creates a new immutable `GeoPoint` object with the provided latitude and
	* longitude values.
	* @param latitude - The latitude as number between -90 and 90.
	* @param longitude - The longitude as number between -180 and 180.
	*/
	constructor(t, n) {
		if (!isFinite(t) || t < -90 || t > 90) throw new e(ta.INVALID_ARGUMENT, "Latitude must be a number between -90 and 90, but was: " + t);
		if (!isFinite(n) || n < -180 || n > 180) throw new e(ta.INVALID_ARGUMENT, "Longitude must be a number between -180 and 180, but was: " + n);
		this._lat = t, this._long = n;
	}
	/**
	* The latitude of this `GeoPoint` instance.
	*/ get latitude() {
		return this._lat;
	}
	/**
	* The longitude of this `GeoPoint` instance.
	*/ get longitude() {
		return this._long;
	}
	/**
	* Returns true if this `GeoPoint` is equal to the provided one.
	*
	* @param other - The `GeoPoint` to compare against.
	* @returns true if this `GeoPoint` is equal to the provided one.
	*/ isEqual(e) {
		return this._lat === e._lat && this._long === e._long;
	}
	/**
	* Actually private to JS consumers of our API, so this function is prefixed
	* with an underscore.
	*/ _compareTo(e) {
		return __PRIVATE_primitiveComparator(this._lat, e._lat) || __PRIVATE_primitiveComparator(this._long, e._long);
	}
	/**
	* Returns a JSON-serializable representation of this `GeoPoint` instance.
	*
	* @returns a JSON representation of this object.
	*/ toJSON() {
		return {
			latitude: this._lat,
			longitude: this._long,
			type: GeoPoint._jsonSchemaVersion
		};
	}
	/**
	* Builds a `GeoPoint` instance from a JSON object created by {@link GeoPoint.toJSON}.
	*
	* @param json - a JSON object represention of a `GeoPoint` instance
	* @returns an instance of {@link GeoPoint} if the JSON object could be parsed. Throws a
	* {@link FirestoreError} if an error occurs.
	*/ static fromJSON(e) {
		if (__PRIVATE_validateJSON(e, GeoPoint._jsonSchema)) return new GeoPoint(e.latitude, e.longitude);
	}
};
GeoPoint._jsonSchemaVersion = "firestore/geoPoint/1.0", GeoPoint._jsonSchema = {
	type: property("string", GeoPoint._jsonSchemaVersion),
	latitude: property("number"),
	longitude: property("number")
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Simple wrapper around a nullable UID. Mostly exists to make code more
* readable.
*/
var User = class {
	constructor(e) {
		this.uid = e;
	}
	isAuthenticated() {
		return null != this.uid;
	}
	/**
	* Returns a key representing this user, suitable for inclusion in a
	* dictionary.
	*/ toKey() {
		return this.isAuthenticated() ? "uid:" + this.uid : "anonymous-user";
	}
	isEqual(e) {
		return e.uid === this.uid;
	}
};
/** A user with a null UID. */ User.UNAUTHENTICATED = new User(null), User.GOOGLE_CREDENTIALS = new User("google-credentials-uid"), User.FIRST_PARTY = new User("first-party-uid"), User.MOCK_USER = new User("mock-user");
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var __PRIVATE_Deferred = class {
	constructor() {
		this.promise = new Promise(((e, t) => {
			this.resolve = e, this.reject = t;
		}));
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var __PRIVATE_OAuthToken = class {
	constructor(e, t) {
		this.user = t, this.type = "OAuth", this.headers = /* @__PURE__ */ new Map(), this.headers.set("Authorization", `Bearer ${e}`);
	}
};
/**
* A CredentialsProvider that always yields an empty token.
* @internal
*/ var __PRIVATE_EmptyAuthCredentialsProvider = class {
	getToken() {
		return Promise.resolve(null);
	}
	invalidateToken() {}
	start(e, t) {
		e.enqueueRetryable((() => t(User.UNAUTHENTICATED)));
	}
	shutdown() {}
};
/**
* A CredentialsProvider that always returns a constant token. Used for
* emulator token mocking.
*/ var __PRIVATE_EmulatorAuthCredentialsProvider = class {
	constructor(e) {
		this.token = e, this.changeListener = null;
	}
	getToken() {
		return Promise.resolve(this.token);
	}
	invalidateToken() {}
	start(e, t) {
		this.changeListener = t, e.enqueueRetryable((() => t(this.token.user)));
	}
	shutdown() {
		this.changeListener = null;
	}
};
var __PRIVATE_FirebaseAuthCredentialsProvider = class {
	constructor(e) {
		this.De = e, this.currentUser = User.UNAUTHENTICATED, this.xe = 0, this.forceRefresh = false, this.auth = null;
	}
	start(e, t) {
		__PRIVATE_hardAssert(void 0 === this.Ce, 42304);
		let n = this.xe;
		const __PRIVATE_guardedChangeListener = (e) => this.xe !== n ? (n = this.xe, t(e)) : Promise.resolve();
		let r = new __PRIVATE_Deferred();
		this.Ce = () => {
			this.xe++, this.currentUser = this.Fe(), r.resolve(), r = new __PRIVATE_Deferred(), e.enqueueRetryable((() => __PRIVATE_guardedChangeListener(this.currentUser)));
		};
		const __PRIVATE_awaitNextToken = () => {
			const t = r;
			e.enqueueRetryable((async () => {
				await t.promise, await __PRIVATE_guardedChangeListener(this.currentUser);
			}));
		}, __PRIVATE_registerAuth = (e) => {
			__PRIVATE_logDebug("FirebaseAuthCredentialsProvider", "Auth detected"), this.auth = e, this.Ce && (this.auth.addAuthTokenListener(this.Ce), __PRIVATE_awaitNextToken());
		};
		this.De.onInit(((e) => __PRIVATE_registerAuth(e))), setTimeout((() => {
			if (!this.auth) {
				const e = this.De.getImmediate({ optional: true });
				e ? __PRIVATE_registerAuth(e) : (__PRIVATE_logDebug("FirebaseAuthCredentialsProvider", "Auth not yet detected"), r.resolve(), r = new __PRIVATE_Deferred());
			}
		}), 0), __PRIVATE_awaitNextToken();
	}
	getToken() {
		const e = this.xe, t = this.forceRefresh;
		return this.forceRefresh = false, this.auth ? this.auth.getToken(t).then(((t) => this.xe !== e ? (__PRIVATE_logDebug("FirebaseAuthCredentialsProvider", "getToken aborted due to token change."), this.getToken()) : t ? (__PRIVATE_hardAssert("string" == typeof t.accessToken, 31837, { Oe: t }), new __PRIVATE_OAuthToken(t.accessToken, this.currentUser)) : null)) : Promise.resolve(null);
	}
	invalidateToken() {
		this.forceRefresh = true;
	}
	shutdown() {
		this.auth && this.Ce && this.auth.removeAuthTokenListener(this.Ce), this.Ce = void 0;
	}
	Fe() {
		const e = this.auth && this.auth.getUid();
		return __PRIVATE_hardAssert(null === e || "string" == typeof e, 2055, { Me: e }), new User(e);
	}
};
var __PRIVATE_FirstPartyToken = class {
	constructor(e, t, n) {
		this.Ne = e, this.Le = t, this.Be = n, this.type = "FirstParty", this.user = User.FIRST_PARTY, this.Ue = /* @__PURE__ */ new Map();
	}
	/**
	* Gets an authorization token, using a provided factory function, or return
	* null.
	*/ ke() {
		return this.Be ? this.Be() : null;
	}
	get headers() {
		this.Ue.set("X-Goog-AuthUser", this.Ne);
		const e = this.ke();
		return e && this.Ue.set("Authorization", e), this.Le && this.Ue.set("X-Goog-Iam-Authorization-Token", this.Le), this.Ue;
	}
};
var __PRIVATE_FirstPartyAuthCredentialsProvider = class {
	constructor(e, t, n) {
		this.Ne = e, this.Le = t, this.Be = n;
	}
	getToken() {
		return Promise.resolve(new __PRIVATE_FirstPartyToken(this.Ne, this.Le, this.Be));
	}
	start(e, t) {
		e.enqueueRetryable((() => t(User.FIRST_PARTY)));
	}
	shutdown() {}
	invalidateToken() {}
};
var AppCheckToken = class {
	constructor(e) {
		this.value = e, this.type = "AppCheck", this.headers = /* @__PURE__ */ new Map(), e && e.length > 0 && this.headers.set("x-firebase-appcheck", this.value);
	}
};
var __PRIVATE_FirebaseAppCheckTokenProvider = class {
	constructor(e, t) {
		this.qe = t, this.forceRefresh = false, this.appCheck = null, this.$e = null, this.Ke = null, _isFirebaseServerApp(e) && e.settings.appCheckToken && (this.Ke = e.settings.appCheckToken);
	}
	start(e, t) {
		__PRIVATE_hardAssert(void 0 === this.Ce, 3512);
		const onTokenChanged = (e) => {
			null != e.error && __PRIVATE_logDebug("FirebaseAppCheckTokenProvider", `Error getting App Check token; using placeholder token instead. Error: ${e.error.message}`);
			const n = e.token !== this.$e;
			return this.$e = e.token, __PRIVATE_logDebug("FirebaseAppCheckTokenProvider", `Received ${n ? "new" : "existing"} token.`), n ? t(e.token) : Promise.resolve();
		};
		this.Ce = (t) => {
			e.enqueueRetryable((() => onTokenChanged(t)));
		};
		const __PRIVATE_registerAppCheck = (e) => {
			__PRIVATE_logDebug("FirebaseAppCheckTokenProvider", "AppCheck detected"), this.appCheck = e, this.Ce && this.appCheck.addTokenListener(this.Ce);
		};
		this.qe.onInit(((e) => __PRIVATE_registerAppCheck(e))), setTimeout((() => {
			if (!this.appCheck) {
				const e = this.qe.getImmediate({ optional: true });
				e ? __PRIVATE_registerAppCheck(e) : __PRIVATE_logDebug("FirebaseAppCheckTokenProvider", "AppCheck not yet detected");
			}
		}), 0);
	}
	getToken() {
		if (this.Ke) return Promise.resolve(new AppCheckToken(this.Ke));
		const e = this.forceRefresh;
		return this.forceRefresh = false, this.appCheck ? this.appCheck.getToken(e).then(((e) => e ? (__PRIVATE_hardAssert("string" == typeof e.token, 44558, { tokenResult: e }), this.$e = e.token, new AppCheckToken(e.token)) : null)) : Promise.resolve(null);
	}
	invalidateToken() {
		this.forceRefresh = true;
	}
	shutdown() {
		this.appCheck && this.Ce && this.appCheck.removeTokenListener(this.Ce), this.Ce = void 0;
	}
};
/**
* Builds a CredentialsProvider depending on the type of
* the credentials passed in.
*/
/**
* Creates and returns a new `ExperimentalLongPollingOptions` with the same
* option values as the given instance.
*/
function __PRIVATE_cloneLongPollingOptions(e) {
	const t = {};
	return void 0 !== e.timeoutSeconds && (t.timeoutSeconds = e.timeoutSeconds), t;
}
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var __PRIVATE_NoopConnectivityMonitor = class {
	Qe(e) {}
	shutdown() {}
};
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var ht = "ConnectivityMonitor";
/**
* Browser implementation of ConnectivityMonitor.
*/ var __PRIVATE_BrowserConnectivityMonitor = class {
	constructor() {
		this.We = () => this.Ge(), this.ze = () => this.je(), this.He = [], this.Je();
	}
	Qe(e) {
		this.He.push(e);
	}
	shutdown() {
		window.removeEventListener("online", this.We), window.removeEventListener("offline", this.ze);
	}
	Je() {
		window.addEventListener("online", this.We), window.addEventListener("offline", this.ze);
	}
	Ge() {
		__PRIVATE_logDebug(ht, "Network connectivity changed: AVAILABLE");
		for (const e of this.He) e(0);
	}
	je() {
		__PRIVATE_logDebug(ht, "Network connectivity changed: UNAVAILABLE");
		for (const e of this.He) e(1);
	}
	/** Checks that all used attributes of window are available. */
	static Ye() {
		return "undefined" != typeof window && void 0 !== window.addEventListener && void 0 !== window.removeEventListener;
	}
};
/**
* @license
* Copyright 2023 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* The value returned from the most recent invocation of
* `generateUniqueDebugId()`, or null if it has never been invoked.
*/ var Tt = null;
/**
* Generates and returns an initial value for `lastUniqueDebugId`.
*
* The returned value is randomly selected from a range of integers that are
* represented as 8 hexadecimal digits. This means that (within reason) any
* numbers generated by incrementing the returned number by 1 will also be
* represented by 8 hexadecimal digits. This leads to all "IDs" having the same
* length when converted to a hexadecimal string, making reading logs containing
* these IDs easier to follow. And since the return value is randomly selected
* it will help to differentiate between logs from different executions.
*/
/**
* Generates and returns a unique ID as a hexadecimal string.
*
* The returned ID is intended to be used in debug logging messages to help
* correlate log messages that may be spatially separated in the logs, but
* logically related. For example, a network connection could include the same
* "debug ID" string in all of its log messages to help trace a specific
* connection over time.
*
* @returns the 10-character generated ID (e.g. "0xa1b2c3d4").
*/
function __PRIVATE_generateUniqueDebugId() {
	return null === Tt ? Tt = function __PRIVATE_generateInitialUniqueDebugId() {
		return 268435456 + Math.round(2147483648 * Math.random());
	}() : Tt++, "0x" + Tt.toString(16);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var Pt = "RestConnection";
var It = {
	BatchGetDocuments: "batchGet",
	Commit: "commit",
	RunQuery: "runQuery",
	RunAggregationQuery: "runAggregationQuery",
	ExecutePipeline: "executePipeline"
};
/**
* Maps RPC names to the corresponding REST endpoint name.
*
* We use array notation to avoid mangling.
*/
/**
* Base class for all Rest-based connections to the backend (WebChannel and
* HTTP).
*/
var __PRIVATE_RestConnection = class {
	get Ze() {
		return false;
	}
	constructor(e) {
		this.databaseInfo = e, this.databaseId = e.databaseId;
		const t = e.ssl ? "https" : "http", n = encodeURIComponent(this.databaseId.projectId), r = encodeURIComponent(this.databaseId.database);
		this.Xe = t + "://" + e.host, this.et = `projects/${n}/databases/${r}`, this.tt = this.databaseId.database === $e ? `project_id=${n}` : `project_id=${n}&database_id=${r}`;
	}
	nt(e, t, n, r, i) {
		const s = __PRIVATE_generateUniqueDebugId(), _ = this.rt(e, t.toUriEncodedString());
		__PRIVATE_logDebug(Pt, `Sending RPC '${e}' ${s}:`, _, n);
		const o = {
			"google-cloud-resource-prefix": this.et,
			"x-goog-request-params": this.tt
		};
		this.it(o, r, i);
		const { host: a } = new URL(_), u = isCloudWorkstation(a);
		return this.st(e, _, o, n, u).then(((t) => (__PRIVATE_logDebug(Pt, `Received RPC '${e}' ${s}: `, t), t)), ((t) => {
			throw __PRIVATE_logWarn(Pt, `RPC '${e}' ${s} failed with error: `, t, "url: ", _, "request:", n), t;
		}));
	}
	_t(e, t, n, r, i, s) {
		return this.nt(e, t, n, r, i);
	}
	/**
	* Modifies the headers for a request, adding any authorization token if
	* present and any additional headers for the request.
	*/ it(e, t, n) {
		if (e["X-Goog-Api-Client"] = function __PRIVATE_getGoogApiClientValue() {
			return "gl-js/ fire/" + Se;
		}(), e["Content-Type"] = "text/plain", this.databaseInfo.appId && (e["X-Firebase-GMPID"] = this.databaseInfo.appId), t && t.headers.forEach(((t, n) => e[n] = t)), n && n.headers.forEach(((t, n) => e[n] = t)), this.databaseInfo._customHeaders) for (const t of Object.keys(this.databaseInfo._customHeaders)) e[t] = this.databaseInfo._customHeaders[t];
	}
	rt(e, t) {
		const n = It[e];
		let r = `${this.Xe}/v1/${t}:${n}`;
		return this.databaseInfo.apiKey && (r = `${r}?key=${encodeURIComponent(this.databaseInfo.apiKey)}`), r;
	}
	/**
	* Closes and cleans up any resources associated with the connection. This
	* implementation is a no-op because there are no resources associated
	* with the RestConnection that need to be cleaned up.
	*/ terminate() {}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Provides a simple helper class that implements the Stream interface to
* bridge to other implementations that are streams but do not implement the
* interface. The stream callbacks are invoked with the callOn... methods.
*/ var __PRIVATE_StreamBridge = class {
	constructor(e) {
		this.ot = e.ot, this.ut = e.ut;
	}
	ct(e) {
		this.lt = e;
	}
	Et(e) {
		this.ht = e;
	}
	Tt(e) {
		this.Pt = e;
	}
	onMessage(e) {
		this.It = e;
	}
	close() {
		this.ut();
	}
	send(e) {
		this.ot(e);
	}
	Rt() {
		this.lt();
	}
	At() {
		this.ht();
	}
	Vt(e) {
		this.Pt(e);
	}
	dt(e) {
		this.It(e);
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var Rt = "WebChannelConnection";
var __PRIVATE_unguardedEventListen = (e, t, n) => {
	e.listen(t, ((e) => {
		try {
			n(e);
		} catch (e) {
			setTimeout((() => {
				throw e;
			}), 0);
		}
	}));
};
var __PRIVATE_WebChannelConnection = class __PRIVATE_WebChannelConnection extends __PRIVATE_RestConnection {
	constructor(e) {
		super(e), this.ft = [], this.forceLongPolling = e.forceLongPolling, this.autoDetectLongPolling = e.autoDetectLongPolling, this.useFetchStreams = e.useFetchStreams, this.longPollingOptions = e.longPollingOptions;
	}
	/**
	* Initialize STAT_EVENT listener once. Subsequent calls are a no-op.
	* getStatEventTarget() returns the same target every time.
	*/ static gt() {
		if (!__PRIVATE_WebChannelConnection.yt) __PRIVATE_unguardedEventListen(getStatEventTarget(), Event.STAT_EVENT, ((e) => {
			e.stat === Stat.PROXY ? __PRIVATE_logDebug(Rt, "STAT_EVENT: detected buffering proxy") : e.stat === Stat.NOPROXY && __PRIVATE_logDebug(Rt, "STAT_EVENT: detected no buffering proxy");
		})), __PRIVATE_WebChannelConnection.yt = true;
	}
	st(t, n, r, i, s) {
		const _ = __PRIVATE_generateUniqueDebugId();
		return new Promise(((s, o) => {
			const a = new XhrIo();
			a.setWithCredentials(true), a.listenOnce(EventType.COMPLETE, (() => {
				try {
					switch (a.getLastErrorCode()) {
						case ErrorCode.NO_ERROR:
							const n = a.getResponseJson();
							__PRIVATE_logDebug(Rt, `XHR for RPC '${t}' ${_} received:`, JSON.stringify(n)), s(n);
							break;
						case ErrorCode.TIMEOUT:
							__PRIVATE_logDebug(Rt, `RPC '${t}' ${_} timed out`), o(new e(ta.DEADLINE_EXCEEDED, "Request time out"));
							break;
						case ErrorCode.HTTP_ERROR:
							const r = a.getStatus();
							if (__PRIVATE_logDebug(Rt, `RPC '${t}' ${_} failed with status:`, r, "response text:", a.getResponseText()), r > 0) {
								let t = a.getResponseJson();
								Array.isArray(t) && (t = t[0]);
								const n = t?.error;
								if (n && n.status && n.message) o(new e(function __PRIVATE_mapCodeFromHttpResponseErrorStatus(e) {
									const t = e.toLowerCase().replace(/_/g, "-");
									return Object.values(ta).indexOf(t) >= 0 ? t : ta.UNKNOWN;
								}(n.status), n.message));
								else o(new e(ta.UNKNOWN, "Server responded with status " + a.getStatus()));
							} else o(new e(ta.UNAVAILABLE, "Connection failed."));
							break;
						default: l(9055, {
							wt: t,
							streamId: _,
							bt: a.getLastErrorCode(),
							St: a.getLastError()
						});
					}
				} finally {
					__PRIVATE_logDebug(Rt, `RPC '${t}' ${_} completed.`);
				}
			}));
			const u = JSON.stringify(i);
			__PRIVATE_logDebug(Rt, `RPC '${t}' ${_} sending request:`, i), a.send(n, "POST", u, r, 15);
		}));
	}
	vt(t, n, r) {
		const i = __PRIVATE_generateUniqueDebugId(), s = [
			this.Xe,
			"/",
			"google.firestore.v1.Firestore",
			"/",
			t,
			"/channel"
		], _ = this.createWebChannelTransport(), o = {
			httpSessionIdParam: "gsessionid",
			initMessageHeaders: {},
			messageUrlParams: { database: `projects/${this.databaseId.projectId}/databases/${this.databaseId.database}` },
			sendRawJson: true,
			supportsCrossDomainXhr: true,
			internalChannelParams: { forwardChannelRequestTimeoutMs: 6e5 },
			forceLongPolling: this.forceLongPolling,
			detectBufferingProxy: this.autoDetectLongPolling
		}, a = this.longPollingOptions.timeoutSeconds;
		void 0 !== a && (o.longPollingTimeout = Math.round(1e3 * a)), this.useFetchStreams && (o.useFetchStreams = true), this.it(o.initMessageHeaders, n, r), o.encodeInitMessageHeaders = true;
		const u = s.join("");
		__PRIVATE_logDebug(Rt, `Creating RPC '${t}' stream ${i}: ${u}`, o);
		const c = _.createWebChannel(u, o);
		this.Dt(c);
		let l = false, E = false;
		const h = new __PRIVATE_StreamBridge({
			ot: (e) => {
				E ? __PRIVATE_logDebug(Rt, `Not sending because RPC '${t}' stream ${i} is closed:`, e) : (l || (__PRIVATE_logDebug(Rt, `Opening RPC '${t}' stream ${i} transport.`), c.open(), l = true), __PRIVATE_logDebug(Rt, `RPC '${t}' stream ${i} sending:`, e), c.send(e));
			},
			ut: () => c.close()
		});
		return __PRIVATE_unguardedEventListen(c, WebChannel.EventType.OPEN, (() => {
			E || (__PRIVATE_logDebug(Rt, `RPC '${t}' stream ${i} transport opened.`), h.Rt());
		})), __PRIVATE_unguardedEventListen(c, WebChannel.EventType.CLOSE, (() => {
			E || (E = !0, __PRIVATE_logDebug(Rt, `RPC '${t}' stream ${i} transport closed`), h.Vt(), this.xt(c));
		})), __PRIVATE_unguardedEventListen(c, WebChannel.EventType.ERROR, ((n) => {
			E || (E = !0, __PRIVATE_logWarn(Rt, `RPC '${t}' stream ${i} transport errored. Name:`, n.name, "Message:", n.message), h.Vt(new e(ta.UNAVAILABLE, "The operation could not be completed")));
		})), __PRIVATE_unguardedEventListen(c, WebChannel.EventType.MESSAGE, ((n) => {
			if (!E) {
				const r = n.data[0];
				__PRIVATE_hardAssert(!!r, 16349);
				const s = r, _ = s?.error || s[0]?.error;
				if (_) {
					__PRIVATE_logDebug(Rt, `RPC '${t}' stream ${i} received error:`, _);
					const n = _.status;
					let r = function __PRIVATE_mapCodeFromRpcStatus(e) {
						const t = et[e];
						if (void 0 !== t) return __PRIVATE_mapCodeFromRpcCode(t);
					}(n), s = _.message;
					"NOT_FOUND" === n && s.includes("database") && s.includes("does not exist") && s.includes(this.databaseId.database) && __PRIVATE_logWarn(`Database '${this.databaseId.database}' not found. Please check your project configuration.`), void 0 === r && (r = ta.INTERNAL, s = "Unknown error status: " + n + " with message " + _.message), E = !0, h.Vt(new e(r, s)), c.close();
				} else __PRIVATE_logDebug(Rt, `RPC '${t}' stream ${i} received:`, r), h.dt(r);
			}
		})), __PRIVATE_WebChannelConnection.gt(), setTimeout((() => {
			h.At();
		}), 0), h;
	}
	/**
	* Closes and cleans up any resources associated with the connection.
	*/ terminate() {
		this.ft.forEach(((e) => e.close())), this.ft = [];
	}
	/**
	* Add a WebChannel instance to the collection of open instances.
	* @param webChannel
	*/ Dt(e) {
		this.ft.push(e);
	}
	/**
	* Remove a WebChannel instance from the collection of open instances.
	* @param webChannel
	*/ xt(e) {
		this.ft = this.ft.filter(((t) => t === e));
	}
	/**
	* Modifies the headers for a request, adding the api key if present,
	* and then calling super.modifyHeadersForRequest
	*/ it(e, t, n) {
		super.it(e, t, n), this.databaseInfo.apiKey && (e["x-goog-api-key"] = this.databaseInfo.apiKey);
	}
	/**
	* Wrapped for mocking.
	* @protected
	*/ createWebChannelTransport() {
		return createWebChannelTransport();
	}
};
/**
* Track if the STAT_EVENT listener has been initialized.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/** Initializes the WebChannelConnection for the browser. */
function __PRIVATE_newConnection(e) {
	return new __PRIVATE_WebChannelConnection(e);
}
/** Return the Platform-specific connectivity monitor. */ __PRIVATE_WebChannelConnection.yt = false;
/**
* A helper for running delayed tasks following an exponential backoff curve
* between attempts.
*
* Each delay is made up of a "base" delay which follows the exponential
* backoff curve, and a +/- 50% "jitter" that is calculated and added to the
* base delay. This prevents clients from accidentally synchronizing their
* delays causing spikes of load to the backend.
*/
var __PRIVATE_ExponentialBackoff = class {
	constructor(e, t, n = 1e3, r = 1.5, i = 6e4) {
		this.Ct = e, this.timerId = t, this.Ft = n, this.Ot = r, this.Mt = i, this.Nt = 0, this.Lt = null, this.Bt = Date.now(), this.reset();
	}
	/**
	* Resets the backoff delay.
	*
	* The very next backoffAndWait() will have no delay. If it is called again
	* (i.e. due to an error), initialDelayMs (plus jitter) will be used, and
	* subsequent ones will increase according to the backoffFactor.
	*/ reset() {
		this.Nt = 0;
	}
	/**
	* Resets the backoff delay to the maximum delay (e.g. for use after a
	* RESOURCE_EXHAUSTED error).
	*/ Ut() {
		this.Nt = this.Mt;
	}
	/**
	* Returns a promise that resolves after currentDelayMs, and increases the
	* delay for any subsequent attempts. If there was a pending backoff operation
	* already, it will be canceled.
	*/ kt(e) {
		this.cancel();
		const t = Math.floor(this.Nt + this.qt()), n = Math.max(0, Date.now() - this.Bt), r = Math.max(0, t - n);
		r > 0 && __PRIVATE_logDebug("ExponentialBackoff", `Backing off for ${r} ms (base delay: ${this.Nt} ms, delay with jitter: ${t} ms, last attempt: ${n} ms ago)`), this.Lt = this.Ct.enqueueAfterDelay(this.timerId, r, (() => (this.Bt = Date.now(), e()))), this.Nt *= this.Ot, this.Nt < this.Ft && (this.Nt = this.Ft), this.Nt > this.Mt && (this.Nt = this.Mt);
	}
	$t() {
		null !== this.Lt && (this.Lt.skipDelay(), this.Lt = null);
	}
	cancel() {
		null !== this.Lt && (this.Lt.cancel(), this.Lt = null);
	}
	/** Returns a random value in the range [-currentBaseMs/2, currentBaseMs/2] */ qt() {
		return (Math.random() - .5) * this.Nt;
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var At = "PersistentStream";
/** The time a stream stays open after it is marked idle. */
/**
* A PersistentStream is an abstract base class that represents a streaming RPC
* to the Firestore backend. It's built on top of the connections own support
* for streaming RPCs, and adds several critical features for our clients:
*
*   - Exponential backoff on failure
*   - Authentication via CredentialsProvider
*   - Dispatching all callbacks into the shared worker queue
*   - Closing idle streams after 60 seconds of inactivity
*
* Subclasses of PersistentStream implement serialization of models to and
* from the JSON representation of the protocol buffers for a specific
* streaming RPC.
*
* ## Starting and Stopping
*
* Streaming RPCs are stateful and need to be start()ed before messages can
* be sent and received. The PersistentStream will call the onOpen() function
* of the listener once the stream is ready to accept requests.
*
* Should a start() fail, PersistentStream will call the registered onClose()
* listener with a FirestoreError indicating what went wrong.
*
* A PersistentStream can be started and stopped repeatedly.
*
* Generic types:
*  SendType: The type of the outgoing message of the underlying
*    connection stream
*  ReceiveType: The type of the incoming message of the underlying
*    connection stream
*  ListenerType: The type of the listener that will be used for callbacks
*/
var __PRIVATE_PersistentStream = class {
	constructor(e, t, n, r, i, s, _, o) {
		this.Ct = e, this.Kt = n, this.Qt = r, this.connection = i, this.authCredentialsProvider = s, this.appCheckCredentialsProvider = _, this.listener = o, this.state = 0, this.Wt = 0, this.Gt = null, this.zt = null, this.stream = null, this.jt = 0, this.Ht = new __PRIVATE_ExponentialBackoff(e, t);
	}
	/**
	* Returns true if start() has been called and no error has occurred. True
	* indicates the stream is open or in the process of opening (which
	* encompasses respecting backoff, getting auth tokens, and starting the
	* actual RPC). Use isOpen() to determine if the stream is open and ready for
	* outbound requests.
	*/ Jt() {
		return 1 === this.state || 5 === this.state || this.Yt();
	}
	/**
	* Returns true if the underlying RPC is open (the onOpen() listener has been
	* called) and the stream is ready for outbound requests.
	*/ Yt() {
		return 2 === this.state || 3 === this.state;
	}
	/**
	* Starts the RPC. Only allowed if isStarted() returns false. The stream is
	* not immediately ready for use: onOpen() will be invoked when the RPC is
	* ready for outbound requests, at which point isOpen() will return true.
	*
	* When start returns, isStarted() will return true.
	*/ start() {
		this.jt = 0, 4 !== this.state ? this.auth() : this.Zt();
	}
	/**
	* Stops the RPC. This call is idempotent and allowed regardless of the
	* current isStarted() state.
	*
	* When stop returns, isStarted() and isOpen() will both return false.
	*/ async stop() {
		this.Jt() && await this.close(0);
	}
	/**
	* After an error the stream will usually back off on the next attempt to
	* start it. If the error warrants an immediate restart of the stream, the
	* sender can use this to indicate that the receiver should not back off.
	*
	* Each error will call the onClose() listener. That function can decide to
	* inhibit backoff if required.
	*/ Xt() {
		this.state = 0, this.Ht.reset();
	}
	/**
	* Marks this stream as idle. If no further actions are performed on the
	* stream for one minute, the stream will automatically close itself and
	* notify the stream's onClose() handler with Status.OK. The stream will then
	* be in a !isStarted() state, requiring the caller to start the stream again
	* before further use.
	*
	* Only streams that are in state 'Open' can be marked idle, as all other
	* states imply pending network operations.
	*/ en() {
		this.Yt() && null === this.Gt && (this.Gt = this.Ct.enqueueAfterDelay(this.Kt, 6e4, (() => this.tn())));
	}
	/** Sends a message to the underlying stream. */ nn(e) {
		this.rn(), this.stream.send(e);
	}
	/** Called by the idle timer when the stream should close due to inactivity. */ async tn() {
		if (this.Yt()) return this.close(0);
	}
	/** Marks the stream as active again. */ rn() {
		this.Gt && (this.Gt.cancel(), this.Gt = null);
	}
	/** Cancels the health check delayed operation. */ sn() {
		this.zt && (this.zt.cancel(), this.zt = null);
	}
	/**
	* Closes the stream and cleans up as necessary:
	*
	* * closes the underlying GRPC stream;
	* * calls the onClose handler with the given 'error';
	* * sets internal stream state to 'finalState';
	* * adjusts the backoff timer based on the error
	*
	* A new stream can be opened by calling start().
	*
	* @param finalState - the intended state of the stream after closing.
	* @param error - the error the connection was closed with.
	*/ async close(e, t) {
		this.rn(), this.sn(), this.Ht.cancel(), this.Wt++, 4 !== e ? this.Ht.reset() : t && t.code === ta.RESOURCE_EXHAUSTED ? (__PRIVATE_logError(t.toString()), __PRIVATE_logError("Using maximum backoff delay to prevent overloading the backend."), this.Ht.Ut()) : t && t.code === ta.UNAUTHENTICATED && 3 !== this.state && (this.authCredentialsProvider.invalidateToken(), this.appCheckCredentialsProvider.invalidateToken()), null !== this.stream && (this._n(), this.stream.close(), this.stream = null), this.state = e, await this.listener.Tt(t);
	}
	/**
	* Can be overridden to perform additional cleanup before the stream is closed.
	* Calling super.tearDown() is not required.
	*/ _n() {}
	auth() {
		this.state = 1;
		const t = this.an(this.Wt), n = this.Wt;
		Promise.all([this.authCredentialsProvider.getToken(), this.appCheckCredentialsProvider.getToken()]).then((([e, t]) => {
			this.Wt === n && this.un(e, t);
		}), ((n) => {
			t((() => {
				const t = new e(ta.UNKNOWN, "Fetching auth token failed: " + n.message);
				return this.cn(t);
			}));
		}));
	}
	un(e, t) {
		const n = this.an(this.Wt);
		this.stream = this.En(e, t), this.stream.ct((() => {
			n((() => this.listener.ct()));
		})), this.stream.Et((() => {
			n((() => (this.state = 2, this.zt = this.Ct.enqueueAfterDelay(this.Qt, 1e4, (() => (this.Yt() && (this.state = 3), Promise.resolve()))), this.listener.Et())));
		})), this.stream.Tt(((e) => {
			n((() => this.cn(e)));
		})), this.stream.onMessage(((e) => {
			n((() => 1 == ++this.jt ? this.hn(e) : this.onNext(e)));
		}));
	}
	Zt() {
		this.state = 5, this.Ht.kt((async () => {
			this.state = 0, this.start();
		}));
	}
	cn(e) {
		return __PRIVATE_logDebug(At, `close with error: ${e}`), this.stream = null, this.close(4, e);
	}
	/**
	* Returns a "dispatcher" function that dispatches operations onto the
	* AsyncQueue but only runs them if closeCount remains unchanged. This allows
	* us to turn auth / stream callbacks into no-ops if the stream is closed /
	* re-opened, etc.
	*/ an(e) {
		return (t) => {
			this.Ct.enqueueAndForget((() => this.Wt === e ? t() : (__PRIVATE_logDebug(At, "stream callback skipped by getCloseGuardedDispatcher."), Promise.resolve())));
		};
	}
};
/**
* A PersistentStream that implements the Listen RPC.
*
* Once the Listen stream has called the onOpen() listener, any number of
* listen() and unlisten() calls can be made to control what changes will be
* sent from the server for ListenResponses.
*/ var __PRIVATE_PersistentListenStream = class extends __PRIVATE_PersistentStream {
	constructor(e, t, n, r, i, s) {
		super(e, "listen_stream_connection_backoff", "listen_stream_idle", "health_check_timeout", t, n, r, s), this.serializer = i;
	}
	En(e, t) {
		return this.connection.vt("Listen", e, t);
	}
	hn(e) {
		return this.onNext(e);
	}
	onNext(e) {
		this.Ht.reset();
		const t = __PRIVATE_fromWatchChange(this.serializer, e), n = function __PRIVATE_versionFromListenResponse(e) {
			if (!("targetChange" in e)) return SnapshotVersion.min();
			const t = e.targetChange;
			return t.targetIds && t.targetIds.length ? SnapshotVersion.min() : t.readTime ? __PRIVATE_fromVersion(t.readTime) : SnapshotVersion.min();
		}(e);
		return this.listener.Tn(t, n);
	}
	/**
	* Registers interest in the results of the given target. If the target
	* includes a resumeToken it will be included in the request. Results that
	* affect the target will be streamed back as WatchChange messages that
	* reference the targetId.
	*/ Pn(e) {
		const t = {};
		t.database = __PRIVATE_getEncodedDatabaseId(this.serializer), t.addTarget = function __PRIVATE_toTarget(e, t) {
			let n;
			const r = t.target;
			if (n = __PRIVATE_targetIsPipelineTarget(r) ? { pipelineQuery: __PRIVATE_toPipelineTarget(e, r) } : __PRIVATE_targetIsDocumentTarget(r) ? { documents: __PRIVATE_toDocumentsTarget(e, r) } : { query: __PRIVATE_toQueryTarget(e, r).Se }, n.targetId = t.targetId, t.resumeToken.approximateByteSize() > 0) {
				n.resumeToken = __PRIVATE_toBytes(e, t.resumeToken);
				const r = __PRIVATE_toInt32Proto(e, t.expectedCount);
				null !== r && (n.expectedCount = r);
			} else if (t.snapshotVersion.compareTo(SnapshotVersion.min()) > 0) {
				n.readTime = toTimestamp(e, t.snapshotVersion.toTimestamp());
				const r = __PRIVATE_toInt32Proto(e, t.expectedCount);
				null !== r && (n.expectedCount = r);
			}
			return n;
		}(this.serializer, e);
		const n = __PRIVATE_toListenRequestLabels(this.serializer, e);
		n && (t.labels = n), this.nn(t);
	}
	/**
	* Unregisters interest in the results of the target associated with the
	* given targetId.
	*/ In(e) {
		const t = {};
		t.database = __PRIVATE_getEncodedDatabaseId(this.serializer), t.removeTarget = e, this.nn(t);
	}
};
/**
* A Stream that implements the Write RPC.
*
* The Write RPC requires the caller to maintain special streamToken
* state in between calls, to help the server understand which responses the
* client has processed by the time the next request is made. Every response
* will contain a streamToken; this value must be passed to the next
* request.
*
* After calling start() on this stream, the next request must be a handshake,
* containing whatever streamToken is on hand. Once a response to this
* request is received, all pending mutations may be submitted. When
* submitting multiple batches of mutations at the same time, it's
* okay to use the same streamToken for the calls to writeMutations.
*
* TODO(b/33271235): Use proto types
*/ var __PRIVATE_PersistentWriteStream = class extends __PRIVATE_PersistentStream {
	constructor(e, t, n, r, i, s) {
		super(e, "write_stream_connection_backoff", "write_stream_idle", "health_check_timeout", t, n, r, s), this.serializer = i;
	}
	/**
	* Tracks whether or not a handshake has been successfully exchanged and
	* the stream is ready to accept mutations.
	*/ get Rn() {
		return this.jt > 0;
	}
	start() {
		this.lastStreamToken = void 0, super.start();
	}
	_n() {
		this.Rn && this.An([]);
	}
	En(e, t) {
		return this.connection.vt("Write", e, t);
	}
	hn(e) {
		return __PRIVATE_hardAssert(!!e.streamToken, 31322), this.lastStreamToken = e.streamToken, __PRIVATE_hardAssert(!e.writeResults || 0 === e.writeResults.length, 55816), this.listener.Vn();
	}
	onNext(e) {
		__PRIVATE_hardAssert(!!e.streamToken, 12678), this.lastStreamToken = e.streamToken, this.Ht.reset();
		const t = __PRIVATE_fromWriteResults(e.writeResults, e.commitTime), n = __PRIVATE_fromVersion(e.commitTime);
		return this.listener.dn(n, t);
	}
	/**
	* Sends an initial streamToken to the server, performing the handshake
	* required to make the StreamingWrite RPC work. Subsequent
	* calls should wait until onHandshakeComplete was called.
	*/ fn() {
		const e = {};
		e.database = __PRIVATE_getEncodedDatabaseId(this.serializer), this.nn(e);
	}
	/** Sends a group of mutations to the Firestore backend to apply. */ An(e) {
		const t = {
			streamToken: this.lastStreamToken,
			writes: e.map(((e) => toMutation(this.serializer, e)))
		};
		this.nn(t);
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Datastore and its related methods are a wrapper around the external Google
* Cloud Datastore grpc API, which provides an interface that is more convenient
* for the rest of the client SDK architecture to consume.
*/ var Datastore = class {};
/**
* An implementation of Datastore that exposes additional state for internal
* consumption.
*/ var __PRIVATE_DatastoreImpl = class extends Datastore {
	constructor(e, t, n, r) {
		super(), this.authCredentials = e, this.appCheckCredentials = t, this.connection = n, this.serializer = r, this.mn = false;
	}
	pn() {
		if (this.mn) throw new e(ta.FAILED_PRECONDITION, "The client has already been terminated.");
	}
	/** Invokes the provided RPC with auth and AppCheck tokens. */ nt(t, n, r, i) {
		return this.pn(), Promise.all([this.authCredentials.getToken(), this.appCheckCredentials.getToken()]).then((([e, s]) => this.connection.nt(t, __PRIVATE_toResourcePath(n, r), i, e, s))).catch(((t) => {
			throw "FirebaseError" === t.name ? (t.code === ta.UNAUTHENTICATED && (this.authCredentials.invalidateToken(), this.appCheckCredentials.invalidateToken()), t) : new e(ta.UNKNOWN, t.toString());
		}));
	}
	/** Invokes the provided RPC with streamed results with auth and AppCheck tokens. */ _t(t, n, r, i, s) {
		return this.pn(), Promise.all([this.authCredentials.getToken(), this.appCheckCredentials.getToken()]).then((([e, _]) => this.connection._t(t, __PRIVATE_toResourcePath(n, r), i, e, _, s))).catch(((t) => {
			throw "FirebaseError" === t.name ? (t.code === ta.UNAUTHENTICATED && (this.authCredentials.invalidateToken(), this.appCheckCredentials.invalidateToken()), t) : new e(ta.UNKNOWN, t.toString());
		}));
	}
	terminate() {
		this.mn = true, this.connection.terminate();
	}
};
function __PRIVATE_newDatastore(e, t, n, r) {
	return new __PRIVATE_DatastoreImpl(e, t, n, r);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var Vt = "ComponentProvider";
var dt = /* @__PURE__ */ new Map();
/**
* An instance map that ensures only one Datastore exists per Firestore
* instance.
*/ function __PRIVATE_makeDatabaseInfo(e, t, n, r, i) {
	return new DatabaseInfo(e, t, n, i.host, i.ssl, i.experimentalForceLongPolling, i.experimentalAutoDetectLongPolling, __PRIVATE_cloneLongPollingOptions(i.experimentalLongPollingOptions), i.useFetchStreams, i.isUsingEmulator, r, i._customHeaders, i.grpcFlowControlWindow);
}
/**
* @license
* Copyright 2018 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var ft = {
	didRun: false,
	sequenceNumbersCollected: 0,
	targetsRemoved: 0,
	documentsRemoved: 0
};
var mt = 41943040;
var LruParams = class LruParams {
	static withCacheSize(e) {
		return new LruParams(e, LruParams.DEFAULT_COLLECTION_PERCENTILE, LruParams.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT);
	}
	constructor(e, t, n) {
		this.cacheSizeCollectionThreshold = e, this.percentileToCollect = t, this.maximumSequenceNumbersToCollect = n;
	}
};
LruParams.DEFAULT_COLLECTION_PERCENTILE = 10, LruParams.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT = 1e3, LruParams.DEFAULT = new LruParams(mt, LruParams.DEFAULT_COLLECTION_PERCENTILE, LruParams.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT), LruParams.DISABLED = new LruParams(-1, 0, 0);
/**
* @license
* Copyright 2018 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* `ListenSequence` is a monotonic sequence. It is initialized with a minimum value to
* exceed. All subsequent calls to next will return increasing values. If provided with a
* `SequenceNumberSyncer`, it will additionally bump its next value when told of a new value, as
* well as write out sequence numbers that it produces via `next()`.
*/
var __PRIVATE_ListenSequence = class {
	constructor(e, t) {
		this.previousValue = e, t && (t.sequenceNumberHandler = (e) => this.gn(e), this.yn = (e) => t.writeSequenceNumber(e));
	}
	gn(e) {
		return this.previousValue = Math.max(e, this.previousValue), this.previousValue;
	}
	next() {
		const e = ++this.previousValue;
		return this.yn && this.yn(e), e;
	}
};
__PRIVATE_ListenSequence.wn = -1;
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var pt = "The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";
/**
* A base class representing a persistence transaction, encapsulating both the
* transaction's sequence numbers as well as a list of onCommitted listeners.
*
* When you call Persistence.runTransaction(), it will create a transaction and
* pass it to your callback. You then pass it to any method that operates
* on persistence.
*/ var PersistenceTransaction = class {
	constructor() {
		this.onCommittedListeners = [];
	}
	addOnCommittedListener(e) {
		this.onCommittedListeners.push(e);
	}
	raiseOnCommittedEvent() {
		this.onCommittedListeners.forEach(((e) => e()));
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Verifies the error thrown by a LocalStore operation. If a LocalStore
* operation fails because the primary lease has been taken by another client,
* we ignore the error (the persistence layer will immediately call
* `applyPrimaryLease` to propagate the primary state change). All other errors
* are re-thrown.
*
* @param err - An error returned by a LocalStore operation.
* @returns A Promise that resolves after we recovered, or the original error.
*/ async function __PRIVATE_ignoreIfPrimaryLeaseLoss(e) {
	if (e.code !== ta.FAILED_PRECONDITION || e.message !== pt) throw e;
	__PRIVATE_logDebug("LocalStore", "Unexpectedly lost primary lease");
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* PersistencePromise is essentially a re-implementation of Promise except
* it has a .next() method instead of .then() and .next() and .catch() callbacks
* are executed synchronously when a PersistencePromise resolves rather than
* asynchronously (Promise implementations use setImmediate() or similar).
*
* This is necessary to interoperate with IndexedDB which will automatically
* commit transactions if control is returned to the event loop without
* synchronously initiating another operation on the transaction.
*
* NOTE: .then() and .catch() only allow a single consumer, unlike normal
* Promises.
*/ var PersistencePromise = class PersistencePromise {
	constructor(e) {
		this.nextCallback = null, this.catchCallback = null, this.result = void 0, this.error = void 0, this.isDone = false, this.callbackAttached = false, e(((e) => {
			this.isDone = true, this.result = e, this.nextCallback && this.nextCallback(e);
		}), ((e) => {
			this.isDone = true, this.error = e, this.catchCallback && this.catchCallback(e);
		}));
	}
	catch(e) {
		return this.next(void 0, e);
	}
	next(e, t) {
		return this.callbackAttached && l(59440), this.callbackAttached = true, this.isDone ? this.error ? this.wrapFailure(t, this.error) : this.wrapSuccess(e, this.result) : new PersistencePromise(((n, r) => {
			this.nextCallback = (t) => {
				this.wrapSuccess(e, t).next(n, r);
			}, this.catchCallback = (e) => {
				this.wrapFailure(t, e).next(n, r);
			};
		}));
	}
	toPromise() {
		return new Promise(((e, t) => {
			this.next(e, t);
		}));
	}
	wrapUserFunction(e) {
		try {
			const t = e();
			return t instanceof PersistencePromise ? t : PersistencePromise.resolve(t);
		} catch (e) {
			return PersistencePromise.reject(e);
		}
	}
	wrapSuccess(e, t) {
		return e ? this.wrapUserFunction((() => e(t))) : PersistencePromise.resolve(t);
	}
	wrapFailure(e, t) {
		return e ? this.wrapUserFunction((() => e(t))) : PersistencePromise.reject(t);
	}
	static resolve(e) {
		return new PersistencePromise(((t, n) => {
			t(e);
		}));
	}
	static reject(e) {
		return new PersistencePromise(((t, n) => {
			n(e);
		}));
	}
	static waitFor(e) {
		return new PersistencePromise(((t, n) => {
			let r = 0, i = 0, s = false;
			e.forEach(((e) => {
				++r, e.next((() => {
					++i, s && i === r && t();
				}), ((e) => n(e)));
			})), s = true, i === r && t();
		}));
	}
	/**
	* Given an array of predicate functions that asynchronously evaluate to a
	* boolean, implements a short-circuiting `or` between the results. Predicates
	* will be evaluated until one of them returns `true`, then stop. The final
	* result will be whether any of them returned `true`.
	*/ static or(e) {
		let t = PersistencePromise.resolve(false);
		for (const n of e) t = t.next(((e) => e ? PersistencePromise.resolve(e) : n()));
		return t;
	}
	static forEach(e, t) {
		const n = [];
		return e.forEach(((e, r) => {
			n.push(t.call(this, e, r));
		})), this.waitFor(n);
	}
	/**
	* Concurrently map all array elements through asynchronous function.
	*/ static mapArray(e, t) {
		return new PersistencePromise(((n, r) => {
			const i = e.length, s = new Array(i);
			let _ = 0;
			for (let o = 0; o < i; o++) {
				const a = o;
				t(e[a]).next(((e) => {
					s[a] = e, ++_, _ === i && n(s);
				}), ((e) => r(e)));
			}
		}));
	}
	/**
	* An alternative to recursive PersistencePromise calls, that avoids
	* potential memory problems from unbounded chains of promises.
	*
	* The `action` will be called repeatedly while `condition` is true.
	*/ static doWhile(e, t) {
		return new PersistencePromise(((n, r) => {
			const process = () => {
				true === e() ? t().next((() => {
					process();
				}), r) : n();
			};
			process();
		}));
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/** Parse User Agent to determine Android version. Returns -1 if not found. */ function __PRIVATE_getAndroidVersion(e) {
	const t = e.match(/Android ([\d.]+)/i), n = t ? t[1].split(".").slice(0, 2).join(".") : "-1";
	return Number(n);
}
/** Verifies whether `e` is an IndexedDbTransactionError. */ function __PRIVATE_isIndexedDbTransactionError(e) {
	return "IndexedDbTransactionError" === e.name;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var wt = "LruGarbageCollector";
var bt = 1048576;
function __PRIVATE_bufferEntryComparator([e, t], [n, r]) {
	const i = __PRIVATE_primitiveComparator(e, n);
	return 0 === i ? __PRIVATE_primitiveComparator(t, r) : i;
}
/**
* Used to calculate the nth sequence number. Keeps a rolling buffer of the
* lowest n values passed to `addElement`, and finally reports the largest of
* them in `maxValue`.
*/ var __PRIVATE_RollingSequenceNumberBuffer = class {
	constructor(e) {
		this.Yn = e, this.buffer = new SortedSet(__PRIVATE_bufferEntryComparator), this.Zn = 0;
	}
	Xn() {
		return ++this.Zn;
	}
	er(e) {
		const t = [e, this.Xn()];
		if (this.buffer.size < this.Yn) this.buffer = this.buffer.add(t);
		else {
			const e = this.buffer.last();
			__PRIVATE_bufferEntryComparator(t, e) < 0 && (this.buffer = this.buffer.delete(e).add(t));
		}
	}
	get maxValue() {
		return this.buffer.last()[0];
	}
};
/**
* This class is responsible for the scheduling of LRU garbage collection. It handles checking
* whether or not GC is enabled, as well as which delay to use before the next run.
*/ var __PRIVATE_LruScheduler = class {
	constructor(e, t, n) {
		this.garbageCollector = e, this.asyncQueue = t, this.localStore = n, this.tr = null;
	}
	start() {
		-1 !== this.garbageCollector.params.cacheSizeCollectionThreshold && this.nr(6e4);
	}
	stop() {
		this.tr && (this.tr.cancel(), this.tr = null);
	}
	get started() {
		return null !== this.tr;
	}
	nr(e) {
		__PRIVATE_logDebug(wt, `Garbage collection scheduled in ${e}ms`), this.tr = this.asyncQueue.enqueueAfterDelay("lru_garbage_collection", e, (async () => {
			this.tr = null;
			try {
				await this.localStore.collectGarbage(this.garbageCollector);
			} catch (e) {
				__PRIVATE_isIndexedDbTransactionError(e) ? __PRIVATE_logDebug(wt, "Ignoring IndexedDB error during garbage collection: ", e) : await __PRIVATE_ignoreIfPrimaryLeaseLoss(e);
			}
			await this.nr(3e5);
		}));
	}
};
/**
* Implements the steps for LRU garbage collection.
*/ var __PRIVATE_LruGarbageCollectorImpl = class {
	constructor(e, t) {
		this.rr = e, this.params = t;
	}
	calculateTargetCount(e, t) {
		return this.rr.ir(e).next(((e) => Math.floor(t / 100 * e)));
	}
	nthSequenceNumber(e, t) {
		if (0 === t) return PersistencePromise.resolve(__PRIVATE_ListenSequence.wn);
		const n = new __PRIVATE_RollingSequenceNumberBuffer(t);
		return this.rr.forEachTarget(e, ((e) => n.er(e.sequenceNumber))).next((() => this.rr.sr(e, ((e) => n.er(e))))).next((() => n.maxValue));
	}
	removeTargets(e, t, n) {
		return this.rr.removeTargets(e, t, n);
	}
	removeOrphanedDocuments(e, t) {
		return this.rr.removeOrphanedDocuments(e, t);
	}
	collect(e, t) {
		return -1 === this.params.cacheSizeCollectionThreshold ? (__PRIVATE_logDebug("LruGarbageCollector", "Garbage collection skipped; disabled"), PersistencePromise.resolve(ft)) : this.getCacheSize(e).next(((n) => n < this.params.cacheSizeCollectionThreshold ? (__PRIVATE_logDebug("LruGarbageCollector", `Garbage collection skipped; Cache size ${n} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`), ft) : this._r(e, t)));
	}
	getCacheSize(e) {
		return this.rr.getCacheSize(e);
	}
	_r(e, t) {
		let n, r, i, s, _, o, a;
		const u = Date.now();
		return this.calculateTargetCount(e, this.params.percentileToCollect).next(((t) => (t > this.params.maximumSequenceNumbersToCollect ? (__PRIVATE_logDebug("LruGarbageCollector", `Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${t}`), r = this.params.maximumSequenceNumbersToCollect) : r = t, s = Date.now(), this.nthSequenceNumber(e, r)))).next(((r) => (n = r, _ = Date.now(), this.removeTargets(e, n, t)))).next(((t) => (i = t, o = Date.now(), this.removeOrphanedDocuments(e, n)))).next(((e) => {
			if (a = Date.now(), __PRIVATE_getLogLevel() <= LogLevel.DEBUG) __PRIVATE_logDebug("LruGarbageCollector", `LRU Garbage Collection\n\tCounted targets in ${s - u}ms\n\tDetermined least recently used ${r} in ` + (_ - s) + `ms
\tRemoved ${i} targets in ` + (o - _) + `ms
\tRemoved ${e} documents in ` + (a - o) + `ms
Total Duration: ${a - u}ms`);
			return PersistencePromise.resolve({
				didRun: true,
				sequenceNumbersCollected: r,
				targetsRemoved: i,
				documentsRemoved: e
			});
		}));
	}
};
function __PRIVATE_newLruGarbageCollector(e, t) {
	return new __PRIVATE_LruGarbageCollectorImpl(e, t);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var St = "firestore.googleapis.com";
var vt = true;
/**
* A concrete type describing all the values that can be applied via a
* user-supplied `FirestoreSettings` object. This is a separate type so that
* defaults can be supplied and the value can be checked for equality.
*/
var FirestoreSettingsImpl = class {
	constructor(t) {
		if (void 0 === t.host) {
			if (void 0 !== t.ssl) throw new e(ta.INVALID_ARGUMENT, "Can't provide ssl option if host option is not set");
			this.host = St, this.ssl = vt;
		} else this.host = t.host, this.ssl = t.ssl ?? vt;
		if (this.isUsingEmulator = void 0 !== t.emulatorOptions, this.credentials = t.credentials, this.ignoreUndefinedProperties = !!t.ignoreUndefinedProperties, this.localCache = t.localCache, t._customHeaders && (this._customHeaders = { ...t._customHeaders }), void 0 === t.cacheSizeBytes) this.cacheSizeBytes = mt;
		else {
			if (-1 !== t.cacheSizeBytes && t.cacheSizeBytes < bt) throw new e(ta.INVALID_ARGUMENT, "cacheSizeBytes must be at least 1048576");
			this.cacheSizeBytes = t.cacheSizeBytes;
		}
		if (__PRIVATE_validateIsNotUsedTogether("experimentalForceLongPolling", t.experimentalForceLongPolling, "experimentalAutoDetectLongPolling", t.experimentalAutoDetectLongPolling), this.experimentalForceLongPolling = !!t.experimentalForceLongPolling, this.experimentalForceLongPolling ? this.experimentalAutoDetectLongPolling = false : void 0 === t.experimentalAutoDetectLongPolling ? this.experimentalAutoDetectLongPolling = true : this.experimentalAutoDetectLongPolling = !!t.experimentalAutoDetectLongPolling, this.experimentalLongPollingOptions = __PRIVATE_cloneLongPollingOptions(t.experimentalLongPollingOptions ?? {}), function __PRIVATE_validateLongPollingOptions(t) {
			if (void 0 !== t.timeoutSeconds) {
				if (isNaN(t.timeoutSeconds)) throw new e(ta.INVALID_ARGUMENT, `invalid long polling timeout: ${t.timeoutSeconds} (must not be NaN)`);
				if (t.timeoutSeconds < 5) throw new e(ta.INVALID_ARGUMENT, `invalid long polling timeout: ${t.timeoutSeconds} (minimum allowed value is 5)`);
				if (t.timeoutSeconds > 30) throw new e(ta.INVALID_ARGUMENT, `invalid long polling timeout: ${t.timeoutSeconds} (maximum allowed value is 30)`);
			}
		}(this.experimentalLongPollingOptions), this.useFetchStreams = !!t.useFetchStreams, void 0 !== t.grpcFlowControlWindow) {
			/**
			* @license
			* Copyright 2020 Google LLC
			*
			* Licensed under the Apache License, Version 2.0 (the "License");
			* you may not use this file except in compliance with the License.
			* You may obtain a copy of the License at
			*
			*   http://www.apache.org/licenses/LICENSE-2.0
			*
			* Unless required by applicable law or agreed to in writing, software
			* distributed under the License is distributed on an "AS IS" BASIS,
			* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
			* See the License for the specific language governing permissions and
			* limitations under the License.
			*/
			if ("number" != typeof t.grpcFlowControlWindow || t.grpcFlowControlWindow <= 0 || t.grpcFlowControlWindow > 2147483647 || !Number.isInteger(t.grpcFlowControlWindow)) throw new e(ta.INVALID_ARGUMENT, "grpcFlowControlWindow must be a positive integer and cannot exceed 2147483647");
			this.grpcFlowControlWindow = t.grpcFlowControlWindow;
		}
	}
	isEqual(e) {
		return this.host === e.host && this.ssl === e.ssl && this.credentials === e.credentials && this.cacheSizeBytes === e.cacheSizeBytes && this.experimentalForceLongPolling === e.experimentalForceLongPolling && this.experimentalAutoDetectLongPolling === e.experimentalAutoDetectLongPolling && function __PRIVATE_longPollingOptionsEqual(e, t) {
			/**
			* @license
			* Copyright 2023 Google LLC
			*
			* Licensed under the Apache License, Version 2.0 (the "License");
			* you may not use this file except in compliance with the License.
			* You may obtain a copy of the License at
			*
			*   http://www.apache.org/licenses/LICENSE-2.0
			*
			* Unless required by applicable law or agreed to in writing, software
			* distributed under the License is distributed on an "AS IS" BASIS,
			* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
			* See the License for the specific language governing permissions and
			* limitations under the License.
			*/
			return e.timeoutSeconds === t.timeoutSeconds;
		}(this.experimentalLongPollingOptions, e.experimentalLongPollingOptions) && this.ignoreUndefinedProperties === e.ignoreUndefinedProperties && this.useFetchStreams === e.useFetchStreams && this.grpcFlowControlWindow === e.grpcFlowControlWindow && function __PRIVATE_customHeadersEqual(e, t) {
			if (e === t) return true;
			if (!e || !t) return false;
			const n = Object.keys(e), r = Object.keys(t);
			if (n.length !== r.length) return false;
			for (const r of n) if (e[r] !== t[r]) return false;
			return true;
		}(this._customHeaders, e._customHeaders);
	}
};
var Dt = class Firestore {
	/** @hideconstructor */
	constructor(e, t, n, r) {
		this._authCredentials = e, this._appCheckCredentials = t, this._databaseId = n, this._app = r, this.type = "firestore-lite", this._persistenceKey = "(lite)", this._settings = new FirestoreSettingsImpl({}), this._settingsFrozen = false, this._emulatorOptions = {}, this._terminateTask = "notTerminated";
	}
	/**
	* The {@link @firebase/app#FirebaseApp} associated with this `Firestore` service
	* instance.
	*/ get app() {
		if (!this._app) throw new e(ta.FAILED_PRECONDITION, "Firestore was not initialized using the Firebase SDK. 'app' is not available");
		return this._app;
	}
	get _initialized() {
		return this._settingsFrozen;
	}
	get _terminated() {
		return "notTerminated" !== this._terminateTask;
	}
	_setSettings(t) {
		if (this._settingsFrozen) throw new e(ta.FAILED_PRECONDITION, "Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");
		this._settings = new FirestoreSettingsImpl(t), this._emulatorOptions = t.emulatorOptions || {}, void 0 !== t.credentials && (this._authCredentials = function __PRIVATE_makeAuthCredentialsProvider(t) {
			if (!t) return new __PRIVATE_EmptyAuthCredentialsProvider();
			switch (t.type) {
				case "firstParty": return new __PRIVATE_FirstPartyAuthCredentialsProvider(t.sessionIndex || "0", t.iamToken || null, t.authTokenFactory || null);
				case "provider": return t.client;
				default: throw new e(ta.INVALID_ARGUMENT, "makeAuthCredentialsProvider failed due to invalid credential type");
			}
		}(t.credentials));
	}
	_getSettings() {
		return this._settings;
	}
	_getEmulatorOptions() {
		return this._emulatorOptions;
	}
	_freezeSettings() {
		return this._settingsFrozen = true, this._settings;
	}
	_delete() {
		return "notTerminated" === this._terminateTask && (this._terminateTask = this._terminate()), this._terminateTask;
	}
	async _restart() {
		"notTerminated" === this._terminateTask ? await this._terminate() : this._terminateTask = "notTerminated";
	}
	/** Returns a JSON-serializable representation of this `Firestore` instance. */ toJSON() {
		return {
			app: this._app,
			databaseId: this._databaseId,
			settings: this._settings
		};
	}
	/**
	* Terminates all components used by this client. Subclasses can override
	* this method to clean up their own dependencies, but must also call this
	* method.
	*
	* Only ever called once.
	*/ _terminate() {
		/**
		* Removes all components associated with the provided instance. Must be called
		* when the `Firestore` instance is terminated.
		*/
		return function __PRIVATE_removeComponents(e) {
			const t = dt.get(e);
			t && (__PRIVATE_logDebug(Vt, "Removing Datastore"), dt.delete(e), t.terminate());
		}(this), Promise.resolve();
	}
};
/**
* Modify this instance to communicate with the Cloud Firestore emulator.
*
* Note: This must be called before this instance has been used to do any
* operations.
*
* @param firestore - The `Firestore` instance to configure to connect to the
* emulator.
* @param host - the emulator host (ex: localhost).
* @param port - the emulator port (ex: 9000).
* @param options.mockUserToken - the mock auth token to use for unit testing
* Security Rules.
*/ function connectFirestoreEmulator(t, n, r, i = {}) {
	t = ra(t, Dt);
	const s = isCloudWorkstation(n), _ = t._getSettings(), o = {
		..._,
		emulatorOptions: t._getEmulatorOptions()
	}, a = `${n}:${r}`;
	s && pingServer(`https://${a}`), _.host !== St && _.host !== a && __PRIVATE_logWarn("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used.");
	const u = {
		..._,
		host: a,
		ssl: s,
		emulatorOptions: i
	};
	if (!deepEqual(u, o) && (t._setSettings(u), i.mockUserToken)) {
		let n, r;
		if ("string" == typeof i.mockUserToken) n = i.mockUserToken, r = User.MOCK_USER;
		else {
			n = createMockUserToken(i.mockUserToken, t._app?.options.projectId);
			const s = i.mockUserToken.sub || i.mockUserToken.user_id;
			if (!s) throw new e(ta.INVALID_ARGUMENT, "mockUserToken must contain 'sub' or 'user_id' field!");
			r = new User(s);
		}
		t._authCredentials = new __PRIVATE_EmulatorAuthCredentialsProvider(new __PRIVATE_OAuthToken(n, r));
	}
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A `Query` refers to a query which you can read or listen to. You can also
* construct refined `Query` objects by adding filters and ordering.
*/ var Query = class Query {
	/** @hideconstructor protected */
	constructor(e, t, n) {
		this.converter = t, this._query = n, this.type = "query", this.firestore = e;
	}
	withConverter(e) {
		return new Query(this.firestore, e, this._query);
	}
};
/**
* A `DocumentReference` refers to a document location in a Firestore database
* and can be used to write, read, or listen to the location. The document at
* the referenced location may or may not exist.
*/ var aa = class aa {
	/** @hideconstructor */
	constructor(e, t, n) {
		this.converter = t, this._key = n, this.type = "document", this.firestore = e;
	}
	get _path() {
		return this._key.path;
	}
	/**
	* The document's identifier within its collection.
	*/ get id() {
		return this._key.path.lastSegment();
	}
	/**
	* A string representing the path of the referenced document (relative
	* to the root of the database).
	*/ get path() {
		return this._key.path.canonicalString();
	}
	/**
	* The collection this `DocumentReference` belongs to.
	*/ get parent() {
		return new na(this.firestore, this.converter, this._key.path.popLast());
	}
	withConverter(e) {
		return new aa(this.firestore, e, this._key);
	}
	/**
	* Returns a JSON-serializable representation of this `DocumentReference` instance.
	*
	* @returns a JSON representation of this object.
	*/ toJSON() {
		return {
			type: aa._jsonSchemaVersion,
			referencePath: this._key.toString()
		};
	}
	static fromJSON(e, t, n) {
		if (__PRIVATE_validateJSON(t, aa._jsonSchema)) return new aa(e, n || null, new DocumentKey(ResourcePath.fromString(t.referencePath)));
	}
};
aa._jsonSchemaVersion = "firestore/documentReference/1.0", aa._jsonSchema = {
	type: property("string", aa._jsonSchemaVersion),
	referencePath: property("string")
};
/**
* A `CollectionReference` object can be used for adding documents, getting
* document references, and querying for documents (using {@link (query:1)}).
*/
var na = class na extends Query {
	/** @hideconstructor */
	constructor(e, t, n) {
		super(e, t, __PRIVATE_newQueryForPath(n)), this._path = n, this.type = "collection";
	}
	/** The collection's identifier. */ get id() {
		return this._query.path.lastSegment();
	}
	/**
	* A string representing the path of the referenced collection (relative
	* to the root of the database).
	*/ get path() {
		return this._query.path.canonicalString();
	}
	/**
	* A reference to the containing `DocumentReference` if this is a
	* subcollection. If this isn't a subcollection, the reference is null.
	*/ get parent() {
		const e = this._path.popLast();
		return e.isEmpty() ? null : new aa(this.firestore, null, new DocumentKey(e));
	}
	withConverter(e) {
		return new na(this.firestore, e, this._path);
	}
};
function collection(t, n, ...r) {
	if (t = getModularInstance(t), __PRIVATE_validateNonEmptyArgument("collection", "path", n), t instanceof Dt) {
		const e = ResourcePath.fromString(n, ...r);
		return __PRIVATE_validateCollectionPath(e), new na(t, null, e);
	}
	{
		if (!(t instanceof aa || t instanceof na)) throw new e(ta.INVALID_ARGUMENT, "Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");
		const i = t._path.child(ResourcePath.fromString(n, ...r));
		return __PRIVATE_validateCollectionPath(i), new na(t.firestore, null, i);
	}
}
function doc(t, n, ...r) {
	if (t = getModularInstance(t), 1 === arguments.length && (n = __PRIVATE_AutoId.newId()), __PRIVATE_validateNonEmptyArgument("doc", "path", n), t instanceof Dt) {
		const e = ResourcePath.fromString(n, ...r);
		return __PRIVATE_validateDocumentPath(e), new aa(t, null, new DocumentKey(e));
	}
	{
		if (!(t instanceof aa || t instanceof na)) throw new e(ta.INVALID_ARGUMENT, "Expected first argument to doc() to be a CollectionReference, a DocumentReference or FirebaseFirestore");
		const i = t._path.child(ResourcePath.fromString(n, ...r));
		return __PRIVATE_validateDocumentPath(i), new aa(t.firestore, t instanceof na ? t.converter : null, new DocumentKey(i));
	}
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Returns true iff the array contains the value using strong equality.
*/
/**
* Compares two array for equality using comparator. The method computes the
* intersection and invokes `onAdd` for every element that is in `after` but not
* `before`. `onRemove` is invoked for every element in `before` but missing
* from `after`.
*
* The method creates a copy of both `before` and `after` and runs in O(n log
* n), where n is the size of the two lists.
*
* @param before - The elements that exist in the original array.
* @param after - The elements to diff against the original array.
* @param comparator - The comparator for the elements in before and after.
* @param onAdd - A function to invoke for every element that is part of `
* after` but not `before`.
* @param onRemove - A function to invoke for every element that is part of
* `before` but not `after`.
*/
/**
* @license
* Copyright 2024 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Represents a vector type in Firestore documents.
* Create an instance with <code>{@link vector}</code>.
*/
var n = class n {
	/**
	* @private
	* @internal
	*/
	constructor(e) {
		this._values = (e || []).map(((e) => e));
	}
	/**
	* Returns a copy of the raw number array form of the vector.
	*/ toArray() {
		return this._values.map(((e) => e));
	}
	/**
	* Returns `true` if the two `VectorValue` values have the same raw number arrays, returns `false` otherwise.
	*/ isEqual(e) {
		/**
		* Verifies equality for an array of primitives.
		*
		* @private
		* @internal
		* @param left - Array of primitives.
		* @param right - Array of primitives.
		* @returns True if arrays are equal.
		*/
		return function __PRIVATE_isPrimitiveArrayEqual(e, t) {
			if (e.length !== t.length) return false;
			for (let n = 0; n < e.length; ++n) if (e[n] !== t[n]) return false;
			return true;
		}(this._values, e._values);
	}
	/**
	* Returns a JSON-serializable representation of this `VectorValue` instance.
	*
	* @returns a JSON representation of this object.
	*/ toJSON() {
		return {
			type: n._jsonSchemaVersion,
			vectorValues: this._values
		};
	}
	/**
	* Builds a `VectorValue` instance from a JSON object created by {@link VectorValue.toJSON}.
	*
	* @param json - a JSON object represention of a `VectorValue` instance.
	* @returns an instance of {@link VectorValue} if the JSON object could be parsed. Throws a
	* {@link FirestoreError} if an error occurs.
	*/ static fromJSON(t) {
		if (__PRIVATE_validateJSON(t, n._jsonSchema)) {
			if (Array.isArray(t.vectorValues) && t.vectorValues.every(((e) => "number" == typeof e))) return new n(t.vectorValues);
			throw new e(ta.INVALID_ARGUMENT, "Expected 'vectorValues' field to be a number array");
		}
	}
};
n._jsonSchemaVersion = "firestore/vectorValue/1.0", n._jsonSchema = {
	type: property("string", n._jsonSchemaVersion),
	vectorValues: property("object")
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var xt = /^__.*__$/;
/** The result of parsing document data (e.g. for a setData call). */ var ParsedSetData = class {
	constructor(e, t, n) {
		this.data = e, this.fieldMask = t, this.fieldTransforms = n;
	}
	toMutation(e, t) {
		return null !== this.fieldMask ? new __PRIVATE_PatchMutation(e, this.data, this.fieldMask, t, this.fieldTransforms) : new __PRIVATE_SetMutation(e, this.data, t, this.fieldTransforms);
	}
};
/** The result of parsing "update" data (i.e. for an updateData call). */ var ParsedUpdateData = class {
	constructor(e, t, n) {
		this.data = e, this.fieldMask = t, this.fieldTransforms = n;
	}
	toMutation(e, t) {
		return new __PRIVATE_PatchMutation(e, this.data, this.fieldMask, t, this.fieldTransforms);
	}
};
function __PRIVATE_isWrite(e) {
	switch (e) {
		case 0:
		case 2:
		case 1: return true;
		case 3:
		case 4: return false;
		default: throw l(40011, { dataSource: e });
	}
}
/** A "context" object passed around while parsing user data. */ var ParseContextImpl = class ParseContextImpl {
	/**
	* Initializes a ParseContext with the given source and path.
	*
	* @param settings - The settings for the parser.
	* @param databaseId - The database ID of the Firestore instance.
	* @param serializer - The serializer to use to generate the Value proto.
	* @param ignoreUndefinedProperties - Whether to ignore undefined properties
	* rather than throw.
	* @param fieldTransforms - A mutable list of field transforms encountered
	* while parsing the data.
	* @param fieldMask - A mutable list of field paths encountered while parsing
	* the data.
	*
	* TODO(b/34871131): We don't support array paths right now, so path can be
	* null to indicate the context represents any location within an array (in
	* which case certain features will not work and errors will be somewhat
	* compromised).
	*/
	constructor(e, t, n, r, i, s) {
		this.settings = e, this.databaseId = t, this.serializer = n, this.ignoreUndefinedProperties = r, void 0 === i && this.validatePath(), this.fieldTransforms = i || [], this.fieldMask = s || [];
	}
	get path() {
		return this.settings.path;
	}
	get dataSource() {
		return this.settings.dataSource;
	}
	/** Returns a new context with the specified settings overwritten. */ contextWith(e) {
		return new ParseContextImpl({
			...this.settings,
			...e
		}, this.databaseId, this.serializer, this.ignoreUndefinedProperties, this.fieldTransforms, this.fieldMask);
	}
	childContextForField(e) {
		const t = this.path?.child(e), n = this.contextWith({
			path: t,
			arrayElement: false
		});
		return n.validatePathSegment(e), n;
	}
	childContextForFieldPath(e) {
		const t = this.path?.child(e), n = this.contextWith({
			path: t,
			arrayElement: false
		});
		return n.validatePath(), n;
	}
	childContextForArray(e) {
		return this.contextWith({
			path: void 0,
			arrayElement: true
		});
	}
	createError(e) {
		return createError(e, this.settings.methodName, this.settings.hasConverter || false, this.path, this.settings.targetDoc);
	}
	/** Returns 'true' if 'fieldPath' was traversed when creating this context. */ contains(e) {
		return void 0 !== this.fieldMask.find(((t) => e.isPrefixOf(t))) || void 0 !== this.fieldTransforms.find(((t) => e.isPrefixOf(t.field)));
	}
	validatePath() {
		if (this.path) for (let e = 0; e < this.path.length; e++) this.validatePathSegment(this.path.get(e));
	}
	validatePathSegment(e) {
		if (0 === e.length) throw this.createError("Document fields must not be empty");
		if (__PRIVATE_isWrite(this.dataSource) && xt.test(e)) throw this.createError("Document fields cannot begin and end with \"__\"");
	}
};
/**
* Helper for parsing raw user input (provided via the API) into internal model
* classes.
*/ var UserDataReader = class {
	constructor(e, t, n) {
		this.databaseId = e, this.ignoreUndefinedProperties = t, this.serializer = n || __PRIVATE_newSerializer(e);
	}
	/** Creates a new top-level parse context. */ createContext(e, t, n, r = false) {
		return new ParseContextImpl({
			dataSource: e,
			methodName: t,
			targetDoc: n,
			path: Oe.emptyPath(),
			arrayElement: false,
			hasConverter: r
		}, this.databaseId, this.serializer, this.ignoreUndefinedProperties);
	}
};
function la(e) {
	const t = e._freezeSettings(), n = __PRIVATE_newSerializer(e._databaseId);
	return new UserDataReader(e._databaseId, !!t.ignoreUndefinedProperties, n);
}
/** Parse document data from a set() call. */ function __PRIVATE_parseSetData(t, n, r, i, s, _ = {}) {
	const o = t.createContext(_.merge || _.mergeFields ? 2 : 0, n, r, s);
	__PRIVATE_validatePlainObject("Data must be an object, but it was:", o, i);
	const a = __PRIVATE_parseObject(i, o);
	let u, c;
	if (_.merge) u = new FieldMask(o.fieldMask), c = o.fieldTransforms;
	else if (_.mergeFields) {
		const t = [];
		for (const i of _.mergeFields) {
			const s = K(n, i, r);
			if (!o.contains(s)) throw new e(ta.INVALID_ARGUMENT, `Field '${s}' is specified in your field mask but missing from your input data.`);
			__PRIVATE_fieldMaskContains(t, s) || t.push(s);
		}
		u = new FieldMask(t), c = o.fieldTransforms.filter(((e) => u.covers(e.field)));
	} else u = null, c = o.fieldTransforms;
	return new ParsedSetData(new ObjectValue(a), u, c);
}
var __PRIVATE_DeleteFieldValueImpl = class __PRIVATE_DeleteFieldValueImpl extends FieldValue {
	_toFieldTransform(e) {
		if (2 !== e.dataSource) throw 1 === e.dataSource ? e.createError(`${this._methodName}() can only appear at the top level of your update data`) : e.createError(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);
		return e.fieldMask.push(e.path), null;
	}
	isEqual(e) {
		return e instanceof __PRIVATE_DeleteFieldValueImpl;
	}
};
/** Parse update data from an update() call. */ function __PRIVATE_parseUpdateData(e, t, n, r) {
	const i = e.createContext(1, t, n);
	__PRIVATE_validatePlainObject("Data must be an object, but it was:", i, r);
	const s = [], _ = ObjectValue.empty();
	forEach(r, ((e, r) => {
		const o = __PRIVATE_fieldPathFromDotSeparatedString(t, e, n);
		r = getModularInstance(r);
		const a = i.childContextForFieldPath(o);
		if (r instanceof __PRIVATE_DeleteFieldValueImpl) s.push(o);
		else {
			const e = __PRIVATE_parseData(r, a);
			null != e && (s.push(o), _.set(o, e));
		}
	}));
	return new ParsedUpdateData(_, new FieldMask(s), i.fieldTransforms);
}
/** Parse update data from a list of field/value arguments. */ function __PRIVATE_parseUpdateVarargs(t, n, r, i, s, _) {
	const o = t.createContext(1, n, r), a = [K(n, i, r)], u = [s];
	if (_.length % 2 != 0) throw new e(ta.INVALID_ARGUMENT, `Function ${n}() needs to be called with an even number of arguments that alternate between field names and values.`);
	for (let e = 0; e < _.length; e += 2) a.push(K(n, _[e])), u.push(_[e + 1]);
	const c = [], l = ObjectValue.empty();
	for (let e = a.length - 1; e >= 0; --e) if (!__PRIVATE_fieldMaskContains(c, a[e])) {
		const t = a[e];
		let n = u[e];
		n = getModularInstance(n);
		const r = o.childContextForFieldPath(t);
		if (n instanceof __PRIVATE_DeleteFieldValueImpl) c.push(t);
		else {
			const e = __PRIVATE_parseData(n, r);
			null != e && (c.push(t), l.set(t, e));
		}
	}
	return new ParsedUpdateData(l, new FieldMask(c), o.fieldTransforms);
}
/**
* Parses user data to Protobuf Values.
*
* @param input - Data to be parsed.
* @param context - A context object representing the current path being parsed,
* the source of the data being parsed, etc.
* @returns The parsed value, or null if the value was a FieldValue sentinel
* that should not be included in the resulting parsed data.
*/ function __PRIVATE_parseData(e, t, r) {
	if (__PRIVATE_looksLikeJsonObject(e = getModularInstance(e))) return __PRIVATE_validatePlainObject("Unsupported field value:", t, e), __PRIVATE_parseObject(e, t);
	if (e instanceof FieldValue)
 /**
	* "Parses" the provided FieldValueImpl, adding any necessary transforms to
	* context.fieldTransforms.
	*/
	return function __PRIVATE_parseSentinelFieldValue(e, t) {
		if (!__PRIVATE_isWrite(t.dataSource)) throw t.createError(`${e._methodName}() can only be used with update() and set()`);
		if (!t.path) throw t.createError(`${e._methodName}() is not currently supported inside arrays`);
		const n = e._toFieldTransform(t);
		n && t.fieldTransforms.push(n);
	}(e, t), null;
	if (void 0 === e && t.ignoreUndefinedProperties) return null;
	if (t.path && t.fieldMask.push(t.path), e instanceof Array) {
		if (t.settings.arrayElement && 4 !== t.dataSource) throw t.createError("Nested arrays are not supported");
		return function __PRIVATE_parseArray(e, t) {
			const n = [];
			let r = 0;
			for (const i of e) {
				let e = __PRIVATE_parseData(i, t.childContextForArray(r));
				e ??= { nullValue: "NULL_VALUE" }, n.push(e), r++;
			}
			return { arrayValue: { values: n } };
		}(e, t);
	}
	return function __PRIVATE_parseScalarValue(e, t, r) {
		if (null === (e = getModularInstance(e))) return { nullValue: "NULL_VALUE" };
		if ("number" == typeof e) return toNumber(t.serializer, e);
		if ("boolean" == typeof e) return { booleanValue: e };
		if ("string" == typeof e) return { stringValue: e };
		if (e instanceof Date) {
			const n = Timestamp.fromDate(e);
			return { timestampValue: toTimestamp(t.serializer, n) };
		}
		if (e instanceof Timestamp) {
			const n = new Timestamp(e.seconds, 1e3 * Math.floor(e.nanoseconds / 1e3));
			return { timestampValue: toTimestamp(t.serializer, n) };
		}
		if (__PRIVATE_isTemporalInstant(e)) {
			const n = Timestamp.fromInstant(e), r = new Timestamp(n.seconds, 1e3 * Math.floor(n.nanoseconds / 1e3));
			return { timestampValue: toTimestamp(t.serializer, r) };
		}
		if (e instanceof GeoPoint) return { geoPointValue: {
			latitude: e.latitude,
			longitude: e.longitude
		} };
		if (e instanceof Bytes) return { bytesValue: __PRIVATE_toBytes(t.serializer, e._byteString) };
		if (e instanceof aa) {
			const n = t.databaseId, r = e.firestore._databaseId;
			if (!r.isEqual(n)) throw t.createError(`Document reference is for database ${r.projectId}/${r.database} but should be for database ${n.projectId}/${n.database}`);
			return { referenceValue: __PRIVATE_toResourceName(e.firestore._databaseId || t.databaseId, e._key.path) };
		}
		if (e instanceof n)
 /**
		* Creates a new VectorValue proto value (using the internal format).
		*/
		return function __PRIVATE_parseVectorValue(e, t) {
			const r = e instanceof n ? e.toArray() : e;
			return { mapValue: { fields: {
				[Qe]: { stringValue: ze },
				[je]: { arrayValue: { values: r.map(((e) => {
					if ("number" != typeof e) throw t.createError("VectorValues must only contain numeric values.");
					return __PRIVATE_toDouble(t.serializer, e);
				})) } }
			} } };
		}(e, t);
		if (__PRIVATE_isProtoValueSerializable(e)) return e._toProto(t.serializer);
		throw t.createError(`Unsupported field value: ${__PRIVATE_valueDescription(e)}`);
	}(e, t);
}
function __PRIVATE_parseObject(e, t) {
	const n = {};
	return isEmpty(e) ? t.path && t.path.length > 0 && t.fieldMask.push(t.path) : forEach(e, ((e, r) => {
		const i = __PRIVATE_parseData(r, t.childContextForField(e));
		null != i && (n[e] = i);
	})), { mapValue: { fields: n } };
}
function __PRIVATE_isTemporalInstant(e) {
	if ("object" != typeof e || null === e) return false;
	if ("undefined" != typeof Temporal && "function" == typeof Temporal.Instant) {
		if (e instanceof Temporal.Instant) return true;
	}
	const t = e;
	return "Temporal.Instant" === t[Symbol.toStringTag] && "bigint" == typeof t.t;
}
function __PRIVATE_looksLikeJsonObject(e) {
	return !("object" != typeof e || null === e || e instanceof Array || e instanceof Date || e instanceof Timestamp || e instanceof GeoPoint || e instanceof Bytes || e instanceof aa || e instanceof FieldValue || e instanceof n || __PRIVATE_isTemporalInstant(e) || __PRIVATE_isProtoValueSerializable(e));
}
function __PRIVATE_validatePlainObject(e, t, n) {
	if (!__PRIVATE_looksLikeJsonObject(n) || !p(n)) {
		const r = __PRIVATE_valueDescription(n);
		throw "an object" === r ? t.createError(e + " a custom object") : t.createError(e + " " + r);
	}
}
/**
* Helper that calls fromDotSeparatedString() but wraps any error thrown.
*/ function K(e, t, n) {
	if ((t = getModularInstance(t)) instanceof FieldPath) return t._internalPath;
	if ("string" == typeof t) return __PRIVATE_fieldPathFromDotSeparatedString(e, t);
	throw createError("Field path arguments must be of type string or ", e, false, void 0, n);
}
/**
* Matches any characters in a field path string that are reserved.
*/ var Ct = /* @__PURE__ */ new RegExp("[~\\*/\\[\\]]");
/**
* Wraps fromDotSeparatedString with an error message about the method that
* was thrown.
* @param methodName - The publicly visible method name
* @param path - The dot-separated string form of a field path which will be
* split on dots.
* @param targetDoc - The document against which the field path will be
* evaluated.
*/ function __PRIVATE_fieldPathFromDotSeparatedString(e, t, n) {
	if (t.search(Ct) >= 0) throw createError(`Invalid field path (${t}). Paths must not contain '~', '*', '/', '[', or ']'`, e, false, void 0, n);
	try {
		return new FieldPath(...t.split("."))._internalPath;
	} catch (r) {
		throw createError(`Invalid field path (${t}). Paths must not be empty, begin with '.', end with '.', or contain '..'`, e, false, void 0, n);
	}
}
function createError(t, n, r, i, s) {
	const _ = i && !i.isEmpty(), o = void 0 !== s;
	let a = `Function ${n}() called with invalid data`;
	r && (a += " (via `toFirestore()`)"), a += ". ";
	let u = "";
	return (_ || o) && (u += " (found", _ && (u += ` in field ${i}`), o && (u += ` in document ${s}`), u += ")"), new e(ta.INVALID_ARGUMENT, a + t + u);
}
/** Checks `haystack` if FieldPath `needle` is present. Runs in O(n). */ function __PRIVATE_fieldMaskContains(e, t) {
	return e.some(((e) => e.isEqual(t)));
}
function __PRIVATE_isUserData(e) {
	return "function" == typeof e._readUserData;
}
/**
* @license
* Copyright 2025 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var OptionsUtil = class OptionsUtil {
	constructor(e) {
		this.optionDefinitions = e;
	}
	_getKnownOptions(e, t) {
		const n = ObjectValue.empty();
		for (const r in this.optionDefinitions) if (this.optionDefinitions.hasOwnProperty(r)) {
			const i = this.optionDefinitions[r];
			if (r in e) {
				const s = e[r];
				let _;
				if (i.nestedOptions && p(s)) _ = { mapValue: { fields: new OptionsUtil(i.nestedOptions).getOptionsProto(t, s) } };
				else s && (_ = __PRIVATE_parseData(s, t) ?? void 0);
				_ && n.set(Oe.fromServerFormat(i.serverName), _);
			}
		}
		return n;
	}
	getOptionsProto(e, t, n) {
		const r = this._getKnownOptions(t, e);
		if (n) {
			const t = new Map(__PRIVATE_mapToArray(n, ((t, n) => [Oe.fromServerFormat(n), void 0 !== t ? __PRIVATE_parseData(t, e) : null])));
			r.setAll(t);
		}
		return r.value.mapValue.fields ?? {};
	}
};
/**
* @license
* Copyright 2024 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function u(e) {
	return "object" == typeof e && null !== e && !!("nullValue" in e && (null === e.nullValue || "NULL_VALUE" === e.nullValue) || "booleanValue" in e && (null === e.booleanValue || "boolean" == typeof e.booleanValue) || "integerValue" in e && (null === e.integerValue || "number" == typeof e.integerValue || "string" == typeof e.integerValue) || "doubleValue" in e && (null === e.doubleValue || "number" == typeof e.doubleValue) || "timestampValue" in e && (null === e.timestampValue || function __PRIVATE_isITimestamp(e) {
		return "object" == typeof e && null !== e && "seconds" in e && (null === e.seconds || "number" == typeof e.seconds || "string" == typeof e.seconds) && "nanos" in e && (null === e.nanos || "number" == typeof e.nanos);
	}(e.timestampValue)) || "stringValue" in e && (null === e.stringValue || "string" == typeof e.stringValue) || "bytesValue" in e && (null === e.bytesValue || e.bytesValue instanceof Uint8Array) || "referenceValue" in e && (null === e.referenceValue || "string" == typeof e.referenceValue) || "geoPointValue" in e && (null === e.geoPointValue || function __PRIVATE_isILatLng(e) {
		return "object" == typeof e && null !== e && "latitude" in e && (null === e.latitude || "number" == typeof e.latitude) && "longitude" in e && (null === e.longitude || "number" == typeof e.longitude);
	}(e.geoPointValue)) || "arrayValue" in e && (null === e.arrayValue || function __PRIVATE_isIArrayValue(e) {
		return "object" == typeof e && null !== e && !(!("values" in e) || null !== e.values && !Array.isArray(e.values));
	}(e.arrayValue)) || "mapValue" in e && (null === e.mapValue || function __PRIVATE_isIMapValue(e) {
		return "object" == typeof e && null !== e && !(!("fields" in e) || null !== e.fields && !p(e.fields));
	}(e.mapValue)) || "fieldReferenceValue" in e && (null === e.fieldReferenceValue || "string" == typeof e.fieldReferenceValue) || "functionValue" in e && (null === e.functionValue || function __PRIVATE_isIFunction(e) {
		return "object" == typeof e && null !== e && !(!("name" in e) || null !== e.name && "string" != typeof e.name || !("args" in e) || null !== e.args && !Array.isArray(e.args));
	}(e.functionValue)) || "pipelineValue" in e && (null === e.pipelineValue || function __PRIVATE_isIPipeline(e) {
		return "object" == typeof e && null !== e && !(!("stages" in e) || null !== e.stages && !Array.isArray(e.stages));
	}(e.pipelineValue)));
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Creates a new `VectorValue` constructed with a copy of the given array of numbers.
*
* @param values - Create a `VectorValue` instance with a copy of this array of numbers.
*
* @returns A new `VectorValue` constructed with a copy of the given array of numbers.
*/ function r(e) {
	return new n(e);
}
/**
* @license
* Copyright 2024 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Converts a value to an Expression, Returning either a Constant, MapFunction,
* ArrayFunction, or the input itself (if it's already an expression).
*
* @private
* @internal
* @param value
*/ function __PRIVATE_valueToDefaultExpr(e) {
	let n;
	return e instanceof t ? e : (n = p(e) ? __PRIVATE__map(e) : e instanceof Array ? b(e) : m(e, void 0), n);
}
/**
* Converts a value to an Expression, Returning either a Constant, MapFunction,
* ArrayFunction, or the input itself (if it's already an expression).
*
* @private
* @internal
* @param value
*/ function __PRIVATE_vectorToExpr(e) {
	if (e instanceof t) return e;
	if (e instanceof n) return i(e);
	if (Array.isArray(e)) return i(r(e));
	throw new Error("Unsupported value: " + typeof e);
}
/**
* Converts a value to an Expression, Returning either a Constant, MapFunction,
* ArrayFunction, or the input itself (if it's already an expression).
* If the input is a string, it is assumed to be a field name, and a
* field(value) is returned.
*
* @private
* @internal
* @param value
*/ function __PRIVATE_fieldOrExpression(e) {
	if (__PRIVATE_isString$1(e)) return s(e);
	return __PRIVATE_valueToDefaultExpr(e);
}
/**
*
* Represents an expression that can be evaluated to a value within the execution of a {@link
* @firebase/firestore/pipelines#Pipeline}.
*
* Expressions are the building blocks for creating complex queries and transformations in
* Firestore pipelines. They can represent:
*
* - **Field references:** Access values from document fields.
* - **Literals:** Represent constant values (strings, numbers, booleans).
* - **Function calls:** Apply functions to one or more expressions.
*
* The `Expression` class provides a fluent API for building expressions. You can chain together
* method calls to create complex expressions.
*/ var t = class {
	constructor() {
		this._protoValueType = "ProtoValue";
	}
	/**
	* Creates an expression that adds this expression to another expression.
	*
	* @example
	* ```typescript
	* // Add the value of the 'quantity' field and the 'reserve' field.
	* field("quantity").add(field("reserve"));
	* ```
	*
	* @param second - The expression or literal to add to this expression.
	* @param others - Optional additional expressions or literals to add to this expression.
	* @returns A new `Expression` representing the addition operation.
	*/ add(e) {
		return new y("add", [this, __PRIVATE_valueToDefaultExpr(e)], "add");
	}
	/**
	* Wraps the expression in a [BooleanExpression].
	*
	* @returns A [BooleanExpression] representing the same expression.
	*/ asBoolean() {
		if (this instanceof BooleanExpression) return this;
		if (this instanceof Constant) return new __PRIVATE_BooleanConstant(this);
		if (this instanceof o) return new __PRIVATE_BooleanField(this);
		if (this instanceof y) return new __PRIVATE_BooleanFunctionExpression(this);
		throw new e("invalid-argument", `Conversion of type ${typeof this} to BooleanExpression not supported.`);
	}
	subtract(e) {
		return new y("subtract", [this, __PRIVATE_valueToDefaultExpr(e)], "subtract");
	}
	/**
	* Creates an expression that multiplies this expression by another expression.
	*
	* @example
	* ```typescript
	* // Multiply the 'quantity' field by the 'price' field
	* field("quantity").multiply(field("price"));
	* ```
	*
	* @param second - The second expression or literal to multiply by.
	* @param others - Optional additional expressions or literals to multiply by.
	* @returns A new `Expression` representing the multiplication operation.
	*/ multiply(e) {
		return new y("multiply", [this, __PRIVATE_valueToDefaultExpr(e)], "multiply");
	}
	divide(e) {
		return new y("divide", [this, __PRIVATE_valueToDefaultExpr(e)], "divide");
	}
	mod(e) {
		return new y("mod", [this, __PRIVATE_valueToDefaultExpr(e)], "mod");
	}
	equal(e) {
		return new y("equal", [this, __PRIVATE_valueToDefaultExpr(e)], "equal").asBoolean();
	}
	notEqual(e) {
		return new y("not_equal", [this, __PRIVATE_valueToDefaultExpr(e)], "notEqual").asBoolean();
	}
	lessThan(e) {
		return new y("less_than", [this, __PRIVATE_valueToDefaultExpr(e)], "lessThan").asBoolean();
	}
	lessThanOrEqual(e) {
		return new y("less_than_or_equal", [this, __PRIVATE_valueToDefaultExpr(e)], "lessThanOrEqual").asBoolean();
	}
	greaterThan(e) {
		return new y("greater_than", [this, __PRIVATE_valueToDefaultExpr(e)], "greaterThan").asBoolean();
	}
	greaterThanOrEqual(e) {
		return new y("greater_than_or_equal", [this, __PRIVATE_valueToDefaultExpr(e)], "greaterThanOrEqual").asBoolean();
	}
	/**
	* Creates an expression that concatenates an array expression with one or more other arrays.
	*
	* @example
	* ```typescript
	* // Combine the 'items' array with another array field.
	* field("items").arrayConcat(field("otherItems"));
	* ```
	* @param secondArray - Second array expression or array literal to concatenate.
	* @param otherArrays - Optional additional array expressions or array literals to concatenate.
	* @returns A new `Expression` representing the concatenated array.
	*/ arrayConcat(e, ...t) {
		const n = [e, ...t].map(((e) => __PRIVATE_valueToDefaultExpr(e)));
		return new y("array_concat", [this, ...n], "arrayConcat");
	}
	arrayContains(e) {
		return new y("array_contains", [this, __PRIVATE_valueToDefaultExpr(e)], "arrayContains").asBoolean();
	}
	arrayContainsAll(e) {
		const t = Array.isArray(e) ? new __PRIVATE_ListOfExprs(e.map(__PRIVATE_valueToDefaultExpr), "arrayContainsAll") : e;
		return new y("array_contains_all", [this, t], "arrayContainsAll").asBoolean();
	}
	arrayContainsAny(e) {
		const t = Array.isArray(e) ? new __PRIVATE_ListOfExprs(e.map(__PRIVATE_valueToDefaultExpr), "arrayContainsAny") : e;
		return new y("array_contains_any", [this, t], "arrayContainsAny").asBoolean();
	}
	/**
	* Creates an expression that reverses an array.
	*
	* @example
	* ```typescript
	* // Reverse the value of the 'myArray' field.
	* field("myArray").arrayReverse();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the reversed array.
	*/ arrayReverse() {
		return new y("array_reverse", [this]);
	}
	/**
	* Creates an expression that calculates the length of an array.
	*
	* @example
	* ```typescript
	* // Get the number of items in the 'cart' array
	* field("cart").arrayLength();
	* ```
	*
	* @returns A new `Expression` representing the length of the array.
	*/ arrayLength() {
		return new y("array_length", [this], "arrayLength");
	}
	equalAny(e) {
		const t = Array.isArray(e) ? new __PRIVATE_ListOfExprs(e.map(__PRIVATE_valueToDefaultExpr), "equalAny") : e;
		return new y("equal_any", [this, t], "equalAny").asBoolean();
	}
	notEqualAny(e) {
		const t = Array.isArray(e) ? new __PRIVATE_ListOfExprs(e.map(__PRIVATE_valueToDefaultExpr), "notEqualAny") : e;
		return new y("not_equal_any", [this, t], "notEqualAny").asBoolean();
	}
	/**
	* Creates an expression that checks if a field exists in the document.
	*
	* @example
	* ```typescript
	* // Check if the document has a field named "phoneNumber"
	* field("phoneNumber").exists();
	* ```
	*
	* @returns A new `Expression` representing the 'exists' check.
	*/ exists() {
		return new y("exists", [this], "exists").asBoolean();
	}
	/**
	* Creates an expression that calculates the character length of a string in UTF-8.
	*
	* @example
	* ```typescript
	* // Get the character length of the 'name' field in its UTF-8 form.
	* field("name").charLength();
	* ```
	*
	* @returns A new `Expression` representing the length of the string.
	*/ charLength() {
		return new y("char_length", [this], "charLength");
	}
	like(e) {
		return new y("like", [this, __PRIVATE_valueToDefaultExpr(e)], "like").asBoolean();
	}
	regexContains(e) {
		return new y("regex_contains", [this, __PRIVATE_valueToDefaultExpr(e)], "regexContains").asBoolean();
	}
	regexFind(e) {
		return new y("regex_find", [this, __PRIVATE_valueToDefaultExpr(e)], "regexFind");
	}
	regexFindAll(e) {
		return new y("regex_find_all", [this, __PRIVATE_valueToDefaultExpr(e)], "regexFindAll");
	}
	regexMatch(e) {
		return new y("regex_match", [this, __PRIVATE_valueToDefaultExpr(e)], "regexMatch").asBoolean();
	}
	stringContains(e) {
		return new y("string_contains", [this, __PRIVATE_valueToDefaultExpr(e)], "stringContains").asBoolean();
	}
	startsWith(e) {
		return new y("starts_with", [this, __PRIVATE_valueToDefaultExpr(e)], "startsWith").asBoolean();
	}
	endsWith(e) {
		return new y("ends_with", [this, __PRIVATE_valueToDefaultExpr(e)], "endsWith").asBoolean();
	}
	/**
	* Creates an expression that converts a string to lowercase.
	*
	* @example
	* ```typescript
	* // Convert the 'name' field to lowercase
	* field("name").toLower();
	* ```
	*
	* @returns A new `Expression` representing the lowercase string.
	*/ toLower() {
		return new y("to_lower", [this], "toLower");
	}
	/**
	* Creates an expression that converts a string to uppercase.
	*
	* @example
	* ```typescript
	* // Convert the 'title' field to uppercase
	* field("title").toUpper();
	* ```
	*
	* @returns A new `Expression` representing the uppercase string.
	*/ toUpper() {
		return new y("to_upper", [this], "toUpper");
	}
	/**
	* Creates an expression that removes leading and trailing characters from a string or byte array.
	*
	* @example
	* ```typescript
	* // Trim whitespace from the 'userInput' field
	* field("userInput").trim();
	*
	* // Trim quotes from the 'userInput' field
	* field("userInput").trim('"');
	* ```
	* @param valueToTrim - Optional This parameter is treated as a set of characters or bytes that will be
	* trimmed from the input. If not specified, then whitespace will be trimmed.
	* @returns A new `Expression` representing the trimmed string or byte array.
	*/ trim(e) {
		const t = [this];
		return e && t.push(__PRIVATE_valueToDefaultExpr(e)), new y("trim", t, "trim");
	}
	/**
	* Trims whitespace or a specified set of characters/bytes from the beginning of a string or byte array.
	*
	* @example
	* ```typescript
	* // Trim whitespace from the beginning of the 'userInput' field
	* field("userInput").ltrim();
	*
	* // Trim quotes from the beginning of the 'userInput' field
	* field("userInput").ltrim('"');
	* ```
	*
	* @param valueToTrim - Optional. A string or byte array containing the characters/bytes to trim.
	* If not specified, whitespace will be trimmed.
	* @returns A new `Expression` representing the trimmed string.
	*/ ltrim(e) {
		const t = [this];
		return e && t.push(__PRIVATE_valueToDefaultExpr(e)), new y("ltrim", t, "ltrim");
	}
	/**
	* Trims whitespace or a specified set of characters/bytes from the end of a string or byte array.
	*
	* @example
	* ```typescript
	* // Trim whitespace from the end of the 'userInput' field
	* field("userInput").rtrim();
	*
	* // Trim quotes from the end of the 'userInput' field
	* field("userInput").rtrim('"');
	* ```
	*
	* @param valueToTrim - Optional. A string or byte array containing the characters/bytes to trim.
	* If not specified, whitespace will be trimmed.
	* @returns A new `Expression` representing the trimmed string or byte array.
	*/ rtrim(e) {
		const t = [this];
		return e && t.push(__PRIVATE_valueToDefaultExpr(e)), new y("rtrim", t, "rtrim");
	}
	/**
	* Creates an expression that returns the data type of this expression's result, as a string.
	*
	* @remarks
	* This is evaluated on the backend. This means:
	* 1. Generic typed elements (like `array<string>`) evaluate strictly to the primitive `'array'`.
	* 2. Any custom `FirestoreDataConverter` mappings are ignored.
	* 3. For numeric values, the backend does not yield the JavaScript `"number"` type; it evaluates
	*    precisely as `"int64"` or `"float64"`.
	* 4. For date or timestamp objects, the backend evaluates to `"timestamp"`.
	*
	* @example
	* ```typescript
	* // Get the data type of the value in field 'title'
	* field('title').type()
	* ```
	*
	* @returns A new `Expression` representing the data type.
	*/ type() {
		return new y("type", [this]);
	}
	/**
	* Creates an expression that checks if the result of this expression is of the given type.
	*
	* @remarks Null or undefined fields evaluate to skip/error. Use `ifAbsent()` / `isAbsent()` to evaluate missing data.
	* Supported values for `type` are:
	* `'null'`, `'array'`, `'boolean'`, `'bytes'`, `'timestamp'`, `'geo_point'`, `'number'`,
	* `'int32'`, `'int64'`, `'float64'`, `'decimal128'`, `'map'`, `'reference'`, `'string'`,
	* `'vector'`, `'max_key'`, `'min_key'`, `'object_id'`, `'regex'`, `'request_timestamp'`.
	*
	* @example
	* ```typescript
	* // Check if the 'price' field is specifically an integer (not just 'number')
	* field('price').isType('int64');
	* ```
	*
	* @param type - The type to check for.
	* @returns A new `BooleanExpression` that evaluates to true if the expression's result is of the given type, false otherwise.
	*/ isType(e) {
		return new y("is_type", [this, i(e)], "isType").asBoolean();
	}
	/**
	* Creates an expression that concatenates string expressions together.
	*
	* @example
	* ```typescript
	* // Combine the 'firstName', " ", and 'lastName' fields into a single string
	* field("firstName").stringConcat(constant(" "), field("lastName"));
	* ```
	*
	* @param secondString - The additional expression or string literal to concatenate.
	* @param otherStrings - Optional additional expressions or string literals to concatenate.
	* @returns A new `Expression` representing the concatenated string.
	*/ stringConcat(e, ...t) {
		const n = [e, ...t].map(__PRIVATE_valueToDefaultExpr);
		return new y("string_concat", [this, ...n], "stringConcat");
	}
	/**
	* Creates an expression that finds the index of the first occurrence of a substring or byte sequence.
	*
	* @example
	* ```typescript
	* // Find the index of "foo" in the 'text' field
	* field("text").stringIndexOf("foo");
	* ```
	*
	* @param search - The substring or byte sequence to search for.
	* @returns A new `Expression` representing the index of the first occurrence.
	*/ stringIndexOf(e) {
		return new y("string_index_of", [this, __PRIVATE_valueToDefaultExpr(e)], "stringIndexOf");
	}
	/**
	* Creates an expression that repeats a string or byte array a specified number of times.
	*
	* @example
	* ```typescript
	* // Repeat the 'label' field 3 times
	* field("label").stringRepeat(3);
	* ```
	*
	* @param repetitions - The number of times to repeat the string or byte array.
	* @returns A new `Expression` representing the repeated string or byte array.
	*/ stringRepeat(e) {
		return new y("string_repeat", [this, __PRIVATE_valueToDefaultExpr(e)], "stringRepeat");
	}
	/**
	* Creates an expression that replaces all occurrences of a substring or byte sequence with a replacement.
	*
	* @example
	* ```typescript
	* // Replace all occurrences of "foo" with "bar" in the 'text' field
	* field("text").stringReplaceAll("foo", "bar");
	* ```
	*
	* @param find - The substring or byte sequence to search for.
	* @param replacement - The replacement string or byte sequence.
	* @returns A new `Expression` representing the string or byte array with replacements.
	*/ stringReplaceAll(e, t) {
		return new y("string_replace_all", [
			this,
			__PRIVATE_valueToDefaultExpr(e),
			__PRIVATE_valueToDefaultExpr(t)
		], "stringReplaceAll");
	}
	/**
	* Creates an expression that replaces the first occurrence of a substring or byte sequence with a replacement.
	*
	* @example
	* ```typescript
	* // Replace the first occurrence of "foo" with "bar" in the 'text' field
	* field("text").stringReplaceOne("foo", "bar");
	* ```
	*
	* @param find - The substring or byte sequence to search for.
	* @param replacement - The replacement string or byte sequence.
	* @returns A new `Expression` representing the string or byte array with the replacement.
	*/ stringReplaceOne(e, t) {
		return new y("string_replace_one", [
			this,
			__PRIVATE_valueToDefaultExpr(e),
			__PRIVATE_valueToDefaultExpr(t)
		], "stringReplaceOne");
	}
	/**
	* Creates an expression that concatenates expression results together.
	*
	* @example
	* ```typescript
	* // Combine the 'firstName', ' ', and 'lastName' fields into a single value.
	* field("firstName").concat(constant(" "), field("lastName"));
	* ```
	*
	* @param second - The additional expression or literal to concatenate.
	* @param others - Optional additional expressions or literals to concatenate.
	* @returns A new `Expression` representing the concatenated value.
	*/ concat(e, ...t) {
		const n = [e, ...t].map(__PRIVATE_valueToDefaultExpr);
		return new y("concat", [this, ...n], "concat");
	}
	/**
	* Creates an expression that reverses this string expression.
	*
	* @example
	* ```typescript
	* // Reverse the value of the 'myString' field.
	* field("myString").reverse();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the reversed string.
	*/ reverse() {
		return new y("reverse", [this], "reverse");
	}
	/**
	* Filters the array using a provided alias and predicate expression.
	*
	* @example
	* ```typescript
	* // Filter the 'items' array to only include those where the 'price' is greater than 10
	* field("items").arrayFilter('item', greaterThan(variable('item.price'), 10));
	* ```
	*
	* @param alias - The variable name to use for each element.
	* @param filter - The predicate boolean expression to filter by.
	* @returns A new `Expression` representing the filtered array.
	*/ arrayFilter(e, t) {
		return new y("array_filter", [
			this,
			__PRIVATE_valueToDefaultExpr(e),
			t
		], "arrayFilter");
	}
	/**
	* Creates an expression that applies a provided transformation to each element in an array.
	*
	* @example
	* ```typescript
	* // Transform the 'scores' array by multiplying each score by 10
	* field("scores").arrayTransform("score", multiply(variable("score"), 10));
	* ```
	*
	* @param elementAlias - The variable name to use for each element.
	* @param transform - The lambda expression used to transform the elements.
	* @returns A new `Expression` representing the arrayTransform operation.
	*/ arrayTransform(e, t) {
		return new y("array_transform", [
			this,
			__PRIVATE_valueToDefaultExpr(e),
			t
		], "arrayTransform");
	}
	/**
	* Creates an expression that applies a provided transformation to each element in an array, providing the element's index to the transformation expression.
	*
	* @example
	* ```typescript
	* // Transform the 'scores' array by adding the index to each score
	* field("scores").arrayTransformWithIndex("score", "i", add(variable("score"), variable("i")));
	* ```
	*
	* @param elementAlias - The variable name to use for each element.
	* @param indexAlias - The variable name to use for the current index.
	* @param transform - The lambda expression used to transform the elements.
	* @returns A new `Expression` representing the arrayTransformWithIndex operation.
	*/ arrayTransformWithIndex(e, t, n) {
		return new y("array_transform", [
			this,
			__PRIVATE_valueToDefaultExpr(e),
			__PRIVATE_valueToDefaultExpr(t),
			n
		], "arrayTransformWithIndex");
	}
	/**
	* Returns a subset of the array.
	*
	* @example
	* ```typescript
	* // Get 5 elements from the 'items' array starting from index 2
	* field("items").arraySlice(2, 5);
	*
	* // Get n number of elements from the 'items' array starting from index 2
	* field("items").arraySlice(2, field("count"));
	* ```
	*
	* @param offset - The starting offset.
	* @param length - The optional length of the slice.
	* @returns A new `Expression` representing the sliced array.
	*/ arraySlice(e, t) {
		const n = [this, __PRIVATE_valueToDefaultExpr(e)];
		return void 0 !== t && n.push(__PRIVATE_valueToDefaultExpr(t)), new y("array_slice", n, "arraySlice");
	}
	/**
	* Returns the first element of the array.
	*
	* @example
	* ```typescript
	* // Get the first element of the 'myArray' field.
	* field("myArray").arrayFirst();
	* ```
	*
	* @returns A new `Expression` representing the first element.
	*/ arrayFirst() {
		return new y("array_first", [this], "arrayFirst");
	}
	arrayFirstN(e) {
		return new y("array_first_n", [this, __PRIVATE_valueToDefaultExpr(e)], "arrayFirstN");
	}
	/**
	* Returns the last element of the array.
	*
	* @example
	* ```typescript
	* // Get the last element of the 'myArray' field.
	* field("myArray").arrayLast();
	* ```
	*
	* @returns A new `Expression` representing the last element.
	*/ arrayLast() {
		return new y("array_last", [this], "arrayLast");
	}
	arrayLastN(e) {
		return new y("array_last_n", [this, __PRIVATE_valueToDefaultExpr(e)], "arrayLastN");
	}
	/**
	* Returns the maximum value in the array.
	*
	* @example
	* ```typescript
	* // Get the maximum value of the 'myArray' field.
	* field("myArray").arrayMaximum();
	* ```
	*
	* @returns A new `Expression` representing the maximum value.
	*/ arrayMaximum() {
		return new y("maximum", [this], "arrayMaximum");
	}
	arrayMaximumN(e) {
		return new y("maximum_n", [this, __PRIVATE_valueToDefaultExpr(e)], "arrayMaximumN");
	}
	/**
	* Returns the minimum value in the array.
	*
	* @example
	* ```typescript
	* // Get the minimum value of the 'myArray' field.
	* field("myArray").arrayMinimum();
	* ```
	*
	* @returns A new `Expression` representing the minimum value.
	*/ arrayMinimum() {
		return new y("minimum", [this], "arrayMinimum");
	}
	arrayMinimumN(e) {
		return new y("minimum_n", [this, __PRIVATE_valueToDefaultExpr(e)], "arrayMinimumN");
	}
	arrayIndexOf(e) {
		return new y("array_index_of", [
			this,
			__PRIVATE_valueToDefaultExpr(e),
			__PRIVATE_valueToDefaultExpr("first")
		], "arrayIndexOf");
	}
	arrayLastIndexOf(e) {
		return new y("array_index_of", [
			this,
			__PRIVATE_valueToDefaultExpr(e),
			__PRIVATE_valueToDefaultExpr("last")
		], "arrayLastIndexOf");
	}
	arrayIndexOfAll(e) {
		return new y("array_index_of_all", [this, __PRIVATE_valueToDefaultExpr(e)], "arrayIndexOfAll");
	}
	/**
	* Creates an expression that calculates the length of this string expression in bytes.
	*
	* @example
	* ```typescript
	* // Calculate the length of the 'myString' field in bytes.
	* field("myString").byteLength();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the length of the string in bytes.
	*/ byteLength() {
		return new y("byte_length", [this], "byteLength");
	}
	/**
	* Creates an expression that computes the ceiling of a numeric value.
	*
	* @example
	* ```typescript
	* // Compute the ceiling of the 'price' field.
	* field("price").ceil();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the ceiling of the numeric value.
	*/ ceil() {
		return new y("ceil", [this]);
	}
	/**
	* Creates an expression that computes the floor of a numeric value.
	*
	* @example
	* ```typescript
	* // Compute the floor of the 'price' field.
	* field("price").floor();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the floor of the numeric value.
	*/ floor() {
		return new y("floor", [this]);
	}
	/**
	* Creates an expression that computes the absolute value of a numeric value.
	*
	* @example
	* ```typescript
	* // Compute the absolute value of the 'price' field.
	* field("price").abs();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the absolute value of the numeric value.
	*/ abs() {
		return new y("abs", [this]);
	}
	/**
	* Creates an expression that computes e to the power of this expression.
	*
	* @example
	* ```typescript
	* // Compute e to the power of the 'value' field.
	* field("value").exp();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the exp of the numeric value.
	*/ exp() {
		return new y("exp", [this]);
	}
	/**
	* Accesses a value from a map (object) field using the provided key.
	*
	* @example
	* ```typescript
	* // Get the 'city' value from the 'address' map field
	* field("address").mapGet("city");
	* ```
	*
	* @param subfield - The key to access in the map.
	* @returns A new `Expression` representing the value associated with the given key in the map.
	*/ mapGet(e) {
		return new y("map_get", [this, i(e)], "mapGet");
	}
	/**
	* Creates an expression that returns a new map with the specified entries added or updated.
	*
	* @remarks
	* Note that `mapSet` only performs shallow updates to the map. Setting a value to `null`
	* will retain the key with a `null` value. To remove a key entirely, use `mapRemove`.
	*
	* @example
	* ```typescript
	* // Set the 'city' to "San Francisco" in the 'address' map
	* field("address").mapSet("city", "San Francisco");
	* ```
	*
	* @param key - The key to set. Must be a string or a constant string expression.
	* @param value - The value to set.
	* @param moreKeyValues - Additional key-value pairs to set.
	* @returns A new `Expression` representing the map with the entries set.
	*/ mapSet(e, t, ...n) {
		return new y("map_set", [
			this,
			__PRIVATE_valueToDefaultExpr(e),
			__PRIVATE_valueToDefaultExpr(t),
			...n.map(__PRIVATE_valueToDefaultExpr)
		], "mapSet");
	}
	/**
	* Creates an expression that returns the keys of a map.
	*
	* @remarks
	* While the backend generally preserves insertion order, relying on the
	* order of the output array is not guaranteed and should be avoided.
	*
	* @example
	* ```typescript
	* // Get the keys of the 'address' map
	* field("address").mapKeys();
	* ```
	*
	* @returns A new `Expression` representing the keys of the map.
	*/ mapKeys() {
		return new y("map_keys", [this], "mapKeys");
	}
	/**
	* Creates an expression that returns the values of a map.
	*
	* @remarks
	* While the backend generally preserves insertion order, relying on the
	* order of the output array is not guaranteed and should be avoided.
	*
	* @example
	* ```typescript
	* // Get the values of the 'address' map
	* field("address").mapValues();
	* ```
	*
	* @returns A new `Expression` representing the values of the map.
	*/ mapValues() {
		return new y("map_values", [this], "mapValues");
	}
	/**
	* Creates an expression that returns the entries of a map as an array of maps,
	* where each map contains a `"k"` property for the key and a `"v"` property for the value.
	* For example: `[{ k: "key1", v: "value1" }, ...]`.
	*
	* @example
	* ```typescript
	* // Get the entries of the 'address' map
	* field("address").mapEntries();
	* ```
	*
	* @returns A new `Expression` representing the entries of the map.
	*/ mapEntries() {
		return new y("map_entries", [this], "mapEntries");
	}
	/**
	* @public
	* Creates an expression that returns the value of a field from the document that results from the evaluation of this expression.
	*
	* @example
	* ```typescript
	* // Get the value of the "city" field in the "address" document.
	* field("address").getField("city")
	* ```
	*
	* @param key The field to access in the document.
	* @returns A new `Expression` representing the value of the field in the document.
	*/ getField(e) {
		return new y("get_field", [this, __PRIVATE_valueToDefaultExpr(e)], "get_field");
	}
	/**
	* Creates an aggregation that counts the number of stage inputs with valid evaluations of the
	* expression or field.
	*
	* @example
	* ```typescript
	* // Count the total number of products
	* field("productId").count().as("totalProducts");
	* ```
	*
	* @returns A new `AggregateFunction` representing the 'count' aggregation.
	*/ count() {
		return k._create("count", [this], "count");
	}
	/**
	* Creates an aggregation that calculates the sum of a numeric field across multiple stage inputs.
	*
	* @example
	* ```typescript
	* // Calculate the total revenue from a set of orders
	* field("orderAmount").sum().as("totalRevenue");
	* ```
	*
	* @returns A new `AggregateFunction` representing the 'sum' aggregation.
	*/ sum() {
		return k._create("sum", [this], "sum");
	}
	/**
	* Creates an aggregation that calculates the average (mean) of a numeric field across multiple
	* stage inputs.
	*
	* @example
	* ```typescript
	* // Calculate the average age of users
	* field("age").average().as("averageAge");
	* ```
	*
	* @returns A new `AggregateFunction` representing the 'average' aggregation.
	*/ average() {
		return k._create("average", [this], "average");
	}
	/**
	* Creates an aggregation that finds the minimum value of a field across multiple stage inputs.
	*
	* @example
	* ```typescript
	* // Find the lowest price of all products
	* field("price").minimum().as("lowestPrice");
	* ```
	*
	* @returns A new `AggregateFunction` representing the 'minimum' aggregation.
	*/ minimum() {
		return k._create("minimum", [this], "minimum");
	}
	/**
	* Creates an aggregation that finds the maximum value of a field across multiple stage inputs.
	*
	* @example
	* ```typescript
	* // Find the highest score in a leaderboard
	* field("score").maximum().as("highestScore");
	* ```
	*
	* @returns A new `AggregateFunction` representing the 'maximum' aggregation.
	*/ maximum() {
		return k._create("maximum", [this], "maximum");
	}
	/**
	* Creates an aggregation that finds the first value of an expression across multiple stage inputs.
	*
	* @example
	* ```typescript
	* // Find the first value of the 'rating' field
	* field("rating").first().as("firstRating");
	* ```
	*
	* @returns A new `AggregateFunction` representing the 'first' aggregation.
	*/ first() {
		return k._create("first", [this], "first");
	}
	/**
	* Creates an aggregation that finds the last value of an expression across multiple stage inputs.
	*
	* @example
	* ```typescript
	* // Find the last value of the 'rating' field
	* field("rating").last().as("lastRating");
	* ```
	*
	* @returns A new `AggregateFunction` representing the 'last' aggregation.
	*/ last() {
		return k._create("last", [this], "last");
	}
	/**
	* Creates an aggregation that collects all values of an expression across multiple stage inputs
	* into an array.
	*
	* @remarks
	* If the expression resolves to an absent value, it is converted to `null`.
	* The order of elements in the output array is not stable and shouldn't be relied upon.
	*
	* @example
	* ```typescript
	* // Collect all tags from books into an array
	* field("tags").arrayAgg().as("allTags");
	* ```
	*
	* @returns A new `AggregateFunction` representing the 'array_agg' aggregation.
	*/ arrayAgg() {
		return k._create("array_agg", [this], "arrayAgg");
	}
	/**
	* Creates an aggregation that collects all distinct values of an expression across multiple stage
	* inputs into an array.
	*
	* @remarks
	* If the expression resolves to an absent value, it is converted to `null`.
	* The order of elements in the output array is not stable and shouldn't be relied upon.
	*
	* @example
	* ```typescript
	* // Collect all distinct tags from books into an array
	* field("tags").arrayAggDistinct().as("allDistinctTags");
	* ```
	*
	* @returns A new `AggregateFunction` representing the 'array_agg_distinct' aggregation.
	*/ arrayAggDistinct() {
		return k._create("array_agg_distinct", [this], "arrayAggDistinct");
	}
	/**
	* Creates an aggregation that counts the number of distinct values of the expression or field.
	*
	* @example
	* ```typescript
	* // Count the distinct number of products
	* field("productId").countDistinct().as("distinctProducts");
	* ```
	*
	* @returns A new `AggregateFunction` representing the 'count_distinct' aggregation.
	*/ countDistinct() {
		return k._create("count_distinct", [this], "countDistinct");
	}
	/**
	* Creates an expression that returns the larger value between this expression and another expression, based on Firestore's value type ordering.
	*
	* @example
	* ```typescript
	* // Returns the larger value between the 'timestamp' field and the current timestamp.
	* field("timestamp").logicalMaximum(currentTimestamp());
	* ```
	*
	* @param second - The second expression or literal to compare with.
	* @param others - Optional additional expressions or literals to compare with.
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the logical maximum operation.
	*/ logicalMaximum(e, ...t) {
		const n = [e, ...t];
		return new y("maximum", [this, ...n.map(__PRIVATE_valueToDefaultExpr)], "logicalMaximum");
	}
	/**
	* Creates an expression that returns the smaller value between this expression and another expression, based on Firestore's value type ordering.
	*
	* @example
	* ```typescript
	* // Returns the smaller value between the 'timestamp' field and the current timestamp.
	* field("timestamp").logicalMinimum(currentTimestamp());
	* ```
	*
	* @param second - The second expression or literal to compare with.
	* @param others - Optional additional expressions or literals to compare with.
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the logical minimum operation.
	*/ logicalMinimum(e, ...t) {
		const n = [e, ...t];
		return new y("minimum", [this, ...n.map(__PRIVATE_valueToDefaultExpr)], "minimum");
	}
	/**
	* Creates an expression that calculates the length (number of dimensions) of this Firestore Vector expression.
	*
	* @example
	* ```typescript
	* // Get the vector length (dimension) of the field 'embedding'.
	* field("embedding").vectorLength();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the length of the vector.
	*/ vectorLength() {
		return new y("vector_length", [this], "vectorLength");
	}
	cosineDistance(e) {
		return new y("cosine_distance", [this, __PRIVATE_vectorToExpr(e)], "cosineDistance");
	}
	dotProduct(e) {
		return new y("dot_product", [this, __PRIVATE_vectorToExpr(e)], "dotProduct");
	}
	euclideanDistance(e) {
		return new y("euclidean_distance", [this, __PRIVATE_vectorToExpr(e)], "euclideanDistance");
	}
	/**
	* Creates an expression that interprets this expression as the number of microseconds since the Unix epoch (1970-01-01 00:00:00 UTC)
	* and returns a timestamp.
	*
	* @example
	* ```typescript
	* // Interpret the 'microseconds' field as microseconds since epoch.
	* field("microseconds").unixMicrosToTimestamp();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the timestamp.
	*/ unixMicrosToTimestamp() {
		return new y("unix_micros_to_timestamp", [this], "unixMicrosToTimestamp");
	}
	/**
	* Creates an expression that converts this timestamp expression to the number of microseconds since the Unix epoch (1970-01-01 00:00:00 UTC).
	*
	* @example
	* ```typescript
	* // Convert the 'timestamp' field to microseconds since epoch.
	* field("timestamp").timestampToUnixMicros();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the number of microseconds since epoch.
	*/ timestampToUnixMicros() {
		return new y("timestamp_to_unix_micros", [this], "timestampToUnixMicros");
	}
	/**
	* Creates an expression that interprets this expression as the number of milliseconds since the Unix epoch (1970-01-01 00:00:00 UTC)
	* and returns a timestamp.
	*
	* @example
	* ```typescript
	* // Interpret the 'milliseconds' field as milliseconds since epoch.
	* field("milliseconds").unixMillisToTimestamp();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the timestamp.
	*/ unixMillisToTimestamp() {
		return new y("unix_millis_to_timestamp", [this], "unixMillisToTimestamp");
	}
	/**
	* Creates an expression that converts this timestamp expression to the number of milliseconds since the Unix epoch (1970-01-01 00:00:00 UTC).
	*
	* @example
	* ```typescript
	* // Convert the 'timestamp' field to milliseconds since epoch.
	* field("timestamp").timestampToUnixMillis();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the number of milliseconds since epoch.
	*/ timestampToUnixMillis() {
		return new y("timestamp_to_unix_millis", [this], "timestampToUnixMillis");
	}
	/**
	* Creates an expression that interprets this expression as the number of seconds since the Unix epoch (1970-01-01 00:00:00 UTC)
	* and returns a timestamp.
	*
	* @example
	* ```typescript
	* // Interpret the 'seconds' field as seconds since epoch.
	* field("seconds").unixSecondsToTimestamp();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the timestamp.
	*/ unixSecondsToTimestamp() {
		return new y("unix_seconds_to_timestamp", [this], "unixSecondsToTimestamp");
	}
	/**
	* Creates an expression that converts this timestamp expression to the number of seconds since the Unix epoch (1970-01-01 00:00:00 UTC).
	*
	* @example
	* ```typescript
	* // Convert the 'timestamp' field to seconds since epoch.
	* field("timestamp").timestampToUnixSeconds();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the number of seconds since epoch.
	*/ timestampToUnixSeconds() {
		return new y("timestamp_to_unix_seconds", [this], "timestampToUnixSeconds");
	}
	timestampAdd(e, t) {
		return new y("timestamp_add", [
			this,
			__PRIVATE_valueToDefaultExpr(e),
			__PRIVATE_valueToDefaultExpr(t)
		], "timestampAdd");
	}
	timestampSubtract(e, t) {
		return new y("timestamp_subtract", [
			this,
			__PRIVATE_valueToDefaultExpr(e),
			__PRIVATE_valueToDefaultExpr(t)
		], "timestampSubtract");
	}
	timestampDiff(e, t) {
		return new y("timestamp_diff", [
			this,
			__PRIVATE_fieldOrExpression(e),
			__PRIVATE_valueToDefaultExpr(t)
		], "timestampDiff");
	}
	timestampExtract(e, t) {
		const n = [this, __PRIVATE_valueToDefaultExpr(e)];
		return t && n.push(__PRIVATE_valueToDefaultExpr(t)), new y("timestamp_extract", n, "timestampExtract");
	}
	/**
	*
	* Creates an expression that returns the document ID from a path.
	*
	* @example
	* ```typescript
	* // Get the document ID from a path.
	* field("__path__").documentId();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the documentId operation.
	*/ documentId() {
		return new y("document_id", [this], "documentId");
	}
	/**
	*
	* Creates an expression that returns the parent document reference of a document reference.
	*
	* @example
	* ```typescript
	* // Get the parent document reference of a document reference.
	* field("__path__").parent();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the parent operation.
	*/ parent() {
		return new y("parent", [this], "parent");
	}
	substring(e, t) {
		const n = __PRIVATE_valueToDefaultExpr(e);
		return new y("substring", void 0 === t ? [this, n] : [
			this,
			n,
			__PRIVATE_valueToDefaultExpr(t)
		], "substring");
	}
	arrayGet(e) {
		return new y("array_get", [this, __PRIVATE_valueToDefaultExpr(e)], "arrayGet");
	}
	/**
	*
	* Creates an expression that checks if a given expression produces an error.
	*
	* @example
	* ```typescript
	* // Check if the result of a calculation is an error
	* field("title").arrayContains(1).isError();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#BooleanExpression} representing the 'isError' check.
	*/ isError() {
		return new y("is_error", [this], "isError").asBoolean();
	}
	ifError(e) {
		const t = new y("if_error", [this, __PRIVATE_valueToDefaultExpr(e)], "ifError");
		return e instanceof BooleanExpression ? t.asBoolean() : t;
	}
	/**
	*
	* Creates an expression that returns `true` if the result of this expression
	* is absent. Otherwise, returns `false` even if the value is `null`.
	*
	* @example
	* ```typescript
	* // Check if the field `value` is absent.
	* field("value").isAbsent();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#BooleanExpression} representing the 'isAbsent' check.
	*/ isAbsent() {
		return new y("is_absent", [this], "isAbsent").asBoolean();
	}
	mapRemove(e) {
		return new y("map_remove", [this, __PRIVATE_valueToDefaultExpr(e)], "mapRemove");
	}
	/**
	*
	* Creates an expression that merges multiple map values.
	*
	* @example
	* ```
	* // Merges the map in the settings field with, a map literal, and a map in
	* // that is conditionally returned by another expression
	* field('settings').mapMerge({ enabled: true }, conditional(field('isAdmin'), { admin: true}, {})
	* ```
	*
	* @param secondMap - A required second map to merge. Represented as a literal or
	* an expression that returns a map.
	* @param otherMaps - Optional additional maps to merge. Each map is represented
	* as a literal or an expression that returns a map.
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the 'mapMerge' operation.
	*/ mapMerge(e, ...t) {
		const n = __PRIVATE_valueToDefaultExpr(e), r = t.map(__PRIVATE_valueToDefaultExpr);
		return new y("map_merge", [
			this,
			n,
			...r
		], "mapMerge");
	}
	pow(e) {
		return new y("pow", [this, __PRIVATE_valueToDefaultExpr(e)]);
	}
	trunc(e) {
		return void 0 === e ? new y("trunc", [this]) : new y("trunc", [this, __PRIVATE_valueToDefaultExpr(e)], "trunc");
	}
	round(e) {
		return void 0 === e ? new y("round", [this]) : new y("round", [this, __PRIVATE_valueToDefaultExpr(e)], "round");
	}
	/**
	* Creates an expression that returns the collection ID from a path.
	*
	* @example
	* ```typescript
	* // Get the collection ID from a path.
	* field("__path__").collectionId();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the collectionId operation.
	*/ collectionId() {
		return new y("collection_id", [this]);
	}
	/**
	* Creates an expression that calculates the length of a string, array, map, vector, or bytes.
	*
	* @example
	* ```typescript
	* // Get the length of the 'name' field.
	* field("name").length();
	*
	* // Get the number of items in the 'cart' array.
	* field("cart").length();
	* ```
	*
	* @returns A new `Expression` representing the length of the string, array, map, vector, or bytes.
	*/ length() {
		return new y("length", [this]);
	}
	/**
	* Creates an expression that computes the natural logarithm of a numeric value.
	*
	* @example
	* ```typescript
	* // Compute the natural logarithm of the 'value' field.
	* field("value").ln();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the natural logarithm of the numeric value.
	*/ ln() {
		return new y("ln", [this]);
	}
	/**
	* Creates an expression that computes the square root of a numeric value.
	*
	* @example
	* ```typescript
	* // Compute the square root of the 'value' field.
	* field("value").sqrt();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the square root of the numeric value.
	*/ sqrt() {
		return new y("sqrt", [this]);
	}
	/**
	* Creates an expression that reverses a string.
	*
	* @example
	* ```typescript
	* // Reverse the value of the 'myString' field.
	* field("myString").stringReverse();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the reversed string.
	*/ stringReverse() {
		return new y("string_reverse", [this]);
	}
	ifAbsent(e) {
		return new y("if_absent", [this, __PRIVATE_valueToDefaultExpr(e)], "ifAbsent");
	}
	ifNull(e) {
		return new y("if_null", [this, __PRIVATE_valueToDefaultExpr(e)], "ifNull");
	}
	/**
	* Creates an expression that returns the first non-null, non-absent argument, without evaluating
	* the rest of the arguments. When all arguments are null or absent, returns the last argument.
	*
	* @example
	* ```typescript
	* // Returns the value of the first non-null, non-absent field among 'preferredName', 'fullName',
	* // or the last argument if all previous fields are null.
	* field("preferredName").coalesce(field("fullName"), "Anonymous");
	* ```
	*
	* @param replacement - The value to use if this expression evaluates to null.
	* @param others - Optional additional values to check if previous values are null.
	* @returns A new `Expression` representing the coalesce operation.
	*/ coalesce(e, ...t) {
		return new y("coalesce", [
			this,
			__PRIVATE_valueToDefaultExpr(e),
			...t.map(__PRIVATE_valueToDefaultExpr)
		], "coalesce");
	}
	join(e) {
		return new y("join", [this, __PRIVATE_valueToDefaultExpr(e)], "join");
	}
	/**
	* Creates an expression that computes the base-10 logarithm of a numeric value.
	*
	* @example
	* ```typescript
	* // Compute the base-10 logarithm of the 'value' field.
	* field("value").log10();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the base-10 logarithm of the numeric value.
	*/ log10() {
		return new y("log10", [this]);
	}
	/**
	* Creates an expression that computes the sum of the elements in an array.
	*
	* @example
	* ```typescript
	* // Compute the sum of the elements in the 'scores' field.
	* field("scores").arraySum();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the sum of the elements in the array.
	*/ arraySum() {
		return new y("sum", [this]);
	}
	split(e) {
		return new y("split", [this, __PRIVATE_valueToDefaultExpr(e)]);
	}
	timestampTruncate(e, t) {
		const n = [this, __PRIVATE_valueToDefaultExpr(e)];
		return t && n.push(__PRIVATE_valueToDefaultExpr(t)), new y("timestamp_trunc", n);
	}
	/**
	* Creates an {@link @firebase/firestore/pipelines#Ordering} that sorts documents in ascending order based on this expression.
	*
	* @example
	* ```typescript
	* // Sort documents by the 'name' field in ascending order
	* firestore.pipeline().collection("users")
	*   .sort(field("name").ascending());
	* ```
	*
	* @returns A new `Ordering` for ascending sorting.
	*/
	ascending() {
		return ascending(this);
	}
	/**
	* Creates an {@link @firebase/firestore/pipelines#Ordering} that sorts documents in descending order based on this expression.
	*
	* @example
	* ```typescript
	* // Sort documents by the 'createdAt' field in descending order
	* firestore.pipeline().collection("users")
	*   .sort(field("createdAt").descending());
	* ```
	*
	* @returns A new `Ordering` for descending sorting.
	*/ descending() {
		return descending(this);
	}
	/**
	* Assigns an alias to this expression.
	*
	* Aliases are useful for renaming fields in the output of a stage or for giving meaningful
	* names to calculated values.
	*
	* @example
	* ```typescript
	* // Calculate the total price and assign it the alias "totalPrice" and add it to the output.
	* firestore.pipeline().collection("items")
	*   .addFields(field("price").multiply(field("quantity")).as("totalPrice"));
	* ```
	*
	* @param name - The alias to assign to this expression.
	* @returns A new {@link @firebase/firestore/pipelines#AliasedExpression} that wraps this
	*     expression and associates it with the provided alias.
	*/ as(e) {
		return new c(this, e, "as");
	}
};
/**
*
* A class that represents an aggregate function.
*/ var k = class k {
	constructor(e, t) {
		this.name = e, this.params = t, this.exprType = "AggregateFunction", this._protoValueType = "ProtoValue";
	}
	/**
	* @internal
	* @private
	*/ static _create(e, t, n) {
		const r = new k(e, t);
		return r._methodName = n, r;
	}
	/**
	* Assigns an alias to this AggregateFunction. The alias specifies the name that
	* the aggregated value will have in the output document.
	*
	* @example
	* ```typescript
	* // Calculate the average price of all items and assign it the alias "averagePrice".
	* firestore.pipeline().collection("items")
	*   .aggregate(field("price").average().as("averagePrice"));
	* ```
	*
	* @param name - The alias to assign to this AggregateFunction.
	* @returns A new {@link @firebase/firestore/pipelines#AliasedAggregate} that wraps this
	*     AggregateFunction and associates it with the provided alias.
	*/ as(e) {
		return new AliasedAggregate(this, e, "as");
	}
	/**
	* @private
	* @internal
	*/ _toProto(e) {
		return { functionValue: {
			name: this.name,
			args: this.params.map(((t) => t._toProto(e)))
		} };
	}
	/**
	* @private
	* @internal
	*/ _readUserData(e) {
		e = this._methodName ? e.contextWith({ methodName: this._methodName }) : e, this.params.forEach(((t) => t._readUserData(e)));
	}
};
/**
*
* An AggregateFunction with alias.
*/ var AliasedAggregate = class {
	constructor(e, t, n) {
		this.aggregate = e, this.alias = t, this._methodName = n;
	}
	/**
	* @private
	* @internal
	*/ _readUserData(e) {
		this.aggregate._readUserData(e);
	}
};
var c = class {
	constructor(e, t, n) {
		this.expr = e, this.alias = t, this._methodName = n, this.exprType = "AliasedExpression", this.selectable = true;
	}
	/**
	* @private
	* @internal
	*/ _readUserData(e) {
		this.expr._readUserData(e);
	}
};
/**
* @internal
*/ var __PRIVATE_ListOfExprs = class extends t {
	constructor(e, t) {
		super(), this.cr = e, this._methodName = t, this.expressionType = "ListOfExpressions";
	}
	/**
	* @private
	* @internal
	*/ _toProto(e) {
		return { arrayValue: { values: this.cr.map(((t) => t._toProto(e))) } };
	}
	/**
	* @private
	* @internal
	*/ _readUserData(e) {
		this.cr.forEach(((t) => t._readUserData(e)));
	}
};
/**
*
* Represents a reference to a field in a Firestore document, or outputs of a {@link @firebase/firestore/pipelines#Pipeline} stage.
*
* <p>Field references are used to access document field values in expressions and to specify fields
* for sorting, filtering, and projecting data in Firestore pipelines.
*
* <p>You can create a `Field` instance using the static {@link @firebase/firestore/pipelines#(field:1) | field} method:
*
* @example
* ```typescript
* // Create a Field instance for the 'name' field
* const nameField = field("name");
*
* // Create a Field instance for a nested field 'address.city'
* const cityField = field("address.city");
* ```
*/ var o = class extends t {
	/**
	* @internal
	* @private
	* @hideconstructor
	* @param fieldPath
	*/
	constructor(e, t) {
		super(), this.fieldPath = e, this._methodName = t, this.expressionType = "Field", this.selectable = true;
	}
	get _fieldPath() {
		return this.fieldPath;
	}
	get fieldName() {
		return this.fieldPath.canonicalString();
	}
	get alias() {
		return this.fieldName;
	}
	get expr() {
		return this;
	}
	/**
	* @beta
	* Evaluates to the distance in meters between the location specified
	* by this field and the query location.
	*
	* @remarks This Expression can only be used within a `search` stage.
	*
	* @param location - Compute distance to this GeoPoint.
	*/
	geoDistance(e) {
		return new y("geo_distance", [this, __PRIVATE_valueToDefaultExpr(e)], "geoDistance");
	}
	/**
	* @private
	* @internal
	*/ _toProto(e) {
		return { fieldReferenceValue: this.fieldPath.canonicalString() };
	}
	/**
	* @private
	* @internal
	*/ _readUserData(e) {}
};
function s(e) {
	return G(e, "field");
}
function G(e, t) {
	return new o("string" == typeof e ? Ce === e ? documentId$1()._internalPath : K("field", e) : e._internalPath, t);
}
/**
* @internal
*
* Represents a constant value that can be used in a Firestore pipeline expression.
*
* You can create a `Constant` instance using the static {@link @firebase/firestore/pipelines#(constant:1) | constant} method:
*
* @example
* ```typescript
* // Create a Constant instance for the number 10
* const ten = constant(10);
*
* // Create a Constant instance for the string "hello"
* const hello = constant("hello");
* ```
*/ var Constant = class Constant extends t {
	/**
	* @private
	* @internal
	* @hideconstructor
	* @param value - The value of the constant.
	*/
	constructor(e, t) {
		super(), this.value = e, this._methodName = t, this.expressionType = "Constant";
	}
	/**
	* @private
	* @internal
	*/ static _fromProto(e) {
		const t = new Constant(e, void 0);
		return t._protoValue = e, t;
	}
	/**
	* @private
	* @internal
	*/ _toProto(e) {
		return __PRIVATE_hardAssert(void 0 !== this._protoValue, 237), this._protoValue;
	}
	_getValue() {
		return this._protoValue;
	}
	/**
	* @private
	* @internal
	*/ _readUserData(e) {
		e = this._methodName ? e.contextWith({ methodName: this._methodName }) : e, u(this._protoValue) || (this._protoValue = __PRIVATE_parseData(this.value, e));
	}
};
function i(e, t) {
	return m(e, "constant");
}
/**
* @internal
* @private
* @param value
* @param methodName
*/ function m(e, t) {
	const n = new Constant(e, t);
	return "boolean" == typeof e ? new __PRIVATE_BooleanConstant(n) : n;
}
/**
*
* This class defines the base class for Firestore {@link @firebase/firestore/pipelines#Pipeline} functions, which can be evaluated within pipeline
* execution.
*
* Typically, you would not use this class or its children directly. Use either the functions like {@link @firebase/firestore/pipelines#and}, {@link @firebase/firestore/pipelines#(equal:1)},
* or the methods on {@link @firebase/firestore/pipelines#Expression} ({@link @firebase/firestore/pipelines#Expression.(equal:1)}, {@link @firebase/firestore/pipelines#Expression.(lessThan:1)}, etc.) to construct new Function instances.
*/ var y = class extends t {
	/**
	* @hideconstructor
	*/
	constructor(e, t, n, r) {
		super(), this.name = e, this.params = t, this.expressionType = "Function", this._optionsProto = void 0, void 0 !== n && (this._methodName = n), void 0 !== r && (this._options = r);
	}
	/**
	* @private
	* @internal
	*/ get _optionsUtil() {
		return new OptionsUtil({});
	}
	/**
	* @private
	* @internal
	*/ _toProto(e) {
		const t = { functionValue: {
			name: this.name,
			args: this.params.map(((t) => t._toProto(e)))
		} };
		return this._optionsProto && (t.functionValue.options = this._optionsProto), t;
	}
	/**
	* @private
	* @internal
	*/ _readUserData(e) {
		e = this._methodName ? e.contextWith({ methodName: this._methodName }) : e, this.params.forEach(((t) => t._readUserData(e))), this._options && (this._optionsProto = this._optionsUtil.getOptionsProto(e, this._options));
	}
};
/**
*
* An interface that represents a filter condition.
*/ var BooleanExpression = class BooleanExpression extends t {
	get _methodName() {
		return this._expr._methodName;
	}
	/**
	* Creates an aggregation that finds the count of input documents satisfying
	* this boolean expression.
	*
	* @example
	* ```typescript
	* // Find the count of documents with a score greater than 90
	* field("score").greaterThan(90).countIf().as("highestScore");
	* ```
	*
	* @returns A new `AggregateFunction` representing the 'countIf' aggregation.
	*/ countIf() {
		return k._create("count_if", [this], "countIf");
	}
	/**
	* Creates an expression that negates this boolean expression.
	*
	* @example
	* ```typescript
	* // Find documents where the 'tags' field does not contain 'completed'
	* field("tags").arrayContains("completed").not();
	* ```
	*
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the negated filter condition.
	*/ not() {
		return new y("not", [this], "not").asBoolean();
	}
	/**
	* Creates a conditional expression that evaluates to the 'then' expression
	* if `this` expression evaluates to `true`,
	* or evaluates to the 'else' expression if `this` expressions evaluates `false`.
	*
	* @example
	* ```typescript
	* // If 'age' is greater than 18, return "Adult"; otherwise, return "Minor".
	* field("age").greaterThanOrEqual(18).conditional(constant("Adult"), constant("Minor"));
	* ```
	*
	* @param thenExpr - The expression to evaluate if the condition is true.
	* @param elseExpr - The expression to evaluate if the condition is false.
	* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the conditional expression.
	*/ conditional(e, t) {
		return new y("conditional", [
			this,
			e,
			t
		], "conditional");
	}
	ifError(e) {
		const t = __PRIVATE_valueToDefaultExpr(e), n = new y("if_error", [this, t], "ifError");
		return t instanceof BooleanExpression ? n.asBoolean() : n;
	}
	/**
	* @private
	* @internal
	*/ _toProto(e) {
		return this._expr._toProto(e);
	}
	/**
	* @private
	* @internal
	*/ _readUserData(e) {
		this._expr._readUserData(e);
	}
};
var __PRIVATE_BooleanFunctionExpression = class extends BooleanExpression {
	constructor(e) {
		super(), this._expr = e, this.expressionType = "Function";
	}
};
var __PRIVATE_BooleanConstant = class extends BooleanExpression {
	constructor(e) {
		super(), this._expr = e, this.expressionType = "Constant";
	}
	_getValue() {
		return this._expr._getValue();
	}
};
var __PRIVATE_BooleanField = class extends BooleanExpression {
	constructor(e) {
		super(), this._expr = e, this.expressionType = "Field";
	}
};
function __PRIVATE__map(e, t) {
	const n = [];
	for (const t in e) if (Object.prototype.hasOwnProperty.call(e, t)) {
		const r = e[t];
		n.push(i(t)), n.push(__PRIVATE_valueToDefaultExpr(r));
	}
	return new y("map", n, "map");
}
/**
*
* Creates an expression that creates a Firestore array value from an input array.
*
* @example
* ```typescript
* // Create an array value from the input array and reference the 'baz' field value from the input document.
* array(['bar', field('baz')]).as('foo');
* ```
*
* @param elements - The input array to evaluate in the expression.
* @returns A new {@link @firebase/firestore/pipelines#Expression} representing the array function.
*/ function b(e) {
	return function __PRIVATE__array(e, t) {
		return new y("array", e.map(((e) => __PRIVATE_valueToDefaultExpr(e))), t);
	}(e, "array");
}
function ascending(e) {
	return new Ordering(__PRIVATE_fieldOrExpression(e), "ascending", "ascending");
}
function descending(e) {
	return new Ordering(__PRIVATE_fieldOrExpression(e), "descending", "descending");
}
/**
*
* Represents an ordering criterion for sorting documents in a Firestore pipeline.
*
* You create `Ordering` instances using the `ascending` and `descending` helper functions.
*/ var Ordering = class {
	constructor(e, t, n) {
		this.expr = e, this.direction = t, this._methodName = n, this._protoValueType = "ProtoValue";
	}
	/**
	* @private
	* @internal
	*/ _toProto(e) {
		return { mapValue: { fields: {
			direction: __PRIVATE_toStringValue(this.direction),
			expression: this.expr._toProto(e)
		} } };
	}
	/**
	* @private
	* @internal
	*/ _readUserData(e) {
		this.expr._readUserData(e);
	}
};
/**
* @license
* Copyright 2024 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var Stage = class {
	constructor(e) {
		/**
		* Store _optionsProto parsed by _readUserData.
		* @private
		* @internal
		* @protected
		*/
		this.optionsProto = void 0, {rawOptions: this.rawOptions, ...this.knownOptions} = e;
	}
	_readUserData(e) {
		this.optionsProto = this._optionsUtil.getOptionsProto(e, this.knownOptions, this.rawOptions);
	}
	_toProto(e) {
		return {
			name: this._name,
			options: this.optionsProto
		};
	}
};
var w = class extends Stage {
	get _name() {
		return "add_fields";
	}
	get _optionsUtil() {
		return new OptionsUtil({});
	}
	constructor(e, t) {
		super(t), this.fields = e;
	}
	_toProto(e) {
		return {
			...super._toProto(e),
			args: [toMapValue(e, this.fields)]
		};
	}
	_readUserData(e) {
		super._readUserData(e), __PRIVATE_readUserDataHelper(this.fields, e);
	}
};
var O = class extends Stage {
	get _name() {
		return "aggregate";
	}
	get _optionsUtil() {
		return new OptionsUtil({});
	}
	constructor(e, t, n) {
		super(n), this.groups = e, this.accumulators = t;
	}
	/**
	* @internal
	* @private
	*/ _toProto(e) {
		return {
			...super._toProto(e),
			args: [toMapValue(e, this.accumulators), toMapValue(e, this.groups)]
		};
	}
	_readUserData(e) {
		super._readUserData(e), __PRIVATE_readUserDataHelper(this.groups, e), __PRIVATE_readUserDataHelper(this.accumulators, e);
	}
};
var M = class extends Stage {
	get _name() {
		return "distinct";
	}
	get _optionsUtil() {
		return new OptionsUtil({});
	}
	constructor(e, t) {
		super(t), this.groups = e;
	}
	/**
	* @internal
	* @private
	*/ _toProto(e) {
		return {
			...super._toProto(e),
			args: [toMapValue(e, this.groups)]
		};
	}
	_readUserData(e) {
		super._readUserData(e), __PRIVATE_readUserDataHelper(this.groups, e);
	}
};
var X = class extends Stage {
	get _name() {
		return "collection";
	}
	get _optionsUtil() {
		return new OptionsUtil({ forceIndex: { serverName: "force_index" } });
	}
	constructor(e, t) {
		super(t), this.hr = e.startsWith("/") ? e : "/" + e;
	}
	/**
	* @internal
	* @private
	*/ _toProto(e) {
		return {
			...super._toProto(e),
			args: [{ referenceValue: this.hr }]
		};
	}
	_readUserData(e) {
		super._readUserData(e);
	}
};
var Y = class extends Stage {
	get _name() {
		return "collection_group";
	}
	get _optionsUtil() {
		return new OptionsUtil({ forceIndex: { serverName: "force_index" } });
	}
	constructor(e, t) {
		super(t), this.collectionId = e;
	}
	/**
	* @internal
	* @private
	*/ _toProto(e) {
		return {
			...super._toProto(e),
			args: [{ referenceValue: "" }, { stringValue: this.collectionId }]
		};
	}
	_readUserData(e) {
		super._readUserData(e);
	}
};
var Z = class extends Stage {
	get _name() {
		return "database";
	}
	get _optionsUtil() {
		return new OptionsUtil({});
	}
	/**
	* @internal
	* @private
	*/ _toProto(e) {
		return { ...super._toProto(e) };
	}
	_readUserData(e) {
		super._readUserData(e);
	}
};
var sa = class extends Stage {
	get _name() {
		return "documents";
	}
	get _optionsUtil() {
		return new OptionsUtil({});
	}
	constructor(t, n) {
		if (super(n), !t || 0 === t.length) throw new e(ta.INVALID_ARGUMENT, "Empty document paths are not allowed in DocumentsSource");
		const r = t.map(((e) => e.startsWith("/") ? e : "/" + e)), i = new Set(r);
		if (i.size !== r.length) throw new e(ta.INVALID_ARGUMENT, "Duplicate document paths are not allowed in DocumentsSource");
		this.Tr = r, this.Pr = i;
	}
	/**
	* @internal
	* @private
	*/ _toProto(e) {
		return {
			...super._toProto(e),
			args: this.Tr.map(((e) => ({ referenceValue: e })))
		};
	}
	_readUserData(e) {
		super._readUserData(e);
	}
};
var A = class extends Stage {
	get _name() {
		return "where";
	}
	get _optionsUtil() {
		return new OptionsUtil({});
	}
	constructor(e, t) {
		super(t), this.condition = e;
	}
	/**
	* @internal
	* @private
	*/ _toProto(e) {
		return {
			...super._toProto(e),
			args: [this.condition._toProto(e)]
		};
	}
	_readUserData(e) {
		super._readUserData(e), __PRIVATE_readUserDataHelper(this.condition, e);
	}
};
var v = class extends Stage {
	get _name() {
		return "limit";
	}
	get _optionsUtil() {
		return new OptionsUtil({});
	}
	constructor(e, t) {
		__PRIVATE_hardAssert(!isNaN(e) && e !== Infinity && e !== -Infinity, 34860), super(t), this.limit = e;
	}
	/**
	* @internal
	* @private
	*/ _toProto(e) {
		return {
			...super._toProto(e),
			args: [toNumber(e, this.limit)]
		};
	}
};
var I = class extends Stage {
	get _name() {
		return "offset";
	}
	get _optionsUtil() {
		return new OptionsUtil({});
	}
	constructor(e, t) {
		super(t), this.offset = e;
	}
	/**
	* @internal
	* @private
	*/ _toProto(e) {
		return {
			...super._toProto(e),
			args: [toNumber(e, this.offset)]
		};
	}
};
var x = class extends Stage {
	get _name() {
		return "select";
	}
	get _optionsUtil() {
		return new OptionsUtil({});
	}
	constructor(e, t) {
		super(t), this.selections = e;
	}
	/**
	* @internal
	* @private
	*/ _toProto(e) {
		return {
			...super._toProto(e),
			args: [toMapValue(e, this.selections)]
		};
	}
	_readUserData(e) {
		super._readUserData(e), __PRIVATE_readUserDataHelper(this.selections, e);
	}
};
var L = class extends Stage {
	get _name() {
		return "sort";
	}
	get _optionsUtil() {
		return new OptionsUtil({});
	}
	constructor(e, t) {
		super(t), this.orderings = e;
	}
	/**
	* @internal
	* @private
	*/ _toProto(e) {
		return {
			...super._toProto(e),
			args: this.orderings.map(((t) => t._toProto(e)))
		};
	}
	_readUserData(e) {
		super._readUserData(e), __PRIVATE_readUserDataHelper(this.orderings, e);
	}
};
var $ = class $ extends Stage {
	get _name() {
		return "replace_with";
	}
	get _optionsUtil() {
		return new OptionsUtil({});
	}
	constructor(e, t) {
		super(t), this.map = e;
	}
	_toProto(e) {
		return {
			...super._toProto(e),
			args: [this.map._toProto(e), __PRIVATE_toStringValue($.Ir)]
		};
	}
	_readUserData(e) {
		super._readUserData(e), __PRIVATE_readUserDataHelper(this.map, e);
	}
};
$.Ir = "full_replace";
/**
* Helper to read user data across a number of different formats.
* @param name - Name of the calling function. Used for error messages when invalid user data is encountered.
* @param expressionMap
* @returns the expressionMap argument.
* @private
*/ function __PRIVATE_readUserDataHelper(e, t) {
	return __PRIVATE_isUserData(e) ? e._readUserData(t) : Array.isArray(e) ? e.forEach(((e) => e._readUserData(t))) : e instanceof Map ? e.forEach(((e) => e._readUserData(t))) : Object.values(e).forEach(((e) => e._readUserData(t))), e;
}
/**
* @license
* Copyright 2026 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @beta
* @internal
*
* The RealtimePipeline class provides a flexible and expressive framework for building complex data
* transformation and query pipelines that can be used with Firestore's real-time and offline capabilities.
*
* A RealtimePipeline takes data sources, such as Firestore collections or collection groups, and applies
* a series of stages that are chained together. Each stage takes the output from the previous stage
* (or the data source) and produces an output for the next stage (or as the final output of the
* pipeline).
*
* Expressions can be used within each stage to filter and transform data through the stage.
*
* NOTE: Both the initial and subsequent snapshots for RealtimePipeline take the consideration of the SDK's cache.
* They might include results that have not been synchronized with the server yet, and wait for subsequent snapshots
* to reflect the latest server state, this is the same as classic Firestore {@link Query}.
* This behavior is different from the {@link Pipeline} class, which does not take the consideration of the SDK's cache.
*
* Usage Examples:
*
* ```typescript
* const db: Firestore; // Assumes a valid firestore instance.
*
* // Example 1: Listen to books published after 1980
* const unsubscribe = onRealtimePipelineSnapshot(db.realtimePipeline()
*     .collection("books")
*     .where(field("published").gt(1980)),
*     (snapshot) => {
*       // Handle the snapshot
*     }
* );
* ```
*/
var __PRIVATE_RealtimePipeline = class __PRIVATE_RealtimePipeline {
	/**
	* @internal
	* @private
	* @param _db
	* @param userDataReader
	* @param _userDataWriter
	* @param _documentReferenceFactory
	* @param stages
	*/
	constructor(e, t, n, r) {
		this._db = e, this.userDataReader = t, this._userDataWriter = n, this.stages = r;
	}
	/**
	* Reads user data for each expression in the expressionMap.
	* @param name Name of the calling function. Used for error messages when invalid user data is encountered.
	* @param expressionMap
	* @return the expressionMap argument.
	* @private
	* @internal
	*/ Vr(e, t) {
		const n = this.userDataReader.createContext(3, e);
		return __PRIVATE_isUserData(t) ? t._readUserData(n) : Array.isArray(t) ? t.forEach(((e) => e._readUserData(n))) : t.forEach(((e) => e._readUserData(n))), t;
	}
	where(e) {
		const t = this.stages.map(((e) => e));
		return this.Vr("where", e), t.push(new A(e, {})), new __PRIVATE_RealtimePipeline(this._db, this.userDataReader, this._userDataWriter, t);
	}
	limit(e) {
		const t = this.stages.map(((e) => e));
		return t.push(new v(e, {})), new __PRIVATE_RealtimePipeline(this._db, this.userDataReader, this._userDataWriter, t);
	}
	sort(e, ...t) {
		const n = this.stages.map(((e) => e));
		return "orderings" in e ? n.push(new L(this.Vr("sort", e.orderings), {})) : n.push(new L(this.Vr("sort", [e, ...t]), {})), new __PRIVATE_RealtimePipeline(this._db, this.userDataReader, this._userDataWriter, n);
	}
	/**
	* @internal
	* @private
	*/ dr(e) {
		return { pipeline: { stages: this.stages.map(((t) => t._toProto(e))) } };
	}
};
var CorePipeline = class {
	constructor(e, t, n) {
		this.serializer = e, this.stages = t, this.listenOptions = n, this.isCorePipeline = true;
	}
	getPipelineCollection() {
		return getPipelineCollection(this);
	}
	getPipelineCollectionGroup() {
		return getPipelineCollectionGroup(this);
	}
	getPipelineCollectionId() {
		return getPipelineCollectionId(this);
	}
	getPipelineDocuments() {
		return getPipelineDocuments(this);
	}
	getPipelineFlavor() {
		return function getPipelineFlavor(e) {
			let t = "exact";
			return e.stages.forEach(((n, r) => {
				n._name !== M.name && n._name !== O.name || (t = "keyless"), n._name === x.name && "exact" === t && (t = "augmented"), n._name === w.name && r < e.stages.length - 1 && "exact" === t && (t = "augmented");
			})), t;
		}(this);
	}
	getPipelineSourceType() {
		return getPipelineSourceType(this);
	}
};
function getPipelineSourceType(e) {
	const t = e.stages[0];
	return t instanceof X || t instanceof Y || t instanceof Z || t instanceof sa ? t._name : "unknown";
}
function getPipelineCollection(e) {
	if ("collection" === getPipelineSourceType(e)) return e.stages[0].hr;
}
function getPipelineCollectionGroup(e) {
	if ("collection_group" === getPipelineSourceType(e)) return e.stages[0].collectionId;
}
function getPipelineCollectionId(e) {
	switch (getPipelineSourceType(e)) {
		case "collection": return ResourcePath.fromString(getPipelineCollection(e)).lastSegment();
		case "collection_group": return getPipelineCollectionGroup(e);
		default: return;
	}
}
function getPipelineDocuments(e) {
	if ("documents" === getPipelineSourceType(e)) return e.stages[0].Tr;
}
var __PRIVATE_EvaluateResult = class __PRIVATE_EvaluateResult {
	constructor(e, t) {
		this.type = e, this.value = t;
	}
	static mr() {
		return new __PRIVATE_EvaluateResult("ERROR", void 0);
	}
	static pr() {
		return new __PRIVATE_EvaluateResult("UNSET", void 0);
	}
	static gr() {
		return new __PRIVATE_EvaluateResult("NULL", He);
	}
	static newValue(e) {
		return __PRIVATE_isNullValue(e) ? new __PRIVATE_EvaluateResult("NULL", He) : function __PRIVATE_isBoolean(e) {
			return !!e && "booleanValue" in e;
		}(e) ? new __PRIVATE_EvaluateResult("BOOLEAN", e) : isInteger(e) ? new __PRIVATE_EvaluateResult("INT", e) : __PRIVATE_isDouble(e) ? new __PRIVATE_EvaluateResult("DOUBLE", e) : function __PRIVATE_isTimestampValue(e) {
			return !!e && "timestampValue" in e && !!e.timestampValue;
		}(e) ? new __PRIVATE_EvaluateResult("TIMESTAMP", e) : function __PRIVATE_isString(e) {
			return !!e && "stringValue" in e;
		}(e) ? new __PRIVATE_EvaluateResult("STRING", e) : function __PRIVATE_isBytes(e) {
			return !!e && "bytesValue" in e;
		}(e) ? new __PRIVATE_EvaluateResult("BYTES", e) : e.referenceValue ? new __PRIVATE_EvaluateResult("REFERENCE", e) : e.geoPointValue ? new __PRIVATE_EvaluateResult("GEO_POINT", e) : isArray(e) ? new __PRIVATE_EvaluateResult("ARRAY", e) : __PRIVATE_isVectorValue(e) ? new __PRIVATE_EvaluateResult("VECTOR", e) : __PRIVATE_isMapValue(e) ? new __PRIVATE_EvaluateResult("MAP", e) : new __PRIVATE_EvaluateResult("ERROR", void 0);
	}
	yr() {
		return "ERROR" === this.type || "UNSET" === this.type;
	}
	wr() {
		return "NULL" === this.type;
	}
};
function __PRIVATE_valueOrUndefined(e) {
	if (!e.yr()) return e.value;
}
function __PRIVATE_unwrapExpression(e) {
	return e instanceof BooleanExpression ? e._expr : e;
}
function __PRIVATE_toEvaluable(e) {
	if ((e = __PRIVATE_unwrapExpression(e)) instanceof o) return new __PRIVATE_CoreField(e);
	if (e instanceof Constant) return new __PRIVATE_CoreConstant(e);
	if (e instanceof __PRIVATE_ListOfExprs) return new __PRIVATE_CoreListOfExprs(e);
	if (e instanceof y) {
		if ("add" === e.name) return new __PRIVATE_CoreAdd(e);
		if ("subtract" === e.name) return new __PRIVATE_CoreSubtract(e);
		if ("multiply" === e.name) return new __PRIVATE_CoreMultiply(e);
		if ("divide" === e.name) return new __PRIVATE_CoreDivide(e);
		if ("mod" === e.name) return new __PRIVATE_CoreMod(e);
		if ("and" === e.name) return new __PRIVATE_CoreAnd(e);
		if ("equal" === e.name) return new __PRIVATE_CoreEq(e);
		if ("not_equal" === e.name) return new __PRIVATE_CoreNeq(e);
		if ("less_than" === e.name) return new __PRIVATE_CoreLt(e);
		if ("less_than_or_equal" === e.name) return new __PRIVATE_CoreLte(e);
		if ("greater_than" === e.name) return new __PRIVATE_CoreGt(e);
		if ("greater_than_or_equal" === e.name) return new __PRIVATE_CoreGte(e);
		if ("array_concat" === e.name) return new __PRIVATE_CoreArrayConcat(e);
		if ("array_reverse" === e.name) return new __PRIVATE_CoreArrayReverse(e);
		if ("array_contains" === e.name) return new __PRIVATE_CoreArrayContains(e);
		if ("array_contains_all" === e.name) return new __PRIVATE_CoreArrayContainsAll(e);
		if ("array_contains_any" === e.name) return new __PRIVATE_CoreArrayContainsAny(e);
		if ("array_length" === e.name) return new __PRIVATE_CoreArrayLength(e);
		if ("array_element" === e.name) return new __PRIVATE_CoreArrayElement(e);
		if ("equal_any" === e.name) return new __PRIVATE_CoreEqAny(e);
		if ("not_equal_any" === e.name) return new __PRIVATE_CoreNotEqAny(e);
		if ("is_nan" === e.name) return new __PRIVATE_CoreIsNan(e);
		if ("is_not_nan" === e.name) return new __PRIVATE_CoreIsNotNan(e);
		if ("is_null" === e.name) return new __PRIVATE_CoreIsNull(e);
		if ("is_not_null" === e.name) return new __PRIVATE_CoreIsNotNull(e);
		if ("is_error" === e.name) return new __PRIVATE_CoreIsError(e);
		if ("exists" === e.name) return new __PRIVATE_CoreExists(e);
		if ("not" === e.name) return new __PRIVATE_CoreNot(e);
		if ("or" === e.name) return new __PRIVATE_CoreOr(e);
		if ("xor" === e.name) return new __PRIVATE_CoreXor(e);
		if ("conditional" === e.name) return new __PRIVATE_CoreCond(e);
		if ("maximum" === e.name) return new __PRIVATE_CoreLogicalMaximum(e);
		if ("minimum" === e.name) return new __PRIVATE_CoreLogicalMinimum(e);
		if ("reverse" === e.name) return new __PRIVATE_CoreReverse(e);
		if ("replace_first" === e.name) return new __PRIVATE_CoreReplaceFirst(e);
		if ("replace_all" === e.name) return new __PRIVATE_CoreReplaceAll(e);
		if ("char_length" === e.name) return new __PRIVATE_CoreCharLength(e);
		if ("byte_length" === e.name) return new __PRIVATE_CoreByteLength(e);
		if ("like" === e.name) return new __PRIVATE_CoreLike(e);
		if ("regex_contains" === e.name) return new __PRIVATE_CoreRegexContains(e);
		if ("regex_match" === e.name) return new __PRIVATE_CoreRegexMatch(e);
		if ("string_contains" === e.name) return new __PRIVATE_CoreStrContains(e);
		if ("starts_with" === e.name) return new __PRIVATE_CoreStartsWith(e);
		if ("ends_with" === e.name) return new __PRIVATE_CoreEndsWith(e);
		if ("to_lower" === e.name) return new __PRIVATE_CoreToLower(e);
		if ("to_upper" === e.name) return new __PRIVATE_CoreToUpper(e);
		if ("trim" === e.name) return new __PRIVATE_CoreTrim(e);
		if ("string_concat" === e.name) return new __PRIVATE_CoreStrConcat(e);
		if ("map_get" === e.name) return new __PRIVATE_CoreMapGet(e);
		if ("cosine_distance" === e.name) return new __PRIVATE_CoreCosineDistance(e);
		if ("dot_product" === e.name) return new __PRIVATE_CoreDotProduct(e);
		if ("euclidean_distance" === e.name) return new __PRIVATE_CoreEuclideanDistance(e);
		if ("vector_length" === e.name) return new __PRIVATE_CoreVectorLength(e);
		if ("unix_micros_to_timestamp" === e.name) return new __PRIVATE_CoreUnixMicrosToTimestamp(e);
		if ("timestamp_to_unix_micros" === e.name) return new __PRIVATE_CoreTimestampToUnixMicros(e);
		if ("unix_millis_to_timestamp" === e.name) return new __PRIVATE_CoreUnixMillisToTimestamp(e);
		if ("timestamp_to_unix_millis" === e.name) return new __PRIVATE_CoreTimestampToUnixMillis(e);
		if ("unix_seconds_to_timestamp" === e.name) return new __PRIVATE_CoreUnixSecondsToTimestamp(e);
		if ("timestamp_to_unix_seconds" === e.name) return new __PRIVATE_CoreTimestampToUnixSeconds(e);
		if ("timestamp_add" === e.name) return new __PRIVATE_CoreTimestampAdd(e);
		if ("timestamp_subtract" === e.name) return new __PRIVATE_CoreTimestampSub(e);
	}
	throw new Error(`Unknown Expr : ${e}`);
}
var __PRIVATE_CoreField = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		if (this.expr.fieldName === Ce) return __PRIVATE_EvaluateResult.newValue({ referenceValue: __PRIVATE_toName(e.serializer, t.key) });
		if ("__update_time__" === this.expr.fieldName) return __PRIVATE_EvaluateResult.newValue({ timestampValue: __PRIVATE_toVersion(e.serializer, t.version) });
		if ("__create_time__" === this.expr.fieldName) return __PRIVATE_EvaluateResult.newValue({ timestampValue: __PRIVATE_toVersion(e.serializer, t.createTime) });
		const n = t.data.field(this.expr._fieldPath);
		return n ? __PRIVATE_isServerTimestamp(n) ? __PRIVATE_EvaluateResult.newValue(function __PRIVATE_getServerTimestampValue(e, t) {
			if ("estimate" === e.serverTimestampBehavior) return { timestampValue: __PRIVATE_toVersion(e.serializer, SnapshotVersion.fromTimestamp(__PRIVATE_getLocalWriteTime(t))) };
			if ("previous" === e.serverTimestampBehavior) {
				const e = __PRIVATE_getPreviousValue(t);
				if (e) return e;
			}
			return { nullValue: "NULL_VALUE" };
		}(e, n)) : __PRIVATE_EvaluateResult.newValue(n) : __PRIVATE_EvaluateResult.pr();
	}
};
var __PRIVATE_CoreConstant = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		return __PRIVATE_EvaluateResult.newValue(this.expr._getValue());
	}
};
var __PRIVATE_CoreListOfExprs = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		const n = this.expr.cr.map(((n) => __PRIVATE_toEvaluable(n).evaluate(e, t)));
		return n.some(((e) => e.yr())) ? __PRIVATE_EvaluateResult.mr() : __PRIVATE_EvaluateResult.newValue({ arrayValue: { values: n.map(((e) => e.value)) } });
	}
};
function __PRIVATE_asDouble(e) {
	return __PRIVATE_isDouble(e) ? Number(e.doubleValue) : Number(e.integerValue);
}
function __PRIVATE_asBigInt(e) {
	return BigInt(e.integerValue);
}
var Ft = BigInt("0x7fffffffffffffff");
var Ot = -BigInt("0x8000000000000000");
var __PRIVATE_BigIntOrDoubleArithmetics = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(this.expr.params.length >= 2, 24778);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t), r = __PRIVATE_toEvaluable(this.expr.params[1]).evaluate(e, t);
		let i = this.br(n, r);
		for (const n of this.expr.params.slice(2)) {
			const r = __PRIVATE_toEvaluable(n).evaluate(e, t);
			i = this.br(i, r);
		}
		return i;
	}
	br(e, t) {
		if (e.yr() || t.yr()) return __PRIVATE_EvaluateResult.mr();
		if (e.wr() || t.wr()) return __PRIVATE_EvaluateResult.gr();
		const n = e.value, r = t.value;
		if (!__PRIVATE_isDouble(n) && !isInteger(n) || !__PRIVATE_isDouble(r) && !isInteger(r)) return __PRIVATE_EvaluateResult.mr();
		if (__PRIVATE_isDouble(n) || __PRIVATE_isDouble(r)) {
			const e = this.Sr(n, r);
			return e ? __PRIVATE_EvaluateResult.newValue(e) : __PRIVATE_EvaluateResult.mr();
		}
		if (isInteger(n) && isInteger(r)) {
			const e = this.vr(n, r);
			return void 0 === e ? __PRIVATE_EvaluateResult.mr() : "number" == typeof e ? __PRIVATE_EvaluateResult.newValue({ doubleValue: e }) : e < Ot || e > Ft ? __PRIVATE_EvaluateResult.mr() : __PRIVATE_EvaluateResult.newValue({ integerValue: `${e}` });
		}
		return __PRIVATE_EvaluateResult.mr();
	}
};
function __PRIVATE_strictValueEquals(e, t) {
	return __PRIVATE_typeOrder(e) !== __PRIVATE_typeOrder(t) ? "TYPE_MISMATCH" : __PRIVATE_isNanValue(e) || __PRIVATE_isNanValue(t) ? "NOT_EQ" : __PRIVATE_isNullValue(e) && __PRIVATE_isNullValue(t) ? "EQ" : __PRIVATE_isNullValue(e) || __PRIVATE_isNullValue(t) ? "NULL" : isArray(e) && isArray(t) ? function __PRIVATE_strictArrayValueEquals(e, t) {
		if (e.values?.length !== t.values?.length) return "NOT_EQ";
		let n = false;
		for (let r = 0; r < (e.values?.length ?? 0); r++) {
			const i = e.values[r], s = t.values[r];
			switch (__PRIVATE_strictValueEquals(i, s)) {
				case "EQ": break;
				case "NOT_EQ":
				case "TYPE_MISMATCH": return "NOT_EQ";
				case "NULL":
					n = true;
					break;
				default: l(44609, {
					Dr: i,
					Cr: s
				});
			}
		}
		if (n) return "NULL";
		return "EQ";
	}(e.arrayValue, t.arrayValue) : __PRIVATE_isVectorValue(e) && __PRIVATE_isVectorValue(t) || __PRIVATE_isMapValue(e) && __PRIVATE_isMapValue(t) ? function __PRIVATE_strictObjectValueEquals(e, t) {
		const n = e.fields || {}, r = t.fields || {};
		if (__PRIVATE_objectSize(n) !== __PRIVATE_objectSize(r)) return "NOT_EQ";
		let i = false;
		for (const e in n) if (n.hasOwnProperty(e)) {
			if (void 0 === r[e]) return "NOT_EQ";
			switch (__PRIVATE_strictValueEquals(n[e], r[e])) {
				case "NOT_EQ":
				case "TYPE_MISMATCH": return "NOT_EQ";
				case "NULL": i = true;
			}
		}
		if (i) return "NULL";
		return "EQ";
	}(e.mapValue, t.mapValue) : function __PRIVATE_valueEquals(e, t) {
		return __PRIVATE_valueEquals$1(e, t, {
			u: false,
			i: true,
			o: true
		});
	}(e, t) ? "EQ" : "NOT_EQ";
}
var __PRIVATE_CoreAdd = class extends __PRIVATE_BigIntOrDoubleArithmetics {
	vr(e, t) {
		return __PRIVATE_asBigInt(e) + __PRIVATE_asBigInt(t);
	}
	Sr(e, t) {
		return { doubleValue: __PRIVATE_asDouble(e) + __PRIVATE_asDouble(t) };
	}
};
var __PRIVATE_CoreSubtract = class extends __PRIVATE_BigIntOrDoubleArithmetics {
	constructor(e) {
		super(e), this.expr = e;
	}
	vr(e, t) {
		return __PRIVATE_asBigInt(e) - __PRIVATE_asBigInt(t);
	}
	Sr(e, t) {
		return { doubleValue: __PRIVATE_asDouble(e) - __PRIVATE_asDouble(t) };
	}
};
var __PRIVATE_CoreMultiply = class extends __PRIVATE_BigIntOrDoubleArithmetics {
	constructor(e) {
		super(e), this.expr = e;
	}
	vr(e, t) {
		return __PRIVATE_asBigInt(e) * __PRIVATE_asBigInt(t);
	}
	Sr(e, t) {
		return { doubleValue: __PRIVATE_asDouble(e) * __PRIVATE_asDouble(t) };
	}
};
var __PRIVATE_CoreDivide = class extends __PRIVATE_BigIntOrDoubleArithmetics {
	constructor(e) {
		super(e), this.expr = e;
	}
	vr(e, t) {
		const n = __PRIVATE_asBigInt(t);
		if (n !== BigInt(0)) return __PRIVATE_asBigInt(e) / n;
	}
	Sr(e, t) {
		const n = __PRIVATE_asDouble(t);
		return 0 === n ? { doubleValue: __PRIVATE_isNegativeZero(n) ? Number.NEGATIVE_INFINITY : Number.POSITIVE_INFINITY } : { doubleValue: __PRIVATE_asDouble(e) / n };
	}
};
var __PRIVATE_CoreMod = class extends __PRIVATE_BigIntOrDoubleArithmetics {
	constructor(e) {
		super(e), this.expr = e;
	}
	vr(e, t) {
		const n = __PRIVATE_asBigInt(t);
		if (n !== BigInt(0)) return __PRIVATE_asBigInt(e) % n;
	}
	Sr(e, t) {
		const n = __PRIVATE_asDouble(t);
		if (0 !== n) return { doubleValue: __PRIVATE_asDouble(e) % n };
	}
};
var __PRIVATE_CoreAnd = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		let n = false, r = false;
		for (const i of this.expr.params) {
			const s = __PRIVATE_toEvaluable(i).evaluate(e, t);
			switch (s.type) {
				case "BOOLEAN":
					if (!s.value?.booleanValue) return __PRIVATE_EvaluateResult.newValue(Ye);
					break;
				case "NULL":
					r = true;
					break;
				default: n = true;
			}
		}
		return n ? __PRIVATE_EvaluateResult.mr() : r ? __PRIVATE_EvaluateResult.gr() : __PRIVATE_EvaluateResult.newValue(Je);
	}
};
var __PRIVATE_CoreNot = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 9634);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "BOOLEAN": return __PRIVATE_EvaluateResult.newValue({ booleanValue: !n.value?.booleanValue });
			case "NULL": return __PRIVATE_EvaluateResult.gr();
			default: return __PRIVATE_EvaluateResult.mr();
		}
	}
};
var __PRIVATE_CoreOr = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		let n = false, r = false;
		for (const i of this.expr.params) {
			const s = __PRIVATE_toEvaluable(i).evaluate(e, t);
			switch (s.type) {
				case "BOOLEAN":
					if (s.value?.booleanValue) return __PRIVATE_EvaluateResult.newValue(Je);
					break;
				case "NULL":
					r = true;
					break;
				default: n = true;
			}
		}
		return n ? __PRIVATE_EvaluateResult.mr() : r ? __PRIVATE_EvaluateResult.gr() : __PRIVATE_EvaluateResult.newValue(Ye);
	}
};
var __PRIVATE_CoreXor = class __PRIVATE_CoreXor {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		let n = false, r = false;
		for (const i of this.expr.params) {
			const s = __PRIVATE_toEvaluable(i).evaluate(e, t);
			switch (s.type) {
				case "BOOLEAN":
					n = __PRIVATE_CoreXor.xor(n, !!s.value?.booleanValue);
					break;
				case "NULL":
					r = true;
					break;
				default: return __PRIVATE_EvaluateResult.mr();
			}
		}
		return r ? __PRIVATE_EvaluateResult.gr() : __PRIVATE_EvaluateResult.newValue({ booleanValue: n });
	}
	static xor(e, t) {
		return (e || t) && !(e && t);
	}
};
var __PRIVATE_CoreEqAny = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(2 === this.expr.params.length, 55094);
		let n = false;
		const r = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (r.type) {
			case "NULL":
				n = true;
				break;
			case "ERROR":
			case "UNSET": return __PRIVATE_EvaluateResult.mr();
		}
		const i = __PRIVATE_toEvaluable(this.expr.params[1]).evaluate(e, t);
		switch (i.type) {
			case "ARRAY": break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.mr();
		}
		if (n) return __PRIVATE_EvaluateResult.gr();
		for (const e of i.value?.arrayValue?.values ?? []) switch (__PRIVATE_isNullValue(r.value) && __PRIVATE_isNullValue(e) ? "EQ" : __PRIVATE_strictValueEquals(r.value, e)) {
			case "EQ": return __PRIVATE_EvaluateResult.newValue(Je);
			case "NOT_EQ":
			case "TYPE_MISMATCH": break;
			case "NULL":
				n = true;
				break;
			default: l(44608, {
				value: r.value,
				candidate: e
			});
		}
		return n ? __PRIVATE_EvaluateResult.gr() : __PRIVATE_EvaluateResult.newValue(Ye);
	}
};
var __PRIVATE_CoreNotEqAny = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		return new __PRIVATE_CoreNot(new y("not", [new y("equal_any", this.expr.params)])).evaluate(e, t);
	}
};
var __PRIVATE_CoreIsNan = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 23322);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "INT": return __PRIVATE_EvaluateResult.newValue(Ye);
			case "DOUBLE": return __PRIVATE_EvaluateResult.newValue({ booleanValue: isNaN(__PRIVATE_asDouble(n.value)) });
			case "NULL": return __PRIVATE_EvaluateResult.gr();
			default: return __PRIVATE_EvaluateResult.mr();
		}
	}
};
var __PRIVATE_CoreIsNotNan = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 50406);
		return new __PRIVATE_CoreNot(new y("not", [new y("is_nan", this.expr.params)])).evaluate(e, t);
	}
};
var __PRIVATE_CoreIsNull = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 23123);
		switch (__PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t).type) {
			case "NULL": return __PRIVATE_EvaluateResult.newValue(Je);
			case "UNSET":
			case "ERROR": return __PRIVATE_EvaluateResult.mr();
			default: return __PRIVATE_EvaluateResult.newValue(Ye);
		}
	}
};
var __PRIVATE_CoreIsNotNull = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 23167);
		return new __PRIVATE_CoreNot(new y("not", [new y("is_null", this.expr.params)])).evaluate(e, t);
	}
};
var __PRIVATE_CoreIsError = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 5228);
		return "ERROR" === __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t).type ? __PRIVATE_EvaluateResult.newValue(Je) : __PRIVATE_EvaluateResult.newValue(Ye);
	}
};
var __PRIVATE_CoreExists = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 6877);
		switch (__PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t).type) {
			case "ERROR": return __PRIVATE_EvaluateResult.mr();
			case "UNSET": return __PRIVATE_EvaluateResult.newValue(Ye);
			default: return __PRIVATE_EvaluateResult.newValue(Je);
		}
	}
};
var __PRIVATE_CoreCond = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(3 === this.expr.params.length, 11706);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "BOOLEAN": return n.value?.booleanValue ? __PRIVATE_toEvaluable(this.expr.params[1]).evaluate(e, t) : __PRIVATE_toEvaluable(this.expr.params[2]).evaluate(e, t);
			case "NULL": return __PRIVATE_toEvaluable(this.expr.params[2]).evaluate(e, t);
			default: return __PRIVATE_EvaluateResult.mr();
		}
	}
};
var __PRIVATE_CoreLogicalMaximum = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		const n = this.expr.params.map(((n) => __PRIVATE_toEvaluable(n).evaluate(e, t)));
		let r;
		for (const e of n) switch (e.type) {
			case "ERROR":
			case "UNSET":
			case "NULL": continue;
			default: r = void 0 === r || __PRIVATE_valueCompare(e.value, r.value) > 0 ? e : r;
		}
		return void 0 === r ? __PRIVATE_EvaluateResult.gr() : r;
	}
};
var __PRIVATE_CoreLogicalMinimum = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		const n = this.expr.params.map(((n) => __PRIVATE_toEvaluable(n).evaluate(e, t)));
		let r;
		for (const e of n) switch (e.type) {
			case "ERROR":
			case "UNSET":
			case "NULL": continue;
			default: r = void 0 === r || __PRIVATE_valueCompare(e.value, r.value) < 0 ? e : r;
		}
		return void 0 === r ? __PRIVATE_EvaluateResult.gr() : r;
	}
};
var __PRIVATE_ComparisonBase = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(2 === this.expr.params.length, 31033, `${this.expr.name}() function should have exactly 2 params`);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "ERROR":
			case "UNSET": return __PRIVATE_EvaluateResult.mr();
		}
		const r = __PRIVATE_toEvaluable(this.expr.params[1]).evaluate(e, t);
		switch (r.type) {
			case "ERROR":
			case "UNSET": return __PRIVATE_EvaluateResult.mr();
		}
		return this.Fr(n, r);
	}
};
var __PRIVATE_CoreEq = class extends __PRIVATE_ComparisonBase {
	constructor(e) {
		super(e), this.expr = e;
	}
	Fr(e, t) {
		if (e.wr() && t.wr()) return __PRIVATE_EvaluateResult.newValue(Je);
		if (e.wr() || t.wr()) return __PRIVATE_EvaluateResult.newValue(Ye);
		if (__PRIVATE_isNanValue(e.value) || __PRIVATE_isNanValue(t.value)) return __PRIVATE_EvaluateResult.newValue(Ye);
		if (__PRIVATE_typeOrder(e.value) !== __PRIVATE_typeOrder(t.value)) return __PRIVATE_EvaluateResult.newValue(Ye);
		switch (__PRIVATE_strictValueEquals(e.value, t.value)) {
			case "EQ": return __PRIVATE_EvaluateResult.newValue(Je);
			case "NOT_EQ": return __PRIVATE_EvaluateResult.newValue(Ye);
			case "NULL": return __PRIVATE_EvaluateResult.gr();
			default: l(44615, {
				left: e,
				right: t
			});
		}
	}
};
var __PRIVATE_CoreNeq = class extends __PRIVATE_ComparisonBase {
	constructor(e) {
		super(e), this.expr = e;
	}
	Fr(e, t) {
		switch (__PRIVATE_strictValueEquals(e.value, t.value)) {
			case "EQ": return __PRIVATE_EvaluateResult.newValue(Ye);
			case "NOT_EQ":
			case "TYPE_MISMATCH": return __PRIVATE_EvaluateResult.newValue(Je);
			case "NULL": return __PRIVATE_EvaluateResult.gr();
			default: l(44614, {
				left: e,
				right: t
			});
		}
	}
};
var __PRIVATE_CoreLt = class extends __PRIVATE_ComparisonBase {
	constructor(e) {
		super(e), this.expr = e;
	}
	Fr(e, t) {
		return __PRIVATE_typeOrder(e.value) !== __PRIVATE_typeOrder(t.value) || __PRIVATE_isNanValue(e.value) || __PRIVATE_isNanValue(t.value) ? __PRIVATE_EvaluateResult.newValue(Ye) : __PRIVATE_EvaluateResult.newValue({ booleanValue: __PRIVATE_valueCompare(e.value, t.value) < 0 });
	}
};
var __PRIVATE_CoreLte = class extends __PRIVATE_ComparisonBase {
	constructor(e) {
		super(e), this.expr = e;
	}
	Fr(e, t) {
		return __PRIVATE_typeOrder(e.value) !== __PRIVATE_typeOrder(t.value) || __PRIVATE_isNanValue(e.value) || __PRIVATE_isNanValue(t.value) ? __PRIVATE_EvaluateResult.newValue(Ye) : "EQ" === __PRIVATE_strictValueEquals(e.value, t.value) ? __PRIVATE_EvaluateResult.newValue(Je) : __PRIVATE_EvaluateResult.newValue({ booleanValue: __PRIVATE_valueCompare(e.value, t.value) < 0 });
	}
};
var __PRIVATE_CoreGt = class extends __PRIVATE_ComparisonBase {
	constructor(e) {
		super(e), this.expr = e;
	}
	Fr(e, t) {
		return __PRIVATE_typeOrder(e.value) !== __PRIVATE_typeOrder(t.value) || __PRIVATE_isNanValue(e.value) || __PRIVATE_isNanValue(t.value) ? __PRIVATE_EvaluateResult.newValue(Ye) : __PRIVATE_EvaluateResult.newValue({ booleanValue: __PRIVATE_valueCompare(e.value, t.value) > 0 });
	}
};
var __PRIVATE_CoreGte = class extends __PRIVATE_ComparisonBase {
	constructor(e) {
		super(e), this.expr = e;
	}
	Fr(e, t) {
		return __PRIVATE_typeOrder(e.value) !== __PRIVATE_typeOrder(t.value) || __PRIVATE_isNanValue(e.value) || __PRIVATE_isNanValue(t.value) ? __PRIVATE_EvaluateResult.newValue(Ye) : "EQ" === __PRIVATE_strictValueEquals(e.value, t.value) ? __PRIVATE_EvaluateResult.newValue(Je) : __PRIVATE_EvaluateResult.newValue({ booleanValue: __PRIVATE_valueCompare(e.value, t.value) > 0 });
	}
};
var __PRIVATE_CoreArrayConcat = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		throw new Error("Unimplemented");
	}
};
var __PRIVATE_CoreArrayReverse = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 216);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "NULL": return __PRIVATE_EvaluateResult.gr();
			case "ARRAY": {
				const e = n.value.arrayValue?.values ?? [];
				return __PRIVATE_EvaluateResult.newValue({ arrayValue: { values: [...e].reverse() } });
			}
			default: return __PRIVATE_EvaluateResult.mr();
		}
	}
};
var __PRIVATE_CoreArrayContains = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		return __PRIVATE_hardAssert(2 === this.expr.params.length, 52884), new __PRIVATE_CoreEqAny(new y("eq_any", [this.expr.params[1], this.expr.params[0]])).evaluate(e, t);
	}
};
var __PRIVATE_CoreArrayContainsAll = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(2 === this.expr.params.length, 1392);
		let n = false;
		const r = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (r.type) {
			case "ARRAY": break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.mr();
		}
		const i = __PRIVATE_toEvaluable(this.expr.params[1]).evaluate(e, t);
		switch (i.type) {
			case "ARRAY": break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.mr();
		}
		if (n) return __PRIVATE_EvaluateResult.gr();
		const s = i.value?.arrayValue?.values ?? [], _ = r.value?.arrayValue?.values ?? [];
		for (const e of s) {
			let t = false;
			n = false;
			for (const r of _) {
				switch (__PRIVATE_isNullValue(e) && __PRIVATE_isNullValue(r) ? "EQ" : __PRIVATE_strictValueEquals(e, r)) {
					case "EQ":
						t = true;
						break;
					case "NOT_EQ":
					case "TYPE_MISMATCH": break;
					case "NULL":
						n = true;
						break;
					default: l(44613, {
						value: r,
						search: e
					});
				}
				if (t) break;
			}
			if (!t) return __PRIVATE_EvaluateResult.newValue(Ye);
		}
		return __PRIVATE_EvaluateResult.newValue(Je);
	}
};
var __PRIVATE_CoreArrayContainsAny = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(2 === this.expr.params.length, 2680);
		let n = false;
		const r = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (r.type) {
			case "ARRAY": break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.mr();
		}
		const i = __PRIVATE_toEvaluable(this.expr.params[1]).evaluate(e, t);
		switch (i.type) {
			case "ARRAY": break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.mr();
		}
		if (n) return __PRIVATE_EvaluateResult.gr();
		const s = i.value?.arrayValue?.values ?? [], _ = r.value?.arrayValue?.values ?? [];
		for (const e of _) for (const t of s) switch (__PRIVATE_isNullValue(e) && __PRIVATE_isNullValue(t) ? "EQ" : __PRIVATE_strictValueEquals(e, t)) {
			case "EQ": return __PRIVATE_EvaluateResult.newValue(Je);
			case "NOT_EQ":
			case "TYPE_MISMATCH": break;
			case "NULL":
				n = true;
				break;
			default: l(60403, {
				value: e,
				search: t
			});
		}
		return n ? __PRIVATE_EvaluateResult.gr() : __PRIVATE_EvaluateResult.newValue(Ye);
	}
};
var __PRIVATE_CoreArrayLength = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 38605);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "NULL": return __PRIVATE_EvaluateResult.gr();
			case "ARRAY": return __PRIVATE_EvaluateResult.newValue({ integerValue: `${n.value?.arrayValue?.values?.length ?? 0}` });
			default: return __PRIVATE_EvaluateResult.mr();
		}
	}
};
var __PRIVATE_CoreArrayElement = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		throw new Error("Unimplemented");
	}
};
var __PRIVATE_CoreReverse = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 1508);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "NULL": return __PRIVATE_EvaluateResult.gr();
			case "BYTES": {
				const e = n.value?.bytesValue;
				if ("string" == typeof e) {
					const t = ByteString.fromBase64String(e).toUint8Array();
					return t.reverse(), __PRIVATE_EvaluateResult.newValue({ bytesValue: ByteString.fromUint8Array(t).toBase64() });
				}
				return __PRIVATE_EvaluateResult.newValue({ bytesValue: new Uint8Array(e).reverse() });
			}
			case "STRING": {
				const e = n.value?.stringValue, t = new Intl.__PRIVATE_Segmenter(void 0, { granularity: "grapheme" }).segment(e), r = Array.from(t, ((e) => e.segment)).reverse();
				return __PRIVATE_EvaluateResult.newValue({ stringValue: r.join("") });
			}
			default: return __PRIVATE_EvaluateResult.mr();
		}
	}
};
var __PRIVATE_CoreReplaceFirst = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		throw new Error("Unimplemented");
	}
};
var __PRIVATE_CoreReplaceAll = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		throw new Error("Unimplemented");
	}
};
var __PRIVATE_CoreCharLength = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 19400);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "NULL": return __PRIVATE_EvaluateResult.gr();
			case "STRING": {
				const e = function __PRIVATE_getUnicodePointCount(e) {
					let t = 0;
					for (let n = 0; n < e.length; n++) {
						const r = e.codePointAt(n);
						if (void 0 === r) return;
						if (r <= 65535) if (r >= 55296 && r <= 57343) if (r <= 56319) {
							const r = e.codePointAt(n + 1);
							void 0 !== r && r >= 56320 && r <= 57343 ? (t += 1, n++) : t += 1;
						} else t += 1;
						else t += 1;
						else {
							if (!(r <= 1114111)) return;
							t += 1, n++;
						}
					}
					return t;
				}(n.value.stringValue);
				return void 0 === e ? __PRIVATE_EvaluateResult.mr() : __PRIVATE_EvaluateResult.newValue({ integerValue: e });
			}
			default: return __PRIVATE_EvaluateResult.mr();
		}
	}
};
var __PRIVATE_CoreByteLength = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 8486);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "BYTES": {
				const e = n.value?.bytesValue;
				return "string" == typeof e ? __PRIVATE_EvaluateResult.newValue({ integerValue: ByteString.fromBase64String(e).toUint8Array().length }) : __PRIVATE_EvaluateResult.newValue({ integerValue: new Uint8Array(e).length });
			}
			case "STRING": {
				const e = function __PRIVATE_getUtf8ByteLength(e) {
					let t = 0;
					for (let n = 0; n < e.length; n++) {
						const r = e.codePointAt(n);
						if (void 0 === r) return;
						if (r >= 55296 && r <= 57343) {
							if (!(r <= 56319)) return;
							{
								const r = e.codePointAt(n + 1);
								if (void 0 === r || !(r >= 56320 && r <= 57343)) return;
								t += 4, n++;
							}
						} else if (r <= 127) t += 1;
						else if (r <= 2047) t += 2;
						else if (r <= 65535) t += 3;
						else {
							if (!(r <= 1114111)) return;
							t += 4, n++;
						}
					}
					return t;
				}(n.value?.stringValue);
				return void 0 === e ? __PRIVATE_EvaluateResult.mr() : __PRIVATE_EvaluateResult.newValue({ integerValue: e });
			}
			case "NULL": return __PRIVATE_EvaluateResult.gr();
			default: return __PRIVATE_EvaluateResult.mr();
		}
	}
};
var __PRIVATE_StringSearchFunctionBase = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(2 === this.expr.params.length, 39773, `${this.expr.name}() function should have exactly two parameters`);
		let n = false;
		const r = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (r.type) {
			case "STRING": break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.mr();
		}
		const i = __PRIVATE_toEvaluable(this.expr.params[1]).evaluate(e, t);
		switch (i.type) {
			case "STRING": break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.mr();
		}
		return n ? __PRIVATE_EvaluateResult.gr() : this.Or(r.value?.stringValue, i.value?.stringValue);
	}
};
var __PRIVATE_CoreLike = class extends __PRIVATE_StringSearchFunctionBase {
	Or(e, t) {
		try {
			const n = function __PRIVATE_likeToRegex(e) {
				let t = "";
				for (let n = 0; n < e.length; n++) {
					const r = e.charAt(n);
					switch (r) {
						case "_":
							t += ".";
							break;
						case "%":
							t += ".*";
							break;
						case "\\":
						case ".":
						case "*":
						case "?":
						case "+":
						case "^":
						case "$":
						case "|":
						case "(":
						case ")":
						case "[":
						case "]":
						case "{":
						case "}":
							t += "\\" + r;
							break;
						default: t += r;
					}
				}
				return "^" + t + "$";
			}(t), r = RE2JS.compile(n);
			return __PRIVATE_EvaluateResult.newValue({ booleanValue: r.matches(e) });
		} catch (e) {
			return __PRIVATE_logWarn(`Invalid LIKE pattern converted to regex: ${t}, returning error. Error: ${e}`), __PRIVATE_EvaluateResult.mr();
		}
	}
};
var __PRIVATE_CoreRegexContains = class extends __PRIVATE_StringSearchFunctionBase {
	Or(e, t) {
		try {
			const n = RE2JS.compile(t);
			return __PRIVATE_EvaluateResult.newValue({ booleanValue: n.test(e) });
		} catch (e) {
			return __PRIVATE_logWarn(`Invalid regex pattern found in regex_contains: ${t}, returning error`), __PRIVATE_EvaluateResult.mr();
		}
	}
};
var __PRIVATE_CoreRegexMatch = class extends __PRIVATE_StringSearchFunctionBase {
	Or(e, t) {
		try {
			return __PRIVATE_EvaluateResult.newValue({ booleanValue: RE2JS.compile(t).matches(e) });
		} catch (e) {
			return __PRIVATE_logWarn(`Invalid regex pattern found in regex_match: ${t}, returning error`), __PRIVATE_EvaluateResult.mr();
		}
	}
};
var __PRIVATE_CoreStrContains = class extends __PRIVATE_StringSearchFunctionBase {
	Or(e, t) {
		return __PRIVATE_EvaluateResult.newValue({ booleanValue: e.includes(t) });
	}
};
var __PRIVATE_CoreStartsWith = class extends __PRIVATE_StringSearchFunctionBase {
	Or(e, t) {
		return __PRIVATE_EvaluateResult.newValue({ booleanValue: e.startsWith(t) });
	}
};
var __PRIVATE_CoreEndsWith = class extends __PRIVATE_StringSearchFunctionBase {
	Or(e, t) {
		return __PRIVATE_EvaluateResult.newValue({ booleanValue: e.endsWith(t) });
	}
};
var __PRIVATE_CoreToLower = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 29079);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "STRING": return __PRIVATE_EvaluateResult.newValue({ stringValue: n.value?.stringValue?.toLowerCase() });
			case "NULL": return __PRIVATE_EvaluateResult.gr();
			default: return __PRIVATE_EvaluateResult.mr();
		}
	}
};
var __PRIVATE_CoreToUpper = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 60487);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "STRING": return __PRIVATE_EvaluateResult.newValue({ stringValue: n.value?.stringValue?.toUpperCase() });
			case "NULL": return __PRIVATE_EvaluateResult.gr();
			default: return __PRIVATE_EvaluateResult.mr();
		}
	}
};
var __PRIVATE_CoreTrim = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 28544);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "STRING": return __PRIVATE_EvaluateResult.newValue({ stringValue: n.value?.stringValue?.trim() });
			case "NULL": return __PRIVATE_EvaluateResult.gr();
			default: return __PRIVATE_EvaluateResult.mr();
		}
	}
};
var __PRIVATE_CoreStrConcat = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		const n = this.expr.params.map(((n) => __PRIVATE_toEvaluable(n).evaluate(e, t)));
		let r = "", i = false;
		for (const e of n) switch (e.type) {
			case "STRING":
				r += e.value.stringValue;
				break;
			case "NULL":
				i = true;
				break;
			default: return __PRIVATE_EvaluateResult.mr();
		}
		return i ? __PRIVATE_EvaluateResult.gr() : __PRIVATE_EvaluateResult.newValue({ stringValue: r });
	}
};
var __PRIVATE_CoreMapGet = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(2 === this.expr.params.length, 4483);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "UNSET": return __PRIVATE_EvaluateResult.pr();
			case "MAP": break;
			default: return __PRIVATE_EvaluateResult.mr();
		}
		const r = __PRIVATE_toEvaluable(this.expr.params[1]).evaluate(e, t);
		if ("STRING" !== r.type) return __PRIVATE_EvaluateResult.mr();
		const i = n.value?.mapValue?.fields?.[r.value?.stringValue];
		return void 0 === i ? __PRIVATE_EvaluateResult.pr() : __PRIVATE_EvaluateResult.newValue(i);
	}
};
var __PRIVATE_DistanceBase = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(2 === this.expr.params.length, 25231, `${this.expr.name}() function should have exactly 2 params`);
		let n = false;
		const r = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (r.type) {
			case "VECTOR": break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.mr();
		}
		const i = __PRIVATE_toEvaluable(this.expr.params[1]).evaluate(e, t);
		switch (i.type) {
			case "VECTOR": break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.mr();
		}
		if (n) return __PRIVATE_EvaluateResult.gr();
		const s = __PRIVATE_getVectorValue(r.value), _ = __PRIVATE_getVectorValue(i.value);
		if (void 0 === s || void 0 === _ || s.values?.length !== _.values?.length) return __PRIVATE_EvaluateResult.mr();
		const o = this.Mr(s, _);
		return void 0 === o || isNaN(o) ? __PRIVATE_EvaluateResult.mr() : __PRIVATE_EvaluateResult.newValue({ doubleValue: o });
	}
};
var __PRIVATE_CoreCosineDistance = class extends __PRIVATE_DistanceBase {
	Mr(e, t) {
		const n = e?.values ?? [], r = t?.values ?? [];
		if (0 === n.length) return;
		let i = 0, s = 0, _ = 0;
		for (let e = 0; e < n.length; e++) {
			if (!R(n[e]) || !R(r[e])) return;
			const t = __PRIVATE_asDouble(n[e]), o = __PRIVATE_asDouble(r[e]);
			i += t * o, s += t * t, _ += o * o;
		}
		const o = Math.sqrt(s) * Math.sqrt(_);
		if (0 === o) return;
		return 1 - Math.max(-1, Math.min(1, i / o));
	}
};
var __PRIVATE_CoreDotProduct = class extends __PRIVATE_DistanceBase {
	Mr(e, t) {
		const n = e?.values ?? [], r = t?.values ?? [];
		if (0 === n.length) return 0;
		let i = 0;
		for (let e = 0; e < n.length; e++) {
			if (!R(n[e]) || !R(r[e])) return;
			i += __PRIVATE_asDouble(n[e]) * __PRIVATE_asDouble(r[e]);
		}
		return i;
	}
};
var __PRIVATE_CoreEuclideanDistance = class extends __PRIVATE_DistanceBase {
	Mr(e, t) {
		const n = e?.values ?? [], r = t?.values ?? [];
		if (0 === n.length) return 0;
		let i = 0;
		for (let e = 0; e < n.length; e++) {
			if (!R(n[e]) || !R(r[e])) return;
			const t = __PRIVATE_asDouble(n[e]), s = __PRIVATE_asDouble(r[e]);
			i += Math.pow(t - s, 2);
		}
		return Math.sqrt(i);
	}
};
var __PRIVATE_CoreVectorLength = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 39044);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "VECTOR": {
				const e = __PRIVATE_getVectorValue(n.value);
				return __PRIVATE_EvaluateResult.newValue({ integerValue: e?.values?.length ?? 0 });
			}
			case "NULL": return __PRIVATE_EvaluateResult.gr();
			default: return __PRIVATE_EvaluateResult.mr();
		}
	}
};
var Mt = BigInt(-62135596800);
var Nt = BigInt(253402300799);
var Lt = BigInt(1e3);
var Bt = BigInt(1e6);
var Ut = Mt * Lt;
var kt = Nt * Lt + BigInt(999);
var qt = Mt * Bt;
var $t = Nt * Bt + BigInt(999999);
function __PRIVATE_isMicrosInBounds(e) {
	return e >= qt && e <= $t;
}
function __PRIVATE_isSecondsInBounds(e) {
	return e >= Mt && e <= Nt;
}
function __PRIVATE_isTimestampInBounds(e, t) {
	const n = BigInt(e);
	return !(n < Mt || n > Nt) && !(t < 0 || t >= 1e9) && (n !== Mt || 0 === t) && !(n === Nt && t > 999999999);
}
function __PRIVATE_adjustTimestamp(e, t) {
	return t < 0 ? {
		seconds: e - 1,
		nanos: t + 1e9
	} : {
		seconds: e,
		nanos: t
	};
}
function __PRIVATE_timestampToMicros(e) {
	return BigInt(e.seconds) * Bt + BigInt(Math.trunc(e.nanoseconds / 1e3));
}
var __PRIVATE_UnixToTimestamp = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 49262, `${this.expr.name}() function should have exactly one parameter`);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "INT": return this.toTimestamp(BigInt(n.value.integerValue));
			case "NULL": return __PRIVATE_EvaluateResult.gr();
			default: return __PRIVATE_EvaluateResult.mr();
		}
	}
};
var __PRIVATE_CoreUnixMicrosToTimestamp = class extends __PRIVATE_UnixToTimestamp {
	toTimestamp(e) {
		if (!__PRIVATE_isMicrosInBounds(e)) return __PRIVATE_EvaluateResult.mr();
		let t = Number(e / Bt), n = Number(e % Bt * BigInt(1e3));
		const r = __PRIVATE_adjustTimestamp(t, n);
		return t = r.seconds, n = r.nanos, __PRIVATE_isTimestampInBounds(t, n) ? __PRIVATE_EvaluateResult.newValue({ timestampValue: {
			seconds: t,
			nanos: n
		} }) : __PRIVATE_EvaluateResult.mr();
	}
};
var __PRIVATE_CoreUnixMillisToTimestamp = class extends __PRIVATE_UnixToTimestamp {
	toTimestamp(e) {
		if (!function __PRIVATE_isMillisInBounds(e) {
			return e >= Ut && e <= kt;
		}(e)) return __PRIVATE_EvaluateResult.mr();
		let t = Number(e / Lt), n = Number(e % Lt * BigInt(1e6));
		const r = __PRIVATE_adjustTimestamp(t, n);
		return t = r.seconds, n = r.nanos, __PRIVATE_isTimestampInBounds(t, n) ? __PRIVATE_EvaluateResult.newValue({ timestampValue: {
			seconds: t,
			nanos: n
		} }) : __PRIVATE_EvaluateResult.mr();
	}
};
var __PRIVATE_CoreUnixSecondsToTimestamp = class extends __PRIVATE_UnixToTimestamp {
	toTimestamp(e) {
		if (!__PRIVATE_isSecondsInBounds(e)) return __PRIVATE_EvaluateResult.mr();
		const t = Number(e);
		return __PRIVATE_EvaluateResult.newValue({ timestampValue: {
			seconds: t,
			nanos: 0
		} });
	}
};
var __PRIVATE_TimestampToUnix = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(1 === this.expr.params.length, 1265, `${this.expr.name}() function should have exactly one parameter`);
		const n = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (n.type) {
			case "TIMESTAMP": break;
			case "NULL": return __PRIVATE_EvaluateResult.gr();
			default: return __PRIVATE_EvaluateResult.mr();
		}
		const r = fromTimestamp(n.value.timestampValue);
		return __PRIVATE_isTimestampInBounds(r.seconds, r.nanoseconds) ? this.Nr(r) : __PRIVATE_EvaluateResult.mr();
	}
};
var __PRIVATE_CoreTimestampToUnixMicros = class extends __PRIVATE_TimestampToUnix {
	Nr(e) {
		const t = __PRIVATE_timestampToMicros(e);
		return __PRIVATE_isMicrosInBounds(t) ? __PRIVATE_EvaluateResult.newValue({ integerValue: `${t.toString()}` }) : __PRIVATE_EvaluateResult.mr();
	}
};
var __PRIVATE_CoreTimestampToUnixMillis = class extends __PRIVATE_TimestampToUnix {
	Nr(e) {
		const t = __PRIVATE_timestampToMicros(e), n = t / BigInt(1e3), r = t % BigInt(1e3);
		return n > BigInt(0) || r === BigInt(0) ? __PRIVATE_EvaluateResult.newValue({ integerValue: n.toString() }) : __PRIVATE_EvaluateResult.newValue({ integerValue: (n - BigInt(1)).toString() });
	}
};
var __PRIVATE_CoreTimestampToUnixSeconds = class extends __PRIVATE_TimestampToUnix {
	Nr(e) {
		const t = BigInt(e.seconds);
		return __PRIVATE_isSecondsInBounds(t) ? __PRIVATE_EvaluateResult.newValue({ integerValue: t.toString() }) : __PRIVATE_EvaluateResult.mr();
	}
};
var __PRIVATE_TimestampArithmetic = class {
	constructor(e) {
		this.expr = e;
	}
	evaluate(e, t) {
		__PRIVATE_hardAssert(3 === this.expr.params.length, 2775, `${this.expr.name}() function should have exactly 3 parameters`);
		let n = false;
		const r = __PRIVATE_toEvaluable(this.expr.params[0]).evaluate(e, t);
		switch (r.type) {
			case "TIMESTAMP": break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.mr();
		}
		const i = __PRIVATE_toEvaluable(this.expr.params[1]).evaluate(e, t);
		let s;
		switch (i.type) {
			case "STRING":
				if (s = function __PRIVATE_asTimeUnit(e) {
					switch (e) {
						case "microsecond": return "microsecond";
						case "millisecond": return "millisecond";
						case "second": return "second";
						case "minute": return "minute";
						case "hour": return "hour";
						case "day": return "day";
						default: return;
					}
				}(i.value.stringValue), void 0 === s) return __PRIVATE_EvaluateResult.mr();
				break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.mr();
		}
		const _ = __PRIVATE_toEvaluable(this.expr.params[2]).evaluate(e, t);
		switch (_.type) {
			case "INT": break;
			case "NULL":
				n = true;
				break;
			default: return __PRIVATE_EvaluateResult.mr();
		}
		if (n) return __PRIVATE_EvaluateResult.gr();
		const o = BigInt(_.value.integerValue);
		let a;
		try {
			switch (s) {
				case "microsecond":
					a = o;
					break;
				case "millisecond":
					a = o * BigInt(1e3);
					break;
				case "second":
					a = o * BigInt(1e6);
					break;
				case "minute":
					a = o * BigInt(6e7);
					break;
				case "hour":
					a = o * BigInt(36e8);
					break;
				case "day":
					a = o * BigInt(864e8);
					break;
				default: return __PRIVATE_EvaluateResult.mr();
			}
			if ("microsecond" !== s && o !== BigInt(0) && a / o !== BigInt(this.Lr(s))) return __PRIVATE_EvaluateResult.mr();
		} catch (e) {
			return __PRIVATE_logWarn(`Error during timestamp arithmetic: ${e}`), __PRIVATE_EvaluateResult.mr();
		}
		const u = fromTimestamp(r.value.timestampValue);
		if (!__PRIVATE_isTimestampInBounds(u.seconds, u.nanoseconds)) return __PRIVATE_EvaluateResult.mr();
		const c = __PRIVATE_timestampToMicros(u), l = this.Br(c, a);
		if (!__PRIVATE_isMicrosInBounds(l)) return __PRIVATE_EvaluateResult.mr();
		const E = Number(l / Bt), h = l % Bt, T = Number((h < 0 ? h + Bt : h) * BigInt(1e3)), P = h < 0 ? E - 1 : E;
		return __PRIVATE_isTimestampInBounds(P, T) ? __PRIVATE_EvaluateResult.newValue({ timestampValue: {
			seconds: P,
			nanos: T
		} }) : __PRIVATE_EvaluateResult.mr();
	}
	Lr(e) {
		switch (e) {
			case "millisecond": return 1e3;
			case "second": return 1e6;
			case "minute": return 6e7;
			case "hour": return 36e8;
			case "day": return 864e8;
			default: return 1;
		}
	}
};
var __PRIVATE_CoreTimestampAdd = class extends __PRIVATE_TimestampArithmetic {
	Br(e, t) {
		return e + t;
	}
};
var __PRIVATE_CoreTimestampSub = class extends __PRIVATE_TimestampArithmetic {
	Br(e, t) {
		return e - t;
	}
};
/**
* @license
* Copyright 2024 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function __PRIVATE_canonifyExpr(e) {
	if ((e = __PRIVATE_unwrapExpression(e)) instanceof o) return `fld(${e.fieldName})`;
	if (e instanceof Constant) return `cst(${function __PRIVATE_canonifyConstantValue(e) {
		return null === e ? "null" : "number" == typeof e ? e.toString() : "string" == typeof e ? `"${e}"` : e instanceof aa ? `ref(${e.path})` : e instanceof n ? `vec(${JSON.stringify(e)})` : JSON.stringify(e);
	}(e.value)})`;
	if (e instanceof y) return `fn(${e.name},[${e.params.map(__PRIVATE_canonifyExpr).join(",")}])`;
	if ("ListOfExpressions" === e.expressionType) return `list([${e.cr.map(__PRIVATE_canonifyExpr).join(",")}])`;
	throw new Error(`Unrecognized expr ${JSON.stringify(e, null, 2)}`);
}
function __PRIVATE_canonifyStage(e) {
	if (e instanceof w) return `${e._name}(${__PRIVATE_canonifyExprMap(e.fields)})`;
	if (e instanceof O) {
		let t = `${e._name}(${__PRIVATE_canonifyExprMap(e.accumulators)})`;
		return e.groups.size > 0 && (t += `grouping(${__PRIVATE_canonifyExprMap(e.groups)})`), t;
	}
	if (e instanceof M) return `${e._name}(${__PRIVATE_canonifyExprMap(e.groups)})`;
	if (e instanceof X) return `${e._name}(${e.hr})`;
	if (e instanceof Y) return `${e._name}(${e.collectionId})`;
	if (e instanceof Z) return `${e._name}()`;
	if (e instanceof sa) return `${e._name}(${e.Tr.sort()})`;
	if (e instanceof A) return `${e._name}(${__PRIVATE_canonifyExpr(e.condition)})`;
	if (e instanceof v) return `${e._name}(${e.limit})`;
	if (e instanceof L) return `${e._name}(${function __PRIVATE_canonifySortOrderings(e) {
		return e.map(((e) => `${__PRIVATE_canonifyExpr(e.expr)}${e.direction}`)).join(",");
	}(e.orderings)})`;
	throw new Error(`Unrecognized stage ${e._name}`);
}
function __PRIVATE_canonifyExprMap(e) {
	return `${Array.from(e.entries()).sort().map((([e, t]) => `${e}=${__PRIVATE_canonifyExpr(t)}`)).join(",")}`;
}
function __PRIVATE_canonifyPipeline(e) {
	return e.stages.map(((e) => __PRIVATE_canonifyStage(e))).join("|");
}
function __PRIVATE_pipelineEq(e, t) {
	return __PRIVATE_canonifyPipeline(e) === __PRIVATE_canonifyPipeline(t);
}
function __PRIVATE_isPipeline(e) {
	return e instanceof CorePipeline;
}
function __PRIVATE_stringifyQueryOrPipeline(e) {
	return __PRIVATE_isPipeline(e) ? __PRIVATE_canonifyPipeline(e) : __PRIVATE_stringifyQuery(e);
}
function __PRIVATE_canonifyQueryOrPipeline(e) {
	return __PRIVATE_isPipeline(e) ? __PRIVATE_canonifyPipeline(e) : function __PRIVATE_canonifyQuery(e) {
		return `${__PRIVATE_canonifyTarget(__PRIVATE_queryToTarget(e))}|lt:${e.limitType}`;
	}(e);
}
function __PRIVATE_queryOrPipelineEqual(e, t) {
	return e instanceof CorePipeline && t instanceof CorePipeline ? __PRIVATE_pipelineEq(e, t) : !(e instanceof CorePipeline && !(t instanceof CorePipeline) || !(e instanceof CorePipeline) && t instanceof CorePipeline) && __PRIVATE_queryEquals(e, t);
}
function __PRIVATE_canonifyTargetOrPipeline(e) {
	return __PRIVATE_targetIsPipelineTarget(e) ? __PRIVATE_canonifyPipeline(e) : __PRIVATE_canonifyTarget(e);
}
function __PRIVATE_targetOrPipelineEqual(e, t) {
	return e instanceof CorePipeline && t instanceof CorePipeline ? __PRIVATE_pipelineEq(e, t) : !(e instanceof CorePipeline && !(t instanceof CorePipeline) || !(e instanceof CorePipeline) && t instanceof CorePipeline) && __PRIVATE_targetEquals(e, t);
}
function __PRIVATE_toCorePipeline(e, t) {
	const n = function __PRIVATE_rewriteStages(e) {
		let t = false;
		const n = [];
		for (const r of e) if (r instanceof L) if (t = true, r.orderings.some(((e) => e.expr instanceof o && e.expr.fieldName === Ce))) n.push(r);
		else {
			const e = r.orderings.map(((e) => e));
			e.push(s(Ce).ascending()), n.push(new L(e, {}));
		}
		else r instanceof v ? (t || (n.push(new L([s(Ce).ascending()], {})), t = true), n.push(r)) : n.push(r);
		return t || n.push(new L([s(Ce).ascending()], {})), n;
	}(e.stages);
	if (e.userDataReader) {
		const t = e.userDataReader.createContext(3, "toCorePipeline");
		n.forEach(((e) => e._readUserData(t)));
	}
	return new CorePipeline(e.userDataReader.serializer, n, t);
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A batch of mutations that will be sent as one unit to the backend.
*/ var MutationBatch = class {
	/**
	* @param batchId - The unique ID of this mutation batch.
	* @param localWriteTime - The original write time of this mutation.
	* @param baseMutations - Mutations that are used to populate the base
	* values when this mutation is applied locally. This can be used to locally
	* overwrite values that are persisted in the remote document cache. Base
	* mutations are never sent to the backend.
	* @param mutations - The user-provided mutations in this mutation batch.
	* User-provided mutations are applied both locally and remotely on the
	* backend.
	*/
	constructor(e, t, n, r) {
		this.batchId = e, this.localWriteTime = t, this.baseMutations = n, this.mutations = r;
	}
	/**
	* Applies all the mutations in this MutationBatch to the specified document
	* to compute the state of the remote document
	*
	* @param document - The document to apply mutations to.
	* @param batchResult - The result of applying the MutationBatch to the
	* backend.
	*/ applyToRemoteDocument(e, t) {
		const n = t.mutationResults;
		for (let t = 0; t < this.mutations.length; t++) {
			const r = this.mutations[t];
			if (r.key.isEqual(e.key)) __PRIVATE_mutationApplyToRemoteDocument(r, e, n[t]);
		}
	}
	/**
	* Computes the local view of a document given all the mutations in this
	* batch.
	*
	* @param document - The document to apply mutations to.
	* @param mutatedFields - Fields that have been updated before applying this mutation batch.
	* @returns A `FieldMask` representing all the fields that are mutated.
	*/ applyToLocalView(e, t) {
		for (const n of this.baseMutations) n.key.isEqual(e.key) && (t = __PRIVATE_mutationApplyToLocalView(n, e, t, this.localWriteTime));
		for (const n of this.mutations) n.key.isEqual(e.key) && (t = __PRIVATE_mutationApplyToLocalView(n, e, t, this.localWriteTime));
		return t;
	}
	/**
	* Computes the local view for all provided documents given the mutations in
	* this batch. Returns a `DocumentKey` to `Mutation` map which can be used to
	* replace all the mutation applications.
	*/ applyToLocalDocumentSet(e, t) {
		const n = __PRIVATE_newMutationMap();
		return this.mutations.forEach(((r) => {
			const i = e.get(r.key), s = i.overlayedDocument;
			let _ = this.applyToLocalView(s, i.mutatedFields);
			_ = t.has(r.key) ? null : _;
			const o = __PRIVATE_calculateOverlayMutation(s, _);
			null !== o && n.set(r.key, o), s.isValidDocument() || s.convertToNoDocument(SnapshotVersion.min());
		})), n;
	}
	keys() {
		return this.mutations.reduce(((e, t) => e.add(t.key)), __PRIVATE_documentKeySet());
	}
	isEqual(e) {
		return this.batchId === e.batchId && __PRIVATE_arrayEquals(this.mutations, e.mutations, ((e, t) => __PRIVATE_mutationEquals(e, t))) && __PRIVATE_arrayEquals(this.baseMutations, e.baseMutations, ((e, t) => __PRIVATE_mutationEquals(e, t)));
	}
};
/** The result of applying a mutation batch to the backend. */ var MutationBatchResult = class MutationBatchResult {
	constructor(e, t, n, r) {
		this.batch = e, this.commitVersion = t, this.mutationResults = n, this.docVersions = r;
	}
	/**
	* Creates a new MutationBatchResult for the given batch and results. There
	* must be one result for each mutation in the batch. This static factory
	* caches a document=&gt;version mapping (docVersions).
	*/ static from(e, t, n) {
		__PRIVATE_hardAssert(e.mutations.length === n.length, 58842, {
			Ur: e.mutations.length,
			kr: n.length
		});
		let r = function __PRIVATE_documentVersionMap() {
			return it;
		}();
		const i = e.mutations;
		for (let e = 0; e < i.length; e++) r = r.insert(i[e].key, n[e].version);
		return new MutationBatchResult(e, t, n, r);
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var Kt = "";
/**
* Encodes a resource path into a IndexedDb-compatible string form.
*/
function __PRIVATE_encodeResourcePath(e) {
	let t = "";
	for (let n = 0; n < e.length; n++) t.length > 0 && (t = __PRIVATE_encodeSeparator(t)), t = __PRIVATE_encodeSegment(e.get(n), t);
	return __PRIVATE_encodeSeparator(t);
}
/** Encodes a single segment of a resource path into the given result */ function __PRIVATE_encodeSegment(e, t) {
	let n = t;
	const r = e.length;
	for (let t = 0; t < r; t++) {
		const r = e.charAt(t);
		switch (r) {
			case "\0":
				n += "";
				break;
			case Kt:
				n += "";
				break;
			default: n += r;
		}
	}
	return n;
}
/** Encodes a path separator into the given result */ function __PRIVATE_encodeSeparator(e) {
	return e + "";
}
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Representation of an overlay computed by Firestore.
*
* Holds information about a mutation and the largest batch id in Firestore when
* the mutation was created.
*/ var Overlay = class {
	constructor(e, t) {
		this.largestBatchId = e, this.mutation = t;
	}
	getKey() {
		return this.mutation.key;
	}
	isEqual(e) {
		return null !== e && this.mutation === e.mutation;
	}
	toString() {
		return `Overlay{\n      largestBatchId: ${this.largestBatchId},\n      mutation: ${this.mutation.toString()}\n    }`;
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An immutable set of metadata that the local store tracks for each target.
*/ var TargetData = class TargetData {
	constructor(e, t, n, r, i = SnapshotVersion.min(), s = SnapshotVersion.min(), _ = ByteString.EMPTY_BYTE_STRING, o = null) {
		this.target = e, this.targetId = t, this.purpose = n, this.sequenceNumber = r, this.snapshotVersion = i, this.lastLimboFreeSnapshotVersion = s, this.resumeToken = _, this.expectedCount = o;
	}
	/** Creates a new target data instance with an updated sequence number. */ withSequenceNumber(e) {
		return new TargetData(this.target, this.targetId, this.purpose, e, this.snapshotVersion, this.lastLimboFreeSnapshotVersion, this.resumeToken, this.expectedCount);
	}
	/**
	* Creates a new target data instance with an updated resume token and
	* snapshot version.
	*/ withResumeToken(e, t) {
		return new TargetData(this.target, this.targetId, this.purpose, this.sequenceNumber, t, this.lastLimboFreeSnapshotVersion, e, null);
	}
	/**
	* Creates a new target data instance with an updated expected count.
	*/ withExpectedCount(e) {
		return new TargetData(this.target, this.targetId, this.purpose, this.sequenceNumber, this.snapshotVersion, this.lastLimboFreeSnapshotVersion, this.resumeToken, e);
	}
	/**
	* Creates a new target data instance with an updated last limbo free
	* snapshot version number.
	*/ withLastLimboFreeSnapshotVersion(e) {
		return new TargetData(this.target, this.targetId, this.purpose, this.sequenceNumber, this.snapshotVersion, e, this.resumeToken, this.expectedCount);
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/** Serializer for values stored in the LocalStore. */ var __PRIVATE_LocalSerializer = class {
	constructor(e) {
		this.$r = e;
	}
};
/**
* Encodes a `BundledQuery` from bundle proto to a Query object.
*
* This reconstructs the original query used to build the bundle being loaded,
* including features exists only in SDKs (for example: limit-to-last).
*/
function __PRIVATE_fromBundledQuery(e) {
	const t = __PRIVATE_convertQueryTargetToQuery({
		parent: e.parent,
		structuredQuery: e.structuredQuery
	});
	return "LAST" === e.limitType ? __PRIVATE_queryWithLimit(t, t.limit, "L") : t;
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2024 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2021 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/** Firestore index value writer.  */
var __PRIVATE_FirestoreIndexValueWriter = class {
	constructor() {}
	/** Writes an index value.  */
	ei(e, t) {
		this.ti(e, t), t.ni();
	}
	ti(e, t) {
		if ("nullValue" in e) this.ri(t, 5);
		else if ("booleanValue" in e) this.ri(t, 10), t.ii(e.booleanValue ? 1 : 0);
		else if ("integerValue" in e) this.ri(t, 15), t.ii(__PRIVATE_normalizeNumber(e.integerValue));
		else if ("doubleValue" in e) {
			const n = __PRIVATE_normalizeNumber(e.doubleValue);
			isNaN(n) ? this.ri(t, 13) : (this.ri(t, 15), __PRIVATE_isNegativeZero(n) ? t.ii(0) : t.ii(n));
		} else if ("timestampValue" in e) {
			let n = e.timestampValue;
			this.ri(t, 20), "string" == typeof n && (n = __PRIVATE_normalizeTimestamp(n)), t.si(`${n.seconds || ""}`), t.ii(n.nanos || 0);
		} else if ("stringValue" in e) this._i(e.stringValue, t), this.oi(t);
		else if ("bytesValue" in e) this.ri(t, 30), t.ai(__PRIVATE_normalizeByteString(e.bytesValue)), this.oi(t);
		else if ("referenceValue" in e) this.ui(e.referenceValue, t);
		else if ("geoPointValue" in e) {
			const n = e.geoPointValue;
			this.ri(t, 45), t.ii(n.latitude || 0), t.ii(n.longitude || 0);
		} else "mapValue" in e ? __PRIVATE_isMaxValue(e) ? this.ri(t, Number.MAX_SAFE_INTEGER) : __PRIVATE_isVectorValue(e) ? this.ci(e.mapValue, t) : (this.li(e.mapValue, t), this.oi(t)) : "arrayValue" in e ? (this.Ei(e.arrayValue, t), this.oi(t)) : l(19022, { hi: e });
	}
	_i(e, t) {
		this.ri(t, 25), this.Ti(e, t);
	}
	Ti(e, t) {
		t.si(e);
	}
	li(e, t) {
		const n = e.fields || {};
		this.ri(t, 55);
		for (const e of Object.keys(n)) this._i(e, t), this.ti(n[e], t);
	}
	ci(e, t) {
		const n = e.fields || {};
		this.ri(t, 53);
		const r = je, i = n[r].arrayValue?.values?.length || 0;
		this.ri(t, 15), t.ii(__PRIVATE_normalizeNumber(i)), this._i(r, t), this.ti(n[r], t);
	}
	Ei(e, t) {
		const n = e.values || [];
		this.ri(t, 50);
		for (const e of n) this.ti(e, t);
	}
	ui(e, t) {
		this.ri(t, 37);
		DocumentKey.fromName(e).path.forEach(((e) => {
			this.ri(t, 60), this.Ti(e, t);
		}));
	}
	ri(e, t) {
		e.ii(t);
	}
	oi(e) {
		e.ii(2);
	}
};
__PRIVATE_FirestoreIndexValueWriter.Pi = new __PRIVATE_FirestoreIndexValueWriter();
/**
* @license
* Copyright 2021 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law | agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES | CONDITIONS OF ANY KIND, either express | implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An in-memory implementation of IndexManager.
*/ var __PRIVATE_MemoryIndexManager = class {
	constructor() {
		this.Zi = new __PRIVATE_MemoryCollectionParentIndex();
	}
	addToCollectionParentIndex(e, t) {
		return this.Zi.add(t), PersistencePromise.resolve();
	}
	getCollectionParents(e, t) {
		return PersistencePromise.resolve(this.Zi.getEntries(t));
	}
	addFieldIndex(e, t) {
		return PersistencePromise.resolve();
	}
	deleteFieldIndex(e, t) {
		return PersistencePromise.resolve();
	}
	deleteAllFieldIndexes(e) {
		return PersistencePromise.resolve();
	}
	createTargetIndexes(e, t) {
		return PersistencePromise.resolve();
	}
	getDocumentsMatchingTarget(e, t) {
		return PersistencePromise.resolve(null);
	}
	getIndexType(e, t) {
		return PersistencePromise.resolve(0);
	}
	getFieldIndexes(e, t) {
		return PersistencePromise.resolve([]);
	}
	getNextCollectionGroupToUpdate(e) {
		return PersistencePromise.resolve(null);
	}
	getMinOffset(e, t) {
		return PersistencePromise.resolve(IndexOffset.min());
	}
	getMinOffsetFromCollectionGroup(e, t) {
		return PersistencePromise.resolve(IndexOffset.min());
	}
	updateCollectionGroup(e, t, n) {
		return PersistencePromise.resolve();
	}
	updateIndexEntries(e, t) {
		return PersistencePromise.resolve();
	}
};
/**
* Internal implementation of the collection-parent index exposed by MemoryIndexManager.
* Also used for in-memory caching by IndexedDbIndexManager and initial index population
* in indexeddb_schema.ts
*/ var __PRIVATE_MemoryCollectionParentIndex = class {
	constructor() {
		this.index = {};
	}
	add(e) {
		const t = e.lastSegment(), n = e.popLast(), r = this.index[t] || new SortedSet(ResourcePath.comparator), i = !r.has(n);
		return this.index[t] = r.add(n), i;
	}
	has(e) {
		const t = e.lastSegment(), n = e.popLast(), r = this.index[t];
		return r && r.has(n);
	}
	getEntries(e) {
		return (this.index[e] || new SortedSet(ResourcePath.comparator)).toArray();
	}
};
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/** Offset to ensure non-overlapping target ids. */
/**
* Generates monotonically increasing target IDs for sending targets to the
* watch stream.
*
* The client constructs two generators, one for the target cache, and one for
* for the sync engine (to generate limbo documents targets). These
* generators produce non-overlapping IDs (by using even and odd IDs
* respectively).
*
* By separating the target ID space, the query cache can generate target IDs
* that persist across client restarts, while sync engine can independently
* generate in-memory target IDs that are transient and can be reused after a
* restart.
*/
var __PRIVATE_TargetIdGenerator = class __PRIVATE_TargetIdGenerator {
	constructor(e) {
		this.ys = e;
	}
	next() {
		return this.ys += 2, this.ys;
	}
	static ws() {
		return new __PRIVATE_TargetIdGenerator(0);
	}
	static bs() {
		return new __PRIVATE_TargetIdGenerator(-1);
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function __PRIVATE_runPipeline(e, t) {
	let n = t;
	for (const t of e.stages) n = evaluate({
		serializer: e.serializer,
		serverTimestampBehavior: e.listenOptions?.serverTimestampBehavior
	}, t, n);
	return n;
}
function __PRIVATE_pipelineMatches(e, t) {
	return __PRIVATE_runPipeline(e, [t]).length > 0;
}
function __PRIVATE_queryOrPipelineMatches(e, t) {
	return __PRIVATE_isPipeline(e) ? __PRIVATE_pipelineMatches(e, t) : __PRIVATE_queryMatches(e, t);
}
function evaluate(e, t, n) {
	if (t instanceof X) return function __PRIVATE_evaluateCollection(e, t, n) {
		return n.filter(((e) => e.isFoundDocument() && `/${e.key.getCollectionPath().canonicalString()}` === t.hr));
	}(0, t, n);
	if (t instanceof A) return function __PRIVATE_evaluateWhere(e, t, n) {
		return n.filter(((n) => {
			const r = __PRIVATE_valueOrUndefined(__PRIVATE_toEvaluable(t.condition).evaluate(e, n));
			return void 0 !== r && __PRIVATE_valueEquals$1(r, Je);
		}));
	}(e, t, n);
	if (t instanceof Y) return function __PRIVATE_evaluateCollectionGroup(e, t, n) {
		return n.filter(((e) => e.isFoundDocument() && e.key.getCollectionPath().lastSegment() === t.collectionId));
	}(0, t, n);
	if (t instanceof Z) return function __PRIVATE_evaluateDatabase(e, t, n) {
		return n.filter(((e) => e.isFoundDocument()));
	}(0, 0, n);
	if (t instanceof sa) return function __PRIVATE_evaluateDocuments(e, t, n) {
		return n.filter(((e) => e.isFoundDocument() && t.Pr.has(e.key.path.toStringWithLeadingSlash())));
	}(0, t, n);
	if (t instanceof v) return function __PRIVATE_evaluateLimit(e, t, n) {
		return n.slice(0, t.limit);
	}(0, t, n);
	if (t instanceof L) return function __PRIVATE_evaluateSort(e, t, n) {
		const r = t.orderings.map(((e) => ({
			Ms: __PRIVATE_toEvaluable(e.expr),
			direction: e.direction
		})));
		return [...n].sort(((t, n) => {
			for (const { Ms: i, direction: s } of r) {
				const r = __PRIVATE_valueOrUndefined(i.evaluate(e, t)), _ = __PRIVATE_valueOrUndefined(i.evaluate(e, n)), o = __PRIVATE_valueCompare(r ?? He, _ ?? He);
				if (0 !== o) return "ascending" === s ? o : -o;
			}
			return 0;
		}));
	}(e, t, n);
	throw new Error(`Unknown stage: ${t._name}`);
}
function __PRIVATE_newPipelineComparator(e) {
	const t = function __PRIVATE_lastEffectiveSort(e) {
		for (let t = e.stages.length - 1; t >= 0; t--) {
			const n = e.stages[t];
			if (n instanceof L) return n.orderings;
		}
		throw new Error("Pipeline must contain at least one Sort stage");
	}(e);
	return (n, r) => {
		for (const i of t) {
			const t = __PRIVATE_valueOrUndefined(__PRIVATE_toEvaluable(i.expr).evaluate({ serializer: e.serializer }, n)), s = __PRIVATE_valueOrUndefined(__PRIVATE_toEvaluable(i.expr).evaluate({ serializer: e.serializer }, r)), _ = __PRIVATE_valueCompare(t || He, s || He);
			if (0 !== _) return "ascending" === i.direction ? _ : -_;
		}
		return 0;
	};
}
function __PRIVATE_getLastEffectiveLimit(e) {
	for (let t = e.stages.length - 1; t >= 0; t--) {
		const n = e.stages[t];
		if (n instanceof v) return { limit: n.limit };
	}
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An in-memory buffer of entries to be written to a RemoteDocumentCache.
* It can be used to batch up a set of changes to be written to the cache, but
* additionally supports reading entries back with the `getEntry()` method,
* falling back to the underlying RemoteDocumentCache if no entry is
* buffered.
*
* Entries added to the cache *must* be read first. This is to facilitate
* calculating the size delta of the pending changes.
*
* PORTING NOTE: This class was implemented then removed from other platforms.
* If byte-counting ends up being needed on the other platforms, consider
* porting this class as part of that implementation work.
*/ var RemoteDocumentChangeBuffer = class {
	constructor() {
		this.changes = new ObjectMap(((e) => e.toString()), ((e, t) => e.isEqual(t))), this.changesApplied = false;
	}
	/**
	* Buffers a `RemoteDocumentCache.addEntry()` call.
	*
	* You can only modify documents that have already been retrieved via
	* `getEntry()/getEntries()` (enforced via IndexedDbs `apply()`).
	*/ addEntry(e) {
		this.assertNotApplied(), this.changes.set(e.key, e);
	}
	/**
	* Buffers a `RemoteDocumentCache.removeEntry()` call.
	*
	* You can only remove documents that have already been retrieved via
	* `getEntry()/getEntries()` (enforced via IndexedDbs `apply()`).
	*/ removeEntry(e, t) {
		this.assertNotApplied(), this.changes.set(e, MutableDocument.newInvalidDocument(e).setReadTime(t));
	}
	/**
	* Looks up an entry in the cache. The buffered changes will first be checked,
	* and if no buffered change applies, this will forward to
	* `RemoteDocumentCache.getEntry()`.
	*
	* @param transaction - The transaction in which to perform any persistence
	*     operations.
	* @param documentKey - The key of the entry to look up.
	* @returns The cached document or an invalid document if we have nothing
	* cached.
	*/ getEntry(e, t) {
		this.assertNotApplied();
		const n = this.changes.get(t);
		return void 0 !== n ? PersistencePromise.resolve(n) : this.getFromCache(e, t);
	}
	/**
	* Looks up several entries in the cache, forwarding to
	* `RemoteDocumentCache.getEntry()`.
	*
	* @param transaction - The transaction in which to perform any persistence
	*     operations.
	* @param documentKeys - The keys of the entries to look up.
	* @returns A map of cached documents, indexed by key. If an entry cannot be
	*     found, the corresponding key will be mapped to an invalid document.
	*/ getEntries(e, t) {
		return this.getAllFromCache(e, t);
	}
	/**
	* Applies buffered changes to the underlying RemoteDocumentCache, using
	* the provided transaction.
	*/ apply(e) {
		return this.assertNotApplied(), this.changesApplied = true, this.applyChanges(e);
	}
	/** Helper to assert this.changes is not null  */ assertNotApplied() {}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Schema Version for the Web client:
* 1.  Initial version including Mutation Queue, Query Cache, and Remote
*     Document Cache
* 2.  Used to ensure a targetGlobal object exists and add targetCount to it. No
*     longer required because migration 3 unconditionally clears it.
* 3.  Dropped and re-created Query Cache to deal with cache corruption related
*     to limbo resolution. Addresses
*     https://github.com/firebase/firebase-ios-sdk/issues/1548
* 4.  Multi-Tab Support.
* 5.  Removal of held write acks.
* 6.  Create document global for tracking document cache size.
* 7.  Ensure every cached document has a sentinel row with a sequence number.
* 8.  Add collection-parent index for Collection Group queries.
* 9.  Change RemoteDocumentChanges store to be keyed by readTime rather than
*     an auto-incrementing ID. This is required for Index-Free queries.
* 10. Rewrite the canonical IDs to the explicit Protobuf-based format.
* 11. Add bundles and named_queries for bundle support.
* 12. Add document overlays.
* 13. Rewrite the keys of the remote document cache to allow for efficient
*     document lookup via `getAll()`.
* 14. Add overlays.
* 15. Add indexing support.
* 16. Parse timestamp strings before creating index entries.
* 17. TODO(tomandersen)
* 18. Encode key safe representations of IndexEntry in DbIndexEntryStore.
*/
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Represents a local view (overlay) of a document, and the fields that are
* locally mutated.
*/
var OverlayedDocument = class {
	constructor(e, t) {
		this.overlayedDocument = e, this.mutatedFields = t;
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A readonly view of the local state of all documents we're tracking (i.e. we
* have a cached version in remoteDocumentCache or local mutations for the
* document). The view is computed by applying the mutations in the
* MutationQueue to the RemoteDocumentCache.
*/ var LocalDocumentsView = class {
	constructor(e, t, n, r) {
		this.remoteDocumentCache = e, this.mutationQueue = t, this.documentOverlayCache = n, this.indexManager = r;
	}
	/**
	* Get the local view of the document identified by `key`.
	*
	* @returns Local view of the document or null if we don't have any cached
	* state for it.
	*/ getDocument(e, t) {
		let n = null;
		return this.documentOverlayCache.getOverlay(e, t).next(((r) => (n = r, this.remoteDocumentCache.getEntry(e, t)))).next(((e) => (null !== n && __PRIVATE_mutationApplyToLocalView(n.mutation, e, FieldMask.empty(), Timestamp.now()), e)));
	}
	/**
	* Gets the local view of the documents identified by `keys`.
	*
	* If we don't have cached state for a document in `keys`, a NoDocument will
	* be stored for that key in the resulting set.
	*/ getDocuments(e, t) {
		return this.remoteDocumentCache.getEntries(e, t).next(((t) => this.getLocalViewOfDocuments(e, t, __PRIVATE_documentKeySet()).next((() => t))));
	}
	/**
	* Similar to `getDocuments`, but creates the local view from the given
	* `baseDocs` without retrieving documents from the local store.
	*
	* @param transaction - The transaction this operation is scoped to.
	* @param docs - The documents to apply local mutations to get the local views.
	* @param existenceStateChanged - The set of document keys whose existence state
	*   is changed. This is useful to determine if some documents overlay needs
	*   to be recalculated.
	*/ getLocalViewOfDocuments(e, t, n = __PRIVATE_documentKeySet()) {
		const r = __PRIVATE_newOverlayMap();
		return this.populateOverlays(e, r, t).next((() => this.computeViews(e, t, r, n).next(((e) => {
			let t = documentMap();
			return e.forEach(((e, n) => {
				t = t.insert(e, n.overlayedDocument);
			})), t;
		}))));
	}
	/**
	* Gets the overlayed documents for the given document map, which will include
	* the local view of those documents and a `FieldMask` indicating which fields
	* are mutated locally, `null` if overlay is a Set or Delete mutation.
	*/ getOverlayedDocuments(e, t) {
		const n = __PRIVATE_newOverlayMap();
		return this.populateOverlays(e, n, t).next((() => this.computeViews(e, t, n, __PRIVATE_documentKeySet())));
	}
	/**
	* Fetches the overlays for {@code docs} and adds them to provided overlay map
	* if the map does not already contain an entry for the given document key.
	*/ populateOverlays(e, t, n) {
		const r = [];
		return n.forEach(((e) => {
			t.has(e) || r.push(e);
		})), this.documentOverlayCache.getOverlays(e, r).next(((e) => {
			e.forEach(((e, n) => {
				t.set(e, n);
			}));
		}));
	}
	/**
	* Computes the local view for the given documents.
	*
	* @param docs - The documents to compute views for. It also has the base
	*   version of the documents.
	* @param overlays - The overlays that need to be applied to the given base
	*   version of the documents.
	* @param existenceStateChanged - A set of documents whose existence states
	*   might have changed. This is used to determine if we need to re-calculate
	*   overlays from mutation queues.
	* @returns A map represents the local documents view.
	*/ computeViews(e, t, n, r) {
		let i = __PRIVATE_mutableDocumentMap();
		const s = __PRIVATE_newDocumentKeyMap(), _ = function __PRIVATE_newOverlayedDocumentMap() {
			return __PRIVATE_newDocumentKeyMap();
		}();
		return t.forEach(((e, t) => {
			const _ = n.get(t.key);
			r.has(t.key) && (void 0 === _ || _.mutation instanceof __PRIVATE_PatchMutation) ? i = i.insert(t.key, t) : void 0 !== _ ? (s.set(t.key, _.mutation.getFieldMask()), __PRIVATE_mutationApplyToLocalView(_.mutation, t, _.mutation.getFieldMask(), Timestamp.now())) : s.set(t.key, FieldMask.empty());
		})), this.recalculateAndSaveOverlays(e, i).next(((e) => (e.forEach(((e, t) => s.set(e, t))), t.forEach(((e, t) => _.set(e, new OverlayedDocument(t, s.get(e) ?? null)))), _)));
	}
	recalculateAndSaveOverlays(e, t) {
		const n = __PRIVATE_newDocumentKeyMap();
		let r = new SortedMap(((e, t) => e - t)), i = __PRIVATE_documentKeySet();
		return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e, t).next(((e) => {
			for (const i of e) i.keys().forEach(((e) => {
				const s = t.get(e);
				if (null === s) return;
				let _ = n.get(e) || FieldMask.empty();
				_ = i.applyToLocalView(s, _), n.set(e, _);
				const o = (r.get(i.batchId) || __PRIVATE_documentKeySet()).add(e);
				r = r.insert(i.batchId, o);
			}));
		})).next((() => {
			const s = [], _ = r.getReverseIterator();
			for (; _.hasNext();) {
				const r = _.getNext(), o = r.key, a = r.value, u = __PRIVATE_newMutationMap();
				a.forEach(((e) => {
					if (!i.has(e)) {
						const r = __PRIVATE_calculateOverlayMutation(t.get(e), n.get(e));
						null !== r && u.set(e, r), i = i.add(e);
					}
				})), s.push(this.documentOverlayCache.saveOverlays(e, o, u));
			}
			return PersistencePromise.waitFor(s);
		})).next((() => n));
	}
	/**
	* Recalculates overlays by reading the documents from remote document cache
	* first, and saves them after they are calculated.
	*/ recalculateAndSaveOverlaysForDocumentKeys(e, t) {
		return this.remoteDocumentCache.getEntries(e, t).next(((t) => this.recalculateAndSaveOverlays(e, t)));
	}
	/**
	* Performs a query against the local view of all documents.
	*
	* @param transaction - The persistence transaction.
	* @param query - The query to match documents against.
	* @param offset - Read time and key to start scanning by (exclusive).
	* @param context - A optional tracker to keep a record of important details
	*   during database local query execution.
	*/ getDocumentsMatchingQuery(e, t, n, r) {
		return __PRIVATE_isPipeline(t) ? this.getDocumentsMatchingPipeline(e, t, n, r) : __PRIVATE_isDocumentQuery$1(t) ? this.getDocumentsMatchingDocumentQuery(e, t.path) : __PRIVATE_isCollectionGroupQuery(t) ? this.getDocumentsMatchingCollectionGroupQuery(e, t, n, r) : this.getDocumentsMatchingCollectionQuery(e, t, n, r);
	}
	/**
	* Given a collection group, returns the next documents that follow the provided offset, along
	* with an updated batch ID.
	*
	* <p>The documents returned by this method are ordered by remote version from the provided
	* offset. If there are no more remote documents after the provided offset, documents with
	* mutations in order of batch id from the offset are returned. Since all documents in a batch are
	* returned together, the total number of documents returned can exceed {@code count}.
	*
	* @param transaction
	* @param collectionGroup - The collection group for the documents.
	* @param offset - The offset to index into.
	* @param count - The number of documents to return
	* @returns A LocalWriteResult with the documents that follow the provided offset and the last processed batch id.
	*/ getNextDocuments(e, t, n, r) {
		return this.remoteDocumentCache.getAllFromCollectionGroup(e, t, n, r).next(((i) => {
			const s = r - i.size > 0 ? this.documentOverlayCache.getOverlaysForCollectionGroup(e, t, n.largestBatchId, r - i.size) : PersistencePromise.resolve(__PRIVATE_newOverlayMap());
			let _ = Xe, o = i;
			return s.next(((t) => PersistencePromise.forEach(t, ((t, n) => (_ < n.largestBatchId && (_ = n.largestBatchId), i.get(t) ? PersistencePromise.resolve() : this.remoteDocumentCache.getEntry(e, t).next(((e) => {
				o = o.insert(t, e);
			}))))).next((() => this.populateOverlays(e, t, i))).next((() => this.computeViews(e, o, t, __PRIVATE_documentKeySet()))).next(((e) => ({
				batchId: _,
				changes: __PRIVATE_convertOverlayedDocumentMapToDocumentMap(e)
			})))));
		}));
	}
	getDocumentsMatchingDocumentQuery(e, t) {
		return this.getDocument(e, new DocumentKey(t)).next(((e) => {
			let t = documentMap();
			return e.isFoundDocument() && (t = t.insert(e.key, e)), t;
		}));
	}
	getDocumentsMatchingCollectionGroupQuery(e, t, n, r) {
		const i = t.collectionGroup;
		let s = documentMap();
		return this.indexManager.getCollectionParents(e, i).next(((_) => PersistencePromise.forEach(_, ((_) => {
			const o = function __PRIVATE_asCollectionQueryAtPath(e, t) {
				return new __PRIVATE_QueryImpl(t, null, e.explicitOrderBy.slice(), e.filters.slice(), e.limit, e.limitType, e.startAt, e.endAt);
			}(t, _.child(i));
			return this.getDocumentsMatchingCollectionQuery(e, o, n, r).next(((e) => {
				e.forEach(((e, t) => {
					s = s.insert(e, t);
				}));
			}));
		})).next((() => s))));
	}
	getDocumentsMatchingCollectionQuery(e, t, n, r) {
		let i;
		return this.documentOverlayCache.getOverlaysForCollection(e, t.path, n.largestBatchId).next(((s) => (i = s, this.remoteDocumentCache.getDocumentsMatchingQuery(e, t, n, i, r)))).next(((e) => this.retrieveMatchingLocalDocuments(i, e, ((e) => __PRIVATE_queryMatches(t, e)))));
	}
	getDocumentsMatchingPipeline(t, n, r, i) {
		if ("collection_group" === getPipelineSourceType(n)) {
			const e = getPipelineCollectionGroup(n);
			let s = documentMap();
			return this.indexManager.getCollectionParents(t, e).next(((_) => PersistencePromise.forEach(_, ((_) => {
				const o = function __PRIVATE_asCollectionPipelineAtPath(e, t) {
					const n = e.stages.map(((e) => e instanceof Y ? new X(t.canonicalString(), {}) : e));
					return new CorePipeline(e.serializer, n);
				}(n, _.child(e));
				return this.getDocumentsMatchingPipeline(t, o, r, i).next(((e) => {
					e.forEach(((e, t) => {
						s = s.insert(e, t);
					}));
				}));
			})).next((() => s))));
		}
		{
			let s;
			return this.getOverlaysForPipeline(t, n, r.largestBatchId).next(((_) => {
				switch (s = _, getPipelineSourceType(n)) {
					case "collection": return this.remoteDocumentCache.getDocumentsMatchingQuery(t, n, r, s, i);
					case "documents":
						let _ = __PRIVATE_documentKeySet();
						for (const e of getPipelineDocuments(n)) _ = _.add(DocumentKey.fromPath(e));
						return this.remoteDocumentCache.getEntries(t, _);
					case "database": return this.remoteDocumentCache.getAllEntries(t);
					default: throw new e("invalid-argument", `Invalid pipeline source to execute offline: ${__PRIVATE_canonifyPipeline(n)}`);
				}
			})).next(((e) => this.retrieveMatchingLocalDocuments(s, e, ((e) => __PRIVATE_pipelineMatches(n, e)))));
		}
	}
	retrieveMatchingLocalDocuments(e, t, n) {
		e.forEach(((e, n) => {
			const r = n.getKey();
			null === t.get(r) && (t = t.insert(r, MutableDocument.newInvalidDocument(r)));
		}));
		let r = documentMap();
		return t.forEach(((t, i) => {
			const s = e.get(t);
			void 0 !== s && __PRIVATE_mutationApplyToLocalView(s.mutation, i, FieldMask.empty(), Timestamp.now()), n(i) && (r = r.insert(t, i));
		})), r;
	}
	getOverlaysForPipeline(t, n, r) {
		switch (getPipelineSourceType(n)) {
			case "collection": return this.documentOverlayCache.getOverlaysForCollection(t, ResourcePath.fromString(getPipelineCollection(n)), r);
			case "collection_group": throw new e("invalid-argument", `Unexpected collection group pipeline: ${__PRIVATE_canonifyPipeline(n)}`);
			case "documents": return this.documentOverlayCache.getOverlays(t, getPipelineDocuments(n).map(((e) => DocumentKey.fromPath(e))));
			case "database": return this.documentOverlayCache.getAllOverlays(t, r);
			default: throw new e("invalid-argument", `Failed to get overlays for pipeline: ${__PRIVATE_canonifyPipeline(n)}`);
		}
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var __PRIVATE_MemoryBundleCache = class {
	constructor(e) {
		this.serializer = e, this.Qs = /* @__PURE__ */ new Map(), this.Ws = /* @__PURE__ */ new Map();
	}
	getBundleMetadata(e, t) {
		return PersistencePromise.resolve(this.Qs.get(t));
	}
	saveBundleMetadata(e, t) {
		return this.Qs.set(
			t.id,
			/** Decodes a BundleMetadata proto into a BundleMetadata object. */
			function __PRIVATE_fromBundleMetadata(e) {
				return {
					id: e.id,
					version: e.version,
					createTime: __PRIVATE_fromVersion(e.createTime)
				};
			}(t)
		), PersistencePromise.resolve();
	}
	getNamedQuery(e, t) {
		return PersistencePromise.resolve(this.Ws.get(t));
	}
	saveNamedQuery(e, t) {
		return this.Ws.set(t.name, function __PRIVATE_fromProtoNamedQuery(e) {
			return {
				name: e.name,
				query: __PRIVATE_fromBundledQuery(e.bundledQuery),
				readTime: __PRIVATE_fromVersion(e.readTime)
			};
		}(t)), PersistencePromise.resolve();
	}
};
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* An in-memory implementation of DocumentOverlayCache.
*/ var __PRIVATE_MemoryDocumentOverlayCache = class {
	constructor() {
		this.overlays = new SortedMap(DocumentKey.comparator), this.Gs = /* @__PURE__ */ new Map();
	}
	getOverlay(e, t) {
		return PersistencePromise.resolve(this.overlays.get(t));
	}
	getOverlays(e, t) {
		const n = __PRIVATE_newOverlayMap();
		return PersistencePromise.forEach(t, ((t) => this.getOverlay(e, t).next(((e) => {
			null !== e && n.set(t, e);
		})))).next((() => n));
	}
	getAllOverlays(e, t) {
		const n = __PRIVATE_newOverlayMap();
		return this.overlays.forEach(((e, r) => {
			r.largestBatchId > t && n.set(e, r);
		})), PersistencePromise.resolve(n);
	}
	saveOverlays(e, t, n) {
		return n.forEach(((n, r) => {
			this.Zr(e, t, r);
		})), PersistencePromise.resolve();
	}
	removeOverlaysForBatchId(e, t, n) {
		const r = this.Gs.get(n);
		return void 0 !== r && (r.forEach(((e) => this.overlays = this.overlays.remove(e))), this.Gs.delete(n)), PersistencePromise.resolve();
	}
	getOverlaysForCollection(e, t, n) {
		const r = __PRIVATE_newOverlayMap(), i = t.length + 1, s = new DocumentKey(t.child("")), _ = this.overlays.getIteratorFrom(s);
		for (; _.hasNext();) {
			const e = _.getNext().value, s = e.getKey();
			if (!t.isPrefixOf(s.path)) break;
			s.path.length === i && e.largestBatchId > n && r.set(e.getKey(), e);
		}
		return PersistencePromise.resolve(r);
	}
	getOverlaysForCollectionGroup(e, t, n, r) {
		let i = new SortedMap(((e, t) => e - t));
		const s = this.overlays.getIterator();
		for (; s.hasNext();) {
			const e = s.getNext().value;
			if (e.getKey().getCollectionGroup() === t && e.largestBatchId > n) {
				let t = i.get(e.largestBatchId);
				null === t && (t = __PRIVATE_newOverlayMap(), i = i.insert(e.largestBatchId, t)), t.set(e.getKey(), e);
			}
		}
		const _ = __PRIVATE_newOverlayMap(), o = i.getIterator();
		for (; o.hasNext();) if (o.getNext().value.forEach(((e, t) => _.set(e, t))), _.size() >= r) break;
		return PersistencePromise.resolve(_);
	}
	Zr(e, t, n) {
		const r = this.overlays.get(n.key);
		if (null !== r) {
			const e = this.Gs.get(r.largestBatchId).delete(n.key);
			this.Gs.set(r.largestBatchId, e);
		}
		this.overlays = this.overlays.insert(n.key, new Overlay(t, n));
		let i = this.Gs.get(t);
		void 0 === i && (i = __PRIVATE_documentKeySet(), this.Gs.set(t, i)), this.Gs.set(t, i.add(n.key));
	}
};
/**
* @license
* Copyright 2024 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var __PRIVATE_MemoryGlobalsCache = class {
	constructor() {
		this.sessionToken = ByteString.EMPTY_BYTE_STRING;
	}
	getSessionToken(e) {
		return PersistencePromise.resolve(this.sessionToken);
	}
	setSessionToken(e, t) {
		return this.sessionToken = t, PersistencePromise.resolve();
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A collection of references to a document from some kind of numbered entity
* (either a target ID or batch ID). As references are added to or removed from
* the set corresponding events are emitted to a registered garbage collector.
*
* Each reference is represented by a DocumentReference object. Each of them
* contains enough information to uniquely identify the reference. They are all
* stored primarily in a set sorted by key. A document is considered garbage if
* there's no references in that set (this can be efficiently checked thanks to
* sorting by key).
*
* ReferenceSet also keeps a secondary set that contains references sorted by
* IDs. This one is used to efficiently implement removal of all references by
* some target ID.
*/ var __PRIVATE_ReferenceSet = class {
	constructor() {
		this.zs = new SortedSet(__PRIVATE_DocReference.js), this.Hs = new SortedSet(__PRIVATE_DocReference.Js);
	}
	/** Returns true if the reference set contains no references. */ isEmpty() {
		return this.zs.isEmpty();
	}
	/** Adds a reference to the given document key for the given ID. */ addReference(e, t) {
		const n = new __PRIVATE_DocReference(e, t);
		this.zs = this.zs.add(n), this.Hs = this.Hs.add(n);
	}
	/** Add references to the given document keys for the given ID. */ Ys(e, t) {
		e.forEach(((e) => this.addReference(e, t)));
	}
	/**
	* Removes a reference to the given document key for the given
	* ID.
	*/ removeReference(e, t) {
		this.Zs(new __PRIVATE_DocReference(e, t));
	}
	Xs(e, t) {
		e.forEach(((e) => this.removeReference(e, t)));
	}
	/**
	* Clears all references with a given ID. Calls removeRef() for each key
	* removed.
	*/ e_(e) {
		const t = new DocumentKey(new ResourcePath([])), n = new __PRIVATE_DocReference(t, e), r = new __PRIVATE_DocReference(t, e + 1), i = [];
		return this.Hs.forEachInRange([n, r], ((e) => {
			this.Zs(e), i.push(e.key);
		})), i;
	}
	t_() {
		this.zs.forEach(((e) => this.Zs(e)));
	}
	Zs(e) {
		this.zs = this.zs.delete(e), this.Hs = this.Hs.delete(e);
	}
	n_(e) {
		const t = new DocumentKey(new ResourcePath([])), n = new __PRIVATE_DocReference(t, e), r = new __PRIVATE_DocReference(t, e + 1);
		let i = __PRIVATE_documentKeySet();
		return this.Hs.forEachInRange([n, r], ((e) => {
			i = i.add(e.key);
		})), i;
	}
	containsKey(e) {
		const t = new __PRIVATE_DocReference(e, 0), n = this.zs.firstAfterOrEqual(t);
		return null !== n && e.isEqual(n.key);
	}
};
var __PRIVATE_DocReference = class {
	constructor(e, t) {
		this.key = e, this.r_ = t;
	}
	/** Compare by key then by ID */ static js(e, t) {
		return DocumentKey.comparator(e.key, t.key) || __PRIVATE_primitiveComparator(e.r_, t.r_);
	}
	/** Compare by ID then by key */ static Js(e, t) {
		return __PRIVATE_primitiveComparator(e.r_, t.r_) || DocumentKey.comparator(e.key, t.key);
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var __PRIVATE_MemoryMutationQueue = class {
	constructor(e, t) {
		this.indexManager = e, this.referenceDelegate = t, this.mutationQueue = [], this.Gr = 1, this.i_ = new SortedSet(__PRIVATE_DocReference.js);
	}
	checkEmpty(e) {
		return PersistencePromise.resolve(0 === this.mutationQueue.length);
	}
	addMutationBatch(e, t, n, r) {
		const i = this.Gr;
		this.Gr++, this.mutationQueue.length > 0 && this.mutationQueue[this.mutationQueue.length - 1];
		const s = new MutationBatch(i, t, n, r);
		this.mutationQueue.push(s);
		for (const t of r) this.i_ = this.i_.add(new __PRIVATE_DocReference(t.key, i)), this.indexManager.addToCollectionParentIndex(e, t.key.path.popLast());
		return PersistencePromise.resolve(s);
	}
	lookupMutationBatch(e, t) {
		return PersistencePromise.resolve(this.s_(t));
	}
	getNextMutationBatchAfterBatchId(e, t) {
		const n = t + 1, r = this.__(n), i = r < 0 ? 0 : r;
		return PersistencePromise.resolve(this.mutationQueue.length > i ? this.mutationQueue[i] : null);
	}
	getHighestUnacknowledgedBatchId() {
		return PersistencePromise.resolve(0 === this.mutationQueue.length ? Ke : this.Gr - 1);
	}
	getAllMutationBatches(e) {
		return PersistencePromise.resolve(this.mutationQueue.slice());
	}
	getAllMutationBatchesAffectingDocumentKey(e, t) {
		const n = new __PRIVATE_DocReference(t, 0), r = new __PRIVATE_DocReference(t, Number.POSITIVE_INFINITY), i = [];
		return this.i_.forEachInRange([n, r], ((e) => {
			const t = this.s_(e.r_);
			i.push(t);
		})), PersistencePromise.resolve(i);
	}
	getAllMutationBatchesAffectingDocumentKeys(e, t) {
		let n = new SortedSet(__PRIVATE_primitiveComparator);
		return t.forEach(((e) => {
			const t = new __PRIVATE_DocReference(e, 0), r = new __PRIVATE_DocReference(e, Number.POSITIVE_INFINITY);
			this.i_.forEachInRange([t, r], ((e) => {
				n = n.add(e.r_);
			}));
		})), PersistencePromise.resolve(this.o_(n));
	}
	getAllMutationBatchesAffectingQuery(e, t) {
		const n = t.path, r = n.length + 1;
		let i = n;
		DocumentKey.isDocumentKey(i) || (i = i.child(""));
		const s = new __PRIVATE_DocReference(new DocumentKey(i), 0);
		let _ = new SortedSet(__PRIVATE_primitiveComparator);
		return this.i_.forEachWhile(((e) => {
			const t = e.key.path;
			return !!n.isPrefixOf(t) && (t.length === r && (_ = _.add(e.r_)), true);
		}), s), PersistencePromise.resolve(this.o_(_));
	}
	o_(e) {
		const t = [];
		return e.forEach(((e) => {
			const n = this.s_(e);
			null !== n && t.push(n);
		})), t;
	}
	removeMutationBatch(e, t) {
		__PRIVATE_hardAssert(0 === this.a_(t.batchId, "removed"), 55003), this.mutationQueue.shift();
		let n = this.i_;
		return PersistencePromise.forEach(t.mutations, ((r) => {
			const i = new __PRIVATE_DocReference(r.key, t.batchId);
			return n = n.delete(i), this.referenceDelegate.markPotentiallyOrphaned(e, r.key);
		})).next((() => {
			this.i_ = n;
		}));
	}
	Hr(e) {}
	containsKey(e, t) {
		const n = new __PRIVATE_DocReference(t, 0), r = this.i_.firstAfterOrEqual(n);
		return PersistencePromise.resolve(t.isEqual(r && r.key));
	}
	performConsistencyCheck(e) {
		return this.mutationQueue.length, PersistencePromise.resolve();
	}
	/**
	* Finds the index of the given batchId in the mutation queue and asserts that
	* the resulting index is within the bounds of the queue.
	*
	* @param batchId - The batchId to search for
	* @param action - A description of what the caller is doing, phrased in passive
	* form (e.g. "acknowledged" in a routine that acknowledges batches).
	*/ a_(e, t) {
		return this.__(e);
	}
	/**
	* Finds the index of the given batchId in the mutation queue. This operation
	* is O(1).
	*
	* @returns The computed index of the batch with the given batchId, based on
	* the state of the queue. Note this index can be negative if the requested
	* batchId has already been removed from the queue or past the end of the
	* queue if the batchId is larger than the last added batch.
	*/ __(e) {
		if (0 === this.mutationQueue.length) return 0;
		return e - this.mutationQueue[0].batchId;
	}
	/**
	* A version of lookupMutationBatch that doesn't return a promise, this makes
	* other functions that uses this code easier to read and more efficient.
	*/ s_(e) {
		const t = this.__(e);
		if (t < 0 || t >= this.mutationQueue.length) return null;
		return this.mutationQueue[t];
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* The smallest value representable by a 64-bit signed integer (long).
*/
/**
* The memory-only RemoteDocumentCache for IndexedDb. To construct, invoke
* `newMemoryRemoteDocumentCache()`.
*/
var __PRIVATE_MemoryRemoteDocumentCacheImpl = class {
	/**
	* @param sizer - Used to assess the size of a document. For eager GC, this is
	* expected to just return 0 to avoid unnecessarily doing the work of
	* calculating the size.
	*/
	constructor(e) {
		this.u_ = e, this.docs = function __PRIVATE_documentEntryMap() {
			return new SortedMap(DocumentKey.comparator);
		}(), this.size = 0;
	}
	setIndexManager(e) {
		this.indexManager = e;
	}
	/**
	* Adds the supplied entry to the cache and updates the cache size as appropriate.
	*
	* All calls of `addEntry`  are required to go through the RemoteDocumentChangeBuffer
	* returned by `newChangeBuffer()`.
	*/ addEntry(e, t) {
		const n = t.key, r = this.docs.get(n), i = r ? r.size : 0, s = this.u_(t);
		return this.docs = this.docs.insert(n, {
			document: t.mutableCopy(),
			size: s
		}), this.size += s - i, this.indexManager.addToCollectionParentIndex(e, n.path.popLast());
	}
	/**
	* Removes the specified entry from the cache and updates the cache size as appropriate.
	*
	* All calls of `removeEntry` are required to go through the RemoteDocumentChangeBuffer
	* returned by `newChangeBuffer()`.
	*/ removeEntry(e) {
		const t = this.docs.get(e);
		t && (this.docs = this.docs.remove(e), this.size -= t.size);
	}
	getEntry(e, t) {
		const n = this.docs.get(t);
		return PersistencePromise.resolve(n ? n.document.mutableCopy() : MutableDocument.newInvalidDocument(t));
	}
	getEntries(e, t) {
		let n = __PRIVATE_mutableDocumentMap();
		return t.forEach(((e) => {
			const t = this.docs.get(e);
			n = n.insert(e, t ? t.document.mutableCopy() : MutableDocument.newInvalidDocument(e));
		})), PersistencePromise.resolve(n);
	}
	getAllEntries(e) {
		let t = __PRIVATE_mutableDocumentMap();
		return this.docs.forEach(((e, n) => {
			t = t.insert(e, n.document);
		})), PersistencePromise.resolve(t);
	}
	getDocumentsMatchingQuery(e, t, n, r) {
		let i, s;
		__PRIVATE_isPipeline(t) ? (i = ResourcePath.fromString(getPipelineCollection(t)), s = (e) => __PRIVATE_pipelineMatches(t, e)) : (i = t.path, s = (e) => __PRIVATE_queryMatches(t, e));
		let _ = __PRIVATE_mutableDocumentMap();
		const o = new DocumentKey(i.child("__id-9223372036854775808__")), a = this.docs.getIteratorFrom(o);
		for (; a.hasNext();) {
			const { key: e, value: { document: t } } = a.getNext();
			if (!i.isPrefixOf(e.path)) break;
			e.path.length > i.length + 1 || __PRIVATE_indexOffsetComparator(__PRIVATE_newIndexOffsetFromDocument(t), n) <= 0 || (r.has(t.key) || s(t)) && (_ = _.insert(t.key, t.mutableCopy()));
		}
		return PersistencePromise.resolve(_);
	}
	getAllFromCollectionGroup(e, t, n, r) {
		l(9500);
	}
	c_(e, t) {
		return PersistencePromise.forEach(this.docs, ((e) => t(e)));
	}
	newChangeBuffer(e) {
		return new __PRIVATE_MemoryRemoteDocumentChangeBuffer(this);
	}
	getSize(e) {
		return PersistencePromise.resolve(this.size);
	}
};
/**
* Creates a new memory-only RemoteDocumentCache.
*
* @param sizer - Used to assess the size of a document. For eager GC, this is
* expected to just return 0 to avoid unnecessarily doing the work of
* calculating the size.
*/
/**
* Handles the details of adding and updating documents in the MemoryRemoteDocumentCache.
*/
var __PRIVATE_MemoryRemoteDocumentChangeBuffer = class extends RemoteDocumentChangeBuffer {
	constructor(e) {
		super(), this.$s = e;
	}
	applyChanges(e) {
		const t = [];
		return this.changes.forEach(((n, r) => {
			r.isValidDocument() ? t.push(this.$s.addEntry(e, r)) : this.$s.removeEntry(n);
		})), PersistencePromise.waitFor(t);
	}
	getFromCache(e, t) {
		return this.$s.getEntry(e, t);
	}
	getAllFromCache(e, t) {
		return this.$s.getEntries(e, t);
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var __PRIVATE_MemoryTargetCache = class {
	constructor(e) {
		this.persistence = e, this.l_ = new ObjectMap(((e) => __PRIVATE_canonifyTargetOrPipeline(e)), __PRIVATE_targetOrPipelineEqual), this.lastRemoteSnapshotVersion = SnapshotVersion.min(), this.highestTargetId = 0, this.E_ = 0, this.h_ = new __PRIVATE_ReferenceSet(), this.targetCount = 0, this.T_ = __PRIVATE_TargetIdGenerator.ws();
	}
	forEachTarget(e, t) {
		return this.l_.forEach(((e, n) => t(n))), PersistencePromise.resolve();
	}
	getLastRemoteSnapshotVersion(e) {
		return PersistencePromise.resolve(this.lastRemoteSnapshotVersion);
	}
	getHighestSequenceNumber(e) {
		return PersistencePromise.resolve(this.E_);
	}
	allocateTargetId(e) {
		return this.highestTargetId = this.T_.next(), PersistencePromise.resolve(this.highestTargetId);
	}
	setTargetsMetadata(e, t, n) {
		return n && (this.lastRemoteSnapshotVersion = n), t > this.E_ && (this.E_ = t), PersistencePromise.resolve();
	}
	Ds(e) {
		this.l_.set(e.target, e);
		const t = e.targetId;
		t > this.highestTargetId && (this.T_ = new __PRIVATE_TargetIdGenerator(t), this.highestTargetId = t), e.sequenceNumber > this.E_ && (this.E_ = e.sequenceNumber);
	}
	addTargetData(e, t) {
		return this.Ds(t), this.targetCount += 1, PersistencePromise.resolve();
	}
	updateTargetData(e, t) {
		return this.Ds(t), PersistencePromise.resolve();
	}
	removeTargetData(e, t) {
		return this.l_.delete(t.target), this.h_.e_(t.targetId), this.targetCount -= 1, PersistencePromise.resolve();
	}
	removeTargets(e, t, n) {
		let r = 0;
		const i = [];
		return this.l_.forEach(((s, _) => {
			_.sequenceNumber <= t && null === n.get(_.targetId) && (this.l_.delete(s), i.push(this.removeMatchingKeysForTargetId(e, _.targetId)), r++);
		})), PersistencePromise.waitFor(i).next((() => r));
	}
	getTargetCount(e) {
		return PersistencePromise.resolve(this.targetCount);
	}
	getTargetData(e, t) {
		const n = this.l_.get(t) || null;
		return PersistencePromise.resolve(n);
	}
	addMatchingKeys(e, t, n) {
		return this.h_.Ys(t, n), PersistencePromise.resolve();
	}
	removeMatchingKeys(e, t, n) {
		this.h_.Xs(t, n);
		const r = this.persistence.referenceDelegate, i = [];
		return r && t.forEach(((t) => {
			i.push(r.markPotentiallyOrphaned(e, t));
		})), PersistencePromise.waitFor(i);
	}
	removeMatchingKeysForTargetId(e, t) {
		return this.h_.e_(t), PersistencePromise.resolve();
	}
	getMatchingKeysForTargetId(e, t) {
		const n = this.h_.n_(t);
		return PersistencePromise.resolve(n);
	}
	containsKey(e, t) {
		return PersistencePromise.resolve(this.h_.containsKey(t));
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A memory-backed instance of Persistence. Data is stored only in RAM and
* not persisted across sessions.
*/
var __PRIVATE_MemoryPersistence = class {
	/**
	* The constructor accepts a factory for creating a reference delegate. This
	* allows both the delegate and this instance to have strong references to
	* each other without having nullable fields that would then need to be
	* checked or asserted on every access.
	*/
	constructor(e, t) {
		this.P_ = {}, this.overlays = {}, this.I_ = new __PRIVATE_ListenSequence(0), this.R_ = false, this.R_ = true, this.A_ = new __PRIVATE_MemoryGlobalsCache(), this.referenceDelegate = e(this), this.V_ = new __PRIVATE_MemoryTargetCache(this);
		this.indexManager = new __PRIVATE_MemoryIndexManager(), this.remoteDocumentCache = function __PRIVATE_newMemoryRemoteDocumentCache(e) {
			return new __PRIVATE_MemoryRemoteDocumentCacheImpl(e);
		}(((e) => this.referenceDelegate.d_(e))), this.serializer = new __PRIVATE_LocalSerializer(t), this.f_ = new __PRIVATE_MemoryBundleCache(this.serializer);
	}
	start() {
		return Promise.resolve();
	}
	shutdown() {
		return this.R_ = false, Promise.resolve();
	}
	get started() {
		return this.R_;
	}
	setDatabaseDeletedListener() {}
	setNetworkEnabled() {}
	getIndexManager(e) {
		return this.indexManager;
	}
	getDocumentOverlayCache(e) {
		let t = this.overlays[e.toKey()];
		return t || (t = new __PRIVATE_MemoryDocumentOverlayCache(), this.overlays[e.toKey()] = t), t;
	}
	getMutationQueue(e, t) {
		let n = this.P_[e.toKey()];
		return n || (n = new __PRIVATE_MemoryMutationQueue(t, this.referenceDelegate), this.P_[e.toKey()] = n), n;
	}
	getGlobalsCache() {
		return this.A_;
	}
	getTargetCache() {
		return this.V_;
	}
	getRemoteDocumentCache() {
		return this.remoteDocumentCache;
	}
	getBundleCache() {
		return this.f_;
	}
	runTransaction(e, t, n) {
		__PRIVATE_logDebug("MemoryPersistence", "Starting transaction:", e);
		const r = new __PRIVATE_MemoryTransaction(this.I_.next());
		return this.referenceDelegate.m_(), n(r).next(((e) => this.referenceDelegate.p_(r).next((() => e)))).toPromise().then(((e) => (r.raiseOnCommittedEvent(), e)));
	}
	g_(e, t) {
		return PersistencePromise.or(Object.values(this.P_).map(((n) => () => n.containsKey(e, t))));
	}
};
/**
* Memory persistence is not actually transactional, but future implementations
* may have transaction-scoped state.
*/ var __PRIVATE_MemoryTransaction = class extends PersistenceTransaction {
	constructor(e) {
		super(), this.currentSequenceNumber = e;
	}
};
var __PRIVATE_MemoryEagerDelegate = class __PRIVATE_MemoryEagerDelegate {
	constructor(e) {
		this.persistence = e, this.y_ = new __PRIVATE_ReferenceSet(), this.w_ = null;
	}
	static b_(e) {
		return new __PRIVATE_MemoryEagerDelegate(e);
	}
	get S_() {
		if (this.w_) return this.w_;
		throw l(60996);
	}
	addReference(e, t, n) {
		return this.y_.addReference(n, t), this.S_.delete(n.toString()), PersistencePromise.resolve();
	}
	removeReference(e, t, n) {
		return this.y_.removeReference(n, t), this.S_.add(n.toString()), PersistencePromise.resolve();
	}
	markPotentiallyOrphaned(e, t) {
		return this.S_.add(t.toString()), PersistencePromise.resolve();
	}
	removeTarget(e, t) {
		this.y_.e_(t.targetId).forEach(((e) => this.S_.add(e.toString())));
		const n = this.persistence.getTargetCache();
		return n.getMatchingKeysForTargetId(e, t.targetId).next(((e) => {
			e.forEach(((e) => this.S_.add(e.toString())));
		})).next((() => n.removeTargetData(e, t)));
	}
	m_() {
		this.w_ = /* @__PURE__ */ new Set();
	}
	p_(e) {
		const t = this.persistence.getRemoteDocumentCache().newChangeBuffer();
		return PersistencePromise.forEach(this.S_, ((n) => {
			const r = DocumentKey.fromPath(n);
			return this.v_(e, r).next(((e) => {
				e || t.removeEntry(r, SnapshotVersion.min());
			}));
		})).next((() => (this.w_ = null, t.apply(e))));
	}
	updateLimboDocument(e, t) {
		return this.v_(e, t).next(((e) => {
			e ? this.S_.delete(t.toString()) : this.S_.add(t.toString());
		}));
	}
	d_(e) {
		return 0;
	}
	v_(e, t) {
		return PersistencePromise.or([
			() => PersistencePromise.resolve(this.y_.containsKey(t)),
			() => this.persistence.getTargetCache().containsKey(e, t),
			() => this.persistence.g_(e, t)
		]);
	}
};
var __PRIVATE_MemoryLruDelegate = class __PRIVATE_MemoryLruDelegate {
	constructor(e, t) {
		this.persistence = e, this.D_ = new ObjectMap(((e) => __PRIVATE_encodeResourcePath(e.path)), ((e, t) => e.isEqual(t))), this.garbageCollector = __PRIVATE_newLruGarbageCollector(this, t);
	}
	static b_(e, t) {
		return new __PRIVATE_MemoryLruDelegate(e, t);
	}
	m_() {}
	p_(e) {
		return PersistencePromise.resolve();
	}
	forEachTarget(e, t) {
		return this.persistence.getTargetCache().forEachTarget(e, t);
	}
	ir(e) {
		const t = this.Cs(e);
		return this.persistence.getTargetCache().getTargetCount(e).next(((e) => t.next(((t) => e + t))));
	}
	Cs(e) {
		let t = 0;
		return this.sr(e, ((e) => {
			t++;
		})).next((() => t));
	}
	sr(e, t) {
		return PersistencePromise.forEach(this.D_, ((n, r) => this.Os(e, n, r).next(((e) => e ? PersistencePromise.resolve() : t(r)))));
	}
	removeTargets(e, t, n) {
		return this.persistence.getTargetCache().removeTargets(e, t, n);
	}
	removeOrphanedDocuments(e, t) {
		let n = 0;
		const r = this.persistence.getRemoteDocumentCache(), i = r.newChangeBuffer();
		return r.c_(e, ((r) => this.Os(e, r, t).next(((e) => {
			e || (n++, i.removeEntry(r, SnapshotVersion.min()));
		})))).next((() => i.apply(e))).next((() => n));
	}
	markPotentiallyOrphaned(e, t) {
		return this.D_.set(t, e.currentSequenceNumber), PersistencePromise.resolve();
	}
	removeTarget(e, t) {
		const n = t.withSequenceNumber(e.currentSequenceNumber);
		return this.persistence.getTargetCache().updateTargetData(e, n);
	}
	addReference(e, t, n) {
		return this.D_.set(n, e.currentSequenceNumber), PersistencePromise.resolve();
	}
	removeReference(e, t, n) {
		return this.D_.set(n, e.currentSequenceNumber), PersistencePromise.resolve();
	}
	updateLimboDocument(e, t) {
		return this.D_.set(t, e.currentSequenceNumber), PersistencePromise.resolve();
	}
	d_(e) {
		let t = e.key.toString().length;
		return e.isFoundDocument() && (t += __PRIVATE_estimateByteSize(e.data.value)), t;
	}
	Os(e, t, n) {
		return PersistencePromise.or([
			() => this.persistence.g_(e, t),
			() => this.persistence.getTargetCache().containsKey(e, t),
			() => {
				const e = this.D_.get(t);
				return PersistencePromise.resolve(void 0 !== e && e > n);
			}
		]);
	}
	getCacheSize(e) {
		return this.persistence.getRemoteDocumentCache().getSize(e);
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A set of changes to what documents are currently in view and out of view for
* a given query. These changes are sent to the LocalStore by the View (via
* the SyncEngine) and are used to pin / unpin documents as appropriate.
*/
var __PRIVATE_LocalViewChanges = class __PRIVATE_LocalViewChanges {
	constructor(e, t, n, r) {
		this.targetId = e, this.fromCache = t, this.Vo = n, this.fo = r;
	}
	static mo(e, t) {
		let n = __PRIVATE_documentKeySet(), r = __PRIVATE_documentKeySet();
		for (const e of t.docChanges) switch (e.type) {
			case 0:
				n = n.add(e.doc.key);
				break;
			case 1: r = r.add(e.doc.key);
		}
		return new __PRIVATE_LocalViewChanges(e, t.fromCache, n, r);
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ function __PRIVATE_compareByKey(e, t) {
	return DocumentKey.comparator(e.key, t.key);
}
/**
* @license
* Copyright 2023 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A tracker to keep a record of important details during database local query
* execution.
*/ var QueryContext = class {
	constructor() {
		/**
		* Counts the number of documents passed through during local query execution.
		*/
		this._documentReadCount = 0;
	}
	get documentReadCount() {
		return this._documentReadCount;
	}
	incrementDocumentReadCount(e) {
		this._documentReadCount += e;
	}
};
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* The Firestore query engine.
*
* Firestore queries can be executed in three modes. The Query Engine determines
* what mode to use based on what data is persisted. The mode only determines
* the runtime complexity of the query - the result set is equivalent across all
* implementations.
*
* The Query engine will use indexed-based execution if a user has configured
* any index that can be used to execute query (via `setIndexConfiguration()`).
* Otherwise, the engine will try to optimize the query by re-using a previously
* persisted query result. If that is not possible, the query will be executed
* via a full collection scan.
*
* Index-based execution is the default when available. The query engine
* supports partial indexed execution and merges the result from the index
* lookup with documents that have not yet been indexed. The index evaluation
* matches the backend's format and as such, the SDK can use indexing for all
* queries that the backend supports.
*
* If no index exists, the query engine tries to take advantage of the target
* document mapping in the TargetCache. These mappings exists for all queries
* that have been synced with the backend at least once and allow the query
* engine to only read documents that previously matched a query plus any
* documents that were edited after the query was last listened to.
*
* There are some cases when this optimization is not guaranteed to produce
* the same results as full collection scans. In these cases, query
* processing falls back to full scans. These cases are:
*
* - Limit queries where a document that matched the query previously no longer
*   matches the query.
*
* - Limit queries where a document edit may cause the document to sort below
*   another document that is in the local cache.
*
* - Queries that have never been CURRENT or free of limbo documents.
*/
var __PRIVATE_QueryEngine = class {
	constructor() {
		this.po = false, this.yo = false, this.wo = 100, this.bo = function __PRIVATE_getDefaultRelativeIndexReadCostPerDocument() {
			return isSafari() ? 8 : __PRIVATE_getAndroidVersion(getUA()) > 0 ? 6 : 4;
		}();
	}
	/** Sets the document view to query against. */ initialize(e, t) {
		this.So = e, this.indexManager = t, this.po = true;
	}
	/** Returns all local documents matching the specified query. */ getDocumentsMatchingQuery(e, t, n, r) {
		const i = { result: null };
		return this.vo(e, t).next(((e) => {
			i.result = e;
		})).next((() => {
			if (!i.result) return this.Do(e, t, r, n).next(((e) => {
				i.result = e;
			}));
		})).next((() => {
			if (i.result) return;
			const n = new QueryContext();
			return this.xo(e, t, n).next(((r) => {
				if (i.result = r, this.yo) return this.Co(e, t, n, r.size);
			}));
		})).next((() => i.result));
	}
	Co(e, t, n, r) {
		return __PRIVATE_isPipeline(t) ? PersistencePromise.resolve() : n.documentReadCount < this.wo ? (__PRIVATE_getLogLevel() <= LogLevel.DEBUG && __PRIVATE_logDebug("QueryEngine", "SDK will not create cache indexes for query:", __PRIVATE_stringifyQuery(t), "since it only creates cache indexes for collection contains", "more than or equal to", this.wo, "documents"), PersistencePromise.resolve()) : (__PRIVATE_getLogLevel() <= LogLevel.DEBUG && __PRIVATE_logDebug("QueryEngine", "Query:", __PRIVATE_stringifyQuery(t), "scans", n.documentReadCount, "local documents and returns", r, "documents as results."), n.documentReadCount > this.bo * r ? (__PRIVATE_getLogLevel() <= LogLevel.DEBUG && __PRIVATE_logDebug("QueryEngine", "The SDK decides to create cache indexes for query:", __PRIVATE_stringifyQuery(t), "as using cache indexes may help improve performance."), this.indexManager.createTargetIndexes(e, __PRIVATE_queryToTarget(t))) : PersistencePromise.resolve());
	}
	/**
	* Performs an indexed query that evaluates the query based on a collection's
	* persisted index values. Returns `null` if an index is not available.
	*/ vo(e, t) {
		if (__PRIVATE_isPipeline(t)) return PersistencePromise.resolve(null);
		let n = t;
		if (__PRIVATE_queryMatchesAllDocuments(n)) return PersistencePromise.resolve(null);
		let r = __PRIVATE_queryToTarget(n);
		return this.indexManager.getIndexType(e, r).next(((t) => 0 === t ? null : (null !== n.limit && 1 === t && (n = __PRIVATE_queryWithLimit(n, null, "F"), r = __PRIVATE_queryToTarget(n)), this.indexManager.getDocumentsMatchingTarget(e, r).next(((t) => {
			const i = __PRIVATE_documentKeySet(...t);
			return this.So.getDocuments(e, i).next(((t) => this.indexManager.getMinOffset(e, r).next(((r) => {
				const s = this.Fo(n, t);
				return this.Oo(n, s, i, r.readTime) ? this.vo(e, __PRIVATE_queryWithLimit(n, null, "F")) : this.Mo(e, s, n, r);
			}))));
		})))));
	}
	/**
	* Performs a query based on the target's persisted query mapping. Returns
	* `null` if the mapping is not available or cannot be used.
	*/ Do(e, t, n, r) {
		return (__PRIVATE_isPipeline(t) ? function __PRIVATE_pipelineMatchesAllDocuments(e) {
			for (const t of e.stages) {
				if (t instanceof v || t instanceof I) return false;
				if (t instanceof A) {
					if (t.condition instanceof __PRIVATE_BooleanFunctionExpression && "exists" === t.condition._expr.name && t.condition._expr.params[0] instanceof o && t.condition._expr.params[0].fieldName === Ce) continue;
					return false;
				}
			}
			return true;
		}(t) : __PRIVATE_queryMatchesAllDocuments(t)) || r.isEqual(SnapshotVersion.min()) ? PersistencePromise.resolve(null) : this.So.getDocuments(e, n).next(((i) => {
			const s = this.Fo(t, i);
			return this.Oo(t, s, n, r) ? PersistencePromise.resolve(null) : (__PRIVATE_getLogLevel() <= LogLevel.DEBUG && __PRIVATE_logDebug("QueryEngine", "Re-using previous result from %s to execute query: %s", r.toString(), __PRIVATE_stringifyQueryOrPipeline(t)), this.Mo(e, s, t, __PRIVATE_newIndexOffsetSuccessorFromReadTime(r, Xe)).next(((e) => e)));
		}));
	}
	/** Applies the query filter and sorting to the provided documents.  */ Fo(e, t) {
		let n, r;
		return __PRIVATE_isPipeline(e) ? (n = new SortedSet(__PRIVATE_compareByKey), r = (t) => __PRIVATE_pipelineMatches(e, t)) : (n = new SortedSet(__PRIVATE_newQueryComparator(e)), r = (t) => __PRIVATE_queryMatches(e, t)), t.forEach(((e, t) => {
			r(t) && (n = n.add(t));
		})), n;
	}
	/**
	* Determines if a limit query needs to be refilled from cache, making it
	* ineligible for index-free execution.
	*
	* @param query - The query.
	* @param sortedPreviousResults - The documents that matched the query when it
	* was last synchronized, sorted by the query's comparator.
	* @param remoteKeys - The document keys that matched the query at the last
	* snapshot.
	* @param limboFreeSnapshotVersion - The version of the snapshot when the
	* query was last synchronized.
	*/ Oo(e, t, n, r) {
		if (__PRIVATE_isPipeline(e)) return function __PRIVATE_pipelineHasRanges(e) {
			return e.stages.some(((e) => e instanceof v || e instanceof I));
		}(e);
		if (null === e.limit) return false;
		if (n.size !== t.size) return true;
		const i = "F" === e.limitType ? t.last() : t.first();
		return !!i && (i.hasPendingWrites || i.version.compareTo(r) > 0);
	}
	xo(e, t, n) {
		return __PRIVATE_getLogLevel() <= LogLevel.DEBUG && __PRIVATE_logDebug("QueryEngine", "Using full collection scan to execute query:", __PRIVATE_stringifyQueryOrPipeline(t)), this.So.getDocumentsMatchingQuery(e, t, IndexOffset.min(), n);
	}
	/**
	* Combines the results from an indexed execution with the remaining documents
	* that have not yet been indexed.
	*/ Mo(e, t, n, r) {
		return this.So.getDocumentsMatchingQuery(e, n, r).next(((e) => (t.forEach(((t) => {
			e = e.insert(t.key, t);
		})), e)));
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var lr = "LocalStore";
var Er = 3e8;
/**
* The maximum time to leave a resume token buffered without writing it out.
* This value is arbitrary: it's long enough to avoid several writes
* (possibly indefinitely if updates come more frequently than this) but
* short enough that restarting after crashing will still have a pretty
* recent resume token.
*/
/**
* Implements `LocalStore` interface.
*
* Note: some field defined in this class might have public access level, but
* the class is not exported so they are only accessible from this module.
* This is useful to implement optional features (like bundles) in free
* functions, such that they are tree-shakeable.
*/
var __PRIVATE_LocalStoreImpl = class {
	constructor(e, t, n, r) {
		this.persistence = e, this.No = t, this.serializer = r, this.Lo = new SortedMap(__PRIVATE_primitiveComparator), this.Bo = new ObjectMap(((e) => __PRIVATE_canonifyTargetOrPipeline(e)), __PRIVATE_targetOrPipelineEqual), this.Uo = /* @__PURE__ */ new Map(), this.ko = e.getRemoteDocumentCache(), this.V_ = e.getTargetCache(), this.f_ = e.getBundleCache(), this.qo(n);
	}
	qo(e) {
		this.documentOverlayCache = this.persistence.getDocumentOverlayCache(e), this.indexManager = this.persistence.getIndexManager(e), this.mutationQueue = this.persistence.getMutationQueue(e, this.indexManager), this.localDocuments = new LocalDocumentsView(this.ko, this.mutationQueue, this.documentOverlayCache, this.indexManager), this.ko.setIndexManager(this.indexManager), this.No.initialize(this.localDocuments, this.indexManager);
	}
	collectGarbage(e) {
		return this.persistence.runTransaction("Collect garbage", "readwrite-primary", ((t) => e.collect(t, this.Lo)));
	}
};
function __PRIVATE_newLocalStore(e, t, n, r) {
	return new __PRIVATE_LocalStoreImpl(e, t, n, r);
}
/**
* Tells the LocalStore that the currently authenticated user has changed.
*
* In response the local store switches the mutation queue to the new user and
* returns any resulting document changes.
*/
async function __PRIVATE_localStoreHandleUserChange(e, t) {
	const n = __PRIVATE_debugCast(e);
	return await n.persistence.runTransaction("Handle user change", "readonly", ((e) => {
		let r;
		return n.mutationQueue.getAllMutationBatches(e).next(((i) => (r = i, n.qo(t), n.mutationQueue.getAllMutationBatches(e)))).next(((t) => {
			const i = [], s = [];
			let _ = __PRIVATE_documentKeySet();
			for (const e of r) {
				i.push(e.batchId);
				for (const t of e.mutations) _ = _.add(t.key);
			}
			for (const e of t) {
				s.push(e.batchId);
				for (const t of e.mutations) _ = _.add(t.key);
			}
			return n.localDocuments.getDocuments(e, _).next(((e) => ({
				$o: e,
				removedBatchIds: i,
				addedBatchIds: s
			})));
		}));
	}));
}
/**
* Acknowledges the given batch.
*
* On the happy path when a batch is acknowledged, the local store will
*
*  + remove the batch from the mutation queue;
*  + apply the changes to the remote document cache;
*  + recalculate the latency compensated view implied by those changes (there
*    may be mutations in the queue that affect the documents but haven't been
*    acknowledged yet); and
*  + give the changed documents back the sync engine
*
* @returns The resulting (modified) documents.
*/
function __PRIVATE_localStoreAcknowledgeBatch(e, t) {
	const n = __PRIVATE_debugCast(e);
	return n.persistence.runTransaction("Acknowledge batch", "readwrite-primary", ((e) => {
		const r = t.batch.keys(), i = n.ko.newChangeBuffer({ trackRemovals: true });
		return function __PRIVATE_applyWriteToRemoteDocuments(e, t, n, r) {
			const i = n.batch, s = i.keys();
			let _ = PersistencePromise.resolve();
			return s.forEach(((e) => {
				_ = _.next((() => r.getEntry(t, e))).next(((t) => {
					const s = n.docVersions.get(e);
					__PRIVATE_hardAssert(null !== s, 48541), t.version.compareTo(s) < 0 && (i.applyToRemoteDocument(t, n), t.isValidDocument() && (t.setReadTime(n.commitVersion), r.addEntry(t)));
				}));
			})), _.next((() => e.mutationQueue.removeMutationBatch(t, i)));
		}(n, e, t, i).next((() => i.apply(e))).next((() => n.mutationQueue.performConsistencyCheck(e))).next((() => n.documentOverlayCache.removeOverlaysForBatchId(e, r, t.batch.batchId))).next((() => n.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(e, function __PRIVATE_getKeysWithTransformResults(e) {
			let t = __PRIVATE_documentKeySet();
			for (let n = 0; n < e.mutationResults.length; ++n) e.mutationResults[n].transformResults.length > 0 && (t = t.add(e.batch.mutations[n].key));
			return t;
		}(t)))).next((() => n.localDocuments.getDocuments(e, r)));
	}));
}
/**
* Returns the last consistent snapshot processed (used by the RemoteStore to
* determine whether to buffer incoming snapshots from the backend).
*/
function __PRIVATE_localStoreGetLastRemoteSnapshotVersion(e) {
	const t = __PRIVATE_debugCast(e);
	return t.persistence.runTransaction("Get last remote snapshot version", "readonly", ((e) => t.V_.getLastRemoteSnapshotVersion(e)));
}
/**
* Updates the "ground-state" (remote) documents. We assume that the remote
* event reflects any write batches that have been acknowledged or rejected
* (i.e. we do not re-apply local mutations to updates from this event).
*
* LocalDocuments are re-calculated if there are remaining mutations in the
* queue.
*/ function __PRIVATE_localStoreApplyRemoteEventToLocalCache(e, t) {
	const n = __PRIVATE_debugCast(e), r = t.snapshotVersion;
	let i = n.Lo;
	return n.persistence.runTransaction("Apply remote event", "readwrite-primary", ((e) => {
		const s = n.ko.newChangeBuffer({ trackRemovals: true });
		i = n.Lo;
		const _ = [];
		t.targetChanges.forEach(((s, o) => {
			const a = i.get(o);
			if (!a) return;
			_.push(n.V_.removeMatchingKeys(e, s.removedDocuments, o).next((() => n.V_.addMatchingKeys(e, s.addedDocuments, o))));
			let u = a.withSequenceNumber(e.currentSequenceNumber);
			null !== t.targetMismatches.get(o) ? u = u.withResumeToken(ByteString.EMPTY_BYTE_STRING, SnapshotVersion.min()).withLastLimboFreeSnapshotVersion(SnapshotVersion.min()) : s.resumeToken.approximateByteSize() > 0 && (u = u.withResumeToken(s.resumeToken, r)), i = i.insert(o, u), function __PRIVATE_shouldPersistTargetData(e, t, n) {
				if (0 === e.resumeToken.approximateByteSize()) return true;
				if (t.snapshotVersion.toMicroseconds() - e.snapshotVersion.toMicroseconds() >= Er) return true;
				return n.addedDocuments.size + n.modifiedDocuments.size + n.removedDocuments.size > 0;
			}(a, u, s) && _.push(n.V_.updateTargetData(e, u));
		}));
		let o = __PRIVATE_mutableDocumentMap(), a = __PRIVATE_documentKeySet();
		if (t.documentUpdates.forEach(((r) => {
			t.resolvedLimboDocuments.has(r) && _.push(n.persistence.referenceDelegate.updateLimboDocument(e, r));
		})), _.push(__PRIVATE_populateDocumentChangeBuffer(e, s, t.documentUpdates).next(((e) => {
			o = e.Ko, a = e.Qo;
		}))), !r.isEqual(SnapshotVersion.min())) {
			const t = n.V_.getLastRemoteSnapshotVersion(e).next(((t) => n.V_.setTargetsMetadata(e, e.currentSequenceNumber, r)));
			_.push(t);
		}
		return PersistencePromise.waitFor(_).next((() => s.apply(e))).next((() => n.localDocuments.getLocalViewOfDocuments(e, o, a))).next((() => o));
	})).then(((e) => (n.Lo = i, e)));
}
/**
* Populates document change buffer with documents from backend or a bundle.
* Returns the document changes resulting from applying those documents, and
* also a set of documents whose existence state are changed as a result.
*
* @param txn - Transaction to use to read existing documents from storage.
* @param documentBuffer - Document buffer to collect the resulted changes to be
*        applied to storage.
* @param documents - Documents to be applied.
*/ function __PRIVATE_populateDocumentChangeBuffer(e, t, n) {
	let r = __PRIVATE_documentKeySet(), i = __PRIVATE_documentKeySet();
	return n.forEach(((e) => r = r.add(e))), t.getEntries(e, r).next(((e) => {
		let r = __PRIVATE_mutableDocumentMap();
		return n.forEach(((n, s) => {
			const _ = e.get(n);
			s.isFoundDocument() !== _.isFoundDocument() && (i = i.add(n)), s.isNoDocument() && s.version.isEqual(SnapshotVersion.min()) ? (t.removeEntry(n, s.readTime), r = r.insert(n, s)) : !_.isValidDocument() || s.version.compareTo(_.version) > 0 || 0 === s.version.compareTo(_.version) && _.hasPendingWrites ? (t.addEntry(s), r = r.insert(n, s)) : __PRIVATE_logDebug(lr, "Ignoring outdated watch update for ", n, ". Current version:", _.version, " Watch version:", s.version);
		})), {
			Ko: r,
			Qo: i
		};
	}));
}
/**
* Gets the mutation batch after the passed in batchId in the mutation queue
* or null if empty.
* @param afterBatchId - If provided, the batch to search after.
* @returns The next mutation or null if there wasn't one.
*/
function __PRIVATE_localStoreGetNextMutationBatch(e, t) {
	const n = __PRIVATE_debugCast(e);
	return n.persistence.runTransaction("Get next mutation batch", "readonly", ((e) => (void 0 === t && (t = Ke), n.mutationQueue.getNextMutationBatchAfterBatchId(e, t))));
}
/**
* Reads the current value of a Document with a given key or null if not
* found - used for testing.
*/
/**
* Assigns the given target an internal ID so that its results can be pinned so
* they don't get GC'd. A target must be allocated in the local store before
* the store can be used to manage its view.
*
* Allocating an already allocated `Target` will return the existing `TargetData`
* for that `Target`.
*/
function __PRIVATE_localStoreAllocateTarget(e, t) {
	const n = __PRIVATE_debugCast(e);
	return n.persistence.runTransaction("Allocate target", "readwrite", ((e) => {
		let r;
		return n.V_.getTargetData(e, t).next(((i) => i ? (r = i, PersistencePromise.resolve(r)) : n.V_.allocateTargetId(e).next(((i) => (r = new TargetData(t, i, "TargetPurposeListen", e.currentSequenceNumber), n.V_.addTargetData(e, r).next((() => r)))))));
	})).then(((e) => {
		const r = n.Lo.get(e.targetId);
		return (null === r || e.snapshotVersion.compareTo(r.snapshotVersion) > 0) && (n.Lo = n.Lo.insert(e.targetId, e), n.Bo.set(t, e.targetId)), e;
	}));
}
/**
* Returns the TargetData as seen by the LocalStore, including updates that may
* have not yet been persisted to the TargetCache.
*/
/**
* Unpins all the documents associated with the given target. If
* `keepPersistedTargetData` is set to false and Eager GC enabled, the method
* directly removes the associated target data from the target cache.
*
* Releasing a non-existing `Target` is a no-op.
*/
async function __PRIVATE_localStoreReleaseTarget(e, t, n) {
	const r = __PRIVATE_debugCast(e), i = r.Lo.get(t), s = n ? "readwrite" : "readwrite-primary";
	try {
		n || await r.persistence.runTransaction("Release target", s, ((e) => r.persistence.referenceDelegate.removeTarget(e, i)));
	} catch (e) {
		if (!__PRIVATE_isIndexedDbTransactionError(e)) throw e;
		__PRIVATE_logDebug(lr, `Failed to update sequence numbers for target ${t}: ${e}`);
	}
	r.Lo = r.Lo.remove(t), r.Bo.delete(i.target);
}
/**
* Runs the specified query against the local store and returns the results,
* potentially taking advantage of query data from previous executions (such
* as the set of remote keys).
*
* @param usePreviousResults - Whether results from previous executions can
* be used to optimize this query execution.
*/ function __PRIVATE_localStoreExecuteQuery(e, t, n) {
	const r = __PRIVATE_debugCast(e);
	let i = SnapshotVersion.min(), s = __PRIVATE_documentKeySet();
	return r.persistence.runTransaction("Execute query", "readwrite", ((e) => function __PRIVATE_localStoreGetTargetData(e, t, n) {
		const r = __PRIVATE_debugCast(e), i = r.Bo.get(n);
		return void 0 !== i ? PersistencePromise.resolve(r.Lo.get(i)) : r.V_.getTargetData(t, n);
	}(r, e, __PRIVATE_isPipeline(t) ? t : __PRIVATE_queryToTarget(t)).next(((t) => {
		if (t) return i = t.lastLimboFreeSnapshotVersion, r.V_.getMatchingKeysForTargetId(e, t.targetId).next(((e) => {
			s = e;
		}));
	})).next((() => r.No.getDocumentsMatchingQuery(e, t, n ? i : SnapshotVersion.min(), n ? s : __PRIVATE_documentKeySet()))).next(((e) => (__PRIVATE_setMaxReadTime(r, e), {
		documents: e,
		Wo: s
	})))));
}
/** Sets the collection group's maximum read time from the given documents. */
function __PRIVATE_setMaxReadTime(e, t) {
	t.forEach(((t, n) => {
		const r = n.key.getCollectionGroup(), i = e.Uo.get(r) || SnapshotVersion.min();
		n.readTime.compareTo(i) > 0 && e.Uo.set(r, n.readTime);
	}));
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* On web, a `ReadableStream` is wrapped around by a `ByteStreamReader`.
*/
/**
* A component used by the RemoteStore to track the OnlineState (that is,
* whether or not the client as a whole should be considered to be online or
* offline), implementing the appropriate heuristics.
*
* In particular, when the client is trying to connect to the backend, we
* allow up to MAX_WATCH_STREAM_FAILURES within ONLINE_STATE_TIMEOUT_MS for
* a connection to succeed. If we have too many failures or the timeout elapses,
* then we set the OnlineState to Offline, and the client will behave as if
* it is offline (get()s will return cached data, etc.).
*/
var __PRIVATE_OnlineStateTracker = class {
	constructor(e, t) {
		this.asyncQueue = e, this.onlineStateHandler = t, this.state = "Unknown", this.Yo = 0, this.Zo = null, this.Xo = true;
	}
	/**
	* Called by RemoteStore when a watch stream is started (including on each
	* backoff attempt).
	*
	* If this is the first attempt, it sets the OnlineState to Unknown and starts
	* the onlineStateTimer.
	*/ ea() {
		0 === this.Yo && (this.ta("Unknown"), this.Zo = this.asyncQueue.enqueueAfterDelay("online_state_timeout", 1e4, (() => (this.Zo = null, this.na("Backend didn't respond within 10 seconds."), this.ta("Offline"), Promise.resolve()))));
	}
	/**
	* Updates our OnlineState as appropriate after the watch stream reports a
	* failure. The first failure moves us to the 'Unknown' state. We then may
	* allow multiple failures (based on MAX_WATCH_STREAM_FAILURES) before we
	* actually transition to the 'Offline' state.
	*/ ra(e) {
		"Online" === this.state ? this.ta("Unknown") : (this.Yo++, this.Yo >= 1 && (this.ia(), this.na(`Connection failed 1 times. Most recent error: ${e.toString()}`), this.ta("Offline")));
	}
	/**
	* Explicitly sets the OnlineState to the specified state.
	*
	* Note that this resets our timers / failure counters, etc. used by our
	* Offline heuristics, so must not be used in place of
	* handleWatchStreamStart() and handleWatchStreamFailure().
	*/ set(e) {
		this.ia(), this.Yo = 0, "Online" === e && (this.Xo = false), this.ta(e);
	}
	ta(e) {
		e !== this.state && (this.state = e, this.onlineStateHandler(e));
	}
	na(e) {
		const t = `Could not reach Cloud Firestore backend. ${e}\nThis typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;
		this.Xo ? (__PRIVATE_logError(t), this.Xo = false) : __PRIVATE_logDebug("OnlineStateTracker", t);
	}
	ia() {
		null !== this.Zo && (this.Zo.cancel(), this.Zo = null);
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var hr = "RemoteStore";
var __PRIVATE_RemoteStoreImpl = class {
	constructor(e, t, n, r, i) {
		this.localStore = e, this.datastore = t, this.asyncQueue = n, this.remoteSyncer = {}, this.sa = [], this._a = /* @__PURE__ */ new Map(), this.oa = /* @__PURE__ */ new Map(), this.aa = /* @__PURE__ */ new Map(), this.ua = new __PRIVATE_TargetIdGenerator(1e3), this.ca = new __PRIVATE_TargetIdGenerator(1001), this.la = /* @__PURE__ */ new Set(), this.Ea = [], this.ha = i, this.ha.Qe(((e) => {
			n.enqueueAndForget((async () => {
				__PRIVATE_canUseNetwork(this) && (__PRIVATE_logDebug(hr, "Restarting streams for network reachability change."), await async function __PRIVATE_restartNetwork(e) {
					const t = __PRIVATE_debugCast(e);
					t.la.add(4), await __PRIVATE_disableNetworkInternal(t), t.Ta.set("Unknown"), t.la.delete(4), await __PRIVATE_enableNetworkInternal(t);
				}(this));
			}));
		})), this.Ta = new __PRIVATE_OnlineStateTracker(n, r);
	}
};
async function __PRIVATE_enableNetworkInternal(e) {
	if (__PRIVATE_canUseNetwork(e)) for (const t of e.Ea) await t(true);
}
/**
* Temporarily disables the network. The network can be re-enabled using
* enableNetwork().
*/ async function __PRIVATE_disableNetworkInternal(e) {
	for (const t of e.Ea) await t(false);
}
/**
* Returns the remote target ID currently mapped to this
* sdkTargetId. Or returns `0` if the SDK target ID
* is not currently mapped.
* @param remoteStoreImpl
* @param sdkTargetId
*/
function __PRIVATE_getRemoteTargetId(e, t) {
	return e.oa.get(t) || void 0;
}
/**
* Generates a new remote target ID that is acceptable
* to map to the given SDK target ID.
* @param remoteStoreImpl
* @param sdkTargetId
*/
/**
* Starts new listen for the given target. Uses resume token if provided. It
* is a no-op if the target of given `TargetData` is already being listened to.
*/
function __PRIVATE_remoteStoreListen(e, t) {
	const n = __PRIVATE_debugCast(e), r = __PRIVATE_getRemoteTargetId(n, t.targetId);
	if (void 0 !== r && n._a.has(r)) return;
	const i = function __PRIVATE_allocateRemoteTargetId(e, t) {
		const n = __PRIVATE_getRemoteTargetId(e, t);
		void 0 !== n && e.aa.delete(n);
		const r = function __PRIVATE_generateRemoteTargetId(e, t) {
			return t % 2 != 0 ? e.ca.next() : e.ua.next();
		}(e, t);
		return e.oa.set(t, r), e.aa.set(r, t), r;
	}(n, t.targetId);
	__PRIVATE_logDebug(hr, "remoteStoreListen mapping SDK target ID to remote", t.targetId, i);
	const s = new TargetData(t.target, i, t.purpose, t.sequenceNumber, t.snapshotVersion, t.lastLimboFreeSnapshotVersion, t.resumeToken);
	n._a.set(i, s), __PRIVATE_shouldStartWatchStream(n) ? __PRIVATE_startWatchStream(n) : __PRIVATE_ensureWatchStream(n).Yt() && __PRIVATE_sendWatchRequest(n, s);
}
/**
* Removes the listen from server. It is a no-op if the given target id is
* not being listened to.
*/ function __PRIVATE_remoteStoreUnlisten(e, t) {
	const n = __PRIVATE_debugCast(e), r = __PRIVATE_ensureWatchStream(n), i = __PRIVATE_getRemoteTargetId(n, t);
	__PRIVATE_logDebug(hr, "remoteStoreUnlisten removing mapping of SDK target ID to remote", t, i), n._a.delete(i), n.oa.delete(t), n.aa.delete(i), r.Yt() && __PRIVATE_sendUnwatchRequest(n, i), 0 === n._a.size && (r.Yt() ? r.en() : __PRIVATE_canUseNetwork(n) && n.Ta.set("Unknown"));
}
/**
* We need to increment the expected number of pending responses we're due
* from watch so we wait for the ack to process any messages from this target.
*/ function __PRIVATE_sendWatchRequest(e, t) {
	if (e.Pa.J(t.targetId), t.resumeToken.approximateByteSize() > 0 || t.snapshotVersion.compareTo(SnapshotVersion.min()) > 0) {
		const n = e.aa.get(t.targetId);
		if (void 0 === n) return void __PRIVATE_logDebug(hr, "SDK target ID not found for remote ID: " + t.targetId);
		const r = e.remoteSyncer.getRemoteKeysForTarget(n).size;
		t = t.withExpectedCount(r);
	}
	__PRIVATE_ensureWatchStream(e).Pn(t);
}
/**
* We need to increment the expected number of pending responses we're due
* from watch so we wait for the removal on the server before we process any
* messages from this target.
*/ function __PRIVATE_sendUnwatchRequest(e, t) {
	e.Pa.J(t), __PRIVATE_ensureWatchStream(e).In(t);
}
function __PRIVATE_startWatchStream(e) {
	e.Pa = new __PRIVATE_WatchChangeAggregator({
		getRemoteKeysForTarget: (t) => {
			const n = e.aa.get(t);
			return void 0 !== n ? e.remoteSyncer.getRemoteKeysForTarget(n) : __PRIVATE_documentKeySet();
		},
		ye: (t) => e._a.get(t) || null,
		Ve: () => e.datastore.serializer.databaseId
	}), __PRIVATE_ensureWatchStream(e).start(), e.Ta.ea();
}
/**
* Returns whether the watch stream should be started because it's necessary
* and has not yet been started.
*/ function __PRIVATE_shouldStartWatchStream(e) {
	return __PRIVATE_canUseNetwork(e) && !__PRIVATE_ensureWatchStream(e).Jt() && e._a.size > 0;
}
function __PRIVATE_canUseNetwork(e) {
	return 0 === __PRIVATE_debugCast(e).la.size;
}
function __PRIVATE_cleanUpWatchStreamState(e) {
	e.Pa = void 0;
}
async function __PRIVATE_onWatchStreamConnected(e) {
	e.Ta.set("Online");
}
async function __PRIVATE_onWatchStreamOpen(e) {
	e._a.forEach(((t, n) => {
		__PRIVATE_sendWatchRequest(e, t);
	}));
}
async function __PRIVATE_onWatchStreamClose(e, t) {
	__PRIVATE_cleanUpWatchStreamState(e), __PRIVATE_shouldStartWatchStream(e) ? (e.Ta.ra(t), __PRIVATE_startWatchStream(e)) : e.Ta.set("Unknown");
}
async function __PRIVATE_onWatchStreamChange(e, t, n) {
	if (e.Ta.set("Online"), t instanceof __PRIVATE_WatchTargetChange && 2 === t.state && t.cause) try {
		/** Handles an error on a target */
		await async function __PRIVATE_handleTargetError(e, t) {
			const n = t.cause;
			for (const r of t.targetIds) {
				if (e._a.has(r)) {
					const t = e.aa.get(r);
					void 0 !== t && (await e.remoteSyncer.rejectListen(t, n), e.oa.delete(t), e.aa.delete(r)), e._a.delete(r);
				}
				e.Pa.removeTarget(r);
			}
		}(e, t);
	} catch (n) {
		__PRIVATE_logDebug(hr, "Failed to remove targets %s: %s ", t.targetIds.join(","), n), await __PRIVATE_disableNetworkUntilRecovery(e, n);
	}
	else if (t instanceof __PRIVATE_DocumentWatchChange ? e.Pa._e(t) : t instanceof __PRIVATE_ExistenceFilterChange ? e.Pa.he(t) : e.Pa.ue(t), !n.isEqual(SnapshotVersion.min())) try {
		const t = await __PRIVATE_localStoreGetLastRemoteSnapshotVersion(e.localStore);
		n.compareTo(t) >= 0 && await function __PRIVATE_raiseWatchSnapshot(e, t) {
			const n = e.Pa.fe(t);
			n.targetChanges.forEach(((n, r) => {
				if (n.resumeToken.approximateByteSize() > 0) {
					const i = e._a.get(r);
					i && e._a.set(r, i.withResumeToken(n.resumeToken, t));
				}
			})), n.targetMismatches.forEach(((t, n) => {
				const r = e._a.get(t);
				if (!r) return;
				e._a.set(t, r.withResumeToken(ByteString.EMPTY_BYTE_STRING, r.snapshotVersion)), __PRIVATE_sendUnwatchRequest(e, t);
				__PRIVATE_sendWatchRequest(e, new TargetData(r.target, t, n, r.sequenceNumber));
			}));
			const r = function __PRIVATE_toSdkRemoteEvent(e, t) {
				const n = /* @__PURE__ */ new Map();
				t.targetChanges.forEach(((t, r) => {
					const i = e.aa.get(r);
					void 0 !== i && n.set(i, t);
				}));
				let r = new SortedMap(__PRIVATE_primitiveComparator);
				return t.targetMismatches.forEach(((t, n) => {
					const i = e.aa.get(t);
					void 0 !== i && (r = r.insert(i, n));
				})), new RemoteEvent(t.snapshotVersion, n, r, t.documentUpdates, t.augmentedDocumentUpdates, t.resolvedLimboDocuments);
			}(e, n);
			return e.remoteSyncer.applyRemoteEvent(r);
		}(e, n);
	} catch (t) {
		__PRIVATE_logDebug(hr, "Failed to raise snapshot:", t), await __PRIVATE_disableNetworkUntilRecovery(e, t);
	}
}
/**
* Recovery logic for IndexedDB errors that takes the network offline until
* `op` succeeds. Retries are scheduled with backoff using
* `enqueueRetryable()`. If `op()` is not provided, IndexedDB access is
* validated via a generic operation.
*
* The returned Promise is resolved once the network is disabled and before
* any retry attempt.
*/ async function __PRIVATE_disableNetworkUntilRecovery(e, t, n) {
	if (!__PRIVATE_isIndexedDbTransactionError(t)) throw t;
	e.la.add(1), await __PRIVATE_disableNetworkInternal(e), e.Ta.set("Offline"), n || (n = () => __PRIVATE_localStoreGetLastRemoteSnapshotVersion(e.localStore)), e.asyncQueue.enqueueRetryable((async () => {
		__PRIVATE_logDebug(hr, "Retrying IndexedDB access"), await n(), e.la.delete(1), await __PRIVATE_enableNetworkInternal(e);
	}));
}
/**
* Executes `op`. If `op` fails, takes the network offline until `op`
* succeeds. Returns after the first attempt.
*/ function __PRIVATE_executeWithRecovery(e, t) {
	return t().catch(((n) => __PRIVATE_disableNetworkUntilRecovery(e, n, t)));
}
async function __PRIVATE_fillWritePipeline(e) {
	const t = __PRIVATE_debugCast(e), n = __PRIVATE_ensureWriteStream(t);
	let r = t.sa.length > 0 ? t.sa[t.sa.length - 1].batchId : Ke;
	for (; __PRIVATE_canAddToWritePipeline(t);) try {
		const e = await __PRIVATE_localStoreGetNextMutationBatch(t.localStore, r);
		if (null === e) {
			0 === t.sa.length && n.en();
			break;
		}
		r = e.batchId, __PRIVATE_addToWritePipeline(t, e);
	} catch (e) {
		await __PRIVATE_disableNetworkUntilRecovery(t, e);
	}
	__PRIVATE_shouldStartWriteStream(t) && __PRIVATE_startWriteStream(t);
}
/**
* Returns true if we can add to the write pipeline (i.e. the network is
* enabled and the write pipeline is not full).
*/ function __PRIVATE_canAddToWritePipeline(e) {
	return __PRIVATE_canUseNetwork(e) && e.sa.length < 10;
}
/**
* Queues additional writes to be sent to the write stream, sending them
* immediately if the write stream is established.
*/ function __PRIVATE_addToWritePipeline(e, t) {
	e.sa.push(t);
	const n = __PRIVATE_ensureWriteStream(e);
	n.Yt() && n.Rn && n.An(t.mutations);
}
function __PRIVATE_shouldStartWriteStream(e) {
	return __PRIVATE_canUseNetwork(e) && !__PRIVATE_ensureWriteStream(e).Jt() && e.sa.length > 0;
}
function __PRIVATE_startWriteStream(e) {
	__PRIVATE_ensureWriteStream(e).start();
}
async function __PRIVATE_onWriteStreamOpen(e) {
	__PRIVATE_ensureWriteStream(e).fn();
}
async function __PRIVATE_onWriteHandshakeComplete(e) {
	const t = __PRIVATE_ensureWriteStream(e);
	for (const n of e.sa) t.An(n.mutations);
}
async function __PRIVATE_onMutationResult(e, t, n) {
	const r = e.sa.shift(), i = MutationBatchResult.from(r, t, n);
	await __PRIVATE_executeWithRecovery(e, (() => e.remoteSyncer.applySuccessfulWrite(i))), await __PRIVATE_fillWritePipeline(e);
}
async function __PRIVATE_onWriteStreamClose(e, t) {
	t && __PRIVATE_ensureWriteStream(e).Rn && await async function __PRIVATE_handleWriteError(e, t) {
		if (function __PRIVATE_isPermanentWriteError(e) {
			return __PRIVATE_isPermanentError(e) && e !== ta.ABORTED;
		}(t.code)) {
			const n = e.sa.shift();
			__PRIVATE_ensureWriteStream(e).Xt(), await __PRIVATE_executeWithRecovery(e, (() => e.remoteSyncer.rejectFailedWrite(n.batchId, t))), await __PRIVATE_fillWritePipeline(e);
		}
	}(e, t), __PRIVATE_shouldStartWriteStream(e) && __PRIVATE_startWriteStream(e);
}
async function __PRIVATE_remoteStoreHandleCredentialChange(e, t) {
	const n = __PRIVATE_debugCast(e);
	n.asyncQueue.verifyOperationInProgress(), __PRIVATE_logDebug(hr, "RemoteStore received new credentials");
	const r = __PRIVATE_canUseNetwork(n);
	n.la.add(3), await __PRIVATE_disableNetworkInternal(n), r && n.Ta.set("Unknown"), await n.remoteSyncer.handleCredentialChange(t), n.la.delete(3), await __PRIVATE_enableNetworkInternal(n);
}
/**
* Toggles the network state when the client gains or loses its primary lease.
*/ async function __PRIVATE_remoteStoreApplyPrimaryState(e, t) {
	const n = __PRIVATE_debugCast(e);
	t ? (n.la.delete(2), await __PRIVATE_enableNetworkInternal(n)) : t || (n.la.add(2), await __PRIVATE_disableNetworkInternal(n), n.Ta.set("Unknown"));
}
/**
* If not yet initialized, registers the WatchStream and its network state
* callback with `remoteStoreImpl`. Returns the existing stream if one is
* already available.
*
* PORTING NOTE: On iOS and Android, the WatchStream gets registered on startup.
* This is not done on Web to allow it to be tree-shaken.
*/ function __PRIVATE_ensureWatchStream(e) {
	return e.Ia || (e.Ia = function __PRIVATE_newPersistentWatchStream(e, t, n) {
		const r = __PRIVATE_debugCast(e);
		return r.pn(), new __PRIVATE_PersistentListenStream(t, r.connection, r.authCredentials, r.appCheckCredentials, r.serializer, n);
	}(e.datastore, e.asyncQueue, {
		ct: __PRIVATE_onWatchStreamConnected.bind(null, e),
		Et: __PRIVATE_onWatchStreamOpen.bind(null, e),
		Tt: __PRIVATE_onWatchStreamClose.bind(null, e),
		Tn: __PRIVATE_onWatchStreamChange.bind(null, e)
	}), e.Ea.push((async (t) => {
		t ? (e.Ia.Xt(), __PRIVATE_shouldStartWatchStream(e) ? __PRIVATE_startWatchStream(e) : e.Ta.set("Unknown")) : (await e.Ia.stop(), __PRIVATE_cleanUpWatchStreamState(e));
	}))), e.Ia;
}
/**
* If not yet initialized, registers the WriteStream and its network state
* callback with `remoteStoreImpl`. Returns the existing stream if one is
* already available.
*
* PORTING NOTE: On iOS and Android, the WriteStream gets registered on startup.
* This is not done on Web to allow it to be tree-shaken.
*/ function __PRIVATE_ensureWriteStream(e) {
	return e.Ra || (e.Ra = function __PRIVATE_newPersistentWriteStream(e, t, n) {
		const r = __PRIVATE_debugCast(e);
		return r.pn(), new __PRIVATE_PersistentWriteStream(t, r.connection, r.authCredentials, r.appCheckCredentials, r.serializer, n);
	}(e.datastore, e.asyncQueue, {
		ct: () => Promise.resolve(),
		Et: __PRIVATE_onWriteStreamOpen.bind(null, e),
		Tt: __PRIVATE_onWriteStreamClose.bind(null, e),
		Vn: __PRIVATE_onWriteHandshakeComplete.bind(null, e),
		dn: __PRIVATE_onMutationResult.bind(null, e)
	}), e.Ea.push((async (t) => {
		t ? (e.Ra.Xt(), await __PRIVATE_fillWritePipeline(e)) : (await e.Ra.stop(), e.sa.length > 0 && (__PRIVATE_logDebug(hr, `Stopping write stream with ${e.sa.length} pending writes`), e.sa = []));
	}))), e.Ra;
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var __PRIVATE_AsyncObserver = class {
	constructor(e) {
		this.observer = e, this.muted = false;
	}
	next(e) {
		this.muted || this.observer.next && this.Aa(this.observer.next, e);
	}
	error(e) {
		this.muted || (this.observer.error ? this.Aa(this.observer.error, e) : __PRIVATE_logError("Uncaught Error in snapshot listener:", e.toString()));
	}
	Va() {
		this.muted = true;
	}
	Aa(e, t) {
		setTimeout((() => {
			this.muted || e(t);
		}), 0);
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Represents an operation scheduled to be run in the future on an AsyncQueue.
*
* It is created via DelayedOperation.createAndSchedule().
*
* Supports cancellation (via cancel()) and early execution (via skipDelay()).
*
* Note: We implement `PromiseLike` instead of `Promise`, as the `Promise` type
* in newer versions of TypeScript defines `finally`, which is not available in
* IE.
*/
var DelayedOperation = class DelayedOperation {
	constructor(e, t, n, r, i) {
		this.asyncQueue = e, this.timerId = t, this.targetTimeMs = n, this.op = r, this.removalCallback = i, this.deferred = new __PRIVATE_Deferred(), this.then = this.deferred.promise.then.bind(this.deferred.promise), this.deferred.promise.catch(((e) => {}));
	}
	get promise() {
		return this.deferred.promise;
	}
	/**
	* Creates and returns a DelayedOperation that has been scheduled to be
	* executed on the provided asyncQueue after the provided delayMs.
	*
	* @param asyncQueue - The queue to schedule the operation on.
	* @param id - A Timer ID identifying the type of operation this is.
	* @param delayMs - The delay (ms) before the operation should be scheduled.
	* @param op - The operation to run.
	* @param removalCallback - A callback to be called synchronously once the
	*   operation is executed or canceled, notifying the AsyncQueue to remove it
	*   from its delayedOperations list.
	*   PORTING NOTE: This exists to prevent making removeDelayedOperation() and
	*   the DelayedOperation class public.
	*/ static createAndSchedule(e, t, n, r, i) {
		const s = Date.now() + n, _ = new DelayedOperation(e, t, s, r, i);
		return _.start(n), _;
	}
	/**
	* Starts the timer. This is called immediately after construction by
	* createAndSchedule().
	*/ start(e) {
		this.timerHandle = setTimeout((() => this.handleDelayElapsed()), e);
	}
	/**
	* Queues the operation to run immediately (if it hasn't already been run or
	* canceled).
	*/ skipDelay() {
		return this.handleDelayElapsed();
	}
	/**
	* Cancels the operation if it hasn't already been executed or canceled. The
	* promise will be rejected.
	*
	* As long as the operation has not yet been run, calling cancel() provides a
	* guarantee that the operation will not be run.
	*/ cancel(t) {
		null !== this.timerHandle && (this.clearTimeout(), this.deferred.reject(new e(ta.CANCELLED, "Operation cancelled" + (t ? ": " + t : ""))));
	}
	handleDelayElapsed() {
		this.asyncQueue.enqueueAndForget((() => null !== this.timerHandle ? (this.clearTimeout(), this.op().then(((e) => this.deferred.resolve(e)))) : Promise.resolve()));
	}
	clearTimeout() {
		null !== this.timerHandle && (this.removalCallback(this), clearTimeout(this.timerHandle), this.timerHandle = null);
	}
};
/**
* Returns a FirestoreError that can be surfaced to the user if the provided
* error is an IndexedDbTransactionError. Re-throws the error otherwise.
*/ function __PRIVATE_wrapInUserErrorIfRecoverable(t, n) {
	if (__PRIVATE_logError("AsyncQueue", `${n}: ${t}`), __PRIVATE_isIndexedDbTransactionError(t)) return new e(ta.UNAVAILABLE, `${n}: ${t}`);
	throw t;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2025 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2018 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Metadata state of the local client. Unlike `RemoteClientState`, this class is
* mutable and keeps track of all pending mutations, which allows us to
* update the range of pending mutation batch IDs as new mutations are added or
* removed.
*
* The data in `LocalClientState` is not read from WebStorage and instead
* updated via its instance methods. The updated state can be serialized via
* `toWebStorageJSON()`.
*/
var __PRIVATE_LocalClientState = class {
	constructor() {
		this.activeTargetIds = __PRIVATE_targetIdSet();
	}
	Ba(e) {
		this.activeTargetIds = this.activeTargetIds.add(e);
	}
	Ua(e) {
		this.activeTargetIds = this.activeTargetIds.delete(e);
	}
	/**
	* Converts this entry into a JSON-encoded format we can use for WebStorage.
	* Does not encode `clientId` as it is part of the key in WebStorage.
	*/ La() {
		const e = {
			activeTargetIds: this.activeTargetIds.toArray(),
			updateTimeMs: Date.now()
		};
		return JSON.stringify(e);
	}
};
var __PRIVATE_MemorySharedClientState = class {
	constructor() {
		this.fu = new __PRIVATE_LocalClientState(), this.mu = {}, this.onlineStateHandler = null, this.sequenceNumberHandler = null;
	}
	addPendingMutation(e) {}
	updateMutationState(e, t, n) {}
	addLocalQueryTarget(e, t = true) {
		return t && this.fu.Ba(e), this.mu[e] || "not-current";
	}
	updateQueryState(e, t, n) {
		this.mu[e] = t;
	}
	removeLocalQueryTarget(e) {
		this.fu.Ua(e);
	}
	isLocalQueryTarget(e) {
		return this.fu.activeTargetIds.has(e);
	}
	clearQueryState(e) {
		delete this.mu[e];
	}
	getAllActiveQueryTargets() {
		return this.fu.activeTargetIds;
	}
	isActiveQueryTarget(e) {
		return this.fu.activeTargetIds.has(e);
	}
	start() {
		return this.fu = new __PRIVATE_LocalClientState(), Promise.resolve();
	}
	handleUserChange(e, t, n) {}
	setOnlineState(e) {}
	shutdown() {}
	writeSequenceNumber(e) {}
	notifyBundleLoaded(e) {}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/** The Platform's 'document' implementation or null if not available. */ function getDocument() {
	return "undefined" != typeof document ? document : null;
}
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* DocumentSet is an immutable (copy-on-write) collection that holds documents
* in order specified by the provided comparator. We always add a document key
* comparator on top of what is provided to guarantee document equality based on
* the key.
*/ var DocumentSet = class DocumentSet {
	/**
	* Returns an empty copy of the existing DocumentSet, using the same
	* comparator.
	*/
	static emptySet(e) {
		return new DocumentSet(e.comparator);
	}
	/** The default ordering is by key if the comparator is omitted */ constructor(e) {
		this.comparator = e ? (t, n) => e(t, n) || DocumentKey.comparator(t.key, n.key) : (e, t) => DocumentKey.comparator(e.key, t.key), this.keyedMap = documentMap(), this.sortedSet = new SortedMap(this.comparator);
	}
	has(e) {
		return null != this.keyedMap.get(e);
	}
	get(e) {
		return this.keyedMap.get(e);
	}
	first() {
		return this.sortedSet.minKey();
	}
	last() {
		return this.sortedSet.maxKey();
	}
	isEmpty() {
		return this.sortedSet.isEmpty();
	}
	/**
	* Returns the index of the provided key in the document set, or -1 if the
	* document key is not present in the set;
	*/ indexOf(e) {
		const t = this.keyedMap.get(e);
		return t ? this.sortedSet.indexOf(t) : -1;
	}
	get size() {
		return this.sortedSet.size;
	}
	/** Iterates documents in order defined by "comparator" */ forEach(e) {
		this.sortedSet.inorderTraversal(((t, n) => (e(t), false)));
	}
	/** Inserts or updates a document with the same key */ add(e) {
		const t = this.delete(e.key);
		return t.copy(t.keyedMap.insert(e.key, e), t.sortedSet.insert(e, null));
	}
	/** Deletes a document with a given key */ delete(e) {
		const t = this.get(e);
		return t ? this.copy(this.keyedMap.remove(e), this.sortedSet.remove(t)) : this;
	}
	isEqual(e) {
		if (!(e instanceof DocumentSet)) return false;
		if (this.size !== e.size) return false;
		const t = this.sortedSet.getIterator(), n = e.sortedSet.getIterator();
		for (; t.hasNext();) {
			const e = t.getNext().key, r = n.getNext().key;
			if (!e.isEqual(r)) return false;
		}
		return true;
	}
	toString() {
		const e = [];
		return this.forEach(((t) => {
			e.push(t.toString());
		})), 0 === e.length ? "DocumentSet ()" : "DocumentSet (\n  " + e.join("  \n") + "\n)";
	}
	copy(e, t) {
		const n = new DocumentSet();
		return n.comparator = this.comparator, n.keyedMap = e, n.sortedSet = t, n;
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* DocumentChangeSet keeps track of a set of changes to docs in a query, merging
* duplicate events for the same doc.
*/ var __PRIVATE_DocumentChangeSet = class {
	constructor() {
		this.pu = new SortedMap(DocumentKey.comparator);
	}
	track(e) {
		const t = e.doc.key, n = this.pu.get(t);
		n ? 0 !== e.type && 3 === n.type ? this.pu = this.pu.insert(t, e) : 3 === e.type && 1 !== n.type ? this.pu = this.pu.insert(t, {
			type: n.type,
			doc: e.doc
		}) : 2 === e.type && 2 === n.type ? this.pu = this.pu.insert(t, {
			type: 2,
			doc: e.doc
		}) : 2 === e.type && 0 === n.type ? this.pu = this.pu.insert(t, {
			type: 0,
			doc: e.doc
		}) : 1 === e.type && 0 === n.type ? this.pu = this.pu.remove(t) : 1 === e.type && 2 === n.type ? this.pu = this.pu.insert(t, {
			type: 1,
			doc: n.doc
		}) : 0 === e.type && 1 === n.type ? this.pu = this.pu.insert(t, {
			type: 2,
			doc: e.doc
		}) : l(63341, {
			we: e,
			gu: n
		}) : this.pu = this.pu.insert(t, e);
	}
	yu() {
		const e = [];
		return this.pu.inorderTraversal(((t, n) => {
			e.push(n);
		})), e;
	}
};
var ViewSnapshot = class ViewSnapshot {
	constructor(e, t, n, r, i, s, _, o, a) {
		this.query = e, this.docs = t, this.oldDocs = n, this.docChanges = r, this.mutatedKeys = i, this.fromCache = s, this.syncStateChanged = _, this.excludesMetadataChanges = o, this.hasCachedResults = a;
	}
	/** Returns a view snapshot as if all documents in the snapshot were added. */ static fromInitialDocuments(e, t, n, r, i) {
		const s = [];
		return t.forEach(((e) => {
			s.push({
				type: 0,
				doc: e
			});
		})), new ViewSnapshot(e, t, DocumentSet.emptySet(t), s, n, r, true, false, i);
	}
	get hasPendingWrites() {
		return !this.mutatedKeys.isEmpty();
	}
	isEqual(e) {
		if (!(this.fromCache === e.fromCache && this.hasCachedResults === e.hasCachedResults && this.syncStateChanged === e.syncStateChanged && this.mutatedKeys.isEqual(e.mutatedKeys) && __PRIVATE_queryOrPipelineEqual(this.query, e.query) && this.docs.isEqual(e.docs) && this.oldDocs.isEqual(e.oldDocs))) return false;
		const t = this.docChanges, n = e.docChanges;
		if (t.length !== n.length) return false;
		for (let e = 0; e < t.length; e++) if (t[e].type !== n[e].type || !t[e].doc.isEqual(n[e].doc)) return false;
		return true;
	}
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Holds the listeners and the last received ViewSnapshot for a query being
* tracked by EventManager.
*/ var __PRIVATE_QueryListenersInfo = class {
	constructor() {
		this.wu = void 0, this.bu = [];
	}
	Su() {
		return this.bu.some(((e) => e.vu()));
	}
};
var __PRIVATE_EventManagerImpl = class {
	constructor() {
		this.queries = __PRIVATE_newQueriesObjectMap(), this.onlineState = "Unknown", this.Du = /* @__PURE__ */ new Set();
	}
	terminate() {
		(function __PRIVATE_errorAllTargets(e, t) {
			const n = __PRIVATE_debugCast(e), r = n.queries;
			n.queries = __PRIVATE_newQueriesObjectMap(), r.forEach(((e, n) => {
				for (const e of n.bu) e.onError(t);
			}));
		})(this, new e(ta.ABORTED, "Firestore shutting down"));
	}
};
function __PRIVATE_newQueriesObjectMap() {
	return new ObjectMap(((e) => __PRIVATE_canonifyQueryOrPipeline(e)), __PRIVATE_queryOrPipelineEqual);
}
async function __PRIVATE_eventManagerListen(e, t) {
	const n = __PRIVATE_debugCast(e);
	let r = 3;
	const i = t.query;
	let s = n.queries.get(i);
	s ? !s.Su() && t.vu() && (r = 2) : (s = new __PRIVATE_QueryListenersInfo(), r = t.vu() ? 0 : 1);
	try {
		switch (r) {
			case 0:
				s.wu = await n.onListen(
					i,
					/** enableRemoteListen= */
					!0
				);
				break;
			case 1:
				s.wu = await n.onListen(
					i,
					/** enableRemoteListen= */
					!1
				);
				break;
			case 2: await n.onFirstRemoteStoreListen(i);
		}
	} catch (e) {
		const n = __PRIVATE_wrapInUserErrorIfRecoverable(e, `Initialization of query '${__PRIVATE_isPipeline(t.query) ? __PRIVATE_canonifyPipeline(t.query) : __PRIVATE_stringifyQuery(t.query)}' failed`);
		t.onError(n);
		return;
	}
	if (n.queries.set(i, s), s.bu.push(t), t.xu(n.onlineState), s.wu) t.Cu(s.wu) && __PRIVATE_raiseSnapshotsInSyncEvent(n);
}
async function __PRIVATE_eventManagerUnlisten(e, t) {
	const n = __PRIVATE_debugCast(e), r = t.query;
	let i = 3;
	const s = n.queries.get(r);
	if (s) {
		const e = s.bu.indexOf(t);
		e >= 0 && (s.bu.splice(e, 1), 0 === s.bu.length ? i = t.vu() ? 0 : 1 : !s.Su() && t.vu() && (i = 2));
	}
	switch (i) {
		case 0: return n.queries.delete(r), n.onUnlisten(
			r,
			/** disableRemoteListen= */
			true
		);
		case 1: return n.queries.delete(r), n.onUnlisten(
			r,
			/** disableRemoteListen= */
			false
		);
		case 2: return n.onLastRemoteStoreUnlisten(r);
		default: return;
	}
}
function __PRIVATE_eventManagerOnWatchChange(e, t) {
	const n = __PRIVATE_debugCast(e);
	let r = false;
	for (const e of t) {
		const t = e.query, i = n.queries.get(t);
		if (i) {
			for (const t of i.bu) t.Cu(e) && (r = true);
			i.wu = e;
		}
	}
	r && __PRIVATE_raiseSnapshotsInSyncEvent(n);
}
function __PRIVATE_eventManagerOnWatchError(e, t, n) {
	const r = __PRIVATE_debugCast(e), i = r.queries.get(t);
	if (i) for (const e of i.bu) e.onError(n);
	r.queries.delete(t);
}
function __PRIVATE_raiseSnapshotsInSyncEvent(e) {
	e.Du.forEach(((e) => {
		e.next();
	}));
}
var Vr;
(function(e) {
	/** Listen to both cache and server changes */
	e.Default = "default", e.Cache = "cache";
})(Vr || (Vr = {}));
/**
* QueryListener takes a series of internal view snapshots and determines
* when to raise the event.
*
* It uses an Observer to dispatch events.
*/
var __PRIVATE_QueryListener = class {
	constructor(e, t, n) {
		this.query = e, this.Fu = t, this.Ou = false, this.Mu = null, this.onlineState = "Unknown", this.options = n || {};
	}
	/**
	* Applies the new ViewSnapshot to this listener, raising a user-facing event
	* if applicable (depending on what changed, whether the user has opted into
	* metadata-only changes, etc.). Returns true if a user-facing event was
	* indeed raised.
	*/ Cu(e) {
		if (!this.options.includeMetadataChanges) {
			const t = [];
			for (const n of e.docChanges) 3 !== n.type && t.push(n);
			e = new ViewSnapshot(e.query, e.docs, e.oldDocs, t, e.mutatedKeys, e.fromCache, e.syncStateChanged, true, e.hasCachedResults);
		}
		let t = false;
		return this.Ou ? this.Nu(e) && (this.Fu.next(e), t = true) : this.Lu(e, this.onlineState) && (this.Bu(e), t = true), this.Mu = e, t;
	}
	onError(e) {
		this.Fu.error(e);
	}
	/** Returns whether a snapshot was raised. */ xu(e) {
		this.onlineState = e;
		let t = false;
		return this.Mu && !this.Ou && this.Lu(this.Mu, e) && (this.Bu(this.Mu), t = true), t;
	}
	Lu(e, t) {
		if (!e.fromCache) return true;
		if (!this.vu()) return true;
		const n = "Offline" !== t;
		return (!this.options.waitForSyncWhenOnline || !n) && (!e.docs.isEmpty() || e.hasCachedResults || "Offline" === t);
	}
	Nu(e) {
		if (e.docChanges.length > 0) return true;
		const t = this.Mu && this.Mu.hasPendingWrites !== e.hasPendingWrites;
		return !(!e.syncStateChanged && !t) && true === this.options.includeMetadataChanges;
	}
	Bu(e) {
		e = ViewSnapshot.fromInitialDocuments(e.query, e.docs, e.mutatedKeys, e.fromCache, e.hasCachedResults), this.Ou = true, this.Fu.next(e);
	}
	vu() {
		return this.options.source !== Vr.Cache;
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Returns a `LoadBundleTaskProgress` representing the progress that the loading
* has succeeded.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var __PRIVATE_AddedLimboDocument = class {
	constructor(e) {
		this.key = e;
	}
};
var __PRIVATE_RemovedLimboDocument = class {
	constructor(e) {
		this.key = e;
	}
};
/**
* View is responsible for computing the final merged truth of what docs are in
* a query. It gets notified of local and remote changes to docs, and applies
* the query filters and limits to determine the most correct possible results.
*/ var __PRIVATE_View = class {
	constructor(e, t) {
		this.query = e, this.zu = t, this.ju = null, this.hasCachedResults = false, this.current = false, this.Hu = __PRIVATE_documentKeySet(), this.mutatedKeys = __PRIVATE_documentKeySet(), this.Ju = __PRIVATE_isPipeline(e) ? __PRIVATE_newPipelineComparator(e) : __PRIVATE_newQueryComparator(e), this.Yu = new DocumentSet(this.Ju);
	}
	/**
	* The set of remote documents that the server has told us belongs to the target associated with
	* this view.
	*/ get Zu() {
		return this.zu;
	}
	/**
	* Iterates over a set of doc changes, applies the query limit, and computes
	* what the new results should be, what the changes were, and whether we may
	* need to go back to the local cache for more results. Does not make any
	* changes to the view.
	* @param docChanges - The doc changes to apply to this view.
	* @param previousChanges - If this is being called with a refill, then start
	*        with this set of docs and changes instead of the current view.
	* @returns a new set of docs, changes, and refill flag.
	*/ Xu(e, t) {
		const n = t ? t.ec : new __PRIVATE_DocumentChangeSet(), r = t ? t.Yu : this.Yu;
		let i = t ? t.mutatedKeys : this.mutatedKeys, s = r, _ = false;
		const [o, a] = this.tc(this.query, r);
		e.inorderTraversal(((e, t) => {
			const u = r.get(e), c = __PRIVATE_queryOrPipelineMatches(this.query, t) ? t : null, l = !!u && this.mutatedKeys.has(u.key), E = !!c && (c.hasLocalMutations || this.mutatedKeys.has(c.key) && c.hasCommittedMutations);
			let h = false;
			if (u && c) u.data.isEqual(c.data) ? l !== E && (n.track({
				type: 3,
				doc: c
			}), h = true) : this.nc(u, c) || (n.track({
				type: 2,
				doc: c
			}), h = true, (o && this.Ju(c, o) > 0 || a && this.Ju(c, a) < 0) && (_ = true));
			else !u && c ? (n.track({
				type: 0,
				doc: c
			}), h = true) : u && !c && (n.track({
				type: 1,
				doc: u
			}), h = true, (o || a) && (_ = true));
			h && (c ? (s = s.add(c), i = E ? i.add(e) : i.delete(e)) : (s = s.delete(e), i = i.delete(e)));
		}));
		const u = this.rc(this.query);
		if (u) if (__PRIVATE_isPipeline(this.query)) {
			const e = [];
			s.forEach(((t) => e.push(t)));
			const t = __PRIVATE_runPipeline(this.query, e);
			let r = new DocumentSet(__PRIVATE_newPipelineComparator(this.query));
			for (const e of t) r = r.add(e);
			s.forEach(((e) => {
				r.has(e.key) || (i = i.delete(e.key), n.track({
					type: 1,
					doc: e
				}));
			})), s = r;
		} else {
			const e = this.sc(this.query);
			for (; s.size > u;) {
				const t = "F" === e ? s.last() : s.first();
				s = s.delete(t.key), i = i.delete(t.key), n.track({
					type: 1,
					doc: t
				});
			}
		}
		return {
			Yu: s,
			ec: n,
			Oo: _,
			mutatedKeys: i
		};
	}
	rc(e) {
		return __PRIVATE_isPipeline(e) ? __PRIVATE_getLastEffectiveLimit(e)?.limit : e.limit || void 0;
	}
	sc(e) {
		if (__PRIVATE_isPipeline(e)) {
			const t = __PRIVATE_getLastEffectiveLimit(e);
			return t && t.limit < 0 ? "L" : "F";
		}
		return e.limitType;
	}
	tc(e, t) {
		if (__PRIVATE_isPipeline(e)) {
			const n = __PRIVATE_getLastEffectiveLimit(e)?.limit;
			return [t.size === n ? t.last() : null, null];
		}
		return ["F" === e.limitType && t.size === this.rc(this.query) ? t.last() : null, "L" === e.limitType && t.size === this.rc(this.query) ? t.first() : null];
	}
	nc(e, t) {
		return e.hasLocalMutations && t.hasCommittedMutations && !t.hasLocalMutations;
	}
	/**
	* Updates the view with the given ViewDocumentChanges and optionally updates
	* limbo docs and sync state from the provided target change.
	* @param docChanges - The set of changes to make to the view's docs.
	* @param limboResolutionEnabled - Whether to update limbo documents based on
	*        this change.
	* @param targetChange - A target change to apply for computing limbo docs and
	*        sync state.
	* @param targetIsPendingReset - Whether the target is pending to reset due to
	*        existence filter mismatch. If not explicitly specified, it is treated
	*        equivalently to `false`.
	* @returns A new ViewChange with the given docs, changes, and sync state.
	*/
	applyChanges(e, t, n, r) {
		const i = this.Yu;
		this.Yu = e.Yu, this.mutatedKeys = e.mutatedKeys;
		const s = e.ec.yu();
		s.sort(((e, t) => function __PRIVATE_compareChangeType(e, t) {
			const order = (e) => {
				switch (e) {
					case 0: return 1;
					case 2:
					case 3: return 2;
					case 1: return 0;
					default: return l(20277, { we: e });
				}
			};
			return order(e) - order(t);
		}(e.type, t.type) || this.Ju(e.doc, t.doc))), this._c(n), r = r ?? false;
		/**
		* @license
		* Copyright 2020 Google LLC
		*
		* Licensed under the Apache License, Version 2.0 (the "License");
		* you may not use this file except in compliance with the License.
		* You may obtain a copy of the License at
		*
		*   http://www.apache.org/licenses/LICENSE-2.0
		*
		* Unless required by applicable law or agreed to in writing, software
		* distributed under the License is distributed on an "AS IS" BASIS,
		* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
		* See the License for the specific language governing permissions and
		* limitations under the License.
		*/
		const _ = t && !r ? this.oc() : [], o = 0 === this.Hu.size && this.current && !r ? 1 : 0, a = o !== this.ju;
		if (this.ju = o, 0 !== s.length || a) return {
			snapshot: new ViewSnapshot(this.query, e.Yu, i, s, e.mutatedKeys, 0 === o, a, false, !!n && n.resumeToken.approximateByteSize() > 0),
			ac: _
		};
		return { ac: _ };
	}
	/**
	* Applies an OnlineState change to the view, potentially generating a
	* ViewChange if the view's syncState changes as a result.
	*/ xu(e) {
		return this.current && "Offline" === e ? (this.current = false, this.applyChanges({
			Yu: this.Yu,
			ec: new __PRIVATE_DocumentChangeSet(),
			mutatedKeys: this.mutatedKeys,
			Oo: false
		}, false)) : { ac: [] };
	}
	/**
	* Returns whether the doc for the given key should be in limbo.
	*/ uc(e) {
		return !this.zu.has(e) && !!this.Yu.has(e) && !this.Yu.get(e).hasLocalMutations;
	}
	/**
	* Updates syncedDocuments, current, and limbo docs based on the given change.
	* Returns the list of changes to which docs are in limbo.
	*/ _c(e) {
		e && (e.addedDocuments.forEach(((e) => this.zu = this.zu.add(e))), e.modifiedDocuments.forEach(((e) => {})), e.removedDocuments.forEach(((e) => this.zu = this.zu.delete(e))), this.current = e.current);
	}
	oc() {
		if (!this.current) return [];
		const e = this.Hu;
		this.Hu = __PRIVATE_documentKeySet(), this.Yu.forEach(((e) => {
			this.uc(e.key) && (this.Hu = this.Hu.add(e.key));
		}));
		const t = [];
		return e.forEach(((e) => {
			this.Hu.has(e) || t.push(new __PRIVATE_RemovedLimboDocument(e));
		})), this.Hu.forEach(((n) => {
			e.has(n) || t.push(new __PRIVATE_AddedLimboDocument(n));
		})), t;
	}
	/**
	* Update the in-memory state of the current view with the state read from
	* persistence.
	*
	* We update the query view whenever a client's primary status changes:
	* - When a client transitions from primary to secondary, it can miss
	*   LocalStorage updates and its query views may temporarily not be
	*   synchronized with the state on disk.
	* - For secondary to primary transitions, the client needs to update the list
	*   of `syncedDocuments` since secondary clients update their query views
	*   based purely on synthesized RemoteEvents.
	*
	* @param queryResult.documents - The documents that match the query according
	* to the LocalStore.
	* @param queryResult.remoteKeys - The keys of the documents that match the
	* query according to the backend.
	*
	* @returns The ViewChange that resulted from this synchronization.
	*/
	cc(e) {
		this.zu = e.Wo, this.Hu = __PRIVATE_documentKeySet();
		const t = this.Xu(e.documents);
		return this.applyChanges(t, true);
	}
	/**
	* Returns a view snapshot as if this query was just listened to. Contains
	* a document add for every existing document and the `fromCache` and
	* `hasPendingWrites` status of the already established view.
	*/
	lc() {
		return ViewSnapshot.fromInitialDocuments(this.query, this.Yu, this.mutatedKeys, 0 === this.ju, this.hasCachedResults);
	}
};
var dr = "SyncEngine";
/**
* QueryView contains all of the data that SyncEngine needs to keep track of for
* a particular query.
*/ var __PRIVATE_QueryView = class {
	constructor(e, t, n) {
		this.query = e, this.targetId = t, this.view = n;
	}
};
/** Tracks a limbo resolution. */ var LimboResolution = class {
	constructor(e) {
		this.key = e, this.Ec = false;
	}
};
/**
* An implementation of `SyncEngine` coordinating with other parts of SDK.
*
* The parts of SyncEngine that act as a callback to RemoteStore need to be
* registered individually. This is done in `syncEngineWrite()` and
* `syncEngineListen()` (as well as `applyPrimaryState()`) as these methods
* serve as entry points to RemoteStore's functionality.
*
* Note: some field defined in this class might have public access level, but
* the class is not exported so they are only accessible from this module.
* This is useful to implement optional features (like bundles) in free
* functions, such that they are tree-shakeable.
*/ var __PRIVATE_SyncEngineImpl = class {
	constructor(e, t, n, r, i, s) {
		this.localStore = e, this.remoteStore = t, this.eventManager = n, this.sharedClientState = r, this.currentUser = i, this.maxConcurrentLimboResolutions = s, this.hc = {}, this.Tc = new ObjectMap(((e) => __PRIVATE_canonifyQueryOrPipeline(e)), __PRIVATE_queryOrPipelineEqual), this.Pc = /* @__PURE__ */ new Map(), this.Ic = /* @__PURE__ */ new Set(), this.Rc = new SortedMap(DocumentKey.comparator), this.Ac = /* @__PURE__ */ new Map(), this.Vc = new __PRIVATE_ReferenceSet(), this.dc = {}, this.fc = /* @__PURE__ */ new Map(), this.mc = __PRIVATE_TargetIdGenerator.bs(), this.onlineState = "Unknown", this.gc = void 0;
	}
	get isPrimaryClient() {
		return true === this.gc;
	}
};
/**
* Initiates the new listen, resolves promise when listen enqueued to the
* server. All the subsequent view snapshots or errors are sent to the
* subscribed handlers. Returns the initial snapshot.
*/
async function __PRIVATE_syncEngineListen(e, t, n = true) {
	const r = __PRIVATE_ensureWatchCallbacks(e);
	let i;
	const s = r.Tc.get(t);
	return s ? (r.sharedClientState.addLocalQueryTarget(s.targetId), i = s.view.lc()) : i = await __PRIVATE_allocateTargetAndMaybeListen(
		r,
		t,
		n,
		/** shouldInitializeView= */
		true
	), i;
}
/** Query has been listening to the cache, and tries to initiate the remote store listen */ async function __PRIVATE_triggerRemoteStoreListen(e, t) {
	await __PRIVATE_allocateTargetAndMaybeListen(
		__PRIVATE_ensureWatchCallbacks(e),
		t,
		/** shouldListenToRemote= */
		true,
		/** shouldInitializeView= */
		false
	);
}
async function __PRIVATE_allocateTargetAndMaybeListen(e, t, n, r) {
	const i = await __PRIVATE_localStoreAllocateTarget(e.localStore, __PRIVATE_isPipeline(t) ? t : __PRIVATE_queryToTarget(t)), s = i.targetId, _ = e.sharedClientState.addLocalQueryTarget(s, n);
	let o;
	return r && (o = await __PRIVATE_initializeViewAndComputeSnapshot(e, t, s, "current" === _, i.resumeToken)), e.isPrimaryClient && n && __PRIVATE_remoteStoreListen(e.remoteStore, i), o;
}
/**
* Registers a view for a previously unknown query and computes its initial
* snapshot.
*/ async function __PRIVATE_initializeViewAndComputeSnapshot(e, t, n, r, i) {
	e.yc = (t, n, r) => async function __PRIVATE_applyDocChanges(e, t, n, r) {
		let i = t.view.Xu(n);
		i.Oo && (i = await __PRIVATE_localStoreExecuteQuery(e.localStore, t.query, false).then((({ documents: e }) => t.view.Xu(e, i))));
		const s = r && r.targetChanges.get(t.targetId), _ = r && null != r.targetMismatches.get(t.targetId), o = t.view.applyChanges(i, e.isPrimaryClient, s, _);
		return __PRIVATE_updateTrackedLimbos(e, t.targetId, o.ac), o.snapshot;
	}(e, t, n, r);
	const s = await __PRIVATE_localStoreExecuteQuery(e.localStore, t, true), _ = new __PRIVATE_View(t, s.Wo), o = _.Xu(s.documents), a = TargetChange.createSynthesizedTargetChangeForCurrentChange(n, r && "Offline" !== e.onlineState, i), u = _.applyChanges(o, e.isPrimaryClient, a);
	__PRIVATE_updateTrackedLimbos(e, n, u.ac);
	const c = new __PRIVATE_QueryView(t, n, _);
	return e.Tc.set(t, c), e.Pc.has(n) ? e.Pc.get(n).push(t) : e.Pc.set(n, [t]), u.snapshot;
}
/** Stops listening to the query. */ async function __PRIVATE_syncEngineUnlisten(e, t, n) {
	const r = __PRIVATE_debugCast(e), i = r.Tc.get(t), s = r.Pc.get(i.targetId);
	if (s.length > 1) return r.Pc.set(i.targetId, s.filter(((e) => !__PRIVATE_queryOrPipelineEqual(e, t)))), void r.Tc.delete(t);
	if (r.isPrimaryClient) {
		r.sharedClientState.removeLocalQueryTarget(i.targetId);
		r.sharedClientState.isActiveQueryTarget(i.targetId) || await __PRIVATE_localStoreReleaseTarget(r.localStore, i.targetId, false).then((() => {
			r.sharedClientState.clearQueryState(i.targetId), n && __PRIVATE_remoteStoreUnlisten(r.remoteStore, i.targetId), __PRIVATE_removeAndCleanupTarget(r, i.targetId);
		})).catch(__PRIVATE_ignoreIfPrimaryLeaseLoss);
	} else __PRIVATE_removeAndCleanupTarget(r, i.targetId), await __PRIVATE_localStoreReleaseTarget(r.localStore, i.targetId, true);
}
/** Unlistens to the remote store while still listening to the cache. */ async function __PRIVATE_triggerRemoteStoreUnlisten(e, t) {
	const n = __PRIVATE_debugCast(e), r = n.Tc.get(t), i = n.Pc.get(r.targetId);
	n.isPrimaryClient && 1 === i.length && (n.sharedClientState.removeLocalQueryTarget(r.targetId), __PRIVATE_remoteStoreUnlisten(n.remoteStore, r.targetId));
}
/**
* Initiates the write of local mutation batch which involves adding the
* writes to the mutation queue, notifying the remote store about new
* mutations and raising events for any changes this write caused.
*
* The promise returned by this call is resolved when the above steps
* have completed, *not* when the write was acked by the backend. The
* userCallback is resolved once the write was acked/rejected by the
* backend (or failed locally for any other reason).
*/ async function __PRIVATE_syncEngineWrite(e, t, n) {
	const r = __PRIVATE_syncEngineEnsureWriteCallbacks(e);
	try {
		const e = await function __PRIVATE_localStoreWriteLocally(e, t) {
			const n = __PRIVATE_debugCast(e), r = Timestamp.now(), i = t.reduce(((e, t) => e.add(t.key)), __PRIVATE_documentKeySet());
			let s, _;
			return n.persistence.runTransaction("Locally write mutations", "readwrite", ((e) => {
				let o = __PRIVATE_mutableDocumentMap(), a = __PRIVATE_documentKeySet();
				return n.ko.getEntries(e, i).next(((e) => {
					o = e, o.forEach(((e, t) => {
						t.isValidDocument() || (a = a.add(e));
					}));
				})).next((() => n.localDocuments.getOverlayedDocuments(e, o))).next(((i) => {
					s = i;
					const _ = [];
					for (const e of t) {
						const t = __PRIVATE_mutationExtractBaseValue(e, s.get(e.key).overlayedDocument);
						null != t && _.push(new __PRIVATE_PatchMutation(e.key, t, __PRIVATE_extractFieldMask(t.value.mapValue), Precondition.exists(!0)));
					}
					return n.mutationQueue.addMutationBatch(e, r, _, t);
				})).next(((t) => {
					_ = t;
					const r = t.applyToLocalDocumentSet(s, a);
					return n.documentOverlayCache.saveOverlays(e, t.batchId, r);
				}));
			})).then((() => ({
				batchId: _.batchId,
				changes: __PRIVATE_convertOverlayedDocumentMapToDocumentMap(s)
			})));
		}(r.localStore, t);
		r.sharedClientState.addPendingMutation(e.batchId), function __PRIVATE_addMutationCallback(e, t, n) {
			let r = e.dc[e.currentUser.toKey()];
			r || (r = new SortedMap(__PRIVATE_primitiveComparator));
			r = r.insert(t, n), e.dc[e.currentUser.toKey()] = r;
		}(r, e.batchId, n), await __PRIVATE_syncEngineEmitNewSnapsAndNotifyLocalStore(r, e.changes), await __PRIVATE_fillWritePipeline(r.remoteStore);
	} catch (e) {
		const t = __PRIVATE_wrapInUserErrorIfRecoverable(e, "Failed to persist write");
		n.reject(t);
	}
}
/**
* Applies one remote event to the sync engine, notifying any views of the
* changes, and releasing any pending mutation batches that would become
* visible because of the snapshot version the remote event contains.
*/ async function __PRIVATE_syncEngineApplyRemoteEvent(e, t) {
	const n = __PRIVATE_debugCast(e);
	try {
		const e = await __PRIVATE_localStoreApplyRemoteEventToLocalCache(n.localStore, t);
		t.targetChanges.forEach(((e, t) => {
			const r = n.Ac.get(t);
			r && (__PRIVATE_hardAssert(e.addedDocuments.size + e.modifiedDocuments.size + e.removedDocuments.size <= 1, 22616), e.addedDocuments.size > 0 ? r.Ec = !0 : e.modifiedDocuments.size > 0 ? __PRIVATE_hardAssert(r.Ec, 14607) : e.removedDocuments.size > 0 && (__PRIVATE_hardAssert(r.Ec, 42227), r.Ec = !1));
		})), await __PRIVATE_syncEngineEmitNewSnapsAndNotifyLocalStore(n, e, t);
	} catch (e) {
		await __PRIVATE_ignoreIfPrimaryLeaseLoss(e);
	}
}
/**
* Applies an OnlineState change to the sync engine and notifies any views of
* the change.
*/ function __PRIVATE_syncEngineApplyOnlineStateChange(e, t, n) {
	const r = __PRIVATE_debugCast(e);
	if (r.isPrimaryClient && 0 === n || !r.isPrimaryClient && 1 === n) {
		const e = [];
		r.Tc.forEach(((n, r) => {
			const i = r.view.xu(t);
			i.snapshot && e.push(i.snapshot);
		})), function __PRIVATE_eventManagerOnOnlineStateChange(e, t) {
			const n = __PRIVATE_debugCast(e);
			n.onlineState = t;
			let r = false;
			n.queries.forEach(((e, n) => {
				for (const e of n.bu) e.xu(t) && (r = true);
			})), r && __PRIVATE_raiseSnapshotsInSyncEvent(n);
		}(r.eventManager, t), e.length && r.hc.Tn(e), r.onlineState = t, r.isPrimaryClient && r.sharedClientState.setOnlineState(t);
	}
}
/**
* Rejects the listen for the given targetID. This can be triggered by the
* backend for any active target.
*
* @param syncEngine - The sync engine implementation.
* @param targetId - The targetID corresponds to one previously initiated by the
* user as part of TargetData passed to listen() on RemoteStore.
* @param err - A description of the condition that has forced the rejection.
* Nearly always this will be an indication that the user is no longer
* authorized to see the data matching the target.
*/ async function __PRIVATE_syncEngineRejectListen(e, t, n) {
	const r = __PRIVATE_debugCast(e);
	r.sharedClientState.updateQueryState(t, "rejected", n);
	const i = r.Ac.get(t), s = i && i.key;
	if (s) {
		let e = new SortedMap(DocumentKey.comparator);
		e = e.insert(s, MutableDocument.newNoDocument(s, SnapshotVersion.min()));
		const n = __PRIVATE_documentKeySet().add(s);
		await __PRIVATE_syncEngineApplyRemoteEvent(r, new RemoteEvent(SnapshotVersion.min(), /* @__PURE__ */ new Map(), new SortedMap(__PRIVATE_primitiveComparator), e, __PRIVATE_mutableDocumentMap(), n)), r.Rc = r.Rc.remove(s), r.Ac.delete(t), __PRIVATE_pumpEnqueuedLimboResolutions(r);
	} else await __PRIVATE_localStoreReleaseTarget(r.localStore, t, false).then((() => __PRIVATE_removeAndCleanupTarget(r, t, n))).catch(__PRIVATE_ignoreIfPrimaryLeaseLoss);
}
async function __PRIVATE_syncEngineApplySuccessfulWrite(e, t) {
	const n = __PRIVATE_debugCast(e), r = t.batch.batchId;
	try {
		const e = await __PRIVATE_localStoreAcknowledgeBatch(n.localStore, t);
		__PRIVATE_processUserCallback(n, r, null), __PRIVATE_triggerPendingWritesCallbacks(n, r), n.sharedClientState.updateMutationState(r, "acknowledged"), await __PRIVATE_syncEngineEmitNewSnapsAndNotifyLocalStore(n, e);
	} catch (e) {
		await __PRIVATE_ignoreIfPrimaryLeaseLoss(e);
	}
}
async function __PRIVATE_syncEngineRejectFailedWrite(e, t, n) {
	const r = __PRIVATE_debugCast(e);
	try {
		const e = await function __PRIVATE_localStoreRejectBatch(e, t) {
			const n = __PRIVATE_debugCast(e);
			return n.persistence.runTransaction("Reject batch", "readwrite-primary", ((e) => {
				let r;
				return n.mutationQueue.lookupMutationBatch(e, t).next(((t) => (__PRIVATE_hardAssert(null !== t, 37113), r = t.keys(), n.mutationQueue.removeMutationBatch(e, t)))).next((() => n.mutationQueue.performConsistencyCheck(e))).next((() => n.documentOverlayCache.removeOverlaysForBatchId(e, r, t))).next((() => n.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(e, r))).next((() => n.localDocuments.getDocuments(e, r)));
			}));
		}(r.localStore, t);
		__PRIVATE_processUserCallback(r, t, n), __PRIVATE_triggerPendingWritesCallbacks(r, t), r.sharedClientState.updateMutationState(t, "rejected", n), await __PRIVATE_syncEngineEmitNewSnapsAndNotifyLocalStore(r, e);
	} catch (n) {
		await __PRIVATE_ignoreIfPrimaryLeaseLoss(n);
	}
}
/**
* Triggers the callbacks that are waiting for this batch id to get acknowledged by server,
* if there are any.
*/ function __PRIVATE_triggerPendingWritesCallbacks(e, t) {
	(e.fc.get(t) || []).forEach(((e) => {
		e.resolve();
	})), e.fc.delete(t);
}
/** Reject all outstanding callbacks waiting for pending writes to complete. */ function __PRIVATE_processUserCallback(e, t, n) {
	const r = __PRIVATE_debugCast(e);
	let i = r.dc[r.currentUser.toKey()];
	if (i) {
		const e = i.get(t);
		e && (n ? e.reject(n) : e.resolve(), i = i.remove(t)), r.dc[r.currentUser.toKey()] = i;
	}
}
function __PRIVATE_removeAndCleanupTarget(e, t, n = null) {
	e.sharedClientState.removeLocalQueryTarget(t);
	for (const r of e.Pc.get(t)) e.Tc.delete(r), n && e.hc.wc(r, n);
	if (e.Pc.delete(t), e.isPrimaryClient) e.Vc.e_(t).forEach(((t) => {
		e.Vc.containsKey(t) || __PRIVATE_removeLimboTarget(e, t);
	}));
}
function __PRIVATE_removeLimboTarget(e, t) {
	e.Ic.delete(t.path.canonicalString());
	const n = e.Rc.get(t);
	null !== n && (__PRIVATE_remoteStoreUnlisten(e.remoteStore, n), e.Rc = e.Rc.remove(t), e.Ac.delete(n), __PRIVATE_pumpEnqueuedLimboResolutions(e));
}
function __PRIVATE_updateTrackedLimbos(e, t, n) {
	for (const r of n) if (r instanceof __PRIVATE_AddedLimboDocument) e.Vc.addReference(r.key, t), __PRIVATE_trackLimboChange(e, r);
	else if (r instanceof __PRIVATE_RemovedLimboDocument) {
		__PRIVATE_logDebug(dr, "Document no longer in limbo: " + r.key), e.Vc.removeReference(r.key, t);
		e.Vc.containsKey(r.key) || __PRIVATE_removeLimboTarget(e, r.key);
	} else l(19791, { bc: r });
}
function __PRIVATE_trackLimboChange(e, t) {
	const n = t.key, r = n.path.canonicalString();
	e.Rc.get(n) || e.Ic.has(r) || (__PRIVATE_logDebug(dr, "New document in limbo: " + n), e.Ic.add(r), __PRIVATE_pumpEnqueuedLimboResolutions(e));
}
/**
* Starts listens for documents in limbo that are enqueued for resolution,
* subject to a maximum number of concurrent resolutions.
*
* Without bounding the number of concurrent resolutions, the server can fail
* with "resource exhausted" errors which can lead to pathological client
* behavior as seen in https://github.com/firebase/firebase-js-sdk/issues/2683.
*/ function __PRIVATE_pumpEnqueuedLimboResolutions(e) {
	for (; e.Ic.size > 0 && e.Rc.size < e.maxConcurrentLimboResolutions;) {
		const t = e.Ic.values().next().value;
		e.Ic.delete(t);
		const n = new DocumentKey(ResourcePath.fromString(t)), r = e.mc.next();
		e.Ac.set(r, new LimboResolution(n)), e.Rc = e.Rc.insert(n, r), __PRIVATE_remoteStoreListen(e.remoteStore, new TargetData(__PRIVATE_queryToTarget(__PRIVATE_newQueryForPath(n.path)), r, "TargetPurposeLimboResolution", __PRIVATE_ListenSequence.wn));
	}
}
async function __PRIVATE_syncEngineEmitNewSnapsAndNotifyLocalStore(e, t, n) {
	const r = __PRIVATE_debugCast(e), i = [], s = [], _ = [];
	r.Tc.isEmpty() || (r.Tc.forEach(((e, o) => {
		_.push(r.yc(o, t, n).then(((e) => {
			if ((e || n) && r.isPrimaryClient) {
				const t = e ? !e.fromCache : n?.targetChanges.get(o.targetId)?.current;
				r.sharedClientState.updateQueryState(o.targetId, t ? "current" : "not-current");
			}
			if (e) {
				i.push(e);
				const t = __PRIVATE_LocalViewChanges.mo(o.targetId, e);
				s.push(t);
			}
		})));
	})), await Promise.all(_), r.hc.Tn(i), await async function __PRIVATE_localStoreNotifyLocalViewChanges(e, t) {
		const n = __PRIVATE_debugCast(e);
		try {
			await n.persistence.runTransaction("notifyLocalViewChanges", "readwrite", ((e) => PersistencePromise.forEach(t, ((t) => PersistencePromise.forEach(t.Vo, ((r) => n.persistence.referenceDelegate.addReference(e, t.targetId, r))).next((() => PersistencePromise.forEach(t.fo, ((r) => n.persistence.referenceDelegate.removeReference(e, t.targetId, r)))))))));
		} catch (e) {
			if (!__PRIVATE_isIndexedDbTransactionError(e)) throw e;
			__PRIVATE_logDebug(lr, "Failed to update sequence numbers: " + e);
		}
		for (const e of t) {
			const t = e.targetId;
			if (!e.fromCache) {
				const e = n.Lo.get(t), r = e.snapshotVersion, i = e.withLastLimboFreeSnapshotVersion(r);
				n.Lo = n.Lo.insert(t, i);
			}
		}
	}(r.localStore, s));
}
async function __PRIVATE_syncEngineHandleCredentialChange(t, n) {
	const r = __PRIVATE_debugCast(t);
	if (!r.currentUser.isEqual(n)) {
		__PRIVATE_logDebug(dr, "User change. New user:", n.toKey());
		const t = await __PRIVATE_localStoreHandleUserChange(r.localStore, n);
		r.currentUser = n, function __PRIVATE_rejectOutstandingPendingWritesCallbacks(t, n) {
			t.fc.forEach(((t) => {
				t.forEach(((t) => {
					t.reject(new e(ta.CANCELLED, n));
				}));
			})), t.fc.clear();
		}(r, "'waitForPendingWrites' promise is rejected due to a user change."), r.sharedClientState.handleUserChange(n, t.removedBatchIds, t.addedBatchIds), await __PRIVATE_syncEngineEmitNewSnapsAndNotifyLocalStore(r, t.$o);
	}
}
function __PRIVATE_syncEngineGetRemoteKeysForTarget(e, t) {
	const n = __PRIVATE_debugCast(e), r = n.Ac.get(t);
	if (r && r.Ec) return __PRIVATE_documentKeySet().add(r.key);
	{
		let e = __PRIVATE_documentKeySet();
		const r = n.Pc.get(t);
		if (!r) return e;
		for (const t of r ?? []) {
			const r = n.Tc.get(t);
			e = e.unionWith(r.view.Zu);
		}
		return e;
	}
}
function __PRIVATE_ensureWatchCallbacks(e) {
	const t = __PRIVATE_debugCast(e);
	return t.remoteStore.remoteSyncer.applyRemoteEvent = __PRIVATE_syncEngineApplyRemoteEvent.bind(null, t), t.remoteStore.remoteSyncer.getRemoteKeysForTarget = __PRIVATE_syncEngineGetRemoteKeysForTarget.bind(null, t), t.remoteStore.remoteSyncer.rejectListen = __PRIVATE_syncEngineRejectListen.bind(null, t), t.hc.Tn = __PRIVATE_eventManagerOnWatchChange.bind(null, t.eventManager), t.hc.wc = __PRIVATE_eventManagerOnWatchError.bind(null, t.eventManager), t;
}
function __PRIVATE_syncEngineEnsureWriteCallbacks(e) {
	const t = __PRIVATE_debugCast(e);
	return t.remoteStore.remoteSyncer.applySuccessfulWrite = __PRIVATE_syncEngineApplySuccessfulWrite.bind(null, t), t.remoteStore.remoteSyncer.rejectFailedWrite = __PRIVATE_syncEngineRejectFailedWrite.bind(null, t), t;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var __PRIVATE_MemoryOfflineComponentProvider = class {
	constructor() {
		this.kind = "memory", this.synchronizeTabs = false;
	}
	async initialize(e) {
		this.serializer = __PRIVATE_newSerializer(e.databaseInfo.databaseId), this.sharedClientState = this.vc(e), this.persistence = this.Dc(e), await this.persistence.start(), this.localStore = this.xc(e), this.gcScheduler = this.Cc(e, this.localStore), this.indexBackfillerScheduler = this.Fc(e, this.localStore);
	}
	Cc(e, t) {
		return null;
	}
	Fc(e, t) {
		return null;
	}
	xc(e) {
		return __PRIVATE_newLocalStore(this.persistence, new __PRIVATE_QueryEngine(), e.initialUser, this.serializer);
	}
	Dc(e) {
		return new __PRIVATE_MemoryPersistence(__PRIVATE_MemoryEagerDelegate.b_, this.serializer);
	}
	vc(e) {
		return new __PRIVATE_MemorySharedClientState();
	}
	async terminate() {
		this.gcScheduler?.stop(), this.indexBackfillerScheduler?.stop(), this.sharedClientState.shutdown(), await this.persistence.shutdown();
	}
};
__PRIVATE_MemoryOfflineComponentProvider.provider = { build: () => new __PRIVATE_MemoryOfflineComponentProvider() };
var __PRIVATE_LruGcMemoryOfflineComponentProvider = class extends __PRIVATE_MemoryOfflineComponentProvider {
	constructor(e) {
		super(), this.cacheSizeBytes = e;
	}
	Cc(e, t) {
		__PRIVATE_hardAssert(this.persistence.referenceDelegate instanceof __PRIVATE_MemoryLruDelegate, 46915);
		const n = this.persistence.referenceDelegate.garbageCollector;
		return new __PRIVATE_LruScheduler(n, e.asyncQueue, t);
	}
	Dc(e) {
		const t = void 0 !== this.cacheSizeBytes ? LruParams.withCacheSize(this.cacheSizeBytes) : LruParams.DEFAULT;
		return new __PRIVATE_MemoryPersistence(((e) => __PRIVATE_MemoryLruDelegate.b_(e, t)), this.serializer);
	}
};
/**
* Initializes and wires the components that are needed to interface with the
* network.
*/ var OnlineComponentProvider = class {
	async initialize(e, t) {
		this.localStore || (this.localStore = e.localStore, this.sharedClientState = e.sharedClientState, this.datastore = this.createDatastore(t), this.remoteStore = this.createRemoteStore(t), this.eventManager = this.createEventManager(t), this.syncEngine = this.createSyncEngine(t, !e.synchronizeTabs), this.sharedClientState.onlineStateHandler = (e) => __PRIVATE_syncEngineApplyOnlineStateChange(this.syncEngine, e, 1), this.remoteStore.remoteSyncer.handleCredentialChange = __PRIVATE_syncEngineHandleCredentialChange.bind(null, this.syncEngine), await __PRIVATE_remoteStoreApplyPrimaryState(this.remoteStore, this.syncEngine.isPrimaryClient));
	}
	createEventManager(e) {
		return function __PRIVATE_newEventManager() {
			return new __PRIVATE_EventManagerImpl();
		}();
	}
	createDatastore(e) {
		const t = __PRIVATE_newSerializer(e.databaseInfo.databaseId), n = __PRIVATE_newConnection(e.databaseInfo);
		return __PRIVATE_newDatastore(e.authCredentials, e.appCheckCredentials, n, t);
	}
	createRemoteStore(e) {
		return function __PRIVATE_newRemoteStore(e, t, n, r, i) {
			return new __PRIVATE_RemoteStoreImpl(e, t, n, r, i);
		}(this.localStore, this.datastore, e.asyncQueue, ((e) => __PRIVATE_syncEngineApplyOnlineStateChange(this.syncEngine, e, 0)), function __PRIVATE_newConnectivityMonitor() {
			return __PRIVATE_BrowserConnectivityMonitor.Ye() ? new __PRIVATE_BrowserConnectivityMonitor() : new __PRIVATE_NoopConnectivityMonitor();
		}());
		/**
		* @license
		* Copyright 2017 Google LLC
		*
		* Licensed under the Apache License, Version 2.0 (the "License");
		* you may not use this file except in compliance with the License.
		* You may obtain a copy of the License at
		*
		*   http://www.apache.org/licenses/LICENSE-2.0
		*
		* Unless required by applicable law or agreed to in writing, software
		* distributed under the License is distributed on an "AS IS" BASIS,
		* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
		* See the License for the specific language governing permissions and
		* limitations under the License.
		*/
	}
	createSyncEngine(e, t) {
		return function __PRIVATE_newSyncEngine(e, t, n, r, i, s, _) {
			const o = new __PRIVATE_SyncEngineImpl(e, t, n, r, i, s);
			return _ && (o.gc = true), o;
		}(this.localStore, this.remoteStore, this.eventManager, this.sharedClientState, e.initialUser, e.maxConcurrentLimboResolutions, t);
	}
	async terminate() {
		await async function __PRIVATE_remoteStoreShutdown(e) {
			const t = __PRIVATE_debugCast(e);
			__PRIVATE_logDebug(hr, "RemoteStore shutting down."), t.la.add(5), await __PRIVATE_disableNetworkInternal(t), t.ha.shutdown(), t.Ta.set("Unknown");
		}(this.remoteStore), this.datastore?.terminate(), this.eventManager?.terminate();
	}
};
OnlineComponentProvider.provider = { build: () => new OnlineComponentProvider() };
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2019 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var fr = "FirestoreClient";
/**
* FirestoreClient is a top-level class that constructs and owns all of the //
* pieces of the client SDK architecture. It is responsible for creating the //
* async queue that is shared by all of the other components in the system. //
*/
var FirestoreClient = class {
	constructor(e, t, n, r, i) {
		this.authCredentials = e, this.appCheckCredentials = t, this.asyncQueue = n, this._databaseInfo = r, this.user = User.UNAUTHENTICATED, this.clientId = __PRIVATE_AutoId.newId(), this.authCredentialListener = () => Promise.resolve(), this.appCheckCredentialListener = () => Promise.resolve(), this._uninitializedComponentsProvider = i, this.authCredentials.start(n, (async (e) => {
			__PRIVATE_logDebug(fr, "Received user=", e.uid), await this.authCredentialListener(e), this.user = e;
		})), this.appCheckCredentials.start(n, ((e) => (__PRIVATE_logDebug(fr, "Received new app check token=", e), this.appCheckCredentialListener(e, this.user))));
	}
	get configuration() {
		return {
			asyncQueue: this.asyncQueue,
			databaseInfo: this._databaseInfo,
			clientId: this.clientId,
			authCredentials: this.authCredentials,
			appCheckCredentials: this.appCheckCredentials,
			initialUser: this.user,
			maxConcurrentLimboResolutions: 100
		};
	}
	setCredentialChangeListener(e) {
		this.authCredentialListener = e;
	}
	setAppCheckTokenChangeListener(e) {
		this.appCheckCredentialListener = e;
	}
	terminate() {
		this.asyncQueue.enterRestrictedMode();
		const e = new __PRIVATE_Deferred();
		return this.asyncQueue.enqueueAndForgetEvenWhileRestricted((async () => {
			try {
				this._onlineComponents && await this._onlineComponents.terminate(), this._offlineComponents && await this._offlineComponents.terminate(), this.authCredentials.shutdown(), this.appCheckCredentials.shutdown(), e.resolve();
			} catch (t) {
				const n = __PRIVATE_wrapInUserErrorIfRecoverable(t, "Failed to shutdown persistence");
				e.reject(n);
			}
		})), e.promise;
	}
};
async function __PRIVATE_setOfflineComponentProvider(e, t) {
	e.asyncQueue.verifyOperationInProgress(), __PRIVATE_logDebug(fr, "Initializing OfflineComponentProvider");
	const n = e.configuration;
	await t.initialize(n);
	let r = n.initialUser;
	e.setCredentialChangeListener((async (e) => {
		r.isEqual(e) || (await __PRIVATE_localStoreHandleUserChange(t.localStore, e), r = e);
	})), t.persistence.setDatabaseDeletedListener((() => e.terminate())), e._offlineComponents = t;
}
async function __PRIVATE_setOnlineComponentProvider(e, t) {
	e.asyncQueue.verifyOperationInProgress();
	const n = await __PRIVATE_ensureOfflineComponents(e);
	__PRIVATE_logDebug(fr, "Initializing OnlineComponentProvider"), await t.initialize(n, e.configuration), e.setCredentialChangeListener(((e) => __PRIVATE_remoteStoreHandleCredentialChange(t.remoteStore, e))), e.setAppCheckTokenChangeListener(((e, n) => __PRIVATE_remoteStoreHandleCredentialChange(t.remoteStore, n))), e._onlineComponents = t;
}
/**
* Decides whether the provided error allows us to gracefully disable
* persistence (as opposed to crashing the client).
*/ async function __PRIVATE_ensureOfflineComponents(e) {
	if (!e._offlineComponents) if (e._uninitializedComponentsProvider) {
		__PRIVATE_logDebug(fr, "Using user provided OfflineComponentProvider");
		try {
			await __PRIVATE_setOfflineComponentProvider(e, e._uninitializedComponentsProvider._offline);
		} catch (t) {
			const n = t;
			if (!function __PRIVATE_canFallbackFromIndexedDbError(e) {
				return "FirebaseError" === e.name ? e.code === ta.FAILED_PRECONDITION || e.code === ta.UNIMPLEMENTED : !("undefined" != typeof DOMException && e instanceof DOMException) || 22 === e.code || 20 === e.code || 11 === e.code;
			}(n)) throw n;
			__PRIVATE_logWarn("Error using user provided cache. Falling back to memory cache: " + n), await __PRIVATE_setOfflineComponentProvider(e, new __PRIVATE_MemoryOfflineComponentProvider());
		}
	} else __PRIVATE_logDebug(fr, "Using default OfflineComponentProvider"), await __PRIVATE_setOfflineComponentProvider(e, new __PRIVATE_LruGcMemoryOfflineComponentProvider(void 0));
	return e._offlineComponents;
}
async function __PRIVATE_ensureOnlineComponents(e) {
	return e._onlineComponents || (e._uninitializedComponentsProvider ? (__PRIVATE_logDebug(fr, "Using user provided OnlineComponentProvider"), await __PRIVATE_setOnlineComponentProvider(e, e._uninitializedComponentsProvider._online)) : (__PRIVATE_logDebug(fr, "Using default OnlineComponentProvider"), await __PRIVATE_setOnlineComponentProvider(e, new OnlineComponentProvider()))), e._onlineComponents;
}
function __PRIVATE_getSyncEngine(e) {
	return __PRIVATE_ensureOnlineComponents(e).then(((e) => e.syncEngine));
}
async function __PRIVATE_getEventManager(e) {
	const t = await __PRIVATE_ensureOnlineComponents(e), n = t.eventManager;
	return n.onListen = __PRIVATE_syncEngineListen.bind(null, t.syncEngine), n.onUnlisten = __PRIVATE_syncEngineUnlisten.bind(null, t.syncEngine), n.onFirstRemoteStoreListen = __PRIVATE_triggerRemoteStoreListen.bind(null, t.syncEngine), n.onLastRemoteStoreUnlisten = __PRIVATE_triggerRemoteStoreUnlisten.bind(null, t.syncEngine), n;
}
function __PRIVATE_firestoreClientGetDocumentsViaSnapshotListener(t, n, r = {}) {
	const i = new __PRIVATE_Deferred();
	return t.asyncQueue.enqueueAndForget((async () => function __PRIVATE_executeQueryViaSnapshotListener(t, n, r, i, s) {
		const _ = new __PRIVATE_AsyncObserver({
			next: (r) => {
				_.Va(), n.enqueueAndForget((() => __PRIVATE_eventManagerUnlisten(t, o))), r.fromCache && "server" === i.source ? s.reject(new e(ta.UNAVAILABLE, "Failed to get documents from server. (However, these documents may exist in the local cache. Run again without setting source to \"server\" to retrieve the cached documents.)")) : s.resolve(r);
			},
			error: (e) => s.reject(e)
		}), o = new __PRIVATE_QueryListener(r instanceof __PRIVATE_RealtimePipeline ? __PRIVATE_toCorePipeline(r) : r, _, {
			includeMetadataChanges: true,
			waitForSyncWhenOnline: true
		});
		return __PRIVATE_eventManagerListen(t, o);
	}(await __PRIVATE_getEventManager(t), t.asyncQueue, n, r, i))), i.promise;
}
function __PRIVATE_firestoreClientWrite(e, t) {
	const n = new __PRIVATE_Deferred();
	return e.asyncQueue.enqueueAndForget((async () => __PRIVATE_syncEngineWrite(await __PRIVATE_getSyncEngine(e), t, n))), n.promise;
}
/**
* @license
* Copyright 2018 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* A `DocumentSnapshot` contains data read from a document in your Firestore
* database. The data can be extracted with `.data()` or `.get(<field>)` to
* get a specific field.
*
* For a `DocumentSnapshot` that points to a non-existing document, any data
* access will return 'undefined'. You can use the `exists()` method to
* explicitly verify a document's existence.
*/ var mr = class DocumentSnapshot {
	/** @hideconstructor protected */
	constructor(e, t, n, r, i) {
		this._firestore = e, this._userDataWriter = t, this._key = n, this._document = r, this._converter = i;
	}
	/** Property of the `DocumentSnapshot` that provides the document's ID. */ get id() {
		return this._key.path.lastSegment();
	}
	/**
	* The `DocumentReference` for the document included in the `DocumentSnapshot`.
	*/ get ref() {
		return new aa(this._firestore, this._converter, this._key);
	}
	/**
	* Signals whether or not the document at the snapshot's location exists.
	*
	* @returns true if the document exists.
	*/ exists() {
		return null !== this._document;
	}
	/**
	* Retrieves all fields in the document as an `Object`. Returns `undefined` if
	* the document doesn't exist.
	*
	* @returns An `Object` containing all fields in the document or `undefined`
	* if the document doesn't exist.
	*/ data() {
		if (this._document) {
			if (this._converter) {
				const e = new pr(this._firestore, this._userDataWriter, this._key, this._document, null);
				return this._converter.fromFirestore(e);
			}
			return this._userDataWriter.convertValue(this._document.data.value);
		}
	}
	/**
	* @internal
	* @private
	*
	* Retrieves all fields in the document as a proto Value. Returns `undefined` if
	* the document doesn't exist.
	*
	* @returns An `Object` containing all fields in the document or `undefined`
	* if the document doesn't exist.
	*/ _fieldsProto() {
		return this._document?.data.clone().value.mapValue.fields ?? void 0;
	}
	/**
	* Retrieves the field specified by `fieldPath`. Returns `undefined` if the
	* document or field doesn't exist.
	*
	* @param fieldPath - The path (for example 'foo' or 'foo.bar') to a specific
	* field.
	* @returns The data at the specified field location or undefined if no such
	* field exists in the document.
	*/
	get(e) {
		if (this._document) {
			const t = this._document.data.field(K("DocumentSnapshot.get", e));
			if (null !== t) return this._userDataWriter.convertValue(t);
		}
	}
};
var pr = class QueryDocumentSnapshot extends mr {
	/**
	* Retrieves all fields in the document as an `Object`.
	*
	* @override
	* @returns An `Object` containing all fields in the document.
	*/
	data() {
		return super.data();
	}
};
/**
* A `QueryDocumentSnapshot` contains data read from a document in your
* Firestore database as part of a query. The document is guaranteed to exist
* and its data can be extracted with `.data()` or `.get(<field>)` to get a
* specific field.
*
* A `QueryDocumentSnapshot` offers the same API surface as a
* `DocumentSnapshot`. Since query results contain only existing documents, the
* `exists` property will always be true and `data()` will never return
* 'undefined'.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Converts Firestore's internal types to the JavaScript types that we expose
* to the user.
*
* @internal
*/
var AbstractUserDataWriter = class {
	convertValue(e, t = "none") {
		switch (__PRIVATE_typeOrder(e)) {
			case 0: return null;
			case 1: return e.booleanValue;
			case 2: return __PRIVATE_normalizeNumber(e.integerValue || e.doubleValue);
			case 3: return this.convertTimestamp(e.timestampValue);
			case 4: return this.convertServerTimestamp(e, t);
			case 5: return e.stringValue;
			case 6: return this.convertBytes(__PRIVATE_normalizeByteString(e.bytesValue));
			case 7: return this.convertReference(e.referenceValue);
			case 8: return this.convertGeoPoint(e.geoPointValue);
			case 9: return this.convertArray(e.arrayValue, t);
			case 11: return this.convertObject(e.mapValue, t);
			case 10: return this.convertVectorValue(e.mapValue);
			default: throw l(62114, { value: e });
		}
	}
	convertObject(e, t) {
		return this.convertObjectMap(e.fields, t);
	}
	/**
	* @internal
	*/ convertObjectMap(e, t = "none") {
		const n = {};
		return forEach(e, ((e, r) => {
			n[e] = this.convertValue(r, t);
		})), n;
	}
	/**
	* @internal
	*/ convertVectorValue(e) {
		const t = e.fields?.[je].arrayValue?.values?.map(((e) => __PRIVATE_normalizeNumber(e.doubleValue)));
		return new n(t);
	}
	convertGeoPoint(e) {
		return new GeoPoint(__PRIVATE_normalizeNumber(e.latitude), __PRIVATE_normalizeNumber(e.longitude));
	}
	convertArray(e, t) {
		return (e.values || []).map(((e) => this.convertValue(e, t)));
	}
	convertServerTimestamp(e, t) {
		switch (t) {
			case "previous":
				const n = __PRIVATE_getPreviousValue(e);
				return null == n ? null : this.convertValue(n, t);
			case "estimate": return this.convertTimestamp(__PRIVATE_getLocalWriteTime(e));
			default: return null;
		}
	}
	convertTimestamp(e) {
		const t = __PRIVATE_normalizeTimestamp(e);
		return new Timestamp(t.seconds, t.nanos);
	}
	convertDocumentKey(e, t) {
		const n = ResourcePath.fromString(e);
		__PRIVATE_hardAssert(__PRIVATE_isValidResourceName(n), 9688, { name: e });
		const r = new DatabaseId(n.get(1), n.get(3)), i = new DocumentKey(n.popFirst(5));
		return r.isEqual(t) || __PRIVATE_logError(`A document reference to ${i} refers to a different database (${r.projectId}/${r.database}), which is not supported. It will be treated as a reference in the current database (${t.projectId}/${t.database}) instead.`), i;
	}
};
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Converts custom model object of type T into `DocumentData` by applying the
* converter if it exists.
*
* This function is used when converting user objects to `DocumentData`
* because we want to provide the user with a more specific error message if
* their `set()` or fails due to invalid data originating from a `toFirestore()`
* call.
*/ function __PRIVATE_applyFirestoreDataConverter(e, t, n) {
	let r;
	return r = e ? n && (n.merge || n.mergeFields) ? e.toFirestore(t, n) : e.toFirestore(t) : t, r;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var gr = "AsyncQueue";
var __PRIVATE_AsyncQueueImpl = class {
	constructor(e = Promise.resolve()) {
		this.$c = [], this.Kc = false, this.Qc = [], this.Wc = null, this.Gc = false, this.zc = false, this.jc = [], this.Ht = new __PRIVATE_ExponentialBackoff(this, "async_queue_retry"), this.Hc = () => {
			const e = getDocument();
			e && __PRIVATE_logDebug(gr, "Visibility state changed to " + e.visibilityState), this.Ht.$t();
		}, this.Jc = e;
		const t = getDocument();
		t && "function" == typeof t.addEventListener && t.addEventListener("visibilitychange", this.Hc);
	}
	get isShuttingDown() {
		return this.Kc;
	}
	/**
	* Adds a new operation to the queue without waiting for it to complete (i.e.
	* we ignore the Promise result).
	*/ enqueueAndForget(e) {
		this.enqueue(e);
	}
	enqueueAndForgetEvenWhileRestricted(e) {
		this.Yc(), this.Zc(e);
	}
	enterRestrictedMode(e) {
		if (!this.Kc) {
			this.Kc = true, this.zc = e || false;
			const t = getDocument();
			t && "function" == typeof t.removeEventListener && t.removeEventListener("visibilitychange", this.Hc);
		}
	}
	enqueue(e) {
		if (this.Yc(), this.Kc) return new Promise((() => {}));
		const t = new __PRIVATE_Deferred();
		return this.Zc((() => this.Kc && this.zc ? Promise.resolve() : (e().then(t.resolve, t.reject), t.promise))).then((() => t.promise));
	}
	enqueueRetryable(e) {
		this.enqueueAndForget((() => (this.$c.push(e), this.Xc())));
	}
	/**
	* Runs the next operation from the retryable queue. If the operation fails,
	* reschedules with backoff.
	*/ async Xc() {
		if (0 !== this.$c.length) {
			try {
				await this.$c[0](), this.$c.shift(), this.Ht.reset();
			} catch (e) {
				if (!__PRIVATE_isIndexedDbTransactionError(e)) throw e;
				__PRIVATE_logDebug(gr, "Operation failed with retryable error: " + e);
			}
			this.$c.length > 0 && this.Ht.kt((() => this.Xc()));
		}
	}
	Zc(e) {
		const t = this.Jc.then((() => (this.Gc = true, e().catch(((e) => {
			this.Wc = e, this.Gc = false;
			throw __PRIVATE_logError("INTERNAL UNHANDLED ERROR: ", __PRIVATE_getMessageOrStack(e)), e;
		})).then(((e) => (this.Gc = false, e))))));
		return this.Jc = t, t;
	}
	enqueueAfterDelay(e, t, n) {
		this.Yc(), this.jc.indexOf(e) > -1 && (t = 0);
		const r = DelayedOperation.createAndSchedule(this, e, t, n, ((e) => this.el(e)));
		return this.Qc.push(r), r;
	}
	Yc() {
		this.Wc && l(47125, { tl: __PRIVATE_getMessageOrStack(this.Wc) });
	}
	verifyOperationInProgress() {}
	/**
	* Waits until all currently queued tasks are finished executing. Delayed
	* operations are not run.
	*/ async nl() {
		let e;
		do
			e = this.Jc, await e;
		while (e !== this.Jc);
	}
	/**
	* For Tests: Determine if a delayed operation with a particular TimerId
	* exists.
	*/ rl(e) {
		for (const t of this.Qc) if (t.timerId === e) return true;
		return false;
	}
	/**
	* For Tests: Runs some or all delayed operations early.
	*
	* @param lastTimerId - Delayed operations up to and including this TimerId
	* will be drained. Pass TimerId.All to run all delayed operations.
	* @returns a Promise that resolves once all operations have been run.
	*/ il(e) {
		return this.nl().then((() => {
			this.Qc.sort(((e, t) => e.targetTimeMs - t.targetTimeMs));
			for (const t of this.Qc) if (t.skipDelay(), "all" !== e && t.timerId === e) break;
			return this.nl();
		}));
	}
	/**
	* For Tests: Skip all subsequent delays for a timer id.
	*/ sl(e) {
		this.jc.push(e);
	}
	/** Called once a DelayedOperation is run or canceled. */ el(e) {
		const t = this.Qc.indexOf(e);
		this.Qc.splice(t, 1);
	}
};
/**
* Chrome includes Error.message in Error.stack. Other browsers do not.
* This returns expected output of message + stack when available.
* @param error - Error or FirestoreError
*/ function __PRIVATE_getMessageOrStack(e) {
	let t = e.message || "";
	return e.stack && (t = e.stack.includes(e.message) ? e.stack : e.message + "\n" + e.stack), t;
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* The Cloud Firestore service interface.
*
* Do not call this constructor directly. Instead, use {@link (getFirestore:1)}.
*/ var da = class extends Dt {
	/** @hideconstructor */
	constructor(e, t, n, r) {
		super(e, t, n, r), this.type = "firestore", this._queue = new __PRIVATE_AsyncQueueImpl(), this._persistenceKey = r?.name || "[DEFAULT]";
	}
	async _terminate() {
		if (this._firestoreClient) {
			const e = this._firestoreClient.terminate();
			this._queue = new __PRIVATE_AsyncQueueImpl(e), this._firestoreClient = void 0, await e;
		}
	}
};
function getFirestore(e, t) {
	const n = "object" == typeof e ? e : getApp(), r = "string" == typeof e ? e : t || $e, i = _getProvider(n, "firestore").getImmediate({ identifier: r });
	if (!i._initialized) {
		const e = getDefaultEmulatorHostnameAndPort("firestore");
		e && connectFirestoreEmulator(i, ...e);
	}
	return i;
}
/**
* @internal
*/ function oa(t) {
	if (t._terminated) throw new e(ta.FAILED_PRECONDITION, "The client has already been terminated.");
	return t._firestoreClient || __PRIVATE_configureFirestore(t), t._firestoreClient;
}
function __PRIVATE_configureFirestore(e) {
	const t = e._freezeSettings(), n = __PRIVATE_makeDatabaseInfo(e._databaseId, e._app?.options.appId || "", e._persistenceKey, e._app?.options.apiKey, t);
	e._componentsProvider || t.localCache?._offlineComponentProvider && t.localCache?._onlineComponentProvider && (e._componentsProvider = {
		_offline: t.localCache._offlineComponentProvider,
		_online: t.localCache._onlineComponentProvider
	}), e._firestoreClient = new FirestoreClient(e._authCredentials, e._appCheckCredentials, e._queue, n, e._componentsProvider && function __PRIVATE_buildComponentProvider(e) {
		const t = e?._online.build();
		return {
			_offline: e?._offline.build(t),
			_online: t
		};
	}(e._componentsProvider));
}
/**
* @license
* Copyright 2024 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ var ua = class extends AbstractUserDataWriter {
	constructor(e) {
		super(), this.firestore = e;
	}
	convertBytes(e) {
		return new Bytes(e);
	}
	convertReference(e) {
		const t = this.convertDocumentKey(e, this.firestore._databaseId);
		return new aa(this.firestore, null, t);
	}
};
/**
* @license
* Copyright 2025 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Metadata about a snapshot, describing the state of the snapshot.
*/ var SnapshotMetadata = class {
	/** @hideconstructor */
	constructor(e, t) {
		this.hasPendingWrites = e, this.fromCache = t;
	}
	/**
	* Returns true if this `SnapshotMetadata` is equal to the provided one.
	*
	* @param other - The `SnapshotMetadata` to compare against.
	* @returns true if this `SnapshotMetadata` is equal to the provided one.
	*/ isEqual(e) {
		return this.hasPendingWrites === e.hasPendingWrites && this.fromCache === e.fromCache;
	}
};
/**
* A `DocumentSnapshot` contains data read from a document in your Firestore
* database. The data can be extracted with `.data()` or `.get(<field>)` to
* get a specific field.
*
* For a `DocumentSnapshot` that points to a non-existing document, any data
* access will return 'undefined'. You can use the `exists()` method to
* explicitly verify a document's existence.
*/ var DocumentSnapshot = class DocumentSnapshot extends mr {
	/** @hideconstructor protected */
	constructor(e, t, n, r, i, s) {
		super(e, t, n, r, s), this._firestore = e, this._firestoreImpl = e, this.metadata = i;
	}
	/**
	* Returns whether or not the data exists. True if the document exists.
	*/ exists() {
		return super.exists();
	}
	/**
	* Retrieves all fields in the document as an `Object`. Returns `undefined` if
	* the document doesn't exist.
	*
	* By default, `serverTimestamp()` values that have not yet been
	* set to their final value will be returned as `null`. You can override
	* this by passing an options object.
	*
	* @param options - An options object to configure how data is retrieved from
	* the snapshot (for example the desired behavior for server timestamps that
	* have not yet been set to their final value).
	* @returns An `Object` containing all fields in the document or `undefined` if
	* the document doesn't exist.
	*/ data(e = {}) {
		if (this._document) {
			if (this._converter) {
				const t = new QueryDocumentSnapshot(this._firestore, this._userDataWriter, this._key, this._document, this.metadata, null);
				return this._converter.fromFirestore(t, e);
			}
			return this._userDataWriter.convertValue(this._document.data.value, e.serverTimestamps);
		}
	}
	/**
	* Retrieves the field specified by `fieldPath`. Returns `undefined` if the
	* document or field doesn't exist.
	*
	* By default, a `serverTimestamp()` that has not yet been set to
	* its final value will be returned as `null`. You can override this by
	* passing an options object.
	*
	* @param fieldPath - The path (for example 'foo' or 'foo.bar') to a specific
	* field.
	* @param options - An options object to configure how the field is retrieved
	* from the snapshot (for example the desired behavior for server timestamps
	* that have not yet been set to their final value).
	* @returns The data at the specified field location or undefined if no such
	* field exists in the document.
	*/
	get(e, t = {}) {
		if (this._document) {
			const n = this._document.data.field(K("DocumentSnapshot.get", e));
			if (null !== n) return this._userDataWriter.convertValue(n, t.serverTimestamps);
		}
	}
	/**
	* Returns a JSON-serializable representation of this `DocumentSnapshot` instance.
	*
	* @returns a JSON representation of this object.  Throws a {@link FirestoreError} if this
	* `DocumentSnapshot` has pending writes.
	*/ toJSON() {
		if (this.metadata.hasPendingWrites) throw new e(ta.FAILED_PRECONDITION, "DocumentSnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");
		const t = this._document, n = {};
		if (n.type = DocumentSnapshot._jsonSchemaVersion, n.bundle = "", n.bundleSource = "DocumentSnapshot", n.bundleName = this._key.toString(), !t || !t.isValidDocument() || !t.isFoundDocument()) return n;
		this._userDataWriter.convertObjectMap(t.data.value.mapValue.fields, "previous");
		return n.bundle = (this._firestore, this.ref.path, "NOT SUPPORTED"), n;
	}
};
/**
* A `QueryDocumentSnapshot` contains data read from a document in your
* Firestore database as part of a query. The document is guaranteed to exist
* and its data can be extracted with `.data()` or `.get(<field>)` to get a
* specific field.
*
* A `QueryDocumentSnapshot` offers the same API surface as a
* `DocumentSnapshot`. Since query results contain only existing documents, the
* `exists` property will always be true and `data()` will never return
* 'undefined'.
*/ DocumentSnapshot._jsonSchemaVersion = "firestore/documentSnapshot/1.0", DocumentSnapshot._jsonSchema = {
	type: property("string", DocumentSnapshot._jsonSchemaVersion),
	bundleSource: property("string", "DocumentSnapshot"),
	bundleName: property("string"),
	bundle: property("string")
};
var QueryDocumentSnapshot = class extends DocumentSnapshot {
	/**
	* Retrieves all fields in the document as an `Object`.
	*
	* By default, `serverTimestamp()` values that have not yet been
	* set to their final value will be returned as `null`. You can override
	* this by passing an options object.
	*
	* @override
	* @param options - An options object to configure how data is retrieved from
	* the snapshot (for example the desired behavior for server timestamps that
	* have not yet been set to their final value).
	* @returns An `Object` containing all fields in the document.
	*/
	data(e = {}) {
		return super.data(e);
	}
};
/**
* A `QuerySnapshot` contains zero or more `DocumentSnapshot` objects
* representing the results of a query. The documents can be accessed as an
* array via the `docs` property or enumerated using the `forEach` method. The
* number of documents can be determined via the `empty` and `size`
* properties.
*/ var QuerySnapshot = class QuerySnapshot {
	/** @hideconstructor */
	constructor(e, t, n, r) {
		this._firestore = e, this._userDataWriter = t, this._snapshot = r, this.metadata = new SnapshotMetadata(r.hasPendingWrites, r.fromCache), this.query = n;
	}
	/** An array of all the documents in the `QuerySnapshot`. */ get docs() {
		const e = [];
		return this.forEach(((t) => e.push(t))), e;
	}
	/** The number of documents in the `QuerySnapshot`. */ get size() {
		return this._snapshot.docs.size;
	}
	/** True if there are no documents in the `QuerySnapshot`. */ get empty() {
		return 0 === this.size;
	}
	/**
	* Enumerates all of the documents in the `QuerySnapshot`.
	*
	* @param callback - A callback to be called with a `QueryDocumentSnapshot` for
	* each document in the snapshot.
	* @param thisArg - The `this` binding for the callback.
	*/ forEach(e, t) {
		this._snapshot.docs.forEach(((n) => {
			e.call(t, new QueryDocumentSnapshot(this._firestore, this._userDataWriter, n.key, n, new SnapshotMetadata(this._snapshot.mutatedKeys.has(n.key), this._snapshot.fromCache), this.query.converter));
		}));
	}
	/**
	* Returns an array of the documents changes since the last snapshot. If this
	* is the first snapshot, all documents will be in the list as 'added'
	* changes.
	*
	* @param options - `SnapshotListenOptions` that control whether metadata-only
	* changes (i.e. only `DocumentSnapshot.metadata` changed) should trigger
	* snapshot events.
	*/ docChanges(t = {}) {
		const n = !!t.includeMetadataChanges;
		if (n && this._snapshot.excludesMetadataChanges) throw new e(ta.INVALID_ARGUMENT, "To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");
		return this._cachedChanges && this._cachedChangesIncludeMetadataChanges === n || (this._cachedChanges = function __PRIVATE_changesFromSnapshot(e, t) {
			if (e._snapshot.oldDocs.isEmpty()) {
				let t = 0;
				return e._snapshot.docChanges.map(((n) => {
					__PRIVATE_isPipeline(e._snapshot.query) ? __PRIVATE_newPipelineComparator(e._snapshot.query) : e.query._query;
					const r = new QueryDocumentSnapshot(e._firestore, e._userDataWriter, n.doc.key, n.doc, new SnapshotMetadata(e._snapshot.mutatedKeys.has(n.doc.key), e._snapshot.fromCache), e.query.converter);
					return n.doc, {
						type: "added",
						doc: r,
						oldIndex: -1,
						newIndex: t++
					};
				}));
			}
			{
				let n = e._snapshot.oldDocs;
				return e._snapshot.docChanges.filter(((e) => t || 3 !== e.type)).map(((t) => {
					const r = new QueryDocumentSnapshot(e._firestore, e._userDataWriter, t.doc.key, t.doc, new SnapshotMetadata(e._snapshot.mutatedKeys.has(t.doc.key), e._snapshot.fromCache), e.query.converter);
					let i = -1, s = -1;
					return 0 !== t.type && (i = n.indexOf(t.doc.key), n = n.delete(t.doc.key)), 1 !== t.type && (n = n.add(t.doc), s = n.indexOf(t.doc.key)), {
						type: __PRIVATE_resultChangeType(t.type),
						doc: r,
						oldIndex: i,
						newIndex: s
					};
				}));
			}
		}(this, n), this._cachedChangesIncludeMetadataChanges = n), this._cachedChanges;
	}
	/**
	* Returns a JSON-serializable representation of this `QuerySnapshot` instance.
	*
	* @returns a JSON representation of this object. Throws a {@link FirestoreError} if this
	* `QuerySnapshot` has pending writes.
	*/ toJSON() {
		if (this.metadata.hasPendingWrites) throw new e(ta.FAILED_PRECONDITION, "QuerySnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");
		const t = {};
		t.type = QuerySnapshot._jsonSchemaVersion, t.bundleSource = "QuerySnapshot", t.bundleName = __PRIVATE_AutoId.newId(), this._firestore._databaseId.database, this._firestore._databaseId.projectId;
		const n = [], r = [], i = [];
		return this.docs.forEach(((e) => {
			null !== e._document && (n.push(e._document), r.push(this._userDataWriter.convertObjectMap(e._document.data.value.mapValue.fields, "previous")), i.push(e.ref.path));
		})), t.bundle = (this._firestore, this.query._query, t.bundleName, "NOT SUPPORTED"), t;
	}
};
function __PRIVATE_resultChangeType(e) {
	switch (e) {
		case 0: return "added";
		case 2:
		case 3: return "modified";
		case 1: return "removed";
		default: return l(61501, { type: e });
	}
}
/**
* @license
* Copyright 2025 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ QuerySnapshot._jsonSchemaVersion = "firestore/querySnapshot/1.0", QuerySnapshot._jsonSchema = {
	type: property("string", QuerySnapshot._jsonSchemaVersion),
	bundleSource: property("string", "QuerySnapshot"),
	bundleName: property("string"),
	bundle: property("string")
};
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
//#endregion
//#region node_modules/@firebase/firestore/dist/index.esm.js
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/ function __PRIVATE_validateHasExplicitOrderByForLimitToLast(e$1) {
	if ("L" === e$1.limitType && 0 === e$1.explicitOrderBy.length) throw new e(ta.UNIMPLEMENTED, "limitToLast() queries require specifying at least one orderBy() clause");
}
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2017 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2023 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2022 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
function getDocs(e) {
	e = ra(e, Query);
	const t = ra(e.firestore, da), n = oa(t), r = new ua(t);
	return __PRIVATE_validateHasExplicitOrderByForLimitToLast(e._query), __PRIVATE_firestoreClientGetDocumentsViaSnapshotListener(n, e._query).then(((n) => new QuerySnapshot(t, r, e, n)));
}
function setDoc(e, t, n) {
	e = ra(e, aa);
	const r = ra(e.firestore, da), s = __PRIVATE_applyFirestoreDataConverter(e.converter, t, n);
	return executeWrite(r, [__PRIVATE_parseSetData(la(r), "setDoc", e._key, s, null !== e.converter, n).toMutation(e._key, Precondition.none())]);
}
function updateDoc(e, t, n, ...r) {
	e = ra(e, aa);
	const s = ra(e.firestore, da), a = la(s);
	let o;
	o = "string" == typeof (t = getModularInstance(t)) || t instanceof FieldPath ? __PRIVATE_parseUpdateVarargs(a, "updateDoc", e._key, t, n, r) : __PRIVATE_parseUpdateData(a, "updateDoc", e._key, t);
	return executeWrite(s, [o.toMutation(e._key, Precondition.exists(true))]);
}
/**
* Deletes the document referred to by the specified `DocumentReference`.
*
* Note that the returned `Promise` does _not_ resolve until the document is
* successfully deleted from the remote Firestore backend and, similarly, is not
* rejected until the remote Firestore backend reports an error deleting the given
* document. So if the client cannot reach the backend (for example, due to being
* offline) then the returned `Promise` will not resolve for a potentially-long
* time (for example, until the client has gone back online). That being said,
* the given data _will_ be immediately deleted from the local cache and will be
* reflected in future "get" operations as if it had been successfully
* deleted from the remote Firestore server, a feature of Firestore called
* "latency compensation". The document will _eventually_ be deleted from the remote
* Firestore backend once a connection can be established. Therefore, it is
* usually undesirable to `await` the `Promise` returned from this function
* because the indefinite amount of time before which the promise resolves or
* rejects can block application logic unnecessarily.
*
* @param reference - A reference to the document to delete.
* @returns A `Promise` that resolves once the document has been successfully
* deleted from the backend or rejects once the backend reports an error
* deleting the document.
*/ function deleteDoc(e) {
	return executeWrite(ra(e.firestore, da), [new __PRIVATE_DeleteMutation(e._key, Precondition.none())]);
}
/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Locally writes `mutations` on the async queue.
* @internal
*/ function executeWrite(e, t) {
	return __PRIVATE_firestoreClientWrite(oa(e), t);
}
/**
* @license
* Copyright 2021 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2023 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* @license
* Copyright 2023 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
var Be = "@firebase/firestore";
var Me = "4.17.2";
/**
* Cloud Firestore
*
* @packageDocumentation
*/
(function __PRIVATE_registerFirestore(s, a = true) {
	/**
	* @license
	* Copyright 2020 Google LLC
	*
	* Licensed under the Apache License, Version 2.0 (the "License");
	* you may not use this file except in compliance with the License.
	* You may obtain a copy of the License at
	*
	*   http://www.apache.org/licenses/LICENSE-2.0
	*
	* Unless required by applicable law or agreed to in writing, software
	* distributed under the License is distributed on an "AS IS" BASIS,
	* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	* See the License for the specific language governing permissions and
	* limitations under the License.
	*/
	__PRIVATE_setSDKVersion(SDK_VERSION), _registerComponent(new Component("firestore", ((e, { instanceIdentifier: t, options: n }) => {
		const r = e.getProvider("app").getImmediate(), s = new da(new __PRIVATE_FirebaseAuthCredentialsProvider(e.getProvider("auth-internal")), new __PRIVATE_FirebaseAppCheckTokenProvider(r, e.getProvider("app-check-internal")), __PRIVATE_databaseIdFromApp(r, t), r);
		return n = {
			useFetchStreams: a,
			...n
		}, s._setSettings(n), s;
	}), "PUBLIC").setMultipleInstances(true)), registerVersion(Be, Me, s), registerVersion(Be, Me, "esm2020");
})();
//#endregion
export { collection as a, updateDoc as i, getDocs as n, doc as o, setDoc as r, getFirestore as s, deleteDoc as t };
