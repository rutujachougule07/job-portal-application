import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as GenericAdminPage } from "./Dashboards-BuSAs1ES.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/notifications-uisP2BFf.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GenericAdminPage, {
	role: "admin",
	title: "Notifications"
});
//#endregion
export { SplitComponent as component };
