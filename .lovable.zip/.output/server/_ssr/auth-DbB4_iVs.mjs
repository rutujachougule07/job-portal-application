import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as stringType, t as objectType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-DbB4_iVs.js
var $$splitComponentImporter = () => import("./auth-DLuInBBR.mjs");
var searchSchema = objectType({
	mode: stringType().optional().catch("login"),
	role: stringType().optional().catch("worker")
});
var Route = createFileRoute("/auth")({
	validateSearch: (s) => searchSchema.parse(s),
	head: () => ({ meta: [{ title: "Login or Register — REAL JOB" }, {
		name: "description",
		content: "Access worker profiles, post jobs, and manage job applications on REAL JOB."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
