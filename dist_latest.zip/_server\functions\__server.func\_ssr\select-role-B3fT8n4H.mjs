import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as stringType, t as objectType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/select-role-B3fT8n4H.js
var $$splitComponentImporter = () => import("./select-role-C1wRfRIm.mjs");
var Route = createFileRoute("/select-role")({
	validateSearch: objectType({ redirectTo: stringType().optional().catch("/") }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
