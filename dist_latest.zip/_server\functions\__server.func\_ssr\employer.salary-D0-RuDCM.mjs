import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as SalaryPage } from "./Dashboards-Bp9jvLIp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/employer.salary-D0-RuDCM.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SalaryPage, { role: "admin" });
//#endregion
export { SplitComponent as component };
