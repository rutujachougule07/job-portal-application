import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n } from "./i18n-CEAlH7ip.mjs";
import { t as Button } from "./button--9UiOy7A.mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as dataStore } from "./data-store-BCcScpg-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { Bt as Building2, M as Save, Vt as Briefcase, a as Wallet, gt as FileText, k as Send, r as X, vt as Eye } from "../_libs/lucide-react.mjs";
import { t as PublicHeader } from "./PublicHeader-D-9eaxtQ.mjs";
import { t as PublicFooter } from "./PublicFooter-zsmeitx6.mjs";
import { t as Badge } from "./badge-DRaMiws1.mjs";
import { t as Input } from "./input-CZUnWUIa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/post-job-eVL_KgG6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SUBCATEGORIES_MAP = {
	"HR & Recruitment": [
		"HR Executive (एचआर एक्झिक्युटिव्ह)",
		"HR Manager (एचआर मॅनेजर)",
		"Recruiter / Talent Acquisition (भरती अधिकारी)",
		"Technical Recruiter (आयटी भरतीदार)",
		"Payroll Executive (पेरोल एक्झिक्युटिव्ह)",
		"HR Generalist"
	],
	"IT & Software": [
		"Full Stack Developer",
		"Frontend Developer",
		"Backend Developer",
		"Web Developer",
		"React Developer",
		"Java Developer",
		"Python Developer",
		"Software Developer",
		"Software Tester / QA",
		"Data Analyst",
		"DevOps Engineer",
		"UI/UX Designer"
	],
	"Engineering": [
		"Mechanical Engineer",
		"Electrical Engineer",
		"Civil Engineer",
		"Electronics Engineer",
		"Production Engineer",
		"Automobile Engineer",
		"Quality Engineer"
	],
	"Healthcare & Medical": [
		"Staff Nurse (परिचारिका)",
		"ICU Assistant",
		"Doctor",
		"Pharmacist (औषधनिर्माता)",
		"Lab Technician",
		"Medical Assistant"
	],
	"Finance & Accounting": [
		"Accountant (लेखापाल)",
		"Finance Executive",
		"Banking Executive",
		"Auditor",
		"Tax Consultant / GST Executive"
	],
	"Sales & Marketing": [
		"Sales Executive",
		"Business Development Executive",
		"Digital Marketing Specialist",
		"Telecaller / Customer Support",
		"Field Sales Officer"
	],
	"Education": [
		"School Teacher (शिक्षक)",
		"Professor / Lecturer",
		"Online Tutor",
		"Academic Coordinator"
	],
	"Design & Creative": [
		"Graphic Designer",
		"Video Editor",
		"Content Creator",
		"UI/UX Designer"
	],
	"Legal": [
		"Lawyer / Advocate",
		"Legal Executive",
		"Compliance Officer"
	],
	"Architecture & Design": [
		"Architect",
		"Interior Designer",
		"3D Visualizer / CAD Designer"
	],
	"Factory Workers": [
		"CNC / VMC Machine Operator",
		"Assembly Line Worker",
		"Quality Inspector",
		"Factory Helper (कारखाना मदतनीस)",
		"Production Supervisor",
		"Welder (वेल्डर)"
	],
	"Construction & Building": [
		"Construction Worker (बांधकाम कामगार)",
		"Mason (गवंडी)",
		"Helper (मदतनीस)",
		"Carpenter (सुतार)",
		"Painter (रंगारी)",
		"Plumber (प्लंबर)",
		"Electrician (इलेक्ट्रीशियन)",
		"Tile Worker",
		"Welder (वेल्डर)",
		"Steel Fixer",
		"Civil Engineer"
	],
	"Technical Staff": [
		"Technician",
		"Maintenance Engineer",
		"Electrician",
		"Fitter / Turner",
		"Tool & Die Maker"
	],
	"Logistics & Drivers": [
		"Driver (ड्रायव्हर)",
		"Heavy Commercial Truck Driver",
		"Tempo / Auto Driver",
		"Delivery Worker (डिलिव्हरी बॉय)",
		"Loader & Unloader (हमाल)"
	],
	"Agriculture & Farming": [
		"Farm Worker (शेतमजूर)",
		"Tractor Operator (ट्रॅक्टर चालक)",
		"Harvesting Worker (काढणी कामगार)",
		"Gardener (माळी)",
		"Dairy Worker (दुग्धव्यवसाय कामगार)",
		"Poultry Worker (पोल्ट्री कामगार)",
		"Fruit Picker"
	],
	"Skilled Workers": [
		"Senior Electrician",
		"Mason",
		"Welder",
		"Mechanic",
		"Fitter",
		"Plumber"
	],
	"Unskilled Workers": [
		"General Helper (मदतनीस)",
		"Loading Worker",
		"Site Helper",
		"Cleaning Helper"
	],
	"Electricians": [
		"Electrician (इलेक्ट्रीशियन)",
		"Panel Wireman",
		"Maintenance Technician",
		"AC / Repair Technician"
	],
	"Warehouse Workers": [
		"Warehouse Helper",
		"Picker & Packer",
		"Inventory Controller",
		"Forklift Operator"
	],
	"Hotel & Restaurant": [
		"Chef / Head Cook (आचारी)",
		"Assistant Cook (सहाय्यक आचारी)",
		"Waiter / Server",
		"Housekeeping Staff",
		"Receptionist / Counter Staff"
	],
	"Security": [
		"Security Guard (सुरक्षा रक्षक)",
		"Security Supervisor",
		"CCTV Monitor"
	],
	"Helpers": [
		"General Helper (मदतनीस)",
		"Housekeeping",
		"Office Boy / Peon",
		"Attendant"
	]
};
function PostJobPage() {
	const { t } = useI18n();
	const navigate = useNavigate();
	const [showPreview, setShowPreview] = (0, import_react.useState)(false);
	const [formData, setFormData] = (0, import_react.useState)({
		title: "",
		category: "HR & Recruitment",
		subcategory: "HR Executive (एचआर एक्झिक्युटिव्ह)",
		company: "",
		location: "",
		salaryMin: "",
		salaryMax: "",
		salaryType: "Per Month",
		experience: "1-3 Years",
		jobType: "Full-time",
		vacancies: "5",
		skills: "Recruitment, Screening, Interviewing, Payroll",
		education: "MBA / Graduate",
		languages: "English, Hindi, Marathi",
		benefits: "Health Insurance, Annual Bonus",
		description: "",
		contactPerson: "",
		contactPhone: ""
	});
	const handleChange = (field, value) => {
		if (field === "category") {
			const subOptions = SUBCATEGORIES_MAP[value] || ["General Role"];
			setFormData((prev) => ({
				...prev,
				category: value,
				subcategory: subOptions[0] || "General Role"
			}));
		} else setFormData((prev) => ({
			...prev,
			[field]: value
		}));
	};
	const handleSaveDraft = () => {
		toast.success("Job draft saved successfully!");
	};
	const handleSubmit = (e) => {
		e.preventDefault();
		if (!formData.title || !formData.company || !formData.location) {
			toast.error("Please fill in Job Title, Company and Location.");
			return;
		}
		const currentUser = dataStore.getCurrentUser();
		const employerId = currentUser ? currentUser.id || currentUser.email : formData.company;
		const cleanMin = formData.salaryMin ? formData.salaryMin.replace(/[^0-9]/g, "") : "";
		const cleanMax = formData.salaryMax ? formData.salaryMax.replace(/[^0-9]/g, "") : "";
		const salaryString = cleanMin && cleanMax ? `₹${cleanMin}–₹${cleanMax} / ${formData.salaryType === "Per Day" ? "day" : "month"}` : cleanMin ? `₹${cleanMin} / ${formData.salaryType === "Per Day" ? "day" : "month"}` : "₹25,000–40,000 / month";
		const skillsArray = formData.skills ? formData.skills.split(",").map((s) => s.trim()) : ["General Work"];
		const benefitsArray = formData.benefits ? formData.benefits.split(",").map((b) => b.trim()) : ["Standard Allowance"];
		dataStore.createJob({
			employerId,
			title: formData.title,
			company: formData.company,
			category: formData.category,
			subcategory: formData.subcategory || formData.category,
			description: formData.description || `${formData.title} job posting for ${formData.company}.`,
			responsibilities: ["Execute daily operations and shopfloor targets", "Maintain site and safety standards"],
			requiredSkills: skillsArray,
			qualification: formData.education || "10th Pass",
			experience: formData.experience,
			salary: salaryString,
			...formData.salaryMin ? { salaryMin: parseInt(formData.salaryMin) } : {},
			...formData.salaryMax ? { salaryMax: parseInt(formData.salaryMax) } : {},
			salaryType: formData.salaryType === "Per Day" ? "Daily" : "Monthly",
			location: formData.location,
			jobType: formData.jobType || "Full Time",
			workMode: "On-site",
			vacancies: parseInt(formData.vacancies) || 5,
			benefits: benefitsArray,
			status: "Active",
			approvalStatus: "pending"
		});
		toast.success("⏳ नोकरी सबमिट झाली आहे! सुपर ॲडमिन मंजुरीनंतर (Super Admin approval) ही Job वेबसाईटवर दिसेल.");
		setTimeout(() => {
			navigate({ to: "/jobs" });
		}, 1800);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "bg-[#F5F8FC] min-h-screen py-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-4xl px-4 sm:px-6 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-hero-overlay p-8 rounded-2xl text-white mb-8 shadow-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-bold uppercase tracking-wider text-[#FFC400] backdrop-blur mb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4" }), "नवीन नोकरी पोस्ट करा • Post Job"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-3xl font-black text-white",
							children: "कामगारांसाठी नोकरी प्रसिद्ध करा"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-white/90 mt-1",
							children: "कारखाने, बांधकाम व व्यवसाय क्षेत्रातील कामगारांपर्यंत तुमची नोकरी त्वरित पोहोचवा."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleSubmit,
					className: "bg-white p-6 sm:p-10 rounded-2xl border border-[#DCE5F0] shadow-sm space-y-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "text-lg font-black text-[#10233F] pb-3 border-b border-[#DCE5F0] mb-5 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-5 text-[#063B78]" }), " 1. नोकरीची प्राथमिक माहिती (Basic Details)"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "sm:col-span-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-extrabold text-[#10233F] mb-1.5 uppercase",
										children: "नोकरीचे नाव (Job Title) *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										required: true,
										placeholder: "उदा. Senior CNC Operator / फॅक्टरी वेल्डर",
										value: formData.title,
										onChange: (e) => handleChange("title", e.target.value),
										className: "h-11 border-[#DCE5F0] text-xs font-bold text-[#10233F]"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-1.5 uppercase",
									children: "कंपनीचे नाव (Company Name) *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									required: true,
									placeholder: "उदा. Tata Auto Components Ltd.",
									value: formData.company,
									onChange: (e) => handleChange("company", e.target.value),
									className: "h-11 border-[#DCE5F0] text-xs font-bold text-[#10233F]"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-1.5 uppercase",
									children: "कामगार / नोकरी श्रेणी (Category) *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: formData.category,
									onChange: (e) => handleChange("category", e.target.value),
									className: "w-full h-11 rounded-lg border border-[#DCE5F0] bg-white px-3 text-xs font-bold text-[#10233F]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("optgroup", {
										label: "💻 Professional & Corporate Categories (कॉर्पोरेट श्रेणी)",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "IT & Software",
												children: "IT & Software (आयटी व सॉफ्टवेअर)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Engineering",
												children: "Engineering (अभियांत्रिकी व तांत्रिक)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Healthcare & Medical",
												children: "Healthcare & Medical (वैद्यकीय व आरोग्य)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Finance & Accounting",
												children: "Finance & Accounting (वित्त व अकाऊंटिंग)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Sales & Marketing",
												children: "Sales & Marketing (विक्री व मार्केटिंग)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Education",
												children: "Education (शिक्षण व अध्यापन)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "HR & Recruitment",
												children: "HR & Recruitment (एचआर व भरती)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Design & Creative",
												children: "Design & Creative (डिझाइन व आर्ट)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Legal",
												children: "Legal & Compliance (कायदेशीर)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Architecture & Design",
												children: "Architecture & Design (स्थापत्य डिझाइन)"
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("optgroup", {
										label: "🛠️ Skilled & Worker Categories (कामगार व व्यवसाय श्रेणी)",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Factory Workers",
												children: "Factory Workers (कारखाना कामगार)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Construction & Building",
												children: "Construction Workers (बांधकाम)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Technical Staff",
												children: "Technical Staff (तांत्रिक कामगार)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Logistics & Drivers",
												children: "Logistics & Drivers (ड्रायव्हर व वाहतूक)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Agriculture & Farming",
												children: "Agriculture & Farming (शेती व कृषी)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Skilled Workers",
												children: "Skilled Workers (कुशल कामगार)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Unskilled Workers",
												children: "Unskilled Workers (अकुशल कामगार)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Electricians",
												children: "Electricians & Maintenance (इलेक्ट्रीशियन व मेंटेनन्स)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Warehouse Workers",
												children: "Warehouse Workers (वेअरहाउस)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Hotel & Restaurant",
												children: "Hotel & Restaurant (हॉटेल व रेस्टॉरंट)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Security",
												children: "Security Guards (सुरक्षा रक्षक)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Helpers",
												children: "Helpers & Attendants (मदतनीस)"
											})
										]
									})]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-1.5 uppercase",
									children: "उपश्रेणी / पद (Subcategory / Role) *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: formData.subcategory,
									onChange: (e) => handleChange("subcategory", e.target.value),
									className: "w-full h-11 rounded-lg border border-[#DCE5F0] bg-white px-3 text-xs font-bold text-[#10233F]",
									children: (SUBCATEGORIES_MAP[formData.category] || ["General Role"]).map((sub) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: sub,
										children: sub
									}, sub))
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-1.5 uppercase",
									children: "ठिकाण (Location / City) *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									required: true,
									placeholder: "उदा. Chakan, Pune",
									value: formData.location,
									onChange: (e) => handleChange("location", e.target.value),
									className: "h-11 border-[#DCE5F0] text-xs font-bold text-[#10233F]"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-1.5 uppercase",
									children: "रिक्त जागांची संख्या (Vacancies)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: formData.vacancies,
									onChange: (e) => handleChange("vacancies", e.target.value),
									className: "h-11 border-[#DCE5F0] text-xs font-bold text-[#10233F]"
								})] })
							]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "text-lg font-black text-[#10233F] pb-3 border-b border-[#DCE5F0] mb-5 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-5 text-[#125BB5]" }), " 2. पगार व नोकरीचे स्वरूप (Salary & Type)"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-3 gap-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-1.5 uppercase",
									children: "किमान पगार (Min Salary ₹)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "18,000",
									value: formData.salaryMin,
									onChange: (e) => handleChange("salaryMin", e.target.value),
									className: "h-11 border-[#DCE5F0] text-xs font-bold text-[#10233F]"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-1.5 uppercase",
									children: "कमाल पगार (Max Salary ₹)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "25,000",
									value: formData.salaryMax,
									onChange: (e) => handleChange("salaryMax", e.target.value),
									className: "h-11 border-[#DCE5F0] text-xs font-bold text-[#10233F]"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-1.5 uppercase",
									children: "पगाराचा कालावधी (Salary Type)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: formData.salaryType,
									onChange: (e) => handleChange("salaryType", e.target.value),
									className: "w-full h-11 rounded-lg border border-[#DCE5F0] bg-white px-3 text-xs font-bold text-[#10233F]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Per Month",
											children: "दरमहा (Per Month)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Per Day",
											children: "दररोज (Per Day)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Per Year",
											children: "वार्षिक (Per Year)"
										})
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-1.5 uppercase",
									children: "आवश्यक अनुभव (Experience Required)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: formData.experience,
									onChange: (e) => handleChange("experience", e.target.value),
									className: "w-full h-11 rounded-lg border border-[#DCE5F0] bg-white px-3 text-xs font-bold text-[#10233F]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Freshers Allowed",
											children: "नवीन कामगार (Fresher Allowed)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "1-3 Years",
											children: "1 ते 3 वर्षे (1-3 Years)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "3-5 Years",
											children: "3 ते 5 वर्षे (3-5 Years)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "5+ Years",
											children: "5 वर्षांपेक्षा जास्त (5+ Years)"
										})
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-1.5 uppercase",
									children: "नोकरीचा प्रकार (Job Type)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: formData.jobType,
									onChange: (e) => handleChange("jobType", e.target.value),
									className: "w-full h-11 rounded-lg border border-[#DCE5F0] bg-white px-3 text-xs font-bold text-[#10233F]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Full-time",
											children: "पूर्ण वेळ (Full-time)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Part-time",
											children: "अर्धा वेळ (Part-time)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Contract",
											children: "कंत्राटी (Contract)"
										})
									]
								})] })
							]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "text-lg font-black text-[#10233F] pb-3 border-b border-[#DCE5F0] mb-5 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-5 text-[#063B78]" }), " 3. कामाचे स्वरूप व कौशल्ये (Details & Skills)"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-1.5 uppercase",
									children: "आवश्यक कौशल्ये (Required Skills, Comma Separated)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "उदा. Wiring, ITI Certificate, Panel Inspection",
									value: formData.skills,
									onChange: (e) => handleChange("skills", e.target.value),
									className: "h-11 border-[#DCE5F0] text-xs font-bold text-[#10233F]"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-1.5 uppercase",
									children: "कामाचे वर्णन व अटी (Job Description)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									rows: 4,
									placeholder: "कामाचे स्वरूप, वेळ आणि इतर नियम सविस्तर प्रविष्ट करा...",
									value: formData.description,
									onChange: (e) => handleChange("description", e.target.value),
									className: "w-full rounded-lg border border-[#DCE5F0] p-3 text-xs font-bold text-[#10233F]"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-extrabold text-[#10233F] mb-1.5 uppercase",
										children: "कंपनीचे फायदे (Benefits, e.g. PF, Canteen)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: "उदा. Free Canteen, OT Allowance, Bus Facility",
										value: formData.benefits,
										onChange: (e) => handleChange("benefits", e.target.value),
										className: "h-11 border-[#DCE5F0] text-xs font-bold text-[#10233F]"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-extrabold text-[#10233F] mb-1.5 uppercase",
										children: "संपर्क व्यक्ती व मोबाईल (Contact Person & Phone)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: "उदा. HR Ramesh Pawar (+91 98220 11223)",
										value: formData.contactPhone,
										onChange: (e) => handleChange("contactPhone", e.target.value),
										className: "h-11 border-[#DCE5F0] text-xs font-bold text-[#10233F]"
									})] })]
								})
							]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pt-6 border-t border-[#DCE5F0] flex flex-wrap items-center justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "outline",
								onClick: handleSaveDraft,
								className: "border-[#063B78] text-[#063B78] font-bold text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4 mr-1.5" }), " ड्राफ्ट सेव्ह करा (Save Draft)"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									variant: "secondary",
									onClick: () => setShowPreview(true),
									className: "bg-[#EBF1F8] text-[#063B78] font-bold text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4 mr-1.5" }), " प्रीव्ह्यू (Preview)"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "submit",
									className: "btn-yellow font-black text-xs px-8 py-3 h-11",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4 mr-1.5" }), " नोकरी प्रसिद्ध करा (Publish Job)"]
								})]
							})]
						})
					]
				})]
			}), showPreview && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-[#082F63]/60 backdrop-blur-sm flex items-center justify-center p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white w-full max-w-xl rounded-2xl p-6 shadow-2xl relative",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setShowPreview(false),
							className: "absolute right-4 top-4 text-[#5B6B7F]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xl font-black text-[#10233F] mb-4",
							children: "नोकरी प्रीव्ह्यू (Job Preview)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "card-realjob p-6 space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "text-xl font-black text-[#063B78]",
									children: formData.title || "Job Title"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-bold text-[#125BB5]",
									children: [
										formData.company,
										" • ",
										formData.location
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-2 text-xs font-bold",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
											className: "bg-[#FFC400] text-[#082F63]",
											children: [
												"₹",
												formData.salaryMin,
												" - ₹",
												formData.salaryMax,
												" ",
												formData.salaryType
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: "outline",
											children: formData.experience
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: "outline",
											children: formData.jobType
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold text-[#5B6B7F]",
									children: formData.description || "Job description preview..."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6 text-right",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => setShowPreview(false),
								className: "btn-yellow text-xs font-bold",
								children: "बंद करा (Close)"
							})
						})
					]
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicFooter, {})
	] });
}
//#endregion
export { PostJobPage as component };
