//#region node_modules/.nitro/vite/services/ssr/assets/data-store-j7ecARph.js
var INITIAL_JOBS = [];
var DataStoreManager = class {
	STORAGE_KEYS = {
		USER: "realjob_current_user",
		JOBS: "realjob_db_jobs",
		APPLICATIONS: "realjob_db_applications",
		SAVED_JOBS: "realjob_db_saved_jobs",
		JOB_ALERTS: "realjob_db_job_alerts",
		PROFILES: "realjob_db_profiles",
		EMPLOYERS: "realjob_db_employers",
		INTERVIEWS: "realjob_db_interviews",
		RESUMES: "realjob_db_resumes"
	};
	constructor() {
		this.initializeDefaults();
	}
	initializeDefaults() {
		if (typeof window === "undefined") return;
		if (!localStorage.getItem(this.STORAGE_KEYS.JOBS)) localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify([]));
		if (!localStorage.getItem(this.STORAGE_KEYS.APPLICATIONS)) localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify([]));
		if (!localStorage.getItem(this.STORAGE_KEYS.SAVED_JOBS)) localStorage.setItem(this.STORAGE_KEYS.SAVED_JOBS, JSON.stringify([]));
		if (!localStorage.getItem(this.STORAGE_KEYS.JOB_ALERTS)) localStorage.setItem(this.STORAGE_KEYS.JOB_ALERTS, JSON.stringify([]));
	}
	getRegisteredUsers() {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem("realjob_db_registered_users");
		if (!raw) return [];
		try {
			return JSON.parse(raw);
		} catch {
			return [];
		}
	}
	getCurrentUser() {
		if (typeof window === "undefined") return null;
		const raw = localStorage.getItem(this.STORAGE_KEYS.USER);
		if (!raw) return null;
		try {
			return JSON.parse(raw);
		} catch {
			return null;
		}
	}
	setCurrentUser(userData) {
		if (typeof window === "undefined") return;
		if (!userData) localStorage.removeItem(this.STORAGE_KEYS.USER);
		else localStorage.setItem(this.STORAGE_KEYS.USER, JSON.stringify(userData));
	}
	logout() {
		this.setCurrentUser(null);
	}
	getAllJobs() {
		if (typeof window === "undefined") return INITIAL_JOBS;
		const raw = localStorage.getItem(this.STORAGE_KEYS.JOBS);
		if (!raw) return INITIAL_JOBS;
		try {
			const parsed = JSON.parse(raw);
			const cleaned = parsed.filter((j) => !j.id.startsWith("job-c") && !j.id.startsWith("job-it") && !j.id.startsWith("job-eng") && !j.id.startsWith("job-hc") && !j.id.startsWith("job-tr") && !j.id.startsWith("job-ag") && !j.id.startsWith("job-fin") && !j.id.startsWith("job-sm") && !j.id.startsWith("job-edu") && !j.id.startsWith("job-mfg") && !j.id.startsWith("job-hr") && !j.id.startsWith("job-hosp") && !j.id.startsWith("job-log") && !j.id.startsWith("job-gov") && !j.id.startsWith("job-legal") && !j.id.startsWith("job-arch") && !j.id.startsWith("job-ret") && !j.id.startsWith("job-bpo") && !j.id.startsWith("job-des") && !j.id.startsWith("c-") && !j.id.startsWith("it-") && !j.id.startsWith("eng-") && !j.id.startsWith("hc-") && !j.id.startsWith("fin-") && !j.id.startsWith("sm-") && !j.id.startsWith("edu-") && !j.id.startsWith("mfg-") && !j.id.startsWith("hr-") && !j.id.startsWith("hosp-") && !j.id.startsWith("log-") && !j.id.startsWith("gov-") && !j.id.startsWith("leg-") && !j.id.startsWith("arch-") && !j.id.startsWith("ret-") && !j.id.startsWith("bpo-") && !j.id.startsWith("des-") && !j.id.startsWith("agri-") && !j.id.startsWith("sci-") && !j.id.startsWith("med-") && j.company?.toLowerCase() !== "alpha byete" && j.title?.toLowerCase() !== "software company");
			if (cleaned.length !== parsed.length) localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify(cleaned));
			return cleaned;
		} catch {
			return INITIAL_JOBS;
		}
	}
	getActiveJobs() {
		return this.getAllJobs().filter((j) => j.status === "Active");
	}
	getJobById(jobId) {
		return this.getAllJobs().find((j) => j.id === jobId);
	}
	createJob(jobData) {
		const jobs = this.getAllJobs();
		const initials = (jobData.company || "Company").substring(0, 2).toUpperCase();
		const newJob = {
			...jobData,
			id: `job-${Date.now()}`,
			postedDate: (/* @__PURE__ */ new Date()).toISOString(),
			postedAgo: "Just now",
			initials
		};
		jobs.unshift(newJob);
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify(jobs));
		return newJob;
	}
	updateJob(jobId, updates) {
		const jobs = this.getAllJobs();
		const existing = jobs.find((j) => j.id === jobId);
		if (!existing) return null;
		const index = jobs.findIndex((j) => j.id === jobId);
		const updatedJob = {
			...existing,
			...updates
		};
		jobs[index] = updatedJob;
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify(jobs));
		return updatedJob;
	}
	deleteJob(jobId) {
		let jobs = this.getAllJobs();
		jobs = jobs.filter((j) => j.id !== jobId);
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify(jobs));
		return true;
	}
	deleteAllJobs() {
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.JOBS, JSON.stringify([]));
		return true;
	}
	getEmployerJobs(identifier) {
		const jobs = this.getAllJobs();
		if (!identifier) return [];
		const q = identifier.toLowerCase().trim();
		return jobs.filter((j) => {
			const empId = (j.employerId || "").toLowerCase();
			const comp = (j.company || "").toLowerCase();
			return empId === q || comp === q || empId && empId.includes(q) || q && q.includes(empId) || comp && comp.includes(q) || q && q.includes(comp);
		});
	}
	getAllApplications() {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.APPLICATIONS);
		if (!raw) return [];
		try {
			return JSON.parse(raw);
		} catch {
			return [];
		}
	}
	hasAlreadyApplied(jobSeekerId, jobId) {
		return this.getAllApplications().some((a) => (a.jobSeekerId === jobSeekerId || a.candidateEmail === jobSeekerId) && a.jobId === jobId);
	}
	createApplication(appData) {
		const apps = this.getAllApplications();
		if (this.hasAlreadyApplied(appData.jobSeekerId, appData.jobId)) throw new Error("Already applied to this job");
		const newApp = {
			...appData,
			id: `app-${Date.now()}`,
			appliedDate: (/* @__PURE__ */ new Date()).toLocaleDateString("en-IN", {
				day: "numeric",
				month: "short",
				year: "numeric"
			}),
			status: "Applied"
		};
		apps.unshift(newApp);
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify(apps));
		return newApp;
	}
	getEmployerApplications(identifier) {
		const apps = this.getAllApplications();
		if (!identifier) return [];
		const q = identifier.toLowerCase().trim();
		return apps.filter((a) => {
			const empId = (a.employerId || "").toLowerCase();
			const comp = (a.companyName || "").toLowerCase();
			return empId === q || comp === q || empId && empId.includes(q) || q && q.includes(empId) || comp && comp.includes(q) || q && q.includes(comp);
		});
	}
	getJobSeekerApplications(jobSeekerId) {
		return this.getAllApplications().filter((a) => a.jobSeekerId === jobSeekerId || a.candidateEmail === jobSeekerId);
	}
	updateApplicationStatus(applicationId, status) {
		const apps = this.getAllApplications();
		const existing = apps.find((a) => a.id === applicationId);
		if (!existing) return null;
		const index = apps.findIndex((a) => a.id === applicationId);
		const updatedApp = {
			...existing,
			status
		};
		apps[index] = updatedApp;
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.APPLICATIONS, JSON.stringify(apps));
		return updatedApp;
	}
	getSavedJobs(jobSeekerId) {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.SAVED_JOBS);
		if (!raw) return [];
		try {
			return JSON.parse(raw).filter((s) => s.jobSeekerId === jobSeekerId);
		} catch {
			return [];
		}
	}
	saveJob(jobSeekerId, jobId) {
		const all = this.getSavedJobs(jobSeekerId);
		if (all.some((s) => s.jobId === jobId)) return all.find((s) => s.jobId === jobId);
		const newSaved = {
			id: `save-${Date.now()}`,
			jobSeekerId,
			jobId,
			savedDate: (/* @__PURE__ */ new Date()).toISOString()
		};
		const raw = localStorage.getItem(this.STORAGE_KEYS.SAVED_JOBS);
		const existing = raw ? JSON.parse(raw) : [];
		existing.push(newSaved);
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.SAVED_JOBS, JSON.stringify(existing));
		return newSaved;
	}
	removeSavedJob(jobSeekerId, jobId) {
		const raw = localStorage.getItem(this.STORAGE_KEYS.SAVED_JOBS);
		if (!raw) return true;
		let existing = JSON.parse(raw);
		existing = existing.filter((s) => !(s.jobSeekerId === jobSeekerId && s.jobId === jobId));
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.SAVED_JOBS, JSON.stringify(existing));
		return true;
	}
	getRecommendedJobs(candidateSkills, candidateCategory) {
		const allJobs = this.getActiveJobs();
		if (!candidateSkills.length && !candidateCategory) return allJobs.slice(0, 4);
		return allJobs.map((job) => {
			let score = 0;
			if (candidateCategory && job.category.toLowerCase().includes(candidateCategory.toLowerCase())) score += 5;
			candidateSkills.forEach((skill) => {
				if (job.requiredSkills.some((s) => s.toLowerCase().includes(skill.toLowerCase())) || job.title.toLowerCase().includes(skill.toLowerCase())) score += 3;
			});
			return {
				job,
				score
			};
		}).sort((a, b) => b.score - a.score).slice(0, 6).map((item) => item.job);
	}
	getApplicationsByJobSeeker(jobSeekerId) {
		return this.getJobSeekerApplications(jobSeekerId);
	}
	getInterviews() {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.INTERVIEWS);
		if (!raw) return [];
		try {
			return JSON.parse(raw);
		} catch {
			return [];
		}
	}
	scheduleInterview(data) {
		const interviews = this.getInterviews();
		const newInt = {
			...data,
			id: `int-${Date.now()}`
		};
		interviews.unshift(newInt);
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.INTERVIEWS, JSON.stringify(interviews));
		return newInt;
	}
	getUserResumes(userId) {
		if (typeof window === "undefined") return [];
		const raw = localStorage.getItem(this.STORAGE_KEYS.RESUMES);
		if (!raw) return [];
		try {
			return JSON.parse(raw).filter((r) => r.userId === userId);
		} catch {
			return [];
		}
	}
	addUserResume(data) {
		const raw = localStorage.getItem(this.STORAGE_KEYS.RESUMES);
		const existing = raw ? JSON.parse(raw) : [];
		const newRes = {
			...data,
			id: `res-${Date.now()}`,
			uploadDate: data.uploadDate || (/* @__PURE__ */ new Date()).toLocaleDateString("en-IN", {
				day: "numeric",
				month: "short",
				year: "numeric"
			})
		};
		existing.unshift(newRes);
		if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.RESUMES, JSON.stringify(existing));
		return newRes;
	}
	deleteUserResume(id) {
		const raw = localStorage.getItem(this.STORAGE_KEYS.RESUMES);
		if (!raw) return true;
		try {
			let existing = JSON.parse(raw);
			existing = existing.filter((r) => r.id !== id);
			if (typeof window !== "undefined") localStorage.setItem(this.STORAGE_KEYS.RESUMES, JSON.stringify(existing));
		} catch {}
		return true;
	}
};
var dataStore = new DataStoreManager();
//#endregion
export { dataStore as t };
