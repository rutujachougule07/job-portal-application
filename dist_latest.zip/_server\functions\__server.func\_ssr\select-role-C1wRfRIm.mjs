import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n } from "./i18n-BlIP7F54.mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { hn as ArrowLeft, mn as ArrowRight, rn as Building2, u as UserRound } from "../_libs/lucide-react.mjs";
import { n as LogoIcon } from "./Brand-CcASrIw4.mjs";
import { t as Route } from "./select-role-B3fT8n4H.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/select-role-C1wRfRIm.js
var import_jsx_runtime = require_jsx_runtime();
function SelectRolePage() {
	const { t, lang } = useI18n();
	const navigate = useNavigate();
	const { redirectTo } = Route.useSearch();
	const handleBackToLanguage = () => {
		navigate({
			to: "/select-language",
			search: { redirectTo }
		});
	};
	const handleSelectRole = (role) => {
		if (typeof window !== "undefined") {
			window.sessionStorage.setItem("karyam-gate-dismissed", "true");
			window.localStorage.setItem("realjob-role", role === "admin" ? "employer" : "worker");
			window.localStorage.setItem("realjob-gate-done", "true");
			window.localStorage.setItem("karyam-onboarding-done", "true");
			window.dispatchEvent(new Event("realjob-auth-change"));
		}
		if (role === "admin") navigate({
			to: "/auth",
			search: {
				mode: "login",
				role: "admin"
			}
		});
		else navigate({
			to: "/auth",
			search: {
				mode: "login",
				role: "worker"
			}
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-cover bg-center flex items-center justify-center p-4 relative",
		style: { backgroundImage: "url('/portal-bg.png')" },
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-black/40 backdrop-blur-xs pointer-events-none" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative z-10 w-full max-w-2xl bg-white rounded-3xl border border-white/60 shadow-2xl p-6 sm:p-8 transition-all duration-300",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: handleBackToLanguage,
					className: "absolute top-4 sm:top-6 left-4 sm:left-6 text-gray-500 hover:text-[#0A3B7B] hover:bg-gray-100 rounded-full h-10 w-10 flex items-center justify-center transition-colors border border-gray-200 shadow-2xs cursor-pointer",
					title: t("backToLanguage"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-center mb-3 sm:mb-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoIcon, { className: "h-14 sm:h-16 object-contain" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center space-y-1 mb-6 sm:mb-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl sm:text-3xl font-black text-[#0A3B7B] tracking-tight",
						children: t("selectRole")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs sm:text-sm font-semibold text-gray-500",
						children: t("roleSubtitle")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 gap-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						onClick: () => handleSelectRole("user"),
						className: "group relative cursor-pointer rounded-2xl border-2 border-slate-200/90 bg-white p-6 transition-all duration-300 hover:border-[#0A3B7B] hover:shadow-xl hover:-translate-y-1 flex flex-col justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-11 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center group-hover:bg-[#0A3B7B] group-hover:text-white transition-colors",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "size-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "px-3 py-1 rounded-full bg-blue-50 text-blue-600 border border-blue-200/70 text-[10px] font-black uppercase tracking-wider",
									children: "WORKER / JOB SEEKER"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xl font-black text-slate-900 group-hover:text-[#0A3B7B] transition-colors mb-2",
								children: t("jobSeeker")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold text-slate-500 leading-relaxed mb-6",
								children: t("jobSeekerDesc")
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center font-bold text-xs text-[#0A3B7B] group-hover:underline gap-1.5 pt-3.5 border-t border-slate-100",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Enter Portal as Job Seeker" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 transition-transform group-hover:translate-x-1" })]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						onClick: () => handleSelectRole("admin"),
						className: "group relative cursor-pointer rounded-2xl border-2 border-slate-200/90 bg-white p-6 transition-all duration-300 hover:border-[#0A3B7B] hover:shadow-xl hover:-translate-y-1 flex flex-col justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-11 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center group-hover:bg-[#0A3B7B] group-hover:text-white transition-colors",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "px-3 py-1 rounded-full bg-amber-50 text-amber-700 border border-amber-200/70 text-[10px] font-black uppercase tracking-wider",
									children: "JOB POSTER"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xl font-black text-slate-900 group-hover:text-[#0A3B7B] transition-colors mb-2",
								children: lang === "en" ? "Job Poster" : t("jobProvider") || "Job Poster"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold text-slate-500 leading-relaxed mb-6",
								children: t("jobProviderDesc")
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center font-bold text-xs text-[#0A3B7B] group-hover:underline gap-1.5 pt-3.5 border-t border-slate-100",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Enter Portal as Job Poster" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 transition-transform group-hover:translate-x-1" })]
						})]
					})]
				})
			]
		})]
	});
}
//#endregion
export { SelectRolePage as component };
