import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button--9UiOy7A.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as dataStore } from "./data-store-BCcScpg-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { A as Search, Ht as BriefcaseBusiness, I as Plus, Lt as ChartColumn, T as ShieldCheck, _t as FileText, h as Trash2, s as Users, y as SquarePen } from "../_libs/lucide-react.mjs";
import { t as Badge } from "./badge-DRaMiws1.mjs";
import { t as StatCard } from "./Stats-BJplhY8l.mjs";
import { t as Input } from "./input-CZUnWUIa.mjs";
import { a as CartesianGrid, i as Area, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-B2zMQwjo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var monthlyAnalytics = [
	{
		month: "May",
		workers: 0,
		jobs: 0,
		hires: 0
	},
	{
		month: "Jun",
		workers: 0,
		jobs: 0,
		hires: 0
	},
	{
		month: "Jul",
		workers: 0,
		jobs: 0,
		hires: 0
	},
	{
		month: "Aug",
		workers: 0,
		jobs: 0,
		hires: 0
	},
	{
		month: "Sep",
		workers: 0,
		jobs: 0,
		hires: 0
	}
];
function formatWaNumber(phone) {
	const digits = (phone || "").trim().replace(/\D/g, "");
	if (!digits) return "919822011223";
	if (digits.length === 10) return `91${digits}`;
	if (digits.length === 12 && digits.startsWith("91")) return digits;
	if (digits.length === 11 && digits.startsWith("0")) return `91${digits.slice(1)}`;
	return digits.length >= 10 ? digits : `91${digits}`;
}
function formatCallNumber(phone) {
	const raw = (phone || "").trim();
	const digits = raw.replace(/\D/g, "");
	if (!digits) return "+919822011223";
	if (digits.length === 10) return `+91${digits}`;
	if (digits.length === 12 && digits.startsWith("91")) return `+${digits}`;
	if (digits.length === 11 && digits.startsWith("0")) return `+91${digits.slice(1)}`;
	return raw.startsWith("+") ? raw : `+${digits}`;
}
function AdminDashboardPage() {
	useNavigate();
	const [activeTab, setActiveTab] = (0, import_react.useState)("overview");
	const [jobs, setJobs] = (0, import_react.useState)([]);
	const [applications, setApplications] = (0, import_react.useState)([]);
	const [userSearch, setUserSearch] = (0, import_react.useState)("");
	const [jobSearch, setJobSearch] = (0, import_react.useState)("");
	const [appSearch, setAppSearch] = (0, import_react.useState)("");
	const [filterJobId, setFilterJobId] = (0, import_react.useState)(null);
	const [expandedApp, setExpandedApp] = (0, import_react.useState)(null);
	const [registeredUsers, setRegisteredUsers] = (0, import_react.useState)([]);
	const currentUser = dataStore.getCurrentUser();
	const isSuperAdmin = currentUser?.email?.toLowerCase() === "supera@gmail.com" || currentUser?.email?.toLowerCase() === "superadmin";
	const empIdentifier = currentUser?.fullName || currentUser?.email || "admin-001";
	const loadAllData = () => {
		if (isSuperAdmin) {
			setJobs(dataStore.getAllJobs());
			setApplications(dataStore.getAllApplications());
		} else {
			setJobs(dataStore.getEmployerJobs(empIdentifier));
			setApplications(dataStore.getEmployerApplications(empIdentifier));
		}
		const reg = dataStore.getRegisteredUsers();
		setRegisteredUsers(reg.map((u) => ({
			id: u.id,
			name: u.fullName,
			role: u.role,
			mobile: u.mobile || "N/A",
			city: "Maharashtra",
			trade: u.role === "worker" ? "Worker" : u.role === "employer" ? "Employer" : "Admin",
			status: "Verified"
		})));
	};
	(0, import_react.useEffect)(() => {
		loadAllData();
	}, [empIdentifier]);
	const handleUpdateAppStatus = (appId, status) => {
		dataStore.updateApplicationStatus(appId, status);
		loadAllData();
		toast.success(`अर्जाची स्थिती '${status}' वर बदलली!`);
	};
	const [showJobForm, setShowJobForm] = (0, import_react.useState)(false);
	const [editingJobId, setEditingJobId] = (0, import_react.useState)(null);
	const [jobForm, setJobForm] = (0, import_react.useState)({
		title: "",
		company: "REAL JOB Platform",
		category: "",
		subcategory: "",
		location: "",
		salaryMin: "",
		salaryMax: "",
		salaryType: "Monthly",
		jobType: "Full Time",
		workMode: "On-site",
		vacancies: "5",
		education: "",
		experience: "",
		skills: "",
		description: "",
		responsibilities: "",
		benefits: "",
		status: "Active"
	});
	const setJ = (k, v) => setJobForm((p) => ({
		...p,
		[k]: v
	}));
	const handleAddNewJobClick = () => {
		setEditingJobId(null);
		setJobForm({
			title: "",
			company: "REAL JOB Platform",
			category: "",
			subcategory: "",
			location: "",
			salaryMin: "",
			salaryMax: "",
			salaryType: "Monthly",
			jobType: "Full Time",
			workMode: "On-site",
			vacancies: "5",
			education: "",
			experience: "",
			skills: "",
			description: "",
			responsibilities: "",
			benefits: "",
			status: "Active"
		});
		setShowJobForm(true);
	};
	const handleEditJobClick = (job) => {
		setEditingJobId(job.id);
		let sMin = job.salaryMin ? String(job.salaryMin) : "";
		let sMax = job.salaryMax ? String(job.salaryMax) : "";
		if (!sMin && !sMax && job.salary) {
			const numbers = job.salary.match(/\d[\d,]*/g);
			if (numbers && numbers.length >= 2 && numbers[0] && numbers[1]) {
				sMin = numbers[0].replace(/,/g, "");
				sMax = numbers[1].replace(/,/g, "");
			}
		}
		setJobForm({
			title: job.title || "",
			company: job.company || "",
			category: job.category || "",
			subcategory: job.subcategory || "",
			location: job.location || "",
			salaryMin: sMin,
			salaryMax: sMax,
			salaryType: job.salaryType || "Monthly",
			jobType: job.jobType || "Full Time",
			workMode: job.workMode || "On-site",
			vacancies: job.vacancies ? String(job.vacancies) : "5",
			education: job.qualification || "",
			experience: job.experience || "",
			skills: (job.requiredSkills || []).join(", "),
			description: job.description || "",
			responsibilities: (job.responsibilities || []).join("\n"),
			benefits: (job.benefits || []).join(", "),
			status: job.status || "Active"
		});
		setShowJobForm(true);
	};
	const handlePublishJob = (e) => {
		e.preventDefault();
		const salaryText = jobForm.salaryMin && jobForm.salaryMax ? `₹${Number(jobForm.salaryMin).toLocaleString("en-IN")} - ₹${Number(jobForm.salaryMax).toLocaleString("en-IN")} / ${jobForm.salaryType === "Monthly" ? "Month" : "Year"}` : "Salary on Interview";
		if (editingJobId) {
			dataStore.updateJob(editingJobId, {
				title: jobForm.title,
				company: jobForm.company || currentUser?.fullName || "Company",
				category: jobForm.category || "General",
				subcategory: jobForm.subcategory || "",
				description: jobForm.description,
				qualification: jobForm.education,
				experience: jobForm.experience,
				salary: salaryText,
				salaryMin: Number(jobForm.salaryMin) || 0,
				salaryMax: Number(jobForm.salaryMax) || 0,
				salaryType: jobForm.salaryType,
				location: jobForm.location,
				jobType: jobForm.jobType,
				workMode: jobForm.workMode,
				vacancies: Number(jobForm.vacancies) || 1,
				status: jobForm.status
			});
			toast.success("✅ नोकरीची माहिती यशस्वीरित्या अद्ययावत (Updated) झाली!");
		} else {
			const empId = currentUser?.email || currentUser?.fullName || currentUser?.id || "admin-001";
			const compName = jobForm.company || currentUser?.fullName || "Company";
			dataStore.createJob({
				employerId: empId,
				title: jobForm.title,
				company: compName,
				category: jobForm.category || "General",
				subcategory: jobForm.subcategory || "",
				description: jobForm.description,
				responsibilities: [],
				requiredSkills: [],
				qualification: jobForm.education,
				experience: jobForm.experience,
				salary: salaryText,
				salaryMin: Number(jobForm.salaryMin) || 0,
				salaryMax: Number(jobForm.salaryMax) || 0,
				salaryType: jobForm.salaryType,
				location: jobForm.location,
				jobType: jobForm.jobType,
				workMode: jobForm.workMode,
				vacancies: Number(jobForm.vacancies) || 1,
				benefits: [],
				status: jobForm.status,
				approvalStatus: "pending"
			});
			toast.success("⏳ नवीन नोकरी सबमिट झाली! सुपर ॲडमिन मंजुरीनंतर (Super Admin approval) ती वेबसाईटवर दिसेल.");
		}
		setShowJobForm(false);
		setEditingJobId(null);
		loadAllData();
	};
	const handleToggleJobStatus = (jobId, currentStatus) => {
		const nextStatus = currentStatus === "Active" ? "Closed" : "Active";
		dataStore.updateJob(jobId, { status: nextStatus });
		loadAllData();
		toast.success(`Job status updated to ${nextStatus}!`);
	};
	const handleDeleteJob = (jobId) => {
		dataStore.deleteJob(jobId);
		loadAllData();
		toast.success("Job posting removed by Admin!");
	};
	const filteredJobs = jobs.filter((j) => j.title.toLowerCase().includes(jobSearch.toLowerCase()) || j.company.toLowerCase().includes(jobSearch.toLowerCase()) || j.location.toLowerCase().includes(jobSearch.toLowerCase()));
	if (showJobForm) {
		const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "fixed inset-0 z-50 bg-[#F0F4FA] overflow-y-auto flex flex-col",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-[#021D3D] text-white px-6 py-4 flex items-center justify-between border-b border-[#0A4F9E] sticky top-0 z-10 shadow-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setShowJobForm(false),
						className: "px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-bold transition-all flex items-center gap-1",
						children: "← मागे जा (Back)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-base font-black text-white",
						children: editingJobId ? "✏️ नोकरीची माहिती संपादीत करा (Edit Job Posting)" : "💼 नवीन नोकरी पोस्ट करा (Post New Job)"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-bold text-[#FFC400] bg-white/10 px-3 py-1 rounded-full",
					children: "100% नि:शुल्क व थेट नोकरी (Zero Commission)"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-5xl w-full mx-auto p-4 sm:p-8 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bg-white rounded-2xl p-4 border border-[#E0E8F5] shadow-sm mb-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between text-xs font-black text-[#063B78]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-5 rounded-full bg-[#063B78] text-white flex items-center justify-center text-[10px]",
									children: "1"
								}), " Basic Details"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[#9DAEC5]",
								children: "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-5 rounded-full bg-[#063B78] text-white flex items-center justify-center text-[10px]",
									children: "2"
								}), " Requirements"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[#9DAEC5]",
								children: "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-5 rounded-full bg-[#063B78] text-white flex items-center justify-center text-[10px]",
									children: "3"
								}), " Salary & Work"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[#9DAEC5]",
								children: "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-5 rounded-full bg-[#063B78] text-white flex items-center justify-center text-[10px]",
									children: "4"
								}), " Preferences"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[#9DAEC5]",
								children: "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-5 rounded-full bg-[#063B78] text-white flex items-center justify-center text-[10px]",
									children: "5"
								}), " Application"]
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handlePublishJob,
					className: "space-y-6 pb-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm overflow-hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 px-5 py-3 bg-[#F8FAFF] border-b border-[#E0E8F5]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-7 rounded-xl bg-[#063B78] text-white flex items-center justify-center text-xs font-black",
									children: "1"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-black text-[#10233F]",
									children: "Basic Job Details"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-5 space-y-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Company Name *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											required: true,
											value: jobForm.company,
											onChange: (e) => setJ("company", e.target.value),
											placeholder: "e.g. Tata Motors / Real Job Platform",
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Job Title *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											required: true,
											value: jobForm.title,
											onChange: (e) => setJ("title", e.target.value),
											placeholder: "e.g. Senior CNC Machine Operator",
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
												children: "Category *"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												required: true,
												list: "categories-list",
												value: jobForm.category,
												onChange: (e) => setJ("category", e.target.value),
												placeholder: "Type or select category...",
												className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("datalist", {
												id: "categories-list",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Manufacturing & Industrial" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Construction & Building" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Healthcare & Nursing" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Logistics & Transport" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Engineering & Technical" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Retail & Sales" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Hotel & Hospitality" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Security & Services" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "IT & Software" })
												]
											})
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
												children: "Subcategory"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												list: "subcategories-list",
												value: jobForm.subcategory,
												onChange: (e) => setJ("subcategory", e.target.value),
												placeholder: "Type or select subcategory...",
												className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("datalist", {
												id: "subcategories-list",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Machine Operator" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Site Supervisor" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Nurse" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Delivery Executive" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Software Developer" })
												]
											})
										] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Location (City/District) *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											required: true,
											value: jobForm.location,
											onChange: (e) => setJ("location", e.target.value),
											placeholder: "e.g. Chakan, Pune / MIDC Kolhapur",
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
										})] })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
										children: "Job Description *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										required: true,
										rows: 3,
										value: jobForm.description,
										onChange: (e) => setJ("description", e.target.value),
										placeholder: "Describe main duties, responsibilities, work schedule, shift timings...",
										className: "w-full p-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
									})] })
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm overflow-hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 px-5 py-3 bg-[#F8FAFF] border-b border-[#E0E8F5]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-7 rounded-xl bg-[#063B78] text-white flex items-center justify-center text-xs font-black",
									children: "2"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-black text-[#10233F]",
									children: "Candidate Requirements"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "p-5 space-y-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
										children: "Education Required *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: jobForm.education,
										onChange: (e) => setJ("education", e.target.value),
										className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "",
												children: "Select Education"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "10th Pass" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "12th Pass" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "ITI Diploma" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Polytechnic Diploma" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Graduate / BE / B.Tech" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Post Graduate" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "No Formal Education Required" })
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
										children: "Experience Required *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: jobForm.experience,
										onChange: (e) => setJ("experience", e.target.value),
										className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "",
												children: "Select Experience"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Fresher (0 Years)" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "1 - 2 Years" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "3 - 5 Years" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "5 - 8 Years" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "8+ Years" })
										]
									})] })]
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm overflow-hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 px-5 py-3 bg-[#F8FAFF] border-b border-[#E0E8F5]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-7 rounded-xl bg-[#063B78] text-white flex items-center justify-center text-xs font-black",
									children: "3"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-black text-[#10233F]",
									children: "Salary & Work Details"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-5 space-y-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Min Salary (₹)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											value: jobForm.salaryMin,
											onChange: (e) => setJ("salaryMin", e.target.value),
											placeholder: "e.g. 18000",
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Max Salary (₹)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											value: jobForm.salaryMax,
											onChange: (e) => setJ("salaryMax", e.target.value),
											placeholder: "e.g. 25000",
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Salary Period"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											value: jobForm.salaryType,
											onChange: (e) => setJ("salaryType", e.target.value),
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "Monthly",
													children: "Per Month (दरमहा)"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "Daily",
													children: "Per Day (दररोज)"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "Yearly",
													children: "Per Year (वार्षिक)"
												})
											]
										})] })
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Job Type *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											value: jobForm.jobType,
											onChange: (e) => setJ("jobType", e.target.value),
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Full Time" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Part Time" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Contract" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Daily Wage" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Internship" })
											]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Work Mode *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											value: jobForm.workMode,
											onChange: (e) => setJ("workMode", e.target.value),
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "On-site" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Work From Home" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Hybrid" })
											]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "No. of Openings *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											required: true,
											type: "number",
											min: "1",
											value: jobForm.vacancies,
											onChange: (e) => setJ("vacancies", e.target.value),
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
										})] })
									]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm overflow-hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 px-5 py-3 bg-[#F8FAFF] border-b border-[#E0E8F5]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-7 rounded-xl bg-[#063B78] text-white flex items-center justify-center text-xs font-black",
									children: "4"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-black text-[#10233F]",
									children: "Preferences & Benefits"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "p-5 space-y-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Gender Preference"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											value: jobForm.genderPreference || "Any",
											onChange: (e) => setJ("genderPreference", e.target.value),
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "Any",
													children: "Any (पुरुष व महिला दोन्ही)"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "Male",
													children: "Male Only (केवळ पुरुष)"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "Female",
													children: "Female Only (केवळ महिला)"
												})
											]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Age Limit (Optional)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "number",
													value: jobForm.ageMin || "",
													onChange: (e) => setJ("ageMin", e.target.value),
													placeholder: "Min Age",
													className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold focus:outline-none focus:border-[#063B78]"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[#9DAEC5] font-bold shrink-0",
													children: "–"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "number",
													value: jobForm.ageMax || "",
													onChange: (e) => setJ("ageMax", e.target.value),
													placeholder: "Max Age",
													className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold focus:outline-none focus:border-[#063B78]"
												})
											]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Languages Required"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: jobForm.languages || "",
											onChange: (e) => setJ("languages", e.target.value),
											placeholder: "e.g. English, Hindi, Marathi",
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
										})] })
									]
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white rounded-2xl border border-[#E0E8F5] shadow-sm overflow-hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 px-5 py-3 bg-[#F8FAFF] border-b border-[#E0E8F5]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-7 rounded-xl bg-[#063B78] text-white flex items-center justify-center text-xs font-black",
									children: "5"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-black text-[#10233F]",
									children: "Application Details"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "p-5 space-y-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-4 gap-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Application Deadline *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											required: true,
											type: "date",
											min: today,
											value: jobForm.deadline || "",
											onChange: (e) => setJ("deadline", e.target.value),
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Application Method *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											value: jobForm.applicationMethod || "",
											onChange: (e) => setJ("applicationMethod", e.target.value),
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "",
													children: "Select Method"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Apply via Portal" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Apply via WhatsApp" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Walk-in Interview" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Call to Apply" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Email CV" })
											]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Recruiter Email *"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "email",
											value: jobForm.recruiterEmail || "",
											onChange: (e) => setJ("recruiterEmail", e.target.value),
											placeholder: "e.g. recruiter@company.com",
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-black text-[#5B6B7F] uppercase mb-1.5",
											children: "Recruiter Phone (Optional)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "tel",
											value: jobForm.recruiterPhone || "",
											onChange: (e) => setJ("recruiterPhone", e.target.value),
											placeholder: "e.g. 98765 43210",
											className: "w-full h-9 px-3 rounded-xl border border-[#DCE5F0] text-xs font-semibold text-[#10233F] focus:outline-none focus:border-[#063B78]"
										})] })
									]
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white rounded-2xl border border-[#E0E8F5] px-6 py-4 flex items-center justify-between sticky bottom-0 shadow-lg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-[#9DAEC5] font-semibold",
								children: "* Required fields must be filled before submitting"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setShowJobForm(false),
									className: "px-5 py-2.5 rounded-xl border border-[#DCE5F0] text-xs font-bold text-[#5B6B7F] hover:bg-[#F5F8FC] transition-all",
									children: "रद्द करा (Cancel)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									className: "px-7 py-2.5 rounded-xl bg-gradient-to-r from-[#063B78] to-[#0A4F9E] text-white font-black text-xs hover:opacity-90 transition-all shadow-md shadow-[#063B78]/20 flex items-center gap-1.5",
									children: editingJobId ? "✦ माहिती अद्ययावत करा (Update Job)" : "✦ नोकरी प्रकाशित करा (Publish Job)"
								})]
							})]
						})
					]
				})]
			})]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-[#F0F4FA]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "sticky top-0 z-40 bg-gradient-to-r from-[#021D3D] via-[#063B78] to-[#0A4F9E] text-white shadow-xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-0.5 w-full bg-gradient-to-r from-[#FFC400] via-[#FFD84D] to-[#FFA500]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col items-center justify-center size-10 rounded-xl bg-white shadow-md shrink-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[9px] font-black text-[#063B78] leading-none",
								children: "REAL"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[9px] font-black text-[#FFC400] leading-none",
								children: "JOB"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hidden sm:block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-black text-white leading-tight",
								children: "REAL JOB"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5 text-[10px] font-bold text-[#FFC400]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3" }), "ॲडमिन कंट्रोल पोर्टल"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hidden md:block w-px h-8 bg-white/20 mx-2" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 border border-white/20 text-[10px] font-black text-white",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-emerald-400 animate-pulse" }), "Super Admin Control"]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 sm:gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "ghost",
						size: "sm",
						className: "hidden sm:flex border border-white/30 text-white hover:bg-white/15 font-bold text-xs h-8 px-3 rounded-lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/home",
							children: "🌐 मुख्य साईट"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => {
							window.localStorage.removeItem("realjob-user");
							dataStore.setCurrentUser(null);
							toast.info("Logged out from Admin Dashboard");
							window.location.href = "/";
						},
						size: "sm",
						className: "bg-red-500 hover:bg-red-600 text-white font-extrabold text-xs h-8 px-3 rounded-lg shadow-md",
						children: "लॉग आउट"
					})]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-[#DCE5F0] shadow-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-2 rounded-full bg-[#063B78]/10 px-3 py-1 text-xs font-black text-[#063B78] mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-emerald-500 animate-pulse" }), "REAL JOB PLATFORM SYSTEM ONLINE"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-2xl sm:text-3xl font-black text-[#10233F]",
							children: "ॲडमिन कंट्रोल सेंटर (Admin Control Dashboard)"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs sm:text-sm font-semibold text-[#5B6B7F] mt-1",
							children: "कामकूट, नवीन नोकऱ्या, कामगार पडताळणी आणि अर्ज व्यवस्थापन नियंत्रण करा."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: handleAddNewJobClick,
							className: "btn-yellow text-xs font-black px-4 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 mr-1" }), " नवीन जॉब जोडा (Add New Job)"]
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap items-center gap-2 mb-8 pb-3 border-b border-[#DCE5F0]",
					children: [
						{
							id: "overview",
							label: "सारांश (Overview)",
							icon: ChartColumn
						},
						{
							id: "jobs",
							label: "नोकरी पोस्टिंग्स (Jobs)",
							icon: BriefcaseBusiness
						},
						{
							id: "applications",
							label: `अर्ज आलेले कामगार (${applications.length})`,
							icon: FileText
						}
					].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setActiveTab(t.id),
						className: `flex items-center gap-2 px-4 py-2.5 rounded-xl font-extrabold text-xs transition-all ${activeTab === t.id ? "bg-[#063B78] text-white shadow-md shadow-[#063B78]/20" : "bg-white text-[#5B6B7F] border border-[#DCE5F0] hover:bg-[#EBF1F8] hover:text-[#063B78]"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(t.icon, { className: "size-4 shrink-0" }), t.label]
					}, t.id))
				}),
				activeTab === "overview" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
								label: "एकूण नोंदणीकृत कामगार (Total Registered Workers)",
								value: registeredUsers.filter((u) => u.role === "worker").length.toString(),
								change: "थेट नोंदणीकृत कामगार",
								icon: Users
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
								label: "सक्रिय नोकऱ्या (Active Jobs)",
								value: jobs.filter((j) => j.status === "Active").length.toString(),
								change: "थेट प्लॅटफॉर्मवर",
								icon: BriefcaseBusiness
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
								label: "एकूण आलेले अर्ज (Total Applications)",
								value: applications.length.toString(),
								change: "थेट कामगारांचे अर्ज",
								icon: FileText
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-6 lg:grid-cols-[1.4fr_1fr]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-[#DCE5F0] bg-white p-6 shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-lg font-black text-[#10233F]",
									children: "प्लॅटफॉर्म वाढ आणि नोकरी अर्ज (Platform Growth & Applications)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold text-[#5B6B7F]",
									children: "महिनानिहाय कामगार नोंदणी आणि भरती डेटा"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									className: "bg-[#063B78] text-white font-bold",
									children: "2026 Live"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-72",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
									width: "100%",
									height: "100%",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
										data: monthlyAnalytics,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("defs", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
												id: "colorWorkers",
												x1: "0",
												y1: "0",
												x2: "0",
												y2: "1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "5%",
													stopColor: "#063B78",
													stopOpacity: .8
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "95%",
													stopColor: "#063B78",
													stopOpacity: 0
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
												id: "colorJobs",
												x1: "0",
												y1: "0",
												x2: "0",
												y2: "1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "5%",
													stopColor: "#FFC400",
													stopOpacity: .8
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "95%",
													stopColor: "#FFC400",
													stopOpacity: 0
												})]
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
												strokeDasharray: "3 3",
												vertical: false
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, { dataKey: "month" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
												type: "monotone",
												dataKey: "workers",
												stroke: "#063B78",
												fillOpacity: 1,
												fill: "url(#colorWorkers)",
												name: "Workers"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
												type: "monotone",
												dataKey: "jobs",
												stroke: "#FFC400",
												fillOpacity: 1,
												fill: "url(#colorJobs)",
												name: "Jobs"
											})
										]
									})
								})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-[#DCE5F0] bg-white p-6 shadow-sm space-y-6 flex flex-col justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-lg font-black text-[#10233F]",
								children: "त्वरित कृती (Quick Controls)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold text-[#5B6B7F] mt-1",
								children: "जॉब लिस्ट व अर्जांचे नियंत्रण करण्यासाठी खालील बटन्स वापरा."
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										onClick: handleAddNewJobClick,
										className: "w-full btn-yellow text-xs font-black py-3",
										children: "+ नवीन जॉब पोस्ट करा (Post New Job)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										onClick: () => setActiveTab("jobs"),
										variant: "outline",
										className: "w-full border-[#063B78] text-[#063B78] font-bold text-xs py-3",
										children: "💼 सर्व जॉब पोस्टिंग्स नियंत्रण"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										onClick: () => setActiveTab("applications"),
										variant: "outline",
										className: "w-full border-[#063B78] text-[#063B78] font-bold text-xs py-3",
										children: [
											"📄 आलेले सर्व कामगार अर्ज पहा (",
											applications.length,
											")"
										]
									})
								]
							})]
						})]
					})]
				}),
				activeTab === "jobs" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white p-6 rounded-2xl border border-[#DCE5F0] shadow-sm space-y-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-black text-[#10233F]",
							children: "नोकरी पोस्टिंग्स नियंत्रण (All Platform Job Listings)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-semibold text-[#5B6B7F]",
							children: [
								"एकूण ",
								jobs.length,
								" नोकऱ्या उपलब्ध आहेत. माहिती अपडेट करा किंवा डिलीट करा."
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "w-full sm:w-72 relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-3 size-4 text-[#5B6B7F]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "नोकरी / कंपनी / शहर शोधा...",
								value: jobSearch,
								onChange: (e) => setJobSearch(e.target.value),
								className: "pl-9 text-xs font-bold"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto rounded-xl border border-[#DCE5F0]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-left text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "bg-[#063B78] text-white font-black uppercase",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5",
										children: "नोकरी शीर्षक (Title)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5",
										children: "कंपनी (Company)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5",
										children: "ठिकाण & पगार (Location & Salary)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5",
										children: "जागा (Vacancies)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5",
										children: "मंजुरी (Approval)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5",
										children: "स्थिती (Status)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5 text-right",
										children: "कृती (Actions)"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
								className: "divide-y divide-[#DCE5F0] font-semibold text-[#10233F]",
								children: [filteredJobs.map((j) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "hover:bg-[#F5F8FC]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "p-3.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "block font-black text-[#063B78]",
												children: j.title
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[11px] text-[#5B6B7F]",
												children: j.category
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3.5 font-bold",
											children: j.company
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "p-3.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: j.location }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[#125BB5] font-bold",
												children: j.salary
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "p-3.5 font-black text-[#063B78]",
											children: [j.vacancies || 5, " Openings"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3.5",
											children: j.approvalStatus === "rejected" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												className: "bg-red-600 text-white font-bold",
												children: "❌ Rejected"
											}) : j.approvalStatus === "approved" || !j.approvalStatus ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												className: "bg-emerald-600 text-white font-bold",
												children: "✅ Approved"
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												className: "bg-amber-500 text-white font-bold",
												children: "⏳ Pending Approval"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												className: j.status === "Active" ? "bg-emerald-600 text-white font-bold" : "bg-gray-500 text-white font-bold",
												children: j.status
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3.5 text-right",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-end gap-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
														size: "sm",
														onClick: () => {
															setFilterJobId(j.id);
															setActiveTab("applications");
														},
														className: "bg-[#063B78] text-white font-extrabold text-[11px] hover:bg-[#0A4F9E]",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-3.5 mr-1" }),
															"अर्ज पहा (",
															applications.filter((a) => a.jobId === j.id).length,
															")"
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
														size: "sm",
														variant: "outline",
														onClick: () => handleEditJobClick(j),
														className: "font-extrabold text-[11px] border-[#063B78] text-[#063B78] hover:bg-[#F0F5FF]",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquarePen, { className: "size-3.5 mr-1" }), " एडिट (Edit)"]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														size: "sm",
														variant: "outline",
														onClick: () => handleToggleJobStatus(j.id, j.status),
														className: "font-extrabold text-[11px] border-gray-400 text-gray-700",
														children: j.status === "Active" ? "बंद करा (Close)" : "सुरू करा (Activate)"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														size: "sm",
														variant: "ghost",
														onClick: () => handleDeleteJob(j.id),
														className: "text-red-600 hover:bg-red-50",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
													})
												]
											})
										})
									]
								}, j.id)), filteredJobs.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									colSpan: 6,
									className: "p-8 text-center text-xs font-bold text-[#5B6B7F] bg-[#F8FAFF]",
									children: "अद्याप एकही नोकरी पोस्ट केलेली नाही. (No jobs posted yet)"
								}) })]
							})]
						})
					})]
				}),
				activeTab === "applications" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white p-6 rounded-2xl border border-[#DCE5F0] shadow-sm space-y-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-black text-[#10233F]",
							children: "नोकरीसाठी आलेले अर्ज (Job Applications & Applicants)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-semibold text-[#5B6B7F]",
							children: [
								"एकूण ",
								applications.length,
								" कामगारांनी नोकरीसाठी अर्ज केले आहेत. थेट संपर्क करा किंवा स्थिती बदला."
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-3 w-full sm:w-auto",
							children: [filterJobId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => setFilterJobId(null),
								className: "text-xs font-bold border-[#063B78] text-[#063B78]",
								children: "✕ सर्व जॉब्जचे अर्ज दाखवा"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "w-full sm:w-64 relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-3 size-4 text-[#5B6B7F]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "उमेदवार नाव / नोकरी / संपर्क शोधा...",
									value: appSearch,
									onChange: (e) => setAppSearch(e.target.value),
									className: "pl-9 text-xs font-bold"
								})]
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto rounded-xl border border-[#DCE5F0]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-left text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "bg-[#063B78] text-white font-black uppercase",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5",
										children: "उमेदवार नाव (Applicant Name)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5",
										children: "अर्ज केलेली नोकरी (Applied Job)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5",
										children: "संपर्क पर्याय (Direct Contact)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5",
										children: "अर्जाची तारीख (Applied Date)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5",
										children: "सध्याची स्थिती (Status)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-3.5 text-right",
										children: "तपशील (Details)"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
								className: "divide-y divide-[#DCE5F0] font-semibold text-[#10233F]",
								children: [applications.filter((a) => !filterJobId || a.jobId === filterJobId).filter((a) => a.candidateName.toLowerCase().includes(appSearch.toLowerCase()) || a.jobTitle.toLowerCase().includes(appSearch.toLowerCase()) || a.candidateMobile.toLowerCase().includes(appSearch.toLowerCase())).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "hover:bg-[#F5F8FC]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "p-3.5 font-black text-[#063B78]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: a.candidateName }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[11px] text-[#5B6B7F] font-normal",
												children: a.candidateEmail
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "p-3.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "font-bold text-[#10233F]",
												children: a.jobTitle
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-[11px] text-[#125BB5]",
												children: [
													a.companyName || "Company",
													" • ",
													a.location
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: `tel:${formatCallNumber(a.candidateMobile)}`,
													className: "px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold text-[10px] hover:bg-emerald-700 transition-all flex items-center gap-1",
													children: "📞 कॉल करा"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: `https://wa.me/${formatWaNumber(a.candidateMobile)}?text=${encodeURIComponent(`नमस्कार ${a.candidateName}, तुम्ही ${a.jobTitle} या नोकरीसाठी अर्ज केला होता. त्यासंदर्भात संपर्क करत आहोत.`)}`,
													target: "_blank",
													rel: "noreferrer",
													className: "px-2.5 py-1 rounded-lg bg-green-600 text-white font-bold text-[10px] hover:bg-green-700 transition-all flex items-center gap-1",
													children: "💬 WhatsApp"
												})]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3.5 text-[#5B6B7F] font-bold",
											children: a.appliedDate
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
												value: a.status,
												onChange: (e) => handleUpdateAppStatus(a.id, e.target.value),
												className: "h-8 px-2 rounded-lg border border-[#DCE5F0] text-xs font-black focus:outline-none focus:border-[#063B78]",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "Applied",
														children: "📝 Applied"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "Viewed",
														children: "👀 Viewed"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "Shortlisted",
														children: "⭐ Shortlisted"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "Interview",
														children: "📅 Interview Scheduled"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "Selected",
														children: "✅ Selected / Hired"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "Rejected",
														children: "❌ Rejected"
													})
												]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3.5 text-right",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												variant: "outline",
												size: "sm",
												onClick: () => setExpandedApp(expandedApp === a.id ? null : a.id),
												className: "text-[10px] h-7 px-3 border-[#063B78] text-[#063B78] hover:bg-[#063B78] hover:text-white",
												children: expandedApp === a.id ? "बंद करा" : "सविस्तर पहा"
											})
										})
									]
								}), expandedApp === a.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
									className: "bg-[#F8FAFC]",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										colSpan: 6,
										className: "p-4 border-t border-[#DCE5F0]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-white p-5 rounded-xl border border-[#E2E8F0] shadow-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
												className: "font-bold text-[#10233F] mb-4 border-b pb-2 flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4 text-[#063B78]" }), "उमेदवाराची सविस्तर माहिती (Candidate Details)"]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5",
												children: [
													a.fieldValues && Object.entries(a.fieldValues).map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "text-xs bg-[#F5F8FC] p-3 rounded-lg border border-[#DCE5F0]",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "font-bold text-[#5B6B7F] capitalize mb-1",
															children: key.replace(/([A-Z])/g, " $1").trim()
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "font-black text-[#10233F]",
															children: value
														})]
													}, key)),
													a.customAnswers && Object.entries(a.customAnswers).map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "text-xs bg-[#F5F8FC] p-3 rounded-lg border border-[#DCE5F0]",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "font-bold text-[#5B6B7F] capitalize mb-1",
															children: key
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "font-black text-[#10233F]",
															children: value
														})]
													}, key)),
													!a.fieldValues && !a.customAnswers && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-sm font-semibold text-[#5B6B7F]",
														children: "अधिक माहिती उपलब्ध नाही."
													})
												]
											})]
										})
									})
								})] }, a.id)), applications.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									colSpan: 6,
									className: "p-8 text-center text-xs font-bold text-[#5B6B7F] bg-[#F8FAFF]",
									children: "अद्याप कोणत्याही कामगाराने अर्ज केलेला नाही (No job applications received yet)"
								}) })]
							})]
						})
					})]
				})
			]
		})]
	});
}
//#endregion
export { AdminDashboardPage as component };
