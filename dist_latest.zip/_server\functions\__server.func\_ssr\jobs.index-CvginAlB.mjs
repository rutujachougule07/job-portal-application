import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/jobs.index-CvginAlB.js
var $$splitComponentImporter = () => import("./jobs.index-Dttflm44.mjs");
var Route = createFileRoute("/jobs/")({
	validateSearch: (search) => {
		return { category: typeof search["category"] === "string" ? search["category"] : void 0 };
	},
	head: () => ({ meta: [{ title: "Find Jobs — REAL JOB | Find Work | Find Workers" }, {
		name: "description",
		content: "Browse verified factory, construction, driver, ITI and technical jobs across Maharashtra and India."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
