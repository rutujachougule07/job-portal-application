import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-D75Utr34.js
var $$splitComponentImporter = () => import("./dashboard-V_CwrCvv.mjs");
var Route = createFileRoute("/dashboard")({
	validateSearch: (search) => {
		return { tab: search["tab"] };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
