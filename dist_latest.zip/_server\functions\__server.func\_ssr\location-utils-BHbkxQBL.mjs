import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { $t as Calendar, Ht as CircleX, Mt as Download, c as User, et as LoaderCircle, i as Wallet, rn as Building2, zt as Clock } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/location-utils-BHbkxQBL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SalarySlip = ({ companyName = "REAL JOB Construction Pvt. Ltd.", companyAddress = "MIDC Industrial Area, Pune, Maharashtra 411026", companyTagline = "Building Better Opportunities", companyLogo, employeeName = "Ramesh Shinde", employeeId = "RJW-000123", employeePhoto, mobile = "9876543210", designation = "Helper", department = "Construction", location = "Site - Pune", joiningDate = "01-08-2026", bankAccountNo = "123456789012", bankName = "State Bank of India", branch = "Pune", month = "October", year = "2026", payPeriod, totalDaysInMonth = 31, presentDays, absentDays, halfDays, weeklyOffDays, publicHolidays, dailyRate = 600, basicSalary, da, hra, conveyance = 0, medicalAllowance = 0, specialAllowance = 0, otherAllowance = 0, overtimeHours = 0, overtimeRate = 150, overtimePay, providentFund = 0, esi = 0, professionalTax = 0, incomeTax = 0, otherDeductions = 0, uanNo = "123456789012", esicNo = "520012345678", leaveEntitlement = 12, leaveAvailed, leaveBalance, absentDatesText, halfDayDatesText, overtimeDatesText, overtimeEntries, totalWorkHours, totalEarningsDays, attendanceGrid }) => {
	const containerRef = (0, import_react.useRef)(null);
	const computedTotalDays = totalDaysInMonth || 31;
	const computedPresent = presentDays !== void 0 ? presentDays : 0;
	const computedAbsent = absentDays !== void 0 ? absentDays : 0;
	const computedHalfDays = halfDays !== void 0 ? halfDays : 0;
	const computedWeeklyOff = weeklyOffDays !== void 0 ? weeklyOffDays : 4;
	const computedHoliday = publicHolidays !== void 0 ? publicHolidays : 0;
	const computedBasic = basicSalary !== void 0 && basicSalary > 0 ? basicSalary : computedPresent * (dailyRate || 600);
	const computedOtherAllowance = otherAllowance || conveyance + medicalAllowance + specialAllowance;
	const computedOtPay = overtimePay !== void 0 ? overtimePay : overtimeHours * overtimeRate;
	const totalEarnings = computedBasic + computedOtPay + (computedOtherAllowance > 0 ? computedOtherAllowance : 0);
	const netPay = Math.max(0, totalEarnings - (otherDeductions || 0));
	const mNum = {
		January: "01",
		February: "02",
		March: "03",
		April: "04",
		May: "05",
		June: "06",
		July: "07",
		August: "08",
		September: "09",
		October: "10",
		November: "11",
		December: "12"
	}[month] || (month.length <= 2 ? month.padStart(2, "0") : "10");
	const resolvedPayPeriod = payPeriod || `01-${mNum}-${year} to ${computedTotalDays}-${mNum}-${year}`;
	const computedWorkHours = totalWorkHours !== void 0 && totalWorkHours > 0 ? totalWorkHours : computedPresent * 8 + Math.round(computedHalfDays * 4) + (overtimeHours || 0);
	const computedEarningsDays = totalEarningsDays !== void 0 ? totalEarningsDays : computedPresent + computedWeeklyOff + computedHoliday + (computedHalfDays > 0 ? computedHalfDays * .5 : 0);
	leaveBalance !== void 0 || Math.max(0, leaveEntitlement - (leaveAvailed !== void 0 ? leaveAvailed : computedAbsent));
	const resolvedAbsentText = absentDatesText !== void 0 ? absentDatesText : computedAbsent > 0 ? `(${computedAbsent} days absent)` : "No absent days recorded";
	const resolvedHalfDayText = halfDayDatesText !== void 0 ? halfDayDatesText : computedHalfDays > 0 ? `(${computedHalfDays} half days)` : "No half days recorded";
	const resolvedOvertimeText = overtimeDatesText !== void 0 ? overtimeDatesText : overtimeEntries && overtimeEntries.length > 0 ? overtimeEntries.map((e) => `${String(e.day).padStart(2, "0")} ${month.slice(0, 3)} (${e.overtimeHours}h OT)`).join(", ") : overtimeHours > 0 ? `${overtimeHours} hrs total` : "";
	const resolvedAttendanceGrid = attendanceGrid || (() => {
		const daysArr = [];
		const weekdays = [
			"Sun",
			"Mon",
			"Tue",
			"Wed",
			"Thu",
			"Fri",
			"Sat"
		];
		const yNum = parseInt(year, 10) || (/* @__PURE__ */ new Date()).getFullYear();
		const mIdx = parseInt(mNum, 10) - 1;
		for (let d = 1; d <= computedTotalDays; d++) {
			const dateObj = new Date(yNum, mIdx, d);
			const wd = weekdays[dateObj.getDay()] || "Mon";
			const isSun = dateObj.getDay() === 0;
			let status = "-";
			if (isSun) status = "WO";
			daysArr.push({
				day: d,
				weekday: wd,
				status
			});
		}
		return daysArr;
	})();
	const [isDownloading, setIsDownloading] = (0, import_react.useState)(false);
	const handleDownload = async () => {
		const element = document.getElementById("salary-slip-content");
		if (!element) {
			toast.error("Salary slip element not found");
			return;
		}
		const fileName = `Salary_Slip_${(employeeName || "Employee").replace(/[^\w\s-]/g, "").trim().replace(/\s+/g, "_")}_${month || "Payroll"}_${year || "2026"}.pdf`;
		try {
			setIsDownloading(true);
			toast.info("Generating Salary Slip PDF...");
			const { toPng } = await import("../_libs/html-to-image.mjs").then((n) => n.t);
			const { jsPDF } = await import("../_libs/jspdf.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			const dataUrl = await toPng(element, {
				quality: 1,
				pixelRatio: 2,
				backgroundColor: "#ffffff",
				skipFonts: true,
				imagePlaceholder: "data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"1\" height=\"1\"/>",
				style: {
					margin: "0",
					boxShadow: "none"
				}
			});
			const pdf = new jsPDF({
				orientation: "portrait",
				unit: "mm",
				format: "a4",
				compress: true
			});
			const pageWidth = pdf.internal.pageSize.getWidth();
			const pageHeight = pdf.internal.pageSize.getHeight();
			const margin = 5;
			const printableWidth = pageWidth - 10;
			const printableHeight = pageHeight - 10;
			const imgProps = pdf.getImageProperties(dataUrl);
			const renderedHeight = imgProps.height * printableWidth / imgProps.width;
			if (renderedHeight <= printableHeight) pdf.addImage(dataUrl, "PNG", margin, margin, printableWidth, renderedHeight, void 0, "FAST");
			else if (renderedHeight <= printableHeight * 1.25) {
				const scaledWidth = printableWidth * (printableHeight / renderedHeight);
				const xOffset = margin + (printableWidth - scaledWidth) / 2;
				pdf.addImage(dataUrl, "PNG", xOffset, margin, scaledWidth, printableHeight, void 0, "FAST");
			} else {
				let heightLeft = renderedHeight;
				let position = margin;
				pdf.addImage(dataUrl, "PNG", margin, position, printableWidth, renderedHeight, void 0, "FAST");
				heightLeft -= printableHeight;
				while (heightLeft > 0) {
					position = position - printableHeight;
					pdf.addPage();
					pdf.addImage(dataUrl, "PNG", margin, position, printableWidth, renderedHeight, void 0, "FAST");
					heightLeft -= printableHeight;
				}
			}
			pdf.save(fileName);
			toast.success(`Salary Slip downloaded: ${fileName}`);
		} catch (err) {
			console.error("PDF download error:", err);
			toast.error("PDF तयार करताना अडचण आली. कृपया पुन्हा प्रयत्न करा.");
		} finally {
			setIsDownloading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full max-w-4xl mx-auto p-2 sm:p-4 text-slate-900 font-sans",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "print:hidden flex items-center justify-between gap-3 mb-4 bg-white p-3.5 rounded-2xl border border-slate-200 shadow-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-5 text-[#063B78]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "text-xs font-black text-[#10233F] leading-tight",
					children: companyName
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[10px] text-slate-500 font-bold",
					children: [
						"Official Employee Payslip • ",
						month,
						" ",
						year
					]
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center gap-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: isDownloading,
					onClick: handleDownload,
					className: "flex items-center gap-1.5 px-4 py-2 bg-[#063B78] hover:bg-[#082F63] disabled:opacity-60 text-white rounded-xl text-xs font-black shadow-md transition-all cursor-pointer",
					title: "Download PDF Salary Slip",
					children: isDownloading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
						size: 14,
						className: "animate-spin"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Downloading..." })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { size: 14 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Download PDF" })] })
				})
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			id: "salary-slip-content",
			ref: containerRef,
			className: "bg-white rounded-2xl shadow-xl border border-slate-300 p-4 sm:p-6 space-y-4 max-w-[800px] mx-auto text-slate-800 overflow-hidden relative print:p-2 print:border-none print:shadow-none",
			style: { fontFamily: "'Inter', system-ui, -apple-system, sans-serif" },
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative rounded-2xl overflow-hidden border border-slate-300 bg-gradient-to-r from-[#FFFFFF] via-[#F4F8FD] to-[#EBF3FC] p-3.5 sm:p-4 flex items-center justify-between min-h-[96px] gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 z-10 flex-1 min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-14 sm:size-16 rounded-2xl bg-[#063B78] flex items-center justify-center p-1.5 shadow-md border-2 border-[#FFC400] shrink-0",
							children: companyLogo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: companyLogo,
								alt: companyName,
								className: "w-full h-full object-contain",
								onError: (e) => {
									e.target.style.display = "none";
								}
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-8 text-[#FFC400]" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "text-2xl sm:text-3xl font-black text-[#063B78] tracking-tight uppercase leading-tight truncate",
									children: companyName || "COMPANY NAME"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] sm:text-xs font-black uppercase text-slate-600 tracking-wider leading-tight mt-0.5",
									children: companyTagline || "EMPLOYMENT & CONTRACTOR SERVICES"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[9px] sm:text-[10px] text-slate-500 font-bold truncate mt-0.5 leading-tight",
									children: companyAddress || "Safe Work • Secure Future • Better Tomorrow"
								})
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 flex flex-col items-end shrink-0 pl-3 border-l border-slate-200",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[9px] font-black uppercase tracking-widest text-slate-400",
								children: "Powered by"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1 mt-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-base sm:text-lg font-black text-[#063B78] tracking-tight",
									children: "REAL"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-base sm:text-lg font-black text-[#FFC400] tracking-tight",
									children: "JOB"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[8px] font-bold text-slate-400",
								children: "India"
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-[#063B78] text-white rounded-xl px-4 py-2.5 flex flex-col sm:flex-row items-center justify-between gap-2 shadow-sm border border-blue-900",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-6 rounded-md bg-white/15 flex items-center justify-center text-white shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, {
								size: 14,
								className: "text-[#FFC400]"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-sm sm:text-base font-black tracking-wider uppercase text-white",
							children: "EMPLOYEE PAYSLIP"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4 text-xs font-bold text-white/90",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, {
									size: 13,
									className: "text-[#FFC400]"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Month : ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
									className: "text-white font-black",
									children: [
										month,
										" ",
										year
									]
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline text-white/40",
								children: "|"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] sm:text-xs",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Pay Period : ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-white font-black",
									children: resolvedPayPeriod
								})] })
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-3.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-slate-300 bg-white p-3.5 shadow-2xs space-y-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 border-b border-slate-200 pb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-6 rounded-full bg-[#063B78] text-white flex items-center justify-center shrink-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { size: 13 })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-xs font-black uppercase text-[#063B78] tracking-wider",
								children: "Employee Details"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1.5 text-[11px] leading-snug",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-12",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-5 text-slate-500 font-semibold",
											children: "Name"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-1 text-slate-400 font-bold",
											children: ":"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-6 font-black text-[#10233F] truncate",
											children: employeeName
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-12",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-5 text-slate-500 font-semibold",
											children: "Mobile No."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-1 text-slate-400 font-bold",
											children: ":"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-6 font-bold text-slate-800",
											children: mobile
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-12",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-5 text-slate-500 font-semibold",
											children: "Designation"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-1 text-slate-400 font-bold",
											children: ":"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-6 font-bold text-slate-800",
											children: designation
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-12",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-5 text-slate-500 font-semibold",
											children: "Department"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-1 text-slate-400 font-bold",
											children: ":"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-6 font-bold text-slate-800",
											children: department
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-12",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-5 text-slate-500 font-semibold",
											children: "Location"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-1 text-slate-400 font-bold",
											children: ":"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-6 font-bold text-slate-800",
											children: location
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-12",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-5 text-slate-500 font-semibold",
											children: "Joining Date"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-1 text-slate-400 font-bold",
											children: ":"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-6 font-bold text-slate-800",
											children: joiningDate
										})
									]
								})
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-slate-300 bg-white p-3.5 shadow-2xs space-y-2.5 flex flex-col justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-b border-slate-200 pb-2 flex items-start gap-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-8 rounded-xl bg-[#063B78] text-white flex items-center justify-center shrink-0 shadow-xs",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { size: 16 })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-black text-[#063B78] truncate leading-tight",
									children: companyName
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-slate-500 font-semibold truncate leading-tight mt-0.5",
									children: companyTagline || companyAddress
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-[11px] space-y-1 leading-snug",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-12 py-0.5 border-b border-slate-100",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-8 text-slate-600 font-semibold",
											children: "Total Days in Month"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-1 text-slate-400 font-bold",
											children: ":"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-3 text-right font-black text-slate-900",
											children: computedTotalDays
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-12 py-0.5 border-b border-slate-100",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-8 text-slate-600 font-semibold",
											children: "Present Days"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-1 text-slate-400 font-bold",
											children: ":"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-3 text-right font-black text-emerald-700",
											children: computedPresent
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-12 py-0.5 border-b border-slate-100",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-8 text-slate-600 font-semibold",
											children: "Absent Days"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-1 text-slate-400 font-bold",
											children: ":"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-3 text-right font-black text-rose-600",
											children: computedAbsent
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-12 py-0.5 border-b border-slate-100",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-8 text-slate-600 font-semibold",
											children: "Half Day"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-1 text-slate-400 font-bold",
											children: ":"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-3 text-right font-black text-amber-600",
											children: computedHalfDays
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-12 py-0.5 border-b border-slate-100",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-8 text-slate-600 font-semibold",
											children: "Weekly Off"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-1 text-slate-400 font-bold",
											children: ":"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-3 text-right font-black text-sky-700",
											children: computedWeeklyOff
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-12 py-0.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-8 text-slate-600 font-semibold",
											children: "Public Holiday"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-1 text-slate-400 font-bold",
											children: ":"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "col-span-3 text-right font-black text-slate-700",
											children: computedHoliday
										})
									]
								})
							]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-slate-300 overflow-hidden bg-white shadow-2xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-[#063B78] text-white px-3.5 py-1.5 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, {
							size: 13,
							className: "text-[#FFC400]"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "text-xs font-black uppercase tracking-wider text-white",
							children: [
								"ATTENDANCE DETAILS (",
								payPeriod ? payPeriod : `${month} ${year}`,
								")"
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-2 sm:p-2.5 overflow-x-auto",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "min-w-[500px] space-y-1",
							children: resolvedAttendanceGrid.length <= 16 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap items-center justify-center gap-1.5 text-center py-1",
								children: resolvedAttendanceGrid.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col items-center min-w-[32px] sm:min-w-[36px]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-black text-slate-700",
											children: item.day
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[9px] font-bold text-slate-500 leading-none mb-1",
											children: item.weekday
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `size-6 rounded-md flex items-center justify-center text-[10px] font-black shadow-2xs ${item.status === "P" ? "bg-[#8CE0A7] text-[#0A5726] border border-[#64CF87]" : item.status === "WO" ? "bg-[#A2D4F8] text-[#064A7E] border border-[#78BFF4]" : item.status === "A" ? "bg-[#FCA5A5] text-[#991B1B] border border-[#F87171]" : item.status === "HD" ? "bg-[#C084FC] text-[#581C87] border border-[#A855F7]" : item.status === "OT" ? "bg-[#DDD6FE] text-[#6D28D9] border border-[#A78BFA]" : "bg-slate-100 text-slate-400 border border-slate-300"}`,
											children: item.status
										})
									]
								}, item.day))
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-16 gap-1 text-center",
								children: resolvedAttendanceGrid.slice(0, 16).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col items-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-black text-slate-700",
											children: item.day
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[9px] font-bold text-slate-500 leading-none mb-1",
											children: item.weekday
										}),
										item.status === "OT" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "size-6 rounded-md flex flex-col items-center justify-center bg-[#8CE0A7] text-[#0A5726] border border-[#64CF87] shadow-2xs relative",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[9px] font-black leading-none",
												children: "P"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[6px] font-black text-white bg-[#7C3AED] px-1 rounded-xs -mt-0.5 leading-tight",
												children: "OT"
											})]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `size-6 rounded-md flex items-center justify-center text-[10px] font-black shadow-2xs ${item.status === "P" ? "bg-[#8CE0A7] text-[#0A5726] border border-[#64CF87]" : item.status === "WO" ? "bg-[#A2D4F8] text-[#064A7E] border border-[#78BFF4]" : item.status === "A" ? "bg-[#FCA5A5] text-[#991B1B] border border-[#F87171]" : item.status === "HD" ? "bg-[#C084FC] text-[#581C87] border border-[#A855F7]" : "bg-slate-100 text-slate-400 border border-slate-300"}`,
											children: item.status
										})
									]
								}, item.day))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-16 gap-1 text-center pt-1.5 border-t border-slate-100",
								children: [resolvedAttendanceGrid.slice(16).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col items-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-black text-slate-700",
											children: item.day
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[9px] font-bold text-slate-500 leading-none mb-1",
											children: item.weekday
										}),
										item.status === "OT" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "size-6 rounded-md flex flex-col items-center justify-center bg-[#8CE0A7] text-[#0A5726] border border-[#64CF87] shadow-2xs relative",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[9px] font-black leading-none",
												children: "P"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[6px] font-black text-white bg-[#7C3AED] px-1 rounded-xs -mt-0.5 leading-tight",
												children: "OT"
											})]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `size-6 rounded-md flex items-center justify-center text-[10px] font-black shadow-2xs ${item.status === "P" ? "bg-[#8CE0A7] text-[#0A5726] border border-[#64CF87]" : item.status === "WO" ? "bg-[#A2D4F8] text-[#064A7E] border border-[#78BFF4]" : item.status === "A" ? "bg-[#FCA5A5] text-[#991B1B] border border-[#F87171]" : item.status === "HD" ? "bg-[#C084FC] text-[#581C87] border border-[#A855F7]" : "bg-slate-100 text-slate-400 border border-slate-300"}`,
											children: item.status
										})
									]
								}, item.day)), resolvedAttendanceGrid.length < 32 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-col items-center justify-center opacity-0",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px]",
										children: "-"
									})
								})]
							})] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-center gap-2.5 sm:gap-5 pt-2.5 mt-2 border-t border-slate-200 text-[10px] font-bold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "size-3.5 rounded-sm bg-[#8CE0A7] border border-[#64CF87] flex items-center justify-center text-[8px] font-black text-[#0A5726]",
										children: "P"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-slate-700 font-black",
										children: "P - Present"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "size-3.5 rounded-sm bg-[#FCA5A5] border border-[#F87171] flex items-center justify-center text-[8px] font-black text-[#991B1B]",
										children: "A"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-slate-700 font-black",
										children: "A - Absent"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "size-3.5 rounded-sm bg-[#C084FC] border border-[#A855F7] flex items-center justify-center text-[8px] font-black text-[#581C87]",
										children: "HD"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-slate-700 font-black",
										children: "HD - Half Day"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "size-3.5 rounded-sm bg-[#8CE0A7] border border-[#64CF87] flex flex-col items-center justify-center text-[6px] font-black text-[#0A5726] leading-none",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "P" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[5px] text-white bg-[#7C3AED] px-0.5 rounded-2xs leading-none",
											children: "OT"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-slate-700 font-black",
										children: "P (OT) - Present + Overtime"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "size-3.5 rounded-sm bg-[#A2D4F8] border border-[#78BFF4] flex items-center justify-center text-[8px] font-black text-[#064A7E]",
										children: "WO"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-slate-700 font-black",
										children: "WO - Weekly Off"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "size-3.5 rounded-sm bg-slate-100 border border-slate-300 flex items-center justify-center text-[8px] font-black text-slate-400",
										children: "-"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-slate-500 font-bold",
										children: "- Not Marked"
									})]
								})
							]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-rose-200 bg-rose-50/50 p-3 shadow-2xs text-[11px] space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5 text-rose-900 font-black border-b border-rose-200/60 pb-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, {
								size: 14,
								className: "text-rose-600"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "uppercase tracking-wider text-[10px]",
								children: "ABSENT & HALF DAY DETAILS"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1 text-slate-700 font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Absent Days" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
									className: "text-rose-700",
									children: [
										": ",
										computedAbsent,
										" Day",
										computedAbsent !== 1 ? "s" : ""
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] text-slate-500 font-medium pl-1",
								children: resolvedAbsentText
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Half Day" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
									className: "text-amber-700",
									children: [
										": ",
										computedHalfDays,
										" Day",
										computedHalfDays !== 1 ? "s" : ""
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] text-slate-500 font-medium pl-1",
								children: resolvedHalfDayText
							})] })]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-emerald-200 bg-emerald-50/50 p-3 shadow-2xs text-[11px] space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5 text-emerald-900 font-black border-b border-emerald-200/60 pb-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, {
								size: 14,
								className: "text-emerald-600"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "uppercase tracking-wider text-[10px]",
								children: "WORK SUMMARY"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1 text-slate-700 font-semibold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total Working Days" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
										className: "text-slate-900",
										children: [
											": ",
											computedPresent + (computedHalfDays > 0 ? computedHalfDays * .5 : 0),
											" Days"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total Work Hours" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
										className: "text-slate-900",
										children: [
											": ",
											computedWorkHours,
											" Hrs"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Overtime Hours" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
										className: "text-purple-700",
										children: [
											": ",
											overtimeHours,
											" Hrs"
										]
									})]
								}), resolvedOvertimeText && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[10px] text-purple-700 font-medium pl-1 leading-tight pt-0.5",
									children: ["Dates & Work Time: ", resolvedOvertimeText]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Overtime Rate" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
										className: "text-purple-700",
										children: [
											": ₹",
											overtimeRate,
											" / Hr"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Overtime Pay" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
										className: "text-emerald-700 font-black",
										children: [": ₹", computedOtPay]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total Earnings Days" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
										className: "text-slate-900",
										children: [
											": ",
											computedEarningsDays,
											" Days"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between border-t border-emerald-300 pt-1.5 mt-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-black text-slate-800 text-xs",
										children: "Total Net Pay"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
										className: "text-emerald-800 font-black text-sm",
										children: [": ₹", netPay]
									})]
								})
							]
						})]
					})]
				})
			]
		})]
	});
};
/**
* Parses latitude and longitude from any Google Maps, Bing Maps, Apple Maps, or OpenStreetMap URL.
*/
function parseMapCoordinates(inputUrl) {
	if (!inputUrl || typeof inputUrl !== "string") return null;
	try {
		const decoded = decodeURIComponent(inputUrl.trim());
		const matchPpois = decoded.match(/ppois=(-?\d+\.\d+)[_~,](-?\d+\.\d+)/i);
		if (matchPpois && matchPpois[1] && matchPpois[2]) {
			const lat = parseFloat(matchPpois[1]);
			const lng = parseFloat(matchPpois[2]);
			if (isValidCoord(lat, lng)) return {
				lat,
				lng
			};
		}
		const matchCp = decoded.match(/cp=(-?\d+\.\d+)[~,_](-?\d+\.\d+)/i);
		if (matchCp && matchCp[1] && matchCp[2]) {
			const lat = parseFloat(matchCp[1]);
			const lng = parseFloat(matchCp[2]);
			if (isValidCoord(lat, lng)) return {
				lat,
				lng
			};
		}
		const matchAt = decoded.match(/@(-?\d+\.\d+),(-?\d+\.\d+)/);
		if (matchAt && matchAt[1] && matchAt[2]) {
			const lat = parseFloat(matchAt[1]);
			const lng = parseFloat(matchAt[2]);
			if (isValidCoord(lat, lng)) return {
				lat,
				lng
			};
		}
		const matchParam = decoded.match(/[?&](?:q|ll|center|where|cp|location|point)=(-?\d+\.\d+)[,~_%7E\s]+(-?\d+\.\d+)/i);
		if (matchParam && matchParam[1] && matchParam[2]) {
			const lat = parseFloat(matchParam[1]);
			const lng = parseFloat(matchParam[2]);
			if (isValidCoord(lat, lng)) return {
				lat,
				lng
			};
		}
		const matchCoords = decoded.match(/(-?\d{1,2}\.\d+)\s*[,~_\s]\s*(-?\d{1,3}\.\d+)/);
		if (matchCoords && matchCoords[1] && matchCoords[2]) {
			const lat = parseFloat(matchCoords[1]);
			const lng = parseFloat(matchCoords[2]);
			if (isValidCoord(lat, lng)) return {
				lat,
				lng
			};
		}
	} catch (e) {
		console.warn("Failed to parse map coordinates:", e);
	}
	return null;
}
function isValidCoord(lat, lng) {
	return !isNaN(lat) && !isNaN(lng) && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180;
}
//#endregion
export { parseMapCoordinates as n, SalarySlip as t };
