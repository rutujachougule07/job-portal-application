import "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
require_react();
require_jsx_runtime();
function LanguageGate() {
	return null;
}
//#endregion
export { LanguageGate as t };
