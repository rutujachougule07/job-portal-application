import { t as ApplicationsPage } from "./Dashboards-Za5rUmr5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/applications-Crbkbhiw.js
var SplitComponent = ApplicationsPage;
//#endregion
export { SplitComponent as component };
