import { r as __exportAll$1 } from "../_runtime.mjs";
import { c as initializeApp, n as isSupported, t as getAnalytics } from "../_libs/@firebase/analytics+[...].mjs";
import "../_libs/firebase.mjs";
import { S as getFirestore } from "../_libs/@firebase/firestore+[...].mjs";
import { n as getAuth } from "../_libs/firebase__auth.mjs";
import { n as getStorage } from "../_libs/firebase__storage.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/firebase-irBfmyIj.js
var firebase_irBfmyIj_exports = /* @__PURE__ */ __exportAll$1({
	i: () => __exportAll,
	n: () => firebase_exports,
	r: () => storage,
	t: () => db
});
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var firebase_exports = /* @__PURE__ */ __exportAll({
	analytics: () => analytics,
	app: () => app,
	db: () => db,
	storage: () => storage
});
var app = initializeApp({
	apiKey: "AIzaSyAbzKGt_lifA0jsZFc13yO1EgS86dm6pbI",
	authDomain: "job-portal-729b6.firebaseapp.com",
	projectId: "job-portal-729b6",
	storageBucket: "job-portal-729b6.firebasestorage.app",
	messagingSenderId: "1000731725448",
	appId: "1:1000731725448:web:ffde1b8a738849c6bc593d",
	measurementId: "G-BWY14L23SE"
});
var db = getFirestore(app);
getAuth(app);
var storage = getStorage(app);
var analytics = null;
if (typeof window !== "undefined") isSupported().then((supported) => {
	if (supported) analytics = getAnalytics(app);
});
//#endregion
export { storage as i, db as n, firebase_irBfmyIj_exports as r, __exportAll as t };
