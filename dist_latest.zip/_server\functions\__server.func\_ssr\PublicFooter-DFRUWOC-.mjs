import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as ShieldCheck, Gt as ChevronUp, Jt as ChevronDown, c as User, in as Briefcase } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/PublicFooter-DFRUWOC-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LoginDropdown({ className = "" }) {
	const [isOpen, setIsOpen] = (0, import_react.useState)(false);
	const timeoutRef = (0, import_react.useRef)(null);
	const dropdownRef = (0, import_react.useRef)(null);
	const isTouchRef = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		function handleClickOutside(event) {
			if (dropdownRef.current && !dropdownRef.current.contains(event.target)) setIsOpen(false);
		}
		if (isOpen) {
			document.addEventListener("mousedown", handleClickOutside);
			document.addEventListener("touchstart", handleClickOutside, { passive: true });
		}
		return () => {
			document.removeEventListener("mousedown", handleClickOutside);
			document.removeEventListener("touchstart", handleClickOutside);
		};
	}, [isOpen]);
	const handleMouseEnter = () => {
		if (isTouchRef.current) return;
		if (typeof window !== "undefined" && window.matchMedia("(hover: hover) and (pointer: fine)").matches) {
			if (timeoutRef.current) clearTimeout(timeoutRef.current);
			setIsOpen(true);
		}
	};
	const handleMouseLeave = () => {
		if (isTouchRef.current) return;
		if (typeof window !== "undefined" && window.matchMedia("(hover: hover) and (pointer: fine)").matches) timeoutRef.current = setTimeout(() => {
			setIsOpen(false);
		}, 250);
	};
	const handleTouchStart = () => {
		isTouchRef.current = true;
		setTimeout(() => {
			isTouchRef.current = false;
		}, 600);
	};
	const toggleDropdown = (e) => {
		e.stopPropagation();
		if (timeoutRef.current) clearTimeout(timeoutRef.current);
		setIsOpen((prev) => !prev);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: dropdownRef,
		className: `relative inline-block text-left ${className}`,
		onMouseEnter: handleMouseEnter,
		onMouseLeave: handleMouseLeave,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: toggleDropdown,
			onTouchStart: handleTouchStart,
			className: "flex items-center gap-2 p-1.5 sm:px-4 sm:py-2 rounded-full bg-white hover:bg-slate-50 text-[#10233F] font-black text-sm border border-[#F5D8A8] shadow-[0_4px_14px_rgba(245,166,35,0.20)] hover:shadow-[0_6px_18px_rgba(245,166,35,0.30)] transition-all active:scale-95 cursor-pointer select-none ring-2 ring-amber-100/60",
			"aria-expanded": isOpen,
			"aria-label": "Login as",
			title: "Login as",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "size-7 sm:size-8 rounded-full bg-white flex items-center justify-center shrink-0 overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/logo_icon.png",
						alt: "Login",
						className: "size-6 sm:size-7 object-contain",
						onError: (e) => {
							e.currentTarget.style.display = "none";
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "hidden sm:inline font-extrabold text-[#10233F] text-sm sm:text-[15px] whitespace-nowrap",
					children: "Login as"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `hidden sm:inline size-4 text-[#10233F] stroke-[2.5] transition-transform duration-200 ${isOpen ? "rotate-180" : ""}` })
			]
		}), isOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute right-0 top-full pt-2 w-64 sm:w-72 max-w-[calc(100vw-1.5rem)] z-[9999] animate-in fade-in-50 zoom-in-95 origin-top-right",
			onMouseEnter: handleMouseEnter,
			onMouseLeave: handleMouseLeave,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-end pr-3.5 sm:pr-8 -mb-2 relative z-0 pointer-events-none",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-3.5 h-3.5 bg-white rotate-45 border-t border-l border-slate-200 shadow-2xs" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 rounded-3xl bg-white border border-slate-200/90 p-3 sm:p-3.5 shadow-2xl space-y-2.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/auth",
						search: {
							mode: "login",
							role: "worker"
						},
						onClick: () => setIsOpen(false),
						className: "flex items-center gap-3.5 p-2.5 sm:p-3 rounded-2xl bg-[#EEF5FF] hover:bg-[#E0EEFF] active:scale-[0.98] transition-all group cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-11 rounded-full bg-[#D6E8FF] flex items-center justify-center text-[#1877F2] shrink-0 shadow-2xs group-hover:scale-105 transition-transform",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-5 stroke-[2.2]" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-black text-[#10233F] group-hover:text-[#1877F2]",
							children: "Seeker Login"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/auth",
						search: {
							mode: "login",
							role: "employee"
						},
						onClick: () => setIsOpen(false),
						className: "flex items-center gap-3.5 p-2.5 sm:p-3 rounded-2xl bg-[#EDF9F2] hover:bg-[#DDF4E6] active:scale-[0.98] transition-all group cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-11 rounded-full bg-[#D1F3E0] flex items-center justify-center text-[#059669] shrink-0 shadow-2xs group-hover:scale-105 transition-transform",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-5 stroke-[2.2]" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-black text-[#10233F] group-hover:text-[#059669]",
							children: "Employee Login"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/auth",
						search: {
							mode: "login",
							role: "admin"
						},
						onClick: () => setIsOpen(false),
						className: "flex items-center gap-3.5 p-2.5 sm:p-3 rounded-2xl bg-[#FFF6EA] hover:bg-[#FFEED8] active:scale-[0.98] transition-all group cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-11 rounded-full bg-[#FFE8CC] flex items-center justify-center text-[#D97706] shrink-0 shadow-2xs group-hover:scale-105 transition-transform",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-5 stroke-[2.2]" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-black text-[#10233F] group-hover:text-[#D97706]",
							children: "Job Poster Login"
						})]
					})
				]
			})]
		})]
	});
}
function PublicFooter() {
	const navigate = useNavigate();
	const scrollToTop = () => {
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	};
	const handleHeartClick = () => {
		navigate({ to: "/superadmin" });
		if (typeof window !== "undefined") window.location.href = "/superadmin";
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "relative bg-[#082F63] text-slate-200 overflow-hidden font-sans border-t border-[#125BB5]/40",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-transparent via-[#FFC400] to-transparent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-4xl px-4 pt-8 pb-6 sm:pt-10 sm:pb-8 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-block group mb-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "bg-white/95 p-2 sm:p-3 rounded-2xl shadow-lg transition-transform duration-300 group-hover:scale-105 inline-flex items-center justify-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/logo.png",
								alt: "REAL JOB Logo",
								className: "h-12 sm:h-16 object-contain"
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs sm:text-sm font-medium text-slate-300 max-w-md mx-auto mb-5",
						children: [
							"Right Person • Right Job • Right Opportunity",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"Connecting Workers and Employers across India"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-8 pt-5 border-t border-white/10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-sm font-semibold text-slate-200 hover:text-[#FFC400] transition-colors",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex items-center justify-center size-7 rounded-full bg-white/10 text-[#FFC400]",
									children: "✉"
								}), "rjsgroup108@gmail.com"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-sm font-semibold text-slate-200 hover:text-[#FFC400] transition-colors",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex items-center justify-center size-7 rounded-full bg-white/10 text-[#FFC400]",
									children: "📞"
								}), "8722739355"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-1 h-1 rounded-full bg-slate-500 hidden sm:block" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								className: "text-sm font-semibold text-slate-200 hover:text-[#FFC400] transition-colors",
								children: "Terms & Conditions"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								className: "text-sm font-semibold text-slate-200 hover:text-[#FFC400] transition-colors",
								children: "Privacy Policy"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-t border-white/10 bg-[#063B78] py-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-4 text-xs font-bold text-slate-300 sm:flex-row sm:px-6 lg:px-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-center sm:text-left",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "© 2026 REAL JOB. All rights reserved." })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1.5",
							children: [
								"Made with",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									onClick: handleHeartClick,
									className: "text-[#FFC400] cursor-pointer select-none hover:scale-125 transition-transform inline-block",
									title: "Superadmin Portal",
									children: "💛"
								}),
								" ",
								"in India."
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: scrollToTop,
							"aria-label": "Scroll to top",
							className: "grid size-8 place-items-center rounded-full bg-[#FFC400] text-[#082F63] transition-all shadow-md hover:scale-105 font-black",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-4 stroke-[3]" })
						})]
					})]
				})
			})
		]
	});
}
//#endregion
export { PublicFooter as n, LoginDropdown as t };
