import { a as SeekerDashboard } from "./Dashboards-DS6IH2fS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-BXWCChc5.js
var SplitComponent = SeekerDashboard;
//#endregion
export { SplitComponent as component };
