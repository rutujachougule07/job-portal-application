import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n } from "./i18n-BcT9wMyM.mjs";
import { t as Button } from "./button--9UiOy7A.mjs";
import { t as dataStore } from "./data-store-CvMaHmbm.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { $t as Building, A as Share2, C as Sparkles, Ht as CircleCheck, It as CloudUpload, Kt as Check, M as Send, O as ShieldCheck, Ot as ExternalLink, Rt as Clock3, S as Sprout, V as Phone, Y as MapPin, _t as HardHat, a as Wallet, an as BookOpen, b as Star, c as User, cn as Award, en as Building2, i as Wrench, mt as HeartPulse, r as X, s as Users, tn as Briefcase, ut as Info, wt as FileText, xt as Gift, yt as GraduationCap } from "../_libs/lucide-react.mjs";
import { t as Badge } from "./badge-DRaMiws1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/JobCard-DBTRplir.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var getFallbackConfig = (category) => {
	const cat = (category || "").toLowerCase();
	const config = {
		fields: {
			fullName: "required",
			mobile: "required",
			currentLocation: "required"
		},
		customQuestions: []
	};
	if (cat.includes("construct") || cat.includes("mason")) config.fields = {
		...config.fields,
		email: "optional",
		preferredWorkLocation: "required",
		jobType: "required",
		totalWorkExperience: "required",
		relevantExperience: "required",
		skills: "required",
		previousWorkExperience: "optional",
		availability: "required",
		willingToRelocate: "optional",
		expectedSalary: "required",
		resume: "optional",
		workExperienceCertificate: "optional",
		skillCertificate: "optional",
		profilePhoto: "optional"
	};
	else if (cat.includes("it") || cat.includes("software") || cat.includes("tech")) config.fields = {
		...config.fields,
		email: "required",
		preferredWorkLocation: "required",
		highestQualification: "required",
		degree: "required",
		college: "optional",
		passingYear: "required",
		totalExperience: "required",
		relevantExperience: "required",
		currentCompany: "optional",
		currentJobTitle: "optional",
		technicalSkills: "required",
		programmingLanguages: "required",
		frameworks: "required",
		projects: "required",
		github: "optional",
		portfolio: "optional",
		linkedin: "optional",
		currentCTC: "optional",
		expectedCTC: "required",
		noticePeriod: "required",
		workModePreference: "optional",
		resume: "required",
		certifications: "optional"
	};
	else if (cat.includes("engineer")) config.fields = {
		...config.fields,
		email: "required",
		preferredWorkLocation: "required",
		engineeringBranch: "required",
		degree: "required",
		college: "optional",
		passingYear: "required",
		totalExperience: "required",
		relevantExperience: "required",
		technicalSkills: "required",
		softwareTools: "optional",
		projects: "optional",
		previousCompany: "optional",
		previousJobRole: "optional",
		currentCTC: "optional",
		expectedCTC: "required",
		noticePeriod: "required",
		willingToRelocate: "optional",
		resume: "required",
		engineeringCertificate: "optional",
		relevantCertifications: "optional"
	};
	else if (cat.includes("health") || cat.includes("medic") || cat.includes("nurs")) config.fields = {
		...config.fields,
		email: "required",
		preferredWorkLocation: "required",
		qualification: "required",
		specialization: "required",
		college: "optional",
		passingYear: "required",
		totalExperience: "required",
		relevantExperience: "required",
		previousHospital: "optional",
		currentRole: "optional",
		medicalSkills: "required",
		department: "optional",
		registrationNumber: "optional",
		registrationAuthority: "optional",
		registrationValidity: "optional",
		expectedSalary: "required",
		noticePeriod: "required",
		shiftAvailability: "required",
		willingToRelocate: "optional",
		resume: "required",
		qualificationCertificate: "optional",
		licenseProof: "optional",
		relevantCertificates: "optional"
	};
	else if (cat.includes("finance") || cat.includes("account")) config.fields = {
		...config.fields,
		email: "required",
		preferredWorkLocation: "required",
		highestQualification: "required",
		degree: "required",
		college: "optional",
		passingYear: "required",
		totalExperience: "required",
		relevantExperience: "required",
		currentCompany: "optional",
		previousJobRole: "optional",
		accountingSkills: "required",
		accountingSoftwareKnowledge: "optional",
		tallyKnowledge: "optional",
		excelKnowledge: "optional",
		sapKnowledge: "optional",
		gstExperience: "optional",
		certifications: "optional",
		currentCTC: "optional",
		expectedCTC: "required",
		noticePeriod: "required",
		resume: "required"
	};
	else if (cat.includes("sales") || cat.includes("market")) config.fields = {
		...config.fields,
		email: "required",
		preferredWorkLocation: "required",
		totalExperience: "required",
		salesExperience: "required",
		previousCompany: "optional",
		previousJobRole: "optional",
		salesSkills: "required",
		marketingSkills: "optional",
		industryExperience: "optional",
		salesTargetExperience: "optional",
		targetHandled: "optional",
		teamHandlingExperience: "optional",
		customerHandlingExperience: "required",
		fieldSalesExperience: "optional",
		travelWillingness: "optional",
		expectedSalary: "required",
		expectedIncentive: "optional",
		noticePeriod: "required",
		resume: "optional",
		portfolio: "optional"
	};
	else if (cat.includes("educat") || cat.includes("teach")) config.fields = {
		...config.fields,
		email: "required",
		preferredWorkLocation: "required",
		highestQualification: "required",
		degree: "required",
		subject: "required",
		college: "optional",
		passingYear: "required",
		teachingExperience: "required",
		subjectsTaught: "required",
		classesTaught: "optional",
		previousSchool: "optional",
		teachingSkills: "required",
		onlineTeachingExperience: "optional",
		teachingCertifications: "optional",
		expectedSalary: "required",
		noticePeriod: "required",
		preferredTeachingMode: "optional",
		willingToRelocate: "optional",
		resume: "required",
		educationCertificates: "optional"
	};
	else if (cat.includes("manufactur") || cat.includes("factory") || cat.includes("production")) config.fields = {
		...config.fields,
		email: "optional",
		preferredWorkLocation: "required",
		jobType: "required",
		totalExperience: "required",
		relevantExperience: "required",
		previousCompany: "optional",
		previousJobRole: "optional",
		productionExperience: "optional",
		machineExperience: "optional",
		technicalSkills: "required",
		qualityControlExperience: "optional",
		productionLineExperience: "optional",
		safetyKnowledge: "optional",
		shiftExperience: "optional",
		shiftAvailability: "required",
		teamHandlingExperience: "optional",
		expectedSalary: "required",
		joiningAvailability: "required",
		willingToRelocate: "optional",
		resume: "optional",
		experienceCertificate: "optional",
		skillCertificate: "optional"
	};
	else if (cat.includes("farm") || cat.includes("agri") || cat.includes("crop") || cat.includes("harvest") || cat.includes("tractor")) config.fields = {
		...config.fields,
		email: "optional",
		positionAppliedFor: "required",
		typeOfFarmingWork: "required",
		employmentType: "required",
		expectedSalary: "required",
		availableJoiningDate: "required",
		farmingExperience: "required",
		skills: "required",
		resume: "optional"
	};
	else config.fields = {
		...config.fields,
		email: "optional",
		resume: "optional",
		experience: "optional"
	};
	return config;
};
var groupFieldsBySection = (fields) => {
	const sections = {
		personal: {},
		work: {},
		salary: {},
		documents: {}
	};
	Object.keys(fields).forEach((key) => {
		const k = key.toLowerCase();
		const val = fields[key];
		if (!val) return;
		if (k.includes("name") || k.includes("email") || k.includes("mobile") || k.includes("location")) sections.personal[key] = val;
		else if (k.includes("salary") || k.includes("ctc") || k.includes("wage") || k.includes("notice") || k.includes("joining") || k.includes("availability") || k.includes("mode") || k.includes("shift")) sections.salary[key] = val;
		else if (k.includes("resume") || k.includes("certificate") || k.includes("photo") || k.includes("portfolio") || k.includes("proof")) sections.documents[key] = val;
		else sections.work[key] = val;
	});
	return sections;
};
var DynamicApplicationForm = ({ appConfig, fieldValues, setFieldValues, customAnswers, setCustomAnswers, lang, category }) => {
	const handleFieldChange = (key, val) => setFieldValues((p) => ({
		...p,
		[key]: val
	}));
	const handleCustomChange = (id, val) => setCustomAnswers((p) => ({
		...p,
		[id]: val
	}));
	const catStr = (category || "").toLowerCase();
	const isConstructionCategory = catStr.includes("construct") || catStr.includes("mason") || catStr.includes("builder") || catStr.includes("site") || catStr.includes("labor") || catStr.includes("labour") || catStr.includes("worker") || catStr.includes("helper") || catStr.includes("plumber") || catStr.includes("electrician") || catStr.includes("carpenter") || catStr.includes("painter") || catStr.includes("बांधकाम");
	const isFarmingCategory = catStr.includes("farm") || catStr.includes("agricultur") || catStr.includes("crop") || catStr.includes("harvest") || catStr.includes("tractor") || catStr.includes("dairy") || catStr.includes("poultry") || catStr.includes("शेती") || catStr.includes("कृषी");
	const isHospitalCategory = catStr.includes("hospital") || catStr.includes("health") || catStr.includes("medic") || catStr.includes("nurs") || catStr.includes("doctor") || catStr.includes("clinic") || catStr.includes("pharm") || catStr.includes("lab") || catStr.includes("pathology");
	if (isConstructionCategory) {
		const handleTypeOfWorkToggle = (item) => {
			const currentList = Array.isArray(fieldValues["typeOfWork"]) ? fieldValues["typeOfWork"] : fieldValues["typeOfWork"] ? [fieldValues["typeOfWork"]] : [];
			const updated = currentList.includes(item) ? currentList.filter((i) => i !== item) : [...currentList, item];
			handleFieldChange("typeOfWork", updated);
		};
		const handleSkillsToggle = (item) => {
			const currentList = Array.isArray(fieldValues["skills"]) ? fieldValues["skills"] : fieldValues["skills"] ? [fieldValues["skills"]] : [];
			const updated = currentList.includes(item) ? currentList.filter((i) => i !== item) : [...currentList, item];
			handleFieldChange("skills", updated);
		};
		const typeOfWorkSelected = Array.isArray(fieldValues["typeOfWork"]) ? fieldValues["typeOfWork"] : fieldValues["typeOfWork"] ? [fieldValues["typeOfWork"]] : [];
		const skillsSelected = Array.isArray(fieldValues["skills"]) ? fieldValues["skills"] : fieldValues["skills"] ? [fieldValues["skills"]] : [];
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-6 mt-2 text-[#10233F]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-[#063B78] text-white p-4 sm:p-5 rounded-2xl flex items-center justify-between shadow-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-10 rounded-xl bg-white/10 flex items-center justify-center text-[#FFC400]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HardHat, { className: "size-6" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-black text-base sm:text-lg text-white",
							children: "Construction Worker Job Application Form"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-blue-100 font-medium",
							children: "Official Site & Construction Worker Recruitment Protocol"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "px-3 py-1 bg-white/20 rounded-full text-xs font-bold uppercase text-white",
						children: "Construction"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white rounded-2xl border border-[#DCE5F0] p-5 shadow-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 mb-4 p-2 bg-[#EBF1F8] rounded-xl text-[#063B78]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-black text-sm",
							children: "1. Personal Information"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "md:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-1",
									children: "Full Name *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									required: true,
									placeholder: "Enter Full Name",
									value: fieldValues["fullName"] || "",
									onChange: (e) => handleFieldChange("fullName", e.target.value),
									className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "Date of Birth *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "date",
								required: true,
								value: fieldValues["dob"] || "",
								onChange: (e) => handleFieldChange("dob", e.target.value),
								className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "Gender *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-2",
								children: [
									"Male",
									"Female",
									"Other"
								].map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => handleFieldChange("gender", g),
									className: `flex-1 h-11 rounded-xl border text-xs font-extrabold transition-colors ${fieldValues["gender"] === g ? "bg-[#063B78] text-white border-[#063B78]" : "bg-white text-gray-700 border-[#DCE5F0] hover:bg-gray-50"}`,
									children: g
								}, g))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "Marital Status"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: fieldValues["maritalStatus"] || "",
								onChange: (e) => handleFieldChange("maritalStatus", e.target.value),
								className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Select Status"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Single",
										children: "Single"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Married",
										children: "Married"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Other",
										children: "Other"
									})
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "Mobile Number *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "tel",
								required: true,
								placeholder: "+91 98220 00000",
								value: fieldValues["mobileNumber"] || fieldValues["mobile"] || "",
								onChange: (e) => handleFieldChange("mobileNumber", e.target.value),
								className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "md:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-1",
									children: "Address *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									required: true,
									rows: 2,
									placeholder: "Full address details",
									value: fieldValues["address"] || "",
									onChange: (e) => handleFieldChange("address", e.target.value),
									className: "w-full rounded-xl border border-[#DCE5F0] p-3 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "City / Village *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								required: true,
								placeholder: "City or Village",
								value: fieldValues["cityVillage"] || fieldValues["city"] || "",
								onChange: (e) => handleFieldChange("cityVillage", e.target.value),
								className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "PIN Code *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								required: true,
								placeholder: "PIN Code",
								value: fieldValues["pinCode"] || "",
								onChange: (e) => handleFieldChange("pinCode", e.target.value),
								className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "md:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-1",
									children: "Email Address"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "email",
									placeholder: "email@example.com (Optional)",
									value: fieldValues["emailAddress"] || fieldValues["email"] || "",
									onChange: (e) => handleFieldChange("emailAddress", e.target.value),
									className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
								})]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white rounded-2xl border border-[#DCE5F0] p-5 shadow-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 mb-4 p-2 bg-[#EBF1F8] rounded-xl text-[#063B78]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-black text-sm",
							children: "2. Job Information"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "Position Applied For *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								required: true,
								placeholder: "e.g. Mason / Helper / Site Work",
								value: fieldValues["positionAppliedFor"] || "",
								onChange: (e) => handleFieldChange("positionAppliedFor", e.target.value),
								className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-2",
									children: "Type of Work *"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap gap-2",
									children: [
										"Mason",
										"Helper",
										"Electrician",
										"Plumber",
										"Carpenter",
										"Painter",
										"Other"
									].map((item) => {
										const isChecked = typeOfWorkSelected.includes(item);
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => handleTypeOfWorkToggle(item),
											className: `px-3.5 py-2 rounded-xl border text-xs font-extrabold flex items-center gap-1.5 transition-colors ${isChecked ? "bg-[#063B78] text-white border-[#063B78]" : "bg-white text-gray-700 border-[#DCE5F0] hover:bg-gray-50"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "checkbox",
												checked: isChecked,
												readOnly: true,
												className: "size-3.5 accent-white pointer-events-none"
											}), item]
										}, item);
									})
								}),
								typeOfWorkSelected.includes("Other") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									placeholder: "Specify other work type...",
									value: fieldValues["otherWorkType"] || "",
									onChange: (e) => handleFieldChange("otherWorkType", e.target.value),
									className: "mt-2.5 w-full h-10 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-2",
								children: "Employment Type *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 sm:grid-cols-4 gap-2",
								children: [
									"Full Time",
									"Part Time",
									"Contract",
									"Daily Wage"
								].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => handleFieldChange("employmentType", t),
									className: `h-11 rounded-xl border text-xs font-extrabold transition-colors ${fieldValues["employmentType"] === t ? "bg-[#063B78] text-white border-[#063B78]" : "bg-white text-gray-700 border-[#DCE5F0] hover:bg-gray-50"}`,
									children: t
								}, t))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-4 pt-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-1",
									children: "Expected Daily/Monthly Salary (₹) *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									required: true,
									placeholder: "e.g. ₹800 / day or ₹25,000 / month",
									value: fieldValues["expectedSalary"] || "",
									onChange: (e) => handleFieldChange("expectedSalary", e.target.value),
									className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-1",
									children: "Available Joining Date *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "date",
									required: true,
									value: fieldValues["availableJoiningDate"] || "",
									onChange: (e) => handleFieldChange("availableJoiningDate", e.target.value),
									className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
								})] })]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white rounded-2xl border border-[#DCE5F0] p-5 shadow-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 mb-4 p-2 bg-[#EBF1F8] rounded-xl text-[#063B78]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-black text-sm",
							children: "3. Educational Qualification"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-left text-xs border-collapse min-w-[500px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "bg-gray-100 text-[#10233F] border border-gray-200",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-2.5 font-black border border-gray-200",
										children: "Qualification"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-2.5 font-black border border-gray-200",
										children: "School / College Name"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-2.5 font-black border border-gray-200 w-32",
										children: "Passing Year"
									})
								]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: [
								1,
								2,
								3
							].map((rowIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border border-gray-200",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-1.5 border border-gray-200",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											placeholder: rowIdx === 1 ? "e.g. 10th / 12th / ITI" : "Qualification",
											value: fieldValues[`edu_qual_${rowIdx}`] || "",
											onChange: (e) => handleFieldChange(`edu_qual_${rowIdx}`, e.target.value),
											className: "w-full h-9 rounded-lg border border-gray-200 px-2.5 font-semibold text-xs"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-1.5 border border-gray-200",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											placeholder: "School or College Name",
											value: fieldValues[`edu_school_${rowIdx}`] || "",
											onChange: (e) => handleFieldChange(`edu_school_${rowIdx}`, e.target.value),
											className: "w-full h-9 rounded-lg border border-gray-200 px-2.5 font-semibold text-xs"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-1.5 border border-gray-200",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											placeholder: "e.g. 2020",
											value: fieldValues[`edu_year_${rowIdx}`] || "",
											onChange: (e) => handleFieldChange(`edu_year_${rowIdx}`, e.target.value),
											className: "w-full h-9 rounded-lg border border-gray-200 px-2.5 font-semibold text-xs"
										})
									})
								]
							}, rowIdx)) })]
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white rounded-2xl border border-[#DCE5F0] p-5 shadow-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 mb-4 p-2 bg-[#EBF1F8] rounded-xl text-[#063B78]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-black text-sm",
							children: "4. Work Experience (If Any)"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-left text-xs border-collapse min-w-[550px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "bg-gray-100 text-[#10233F] border border-gray-200",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-2.5 font-black border border-gray-200",
										children: "Previous Company / Site"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-2.5 font-black border border-gray-200",
										children: "Work Type"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-2.5 font-black border border-gray-200 w-28",
										children: "From (Year)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-2.5 font-black border border-gray-200 w-28",
										children: "To (Year)"
									})
								]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: [1, 2].map((rowIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border border-gray-200",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-1.5 border border-gray-200",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											placeholder: "Company or Site Name",
											value: fieldValues[`exp_company_${rowIdx}`] || "",
											onChange: (e) => handleFieldChange(`exp_company_${rowIdx}`, e.target.value),
											className: "w-full h-9 rounded-lg border border-gray-200 px-2.5 font-semibold text-xs"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-1.5 border border-gray-200",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											placeholder: "e.g. Masonry / Helping",
											value: fieldValues[`exp_work_${rowIdx}`] || "",
											onChange: (e) => handleFieldChange(`exp_work_${rowIdx}`, e.target.value),
											className: "w-full h-9 rounded-lg border border-gray-200 px-2.5 font-semibold text-xs"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-1.5 border border-gray-200",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											placeholder: "2021",
											value: fieldValues[`exp_from_${rowIdx}`] || "",
											onChange: (e) => handleFieldChange(`exp_from_${rowIdx}`, e.target.value),
											className: "w-full h-9 rounded-lg border border-gray-200 px-2.5 font-semibold text-xs"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-1.5 border border-gray-200",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											placeholder: "2023",
											value: fieldValues[`exp_to_${rowIdx}`] || "",
											onChange: (e) => handleFieldChange(`exp_to_${rowIdx}`, e.target.value),
											className: "w-full h-9 rounded-lg border border-gray-200 px-2.5 font-semibold text-xs"
										})
									})
								]
							}, rowIdx)) })]
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white rounded-2xl border border-[#DCE5F0] p-5 shadow-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 mb-4 p-2 bg-[#EBF1F8] rounded-xl text-[#063B78]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
								className: "font-black text-sm",
								children: "5. Skills (Select if applicable)"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								"Masonry",
								"Electrical Work",
								"Plumbing",
								"Carpentry",
								"Painting",
								"Machine Handling",
								"Other"
							].map((skill) => {
								const isChecked = skillsSelected.includes(skill);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => handleSkillsToggle(skill),
									className: `px-3.5 py-2 rounded-xl border text-xs font-extrabold flex items-center gap-1.5 transition-colors ${isChecked ? "bg-[#063B78] text-white border-[#063B78]" : "bg-white text-gray-700 border-[#DCE5F0] hover:bg-gray-50"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: isChecked,
										readOnly: true,
										className: "size-3.5 accent-white pointer-events-none"
									}), skill]
								}, skill);
							})
						}),
						skillsSelected.includes("Other") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							placeholder: "Specify other skills...",
							value: fieldValues["otherSkills"] || "",
							onChange: (e) => handleFieldChange("otherSkills", e.target.value),
							className: "mt-3 w-full h-10 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 pt-4 border-t border-gray-100",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-2",
								children: "Documents Upload (Optional - ID Proof / Photo / Resume)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
								children: [
									{
										key: "idProof",
										label: "ID Proof (Aadhaar / Voter ID / PAN)",
										accept: ".pdf,.jpg,.png"
									},
									{
										key: "photo",
										label: "Passport Size Photo",
										accept: ".jpg,.png"
									},
									{
										key: "resume",
										label: "Resume / CV (Optional)",
										accept: ".pdf,.doc,.docx"
									},
									{
										key: "expCert",
										label: "Experience Certificate (If any)",
										accept: ".pdf,.jpg,.png"
									}
								].map((doc) => {
									const fileName = fieldValues[doc.key];
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-[11px] font-bold text-[#5B6B7F]",
											children: doc.label
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: `border border-dashed ${fileName ? "border-emerald-500 bg-emerald-50" : "border-[#DCE5F0] hover:border-[#063B78] hover:bg-[#F5F8FC]"} rounded-lg p-2.5 flex items-center justify-between text-center transition-colors relative h-12`,
											children: [fileName ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-xs font-black text-emerald-700 truncate",
												children: ["✓ ", fileName]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[11px] font-semibold text-[#5B6B7F] flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudUpload, { className: "size-3.5 text-[#063B78]" }), " Upload file"]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "file",
												accept: doc.accept,
												onChange: (e) => handleFieldChange(doc.key, e.target.files?.[0]?.name),
												className: "absolute inset-0 opacity-0 cursor-pointer w-full h-full"
											})]
										})]
									}, doc.key);
								})
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white rounded-2xl border border-[#DCE5F0] p-5 shadow-xs space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 mb-2 p-2 bg-[#EBF1F8] rounded-xl text-[#063B78]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
								className: "font-black text-sm",
								children: "6. Declaration"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3 p-3 bg-gray-50 rounded-xl border border-gray-200",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								id: "constructionDeclaration",
								required: true,
								checked: !!fieldValues["declarationConfirmed"],
								onChange: (e) => handleFieldChange("declarationConfirmed", e.target.checked),
								className: "mt-1 size-4 accent-[#063B78] cursor-pointer"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "constructionDeclaration",
								className: "text-xs font-bold text-[#10233F] cursor-pointer select-none leading-relaxed",
								children: "I hereby declare that the information given above is true and correct to the best of my knowledge."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 md:grid-cols-2 gap-4 pt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "Date"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								readOnly: true,
								value: (/* @__PURE__ */ new Date()).toLocaleDateString(),
								className: "w-full h-10 rounded-xl bg-gray-100 border border-[#DCE5F0] px-3.5 text-xs font-bold text-gray-700"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "Signature (Applicant Full Name) *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								required: true,
								placeholder: "Type your full name as signature",
								value: fieldValues["digitalSignature"] || "",
								onChange: (e) => handleFieldChange("digitalSignature", e.target.value),
								className: "w-full h-10 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
							})] })]
						})
					]
				})
			]
		});
	}
	if (isFarmingCategory) {
		const handleSkillsToggle = (item) => {
			const currentList = Array.isArray(fieldValues["skills"]) ? fieldValues["skills"] : fieldValues["skills"] ? [fieldValues["skills"]] : [];
			const updated = currentList.includes(item) ? currentList.filter((i) => i !== item) : [...currentList, item];
			handleFieldChange("skills", updated);
		};
		const skillsSelected = Array.isArray(fieldValues["skills"]) ? fieldValues["skills"] : fieldValues["skills"] ? [fieldValues["skills"]] : [];
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-6 mt-2 text-[#10233F]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-[#1E5631] text-white p-4 sm:p-5 rounded-2xl flex items-center justify-between shadow-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-10 rounded-xl bg-white/10 flex items-center justify-center text-[#A3E635]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sprout, { className: "size-6" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-black text-base sm:text-lg text-white",
							children: "Farming Job Application Form"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-emerald-100 font-medium",
							children: "Official Agriculture & Farm Worker Recruitment Protocol"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "px-3 py-1 bg-white/20 rounded-full text-xs font-bold uppercase text-white",
						children: "Farming Category"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white rounded-2xl border border-[#DCE5F0] p-5 shadow-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 mb-4 p-2 bg-[#E8F5E9] rounded-xl text-[#1E5631]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-black text-sm",
							children: "1. Personal Information"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "md:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-1",
									children: "Full Name *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									required: true,
									placeholder: "Enter Full Name",
									value: fieldValues["fullName"] || "",
									onChange: (e) => handleFieldChange("fullName", e.target.value),
									className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#1E5631]"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "Date of Birth *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "date",
								required: true,
								value: fieldValues["dob"] || "",
								onChange: (e) => handleFieldChange("dob", e.target.value),
								className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#1E5631]"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "Gender *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-2",
								children: [
									"Male",
									"Female",
									"Other"
								].map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => handleFieldChange("gender", g),
									className: `flex-1 h-11 rounded-xl border text-xs font-extrabold transition-colors ${fieldValues["gender"] === g ? "bg-[#1E5631] text-white border-[#1E5631]" : "bg-white text-gray-700 border-[#DCE5F0] hover:bg-gray-50"}`,
									children: g
								}, g))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "md:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-1",
									children: "Address *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									required: true,
									rows: 2,
									placeholder: "Full address details",
									value: fieldValues["address"] || "",
									onChange: (e) => handleFieldChange("address", e.target.value),
									className: "w-full rounded-xl border border-[#DCE5F0] p-3 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#1E5631]"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "City / Village *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								required: true,
								placeholder: "City or Village",
								value: fieldValues["cityVillage"] || fieldValues["city"] || "",
								onChange: (e) => handleFieldChange("cityVillage", e.target.value),
								className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#1E5631]"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "PIN Code *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								required: true,
								placeholder: "PIN Code",
								value: fieldValues["pinCode"] || "",
								onChange: (e) => handleFieldChange("pinCode", e.target.value),
								className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#1E5631]"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "Mobile Number *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "tel",
								required: true,
								placeholder: "+91 98220 00000",
								value: fieldValues["mobileNumber"] || fieldValues["mobile"] || "",
								onChange: (e) => handleFieldChange("mobileNumber", e.target.value),
								className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#1E5631]"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "Email Address"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "email",
								placeholder: "email@example.com (Optional)",
								value: fieldValues["emailAddress"] || fieldValues["email"] || "",
								onChange: (e) => handleFieldChange("emailAddress", e.target.value),
								className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#1E5631]"
							})] })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white rounded-2xl border border-[#DCE5F0] p-5 shadow-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 mb-4 p-2 bg-[#E8F5E9] rounded-xl text-[#1E5631]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-black text-sm",
							children: "2. Job Information"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "Position Applied For *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								required: true,
								placeholder: "e.g. Farm Worker / Tractor Driver / Cultivator",
								value: fieldValues["positionAppliedFor"] || "",
								onChange: (e) => handleFieldChange("positionAppliedFor", e.target.value),
								className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#1E5631]"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "Type of Farming Work *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								required: true,
								placeholder: "e.g. Crop Cultivation, Harvesting, Dairy Farm, Spraying",
								value: fieldValues["typeOfFarmingWork"] || "",
								onChange: (e) => handleFieldChange("typeOfFarmingWork", e.target.value),
								className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#1E5631]"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-2",
								children: "Employment Type *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 sm:grid-cols-4 gap-2",
								children: [
									"Full Time",
									"Part Time",
									"Seasonal",
									"Contract"
								].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => handleFieldChange("employmentType", t),
									className: `h-11 rounded-xl border text-xs font-extrabold transition-colors ${fieldValues["employmentType"] === t ? "bg-[#1E5631] text-white border-[#1E5631]" : "bg-white text-gray-700 border-[#DCE5F0] hover:bg-gray-50"}`,
									children: t
								}, t))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-4 pt-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-1",
									children: "Expected Salary (₹) *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									required: true,
									placeholder: "e.g. ₹500 / day or ₹15,000 / month",
									value: fieldValues["expectedSalary"] || "",
									onChange: (e) => handleFieldChange("expectedSalary", e.target.value),
									className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#1E5631]"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-extrabold text-[#10233F] mb-1",
									children: "Available Joining Date *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "date",
									required: true,
									value: fieldValues["availableJoiningDate"] || "",
									onChange: (e) => handleFieldChange("availableJoiningDate", e.target.value),
									className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#1E5631]"
								})] })]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white rounded-2xl border border-[#DCE5F0] p-5 shadow-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 mb-4 p-2 bg-[#E8F5E9] rounded-xl text-[#1E5631]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-black text-sm",
							children: "3. Education Details"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-left text-xs border-collapse min-w-[500px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "bg-gray-100 text-[#10233F] border border-gray-200",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-2.5 font-black border border-gray-200",
										children: "Qualification"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-2.5 font-black border border-gray-200",
										children: "School / College Name"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "p-2.5 font-black border border-gray-200 w-32",
										children: "Passing Year"
									})
								]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: [
								1,
								2,
								3
							].map((rowIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border border-gray-200",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-1.5 border border-gray-200",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											placeholder: rowIdx === 1 ? "e.g. 10th / Primary" : "Qualification",
											value: fieldValues[`edu_qual_${rowIdx}`] || "",
											onChange: (e) => handleFieldChange(`edu_qual_${rowIdx}`, e.target.value),
											className: "w-full h-9 rounded-lg border border-gray-200 px-2.5 font-semibold text-xs"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-1.5 border border-gray-200",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											placeholder: "School or College Name",
											value: fieldValues[`edu_school_${rowIdx}`] || "",
											onChange: (e) => handleFieldChange(`edu_school_${rowIdx}`, e.target.value),
											className: "w-full h-9 rounded-lg border border-gray-200 px-2.5 font-semibold text-xs"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-1.5 border border-gray-200",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											placeholder: "e.g. 2018",
											value: fieldValues[`edu_year_${rowIdx}`] || "",
											onChange: (e) => handleFieldChange(`edu_year_${rowIdx}`, e.target.value),
											className: "w-full h-9 rounded-lg border border-gray-200 px-2.5 font-semibold text-xs"
										})
									})
								]
							}, rowIdx)) })]
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white rounded-2xl border border-[#DCE5F0] p-5 shadow-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 mb-4 p-2 bg-[#E8F5E9] rounded-xl text-[#1E5631]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-black text-sm",
							children: "4. Work Experience (If Any)"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "Farming Experience *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-3",
							children: ["Fresher", "Experienced"].map((exp) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => handleFieldChange("farmingExperience", exp),
								className: `flex-1 h-11 rounded-xl border text-xs font-extrabold transition-colors ${fieldValues["farmingExperience"] === exp ? "bg-[#1E5631] text-white border-[#1E5631]" : "bg-white text-gray-700 border-[#DCE5F0] hover:bg-gray-50"}`,
								children: exp
							}, exp))
						})] }), fieldValues["farmingExperience"] === "Experienced" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "If Experienced, Years *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							placeholder: "e.g. 3 Years / 5 Years",
							value: fieldValues["experiencedYears"] || "",
							onChange: (e) => handleFieldChange("experiencedYears", e.target.value),
							className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#1E5631]"
						})] })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white rounded-2xl border border-[#DCE5F0] p-5 shadow-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 mb-4 p-2 bg-[#E8F5E9] rounded-xl text-[#1E5631]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sprout, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
								className: "font-black text-sm",
								children: "5. Skills (Select if applicable)"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								"Crop Cultivation",
								"Tractor Driving",
								"Irrigation",
								"Use of Machinery",
								"Other"
							].map((skill) => {
								const isChecked = skillsSelected.includes(skill);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => handleSkillsToggle(skill),
									className: `px-3.5 py-2 rounded-xl border text-xs font-extrabold flex items-center gap-1.5 transition-colors ${isChecked ? "bg-[#1E5631] text-white border-[#1E5631]" : "bg-white text-gray-700 border-[#DCE5F0] hover:bg-gray-50"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: isChecked,
										readOnly: true,
										className: "size-3.5 accent-white pointer-events-none"
									}), skill]
								}, skill);
							})
						}),
						skillsSelected.includes("Other") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							placeholder: "Specify other farming skills...",
							value: fieldValues["otherSkills"] || "",
							onChange: (e) => handleFieldChange("otherSkills", e.target.value),
							className: "mt-3 w-full h-10 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#1E5631]"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white rounded-2xl border border-[#DCE5F0] p-5 shadow-xs space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 mb-2 p-2 bg-[#E8F5E9] rounded-xl text-[#1E5631]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
								className: "font-black text-sm",
								children: "6. Declaration"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3 p-3 bg-gray-50 rounded-xl border border-gray-200",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								id: "farmingDeclaration",
								required: true,
								checked: !!fieldValues["declarationConfirmed"],
								onChange: (e) => handleFieldChange("declarationConfirmed", e.target.checked),
								className: "mt-1 size-4 accent-[#1E5631] cursor-pointer"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "farmingDeclaration",
								className: "text-xs font-bold text-[#10233F] cursor-pointer select-none leading-relaxed",
								children: "I hereby declare that the information given above is true and correct to the best of my knowledge."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 md:grid-cols-2 gap-4 pt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "Date"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								readOnly: true,
								value: (/* @__PURE__ */ new Date()).toLocaleDateString(),
								className: "w-full h-10 rounded-xl bg-gray-100 border border-[#DCE5F0] px-3.5 text-xs font-bold text-gray-700"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "Signature (Applicant Full Name) *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								required: true,
								placeholder: "Type your full name as signature",
								value: fieldValues["digitalSignature"] || "",
								onChange: (e) => handleFieldChange("digitalSignature", e.target.value),
								className: "w-full h-10 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#1E5631]"
							})] })]
						})
					]
				})
			]
		});
	}
	if (isHospitalCategory) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 mt-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-[#063B78] text-white p-4 sm:p-5 rounded-2xl flex items-center justify-between shadow-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-10 rounded-xl bg-white/10 flex items-center justify-center text-[#FFC400]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeartPulse, { className: "size-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-black text-base sm:text-lg text-white",
						children: "Hospital Job Application Form"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-blue-100 font-medium",
						children: "Official Healthcare & Medical Recruitment Protocol"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "px-3 py-1 bg-white/20 rounded-full text-xs font-bold uppercase text-white",
					children: "Hospital Category"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white rounded-2xl border border-[#DCE5F0] p-5 shadow-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 mb-4 p-2 bg-[#EBF1F8] rounded-xl text-[#063B78]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-black text-sm",
						children: "1. Personal Information"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "First Name *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							required: true,
							placeholder: "First Name",
							value: fieldValues["firstName"] || "",
							onChange: (e) => handleFieldChange("firstName", e.target.value),
							className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "Last Name *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							required: true,
							placeholder: "Last Name",
							value: fieldValues["lastName"] || "",
							onChange: (e) => handleFieldChange("lastName", e.target.value),
							className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "Date of Birth *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							required: true,
							value: fieldValues["dob"] || "",
							onChange: (e) => handleFieldChange("dob", e.target.value),
							className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "Gender *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-2",
							children: [
								"Male",
								"Female",
								"Other"
							].map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => handleFieldChange("gender", g),
								className: `flex-1 h-11 rounded-xl border text-xs font-extrabold transition-colors ${fieldValues["gender"] === g ? "bg-[#063B78] text-white border-[#063B78]" : "bg-white text-gray-700 border-[#DCE5F0] hover:bg-gray-50"}`,
								children: g
							}, g))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "Marital Status"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: fieldValues["maritalStatus"] || "",
							onChange: (e) => handleFieldChange("maritalStatus", e.target.value),
							className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Select Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Single",
									children: "Single"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Married",
									children: "Married"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Divorced",
									children: "Divorced"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Widowed",
									children: "Widowed"
								})
							]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "Nationality"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							placeholder: "e.g. Indian",
							value: fieldValues["nationality"] || "Indian",
							onChange: (e) => handleFieldChange("nationality", e.target.value),
							className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "md:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "Blood Group"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: fieldValues["bloodGroup"] || "",
								onChange: (e) => handleFieldChange("bloodGroup", e.target.value),
								className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Select Blood Group"
								}), [
									"A+",
									"A-",
									"B+",
									"B-",
									"AB+",
									"AB-",
									"O+",
									"O-"
								].map((bg) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: bg,
									children: bg
								}, bg))]
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white rounded-2xl border border-[#DCE5F0] p-5 shadow-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 mb-4 p-2 bg-[#EBF1F8] rounded-xl text-[#063B78]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-black text-sm",
						children: "2. Contact Information"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "Mobile Number *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "tel",
							required: true,
							placeholder: "+91 98220 00000",
							value: fieldValues["mobileNumber"] || fieldValues["mobile"] || "",
							onChange: (e) => handleFieldChange("mobileNumber", e.target.value),
							className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "Email Address *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "email",
							required: true,
							placeholder: "name@hospital.com",
							value: fieldValues["emailAddress"] || fieldValues["email"] || "",
							onChange: (e) => handleFieldChange("emailAddress", e.target.value),
							className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "md:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "Current Address *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								required: true,
								rows: 2,
								placeholder: "Street address, locality, area...",
								value: fieldValues["currentAddress"] || "",
								onChange: (e) => handleFieldChange("currentAddress", e.target.value),
								className: "w-full rounded-xl border border-[#DCE5F0] p-3 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "City *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							required: true,
							placeholder: "e.g. Pune / Mumbai",
							value: fieldValues["city"] || "",
							onChange: (e) => handleFieldChange("city", e.target.value),
							className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "PIN Code *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							required: true,
							placeholder: "411001",
							value: fieldValues["pinCode"] || "",
							onChange: (e) => handleFieldChange("pinCode", e.target.value),
							className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						})] })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white rounded-2xl border border-[#DCE5F0] p-5 shadow-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 mb-4 p-2 bg-[#EBF1F8] rounded-xl text-[#063B78]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-black text-sm",
						children: "3. Job Details"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "Applying For Position *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							required: true,
							placeholder: "e.g. Staff Nurse / Resident Doctor / Lab Technician",
							value: fieldValues["applyingForPosition"] || "",
							onChange: (e) => handleFieldChange("applyingForPosition", e.target.value),
							className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "Department"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: fieldValues["department"] || "",
							onChange: (e) => handleFieldChange("department", e.target.value),
							className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Select Department"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Nursing",
									children: "Nursing"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "ICU / CCU",
									children: "ICU / CCU"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "OPD / Emergency",
									children: "OPD / Emergency"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Pathology / Lab",
									children: "Pathology / Lab"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Radiology",
									children: "Radiology"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Surgery / OT",
									children: "Surgery / OT"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Pharmacy",
									children: "Pharmacy"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Physiotherapy",
									children: "Physiotherapy"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Hospital Admin",
									children: "Hospital Administration"
								})
							]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "Employment Type *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [
								"Full Time",
								"Part Time",
								"Contract",
								"Internship"
							].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => handleFieldChange("employmentType", t),
								className: `h-10 rounded-xl border text-[11px] font-extrabold transition-colors ${fieldValues["employmentType"] === t ? "bg-[#063B78] text-white border-[#063B78]" : "bg-white text-gray-700 border-[#DCE5F0]"}`,
								children: t
							}, t))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "Preferred Shift *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [
								"Day Shift",
								"Night Shift",
								"Rotational Shift",
								"Flexible"
							].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => handleFieldChange("preferredShift", s),
								className: `h-10 rounded-xl border text-[11px] font-extrabold transition-colors ${fieldValues["preferredShift"] === s ? "bg-[#063B78] text-white border-[#063B78]" : "bg-white text-gray-700 border-[#DCE5F0]"}`,
								children: s
							}, s))
						})] })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white rounded-2xl border border-[#DCE5F0] p-5 shadow-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 mb-4 p-2 bg-[#EBF1F8] rounded-xl text-[#063B78]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-black text-sm",
						children: "4. Educational Qualification"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 md:grid-cols-4 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "Qualification *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							required: true,
							placeholder: "e.g. MBBS / GNM / B.Sc Nursing / DMLT",
							value: fieldValues["qualification"] || "",
							onChange: (e) => handleFieldChange("qualification", e.target.value),
							className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "College / University Name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							placeholder: "College / University Name",
							value: fieldValues["collegeName"] || "",
							onChange: (e) => handleFieldChange("collegeName", e.target.value),
							className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "Passing Year *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							required: true,
							placeholder: "e.g. 2022",
							value: fieldValues["passingYear"] || "",
							onChange: (e) => handleFieldChange("passingYear", e.target.value),
							className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "Percentage / Grade"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							placeholder: "e.g. 78% / First Class",
							value: fieldValues["percentageGrade"] || "",
							onChange: (e) => handleFieldChange("percentageGrade", e.target.value),
							className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						})] })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white rounded-2xl border border-[#DCE5F0] p-5 shadow-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 mb-4 p-2 bg-[#EBF1F8] rounded-xl text-[#063B78]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-black text-sm",
						children: "5. Professional Experience"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 md:grid-cols-2 gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "Are you a Fresher or Experienced? *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-2",
								children: ["Fresher", "Experienced"].map((exp) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => handleFieldChange("fresherOrExperienced", exp),
									className: `flex-1 h-11 rounded-xl border text-xs font-extrabold transition-colors ${fieldValues["fresherOrExperienced"] === exp ? "bg-[#063B78] text-white border-[#063B78]" : "bg-white text-gray-700 border-[#DCE5F0]"}`,
									children: exp
								}, exp))
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F] mb-1",
								children: "Total Experience"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								placeholder: "e.g. 3 Years 6 Months",
								value: fieldValues["totalExperience"] || "",
								onChange: (e) => handleFieldChange("totalExperience", e.target.value),
								className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
							})] })]
						}),
						fieldValues["fresherOrExperienced"] === "Experienced" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 bg-gray-50 rounded-xl border border-gray-200 grid grid-cols-1 md:grid-cols-4 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[11px] font-extrabold text-[#10233F] mb-1",
									children: "Previous Hospital / Org"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									placeholder: "Hospital Name",
									value: fieldValues["previousHospital"] || "",
									onChange: (e) => handleFieldChange("previousHospital", e.target.value),
									className: "w-full h-10 rounded-lg border border-[#DCE5F0] px-3 text-xs font-bold"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[11px] font-extrabold text-[#10233F] mb-1",
									children: "Job Position"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									placeholder: "e.g. Staff Nurse",
									value: fieldValues["previousJobPosition"] || "",
									onChange: (e) => handleFieldChange("previousJobPosition", e.target.value),
									className: "w-full h-10 rounded-lg border border-[#DCE5F0] px-3 text-xs font-bold"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[11px] font-extrabold text-[#10233F] mb-1",
									children: "From (Year)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									placeholder: "2020",
									value: fieldValues["experienceFromYear"] || "",
									onChange: (e) => handleFieldChange("experienceFromYear", e.target.value),
									className: "w-full h-10 rounded-lg border border-[#DCE5F0] px-3 text-xs font-bold"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[11px] font-extrabold text-[#10233F] mb-1",
									children: "To (Year)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									placeholder: "2023",
									value: fieldValues["experienceToYear"] || "",
									onChange: (e) => handleFieldChange("experienceToYear", e.target.value),
									className: "w-full h-10 rounded-lg border border-[#DCE5F0] px-3 text-xs font-bold"
								})] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "Clinical / Medical Skills *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							required: true,
							placeholder: "e.g. Patient Care, ICU Monitoring, IV Administration, Phlebotomy, OT Assistance",
							value: fieldValues["clinicalMedicalSkills"] || "",
							onChange: (e) => handleFieldChange("clinicalMedicalSkills", e.target.value),
							className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						})] })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white rounded-2xl border border-[#DCE5F0] p-5 shadow-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 mb-4 p-2 bg-[#EBF1F8] rounded-xl text-[#063B78]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-black text-sm",
						children: "6. Medical Registration (If Applicable)"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "block text-xs font-extrabold text-[#10233F] mb-1",
						children: "Medical Registration Number"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "text",
						placeholder: "e.g. MMC-12345 / MNC-67890",
						value: fieldValues["medicalRegistrationNumber"] || "",
						onChange: (e) => handleFieldChange("medicalRegistrationNumber", e.target.value),
						className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "block text-xs font-extrabold text-[#10233F] mb-1",
						children: "Registration Council"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "text",
						placeholder: "e.g. Maharashtra Medical Council / Nursing Council",
						value: fieldValues["registrationCouncil"] || "",
						onChange: (e) => handleFieldChange("registrationCouncil", e.target.value),
						className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
					})] })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white rounded-2xl border border-[#DCE5F0] p-5 shadow-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 mb-4 p-2 bg-[#EBF1F8] rounded-xl text-[#063B78]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-black text-sm",
						children: "7. Documents Upload"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
					children: [
						{
							key: "resume",
							label: "Resume / CV *",
							req: true,
							accept: ".pdf,.doc,.docx"
						},
						{
							key: "educationalCertificates",
							label: "Educational Certificates",
							req: false,
							accept: ".pdf,.jpg,.png"
						},
						{
							key: "passportSizePhoto",
							label: "Passport Size Photo",
							req: false,
							accept: ".jpg,.png"
						},
						{
							key: "medicalRegistrationCertificate",
							label: "Medical Registration Certificate",
							req: false,
							accept: ".pdf,.jpg,.png"
						}
					].map((doc) => {
						const fileName = fieldValues[doc.key];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-extrabold text-[#10233F]",
								children: doc.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `border-2 border-dashed ${fileName ? "border-emerald-500 bg-emerald-50" : "border-[#DCE5F0] hover:border-[#063B78] hover:bg-[#F5F8FC]"} rounded-xl p-3 flex flex-col items-center justify-center text-center transition-colors relative h-24`,
								children: [fileName ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-7 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600 mb-1",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-black text-emerald-700 truncate max-w-[90%]",
									children: fileName
								})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudUpload, { className: "size-5 text-[#063B78] mb-1" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[11px] font-semibold text-[#5B6B7F]",
									children: ["Upload ", doc.label.split("*")[0]]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									required: doc.req && !fileName,
									accept: doc.accept,
									onChange: (e) => handleFieldChange(doc.key, e.target.files?.[0]?.name),
									className: "absolute inset-0 opacity-0 cursor-pointer w-full h-full"
								})]
							})]
						}, doc.key);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white rounded-2xl border border-[#DCE5F0] p-5 shadow-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 mb-4 p-2 bg-[#EBF1F8] rounded-xl text-[#063B78]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-black text-sm",
						children: "8. Salary & Availability"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 md:grid-cols-3 gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "Expected Monthly Salary (₹) *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							required: true,
							placeholder: "e.g. ₹25,000 / month",
							value: fieldValues["expectedMonthlySalary"] || "",
							onChange: (e) => handleFieldChange("expectedMonthlySalary", e.target.value),
							className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "Available Joining Date *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							required: true,
							value: fieldValues["availableJoiningDate"] || "",
							onChange: (e) => handleFieldChange("availableJoiningDate", e.target.value),
							className: "w-full h-11 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "Willing to Relocate? *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-2",
							children: ["Yes", "No"].map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => handleFieldChange("willingToRelocate", w),
								className: `flex-1 h-11 rounded-xl border text-xs font-extrabold transition-colors ${fieldValues["willingToRelocate"] === w ? "bg-[#063B78] text-white border-[#063B78]" : "bg-white text-gray-700 border-[#DCE5F0]"}`,
								children: w
							}, w))
						})] })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white rounded-2xl border border-[#DCE5F0] p-5 shadow-xs space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 mb-2 p-2 bg-[#EBF1F8] rounded-xl text-[#063B78]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-black text-sm",
							children: "9. Declaration"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-3 p-3 bg-gray-50 rounded-xl border border-gray-200",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							id: "declaration",
							required: true,
							checked: !!fieldValues["declarationConfirmed"],
							onChange: (e) => handleFieldChange("declarationConfirmed", e.target.checked),
							className: "mt-1 size-4 accent-[#063B78] cursor-pointer"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "declaration",
							className: "text-xs font-bold text-[#10233F] cursor-pointer select-none leading-relaxed",
							children: "I confirm that the information provided above is accurate and complete to the best of my knowledge."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-4 pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "Date"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							readOnly: true,
							value: (/* @__PURE__ */ new Date()).toLocaleDateString(),
							className: "w-full h-10 rounded-xl bg-gray-100 border border-[#DCE5F0] px-3.5 text-xs font-bold text-gray-700"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-extrabold text-[#10233F] mb-1",
							children: "Applicant Full Name / Digital Signature *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							required: true,
							placeholder: "Type your full name as signature",
							value: fieldValues["digitalSignature"] || "",
							onChange: (e) => handleFieldChange("digitalSignature", e.target.value),
							className: "w-full h-10 rounded-xl border border-[#DCE5F0] px-3.5 text-xs font-bold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						})] })]
					})
				]
			})
		]
	});
	const groupedFields = groupFieldsBySection(appConfig.fields);
	const renderField = (fieldKey, req) => {
		if (req === "hidden") return null;
		const isReq = req === "required";
		const label = fieldKey.replace(/([A-Z])/g, " $1").trim().replace(/^./, (str) => str.toUpperCase());
		if (fieldKey === "resume" || fieldKey === "profilePhoto" || fieldKey.toLowerCase().includes("certificate") || fieldKey.toLowerCase().includes("proof") || fieldKey.toLowerCase().includes("portfolio")) {
			const fileName = fieldValues[fieldKey];
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm font-extrabold text-[#10233F]",
					children: [
						label,
						" ",
						isReq && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-red-500",
							children: "*"
						}),
						" ",
						req === "optional" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-gray-400 font-normal text-xs",
							children: "(Optional)"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `border-2 border-dashed ${fileName ? "border-emerald-500 bg-emerald-50" : "border-[#DCE5F0] hover:border-[#125BB5] hover:bg-[#F5F8FC]"} rounded-xl p-4 flex flex-col items-center justify-center text-center transition-colors relative h-28`,
					children: [fileName ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-8 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600 mb-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-black text-emerald-700 truncate max-w-[90%]",
							children: fileName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] font-bold text-emerald-600/70 mt-0.5",
							children: "Click to change file"
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						fieldKey === "profilePhoto" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-6 text-[#125BB5] mb-1" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudUpload, { className: "size-6 text-[#125BB5] mb-1" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] font-semibold text-[#5B6B7F]",
							children: "Click to upload or drag and drop"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[9px] text-[#8695A7] mt-0.5",
							children: fieldKey === "profilePhoto" ? "JPG, PNG (Max 2MB)" : "PDF, DOC, DOCX (Max 5MB)"
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						required: isReq && !fileName,
						onChange: (e) => handleFieldChange(fieldKey, e.target.files?.[0]?.name),
						className: "absolute inset-0 opacity-0 cursor-pointer w-full h-full",
						title: fileName || "Upload file"
					})]
				})]
			}, fieldKey);
		}
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm font-extrabold text-[#10233F]",
				children: [
					label,
					" ",
					isReq && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-red-500",
						children: "*"
					})
				]
			}), fieldKey === "experience" || fieldKey === "relevantExperience" || fieldKey === "totalExperience" || fieldKey === "totalWorkExperience" || fieldKey === "teachingExperience" || fieldKey === "salesExperience" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				required: isReq,
				value: fieldValues[fieldKey] || "",
				onChange: (e) => handleFieldChange(fieldKey, e.target.value),
				className: "w-full h-12 rounded-xl border border-[#DCE5F0] bg-white px-4 text-sm font-semibold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Select Experience"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "Fresher",
						children: "Fresher"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "1-3 Years",
						children: "1 - 3 Years"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "3-5 Years",
						children: "3 - 5 Years"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "5+ Years",
						children: "5+ Years"
					})
				]
			}) : fieldKey === "availability" || fieldKey === "noticePeriod" || fieldKey === "joiningAvailability" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "date",
				required: isReq,
				value: fieldValues[fieldKey] || "",
				onChange: (e) => handleFieldChange(fieldKey, e.target.value),
				className: "w-full h-12 rounded-xl border border-[#DCE5F0] bg-white px-4 text-sm font-semibold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
			}) : fieldKey === "willingToRelocate" || fieldKey === "fieldSalesExperience" || fieldKey === "travelWillingness" || fieldKey === "onlineTeachingExperience" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				required: isReq,
				value: fieldValues[fieldKey] || "",
				onChange: (e) => handleFieldChange(fieldKey, e.target.value),
				className: "w-full h-12 rounded-xl border border-[#DCE5F0] bg-white px-4 text-sm font-semibold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Select"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "Yes",
						children: "Yes"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "No",
						children: "No"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: fieldKey.toLowerCase().includes("email") ? "email" : fieldKey.toLowerCase().includes("mobile") || fieldKey.toLowerCase().includes("phone") ? "tel" : "text",
				required: isReq,
				placeholder: `Enter ${label.toLowerCase()}`,
				value: fieldValues[fieldKey] || "",
				onChange: (e) => handleFieldChange(fieldKey, e.target.value),
				className: "w-full h-12 rounded-xl border border-[#DCE5F0] bg-white px-4 text-sm font-semibold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
			})]
		}, fieldKey);
	};
	const renderSection = (title, icon, fieldsObj, number) => {
		if (Object.keys(fieldsObj).length === 0) return null;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 mb-4 p-2 bg-[#EBF1F8] rounded-lg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[#125BB5]",
					children: icon
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "text-[#125BB5] font-extrabold text-sm",
					children: [
						number,
						". ",
						title
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-5",
				children: Object.keys(fieldsObj).map((k) => renderField(k, fieldsObj[k] || ""))
			})]
		});
	};
	let sectionCounter = 1;
	const showInfo = (category || "").toLowerCase().includes("construct") || (category || "").toLowerCase().includes("mason") || (category || "").toLowerCase().includes("manufactur") || (category || "").toLowerCase().includes("helper");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 mt-4",
		children: [
			renderSection("Personal Details", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-5" }), groupedFields.personal, sectionCounter++),
			renderSection("Work Details", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-5" }), groupedFields.work, sectionCounter++),
			renderSection("Salary", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-5" }), groupedFields.salary, sectionCounter++),
			appConfig.customQuestions && appConfig.customQuestions.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 mb-4 p-2 bg-[#EBF1F8] rounded-lg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[#125BB5]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "text-[#125BB5] font-extrabold text-sm",
						children: [sectionCounter++, ". Job Specific Questions"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-5",
					children: appConfig.customQuestions.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "col-span-1 md:col-span-2 space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-extrabold text-[#10233F]",
							children: [
								q.question,
								" ",
								q.required && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-red-500",
									children: "*"
								})
							]
						}), q.type === "long" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							required: q.required,
							value: customAnswers[q.id] || "",
							onChange: (e) => handleCustomChange(q.id, e.target.value),
							className: "w-full rounded-xl border border-[#DCE5F0] bg-white p-4 text-sm font-semibold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]",
							rows: 3
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							required: q.required,
							value: customAnswers[q.id] || "",
							onChange: (e) => handleCustomChange(q.id, e.target.value),
							className: "w-full h-12 rounded-xl border border-[#DCE5F0] bg-white px-4 text-sm font-semibold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						})]
					}, q.id))
				})]
			}),
			renderSection("Documents", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-5" }), groupedFields.documents, sectionCounter++),
			showInfo && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-[#F5F8FC] rounded-xl p-4 flex gap-3 border border-[#DCE5F0] mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-5 text-[#125BB5] shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "font-extrabold text-[#063B78] text-sm",
					children: "Important"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold text-[#5B6B7F] mt-1",
					children: "Resume is not compulsory for Construction Labour, Helper, Mason and similar worker-level jobs."
				})] })]
			})
		]
	});
};
var companyDatabase = {
	"L&T Construction": {
		name: "Larsen & Toubro (L&T) Construction",
		industry: "Engineering & Heavy Construction",
		founded: "1938",
		size: "50,000+ Employees",
		headquarters: "Mumbai, Maharashtra",
		rating: "4.6",
		reviewsCount: "12,450+",
		website: "https://www.larsentoubro.com",
		aboutMr: "L&T Construction ही भारतातील सर्वात मोठी आणि जागतिक स्तरावरील अव्वल दर्जाची इन्फ्रास्ट्रक्चर व अभियांत्रिकी कंपनी आहे. कंपनी मेट्रो, पूल, हायवे आणि मोठ्या कमर्शियल प्रोजेक्ट्सचे काम करते.",
		aboutEn: "L&T Construction is India's largest infrastructure engineering & construction conglomerate with landmark global mega-projects.",
		trustBadges: [
			"GST Verified Employer",
			"ISO 9001 Certified",
			"Govt Infrastructure Partner",
			"Top Employer 2026"
		],
		perksMr: [
			"PF + ESIC वैद्यकीय विमा",
			"मोफत कॅन्टीन व वाहतूक सुविधा",
			"वार्षिक दिवाळी व परफॉर्मन्स बोनस",
			"साइट निवास व्यवस्था (Accommodation)"
		],
		perksEn: [
			"PF + ESIC Medical Insurance",
			"Subsidized Canteen & Transport",
			"Annual Performance Bonus",
			"Site Accommodation Provided"
		],
		jobDescMr: "साइट ऑपरेशन, क्वालिटी कंट्रोल, प्रोग्रेस ट्रॅकिंग आणि सुरक्षा नियमांचे पालन करून बांधकाम प्रकल्प वेळेत पूर्ण करण्याची जबाबदारी राहील.",
		jobDescEn: "Responsible for site execution, quality assurance, safety protocol compliance, and structural progress tracking.",
		skills: [
			"Civil Engineering",
			"Site Safety",
			"AutoCAD",
			"Project Management",
			"Quality Inspection"
		]
	},
	"Shapoorji Pallonji": {
		name: "Shapoorji Pallonji & Co. Ltd.",
		industry: "Real Estate & Construction",
		founded: "1865",
		size: "35,000+ Employees",
		headquarters: "Mumbai, Maharashtra",
		rating: "4.5",
		reviewsCount: "8,900+",
		website: "https://www.shapoorjipallonji.com",
		aboutMr: "१५० वर्षांपेक्षा जास्त समृद्ध वारसा असणारी Shapoorji Pallonji ग्रुप ही भारतातील प्रीमियर रिअल इस्टेट व कन्स्ट्रक्शन कंपनी आहे.",
		aboutEn: "Shapoorji Pallonji is a 150+ year old premier Indian conglomerate operating in construction, real estate, and infrastructure.",
		trustBadges: [
			"A+ Govt Rated",
			"GST Registered",
			"Safety Certified 2026"
		],
		perksMr: [
			"आरोग्य विमा",
			"ओव्हरटाइम अलाउन्स",
			"तांत्रिक प्रशिक्षण"
		],
		perksEn: [
			"Health Insurance",
			"Overtime Allowance",
			"Technical Training"
		],
		jobDescMr: "सिव्हिल स्ट्रक्चर तपासणे, साइट लेबर मॅनेजमेंट आणि मटेरियल ऑडिट करणे.",
		jobDescEn: "Site structural inspections, labor management, material audit and daily reporting.",
		skills: [
			"Site Supervision",
			"Structural Safety",
			"Labor Management",
			"Material Testing"
		]
	},
	"TCS": {
		name: "Tata Consultancy Services (TCS)",
		industry: "IT & Software Services",
		founded: "1968",
		size: "600,000+ Employees",
		headquarters: "Mumbai, Maharashtra",
		rating: "4.7",
		reviewsCount: "45,000+",
		website: "https://www.tcs.com",
		aboutMr: "टाटा समूहाची TCS ही जगातील अग्रगण्य आयटी सर्व्हिसेस, कन्सलटिंग आणि बिझनेस सोल्युशन्स देणारी कंपनी आहे.",
		aboutEn: "TCS is a global leader in IT services, consulting & business solutions partnering with top Fortune 500 enterprises.",
		trustBadges: [
			"Global Top Employer",
			"Tata Group Brand",
			"100% Tax Compliant"
		],
		perksMr: [
			"हायब्रिड / WFH पर्याय",
			"कुटुंब आरोग्य विमा (₹5 लाख)",
			"TCS Xplore लर्निंग कोर्सेस",
			"कॅब पिक & ड्रॉप"
		],
		perksEn: [
			"Hybrid / Remote Work",
			"Family Health Cover (₹5L)",
			"TCS Upskilling Programs",
			"Cab Drop Service"
		],
		jobDescMr: "एंटरप्राइज सॉफ्टवेअर डिझाइन करणे, रिॲक्ट/जावा कोडिंग, एपीआय इंटिग्रेशन आणि बग फिक्सिंग करणे.",
		jobDescEn: "Design and implement enterprise Web apps, React/Node microservices, API integrations, and code optimization.",
		skills: [
			"React",
			"Node.js",
			"Java / Python",
			"SQL / NoSQL",
			"Git"
		]
	},
	"Infosys": {
		name: "Infosys Limited",
		industry: "IT & Next-Gen Digital Services",
		founded: "1981",
		size: "300,000+ Employees",
		headquarters: "Bengaluru, Karnataka",
		rating: "4.6",
		reviewsCount: "38,000+",
		website: "https://www.infosys.com",
		aboutMr: "इन्फोसिस ही डिजिटल ट्रान्सफॉर्मेशन आणि सॉफ्टवेअर सोल्यूशन्स देणारी भारतातील अव्वल जागतिक कंपनी आहे.",
		aboutEn: "Infosys is a global leader in next-generation digital services and consulting.",
		trustBadges: [
			"Listed on NYSE",
			"Top Employer India",
			"Verified Recruiter"
		],
		perksMr: [
			"वर्क फ्रॉम होम फ्लेक्सिबिलिटी",
			"वार्षिक अप्र Appraisals",
			"इन्फोसिस स्प्रिंगबोर्ड लर्निंग"
		],
		perksEn: [
			"Work From Home Flexibility",
			"Annual Performance Appraisal",
			"Infosys Springboard Learning"
		],
		jobDescMr: "वेब व मोबाईल ॲप्लिकेशन डेव्हलपमेंट, फ्रंटएंड आणि युझर एक्सपिरियन्स डिझाइन.",
		jobDescEn: "Develop responsive web interfaces, frontend logic, component integration and cloud deployment.",
		skills: [
			"React.js",
			"TypeScript",
			"Tailwind CSS",
			"REST API",
			"UI Testing"
		]
	},
	"Tata Motors": {
		name: "Tata Motors Commercial & Passenger Vehicles",
		industry: "Automobile & Manufacturing",
		founded: "1945",
		size: "80,000+ Employees",
		headquarters: "Pune / Mumbai, Maharashtra",
		rating: "4.7",
		reviewsCount: "18,200+",
		website: "https://www.tatamotors.com",
		aboutMr: "टाटा मोटर्स ही भारतातील सर्वात मोठी ऑटोमोबाईल उत्पादक कंपनी असून EV (इलेक्ट्रिक व्हेईकल) क्षेत्रात क्रांती घडवत आहे.",
		aboutEn: "Tata Motors is India's pioneer automotive manufacturer leading the Electric Vehicle revolution.",
		trustBadges: [
			"Make in India Pioneer",
			"Tata Trust Certified",
			"ISO 14001 Compliant"
		],
		perksMr: [
			"कंपनी बस सेवा (पुणे/पिंपरी)",
			"कॅन्टीन भोजन सवलत",
			"मेडिक्लेम व ग्रॅच्युइटी"
		],
		perksEn: [
			"Free Factory Bus Service",
			"Subsidized Canteen Meals",
			"Mediclaim & Gratuity"
		],
		jobDescMr: "असेंब्ली लाईन प्रोडक्शन, मेकॅनिकल कंपोनंट टेस्टिंग आणि क्वालिटी अश्युरन्स तपासणे.",
		jobDescEn: "Assembly line oversight, mechanical testing, vehicle quality audit and production throughput.",
		skills: [
			"Mechanical Engineering",
			"Production Planning",
			"Quality Inspection",
			"AutoCAD / CATIA"
		]
	},
	"Ruby Hall Clinic": {
		name: "Grant Medical Foundation - Ruby Hall Clinic",
		industry: "Healthcare & Multispecialty Hospital",
		founded: "1959",
		size: "4,500+ Staff",
		headquarters: "Pune, Maharashtra",
		rating: "4.8",
		reviewsCount: "5,600+",
		website: "https://www.rubyhall.com",
		aboutMr: "रुबी हॉल क्लिनिक हे पुण्यातील सर्वात प्रख्यात आणि NABH मान्यताप्राप्त मल्टीस्पेशालिटी हॉस्पिटल आहे.",
		aboutEn: "Ruby Hall Clinic is a premier NABH-accredited multispecialty tertiary care hospital in Maharashtra.",
		trustBadges: [
			"NABH Accredited Hospital",
			"Govt Health Partner",
			"Top Healthcare Brand"
		],
		perksMr: [
			"कर्मचारी व कुटुंब मोफत रुग्णालय उपचार",
			"नाईट शिफ्ट अलाउन्स",
			"नर्सिंग क्वार्टर्स"
		],
		perksEn: [
			"Free Hospital Care for Staff",
			"Night Shift Allowance",
			"Nursing Quarters"
		],
		jobDescMr: "पेशंट केअर, आयसीयू ऑब्झर्व्हेशन, डॉक्टर असिस्टन्स आणि मेडिकल रेकॉर्ड्स मेंटेन करणे.",
		jobDescEn: "Patient nursing care, ICU monitoring, physician assistance, and clinical documentation.",
		skills: [
			"Patient Nursing",
			"ICU Care",
			"First Aid / CPR",
			"Medical Records"
		]
	},
	"KPMG": {
		name: "KPMG India",
		industry: "Financial Advisory, Audit & Tax",
		founded: "1993",
		size: "20,000+ Professionals",
		headquarters: "Mumbai, Maharashtra",
		rating: "4.6",
		reviewsCount: "9,100+",
		website: "https://home.kpmg/in",
		aboutMr: "केपीएमजी ही जगप्रसिद्ध बिग-४ मधील एक फायनान्शियल ऑडिट, टॅक्स सल्लागार आणि कॉर्पोरेट अकाऊंटिंग कंपनी आहे.",
		aboutEn: "KPMG is one of the Big Four global financial auditing, advisory and accounting firms.",
		trustBadges: [
			"Big 4 Financial Brand",
			"Certified Tax Consultants",
			"Top Corporate Firm"
		],
		perksMr: [
			"उच्च कॉर्पोरेट पगार",
			"वार्षिक इन्सेन्टिव्ह",
			"सीए व फायनान्स स्पॉन्सरशिप"
		],
		perksEn: [
			"High Corporate Pay",
			"Annual Performance Bonus",
			"Finance Certifications Cover"
		],
		jobDescMr: "जीएसटी रिटर्न्स, कॉर्पोरेट टॅक्स ऑडिट, बॅलन्स शीट फायनलायझेशन आणि फायनान्शियल प्लॅनिंग करणे.",
		jobDescEn: "Corporate tax auditing, GST compliance, balance sheet finalization and client risk assessment.",
		skills: [
			"Accounting",
			"GST / Income Tax",
			"Tally Prime",
			"Financial Audit",
			"Excel Mastery"
		]
	},
	"Reliance Industries": {
		name: "Reliance Industries & Digital Services",
		industry: "Conglomerate - Retail, Telecom & Energy",
		founded: "1958",
		size: "350,000+ Employees",
		headquarters: "Mumbai, Maharashtra",
		rating: "4.7",
		reviewsCount: "28,000+",
		website: "https://www.ril.com",
		aboutMr: "रिलायन्स इंडस्ट्रिज ही भारतातील सर्वात मोठी प्रायव्हेट कंपनी असून रिटेल, टेलिकॉम (Jio) आणि ऊर्जेमध्ये अग्रगण्य आहे.",
		aboutEn: "Reliance Industries Limited is India's largest private sector enterprise spanning Energy, Retail & Digital.",
		trustBadges: [
			"India #1 Fortune 500",
			"GST Registered",
			"Verified Enterprise"
		],
		perksMr: [
			"रिलायन्स रिटेल डिस्काऊंट",
			"मेडिकल इन्शुरन्स (₹4 लाख)",
			"कर्मचारी शेअर योजना"
		],
		perksEn: [
			"Reliance Store Discounts",
			"Comprehensive Medical Cover",
			"Employee Stock Options"
		],
		jobDescMr: "डिजिटल मार्केटिंग कॅम्पेन, सेल्स एक्झिक्युशन, बिझनेस डेव्हलपमेंट आणि कस्टमर ऑनबोर्डिंग.",
		jobDescEn: "Lead digital marketing drives, B2B/B2C sales execution, and market expansion campaigns.",
		skills: [
			"Sales Management",
			"Digital Marketing",
			"Business Development",
			"Client Relationship"
		]
	},
	"Bharat Forge": {
		name: "Bharat Forge Limited (Kalyani Group)",
		industry: "Heavy Engineering & Manufacturing",
		founded: "1961",
		size: "12,000+ Employees",
		headquarters: "Pune, Maharashtra",
		rating: "4.6",
		reviewsCount: "4,200+",
		website: "https://www.bharatforge.com",
		aboutMr: "भारत फोर्ज ही जगातील दुसऱ्या क्रमांकाची सर्वात मोठी ऑटोमोबाईल व एरोस्पेस फोर्जिंग उत्पादक कंपनी आहे.",
		aboutEn: "Bharat Forge is a global engineering leader manufacturing critical automotive & aerospace components.",
		trustBadges: [
			"Defense & Aerospace Approved",
			"ISO 45001",
			"Kalyani Group Brand"
		],
		perksMr: [
			"मोफत कॅन्टीन व चहा",
			"सुरक्षा किट व गणवेश",
			"वार्षिक बोनस व PF"
		],
		perksEn: [
			"Free Canteen & Refreshments",
			"Safety Gear & Uniform",
			"Annual Bonus & PF"
		],
		jobDescMr: "सीएनसी मशीन ऑपरेटिंग, मॅन्युफॅक्चरिंग लाईन सुपरव्हिजन आणि मेटल चाचणी करणे.",
		jobDescEn: "CNC machine operations, metallurgy quality check, and shopfloor production target management.",
		skills: [
			"CNC / VMC Operations",
			"Manufacturing Supervision",
			"Quality Assurance",
			"Plant Safety"
		]
	}
};
function getCompanyMetadata(job) {
	const found = companyDatabase[job.company];
	if (found) return found;
	return {
		name: job.company,
		industry: job.category || "General Industry",
		founded: "2010",
		size: "500+ Employees",
		headquarters: job.location || "Maharashtra, India",
		rating: "4.5",
		reviewsCount: "150+ Reviews",
		website: `https://www.google.com/search?q=${encodeURIComponent(job.company)}`,
		aboutMr: `${job.company} ही ${job.category} क्षेत्रातील अधिकृत आणि नोंदणीकृत कंपनी आहे. कंपनी उच्च दर्जाच्या सेवा आणि रोजगार संधी उपलब्ध करून देते.`,
		aboutEn: `${job.company} is a verified enterprise in the ${job.category} sector providing reliable products, services, and career opportunities.`,
		trustBadges: [
			"GST Registered Employer",
			"REAL JOB Verified",
			"Government Compliant"
		],
		perksMr: [
			"PF + ESIC सुविधा",
			"नियमित पगार व बोनस",
			"कामाचे सुरक्षित वातावरण"
		],
		perksEn: [
			"PF + ESIC Benefits",
			"Timely Salary & Bonus",
			"Safe Working Environment"
		],
		jobDescMr: `${job.title} या पदासाठी मुख्य जबाबदाऱ्यांमध्ये दैनिक कामकाज, टीम वर्क आणि दिलेल्या उद्दिष्टांची पूर्तता करणे समाविष्ट आहे.`,
		jobDescEn: `Primary duties for ${job.title} include daily operational execution, teamwork, and target milestone completion.`,
		skills: [
			job.category,
			"Teamwork",
			"Problem Solving",
			"Domain Expertise"
		]
	};
}
var jobs = [];
function JobCard({ job, onApply }) {
	const { t, n, lang } = useI18n();
	const currentUser = dataStore.getCurrentUser();
	const [saved, setSaved] = (0, import_react.useState)(() => {
		if (!currentUser || !currentUser.id) return false;
		return dataStore.getSavedJobs(currentUser.id).some((s) => s.jobId === job.id);
	});
	const [showApplyModal, setShowApplyModal] = (0, import_react.useState)(false);
	const [showCompanyModal, setShowCompanyModal] = (0, import_react.useState)(false);
	const [activeModalTab, setActiveModalTab] = (0, import_react.useState)("company");
	const [applied, setApplied] = (0, import_react.useState)(() => {
		if (!currentUser || !currentUser.id) return false;
		return dataStore.getJobSeekerApplications(currentUser.id).some((a) => a.jobId === job.id);
	});
	const handleSaveToggle = () => {
		if (!currentUser || !currentUser.id) {
			toast.error(lang === "mr" ? "नोकरी सेव्ह करण्यासाठी लॉग इन करा" : "Please log in to save jobs");
			return;
		}
		if (saved) {
			dataStore.removeSavedJob(currentUser.id, job.id);
			setSaved(false);
			toast.success(lang === "mr" ? "नोकरी सेव्हड लिस्टमधून काढली" : "Job removed from saved list");
		} else {
			dataStore.saveJob(currentUser.id, job.id);
			setSaved(true);
			toast.success(lang === "mr" ? "नोकरी सेव्ह केली" : "Job saved successfully");
		}
	};
	(0, import_react.useEffect)(() => {
		if (!showApplyModal && !showCompanyModal) return;
		const originalStyle = window.getComputedStyle(document.body).overflow;
		document.body.style.overflow = "hidden";
		return () => {
			document.body.style.overflow = originalStyle;
		};
	}, [showApplyModal, showCompanyModal]);
	const [fieldValues, setFieldValues] = (0, import_react.useState)({});
	const [customAnswers, setCustomAnswers] = (0, import_react.useState)({});
	const appConfig = job.applicationConfig || getFallbackConfig(job.category);
	const companyMeta = getCompanyMetadata(job);
	const handleApplyClick = (e) => {
		e.stopPropagation();
		if (onApply) onApply(job);
		else setShowApplyModal(true);
	};
	const [copied, setCopied] = (0, import_react.useState)(false);
	const handleShareClick = (e) => {
		e.stopPropagation();
		setCopied(true);
		if (typeof navigator !== "undefined" && navigator.clipboard) navigator.clipboard.writeText(window.location.href);
		setTimeout(() => setCopied(false), 2e3);
	};
	const openModalTab = (tab) => {
		setActiveModalTab(tab);
		setShowCompanyModal(true);
	};
	const submitApplication = (e) => {
		e.preventDefault();
		const currentUser = dataStore.getCurrentUser();
		const seekerId = currentUser ? currentUser.id || currentUser.email || "seeker-demo" : fieldValues["email"] || "candidate@realjob.com";
		const seekerName = fieldValues["fullName"] || fieldValues["candidateName"] || currentUser?.fullName || "Candidate Applicant";
		const userMobile = (seekerId ? dataStore.findRegisteredAccount(seekerId) : null)?.mobile || currentUser?.mobile || "";
		const seekerMobile = fieldValues["mobile"] || fieldValues["phone"] || fieldValues["candidateMobile"] || fieldValues["mobileNumber"] || fieldValues["contactNumber"] || fieldValues["phoneNo"] || fieldValues["mobileNo"] || userMobile;
		if (dataStore.hasAlreadyApplied(seekerId, job.id)) {
			toast.error(lang === "mr" ? "तुम्ही या नोकरीसाठी आधीच अर्ज भरला आहे!" : "You have already applied to this job!");
			setShowApplyModal(false);
			return;
		}
		try {
			dataStore.createApplication({
				jobId: job.id,
				employerId: job.company,
				jobSeekerId: seekerId,
				candidateName: seekerName,
				candidateEmail: fieldValues["email"] || seekerId,
				candidateMobile: seekerMobile,
				jobTitle: job.title,
				companyName: job.company,
				location: job.location,
				salary: job.salary,
				resume: fieldValues["resume"] || `${seekerName.replaceAll(" ", "_")}_Resume.pdf`,
				fieldValues,
				customAnswers,
				category: job.category
			});
			setApplied(true);
			toast.success(lang === "mr" ? "अर्ज यशस्वीरीत्या पाठवला!" : "Application submitted successfully!");
			setTimeout(() => {
				setShowApplyModal(false);
			}, 2e3);
		} catch (err) {
			toast.error(err.message || "Failed to submit application");
		}
	};
	const companyJobs = jobs.filter((j) => j.company === job.company);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "card-realjob p-5 flex flex-col justify-between group relative overflow-hidden bg-white border border-[#DCE5F0] hover:border-[#063B78]/40 hover:shadow-lg transition-all rounded-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2 mb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5 flex-wrap",
						children: [job.featured && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							className: "bg-[#FFC400] text-[#082F63] font-black text-[10px] uppercase tracking-wider px-2 py-0.5 border-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "mr-1 size-3" }),
								" ",
								lang === "mr" ? "खास संधी" : "Featured"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "outline",
							className: "border-[#063B78]/20 text-[#063B78] font-bold text-[10px] bg-[#063B78]/5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mr-1 size-3 text-emerald-600" }), " GST Verified"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: handleShareClick,
							title: lang === "mr" ? "नोकरी शेअर करा" : "Share Job",
							className: "text-[#5B6B7F] hover:text-[#063B78] p-1.5 rounded-full hover:bg-[#F5F8FC] transition-colors relative",
							children: copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs font-bold text-emerald-600 flex items-center gap-1 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 animate-fade-in",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3" }),
									" ",
									lang === "mr" ? "कॉपी झाली!" : "Copied!"
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: (e) => {
								e.stopPropagation();
								handleSaveToggle();
							},
							"aria-label": "Save Job",
							title: lang === "mr" ? "नोकरी सेव्ह करा" : "Save Job",
							className: "text-[#5B6B7F] hover:text-[#063B78] p-1.5 rounded-full hover:bg-[#F5F8FC] transition-colors",
							children: saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[#063B78] font-bold text-xs flex items-center gap-1 bg-[#063B78]/10 px-2 py-0.5 rounded-full",
								children: "★ Saved"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[#5B6B7F] text-xs flex items-center gap-1 px-1.5",
								children: "☆ Save"
							})
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: companyMeta.website,
						target: "_blank",
						rel: "noopener noreferrer",
						title: `${companyMeta.name} ची अधिकृत वेबसाईट उघडा (${companyMeta.website})`,
						className: "grid size-12 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-[#063B78] to-[#082F63] font-black text-white text-base shadow-sm hover:scale-105 transition-transform",
						children: job.initials
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								onClick: () => openModalTab("job"),
								title: lang === "mr" ? "नोकरीचे सविस्तर स्वरूप (Job Details) पाहा" : "View Full Job Details",
								className: "font-display text-base sm:text-lg font-black text-[#10233F] hover:text-[#063B78] hover:underline cursor-pointer transition-colors line-clamp-1",
								children: job.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: companyMeta.website,
								target: "_blank",
								rel: "noopener noreferrer",
								title: `${companyMeta.name} ची अधिकृत वेबसाईट उघडा`,
								className: "mt-0.5 inline-flex items-center gap-1.5 text-xs font-bold text-[#125BB5] hover:underline",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3.5 text-[#063B78]" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate",
										children: job.company
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3.5 text-emerald-600 shrink-0" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[10px] font-black text-[#FFC400] bg-[#082F63] px-1.5 py-0.2 rounded-full",
										children: ["★ ", companyMeta.rating]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3 text-[#125BB5] shrink-0" })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 flex items-center gap-2 text-xs font-semibold text-[#5B6B7F]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => openModalTab("job"),
									className: "inline-flex items-center gap-1 hover:text-[#063B78] hover:underline",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5 text-[#063B78]" }),
										" ",
										job.location
									]
								})
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid grid-cols-2 gap-3 rounded-xl bg-[#F5F8FC] p-3 border border-[#DCE5F0]/50",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						onClick: () => openModalTab("job"),
						className: "flex items-center gap-2.5 cursor-pointer hover:opacity-80 transition-opacity",
						title: lang === "mr" ? "पगार व नोकरीचे तपशील पाहा" : "View Salary Details",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid size-8 shrink-0 place-items-center rounded-lg bg-[#063B78]/10 text-[#063B78]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[9px] font-bold uppercase text-[#5B6B7F] truncate",
								children: lang === "mr" ? "सुरुवातीचा पगार" : "Starting Salary"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs sm:text-sm font-black text-[#063B78] truncate",
								children: n(job.salary)
							})]
						})]
					}), job.openings && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						onClick: () => openModalTab("openings"),
						className: "flex items-center gap-2.5 border-l border-[#DCE5F0] pl-3 cursor-pointer hover:opacity-80 transition-opacity",
						title: lang === "mr" ? "या कंपनीतील इतर सर्व जागा पाहा" : "View Active Openings",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid size-8 shrink-0 place-items-center rounded-lg bg-[#FFC400]/20 text-[#082F63]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[9px] font-bold uppercase text-[#5B6B7F] truncate",
								children: lang === "mr" ? "एकूण जागा" : "Openings"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs sm:text-sm font-black text-[#10233F] truncate",
								children: [
									n(job.openings),
									"+ ",
									lang === "mr" ? "शिल्लक" : "Vacancies"
								]
							})]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap items-center gap-2 relative z-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1 rounded-lg bg-[#063B78]/5 px-2 py-1 text-[10px] sm:text-[11px] font-bold text-[#063B78] whitespace-nowrap",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { className: "size-3" }),
								" ",
								job.type
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "inline-flex items-center gap-1 rounded-lg bg-[#063B78]/5 px-2 py-1 text-[10px] sm:text-[11px] font-bold text-[#063B78] whitespace-nowrap",
							children: job.workMode
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1 rounded-lg bg-[#063B78]/5 px-2 py-1 text-[10px] sm:text-[11px] font-bold text-[#063B78] whitespace-nowrap",
							children: [
								lang === "mr" ? "अनुभव" : "Exp",
								": ",
								n(job.experience)
							]
						}),
						companyMeta.skills.slice(0, 2).map((skill, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => openModalTab("job"),
							title: `View ${skill} requirement details`,
							className: "inline-flex items-center gap-1 rounded-lg bg-[#FFC400]/15 border border-[#FFC400]/30 hover:bg-[#FFC400] transition-colors px-2 py-1 text-[10px] sm:text-[11px] font-black text-[#082F63] whitespace-nowrap",
							children: skill
						}, idx))
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex items-center justify-between gap-2 border-t border-[#DCE5F0] pt-4 relative z-20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						className: "h-9 text-xs font-black border-[#063B78]/30 text-[#063B78] hover:bg-[#063B78] hover:text-white rounded-xl shadow-2xs px-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: companyMeta.website,
							target: "_blank",
							rel: "noopener noreferrer",
							title: `${companyMeta.name} ची अधिकृत वेबसाईट उघडा (${companyMeta.website})`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building, { className: "mr-1.5 size-3.5" }),
								lang === "mr" ? "कंपनी वेबसाईट" : "Company Website",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "ml-1 size-3" })
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: handleApplyClick,
						className: "btn-yellow h-9 px-5 font-black text-xs shadow-sm rounded-xl",
						children: [
							t("apply"),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "ml-1.5 size-3" })
						]
					})]
				})
			]
		}),
		showCompanyModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-50 flex items-center justify-center bg-[#082F63]/70 backdrop-blur-md p-4 animate-in fade-in duration-200",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative w-full max-w-3xl rounded-3xl border border-[#DCE5F0] bg-white shadow-2xl overflow-hidden flex flex-col max-h-[90vh]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-gradient-to-r from-[#063B78] via-[#082F63] to-[#125BB5] p-6 text-white relative",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setShowCompanyModal(false),
								className: "absolute right-4 top-4 grid size-8 place-items-center rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid size-16 shrink-0 place-items-center rounded-2xl bg-white font-black text-[#063B78] text-2xl shadow-lg border-2 border-[#FFC400]",
									children: job.initials
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1 min-w-0 pr-8",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 flex-wrap",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] font-black uppercase tracking-wider bg-[#FFC400] text-[#082F63] px-2 py-0.5 rounded-full",
												children: companyMeta.industry
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-xs font-bold text-emerald-300 flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4" }), " Real Job Verified Employer"]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-xl sm:text-2xl font-black text-white truncate",
											children: companyMeta.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 text-xs font-bold text-slate-200 flex-wrap",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-1",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5 text-[#FFC400]" }),
														" ",
														companyMeta.headquarters
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-1 text-[#FFC400]",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-3.5 fill-[#FFC400]" }),
														" ",
														companyMeta.rating,
														" / 5.0 (",
														companyMeta.reviewsCount,
														")"
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Est. ", companyMeta.founded] })
											]
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 mt-6 border-b border-white/20",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setActiveModalTab("company"),
										className: `pb-2.5 px-3 text-xs sm:text-sm font-black transition-all border-b-2 ${activeModalTab === "company" ? "border-[#FFC400] text-[#FFC400]" : "border-transparent text-white/70 hover:text-white"}`,
										children: ["🏢 ", lang === "mr" ? "कंपनी पार्श्वभूमी" : "Company Profile"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setActiveModalTab("job"),
										className: `pb-2.5 px-3 text-xs sm:text-sm font-black transition-all border-b-2 ${activeModalTab === "job" ? "border-[#FFC400] text-[#FFC400]" : "border-transparent text-white/70 hover:text-white"}`,
										children: ["📋 ", lang === "mr" ? "नोकरी सविस्तर माहिती" : "Job Details"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setActiveModalTab("openings"),
										className: `pb-2.5 px-3 text-xs sm:text-sm font-black transition-all border-b-2 ${activeModalTab === "openings" ? "border-[#FFC400] text-[#FFC400]" : "border-transparent text-white/70 hover:text-white"}`,
										children: [
											"🚀 ",
											lang === "mr" ? "इतर जागा" : "Active Openings",
											" (",
											companyJobs.length,
											")"
										]
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-6 overflow-y-auto space-y-6 flex-1 text-[#10233F]",
						children: [
							activeModalTab === "company" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-6 animate-fade-in",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "text-xs font-black uppercase text-[#5B6B7F] tracking-wider mb-2",
										children: lang === "mr" ? "विश्वासार्हता आणि प्रमाणपत्रे" : "Verification Badges"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap items-center gap-2",
										children: companyMeta.trustBadges.map((badge, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "inline-flex items-center gap-1.5 rounded-xl bg-emerald-50 border border-emerald-200 px-3 py-1.5 text-xs font-black text-emerald-800",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-emerald-600" }), badge]
										}, idx))
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
										className: "text-sm font-black text-[#063B78] mb-2 flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4 text-[#063B78]" }), lang === "mr" ? "कंपनीबद्दल थोडक्यात (About Company)" : "About Company"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs sm:text-sm font-semibold leading-relaxed text-[#5B6B7F] bg-[#F5F8FC] p-4 rounded-2xl border border-[#DCE5F0]",
										children: lang === "mr" ? companyMeta.aboutMr : companyMeta.aboutEn
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 sm:grid-cols-4 gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-3 rounded-xl bg-[#F5F8FC] border border-[#DCE5F0]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
													children: "कर्मचारी संख्या"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-black text-[#063B78]",
													children: companyMeta.size
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-3 rounded-xl bg-[#F5F8FC] border border-[#DCE5F0]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
													children: "स्थापना वर्ष"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-xs font-black text-[#063B78]",
													children: ["वर्ष ", companyMeta.founded]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-3 rounded-xl bg-[#F5F8FC] border border-[#DCE5F0]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
													children: "मुख्यालय"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-black text-[#063B78] truncate block",
													children: companyMeta.headquarters
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-3 rounded-xl bg-[#F5F8FC] border border-[#DCE5F0]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
													children: "वेबसाईट"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
													href: companyMeta.website,
													target: "_blank",
													rel: "noreferrer",
													className: "text-xs font-black text-[#125BB5] hover:underline flex items-center gap-1",
													children: ["Visit Site ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3" })]
												})]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
										className: "text-sm font-black text-[#063B78] mb-2 flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "size-4 text-[#FFC400]" }), lang === "mr" ? "कामगारांना मिळणाऱ्या सुविधा (Employee Benefits & Perks)" : "Employee Perks"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
										children: (lang === "mr" ? companyMeta.perksMr : companyMeta.perksEn).map((perk, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 p-2.5 rounded-xl bg-[#EBF1F8] text-xs font-bold text-[#063B78]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "size-4 text-[#063B78] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: perk })]
										}, idx))
									})] })
								]
							}),
							activeModalTab === "job" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-6 animate-fade-in",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4 rounded-2xl bg-[#063B78]/5 border border-[#063B78]/15 space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-base font-black text-[#063B78]",
											children: job.title
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-center gap-4 text-xs font-bold text-[#5B6B7F]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["💰 Salary: ", job.salary] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["📍 Location: ", job.location] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["💼 Exp: ", job.experience] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
													"🕒 Type: ",
													job.type,
													" (",
													job.workMode,
													")"
												] })
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
										className: "text-sm font-black text-[#063B78] mb-2 flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4 text-[#063B78]" }), lang === "mr" ? "कामाचे स्वरूप आणि जबाबदाऱ्या" : "Job Description & Duties"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs sm:text-sm font-semibold leading-relaxed text-[#5B6B7F] bg-[#F5F8FC] p-4 rounded-2xl border border-[#DCE5F0]",
										children: lang === "mr" ? companyMeta.jobDescMr : companyMeta.jobDescEn
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
										className: "text-sm font-black text-[#063B78] mb-2 flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-4 text-[#063B78]" }), lang === "mr" ? "आवश्यक कौशल्ये (Required Skills)" : "Required Skills"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap gap-2",
										children: companyMeta.skills.map((skill, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "px-3 py-1 rounded-xl bg-[#063B78] text-white text-xs font-bold shadow-2xs",
											children: skill
										}, idx))
									})] })
								]
							}),
							activeModalTab === "openings" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-4 animate-fade-in",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
									className: "text-xs font-black uppercase text-[#5B6B7F] tracking-wider",
									children: [
										companyMeta.name,
										" ",
										lang === "mr" ? "मधील इतर सर्व नोकऱ्या" : "Active Vacancies"
									]
								}), companyJobs.map((cj) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl border border-[#DCE5F0] bg-[#F5F8FC] flex items-center justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
										className: "font-black text-sm text-[#10233F]",
										children: cj.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs font-semibold text-[#5B6B7F] mt-0.5",
										children: [
											cj.location,
											" • ",
											cj.salary,
											" • ",
											cj.experience
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										onClick: () => {
											setShowCompanyModal(false);
											setShowApplyModal(true);
										},
										className: "btn-yellow h-8 px-4 font-black text-xs rounded-xl shrink-0",
										children: ["Apply ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "ml-1 size-3" })]
									})]
								}, cj.id))]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 bg-[#F5F8FC] border-t border-[#DCE5F0] flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-bold text-[#5B6B7F]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: lang === "mr" ? "थेट HR पडताळणी पूर्ण झालेली कंपनी" : "Verified HR Direct Recruiter" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setShowCompanyModal(false),
								className: "h-10 text-xs font-bold px-4 rounded-xl border-[#DCE5F0]",
								children: lang === "mr" ? "बंद करा" : "Close"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => {
									setShowCompanyModal(false);
									setShowApplyModal(true);
								},
								className: "btn-yellow h-10 px-6 font-black text-xs rounded-xl shadow-md",
								children: [
									t("apply"),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "ml-1.5 size-3.5" })
								]
							})]
						})]
					})
				]
			})
		}),
		showApplyModal && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "fixed inset-0 z-[100] flex flex-col bg-[#F5F8FC] overflow-y-auto animate-in fade-in duration-200",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white border-b border-[#DCE5F0] sticky top-0 z-10 px-4 sm:px-8 py-3 flex items-center justify-between shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-8 rounded-xl bg-gradient-to-br from-[#125BB5] to-[#063B78] flex items-center justify-center text-white font-black shadow-md",
						children: "J"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-black text-[#082F63] text-xl tracking-tight hidden sm:block",
						children: "JobPortal"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setShowApplyModal(false),
					className: "flex items-center gap-2 px-4 py-2 rounded-xl bg-[#F5F8FC] text-[#5B6B7F] hover:text-[#10233F] hover:bg-[#EBF1F8] font-bold text-sm transition-colors",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }),
						" ",
						lang === "mr" ? "बंद करा" : "Close"
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 w-full max-w-7xl mx-auto px-4 py-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col lg:flex-row gap-8 items-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 w-full bg-white rounded-3xl border border-[#DCE5F0] p-6 sm:p-10 shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-3xl font-black text-[#082F63] mb-2",
								children: lang === "mr" ? "नोकरीसाठी अर्ज करा" : "Apply for Job"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[#5B6B7F] font-semibold text-sm mb-8",
								children: lang === "mr" ? "खालील माहिती काळजीपूर्वक भरा." : "Fill in the details below to apply for this job. Make sure all information is correct."
							}),
							applied ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center py-12",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-20 text-[#063B78] mx-auto mb-4 animate-bounce" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-2xl font-black text-[#10233F]",
										children: lang === "mr" ? "अर्ज यशस्वीरीत्या पाठवला!" : "Application Submitted!"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold text-[#5B6B7F] mt-2 max-w-md mx-auto",
										children: lang === "mr" ? "तुमचा अर्ज कंपनीला पाठवण्यात आला आहे. ते लवकरच तुमच्याशी संपर्क साधतील." : "Your application has been sent to the employer. They will contact you shortly."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										onClick: () => setShowApplyModal(false),
										className: "btn-yellow h-12 px-8 font-black text-sm mt-8 rounded-xl",
										children: lang === "mr" ? "मागे जा" : "Go Back"
									})
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: submitApplication,
								className: "space-y-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DynamicApplicationForm, {
									appConfig,
									fieldValues,
									setFieldValues,
									customAnswers,
									setCustomAnswers,
									lang,
									category: job.category
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-8 flex justify-end gap-4 mt-8",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										onClick: () => setShowApplyModal(false),
										variant: "outline",
										className: "h-12 px-8 font-bold text-sm rounded-xl border-[#DCE5F0] text-[#5B6B7F]",
										children: lang === "mr" ? "रद्द करा" : "Cancel"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "submit",
										className: "btn-yellow h-12 px-8 font-black text-sm shadow-md rounded-xl",
										children: [
											lang === "mr" ? "अंतिम अर्ज सादर करा" : "Submit Application",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "ml-2 size-4" })
										]
									})]
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-full lg:w-[400px] shrink-0 bg-white rounded-3xl border border-[#DCE5F0] p-6 shadow-sm sticky top-24 hidden lg:block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between mb-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-14 place-items-center rounded-2xl bg-[#063B78] font-black text-white text-xl shadow-md",
									children: job.initials
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: "outline",
									className: "bg-emerald-50 text-emerald-700 border-emerald-200 font-bold px-3 py-1 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5" }), "Active"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-2xl font-black text-[#10233F] mb-2",
								children: job.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2 mb-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm font-bold text-[#125BB5] flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building, { className: "size-4" }),
										" ",
										job.company
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm font-semibold text-[#5B6B7F] flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" }),
										" ",
										job.location
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "inline-block px-3 py-1 bg-[#EBF1F8] text-[#125BB5] text-xs font-bold rounded-lg mb-6",
								children: job.category || "General"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-3 items-start",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-8 rounded-full bg-[#F5F8FC] flex items-center justify-center shrink-0",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4 text-[#5B6B7F]" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-bold text-[#5B6B7F]",
											children: "Experience Required"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-black text-[#10233F]",
											children: job.experience
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-3 items-start",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-8 rounded-full bg-[#F5F8FC] flex items-center justify-center shrink-0",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-4 text-[#5B6B7F]" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-bold text-[#5B6B7F]",
											children: "Salary"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-black text-[#10233F]",
											children: job.salary
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-3 items-start",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-8 rounded-full bg-[#F5F8FC] flex items-center justify-center shrink-0",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-4 text-[#5B6B7F]" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-bold text-[#5B6B7F]",
											children: "Vacancies"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-black text-[#10233F]",
											children: job.vacancies || 1
										})] })]
									})
								]
							})
						]
					})]
				})
			})]
		})
	] });
}
//#endregion
export { jobs as a, getFallbackConfig as i, JobCard as n, getCompanyMetadata as r, DynamicApplicationForm as t };
