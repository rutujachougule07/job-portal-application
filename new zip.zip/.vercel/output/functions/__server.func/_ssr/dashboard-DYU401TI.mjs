import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button--9UiOy7A.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as dataStore } from "./data-store-BCcScpg-.mjs";
import { Bt as Building2, O as Settings, Rt as Calendar, Ut as Bookmark, Vt as Briefcase, W as MapPin, _t as FileText, c as User } from "../_libs/lucide-react.mjs";
import { t as Route } from "./dashboard-B4qN4F-O.mjs";
import { t as UserSidebarLayout } from "./UserSidebarLayout-6xsUOBQ5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-DYU401TI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function UserDashboard() {
	const navigate = useNavigate();
	const activeTab = Route.useSearch().tab || "overview";
	const [user, setUser] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const currentUser = dataStore.getCurrentUser();
		if (!currentUser) navigate({
			to: "/auth",
			search: {
				mode: "login",
				role: "worker"
			}
		});
		else setUser(currentUser);
	}, [navigate]);
	if (!user) return null;
	const applications = dataStore.getJobSeekerApplications(user.id);
	const savedJobs = dataStore.getSavedJobs(user.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(UserSidebarLayout, {
		activeTab,
		children: [
			activeTab === "overview" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "text-3xl sm:text-4xl font-black text-[#10233F] tracking-tight",
						children: [
							"Welcome back, ",
							user.fullName?.split(" ")[0],
							"! 👋"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[#5B6B7F] font-semibold mt-2",
						children: "Here is what's happening with your job search today."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 sm:grid-cols-3 gap-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 rounded-2xl shadow-sm border border-[#DCE5F0] flex flex-col justify-between group hover:shadow-md transition-shadow",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "size-12 bg-blue-50 group-hover:bg-blue-100 transition-colors rounded-xl flex items-center justify-center text-[#063B78]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-6" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-bold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-full",
										children: "All time"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-3xl font-black text-[#10233F]",
									children: applications.length
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-semibold text-[#5B6B7F] mt-1",
									children: "Applied Jobs"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 rounded-2xl shadow-sm border border-[#DCE5F0] flex flex-col justify-between group hover:shadow-md transition-shadow",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "size-12 bg-yellow-50 group-hover:bg-yellow-100 transition-colors rounded-xl flex items-center justify-center text-[#D97706]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-6" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-bold text-yellow-700 bg-yellow-50 px-2.5 py-1 rounded-full",
										children: "Saved"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-3xl font-black text-[#10233F]",
									children: savedJobs.length
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-semibold text-[#5B6B7F] mt-1",
									children: "Saved Jobs"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 rounded-2xl shadow-sm border border-[#DCE5F0] flex flex-col justify-between group hover:shadow-md transition-shadow",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "size-12 bg-green-50 group-hover:bg-green-100 transition-colors rounded-xl flex items-center justify-center text-green-600",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-6" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-bold text-green-700 bg-green-50 px-2.5 py-1 rounded-full",
										children: "This week"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-3xl font-black text-[#10233F]",
									children: "12"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-semibold text-[#5B6B7F] mt-1",
									children: "Profile Views"
								})] })]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white rounded-2xl shadow-sm border border-[#DCE5F0] overflow-hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-6 sm:px-8 border-b border-[#DCE5F0] flex items-center justify-between bg-gray-50/50",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-xl font-black text-[#10233F]",
								children: "Recent Applications"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "ghost",
								size: "sm",
								className: "text-[#063B78] font-bold text-xs hover:bg-blue-50",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/dashboard",
									search: { tab: "applied" },
									children: "View All Applications"
								})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-2 sm:p-4",
							children: applications.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center py-12 px-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "size-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4 border border-gray-100",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-10 text-gray-400" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-lg font-black text-[#10233F]",
										children: "No applications yet"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-[#5B6B7F] mt-2 mb-6 max-w-sm mx-auto",
										children: "You haven't applied to any jobs yet. Browse our job listings to find your next great opportunity!"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										className: "bg-[#063B78] hover:bg-[#082F63] text-white font-bold h-11 px-6 rounded-xl shadow-md hover:shadow-lg transition-all",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/jobs",
											children: "Browse Jobs Now"
										})
									})
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-3",
								children: applications.slice(0, 4).map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 sm:p-5 rounded-xl border border-gray-100 hover:border-[#B8D3F2] hover:bg-[#F8FAFC] transition-all group",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-4 min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-14 bg-white rounded-xl shadow-xs flex items-center justify-center border border-gray-100 shrink-0",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-7 text-gray-400" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
													className: "font-black text-base text-[#10233F] truncate",
													children: app.jobTitle
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm font-semibold text-[#5B6B7F] truncate",
													children: app.companyName
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-4 mt-2 text-xs font-semibold text-gray-500",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "flex items-center gap-1.5",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5 text-gray-400" }),
															" ",
															app.location
														]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "flex items-center gap-1.5",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-3.5 text-gray-400" }),
															" Applied: ",
															app.appliedDate
														]
													})]
												})
											]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between sm:justify-end gap-4 shrink-0 sm:border-l sm:border-gray-100 sm:pl-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "inline-flex items-center px-3 py-1.5 rounded-lg text-xs font-black bg-[#EBF1F8] text-[#063B78] border border-[#B8D3F2]",
											children: app.status
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											asChild: true,
											size: "sm",
											variant: "outline",
											className: "opacity-100 sm:opacity-0 group-hover:opacity-100 transition-opacity text-xs font-bold h-9 border-gray-200 hover:bg-white hover:text-[#063B78]",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
												to: "/jobs/$jobId",
												params: { jobId: app.jobId },
												children: "View Job"
											})
										})]
									})]
								}, app.id))
							})
						})]
					})
				]
			}),
			activeTab === "applied" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6 animate-in fade-in duration-500",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-3xl font-black text-[#10233F]",
					children: "Applied Jobs History"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bg-white rounded-2xl shadow-sm border border-[#DCE5F0] p-6 sm:p-8",
					children: applications.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center py-12",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[#5B6B7F] font-semibold text-lg",
							children: "You haven't applied to any jobs yet."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							className: "mt-6 bg-[#063B78] hover:bg-[#082F63] text-white",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/jobs",
								children: "Find Jobs to Apply"
							})
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-4",
						children: applications.map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-xl border border-gray-100 bg-gray-50/30 hover:bg-white hover:border-[#B8D3F2] hover:shadow-sm transition-all",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-black text-[#10233F] text-lg",
									children: app.jobTitle
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm font-semibold text-[#5B6B7F] mt-1",
									children: [
										app.companyName,
										" • ",
										app.location
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "shrink-0 flex flex-col sm:items-end gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-block px-3 py-1.5 rounded-lg text-xs font-black bg-[#EBF1F8] text-[#063B78] border border-[#B8D3F2]",
									children: ["Status: ", app.status]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold text-gray-500",
									children: ["Applied on ", app.appliedDate]
								})]
							})]
						}, app.id))
					})
				})]
			}),
			(activeTab === "saved" || activeTab === "profile" || activeTab === "settings") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6 animate-in fade-in duration-500",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-3xl font-black text-[#10233F] capitalize",
					children: activeTab
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white rounded-2xl shadow-sm border border-[#DCE5F0] p-12 text-center flex flex-col items-center justify-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "inline-flex items-center justify-center size-20 bg-blue-50 rounded-full mb-5 text-[#063B78]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-10" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xl font-black text-[#10233F] mb-3",
							children: "Module Coming Soon"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[#5B6B7F] font-medium max-w-md mx-auto",
							children: [
								"The ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "capitalize font-bold text-[#10233F]",
									children: activeTab
								}),
								" section is currently under development. Our team is working hard to bring you these features soon."
							]
						})
					]
				})]
			})
		]
	});
}
//#endregion
export { UserDashboard as component };
