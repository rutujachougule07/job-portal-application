import { n as EmployerDashboard } from "./Dashboards-Za5rUmr5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/employer-B0B7Y7pd.js
var SplitComponent = EmployerDashboard;
//#endregion
export { SplitComponent as component };
