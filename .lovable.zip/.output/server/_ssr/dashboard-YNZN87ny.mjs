import { a as SeekerDashboard } from "./Dashboards-Za5rUmr5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-YNZN87ny.js
var SplitComponent = SeekerDashboard;
//#endregion
export { SplitComponent as component };
