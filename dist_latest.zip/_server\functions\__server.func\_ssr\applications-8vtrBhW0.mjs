import { t as ApplicationsPage } from "./Dashboards-Bp9jvLIp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/applications-8vtrBhW0.js
var SplitComponent = ApplicationsPage;
//#endregion
export { SplitComponent as component };
