import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { D as ShieldCheck, Jt as ChevronDown, R as Plus, S as Sparkles, V as PenLine, b as SquarePen, d as UserPlus, g as Trash2, n as X, t as Zap, zt as Clock } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/employer.employees-Dl3DZiJd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function parseTimeStringToMinutes(timeStr) {
	if (!timeStr) return null;
	const match = timeStr.trim().toUpperCase().match(/^(\d{1,2}):(\d{2})\s*(AM|PM)?$/);
	if (!match || !match[1] || !match[2]) return null;
	let hours = parseInt(match[1], 10);
	const minutes = parseInt(match[2], 10);
	const meridiem = match[3];
	if (meridiem) {
		if (meridiem === "PM" && hours < 12) hours += 12;
		if (meridiem === "AM" && hours === 12) hours = 0;
	}
	return hours * 60 + minutes;
}
function computeHoursFromTimes(startStr, endStr) {
	if (!startStr || !endStr) return 9;
	const start = parseTimeStringToMinutes(startStr);
	const end = parseTimeStringToMinutes(endStr);
	if (start !== null && end !== null && end > start) {
		const diff = end - start;
		return Math.round(diff / 60 * 10) / 10;
	}
	return 9;
}
var DEFAULT_CATEGORIES = [
	"💻 Software Developer / Engineer",
	"🎨 UI/UX Designer",
	"📊 Data Analyst",
	"📞 BPO / Call Center Executive",
	"📈 Sales & Marketing",
	"👥 HR & Administration",
	"🛎️ System Admin / IT Support",
	"💼 Project Manager",
	"🌱 Plant Nursery & Care",
	"🚜 Tractor & Machinery",
	"⚡ Electrical & Wiring",
	"🧱 Masonry & Brickwork",
	"⚙️ Machine Operator",
	"📦 Packing & Warehouse",
	"💼 Office Staff & Admin"
];
var AddEmployeeModal = ({ isOpen, onClose, onSave, initialData = null, empIdentifier = "admin-001", attendanceMode = "fixed" }) => {
	const [workerForm, setWorkerForm] = (0, import_react.useState)({
		name: "",
		mobile: "",
		trade: "General Worker",
		category: "💻 Software Developer / Engineer",
		education: "",
		dailyRate: "600",
		joiningDate: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
		workShiftStart: "09:00",
		workShiftEnd: "18:00",
		dailyWorkingHours: "9",
		overtimeRate: "67",
		overtimeRateMode: "auto",
		notes: "",
		pin: "1234",
		locationType: "fixed",
		attendanceMode: "punch"
	});
	const [customFields, setCustomFields] = (0, import_react.useState)([]);
	const [showAddFieldPrompt, setShowAddFieldPrompt] = (0, import_react.useState)(false);
	const [newFieldNameInput, setNewFieldNameInput] = (0, import_react.useState)("");
	const [removedStandardFields, setRemovedStandardFields] = (0, import_react.useState)([]);
	const [customCategories, setCustomCategories] = (0, import_react.useState)(() => {
		try {
			const saved = localStorage.getItem(`emp_custom_cats_${empIdentifier}`);
			return saved ? JSON.parse(saved) : [];
		} catch {
			return [];
		}
	});
	const [removedCategories, setRemovedCategories] = (0, import_react.useState)([]);
	const [showOtherCategoryInput, setShowOtherCategoryInput] = (0, import_react.useState)(false);
	const [isCategoryDropdownOpen, setIsCategoryDropdownOpen] = (0, import_react.useState)(false);
	const [newCustomCategoryInput, setNewCustomCategoryInput] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (initialData) {
			setWorkerForm({
				name: initialData.name || "",
				mobile: initialData.mobile || "",
				trade: initialData.trade || "General Worker",
				category: initialData.category || "💻 Software Developer / Engineer",
				education: initialData.education || "",
				dailyRate: initialData.dailyRate ? initialData.dailyRate.toString() : "600",
				joiningDate: initialData.joiningDate || (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
				workShiftStart: initialData.workShiftStart || "09:00",
				workShiftEnd: initialData.workShiftEnd || "18:00",
				dailyWorkingHours: initialData.dailyWorkingHours ? initialData.dailyWorkingHours.toString() : "9",
				overtimeRate: initialData.overtimeRate ? initialData.overtimeRate.toString() : "67",
				overtimeRateMode: initialData.overtimeRateMode || "auto",
				notes: initialData.notes || "",
				pin: initialData.pin || "1234",
				locationType: initialData.locationType || "fixed",
				attendanceMode: initialData.attendanceMode || "punch"
			});
			setCustomFields(initialData.customFields || []);
		} else {
			setWorkerForm({
				name: "",
				mobile: "",
				trade: "General Worker",
				category: "💻 Software Developer / Engineer",
				education: "",
				dailyRate: "600",
				joiningDate: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
				workShiftStart: "09:00",
				workShiftEnd: "18:00",
				dailyWorkingHours: "9",
				overtimeRate: "67",
				overtimeRateMode: "auto",
				notes: "",
				pin: "1234",
				locationType: "fixed",
				attendanceMode: "punch"
			});
			setCustomFields([]);
			setRemovedStandardFields([]);
		}
	}, [initialData, isOpen]);
	if (!isOpen) return null;
	const handleAddCustomCategory = () => {
		const trimmed = newCustomCategoryInput.trim();
		if (!trimmed) return;
		const catName = trimmed.startsWith("✨") ? trimmed : `✨ ${trimmed}`;
		const updated = Array.from(/* @__PURE__ */ new Set([...customCategories, catName]));
		setCustomCategories(updated);
		try {
			localStorage.setItem(`emp_custom_cats_${empIdentifier}`, JSON.stringify(updated));
		} catch {}
		setWorkerForm((p) => ({
			...p,
			category: catName
		}));
		setNewCustomCategoryInput("");
		setShowOtherCategoryInput(false);
	};
	const handleRemoveCategory = (catToRemove) => {
		const updatedCustom = customCategories.filter((c) => c !== catToRemove);
		setCustomCategories(updatedCustom);
		setRemovedCategories((prev) => [...prev, catToRemove]);
		if (workerForm.category === catToRemove) setWorkerForm((p) => ({
			...p,
			category: DEFAULT_CATEGORIES[0] || "General Work"
		}));
	};
	const handleRemoveStandardField = (fieldKey) => {
		setRemovedStandardFields((prev) => [...prev, fieldKey]);
	};
	const handleRestoreStandardField = (fieldKey) => {
		setRemovedStandardFields((prev) => prev.filter((k) => k !== fieldKey));
	};
	const handleOpenAddFieldPrompt = () => {
		setNewFieldNameInput("");
		setShowAddFieldPrompt(true);
	};
	const handleConfirmAddCustomField = (presetName) => {
		const fieldName = (presetName || newFieldNameInput).trim();
		if (!fieldName) return;
		setCustomFields((prev) => [...prev, {
			label: fieldName,
			value: ""
		}]);
		setNewFieldNameInput("");
		setShowAddFieldPrompt(false);
	};
	const handleRemoveCustomField = (index) => {
		setCustomFields((prev) => prev.filter((_, i) => i !== index));
	};
	const handleCustomFieldChange = (index, val) => {
		setCustomFields((prev) => {
			const copy = [...prev];
			if (copy[index]) copy[index] = {
				...copy[index],
				value: val
			};
			return copy;
		});
	};
	const handleSubmit = (e) => {
		e.preventDefault();
		if (!workerForm.name.trim()) return;
		const baseHrsNum = computeHoursFromTimes(workerForm.workShiftStart, workerForm.workShiftEnd);
		const dailyWageNum = Number(workerForm.dailyRate) || 600;
		const workingHrsNum = Number(workerForm.dailyWorkingHours) || baseHrsNum;
		const autoOtRate = baseHrsNum > 0 ? Math.round(dailyWageNum / baseHrsNum) : 67;
		const otRateNum = Number(workerForm.overtimeRate) || autoOtRate;
		onSave({
			...initialData ? { id: initialData.id } : {},
			employerId: empIdentifier,
			employerName: initialData?.employerName || "Alpha Byte",
			name: workerForm.name.trim(),
			mobile: workerForm.mobile.trim(),
			trade: workerForm.trade.trim() || "General Worker",
			category: workerForm.category.trim() || "General",
			dailyRate: dailyWageNum,
			joiningDate: workerForm.joiningDate || (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
			status: "Active",
			workShiftStart: workerForm.workShiftStart,
			workShiftEnd: workerForm.workShiftEnd,
			dailyWorkingHours: workingHrsNum,
			overtimeRate: otRateNum,
			overtimeRateMode: workerForm.overtimeRateMode,
			notes: workerForm.notes.trim(),
			pin: workerForm.pin || "1234",
			locationType: workerForm.locationType,
			attendanceMode: workerForm.attendanceMode,
			customFields: customFields.filter((f) => f.label.trim() !== "")
		});
		onClose();
	};
	const baseShiftHrs = computeHoursFromTimes(workerForm.workShiftStart, workerForm.workShiftEnd);
	const dailyWageNum = Number(workerForm.dailyRate) || 600;
	const autoHourlyRate = baseShiftHrs > 0 ? Math.round(dailyWageNum / baseShiftHrs) : 67;
	const currentWorkingHrs = Number(workerForm.dailyWorkingHours) || baseShiftHrs;
	Math.max(0, Math.round((currentWorkingHrs - baseShiftHrs) * 10) / 10);
	workerForm.overtimeRateMode === "manual" && workerForm.overtimeRate && Number(workerForm.overtimeRate);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bg-white w-full max-w-xl rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-100 relative max-h-[92vh] overflow-y-auto",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					className: "absolute top-5 right-5 text-slate-400 hover:text-slate-700 font-extrabold text-xl p-2 rounded-full hover:bg-slate-100 transition-colors",
					children: "✕"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 pb-4 border-b border-slate-100 pr-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-3 rounded-2xl bg-emerald-50 text-emerald-700 shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-6 text-emerald-600" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xl font-black text-[#10233F]",
							children: initialData ? "Edit Employee Information" : "Add New Employee"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-500 font-semibold mt-0.5",
							children: "Enter employee details, designation, shift timings & custom fields."
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: handleOpenAddFieldPrompt,
						className: "px-3.5 py-2.5 rounded-xl bg-[#063B78] hover:bg-[#0A4F9E] text-white font-extrabold text-xs transition-all flex items-center gap-1.5 shadow-md shrink-0 self-start sm:self-auto cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Add Custom Field"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleSubmit,
					className: "space-y-4",
					children: [
						removedStandardFields.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5 flex-wrap p-2.5 bg-amber-50/80 rounded-2xl border border-amber-200/80 mb-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-extrabold text-amber-800 uppercase tracking-wide mr-1",
									children: "Restore Hidden Fields:"
								}),
								removedStandardFields.includes("trade") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => handleRestoreStandardField("trade"),
									className: "px-2.5 py-1 bg-white hover:bg-emerald-50 hover:text-emerald-700 text-slate-700 font-bold text-xs rounded-lg border border-slate-200 shadow-2xs transition-all",
									children: "+ Role / Designation"
								}),
								removedStandardFields.includes("mobile") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => handleRestoreStandardField("mobile"),
									className: "px-2.5 py-1 bg-white hover:bg-emerald-50 hover:text-emerald-700 text-slate-700 font-bold text-xs rounded-lg border border-slate-200 shadow-2xs transition-all",
									children: "+ Mobile Number"
								}),
								removedStandardFields.includes("joiningDate") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => handleRestoreStandardField("joiningDate"),
									className: "px-2.5 py-1 bg-white hover:bg-emerald-50 hover:text-emerald-700 text-slate-700 font-bold text-xs rounded-lg border border-slate-200 shadow-2xs transition-all",
									children: "+ Joining Date"
								}),
								removedStandardFields.includes("shiftTimes") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => handleRestoreStandardField("shiftTimes"),
									className: "px-2.5 py-1 bg-white hover:bg-emerald-50 hover:text-emerald-700 text-slate-700 font-bold text-xs rounded-lg border border-slate-200 shadow-2xs transition-all",
									children: "+ Work Shift Times"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-extrabold text-slate-700 uppercase mb-1 block",
							children: "EMPLOYEE NAME *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							required: true,
							type: "text",
							placeholder: "e.g. Ramesh Pawar / Vijay Patil",
							value: workerForm.name,
							onChange: (e) => setWorkerForm((p) => ({
								...p,
								name: e.target.value
							})),
							className: "w-full h-11 px-3.5 rounded-xl text-xs font-bold border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mb-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-extrabold text-slate-700 uppercase block",
								children: "DEPARTMENT / CATEGORY *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									setIsCategoryDropdownOpen(true);
									setShowOtherCategoryInput(true);
								},
								className: "text-[#063B78] hover:underline text-[11px] font-bold flex items-center gap-1 cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3" }), " Add Custom Category"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setIsCategoryDropdownOpen((prev) => !prev),
								className: "w-full h-11 px-3.5 rounded-xl text-xs font-bold border border-slate-300 bg-white text-[#10233F] flex items-center justify-between focus:outline-none focus:ring-2 focus:ring-[#063B78] shadow-xs cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate",
									children: workerForm.category || "Select Category"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `size-4 text-slate-400 transition-transform duration-200 ${isCategoryDropdownOpen ? "rotate-180" : ""}` })]
							}), isCategoryDropdownOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute left-0 right-0 top-12 z-50 bg-white border border-slate-200 rounded-2xl shadow-xl max-h-72 overflow-y-auto p-1.5 space-y-0.5",
								children: [[...DEFAULT_CATEGORIES, ...customCategories].filter((c) => !removedCategories.includes(c)).map((catName) => {
									const isSelected = workerForm.category === catName;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										onClick: () => {
											setWorkerForm((p) => ({
												...p,
												category: catName
											}));
											setIsCategoryDropdownOpen(false);
											setShowOtherCategoryInput(false);
										},
										className: `w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold cursor-pointer transition-colors ${isSelected ? "bg-[#063B78] text-white" : "hover:bg-slate-100 text-[#10233F]"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate",
											children: catName
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: (e) => {
												e.stopPropagation();
												handleRemoveCategory(catName);
											},
											className: `p-1 rounded-lg hover:bg-red-500 hover:text-white transition-colors ml-2 shrink-0 ${isSelected ? "text-white/80 hover:text-white" : "text-slate-400 hover:text-red-600"}`,
											title: `Remove category "${catName}"`,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
										})]
									}, catName);
								}), showOtherCategoryInput ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									onClick: (e) => e.stopPropagation(),
									className: "p-2 bg-blue-50/90 rounded-xl border border-blue-200 mt-1 flex items-center gap-1.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											autoFocus: true,
											type: "text",
											placeholder: "Type new category...",
											value: newCustomCategoryInput,
											onChange: (e) => setNewCustomCategoryInput(e.target.value),
											onKeyDown: (e) => {
												if (e.key === "Enter") {
													e.preventDefault();
													handleAddCustomCategory();
												}
											},
											className: "flex-1 h-9 px-2 text-xs font-bold bg-white border border-blue-300 rounded-lg focus:outline-none"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: handleAddCustomCategory,
											className: "px-3 py-2 rounded-lg bg-[#063B78] hover:bg-[#0A4F9E] text-white font-extrabold text-xs shrink-0 cursor-pointer",
											children: "+ Add"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setShowOtherCategoryInput(false),
											className: "p-1 text-slate-400 hover:text-slate-700 text-xs font-bold shrink-0 cursor-pointer",
											children: "✕"
										})
									]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: (e) => {
										e.stopPropagation();
										setShowOtherCategoryInput(true);
									},
									className: "w-full flex items-center gap-2 px-3 py-2.5 rounded-xl text-xs font-black text-[#063B78] hover:bg-blue-50 transition-colors border-t border-slate-100 mt-1 cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "➕ Add New Custom Category..." })]
								})]
							})]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
							children: [!removedStandardFields.includes("trade") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-extrabold text-slate-700 uppercase block",
									children: "ROLE / DESIGNATION"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => handleRemoveStandardField("trade"),
									className: "text-rose-500 hover:text-rose-700 text-[11px] font-bold flex items-center gap-1 hover:bg-rose-50 px-1.5 py-0.5 rounded transition-colors cursor-pointer",
									title: "Remove Field",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), " Remove"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								placeholder: "General Worker",
								value: workerForm.trade,
								onChange: (e) => setWorkerForm((p) => ({
									...p,
									trade: e.target.value
								})),
								className: "w-full h-11 px-3.5 rounded-xl text-xs font-bold border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#063B78]"
							})] }), !removedStandardFields.includes("mobile") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-extrabold text-slate-700 uppercase block",
									children: "MOBILE NUMBER"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => handleRemoveStandardField("mobile"),
									className: "text-rose-500 hover:text-rose-700 text-[11px] font-bold flex items-center gap-1 hover:bg-rose-50 px-1.5 py-0.5 rounded transition-colors cursor-pointer",
									title: "Remove Field",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), " Remove"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								placeholder: "e.g. 9822112233",
								value: workerForm.mobile,
								onChange: (e) => setWorkerForm((p) => ({
									...p,
									mobile: e.target.value
								})),
								className: "w-full h-11 px-3.5 rounded-xl text-xs font-bold border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#063B78]"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 p-4 bg-slate-50/90 rounded-2xl border border-slate-200",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-extrabold text-slate-800 uppercase block tracking-wider",
								children: "WORK LOCATION & ATTENDANCE TYPE (AUTO-DETECTED)"
							}), attendanceMode === "field" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3.5 bg-amber-50 rounded-xl border border-amber-200/90 space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-xs font-black text-amber-950",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-amber-500 animate-pulse shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "🚜 Field / Site Worksite (Auto-Detected: Employer Attendance)" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-amber-900/90 font-medium leading-relaxed",
									children: "Auto-detected from company name. Mobile GPS & selfie punch-in are not required. Daily attendance will be marked directly by employer."
								})]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3.5 bg-blue-50/90 rounded-xl border border-blue-200/90 space-y-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 text-xs font-black text-[#063B78]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-blue-600 animate-pulse shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "📍 Fixed Location Worksite (Auto-Detected: App Punch In/Out)" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] text-blue-900/90 font-medium leading-relaxed",
										children: "Auto-detected from company name. Employee punches in/out via mobile app (GPS + Camera)."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "pt-3 border-t border-blue-200/70",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "text-xs font-extrabold text-slate-700 uppercase mb-1 block",
												children: "EMPLOYEE LOGIN 4-DIGIT PIN *"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												required: true,
												type: "text",
												placeholder: "1234",
												maxLength: 4,
												minLength: 4,
												value: workerForm.pin,
												onChange: (e) => setWorkerForm((p) => ({
													...p,
													pin: e.target.value.replace(/\D/g, "")
												})),
												className: "h-10 w-44 px-3 rounded-xl text-xs font-black border border-slate-300 tracking-widest text-[#063B78] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] text-slate-500 mt-1 font-semibold",
												children: "Employee uses Mobile Number and this 4-digit PIN to login to the app."
											})
										]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-extrabold text-slate-700 uppercase mb-1 block",
								children: "CUSTOM DAILY WAGE RATE (₹) *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								required: true,
								placeholder: "600",
								value: workerForm.dailyRate,
								onChange: (e) => {
									const val = e.target.value;
									setWorkerForm((p) => {
										const next = {
											...p,
											dailyRate: val
										};
										if (p.overtimeRateMode === "auto") {
											const baseHrs = computeHoursFromTimes(p.workShiftStart, p.workShiftEnd);
											const rateNum = Number(val) || 0;
											next.overtimeRate = baseHrs > 0 ? Math.round(rateNum / baseHrs).toString() : "0";
										}
										return next;
									});
								},
								className: "w-full h-11 px-3.5 rounded-xl text-xs font-black border border-slate-300 text-emerald-700 focus:outline-none focus:ring-2 focus:ring-[#063B78]"
							})] }), !removedStandardFields.includes("joiningDate") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-extrabold text-slate-700 uppercase block",
									children: "JOINING DATE"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => handleRemoveStandardField("joiningDate"),
									className: "text-rose-500 hover:text-rose-700 text-[11px] font-bold flex items-center gap-1 hover:bg-rose-50 px-1.5 py-0.5 rounded transition-colors cursor-pointer",
									title: "Remove Field",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), " Remove"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "date",
								value: workerForm.joiningDate,
								onChange: (e) => setWorkerForm((p) => ({
									...p,
									joiningDate: e.target.value
								})),
								className: "w-full h-11 px-3.5 rounded-xl text-xs font-bold border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#063B78]"
							})] })]
						}),
						!removedStandardFields.includes("shiftTimes") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs font-extrabold text-slate-700 uppercase mb-1 flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5 text-[#063B78]" }), " Work Start Time (shift)"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "time",
								value: workerForm.workShiftStart,
								onChange: (e) => {
									const startVal = e.target.value;
									setWorkerForm((p) => {
										const next = {
											...p,
											workShiftStart: startVal
										};
										const newBaseHrs = computeHoursFromTimes(startVal, p.workShiftEnd);
										next.dailyWorkingHours = newBaseHrs.toString();
										if (p.overtimeRateMode === "auto") {
											const rateNum = Number(p.dailyRate) || 600;
											next.overtimeRate = newBaseHrs > 0 ? Math.round(rateNum / newBaseHrs).toString() : "67";
										}
										return next;
									});
								},
								className: "w-full h-11 px-3.5 rounded-xl text-xs font-bold border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#063B78]"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-xs font-extrabold text-slate-700 uppercase flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5 text-[#063B78]" }), " Work End Time (shift)"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => handleRemoveStandardField("shiftTimes"),
									className: "text-rose-500 hover:text-rose-700 text-[11px] font-bold flex items-center gap-1 hover:bg-rose-50 px-1.5 py-0.5 rounded transition-colors cursor-pointer",
									title: "Remove Field",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), " Remove"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "time",
								value: workerForm.workShiftEnd,
								onChange: (e) => {
									const endVal = e.target.value;
									setWorkerForm((p) => {
										const next = {
											...p,
											workShiftEnd: endVal
										};
										const newBaseHrs = computeHoursFromTimes(p.workShiftStart, endVal);
										next.dailyWorkingHours = newBaseHrs.toString();
										if (p.overtimeRateMode === "auto") {
											const rateNum = Number(p.dailyRate) || 600;
											next.overtimeRate = newBaseHrs > 0 ? Math.round(rateNum / newBaseHrs).toString() : "67";
										}
										return next;
									});
								},
								className: "w-full h-11 px-3.5 rounded-xl text-xs font-bold border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#063B78]"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-gradient-to-br from-amber-50/80 via-blue-50/40 to-slate-50 border-2 border-amber-200 shadow-xs space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-2 border-b border-amber-200/80 pb-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "size-7 rounded-lg bg-amber-500 text-white flex items-center justify-center font-black text-xs shadow-xs",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-4 fill-white" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
										className: "text-xs font-black text-[#10233F] uppercase tracking-wide flex items-center gap-1.5",
										children: ["Overtime Hourly Rate (₹ / hr)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "bg-amber-100 text-amber-900 border border-amber-300 font-extrabold text-[10px] px-1.5 py-0 rounded",
											children: workerForm.overtimeRateMode === "auto" ? `⚡ Auto (${dailyWageNum} ÷ ${baseShiftHrs}h = ₹${autoHourlyRate}/hr)` : "✏️ Custom Manual Rate"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[10px] font-bold text-slate-500",
										children: [
											"Daily Wage (₹",
											dailyWageNum,
											") ÷ Shift (",
											baseShiftHrs,
											"h) = ₹",
											autoHourlyRate,
											"/hr default rate."
										]
									})] })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center bg-white p-0.5 rounded-xl border border-amber-300 shadow-2xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											setWorkerForm((p) => ({
												...p,
												overtimeRateMode: "auto",
												overtimeRate: autoHourlyRate.toString()
											}));
										},
										className: `px-2.5 py-1 rounded-lg text-[11px] font-black transition-all flex items-center gap-1 cursor-pointer ${workerForm.overtimeRateMode === "auto" ? "bg-amber-500 text-white shadow-xs" : "text-slate-600 hover:text-slate-900"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-3 fill-current" }), " Auto Calculate"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											setWorkerForm((p) => ({
												...p,
												overtimeRateMode: "manual"
											}));
										},
										className: `px-2.5 py-1 rounded-lg text-[11px] font-black transition-all flex items-center gap-1 cursor-pointer ${workerForm.overtimeRateMode === "manual" ? "bg-[#063B78] text-white shadow-xs" : "text-slate-600 hover:text-slate-900"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "size-3" }), " Manual Rate"]
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "text-[11px] font-extrabold text-slate-700 uppercase flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Overtime Rate (₹ / hr) *" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[10px] text-slate-500 font-bold lowercase",
											children: [
												"(daily wage remains ₹",
												dailyWageNum,
												"/day)"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative max-w-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "absolute left-3 top-1/2 -translate-y-1/2 text-sm font-black text-slate-400",
												children: "₹"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "number",
												placeholder: autoHourlyRate.toString(),
												value: workerForm.overtimeRate,
												onChange: (e) => {
													const val = e.target.value;
													setWorkerForm((p) => ({
														...p,
														overtimeRate: val,
														overtimeRateMode: "manual"
													}));
												},
												className: `w-full h-11 pl-8 pr-16 rounded-xl text-sm font-black border ${workerForm.overtimeRateMode === "auto" ? "bg-amber-50/60 text-amber-950 border-amber-300 font-extrabold" : "bg-white text-emerald-800 border-emerald-400 ring-2 ring-emerald-400/20"}`
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "absolute right-3 top-1/2 -translate-y-1/2 text-xs font-extrabold text-slate-400",
												children: "/ Hour"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[10px] font-bold text-slate-500 mt-1",
										children: [
											"💡 Note: Overtime hours (1h, 2h, etc.) are recorded per day in the Attendance Calendar. In Salary Slip, overtime will be calculated as: ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
												"Total Overtime Hours × ₹",
												workerForm.overtimeRate || autoHourlyRate,
												"/hr"
											] }),
											"."
										]
									})
								]
							})]
						}),
						customFields.map((field, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pt-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-xs font-extrabold text-slate-700 uppercase block flex items-center gap-1.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5 text-[#063B78]" }),
										" ",
										field.label || "CUSTOM FIELD"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => handleRemoveCustomField(idx),
									className: "text-rose-500 hover:text-rose-700 text-[11px] font-bold flex items-center gap-1 hover:bg-rose-50 px-2 py-0.5 rounded transition-colors cursor-pointer",
									title: "Remove Field",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), " Remove Field"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								placeholder: `e.g. Enter ${field.label}...`,
								value: field.value,
								onChange: (e) => handleCustomFieldChange(idx, e.target.value),
								className: "w-full h-11 px-3.5 rounded-xl text-xs font-bold border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#063B78]"
							})]
						}, idx)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-3 pt-4 border-t border-slate-100",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: onClose,
								className: "flex-1 py-3 rounded-xl font-bold border border-slate-300 text-xs hover:bg-slate-50 transition-colors cursor-pointer",
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: "flex-1 py-3 rounded-xl font-black bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg text-xs transition-colors cursor-pointer",
								children: initialData ? "Update Employee" : "Save Employee"
							})]
						})
					]
				})
			]
		})
	}), showAddFieldPrompt && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-60 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bg-white w-full max-w-md rounded-3xl p-6 shadow-2xl border border-slate-100 relative space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setShowAddFieldPrompt(false),
					className: "absolute top-5 right-5 text-slate-400 hover:text-slate-700 font-extrabold text-lg p-1.5 rounded-full hover:bg-slate-100 transition-colors cursor-pointer",
					children: "✕"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
					className: "text-lg font-black text-[#10233F] flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-5 text-[#063B78]" }), " Add New Custom Field"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-slate-500 font-semibold mt-0.5",
					children: "Type the field name (e.g. Aadhaar Card ID, Education, PF Number)."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-extrabold text-slate-700 uppercase mb-1 block",
					children: "Field Name / Title *"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					autoFocus: true,
					type: "text",
					placeholder: "e.g. Aadhaar Card ID / Education / PF No",
					value: newFieldNameInput,
					onChange: (e) => setNewFieldNameInput(e.target.value),
					onKeyDown: (e) => {
						if (e.key === "Enter") {
							e.preventDefault();
							handleConfirmAddCustomField();
						}
					},
					className: "w-full h-11 px-3.5 rounded-xl text-xs font-bold border border-slate-300 focus:outline-none focus:border-[#063B78]"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] font-bold text-slate-500 uppercase",
						children: "Quick Suggestions:"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-1.5 flex-wrap",
						children: [
							"Aadhaar Card ID",
							"Education",
							"Alternate Mobile",
							"Bank Details",
							"PF Number"
						].map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => handleConfirmAddCustomField(preset),
							className: "px-2.5 py-1 bg-slate-100 hover:bg-[#063B78] hover:text-white text-slate-700 font-bold text-xs rounded-lg transition-colors cursor-pointer",
							children: ["+ ", preset]
						}, preset))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2 pt-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setShowAddFieldPrompt(false),
						className: "flex-1 py-2.5 rounded-xl border border-slate-300 font-bold text-xs hover:bg-slate-50 transition-colors cursor-pointer",
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => handleConfirmAddCustomField(),
						className: "flex-1 py-2.5 rounded-xl bg-[#063B78] hover:bg-[#0A4F9E] text-white font-black text-xs shadow-md transition-colors cursor-pointer",
						children: "Add Field"
					})]
				})
			]
		})
	})] });
};
var AddEmployeePageDemo = () => {
	const [isModalOpen, setIsModalOpen] = (0, import_react.useState)(false);
	const [editingWorker, setEditingWorker] = (0, import_react.useState)(null);
	const [workersList, setWorkersList] = (0, import_react.useState)([{
		id: "emp-101",
		employerId: "admin-001",
		name: "Ramesh Pawar",
		mobile: "9822112233",
		trade: "General Worker",
		category: "💻 Software Developer / Engineer",
		dailyRate: 600,
		joiningDate: "2026-08-01",
		status: "Active",
		workShiftStart: "09:00",
		workShiftEnd: "18:00",
		dailyWorkingHours: 9,
		overtimeRate: 67,
		pin: "1234",
		customFields: [{
			label: "Aadhaar Card ID",
			value: "1234-5678-9012"
		}]
	}]);
	const handleSave = (savedData) => {
		if (editingWorker) setWorkersList((prev) => prev.map((w) => w.id === editingWorker.id ? {
			...w,
			...savedData
		} : w));
		else {
			const newWorker = {
				id: "emp-" + Date.now(),
				employerId: "admin-001",
				name: savedData.name || "Employee",
				mobile: savedData.mobile || "",
				trade: savedData.trade || "Worker",
				category: savedData.category || "General",
				dailyRate: savedData.dailyRate || 600,
				joiningDate: savedData.joiningDate || (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
				status: "Active",
				workShiftStart: savedData.workShiftStart || "09:00",
				workShiftEnd: savedData.workShiftEnd || "18:00",
				dailyWorkingHours: savedData.dailyWorkingHours || 9,
				overtimeRate: savedData.overtimeRate || 67,
				pin: savedData.pin || "1234",
				customFields: savedData.customFields || []
			};
			setWorkersList((prev) => [newWorker, ...prev]);
		}
	};
	const handleDelete = (id) => {
		if (confirm("Are you sure you want to delete this employee?")) setWorkersList((prev) => prev.filter((w) => w.id !== id));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-[#F8FAFC] p-4 sm:p-8 text-slate-800 font-sans",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-5xl mx-auto space-y-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 text-xs font-black mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-emerald-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "HR & Employee Management" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-2xl sm:text-3xl font-black text-[#10233F]",
							children: "Employee Management Directory"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs sm:text-sm text-slate-500 font-semibold mt-1",
							children: "Click \"Add New Employee\" to open the interactive modal with custom fields, overtime & shift setup."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							setEditingWorker(null);
							setIsModalOpen(true);
						},
						className: "px-5 py-3 rounded-2xl bg-[#063B78] hover:bg-[#0A4F9E] text-white font-black text-xs sm:text-sm flex items-center gap-2 shadow-lg hover:shadow-xl transition-all cursor-pointer shrink-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "+ Add New Employee" })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-4",
					children: workersList.map((worker) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white rounded-2xl p-5 border border-slate-200 shadow-xs hover:border-[#063B78] transition-all space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-black text-base text-[#10233F]",
										children: worker.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-bold text-[#063B78]",
										children: worker.category
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] font-semibold text-slate-500",
										children: worker.trade
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "px-2.5 py-1 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 font-black text-xs",
									children: [
										"₹",
										worker.dailyRate,
										" / day"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2 text-xs text-slate-600 pt-2 border-t border-slate-100",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] uppercase font-extrabold text-slate-400 block",
										children: "Mobile"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: worker.mobile || "--" })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] uppercase font-extrabold text-slate-400 block",
										children: "Login PIN"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "tracking-widest text-[#063B78]",
										children: worker.pin || "1234"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] uppercase font-extrabold text-slate-400 block",
										children: "Shift"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
										worker.workShiftStart,
										" - ",
										worker.workShiftEnd
									] })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] uppercase font-extrabold text-slate-400 block",
										children: "Overtime Rate"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
										className: "text-amber-700",
										children: [
											"₹",
											worker.overtimeRate,
											" / hr"
										]
									})] })
								]
							}),
							worker.customFields && worker.customFields.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "pt-2 border-t border-slate-100 flex flex-wrap gap-1.5",
								children: worker.customFields.map((cf, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "px-2 py-0.5 rounded-lg bg-slate-100 text-slate-700 text-[10px] font-bold",
									children: [
										cf.label,
										": ",
										cf.value || "--"
									]
								}, idx))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-end gap-2 pt-2 border-t border-slate-100",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => {
										setEditingWorker(worker);
										setIsModalOpen(true);
									},
									className: "px-3 py-1.5 rounded-xl border border-slate-200 text-slate-700 font-bold text-xs hover:bg-slate-100 flex items-center gap-1 cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquarePen, { className: "size-3.5" }), " Edit"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => handleDelete(worker.id),
									className: "px-3 py-1.5 rounded-xl border border-rose-200 text-rose-600 font-bold text-xs hover:bg-rose-50 flex items-center gap-1 cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), " Delete"]
								})]
							})
						]
					}, worker.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddEmployeeModal, {
					isOpen: isModalOpen,
					onClose: () => setIsModalOpen(false),
					onSave: handleSave,
					initialData: editingWorker
				})
			]
		})
	});
};
var SplitComponent = AddEmployeePageDemo;
//#endregion
export { SplitComponent as component };
