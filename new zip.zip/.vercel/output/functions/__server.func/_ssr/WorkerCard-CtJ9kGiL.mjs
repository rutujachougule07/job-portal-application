import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n } from "./i18n-CEAlH7ip.mjs";
import { t as Button } from "./button--9UiOy7A.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { Mt as CircleCheck, R as PhoneCall, W as MapPin, qt as BadgeCheck, v as Star } from "../_libs/lucide-react.mjs";
import { t as Badge } from "./badge-DRaMiws1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/WorkerCard-CtJ9kGiL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var workersList = [
	{
		id: "worker-1",
		name: "Ramesh Pawar",
		profession: "Senior Electrician",
		marathiProfession: "वरिष्ठ इलेक्ट्रीशियन",
		hindiProfession: "वरिष्ठ इलेक्ट्रीशियन",
		location: "Pune, Maharashtra",
		experience: "7 Years",
		expectedSalary: "₹25,000 / month",
		availability: "Available Now",
		rating: 4.9,
		reviewsCount: 38,
		verified: true,
		skills: [
			"Industrial Wiring",
			"Panel Maintenance",
			"PLC Basics",
			"Solar Installation"
		],
		photoUrl: "https://images.unsplash.com/photo-1540569014015-19a7be504e3a?auto=format&fit=crop&w=300&q=80",
		phone: "+91 98230 11223",
		age: 32,
		languages: [
			"Marathi",
			"Hindi",
			"English"
		],
		about: "Certified ITI electrician with 7 years of industrial & commercial building wiring experience."
	},
	{
		id: "worker-2",
		name: "Ganesh Patil",
		profession: "CNC Machine Operator",
		marathiProfession: "CNC मशीन ऑपरेटर",
		hindiProfession: "सीएनसी मशीन ऑपरेटर",
		location: "Chakan, Pune",
		experience: "5 Years",
		expectedSalary: "₹28,000 / month",
		availability: "Available Now",
		rating: 4.8,
		reviewsCount: 24,
		verified: true,
		skills: [
			"Fanuc Control",
			"VMC Operating",
			"Quality Inspection",
			"Micrometer"
		],
		photoUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80",
		phone: "+91 97654 44321",
		age: 28,
		languages: ["Marathi", "Hindi"],
		about: "Specialized in auto-component machining, Fanuc CNC turning and VMC setting."
	},
	{
		id: "worker-3",
		name: "Sunil Shinde",
		profession: "Heavy Commercial Driver",
		marathiProfession: "अवजड वाहन चालक (ड्रायव्हर)",
		hindiProfession: "भारी वाहन चालक (ड्राइवर)",
		location: "Thane, Mumbai",
		experience: "9 Years",
		expectedSalary: "₹30,000 / month",
		availability: "Immediate",
		rating: 4.9,
		reviewsCount: 52,
		verified: true,
		skills: [
			"Heavy Badge License",
			"Container Truck",
			"Interstate Driving",
			"GPS Navigation"
		],
		photoUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80",
		phone: "+91 98901 22334",
		age: 36,
		languages: ["Marathi", "Hindi"],
		about: "Clean driving record, experienced in long-haul multi-axle trucks and container transport."
	},
	{
		id: "worker-4",
		name: "Prakash Jadhav",
		profession: "ARC & TIG Welder",
		marathiProfession: "वेल्डर (ARC / TIG)",
		hindiProfession: "वेल्डर (ARC / TIG)",
		location: "Aurangabad / Chhatrapati Sambhajinagar",
		experience: "6 Years",
		expectedSalary: "₹24,000 / month",
		availability: "Available Now",
		rating: 4.7,
		reviewsCount: 19,
		verified: true,
		skills: [
			"6G Welding",
			"Structure Welding",
			"SS Pipe Welding",
			"Safety Norms"
		],
		photoUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=300&q=80",
		phone: "+91 94221 88776",
		age: 30,
		languages: ["Marathi", "Hindi"],
		about: "Certified structural and pressure vessel welder with 6G certification."
	},
	{
		id: "worker-5",
		name: "Santosh More",
		profession: "Head Mason & Construction Supervisor",
		marathiProfession: "मुख्य गवंडी (Mason)",
		hindiProfession: "मुख्य राजमिस्त्री (Mason)",
		location: "Nagpur, Maharashtra",
		experience: "12 Years",
		expectedSalary: "₹35,000 / month",
		availability: "1 Week Notice",
		rating: 5,
		reviewsCount: 61,
		verified: true,
		skills: [
			"Brickwork",
			"Plastering",
			"Tile Laying",
			"Site Supervision"
		],
		photoUrl: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=300&q=80",
		phone: "+91 98220 99887",
		age: 42,
		languages: ["Marathi", "Hindi"],
		about: "Experienced building contractor mason leading site teams of up to 25 workers."
	},
	{
		id: "worker-6",
		name: "Sachin Kadam",
		profession: "Plumbing & Maintenance Specialist",
		marathiProfession: "प्लंबर व मेंटेनन्स",
		hindiProfession: "प्लंबर व मेंटेनेंस",
		location: "Navi Mumbai, Maharashtra",
		experience: "4 Years",
		expectedSalary: "₹22,000 / month",
		availability: "Available Now",
		rating: 4.8,
		reviewsCount: 31,
		verified: true,
		skills: [
			"CPVC Fitting",
			"Drainage Systems",
			"Water Pump Repair",
			"Leak Detection"
		],
		photoUrl: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=300&q=80",
		phone: "+91 97300 55443",
		age: 26,
		languages: [
			"Marathi",
			"Hindi",
			"English"
		],
		about: "Residential and commercial plumbing specialist skilled in pump automation."
	}
];
function WorkerCard({ worker }) {
	const { t, n, lang } = useI18n();
	const [requested, setRequested] = (0, import_react.useState)(false);
	const handleHireRequest = () => {
		setRequested(true);
		toast.success(`Hire request sent to ${worker.name}! They will contact you shortly.`);
	};
	const displayProfession = lang === "mr" ? worker.marathiProfession : lang === "hi" ? worker.hindiProfession || worker.profession : worker.profession;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card-realjob p-5 flex flex-col justify-between h-full group",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: worker.photoUrl,
						alt: worker.name,
						className: "size-16 rounded-full object-cover border-2 border-[#063B78] shadow-sm"
					}), worker.verified && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { className: "size-5 text-[#FFC400] fill-[#063B78] absolute -bottom-1 -right-1" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-base font-black text-[#10233F] truncate group-hover:text-[#063B78] transition-colors",
								children: worker.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1 text-xs font-extrabold text-[#082F63] bg-[#FFC400] px-2 py-0.5 rounded-full",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-3 fill-[#082F63]" }), n(worker.rating)]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-extrabold text-[#063B78] truncate",
							children: displayProfession
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 flex items-center gap-2 text-xs font-semibold text-[#5B6B7F]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5 text-[#125BB5]" }), worker.location]
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-2 gap-2 bg-[#F5F8FC] p-2.5 rounded-lg border border-[#DCE5F0]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[10px] font-bold uppercase text-[#5B6B7F] block",
					children: t("experience")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-extrabold text-[#10233F]",
					children: n(worker.experience)
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[10px] font-bold uppercase text-[#5B6B7F] block",
					children: t("expectedSalary")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-black text-[#063B78]",
					children: n(worker.expectedSalary)
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[10px] font-bold uppercase text-[#5B6B7F] block mb-1.5",
					children: t("keySkills")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1.5",
					children: worker.skills.map((skill, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "secondary",
						className: "text-[10.5px] font-bold bg-[#EBF1F8] text-[#063B78] border-0",
						children: skill
					}, idx))
				})]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 pt-3 border-t border-[#DCE5F0] flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/workers/$workerId",
				params: { workerId: worker.id },
				className: "flex-1 text-center py-2 px-3 rounded-lg border border-[#063B78] text-[#063B78] font-extrabold text-xs hover:bg-[#063B78] hover:text-white transition-colors",
				children: t("viewProfile")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: handleHireRequest,
				disabled: requested,
				size: "sm",
				className: "btn-yellow text-xs font-black px-4 py-2",
				children: requested ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5 text-[#082F63]" }), t("contactSent")]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneCall, { className: "size-3.5 text-[#082F63]" }), t("hireWorker")]
				})
			})]
		})]
	});
}
//#endregion
export { workersList as n, WorkerCard as t };
