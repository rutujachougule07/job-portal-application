import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useI18n } from "./i18n-CEAlH7ip.mjs";
import { t as Button } from "./button--9UiOy7A.mjs";
import { t as dataStore } from "./data-store-BCcScpg-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { Bt as Building2, D as Share2, Et as CloudUpload, Gt as BookOpen, It as Check, Jt as Award, Mt as CircleCheck, Ot as Clock3, T as ShieldCheck, Vt as Briefcase, W as MapPin, a as Wallet, bt as ExternalLink, c as User, gt as FileText, k as Send, pt as Gift, r as X, rt as Info, s as Users, v as Star, x as Sparkles, zt as Building } from "../_libs/lucide-react.mjs";
import { t as Badge } from "./badge-DRaMiws1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/JobCard-B_QpStMo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var getFallbackConfig = (category) => {
	const cat = (category || "").toLowerCase();
	const config = {
		fields: {
			fullName: "required",
			mobile: "required",
			currentLocation: "required"
		},
		customQuestions: []
	};
	if (cat.includes("construct") || cat.includes("mason")) config.fields = {
		...config.fields,
		email: "optional",
		preferredWorkLocation: "required",
		jobType: "required",
		totalWorkExperience: "required",
		relevantExperience: "required",
		skills: "required",
		previousWorkExperience: "optional",
		availability: "required",
		willingToRelocate: "optional",
		expectedSalary: "required",
		resume: "optional",
		workExperienceCertificate: "optional",
		skillCertificate: "optional",
		profilePhoto: "optional"
	};
	else if (cat.includes("it") || cat.includes("software") || cat.includes("tech")) config.fields = {
		...config.fields,
		email: "required",
		preferredWorkLocation: "required",
		highestQualification: "required",
		degree: "required",
		college: "optional",
		passingYear: "required",
		totalExperience: "required",
		relevantExperience: "required",
		currentCompany: "optional",
		currentJobTitle: "optional",
		technicalSkills: "required",
		programmingLanguages: "required",
		frameworks: "required",
		projects: "required",
		github: "optional",
		portfolio: "optional",
		linkedin: "optional",
		currentCTC: "optional",
		expectedCTC: "required",
		noticePeriod: "required",
		workModePreference: "optional",
		resume: "required",
		certifications: "optional"
	};
	else if (cat.includes("engineer")) config.fields = {
		...config.fields,
		email: "required",
		preferredWorkLocation: "required",
		engineeringBranch: "required",
		degree: "required",
		college: "optional",
		passingYear: "required",
		totalExperience: "required",
		relevantExperience: "required",
		technicalSkills: "required",
		softwareTools: "optional",
		projects: "optional",
		previousCompany: "optional",
		previousJobRole: "optional",
		currentCTC: "optional",
		expectedCTC: "required",
		noticePeriod: "required",
		willingToRelocate: "optional",
		resume: "required",
		engineeringCertificate: "optional",
		relevantCertifications: "optional"
	};
	else if (cat.includes("health") || cat.includes("medic") || cat.includes("nurs")) config.fields = {
		...config.fields,
		email: "required",
		preferredWorkLocation: "required",
		qualification: "required",
		specialization: "required",
		college: "optional",
		passingYear: "required",
		totalExperience: "required",
		relevantExperience: "required",
		previousHospital: "optional",
		currentRole: "optional",
		medicalSkills: "required",
		department: "optional",
		registrationNumber: "optional",
		registrationAuthority: "optional",
		registrationValidity: "optional",
		expectedSalary: "required",
		noticePeriod: "required",
		shiftAvailability: "required",
		willingToRelocate: "optional",
		resume: "required",
		qualificationCertificate: "optional",
		licenseProof: "optional",
		relevantCertificates: "optional"
	};
	else if (cat.includes("finance") || cat.includes("account")) config.fields = {
		...config.fields,
		email: "required",
		preferredWorkLocation: "required",
		highestQualification: "required",
		degree: "required",
		college: "optional",
		passingYear: "required",
		totalExperience: "required",
		relevantExperience: "required",
		currentCompany: "optional",
		previousJobRole: "optional",
		accountingSkills: "required",
		accountingSoftwareKnowledge: "optional",
		tallyKnowledge: "optional",
		excelKnowledge: "optional",
		sapKnowledge: "optional",
		gstExperience: "optional",
		certifications: "optional",
		currentCTC: "optional",
		expectedCTC: "required",
		noticePeriod: "required",
		resume: "required"
	};
	else if (cat.includes("sales") || cat.includes("market")) config.fields = {
		...config.fields,
		email: "required",
		preferredWorkLocation: "required",
		totalExperience: "required",
		salesExperience: "required",
		previousCompany: "optional",
		previousJobRole: "optional",
		salesSkills: "required",
		marketingSkills: "optional",
		industryExperience: "optional",
		salesTargetExperience: "optional",
		targetHandled: "optional",
		teamHandlingExperience: "optional",
		customerHandlingExperience: "required",
		fieldSalesExperience: "optional",
		travelWillingness: "optional",
		expectedSalary: "required",
		expectedIncentive: "optional",
		noticePeriod: "required",
		resume: "optional",
		portfolio: "optional"
	};
	else if (cat.includes("educat") || cat.includes("teach")) config.fields = {
		...config.fields,
		email: "required",
		preferredWorkLocation: "required",
		highestQualification: "required",
		degree: "required",
		subject: "required",
		college: "optional",
		passingYear: "required",
		teachingExperience: "required",
		subjectsTaught: "required",
		classesTaught: "optional",
		previousSchool: "optional",
		teachingSkills: "required",
		onlineTeachingExperience: "optional",
		teachingCertifications: "optional",
		expectedSalary: "required",
		noticePeriod: "required",
		preferredTeachingMode: "optional",
		willingToRelocate: "optional",
		resume: "required",
		educationCertificates: "optional"
	};
	else if (cat.includes("manufactur") || cat.includes("factory") || cat.includes("production")) config.fields = {
		...config.fields,
		email: "optional",
		preferredWorkLocation: "required",
		jobType: "required",
		totalExperience: "required",
		relevantExperience: "required",
		previousCompany: "optional",
		previousJobRole: "optional",
		productionExperience: "optional",
		machineExperience: "optional",
		technicalSkills: "required",
		qualityControlExperience: "optional",
		productionLineExperience: "optional",
		safetyKnowledge: "optional",
		shiftExperience: "optional",
		shiftAvailability: "required",
		teamHandlingExperience: "optional",
		expectedSalary: "required",
		joiningAvailability: "required",
		willingToRelocate: "optional",
		resume: "optional",
		experienceCertificate: "optional",
		skillCertificate: "optional"
	};
	else config.fields = {
		...config.fields,
		email: "optional",
		resume: "optional",
		experience: "optional"
	};
	return config;
};
var groupFieldsBySection = (fields) => {
	const sections = {
		personal: {},
		work: {},
		salary: {},
		documents: {}
	};
	Object.keys(fields).forEach((key) => {
		const k = key.toLowerCase();
		const val = fields[key];
		if (!val) return;
		if (k.includes("name") || k.includes("email") || k.includes("mobile") || k.includes("location")) sections.personal[key] = val;
		else if (k.includes("salary") || k.includes("ctc") || k.includes("wage") || k.includes("notice") || k.includes("joining") || k.includes("availability") || k.includes("mode") || k.includes("shift")) sections.salary[key] = val;
		else if (k.includes("resume") || k.includes("certificate") || k.includes("photo") || k.includes("portfolio") || k.includes("proof")) sections.documents[key] = val;
		else sections.work[key] = val;
	});
	return sections;
};
var DynamicApplicationForm = ({ appConfig, fieldValues, setFieldValues, customAnswers, setCustomAnswers, lang, category }) => {
	const groupedFields = groupFieldsBySection(appConfig.fields);
	const handleFieldChange = (key, val) => setFieldValues((p) => ({
		...p,
		[key]: val
	}));
	const handleCustomChange = (id, val) => setCustomAnswers((p) => ({
		...p,
		[id]: val
	}));
	const renderField = (fieldKey, req) => {
		if (req === "hidden") return null;
		const isReq = req === "required";
		const label = fieldKey.replace(/([A-Z])/g, " $1").trim().replace(/^./, (str) => str.toUpperCase());
		if (fieldKey === "resume" || fieldKey === "profilePhoto" || fieldKey.toLowerCase().includes("certificate") || fieldKey.toLowerCase().includes("proof") || fieldKey.toLowerCase().includes("portfolio")) {
			const fileName = fieldValues[fieldKey];
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm font-extrabold text-[#10233F]",
					children: [
						label,
						" ",
						isReq && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-red-500",
							children: "*"
						}),
						" ",
						req === "optional" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-gray-400 font-normal text-xs",
							children: "(Optional)"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `border-2 border-dashed ${fileName ? "border-emerald-500 bg-emerald-50" : "border-[#DCE5F0] hover:border-[#125BB5] hover:bg-[#F5F8FC]"} rounded-xl p-4 flex flex-col items-center justify-center text-center transition-colors relative h-28`,
					children: [fileName ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-8 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600 mb-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-black text-emerald-700 truncate max-w-[90%]",
							children: fileName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] font-bold text-emerald-600/70 mt-0.5",
							children: "Click to change file"
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						fieldKey === "profilePhoto" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-6 text-[#125BB5] mb-1" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudUpload, { className: "size-6 text-[#125BB5] mb-1" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] font-semibold text-[#5B6B7F]",
							children: "Click to upload or drag and drop"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[9px] text-[#8695A7] mt-0.5",
							children: fieldKey === "profilePhoto" ? "JPG, PNG (Max 2MB)" : "PDF, DOC, DOCX (Max 5MB)"
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						required: isReq && !fileName,
						onChange: (e) => handleFieldChange(fieldKey, e.target.files?.[0]?.name),
						className: "absolute inset-0 opacity-0 cursor-pointer w-full h-full",
						title: fileName || "Upload file"
					})]
				})]
			}, fieldKey);
		}
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm font-extrabold text-[#10233F]",
				children: [
					label,
					" ",
					isReq && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-red-500",
						children: "*"
					})
				]
			}), fieldKey === "experience" || fieldKey === "relevantExperience" || fieldKey === "totalExperience" || fieldKey === "totalWorkExperience" || fieldKey === "teachingExperience" || fieldKey === "salesExperience" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				required: isReq,
				value: fieldValues[fieldKey] || "",
				onChange: (e) => handleFieldChange(fieldKey, e.target.value),
				className: "w-full h-12 rounded-xl border border-[#DCE5F0] bg-white px-4 text-sm font-semibold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Select Experience"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "Fresher",
						children: "Fresher"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "1-3 Years",
						children: "1 - 3 Years"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "3-5 Years",
						children: "3 - 5 Years"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "5+ Years",
						children: "5+ Years"
					})
				]
			}) : fieldKey === "availability" || fieldKey === "noticePeriod" || fieldKey === "joiningAvailability" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "date",
				required: isReq,
				value: fieldValues[fieldKey] || "",
				onChange: (e) => handleFieldChange(fieldKey, e.target.value),
				className: "w-full h-12 rounded-xl border border-[#DCE5F0] bg-white px-4 text-sm font-semibold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
			}) : fieldKey === "willingToRelocate" || fieldKey === "fieldSalesExperience" || fieldKey === "travelWillingness" || fieldKey === "onlineTeachingExperience" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				required: isReq,
				value: fieldValues[fieldKey] || "",
				onChange: (e) => handleFieldChange(fieldKey, e.target.value),
				className: "w-full h-12 rounded-xl border border-[#DCE5F0] bg-white px-4 text-sm font-semibold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Select"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "Yes",
						children: "Yes"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "No",
						children: "No"
					})
				]
			}) : fieldKey === "preferredTeachingMode" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				required: isReq,
				value: fieldValues[fieldKey] || "",
				onChange: (e) => handleFieldChange(fieldKey, e.target.value),
				className: "w-full h-12 rounded-xl border border-[#DCE5F0] bg-white px-4 text-sm font-semibold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Select Mode"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "Online",
						children: "Online"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "Offline",
						children: "Offline"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "Hybrid",
						children: "Hybrid"
					})
				]
			}) : fieldKey === "workModePreference" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				required: isReq,
				value: fieldValues[fieldKey] || "",
				onChange: (e) => handleFieldChange(fieldKey, e.target.value),
				className: "w-full h-12 rounded-xl border border-[#DCE5F0] bg-white px-4 text-sm font-semibold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Select Mode"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "Remote",
						children: "Remote"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "Hybrid",
						children: "Hybrid"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "Office",
						children: "Office"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: fieldKey.toLowerCase().includes("email") ? "email" : fieldKey.toLowerCase().includes("mobile") || fieldKey.toLowerCase().includes("phone") ? "tel" : "text",
				required: isReq,
				placeholder: `Enter ${label.toLowerCase()}`,
				value: fieldValues[fieldKey] || "",
				onChange: (e) => handleFieldChange(fieldKey, e.target.value),
				className: "w-full h-12 rounded-xl border border-[#DCE5F0] bg-white px-4 text-sm font-semibold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
			})]
		}, fieldKey);
	};
	const renderSection = (title, icon, fieldsObj, number) => {
		if (Object.keys(fieldsObj).length === 0) return null;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 mb-4 p-2 bg-[#EBF1F8] rounded-lg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[#125BB5]",
					children: icon
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "text-[#125BB5] font-extrabold text-sm",
					children: [
						number,
						". ",
						title
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-5",
				children: Object.keys(fieldsObj).map((k) => renderField(k, fieldsObj[k] || ""))
			})]
		});
	};
	let sectionCounter = 1;
	const showInfo = (category || "").toLowerCase().includes("construct") || (category || "").toLowerCase().includes("mason") || (category || "").toLowerCase().includes("manufactur") || (category || "").toLowerCase().includes("helper");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 mt-4",
		children: [
			renderSection("Personal Details", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-5" }), groupedFields.personal, sectionCounter++),
			renderSection("Work Details", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-5" }), groupedFields.work, sectionCounter++),
			renderSection("Salary", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-5" }), groupedFields.salary, sectionCounter++),
			appConfig.customQuestions && appConfig.customQuestions.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 mb-4 p-2 bg-[#EBF1F8] rounded-lg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[#125BB5]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "text-[#125BB5] font-extrabold text-sm",
						children: [sectionCounter++, ". Job Specific Questions"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-5",
					children: appConfig.customQuestions.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "col-span-1 md:col-span-2 space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-extrabold text-[#10233F]",
							children: [
								q.question,
								" ",
								q.required && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-red-500",
									children: "*"
								})
							]
						}), q.type === "long" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							required: q.required,
							value: customAnswers[q.id] || "",
							onChange: (e) => handleCustomChange(q.id, e.target.value),
							className: "w-full rounded-xl border border-[#DCE5F0] bg-white p-4 text-sm font-semibold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]",
							rows: 3
						}) : q.type === "yesno" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							required: q.required,
							value: customAnswers[q.id] || "",
							onChange: (e) => handleCustomChange(q.id, e.target.value),
							className: "w-full h-12 rounded-xl border border-[#DCE5F0] bg-white px-4 text-sm font-semibold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Select option"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Yes",
									children: "Yes"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "No",
									children: "No"
								})
							]
						}) : q.type === "number" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							required: q.required,
							value: customAnswers[q.id] || "",
							onChange: (e) => handleCustomChange(q.id, e.target.value),
							className: "w-full h-12 rounded-xl border border-[#DCE5F0] bg-white px-4 text-sm font-semibold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						}) : q.type === "date" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							required: q.required,
							value: customAnswers[q.id] || "",
							onChange: (e) => handleCustomChange(q.id, e.target.value),
							className: "w-full h-12 rounded-xl border border-[#DCE5F0] bg-white px-4 text-sm font-semibold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							required: q.required,
							value: customAnswers[q.id] || "",
							onChange: (e) => handleCustomChange(q.id, e.target.value),
							className: "w-full h-12 rounded-xl border border-[#DCE5F0] bg-white px-4 text-sm font-semibold text-[#10233F] focus:outline-none focus:ring-2 focus:ring-[#063B78]"
						})]
					}, q.id))
				})]
			}),
			renderSection("Documents", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-5" }), groupedFields.documents, sectionCounter++),
			showInfo && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-[#F5F8FC] rounded-xl p-4 flex gap-3 border border-[#DCE5F0] mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-5 text-[#125BB5] shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "font-extrabold text-[#063B78] text-sm",
					children: "Important"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold text-[#5B6B7F] mt-1",
					children: "Resume is not compulsory for Construction Labour, Helper, Mason and similar worker-level jobs."
				})] })]
			})
		]
	});
};
var companyDatabase = {
	"L&T Construction": {
		name: "Larsen & Toubro (L&T) Construction",
		industry: "Engineering & Heavy Construction",
		founded: "1938",
		size: "50,000+ Employees",
		headquarters: "Mumbai, Maharashtra",
		rating: "4.6",
		reviewsCount: "12,450+",
		website: "https://www.larsentoubro.com",
		aboutMr: "L&T Construction ही भारतातील सर्वात मोठी आणि जागतिक स्तरावरील अव्वल दर्जाची इन्फ्रास्ट्रक्चर व अभियांत्रिकी कंपनी आहे. कंपनी मेट्रो, पूल, हायवे आणि मोठ्या कमर्शियल प्रोजेक्ट्सचे काम करते.",
		aboutEn: "L&T Construction is India's largest infrastructure engineering & construction conglomerate with landmark global mega-projects.",
		trustBadges: [
			"GST Verified Employer",
			"ISO 9001 Certified",
			"Govt Infrastructure Partner",
			"Top Employer 2026"
		],
		perksMr: [
			"PF + ESIC वैद्यकीय विमा",
			"मोफत कॅन्टीन व वाहतूक सुविधा",
			"वार्षिक दिवाळी व परफॉर्मन्स बोनस",
			"साइट निवास व्यवस्था (Accommodation)"
		],
		perksEn: [
			"PF + ESIC Medical Insurance",
			"Subsidized Canteen & Transport",
			"Annual Performance Bonus",
			"Site Accommodation Provided"
		],
		jobDescMr: "साइट ऑपरेशन, क्वालिटी कंट्रोल, प्रोग्रेस ट्रॅकिंग आणि सुरक्षा नियमांचे पालन करून बांधकाम प्रकल्प वेळेत पूर्ण करण्याची जबाबदारी राहील.",
		jobDescEn: "Responsible for site execution, quality assurance, safety protocol compliance, and structural progress tracking.",
		skills: [
			"Civil Engineering",
			"Site Safety",
			"AutoCAD",
			"Project Management",
			"Quality Inspection"
		]
	},
	"Shapoorji Pallonji": {
		name: "Shapoorji Pallonji & Co. Ltd.",
		industry: "Real Estate & Construction",
		founded: "1865",
		size: "35,000+ Employees",
		headquarters: "Mumbai, Maharashtra",
		rating: "4.5",
		reviewsCount: "8,900+",
		website: "https://www.shapoorjipallonji.com",
		aboutMr: "१५० वर्षांपेक्षा जास्त समृद्ध वारसा असणारी Shapoorji Pallonji ग्रुप ही भारतातील प्रीमियर रिअल इस्टेट व कन्स्ट्रक्शन कंपनी आहे.",
		aboutEn: "Shapoorji Pallonji is a 150+ year old premier Indian conglomerate operating in construction, real estate, and infrastructure.",
		trustBadges: [
			"A+ Govt Rated",
			"GST Registered",
			"Safety Certified 2026"
		],
		perksMr: [
			"आरोग्य विमा",
			"ओव्हरटाइम अलाउन्स",
			"तांत्रिक प्रशिक्षण"
		],
		perksEn: [
			"Health Insurance",
			"Overtime Allowance",
			"Technical Training"
		],
		jobDescMr: "सिव्हिल स्ट्रक्चर तपासणे, साइट लेबर मॅनेजमेंट आणि मटेरियल ऑडिट करणे.",
		jobDescEn: "Site structural inspections, labor management, material audit and daily reporting.",
		skills: [
			"Site Supervision",
			"Structural Safety",
			"Labor Management",
			"Material Testing"
		]
	},
	"TCS": {
		name: "Tata Consultancy Services (TCS)",
		industry: "IT & Software Services",
		founded: "1968",
		size: "600,000+ Employees",
		headquarters: "Mumbai, Maharashtra",
		rating: "4.7",
		reviewsCount: "45,000+",
		website: "https://www.tcs.com",
		aboutMr: "टाटा समूहाची TCS ही जगातील अग्रगण्य आयटी सर्व्हिसेस, कन्सलटिंग आणि बिझनेस सोल्युशन्स देणारी कंपनी आहे.",
		aboutEn: "TCS is a global leader in IT services, consulting & business solutions partnering with top Fortune 500 enterprises.",
		trustBadges: [
			"Global Top Employer",
			"Tata Group Brand",
			"100% Tax Compliant"
		],
		perksMr: [
			"हायब्रिड / WFH पर्याय",
			"कुटुंब आरोग्य विमा (₹5 लाख)",
			"TCS Xplore लर्निंग कोर्सेस",
			"कॅब पिक & ड्रॉप"
		],
		perksEn: [
			"Hybrid / Remote Work",
			"Family Health Cover (₹5L)",
			"TCS Upskilling Programs",
			"Cab Drop Service"
		],
		jobDescMr: "एंटरप्राइज सॉफ्टवेअर डिझाइन करणे, रिॲक्ट/जावा कोडिंग, एपीआय इंटिग्रेशन आणि बग फिक्सिंग करणे.",
		jobDescEn: "Design and implement enterprise Web apps, React/Node microservices, API integrations, and code optimization.",
		skills: [
			"React",
			"Node.js",
			"Java / Python",
			"SQL / NoSQL",
			"Git"
		]
	},
	"Infosys": {
		name: "Infosys Limited",
		industry: "IT & Next-Gen Digital Services",
		founded: "1981",
		size: "300,000+ Employees",
		headquarters: "Bengaluru, Karnataka",
		rating: "4.6",
		reviewsCount: "38,000+",
		website: "https://www.infosys.com",
		aboutMr: "इन्फोसिस ही डिजिटल ट्रान्सफॉर्मेशन आणि सॉफ्टवेअर सोल्यूशन्स देणारी भारतातील अव्वल जागतिक कंपनी आहे.",
		aboutEn: "Infosys is a global leader in next-generation digital services and consulting.",
		trustBadges: [
			"Listed on NYSE",
			"Top Employer India",
			"Verified Recruiter"
		],
		perksMr: [
			"वर्क फ्रॉम होम फ्लेक्सिबिलिटी",
			"वार्षिक अप्र Appraisals",
			"इन्फोसिस स्प्रिंगबोर्ड लर्निंग"
		],
		perksEn: [
			"Work From Home Flexibility",
			"Annual Performance Appraisal",
			"Infosys Springboard Learning"
		],
		jobDescMr: "वेब व मोबाईल ॲप्लिकेशन डेव्हलपमेंट, फ्रंटएंड आणि युझर एक्सपिरियन्स डिझाइन.",
		jobDescEn: "Develop responsive web interfaces, frontend logic, component integration and cloud deployment.",
		skills: [
			"React.js",
			"TypeScript",
			"Tailwind CSS",
			"REST API",
			"UI Testing"
		]
	},
	"Tata Motors": {
		name: "Tata Motors Commercial & Passenger Vehicles",
		industry: "Automobile & Manufacturing",
		founded: "1945",
		size: "80,000+ Employees",
		headquarters: "Pune / Mumbai, Maharashtra",
		rating: "4.7",
		reviewsCount: "18,200+",
		website: "https://www.tatamotors.com",
		aboutMr: "टाटा मोटर्स ही भारतातील सर्वात मोठी ऑटोमोबाईल उत्पादक कंपनी असून EV (इलेक्ट्रिक व्हेईकल) क्षेत्रात क्रांती घडवत आहे.",
		aboutEn: "Tata Motors is India's pioneer automotive manufacturer leading the Electric Vehicle revolution.",
		trustBadges: [
			"Make in India Pioneer",
			"Tata Trust Certified",
			"ISO 14001 Compliant"
		],
		perksMr: [
			"कंपनी बस सेवा (पुणे/पिंपरी)",
			"कॅन्टीन भोजन सवलत",
			"मेडिक्लेम व ग्रॅच्युइटी"
		],
		perksEn: [
			"Free Factory Bus Service",
			"Subsidized Canteen Meals",
			"Mediclaim & Gratuity"
		],
		jobDescMr: "असेंब्ली लाईन प्रोडक्शन, मेकॅनिकल कंपोनंट टेस्टिंग आणि क्वालिटी अश्युरन्स तपासणे.",
		jobDescEn: "Assembly line oversight, mechanical testing, vehicle quality audit and production throughput.",
		skills: [
			"Mechanical Engineering",
			"Production Planning",
			"Quality Inspection",
			"AutoCAD / CATIA"
		]
	},
	"Ruby Hall Clinic": {
		name: "Grant Medical Foundation - Ruby Hall Clinic",
		industry: "Healthcare & Multispecialty Hospital",
		founded: "1959",
		size: "4,500+ Staff",
		headquarters: "Pune, Maharashtra",
		rating: "4.8",
		reviewsCount: "5,600+",
		website: "https://www.rubyhall.com",
		aboutMr: "रुबी हॉल क्लिनिक हे पुण्यातील सर्वात प्रख्यात आणि NABH मान्यताप्राप्त मल्टीस्पेशालिटी हॉस्पिटल आहे.",
		aboutEn: "Ruby Hall Clinic is a premier NABH-accredited multispecialty tertiary care hospital in Maharashtra.",
		trustBadges: [
			"NABH Accredited Hospital",
			"Govt Health Partner",
			"Top Healthcare Brand"
		],
		perksMr: [
			"कर्मचारी व कुटुंब मोफत रुग्णालय उपचार",
			"नाईट शिफ्ट अलाउन्स",
			"नर्सिंग क्वार्टर्स"
		],
		perksEn: [
			"Free Hospital Care for Staff",
			"Night Shift Allowance",
			"Nursing Quarters"
		],
		jobDescMr: "पेशंट केअर, आयसीयू ऑब्झर्व्हेशन, डॉक्टर असिस्टन्स आणि मेडिकल रेकॉर्ड्स मेंटेन करणे.",
		jobDescEn: "Patient nursing care, ICU monitoring, physician assistance, and clinical documentation.",
		skills: [
			"Patient Nursing",
			"ICU Care",
			"First Aid / CPR",
			"Medical Records"
		]
	},
	"KPMG": {
		name: "KPMG India",
		industry: "Financial Advisory, Audit & Tax",
		founded: "1993",
		size: "20,000+ Professionals",
		headquarters: "Mumbai, Maharashtra",
		rating: "4.6",
		reviewsCount: "9,100+",
		website: "https://home.kpmg/in",
		aboutMr: "केपीएमजी ही जगप्रसिद्ध बिग-४ मधील एक फायनान्शियल ऑडिट, टॅक्स सल्लागार आणि कॉर्पोरेट अकाऊंटिंग कंपनी आहे.",
		aboutEn: "KPMG is one of the Big Four global financial auditing, advisory and accounting firms.",
		trustBadges: [
			"Big 4 Financial Brand",
			"Certified Tax Consultants",
			"Top Corporate Firm"
		],
		perksMr: [
			"उच्च कॉर्पोरेट पगार",
			"वार्षिक इन्सेन्टिव्ह",
			"सीए व फायनान्स स्पॉन्सरशिप"
		],
		perksEn: [
			"High Corporate Pay",
			"Annual Performance Bonus",
			"Finance Certifications Cover"
		],
		jobDescMr: "जीएसटी रिटर्न्स, कॉर्पोरेट टॅक्स ऑडिट, बॅलन्स शीट फायनलायझेशन आणि फायनान्शियल प्लॅनिंग करणे.",
		jobDescEn: "Corporate tax auditing, GST compliance, balance sheet finalization and client risk assessment.",
		skills: [
			"Accounting",
			"GST / Income Tax",
			"Tally Prime",
			"Financial Audit",
			"Excel Mastery"
		]
	},
	"Reliance Industries": {
		name: "Reliance Industries & Digital Services",
		industry: "Conglomerate - Retail, Telecom & Energy",
		founded: "1958",
		size: "350,000+ Employees",
		headquarters: "Mumbai, Maharashtra",
		rating: "4.7",
		reviewsCount: "28,000+",
		website: "https://www.ril.com",
		aboutMr: "रिलायन्स इंडस्ट्रिज ही भारतातील सर्वात मोठी प्रायव्हेट कंपनी असून रिटेल, टेलिकॉम (Jio) आणि ऊर्जेमध्ये अग्रगण्य आहे.",
		aboutEn: "Reliance Industries Limited is India's largest private sector enterprise spanning Energy, Retail & Digital.",
		trustBadges: [
			"India #1 Fortune 500",
			"GST Registered",
			"Verified Enterprise"
		],
		perksMr: [
			"रिलायन्स रिटेल डिस्काऊंट",
			"मेडिकल इन्शुरन्स (₹4 लाख)",
			"कर्मचारी शेअर योजना"
		],
		perksEn: [
			"Reliance Store Discounts",
			"Comprehensive Medical Cover",
			"Employee Stock Options"
		],
		jobDescMr: "डिजिटल मार्केटिंग कॅम्पेन, सेल्स एक्झिक्युशन, बिझनेस डेव्हलपमेंट आणि कस्टमर ऑनबोर्डिंग.",
		jobDescEn: "Lead digital marketing drives, B2B/B2C sales execution, and market expansion campaigns.",
		skills: [
			"Sales Management",
			"Digital Marketing",
			"Business Development",
			"Client Relationship"
		]
	},
	"Bharat Forge": {
		name: "Bharat Forge Limited (Kalyani Group)",
		industry: "Heavy Engineering & Manufacturing",
		founded: "1961",
		size: "12,000+ Employees",
		headquarters: "Pune, Maharashtra",
		rating: "4.6",
		reviewsCount: "4,200+",
		website: "https://www.bharatforge.com",
		aboutMr: "भारत फोर्ज ही जगातील दुसऱ्या क्रमांकाची सर्वात मोठी ऑटोमोबाईल व एरोस्पेस फोर्जिंग उत्पादक कंपनी आहे.",
		aboutEn: "Bharat Forge is a global engineering leader manufacturing critical automotive & aerospace components.",
		trustBadges: [
			"Defense & Aerospace Approved",
			"ISO 45001",
			"Kalyani Group Brand"
		],
		perksMr: [
			"मोफत कॅन्टीन व चहा",
			"सुरक्षा किट व गणवेश",
			"वार्षिक बोनस व PF"
		],
		perksEn: [
			"Free Canteen & Refreshments",
			"Safety Gear & Uniform",
			"Annual Bonus & PF"
		],
		jobDescMr: "सीएनसी मशीन ऑपरेटिंग, मॅन्युफॅक्चरिंग लाईन सुपरव्हिजन आणि मेटल चाचणी करणे.",
		jobDescEn: "CNC machine operations, metallurgy quality check, and shopfloor production target management.",
		skills: [
			"CNC / VMC Operations",
			"Manufacturing Supervision",
			"Quality Assurance",
			"Plant Safety"
		]
	}
};
function getCompanyMetadata(job) {
	const found = companyDatabase[job.company];
	if (found) return found;
	return {
		name: job.company,
		industry: job.category || "General Industry",
		founded: "2010",
		size: "500+ Employees",
		headquarters: job.location || "Maharashtra, India",
		rating: "4.5",
		reviewsCount: "150+ Reviews",
		website: `https://www.google.com/search?q=${encodeURIComponent(job.company)}`,
		aboutMr: `${job.company} ही ${job.category} क्षेत्रातील अधिकृत आणि नोंदणीकृत कंपनी आहे. कंपनी उच्च दर्जाच्या सेवा आणि रोजगार संधी उपलब्ध करून देते.`,
		aboutEn: `${job.company} is a verified enterprise in the ${job.category} sector providing reliable products, services, and career opportunities.`,
		trustBadges: [
			"GST Registered Employer",
			"REAL JOB Verified",
			"Government Compliant"
		],
		perksMr: [
			"PF + ESIC सुविधा",
			"नियमित पगार व बोनस",
			"कामाचे सुरक्षित वातावरण"
		],
		perksEn: [
			"PF + ESIC Benefits",
			"Timely Salary & Bonus",
			"Safe Working Environment"
		],
		jobDescMr: `${job.title} या पदासाठी मुख्य जबाबदाऱ्यांमध्ये दैनिक कामकाज, टीम वर्क आणि दिलेल्या उद्दिष्टांची पूर्तता करणे समाविष्ट आहे.`,
		jobDescEn: `Primary duties for ${job.title} include daily operational execution, teamwork, and target milestone completion.`,
		skills: [
			job.category,
			"Teamwork",
			"Problem Solving",
			"Domain Expertise"
		]
	};
}
var jobs = [];
function JobCard({ job, onApply }) {
	const { t, n, lang } = useI18n();
	const [saved, setSaved] = (0, import_react.useState)(false);
	const [showApplyModal, setShowApplyModal] = (0, import_react.useState)(false);
	const [showCompanyModal, setShowCompanyModal] = (0, import_react.useState)(false);
	const [activeModalTab, setActiveModalTab] = (0, import_react.useState)("company");
	const [applied, setApplied] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!showApplyModal && !showCompanyModal) return;
		const originalStyle = window.getComputedStyle(document.body).overflow;
		document.body.style.overflow = "hidden";
		return () => {
			document.body.style.overflow = originalStyle;
		};
	}, [showApplyModal, showCompanyModal]);
	const [fieldValues, setFieldValues] = (0, import_react.useState)({});
	const [customAnswers, setCustomAnswers] = (0, import_react.useState)({});
	const appConfig = job.applicationConfig || getFallbackConfig(job.category);
	const companyMeta = getCompanyMetadata(job);
	const handleApplyClick = (e) => {
		e.stopPropagation();
		if (onApply) onApply(job);
		else setShowApplyModal(true);
	};
	const [copied, setCopied] = (0, import_react.useState)(false);
	const handleShareClick = (e) => {
		e.stopPropagation();
		setCopied(true);
		if (typeof navigator !== "undefined" && navigator.clipboard) navigator.clipboard.writeText(window.location.href);
		setTimeout(() => setCopied(false), 2e3);
	};
	const openModalTab = (tab) => {
		setActiveModalTab(tab);
		setShowCompanyModal(true);
	};
	const submitApplication = (e) => {
		e.preventDefault();
		const currentUser = dataStore.getCurrentUser();
		const seekerId = currentUser ? currentUser.email || currentUser.id || "seeker-demo" : fieldValues["email"] || "candidate@realjob.com";
		const seekerName = fieldValues["fullName"] || fieldValues["candidateName"] || currentUser?.fullName || "Candidate Applicant";
		const userMobile = (seekerId ? dataStore.findRegisteredAccount(seekerId) : null)?.mobile || currentUser?.mobile || "";
		const seekerMobile = fieldValues["mobile"] || fieldValues["phone"] || fieldValues["candidateMobile"] || fieldValues["mobileNumber"] || fieldValues["contactNumber"] || fieldValues["phoneNo"] || fieldValues["mobileNo"] || userMobile;
		if (dataStore.hasAlreadyApplied(seekerId, job.id)) {
			toast.error(lang === "mr" ? "तुम्ही या नोकरीसाठी आधीच अर्ज भरला आहे!" : "You have already applied to this job!");
			setShowApplyModal(false);
			return;
		}
		try {
			dataStore.createApplication({
				jobId: job.id,
				employerId: job.company,
				jobSeekerId: seekerId,
				candidateName: seekerName,
				candidateEmail: fieldValues["email"] || seekerId,
				candidateMobile: seekerMobile,
				jobTitle: job.title,
				companyName: job.company,
				location: job.location,
				salary: job.salary,
				resume: fieldValues["resume"] || `${seekerName.replaceAll(" ", "_")}_Resume.pdf`,
				fieldValues,
				customAnswers,
				category: job.category
			});
			setApplied(true);
			toast.success(lang === "mr" ? "अर्ज यशस्वीरीत्या पाठवला!" : "Application submitted successfully!");
			setTimeout(() => {
				setApplied(false);
				setShowApplyModal(false);
			}, 2e3);
		} catch (err) {
			toast.error(err.message || "Failed to submit application");
		}
	};
	const companyJobs = jobs.filter((j) => j.company === job.company);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "card-realjob p-5 flex flex-col justify-between group relative overflow-hidden bg-white border border-[#DCE5F0] hover:border-[#063B78]/40 hover:shadow-lg transition-all rounded-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2 mb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5 flex-wrap",
						children: [job.featured && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							className: "bg-[#FFC400] text-[#082F63] font-black text-[10px] uppercase tracking-wider px-2 py-0.5 border-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "mr-1 size-3" }),
								" ",
								lang === "mr" ? "खास संधी" : "Featured"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "outline",
							className: "border-[#063B78]/20 text-[#063B78] font-bold text-[10px] bg-[#063B78]/5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mr-1 size-3 text-emerald-600" }), " GST Verified"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: handleShareClick,
							title: lang === "mr" ? "नोकरी शेअर करा" : "Share Job",
							className: "text-[#5B6B7F] hover:text-[#063B78] p-1.5 rounded-full hover:bg-[#F5F8FC] transition-colors relative",
							children: copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs font-bold text-emerald-600 flex items-center gap-1 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 animate-fade-in",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3" }),
									" ",
									lang === "mr" ? "कॉपी झाली!" : "Copied!"
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setSaved(!saved),
							"aria-label": "Save Job",
							title: lang === "mr" ? "नोकरी सेव्ह करा" : "Save Job",
							className: "text-[#5B6B7F] hover:text-[#063B78] p-1.5 rounded-full hover:bg-[#F5F8FC] transition-colors",
							children: saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[#063B78] font-bold text-xs flex items-center gap-1 bg-[#063B78]/10 px-2 py-0.5 rounded-full",
								children: "★ Saved"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[#5B6B7F] text-xs flex items-center gap-1 px-1.5",
								children: "☆ Save"
							})
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: companyMeta.website,
						target: "_blank",
						rel: "noopener noreferrer",
						title: `${companyMeta.name} ची अधिकृत वेबसाईट उघडा (${companyMeta.website})`,
						className: "grid size-12 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-[#063B78] to-[#082F63] font-black text-white text-base shadow-sm hover:scale-105 transition-transform",
						children: job.initials
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								onClick: () => openModalTab("job"),
								title: lang === "mr" ? "नोकरीचे सविस्तर स्वरूप (Job Details) पाहा" : "View Full Job Details",
								className: "font-display text-base sm:text-lg font-black text-[#10233F] hover:text-[#063B78] hover:underline cursor-pointer transition-colors line-clamp-1",
								children: job.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: companyMeta.website,
								target: "_blank",
								rel: "noopener noreferrer",
								title: `${companyMeta.name} ची अधिकृत वेबसाईट उघडा`,
								className: "mt-0.5 inline-flex items-center gap-1.5 text-xs font-bold text-[#125BB5] hover:underline",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3.5 text-[#063B78]" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate",
										children: job.company
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3.5 text-emerald-600 shrink-0" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[10px] font-black text-[#FFC400] bg-[#082F63] px-1.5 py-0.2 rounded-full",
										children: ["★ ", companyMeta.rating]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3 text-[#125BB5] shrink-0" })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 flex items-center gap-2 text-xs font-semibold text-[#5B6B7F]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => openModalTab("job"),
									className: "inline-flex items-center gap-1 hover:text-[#063B78] hover:underline",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5 text-[#063B78]" }),
										" ",
										job.location
									]
								})
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid grid-cols-2 gap-3 rounded-xl bg-[#F5F8FC] p-3 border border-[#DCE5F0]/50",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						onClick: () => openModalTab("job"),
						className: "flex items-center gap-2.5 cursor-pointer hover:opacity-80 transition-opacity",
						title: lang === "mr" ? "पगार व नोकरीचे तपशील पाहा" : "View Salary Details",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid size-8 shrink-0 place-items-center rounded-lg bg-[#063B78]/10 text-[#063B78]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[9px] font-bold uppercase text-[#5B6B7F] truncate",
								children: lang === "mr" ? "सुरुवातीचा पगार" : "Starting Salary"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs sm:text-sm font-black text-[#063B78] truncate",
								children: n(job.salary)
							})]
						})]
					}), job.openings && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						onClick: () => openModalTab("openings"),
						className: "flex items-center gap-2.5 border-l border-[#DCE5F0] pl-3 cursor-pointer hover:opacity-80 transition-opacity",
						title: lang === "mr" ? "या कंपनीतील इतर सर्व जागा पाहा" : "View Active Openings",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid size-8 shrink-0 place-items-center rounded-lg bg-[#FFC400]/20 text-[#082F63]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[9px] font-bold uppercase text-[#5B6B7F] truncate",
								children: lang === "mr" ? "एकूण जागा" : "Openings"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs sm:text-sm font-black text-[#10233F] truncate",
								children: [
									n(job.openings),
									"+ ",
									lang === "mr" ? "शिल्लक" : "Vacancies"
								]
							})]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap items-center gap-2 relative z-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1 rounded-lg bg-[#063B78]/5 px-2 py-1 text-[10px] sm:text-[11px] font-bold text-[#063B78] whitespace-nowrap",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { className: "size-3" }),
								" ",
								job.type
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "inline-flex items-center gap-1 rounded-lg bg-[#063B78]/5 px-2 py-1 text-[10px] sm:text-[11px] font-bold text-[#063B78] whitespace-nowrap",
							children: job.workMode
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1 rounded-lg bg-[#063B78]/5 px-2 py-1 text-[10px] sm:text-[11px] font-bold text-[#063B78] whitespace-nowrap",
							children: [
								lang === "mr" ? "अनुभव" : "Exp",
								": ",
								n(job.experience)
							]
						}),
						companyMeta.skills.slice(0, 2).map((skill, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => openModalTab("job"),
							title: `View ${skill} requirement details`,
							className: "inline-flex items-center gap-1 rounded-lg bg-[#FFC400]/15 border border-[#FFC400]/30 hover:bg-[#FFC400] transition-colors px-2 py-1 text-[10px] sm:text-[11px] font-black text-[#082F63] whitespace-nowrap",
							children: skill
						}, idx))
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex items-center justify-between gap-2 border-t border-[#DCE5F0] pt-4 relative z-20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						className: "h-9 text-xs font-black border-[#063B78]/30 text-[#063B78] hover:bg-[#063B78] hover:text-white rounded-xl shadow-2xs px-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: companyMeta.website,
							target: "_blank",
							rel: "noopener noreferrer",
							title: `${companyMeta.name} ची अधिकृत वेबसाईट उघडा (${companyMeta.website})`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building, { className: "mr-1.5 size-3.5" }),
								lang === "mr" ? "कंपनी वेबसाईट" : "Company Website",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "ml-1 size-3" })
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: handleApplyClick,
						className: "btn-yellow h-9 px-5 font-black text-xs shadow-sm rounded-xl",
						children: [
							t("apply"),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "ml-1.5 size-3" })
						]
					})]
				})
			]
		}),
		showCompanyModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-50 flex items-center justify-center bg-[#082F63]/70 backdrop-blur-md p-4 animate-in fade-in duration-200",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative w-full max-w-3xl rounded-3xl border border-[#DCE5F0] bg-white shadow-2xl overflow-hidden flex flex-col max-h-[90vh]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-gradient-to-r from-[#063B78] via-[#082F63] to-[#125BB5] p-6 text-white relative",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setShowCompanyModal(false),
								className: "absolute right-4 top-4 grid size-8 place-items-center rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid size-16 shrink-0 place-items-center rounded-2xl bg-white font-black text-[#063B78] text-2xl shadow-lg border-2 border-[#FFC400]",
									children: job.initials
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1 min-w-0 pr-8",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 flex-wrap",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] font-black uppercase tracking-wider bg-[#FFC400] text-[#082F63] px-2 py-0.5 rounded-full",
												children: companyMeta.industry
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-xs font-bold text-emerald-300 flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4" }), " Real Job Verified Employer"]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-xl sm:text-2xl font-black text-white truncate",
											children: companyMeta.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 text-xs font-bold text-slate-200 flex-wrap",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-1",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5 text-[#FFC400]" }),
														" ",
														companyMeta.headquarters
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center gap-1 text-[#FFC400]",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-3.5 fill-[#FFC400]" }),
														" ",
														companyMeta.rating,
														" / 5.0 (",
														companyMeta.reviewsCount,
														")"
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Est. ", companyMeta.founded] })
											]
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 mt-6 border-b border-white/20",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setActiveModalTab("company"),
										className: `pb-2.5 px-3 text-xs sm:text-sm font-black transition-all border-b-2 ${activeModalTab === "company" ? "border-[#FFC400] text-[#FFC400]" : "border-transparent text-white/70 hover:text-white"}`,
										children: ["🏢 ", lang === "mr" ? "कंपनी पार्श्वभूमी" : "Company Profile"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setActiveModalTab("job"),
										className: `pb-2.5 px-3 text-xs sm:text-sm font-black transition-all border-b-2 ${activeModalTab === "job" ? "border-[#FFC400] text-[#FFC400]" : "border-transparent text-white/70 hover:text-white"}`,
										children: ["📋 ", lang === "mr" ? "नोकरी सविस्तर माहिती" : "Job Details"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setActiveModalTab("openings"),
										className: `pb-2.5 px-3 text-xs sm:text-sm font-black transition-all border-b-2 ${activeModalTab === "openings" ? "border-[#FFC400] text-[#FFC400]" : "border-transparent text-white/70 hover:text-white"}`,
										children: [
											"🚀 ",
											lang === "mr" ? "इतर जागा" : "Active Openings",
											" (",
											companyJobs.length,
											")"
										]
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-6 overflow-y-auto space-y-6 flex-1 text-[#10233F]",
						children: [
							activeModalTab === "company" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-6 animate-fade-in",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "text-xs font-black uppercase text-[#5B6B7F] tracking-wider mb-2",
										children: lang === "mr" ? "विश्वासार्हता आणि प्रमाणपत्रे" : "Verification Badges"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap items-center gap-2",
										children: companyMeta.trustBadges.map((badge, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "inline-flex items-center gap-1.5 rounded-xl bg-emerald-50 border border-emerald-200 px-3 py-1.5 text-xs font-black text-emerald-800",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-emerald-600" }), badge]
										}, idx))
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
										className: "text-sm font-black text-[#063B78] mb-2 flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4 text-[#063B78]" }), lang === "mr" ? "कंपनीबद्दल थोडक्यात (About Company)" : "About Company"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs sm:text-sm font-semibold leading-relaxed text-[#5B6B7F] bg-[#F5F8FC] p-4 rounded-2xl border border-[#DCE5F0]",
										children: lang === "mr" ? companyMeta.aboutMr : companyMeta.aboutEn
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 sm:grid-cols-4 gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-3 rounded-xl bg-[#F5F8FC] border border-[#DCE5F0]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
													children: "कर्मचारी संख्या"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-black text-[#063B78]",
													children: companyMeta.size
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-3 rounded-xl bg-[#F5F8FC] border border-[#DCE5F0]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
													children: "स्थापना वर्ष"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-xs font-black text-[#063B78]",
													children: ["वर्ष ", companyMeta.founded]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-3 rounded-xl bg-[#F5F8FC] border border-[#DCE5F0]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
													children: "मुख्यालय"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-black text-[#063B78] truncate block",
													children: companyMeta.headquarters
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-3 rounded-xl bg-[#F5F8FC] border border-[#DCE5F0]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] font-bold text-[#5B6B7F] uppercase block",
													children: "वेबसाईट"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
													href: companyMeta.website,
													target: "_blank",
													rel: "noreferrer",
													className: "text-xs font-black text-[#125BB5] hover:underline flex items-center gap-1",
													children: ["Visit Site ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3" })]
												})]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
										className: "text-sm font-black text-[#063B78] mb-2 flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "size-4 text-[#FFC400]" }), lang === "mr" ? "कामगारांना मिळणाऱ्या सुविधा (Employee Benefits & Perks)" : "Employee Perks"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
										children: (lang === "mr" ? companyMeta.perksMr : companyMeta.perksEn).map((perk, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 p-2.5 rounded-xl bg-[#EBF1F8] text-xs font-bold text-[#063B78]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "size-4 text-[#063B78] shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: perk })]
										}, idx))
									})] })
								]
							}),
							activeModalTab === "job" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-6 animate-fade-in",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-4 rounded-2xl bg-[#063B78]/5 border border-[#063B78]/15 space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-base font-black text-[#063B78]",
											children: job.title
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-center gap-4 text-xs font-bold text-[#5B6B7F]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["💰 Salary: ", job.salary] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["📍 Location: ", job.location] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["💼 Exp: ", job.experience] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
													"🕒 Type: ",
													job.type,
													" (",
													job.workMode,
													")"
												] })
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
										className: "text-sm font-black text-[#063B78] mb-2 flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4 text-[#063B78]" }), lang === "mr" ? "कामाचे स्वरूप आणि जबाबदाऱ्या" : "Job Description & Duties"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs sm:text-sm font-semibold leading-relaxed text-[#5B6B7F] bg-[#F5F8FC] p-4 rounded-2xl border border-[#DCE5F0]",
										children: lang === "mr" ? companyMeta.jobDescMr : companyMeta.jobDescEn
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
										className: "text-sm font-black text-[#063B78] mb-2 flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-4 text-[#063B78]" }), lang === "mr" ? "आवश्यक कौशल्ये (Required Skills)" : "Required Skills"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap gap-2",
										children: companyMeta.skills.map((skill, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "px-3 py-1 rounded-xl bg-[#063B78] text-white text-xs font-bold shadow-2xs",
											children: skill
										}, idx))
									})] })
								]
							}),
							activeModalTab === "openings" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-4 animate-fade-in",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
									className: "text-xs font-black uppercase text-[#5B6B7F] tracking-wider",
									children: [
										companyMeta.name,
										" ",
										lang === "mr" ? "मधील इतर सर्व नोकऱ्या" : "Active Vacancies"
									]
								}), companyJobs.map((cj) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-2xl border border-[#DCE5F0] bg-[#F5F8FC] flex items-center justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
										className: "font-black text-sm text-[#10233F]",
										children: cj.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs font-semibold text-[#5B6B7F] mt-0.5",
										children: [
											cj.location,
											" • ",
											cj.salary,
											" • ",
											cj.experience
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										onClick: () => {
											setShowCompanyModal(false);
											setShowApplyModal(true);
										},
										className: "btn-yellow h-8 px-4 font-black text-xs rounded-xl shrink-0",
										children: ["Apply ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "ml-1 size-3" })]
									})]
								}, cj.id))]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 bg-[#F5F8FC] border-t border-[#DCE5F0] flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-bold text-[#5B6B7F]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: lang === "mr" ? "थेट HR पडताळणी पूर्ण झालेली कंपनी" : "Verified HR Direct Recruiter" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setShowCompanyModal(false),
								className: "h-10 text-xs font-bold px-4 rounded-xl border-[#DCE5F0]",
								children: lang === "mr" ? "बंद करा" : "Close"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => {
									setShowCompanyModal(false);
									setShowApplyModal(true);
								},
								className: "btn-yellow h-10 px-6 font-black text-xs rounded-xl shadow-md",
								children: [
									t("apply"),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "ml-1.5 size-3.5" })
								]
							})]
						})]
					})
				]
			})
		}),
		showApplyModal && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "fixed inset-0 z-[100] flex flex-col bg-[#F5F8FC] overflow-y-auto animate-in fade-in duration-200",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white border-b border-[#DCE5F0] sticky top-0 z-10 px-4 sm:px-8 py-3 flex items-center justify-between shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-8 rounded-xl bg-gradient-to-br from-[#125BB5] to-[#063B78] flex items-center justify-center text-white font-black shadow-md",
						children: "J"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-black text-[#082F63] text-xl tracking-tight hidden sm:block",
						children: "JobPortal"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setShowApplyModal(false),
					className: "flex items-center gap-2 px-4 py-2 rounded-xl bg-[#F5F8FC] text-[#5B6B7F] hover:text-[#10233F] hover:bg-[#EBF1F8] font-bold text-sm transition-colors",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }),
						" ",
						lang === "mr" ? "बंद करा" : "Close"
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 w-full max-w-7xl mx-auto px-4 py-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col lg:flex-row gap-8 items-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 w-full bg-white rounded-3xl border border-[#DCE5F0] p-6 sm:p-10 shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-3xl font-black text-[#082F63] mb-2",
								children: lang === "mr" ? "नोकरीसाठी अर्ज करा" : "Apply for Job"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[#5B6B7F] font-semibold text-sm mb-8",
								children: lang === "mr" ? "खालील माहिती काळजीपूर्वक भरा." : "Fill in the details below to apply for this job. Make sure all information is correct."
							}),
							applied ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center py-12",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-20 text-[#063B78] mx-auto mb-4 animate-bounce" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-2xl font-black text-[#10233F]",
										children: lang === "mr" ? "अर्ज यशस्वीरीत्या पाठवला!" : "Application Submitted!"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold text-[#5B6B7F] mt-2 max-w-md mx-auto",
										children: lang === "mr" ? "तुमचा अर्ज कंपनीला पाठवण्यात आला आहे. ते लवकरच तुमच्याशी संपर्क साधतील." : "Your application has been sent to the employer. They will contact you shortly."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										onClick: () => setShowApplyModal(false),
										className: "btn-yellow h-12 px-8 font-black text-sm mt-8 rounded-xl",
										children: lang === "mr" ? "मागे जा" : "Go Back"
									})
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: submitApplication,
								className: "space-y-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DynamicApplicationForm, {
									appConfig,
									fieldValues,
									setFieldValues,
									customAnswers,
									setCustomAnswers,
									lang,
									category: job.category
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-8 flex justify-end gap-4 mt-8",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										onClick: () => setShowApplyModal(false),
										variant: "outline",
										className: "h-12 px-8 font-bold text-sm rounded-xl border-[#DCE5F0] text-[#5B6B7F]",
										children: lang === "mr" ? "रद्द करा" : "Cancel"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "submit",
										className: "btn-yellow h-12 px-8 font-black text-sm shadow-md rounded-xl",
										children: [
											lang === "mr" ? "अंतिम अर्ज सादर करा" : "Submit Application",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "ml-2 size-4" })
										]
									})]
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-full lg:w-[400px] shrink-0 bg-white rounded-3xl border border-[#DCE5F0] p-6 shadow-sm sticky top-24 hidden lg:block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between mb-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-14 place-items-center rounded-2xl bg-[#063B78] font-black text-white text-xl shadow-md",
									children: job.initials
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: "outline",
									className: "bg-emerald-50 text-emerald-700 border-emerald-200 font-bold px-3 py-1 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5" }), "Active"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-2xl font-black text-[#10233F] mb-2",
								children: job.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2 mb-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm font-bold text-[#125BB5] flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building, { className: "size-4" }),
										" ",
										job.company
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm font-semibold text-[#5B6B7F] flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" }),
										" ",
										job.location
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "inline-block px-3 py-1 bg-[#EBF1F8] text-[#125BB5] text-xs font-bold rounded-lg mb-6",
								children: job.category || "General"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-3 items-start",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-8 rounded-full bg-[#F5F8FC] flex items-center justify-center shrink-0",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-4 text-[#5B6B7F]" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-bold text-[#5B6B7F]",
											children: "Experience Required"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-black text-[#10233F]",
											children: job.experience
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-3 items-start",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-8 rounded-full bg-[#F5F8FC] flex items-center justify-center shrink-0",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-4 text-[#5B6B7F]" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-bold text-[#5B6B7F]",
											children: "Salary"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-black text-[#10233F]",
											children: job.salary
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-3 items-start",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-8 rounded-full bg-[#F5F8FC] flex items-center justify-center shrink-0",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-4 text-[#5B6B7F]" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-bold text-[#5B6B7F]",
											children: "Vacancies"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-black text-[#10233F]",
											children: job.vacancies || 1
										})] })]
									})
								]
							})
						]
					})]
				})
			})]
		})
	] });
}
//#endregion
export { jobs as a, getFallbackConfig as i, JobCard as n, getCompanyMetadata as r, DynamicApplicationForm as t };
